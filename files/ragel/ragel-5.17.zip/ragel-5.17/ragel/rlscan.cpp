#line 1 "rlscan.rl"
/*
 *  Copyright 2006 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <fstream>
#include <string.h>

#include "ragel.h"
#include "rlparse.h"
#include "parsedata.h"
#include "avltree.h"
#include "vector.h"


using std::ifstream;
using std::istream;
using std::ostream;
using std::cout;
using std::cerr;
using std::endl;

/* This is used for tracking the current stack of include file/machine pairs. It is
 * is used to detect and recursive include structure. */
struct IncludeStackItem
{
	IncludeStackItem( char *fileName, char *sectionName )
		: fileName(fileName), sectionName(sectionName) {}

	char *fileName;
	char *sectionName;
};

typedef Vector<IncludeStackItem> IncludeStack;

enum InlineBlockType
{
	CurlyDelimited,
	SemiTerminated
};

struct Scanner
{
	Scanner( char *fileName, istream &input, ostream &output,
			Parser *inclToParser, char *inclSectionTarg,
			int includeDepth )
	: 
		fileName(fileName), input(input), output(output),
		inclToParser(inclToParser),
		inclSectionTarg(inclSectionTarg),
		includeDepth(includeDepth),
		line(1), column(1), lastnl(0), 
		parser(0), active(false), 
		parserExistsError(false), ragelDefOpen(false),
		whitespaceOn(true)
		{}

	bool recursiveInclude( char *inclFileName, char *inclSectionName );

	char *prepareFileName( char *fileName, int len )
	{
		bool caseInsensitive;
		Token tokenFnStr, tokenRes;
		tokenFnStr.data = fileName;
		tokenFnStr.length = len;
		tokenFnStr.prepareLitString( tokenRes, caseInsensitive );
		return tokenRes.data;
	}

	void init();
	void token( int type, char *start, char *end );
	void token( int type, char c );
	void token( int type );
	void updateCol();
	void startSection();
	void endSection();
	void openRagelDef();
	void do_scan();
	bool parserExists();
	ostream &scan_error();

	char *fileName;
	istream &input;
	ostream &output;
	Parser *inclToParser;
	char *inclSectionTarg;
	int includeDepth;

	int cs;
	int line;
	char *word, *lit;
	int word_len, lit_len;
	InputLoc sectionLoc;
	char *tokstart, *tokend;
	int column;
	char *lastnl;

	/* Set by machine statements, these persist from section to section
	 * allowing for unnamed sections. */
	Parser *parser;
	bool active;
	IncludeStack includeStack;

	/* This is set if ragel has already emitted an error stating that
	 * no section name has been seen and thus no parser exists. */
	bool parserExistsError;
	bool ragelDefOpen;

	/* This is for inline code. By default it is on. It goes off for
	 * statements and values in inline blocks which are parsed. */
	bool whitespaceOn;
};


#line 134 "rlscan.cpp"
static const int section_parse_start = 8;

static const int section_parse_first_final = 8;

static const int section_parse_error = 1;

#line 135 "rlscan.rl"


void Scanner::init( )
{
	
#line 147 "rlscan.cpp"
	{
	cs = section_parse_start;
	}
#line 140 "rlscan.rl"
}

bool Scanner::parserExists()
{
	if ( parser != 0 )
		return true;

	if ( ! parserExistsError ) {
		scan_error() << "include: there is no previous specification name" << endl;
		parserExistsError = true;
	}
	return false;
}

ostream &Scanner::scan_error()
{
	/* Maintain the error count. */
	gblErrorCount += 1;
	cerr << fileName << ":" << line << ":" << column << ": ";
	return cerr;
}

bool Scanner::recursiveInclude( char *inclFileName, char *inclSectionName )
{
	for ( IncludeStack::Iter si = includeStack; si.lte(); si++ ) {
		if ( strcmp( si->fileName, inclFileName ) == 0 &&
				strcmp( si->sectionName, inclSectionName ) == 0 )
		{
			return true;
		}
	}
	return false;	
}

void Scanner::updateCol()
{
	char *from = lastnl;
	if ( from == 0 )
		from = tokstart;
	//cerr << "adding " << tokend - from << " to column" << endl;
	column += tokend - from;
	lastnl = 0;
}

void Scanner::token( int type, char c )
{
	token( type, &c, &c + 1 );
}

void Scanner::token( int type )
{
	token( type, 0, 0 );
}

#line 360 "rlscan.rl"


void Scanner::token( int type, char *start, char *end )
{
	char *tokdata = 0;
	int toklen = 0;
	int *p = &type;
	int *pe = &type + 1;

	if ( start != 0 ) {
		toklen = end-start;
		tokdata = new char[toklen+1];
		memcpy( tokdata, start, toklen );
		tokdata[toklen] = 0;
	}

	
#line 224 "rlscan.cpp"
	{
	if ( p == pe )
		goto _out;
	switch ( cs )
	{
tr0:
#line 329 "rlscan.rl"
	{
		/* Send the token off to the parser. */
		if ( active && parserExists() ) {
			InputLoc loc;

			#if 0
			cerr << "scanner:" << line << ":" << column << 
					": sending token to the parser " << lelNames[*p];
			cerr << " " << toklen;
			if ( tokdata != 0 )
				cerr << " " << tokdata;
			cerr << endl;
			#endif

			loc.fileName = fileName;
			loc.line = line;
			loc.col = column;

			parser->token( loc, type, tokdata, toklen );
		}
	}
	goto st8;
tr6:
#line 214 "rlscan.rl"
	{
		/* Assign a name to the machine. */
		char *machine = word;

		if ( inclSectionTarg == 0 ) {
			active = true;

			ParserDictEl *pdEl = parserDict.find( machine );
			if ( pdEl == 0 ) {
				pdEl = new ParserDictEl( machine );
				pdEl->value = new Parser( fileName, machine, sectionLoc );
				pdEl->value->init();
				parserDict.insert( pdEl );
			}

			parser = pdEl->value;
		}
		else if ( strcmp( inclSectionTarg, machine ) == 0 ) {
			/* found include target */
			active = true;
			parser = inclToParser;
		}
		else {
			/* ignoring section */
			active = false;
			parser = 0;
		}
	}
	goto st8;
tr10:
#line 248 "rlscan.rl"
	{
		if ( active && parserExists() ) {
			char *inclSectionName = word;
			char *inclFileName = 0;

			/* Implement defaults for the input file and section name. */
			if ( inclSectionName == 0 )
				inclSectionName = parser->sectionName;

			if ( lit != 0 ) 
				inclFileName = prepareFileName( lit, lit_len );
			else
				inclFileName = fileName;

			/* Check for a recursive include structure. Add the current file/section
			 * name then check if what we are including is already in the stack. */
			includeStack.append( IncludeStackItem( fileName, parser->sectionName ) );

			if ( recursiveInclude( inclFileName, inclSectionName ) )
				scan_error() << "include: this is a recursive include operation" << endl;
			else {
				/* Open the input file for reading. */
				ifstream *inFile = new ifstream( inclFileName );
				if ( ! inFile->is_open() ) {
					scan_error() << "include: could not open " << 
							inclFileName << " for reading" << endl;
				}

				Scanner scanner( inclFileName, *inFile, output, parser,
						inclSectionName, includeDepth+1 );
				scanner.init();
				scanner.do_scan( );
				delete inFile;
			}

			/* Remove the last element (len-1) */
			includeStack.remove( -1 );
		}
	}
	goto st8;
tr14:
#line 318 "rlscan.rl"
	{
		if ( active )
			output << "</write>\n";
	}
	goto st8;
st8:
	if ( ++p == pe )
		goto _out8;
case 8:
#line 338 "rlscan.cpp"
	switch( (*p) ) {
		case 128: goto st0;
		case 129: goto st3;
		case 130: goto st6;
	}
	goto tr0;
st0:
	if ( ++p == pe )
		goto _out0;
case 0:
	if ( (*p) == 131 )
		goto tr5;
	goto tr4;
tr4:
#line 209 "rlscan.rl"
	{ scan_error() << "bad machine statement" << endl; }
	goto st1;
tr7:
#line 210 "rlscan.rl"
	{ scan_error() << "bad include statement" << endl; }
	goto st1;
tr12:
#line 211 "rlscan.rl"
	{ scan_error() << "bad write statement" << endl; }
	goto st1;
#line 364 "rlscan.cpp"
st1:
	goto _out1;
tr5:
#line 206 "rlscan.rl"
	{ word = tokdata; word_len = toklen; }
	goto st2;
st2:
	if ( ++p == pe )
		goto _out2;
case 2:
#line 375 "rlscan.cpp"
	if ( (*p) == 59 )
		goto tr6;
	goto tr4;
st3:
	if ( ++p == pe )
		goto _out3;
case 3:
	switch( (*p) ) {
		case 131: goto tr8;
		case 132: goto tr9;
	}
	goto tr7;
tr8:
#line 205 "rlscan.rl"
	{ word = lit = 0; word_len = lit_len = 0; }
#line 206 "rlscan.rl"
	{ word = tokdata; word_len = toklen; }
	goto st4;
st4:
	if ( ++p == pe )
		goto _out4;
case 4:
#line 398 "rlscan.cpp"
	switch( (*p) ) {
		case 59: goto tr10;
		case 132: goto tr11;
	}
	goto tr7;
tr9:
#line 205 "rlscan.rl"
	{ word = lit = 0; word_len = lit_len = 0; }
#line 207 "rlscan.rl"
	{ lit = tokdata; lit_len = toklen; }
	goto st5;
tr11:
#line 207 "rlscan.rl"
	{ lit = tokdata; lit_len = toklen; }
	goto st5;
st5:
	if ( ++p == pe )
		goto _out5;
case 5:
#line 418 "rlscan.cpp"
	if ( (*p) == 59 )
		goto tr10;
	goto tr7;
st6:
	if ( ++p == pe )
		goto _out6;
case 6:
	if ( (*p) == 131 )
		goto tr13;
	goto tr12;
tr13:
#line 298 "rlscan.rl"
	{
		if ( active ) {
			openRagelDef();
			if ( strcmp( tokdata, "data" ) != 0 &&
					strcmp( tokdata, "init" ) != 0 &&
					strcmp( tokdata, "exec" ) != 0 &&
					strcmp( tokdata, "eof" ) != 0 )
			{
				scan_error() << "unknown write command" << endl;
			}
			output << "  <write what=\"" << tokdata << "\">";
		}
	}
	goto st7;
tr15:
#line 313 "rlscan.rl"
	{
		if ( active )
			output << "<option>" << tokdata << "</option>";
	}
	goto st7;
st7:
	if ( ++p == pe )
		goto _out7;
case 7:
#line 456 "rlscan.cpp"
	switch( (*p) ) {
		case 59: goto tr14;
		case 131: goto tr15;
	}
	goto tr12;
	}
	_out8: cs = 8; goto _out; 
	_out0: cs = 0; goto _out; 
	_out1: cs = 1; goto _out; 
	_out2: cs = 2; goto _out; 
	_out3: cs = 3; goto _out; 
	_out4: cs = 4; goto _out; 
	_out5: cs = 5; goto _out; 
	_out6: cs = 6; goto _out; 
	_out7: cs = 7; goto _out; 

	_out: {}
	}
#line 379 "rlscan.rl"


	updateCol();
}

void Scanner::startSection( )
{
	parserExistsError = false;

	if ( includeDepth == 0 ) {
		if ( machineSpec == 0 && machineName == 0 )
			output << "</host>\n";
		ragelDefOpen = false;
	}

	sectionLoc.fileName = fileName;
	sectionLoc.line = line;
	sectionLoc.col = 0;
}

void Scanner::openRagelDef()
{
	if ( ! ragelDefOpen ) {
		ragelDefOpen = true;
		output << "<ragel_def name=\"" << parser->sectionName << "\">\n";
	}
}

void Scanner::endSection( )
{
	/* Execute the eof actions for the section parser. */
	
#line 508 "rlscan.cpp"
	{
	switch ( cs ) {
	case 0: 
	case 2: 
#line 209 "rlscan.rl"
	{ scan_error() << "bad machine statement" << endl; }
	break;
	case 3: 
	case 4: 
	case 5: 
#line 210 "rlscan.rl"
	{ scan_error() << "bad include statement" << endl; }
	break;
	case 6: 
	case 7: 
#line 211 "rlscan.rl"
	{ scan_error() << "bad write statement" << endl; }
	break;
#line 527 "rlscan.cpp"
	}
	}

#line 413 "rlscan.rl"


	/* Close off the section with the parser. */
	if ( active && parserExists() ) {
		InputLoc loc;
		loc.fileName = fileName;
		loc.line = line;
		loc.col = 0;

		parser->token( loc, TK_EndSection, 0, 0 );
	}

	if ( includeDepth == 0 ) {
		if ( ragelDefOpen ) {
			output << "</ragel_def>\n";
			ragelDefOpen = false;
		}

		if ( machineSpec == 0 && machineName == 0 ) {
			/* The end section may include a newline on the end, so
			 * we use the last line, which will count the newline. */
			output << "<host line=\"" << line << "\">";
		}
	}
}

#line 829 "rlscan.rl"



#line 562 "rlscan.cpp"
static const int rlscan_start = 23;

static const int rlscan_first_final = 23;

static const int rlscan_error = 15;

#line 832 "rlscan.rl"

void Scanner::do_scan()
{
	int bufsize = 8;
	char *buf = new char[bufsize];
	const char last_char = 0;
	int cs, act, have = 0;
	int top, stack[1];
	int curly_count = 0;
	bool execute = true;
	bool singleLineSpec = false;
	InlineBlockType inlineBlockType;

	
#line 584 "rlscan.cpp"
	{
	cs = rlscan_start;
	top = 0;
	tokstart = 0;
	tokend = 0;
	act = 0;
	}
#line 846 "rlscan.rl"

	while ( execute ) {
		char *p = buf + have;
		int space = bufsize - have;

		if ( space == 0 ) {
			/* We filled up the buffer trying to scan a token. Grow it. */
			bufsize = bufsize * 2;
			char *newbuf = new char[bufsize];

			/* Recompute p and space. */
			p = newbuf + have;
			space = bufsize - have;

			/* Patch up pointers possibly in use. */
			if ( tokstart != 0 )
				tokstart = newbuf + ( tokstart - buf );
			tokend = newbuf + ( tokend - buf );

			/* Copy the new buffer in. */
			memcpy( newbuf, buf, have );
			delete[] buf;
			buf = newbuf;
		}

		input.read( p, space );
		int len = input.gcount();

		/* If we see eof then append the EOF char. */
	 	if ( len == 0 ) {
			p[0] = last_char, len = 1;
			execute = false;
		}

		char *pe = p + len;
		
#line 629 "rlscan.cpp"
	{
	if ( p == pe )
		goto _out;
	goto _resume;

_again:
	switch ( cs ) {
		case 23: goto st23;
		case 24: goto st24;
		case 25: goto st25;
		case 0: goto st0;
		case 1: goto st1;
		case 26: goto st26;
		case 27: goto st27;
		case 28: goto st28;
		case 2: goto st2;
		case 3: goto st3;
		case 29: goto st29;
		case 4: goto st4;
		case 5: goto st5;
		case 6: goto st6;
		case 30: goto st30;
		case 31: goto st31;
		case 32: goto st32;
		case 33: goto st33;
		case 34: goto st34;
		case 7: goto st7;
		case 8: goto st8;
		case 35: goto st35;
		case 9: goto st9;
		case 10: goto st10;
		case 36: goto st36;
		case 11: goto st11;
		case 12: goto st12;
		case 13: goto st13;
		case 37: goto st37;
		case 38: goto st38;
		case 14: goto st14;
		case 39: goto st39;
		case 40: goto st40;
		case 41: goto st41;
		case 42: goto st42;
		case 43: goto st43;
		case 44: goto st44;
		case 45: goto st45;
		case 46: goto st46;
		case 47: goto st47;
		case 48: goto st48;
		case 49: goto st49;
		case 50: goto st50;
		case 51: goto st51;
		case 52: goto st52;
		case 53: goto st53;
		case 54: goto st54;
		case 55: goto st55;
		case 56: goto st56;
		case 57: goto st57;
		case 58: goto st58;
		case 59: goto st59;
		case 60: goto st60;
		case 61: goto st61;
		case 62: goto st62;
		case 63: goto st63;
		case 64: goto st64;
		case 65: goto st65;
		case 66: goto st66;
		case 67: goto st67;
		case 68: goto st68;
		case 69: goto st69;
		case 70: goto st70;
		case 71: goto st71;
		case 72: goto st72;
		case 73: goto st73;
		case 74: goto st74;
		case 75: goto st75;
		case 76: goto st76;
		case 77: goto st77;
		case 78: goto st78;
		case 79: goto st79;
		case 80: goto st80;
		case 15: goto st15;
		case 81: goto st81;
		case 82: goto st82;
		case 83: goto st83;
		case 84: goto st84;
		case 85: goto st85;
		case 16: goto st16;
		case 86: goto st86;
		case 17: goto st17;
		case 87: goto st87;
		case 18: goto st18;
		case 88: goto st88;
		case 89: goto st89;
		case 90: goto st90;
		case 19: goto st19;
		case 20: goto st20;
		case 91: goto st91;
		case 92: goto st92;
		case 93: goto st93;
		case 94: goto st94;
		case 95: goto st95;
		case 21: goto st21;
		case 96: goto st96;
		case 97: goto st97;
		case 98: goto st98;
		case 99: goto st99;
		case 100: goto st100;
		case 101: goto st101;
		case 102: goto st102;
		case 103: goto st103;
		case 104: goto st104;
		case 105: goto st105;
		case 106: goto st106;
		case 107: goto st107;
		case 108: goto st108;
		case 109: goto st109;
		case 110: goto st110;
		case 111: goto st111;
		case 112: goto st112;
		case 113: goto st113;
		case 114: goto st114;
		case 115: goto st115;
		case 116: goto st116;
		case 117: goto st117;
		case 118: goto st118;
		case 119: goto st119;
		case 120: goto st120;
		case 121: goto st121;
		case 122: goto st122;
		case 123: goto st123;
		case 124: goto st124;
		case 125: goto st125;
		case 126: goto st126;
		case 127: goto st127;
		case 128: goto st128;
		case 129: goto st129;
		case 130: goto st130;
		case 131: goto st131;
		case 132: goto st132;
		case 133: goto st133;
		case 134: goto st134;
		case 135: goto st135;
		case 136: goto st136;
		case 137: goto st137;
		case 138: goto st138;
		case 139: goto st139;
		case 140: goto st140;
		case 141: goto st141;
		case 142: goto st142;
		case 143: goto st143;
		case 144: goto st144;
		case 145: goto st145;
		case 146: goto st146;
		case 147: goto st147;
		case 148: goto st148;
		case 149: goto st149;
		case 150: goto st150;
		case 151: goto st151;
		case 152: goto st152;
		case 153: goto st153;
		case 154: goto st154;
		case 155: goto st155;
		case 156: goto st156;
		case 157: goto st157;
		case 158: goto st158;
		case 159: goto st159;
		case 160: goto st160;
		case 161: goto st161;
		case 22: goto st22;
	default: break;
	}

	if ( ++p == pe )
		goto _out;
_resume:
	switch ( cs )
	{
tr2:
#line 797 "rlscan.rl"
	{tokend = p+1;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
tr7:
#line 797 "rlscan.rl"
	{tokend = p;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
tr9:
#line 797 "rlscan.rl"
	{tokend = p;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
tr11:
#line 818 "rlscan.rl"
	{tokend = p;{ 
			updateCol();
			singleLineSpec = true;
			startSection();
			{{p = ((tokend))-1;}{goto st83;}}
		}{p = ((tokend))-1;}}
	goto st23;
tr12:
#line 812 "rlscan.rl"
	{tokend = p+1;{ 
			updateCol();
			singleLineSpec = false;
			startSection();
			{{p = ((tokend))-1;}{goto st83;}}
		}{p = ((tokend))-1;}}
	goto st23;
tr13:
#line 797 "rlscan.rl"
	{tokend = p;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
tr16:
#line 797 "rlscan.rl"
	{tokend = p;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
tr20:
#line 797 "rlscan.rl"
	{tokend = p+1;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
tr21:
#line 825 "rlscan.rl"
	{tokend = p+1;{p = ((tokend))-1;}}
	goto st23;
tr28:
#line 797 "rlscan.rl"
	{tokend = p+1;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
tr29:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
#line 797 "rlscan.rl"
	{tokend = p+1;{
		updateCol();

		/* If no errors and we are at the bottom of the include stack (the
		 * source file listed on the command line) then write out the data. */
		if ( includeDepth == 0 && machineSpec == 0 && machineName == 0 )
			xmlEscapeHost( output, tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st23;
st23:
#line 1 "rlscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out23;
case 23:
#line 1 "rlscan.rl"
	{tokstart = p;}
#line 931 "rlscan.cpp"
	switch( (*p) ) {
		case 0: goto tr21;
		case 9: goto st24;
		case 10: goto tr15;
		case 32: goto st24;
		case 34: goto tr22;
		case 37: goto st26;
		case 39: goto tr24;
		case 47: goto tr25;
		case 95: goto st31;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st30;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st31;
	} else
		goto st31;
	goto tr20;
tr15:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st24;
st24:
	if ( ++p == pe )
		goto _out24;
case 24:
#line 964 "rlscan.cpp"
	switch( (*p) ) {
		case 9: goto st24;
		case 10: goto tr15;
		case 32: goto st24;
	}
	goto tr13;
tr22:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st25;
st25:
	if ( ++p == pe )
		goto _out25;
case 25:
#line 979 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr5;
		case 34: goto tr2;
		case 92: goto st1;
	}
	goto st0;
tr5:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st0;
st0:
	if ( ++p == pe )
		goto _out0;
case 0:
#line 998 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr5;
		case 34: goto tr2;
		case 92: goto st1;
	}
	goto st0;
st1:
	if ( ++p == pe )
		goto _out1;
case 1:
	if ( (*p) == 10 )
		goto tr5;
	goto st0;
st26:
	if ( ++p == pe )
		goto _out26;
case 26:
	if ( (*p) == 37 )
		goto st27;
	goto tr16;
st27:
	if ( ++p == pe )
		goto _out27;
case 27:
	if ( (*p) == 123 )
		goto tr12;
	goto tr11;
tr24:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st28;
st28:
	if ( ++p == pe )
		goto _out28;
case 28:
#line 1034 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr1;
		case 39: goto tr2;
		case 92: goto st3;
	}
	goto st2;
tr1:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st2;
st2:
	if ( ++p == pe )
		goto _out2;
case 2:
#line 1053 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr1;
		case 39: goto tr2;
		case 92: goto st3;
	}
	goto st2;
st3:
	if ( ++p == pe )
		goto _out3;
case 3:
	if ( (*p) == 10 )
		goto tr1;
	goto st2;
tr25:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st29;
st29:
	if ( ++p == pe )
		goto _out29;
case 29:
#line 1075 "rlscan.cpp"
	switch( (*p) ) {
		case 42: goto st4;
		case 47: goto st6;
	}
	goto tr16;
tr26:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st4;
st4:
	if ( ++p == pe )
		goto _out4;
case 4:
#line 1093 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr26;
		case 42: goto st5;
	}
	goto st4;
st5:
	if ( ++p == pe )
		goto _out5;
case 5:
	switch( (*p) ) {
		case 10: goto tr26;
		case 42: goto st5;
		case 47: goto tr28;
	}
	goto st4;
st6:
	if ( ++p == pe )
		goto _out6;
case 6:
	if ( (*p) == 10 )
		goto tr29;
	goto st6;
st30:
	if ( ++p == pe )
		goto _out30;
case 30:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st30;
	goto tr9;
st31:
	if ( ++p == pe )
		goto _out31;
case 31:
	if ( (*p) == 95 )
		goto st31;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st31;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st31;
	} else
		goto st31;
	goto tr7;
tr32:
#line 519 "rlscan.rl"
	{tokend = p+1;{ token( IL_Literal, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr37:
#line 478 "rlscan.rl"
	{tokend = p;{ token( KW_Char ); }{p = ((tokend))-1;}}
	goto st32;
tr41:
#line 513 "rlscan.rl"
	{tokend = p;{ token( TK_Word, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr72:
#line 515 "rlscan.rl"
	{tokend = p;{ token( TK_UInt, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr75:
#line 516 "rlscan.rl"
	{tokend = p;{ token( TK_Hex, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr77:
#line 521 "rlscan.rl"
	{tokend = p;{ 
			if ( whitespaceOn ) 
				token( IL_WhiteSpace, tokstart, tokend );
		}{p = ((tokend))-1;}}
	goto st32;
tr80:
#line 572 "rlscan.rl"
	{tokend = p;{ token( IL_Symbol, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr83:
#line 527 "rlscan.rl"
	{tokend = p+1;{ token( TK_NameSep, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr84:
#line 1 "rlscan.rl"
	{	switch( act ) {
	case 1:
	{ token( KW_PChar ); }
	break;
	case 3:
	{ token( KW_CurState ); }
	break;
	case 4:
	{ token( KW_TargState ); }
	break;
	case 5:
	{ 
			whitespaceOn = false; 
			token( KW_Entry );
		}
	break;
	case 6:
	{ 
			whitespaceOn = false; 
			token( KW_Hold );
		}
	break;
	case 7:
	{ token( KW_Exec, 0, 0 ); }
	break;
	case 8:
	{ 
			whitespaceOn = false; 
			token( KW_Goto );
		}
	break;
	case 9:
	{ 
			whitespaceOn = false; 
			token( KW_Next );
		}
	break;
	case 10:
	{ 
			whitespaceOn = false; 
			token( KW_Call );
		}
	break;
	case 11:
	{ 
			whitespaceOn = false; 
			token( KW_Ret );
		}
	break;
	case 12:
	{ 
			whitespaceOn = false; 
			token( KW_Break );
		}
	break;
	case 13:
	{ token( TK_Word, tokstart, tokend ); }
	break;
	default: break;
	}
	{p = ((tokend))-1;}}
	goto st32;
tr85:
#line 572 "rlscan.rl"
	{tokend = p+1;{ token( IL_Symbol, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr86:
#line 567 "rlscan.rl"
	{tokend = p+1;{
			scan_error() << "unterminated code block" << endl;
		}{p = ((tokend))-1;}}
	goto st32;
tr89:
#line 547 "rlscan.rl"
	{tokend = p+1;{ token( *tokstart, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr90:
#line 542 "rlscan.rl"
	{tokend = p+1;{ 
			whitespaceOn = true;
			token( *tokstart, tokstart, tokend );
		}{p = ((tokend))-1;}}
	goto st32;
tr94:
#line 535 "rlscan.rl"
	{tokend = p+1;{
			whitespaceOn = true;
			token( *tokstart, tokstart, tokend );
			if ( inlineBlockType == SemiTerminated )
				{{p = ((tokend))-1;}{goto st83;}}
		}{p = ((tokend))-1;}}
	goto st32;
tr96:
#line 549 "rlscan.rl"
	{tokend = p+1;{ 
			token( IL_Symbol, tokstart, tokend );
			curly_count += 1; 
		}{p = ((tokend))-1;}}
	goto st32;
tr97:
#line 554 "rlscan.rl"
	{tokend = p+1;{ 
			if ( --curly_count == 0 && inlineBlockType == CurlyDelimited ) {
				/* Inline code block ends. */
				token( '}' );
				{{p = ((tokend))-1;}{goto st83;}}
			}
			else {
				/* Either a semi terminated inline block or only the closing
				 * brace of some inner scope, not the block's closing brace. */
				token( IL_Symbol, tokstart, tokend );
			}
		}{p = ((tokend))-1;}}
	goto st32;
tr100:
#line 525 "rlscan.rl"
	{tokend = p+1;{ token( IL_Comment, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr101:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
#line 525 "rlscan.rl"
	{tokend = p+1;{ token( IL_Comment, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
tr102:
#line 515 "rlscan.rl"
	{{ token( TK_UInt, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st32;
st32:
#line 1 "rlscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out32;
case 32:
#line 1 "rlscan.rl"
	{tokstart = p;}
#line 1315 "rlscan.cpp"
	switch( (*p) ) {
		case 0: goto tr86;
		case 9: goto st33;
		case 10: goto tr79;
		case 32: goto st33;
		case 34: goto tr87;
		case 39: goto tr88;
		case 40: goto tr89;
		case 44: goto tr89;
		case 47: goto tr91;
		case 48: goto tr92;
		case 58: goto st40;
		case 59: goto tr94;
		case 95: goto tr38;
		case 102: goto st42;
		case 123: goto tr96;
		case 125: goto tr97;
	}
	if ( (*p) < 49 ) {
		if ( 41 <= (*p) && (*p) <= 42 )
			goto tr90;
	} else if ( (*p) > 57 ) {
		if ( (*p) > 90 ) {
			if ( 97 <= (*p) && (*p) <= 122 )
				goto tr38;
		} else if ( (*p) >= 65 )
			goto tr38;
	} else
		goto st38;
	goto tr85;
tr79:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st33;
st33:
	if ( ++p == pe )
		goto _out33;
case 33:
#line 1358 "rlscan.cpp"
	switch( (*p) ) {
		case 9: goto st33;
		case 10: goto tr79;
		case 32: goto st33;
	}
	goto tr77;
tr87:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st34;
st34:
	if ( ++p == pe )
		goto _out34;
case 34:
#line 1373 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr35;
		case 34: goto tr32;
		case 92: goto st8;
	}
	goto st7;
tr35:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st7;
st7:
	if ( ++p == pe )
		goto _out7;
case 7:
#line 1392 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr35;
		case 34: goto tr32;
		case 92: goto st8;
	}
	goto st7;
st8:
	if ( ++p == pe )
		goto _out8;
case 8:
	if ( (*p) == 10 )
		goto tr35;
	goto st7;
tr88:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st35;
st35:
	if ( ++p == pe )
		goto _out35;
case 35:
#line 1414 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr31;
		case 39: goto tr32;
		case 92: goto st10;
	}
	goto st9;
tr31:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st9;
st9:
	if ( ++p == pe )
		goto _out9;
case 9:
#line 1433 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr31;
		case 39: goto tr32;
		case 92: goto st10;
	}
	goto st9;
st10:
	if ( ++p == pe )
		goto _out10;
case 10:
	if ( (*p) == 10 )
		goto tr31;
	goto st9;
tr91:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st36;
st36:
	if ( ++p == pe )
		goto _out36;
case 36:
#line 1455 "rlscan.cpp"
	switch( (*p) ) {
		case 42: goto st11;
		case 47: goto st13;
	}
	goto tr80;
tr98:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st11;
st11:
	if ( ++p == pe )
		goto _out11;
case 11:
#line 1473 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr98;
		case 42: goto st12;
	}
	goto st11;
st12:
	if ( ++p == pe )
		goto _out12;
case 12:
	switch( (*p) ) {
		case 10: goto tr98;
		case 42: goto st12;
		case 47: goto tr100;
	}
	goto st11;
st13:
	if ( ++p == pe )
		goto _out13;
case 13:
	if ( (*p) == 10 )
		goto tr101;
	goto st13;
tr92:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st37;
st37:
	if ( ++p == pe )
		goto _out37;
case 37:
#line 1504 "rlscan.cpp"
	if ( (*p) == 120 )
		goto st14;
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st38;
	goto tr72;
st38:
	if ( ++p == pe )
		goto _out38;
case 38:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st38;
	goto tr72;
st14:
	if ( ++p == pe )
		goto _out14;
case 14:
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st39;
	} else if ( (*p) > 70 ) {
		if ( 97 <= (*p) && (*p) <= 102 )
			goto st39;
	} else
		goto st39;
	goto tr102;
st39:
	if ( ++p == pe )
		goto _out39;
case 39:
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st39;
	} else if ( (*p) > 70 ) {
		if ( 97 <= (*p) && (*p) <= 102 )
			goto st39;
	} else
		goto st39;
	goto tr75;
st40:
	if ( ++p == pe )
		goto _out40;
case 40:
	if ( (*p) == 58 )
		goto tr83;
	goto tr80;
tr38:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 513 "rlscan.rl"
	{act = 13;}
	goto st41;
tr61:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 481 "rlscan.rl"
	{act = 5;}
	goto st41;
tr62:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 496 "rlscan.rl"
	{act = 9;}
	goto st41;
tr63:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 504 "rlscan.rl"
	{act = 11;}
	goto st41;
tr64:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 479 "rlscan.rl"
	{act = 3;}
	goto st41;
tr65:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 480 "rlscan.rl"
	{act = 4;}
	goto st41;
tr66:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 492 "rlscan.rl"
	{act = 8;}
	goto st41;
tr67:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 500 "rlscan.rl"
	{act = 10;}
	goto st41;
tr68:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 508 "rlscan.rl"
	{act = 12;}
	goto st41;
tr69:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 487 "rlscan.rl"
	{act = 6;}
	goto st41;
tr70:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 477 "rlscan.rl"
	{act = 1;}
	goto st41;
tr71:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 491 "rlscan.rl"
	{act = 7;}
	goto st41;
st41:
	if ( ++p == pe )
		goto _out41;
case 41:
#line 1626 "rlscan.cpp"
	if ( (*p) == 95 )
		goto tr38;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr84;
st42:
	if ( ++p == pe )
		goto _out42;
case 42:
	switch( (*p) ) {
		case 95: goto tr38;
		case 98: goto st43;
		case 99: goto st47;
		case 101: goto st52;
		case 103: goto st58;
		case 104: goto st61;
		case 110: goto st64;
		case 112: goto st67;
		case 114: goto st68;
		case 116: goto st70;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st43:
	if ( ++p == pe )
		goto _out43;
case 43:
	switch( (*p) ) {
		case 95: goto tr38;
		case 114: goto st44;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st44:
	if ( ++p == pe )
		goto _out44;
case 44:
	switch( (*p) ) {
		case 95: goto tr38;
		case 101: goto st45;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st45:
	if ( ++p == pe )
		goto _out45;
case 45:
	switch( (*p) ) {
		case 95: goto tr38;
		case 97: goto st46;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st46:
	if ( ++p == pe )
		goto _out46;
case 46:
	switch( (*p) ) {
		case 95: goto tr38;
		case 107: goto tr68;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st47:
	if ( ++p == pe )
		goto _out47;
case 47:
	switch( (*p) ) {
		case 95: goto tr38;
		case 97: goto st48;
		case 117: goto st50;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr37;
st48:
	if ( ++p == pe )
		goto _out48;
case 48:
	switch( (*p) ) {
		case 95: goto tr38;
		case 108: goto st49;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st49:
	if ( ++p == pe )
		goto _out49;
case 49:
	switch( (*p) ) {
		case 95: goto tr38;
		case 108: goto tr67;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st50:
	if ( ++p == pe )
		goto _out50;
case 50:
	switch( (*p) ) {
		case 95: goto tr38;
		case 114: goto st51;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st51:
	if ( ++p == pe )
		goto _out51;
case 51:
	switch( (*p) ) {
		case 95: goto tr38;
		case 115: goto tr64;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st52:
	if ( ++p == pe )
		goto _out52;
case 52:
	switch( (*p) ) {
		case 95: goto tr38;
		case 110: goto st53;
		case 120: goto st56;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st53:
	if ( ++p == pe )
		goto _out53;
case 53:
	switch( (*p) ) {
		case 95: goto tr38;
		case 116: goto st54;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st54:
	if ( ++p == pe )
		goto _out54;
case 54:
	switch( (*p) ) {
		case 95: goto tr38;
		case 114: goto st55;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st55:
	if ( ++p == pe )
		goto _out55;
case 55:
	switch( (*p) ) {
		case 95: goto tr38;
		case 121: goto tr61;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st56:
	if ( ++p == pe )
		goto _out56;
case 56:
	switch( (*p) ) {
		case 95: goto tr38;
		case 101: goto st57;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st57:
	if ( ++p == pe )
		goto _out57;
case 57:
	switch( (*p) ) {
		case 95: goto tr38;
		case 99: goto tr71;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st58:
	if ( ++p == pe )
		goto _out58;
case 58:
	switch( (*p) ) {
		case 95: goto tr38;
		case 111: goto st59;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st59:
	if ( ++p == pe )
		goto _out59;
case 59:
	switch( (*p) ) {
		case 95: goto tr38;
		case 116: goto st60;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st60:
	if ( ++p == pe )
		goto _out60;
case 60:
	switch( (*p) ) {
		case 95: goto tr38;
		case 111: goto tr66;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st61:
	if ( ++p == pe )
		goto _out61;
case 61:
	switch( (*p) ) {
		case 95: goto tr38;
		case 111: goto st62;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st62:
	if ( ++p == pe )
		goto _out62;
case 62:
	switch( (*p) ) {
		case 95: goto tr38;
		case 108: goto st63;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st63:
	if ( ++p == pe )
		goto _out63;
case 63:
	switch( (*p) ) {
		case 95: goto tr38;
		case 100: goto tr69;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st64:
	if ( ++p == pe )
		goto _out64;
case 64:
	switch( (*p) ) {
		case 95: goto tr38;
		case 101: goto st65;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st65:
	if ( ++p == pe )
		goto _out65;
case 65:
	switch( (*p) ) {
		case 95: goto tr38;
		case 120: goto st66;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st66:
	if ( ++p == pe )
		goto _out66;
case 66:
	switch( (*p) ) {
		case 95: goto tr38;
		case 116: goto tr62;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st67:
	if ( ++p == pe )
		goto _out67;
case 67:
	switch( (*p) ) {
		case 95: goto tr38;
		case 99: goto tr70;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st68:
	if ( ++p == pe )
		goto _out68;
case 68:
	switch( (*p) ) {
		case 95: goto tr38;
		case 101: goto st69;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st69:
	if ( ++p == pe )
		goto _out69;
case 69:
	switch( (*p) ) {
		case 95: goto tr38;
		case 116: goto tr63;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st70:
	if ( ++p == pe )
		goto _out70;
case 70:
	switch( (*p) ) {
		case 95: goto tr38;
		case 97: goto st71;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st71:
	if ( ++p == pe )
		goto _out71;
case 71:
	switch( (*p) ) {
		case 95: goto tr38;
		case 114: goto st72;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st72:
	if ( ++p == pe )
		goto _out72;
case 72:
	switch( (*p) ) {
		case 95: goto tr38;
		case 103: goto st73;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
st73:
	if ( ++p == pe )
		goto _out73;
case 73:
	switch( (*p) ) {
		case 95: goto tr38;
		case 115: goto tr65;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr38;
	} else
		goto tr38;
	goto tr41;
tr113:
#line 586 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, tokstart+1, tokend ); }{p = ((tokend))-1;}}
	goto st74;
tr114:
#line 585 "rlscan.rl"
	{tokend = p+1;{ updateCol(); }{p = ((tokend))-1;}}
	goto st74;
tr115:
#line 577 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\0' ); }{p = ((tokend))-1;}}
	goto st74;
tr116:
#line 578 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\a' ); }{p = ((tokend))-1;}}
	goto st74;
tr117:
#line 579 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\b' ); }{p = ((tokend))-1;}}
	goto st74;
tr118:
#line 583 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\f' ); }{p = ((tokend))-1;}}
	goto st74;
tr119:
#line 581 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\n' ); }{p = ((tokend))-1;}}
	goto st74;
tr120:
#line 584 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\r' ); }{p = ((tokend))-1;}}
	goto st74;
tr121:
#line 580 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\t' ); }{p = ((tokend))-1;}}
	goto st74;
tr122:
#line 582 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\v' ); }{p = ((tokend))-1;}}
	goto st74;
tr123:
#line 599 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st74;
tr124:
#line 594 "rlscan.rl"
	{tokend = p+1;{
			scan_error() << "unterminated OR literal" << endl;
		}{p = ((tokend))-1;}}
	goto st74;
tr125:
#line 589 "rlscan.rl"
	{tokend = p+1;{ token( RE_Dash, 0, 0 ); }{p = ((tokend))-1;}}
	goto st74;
tr127:
#line 592 "rlscan.rl"
	{tokend = p+1;{ token( RE_SqClose ); {{p = ((tokend))-1;}{cs = stack[--top]; goto _again;}} }{p = ((tokend))-1;}}
	goto st74;
st74:
#line 1 "rlscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out74;
case 74:
#line 1 "rlscan.rl"
	{tokstart = p;}
#line 2258 "rlscan.cpp"
	switch( (*p) ) {
		case 0: goto tr124;
		case 45: goto tr125;
		case 92: goto st75;
		case 93: goto tr127;
	}
	goto tr123;
st75:
	if ( ++p == pe )
		goto _out75;
case 75:
	switch( (*p) ) {
		case 10: goto tr114;
		case 48: goto tr115;
		case 97: goto tr116;
		case 98: goto tr117;
		case 102: goto tr118;
		case 110: goto tr119;
		case 114: goto tr120;
		case 116: goto tr121;
		case 118: goto tr122;
	}
	goto tr113;
tr128:
#line 617 "rlscan.rl"
	{tokend = p;{ 
			token( RE_Slash, tokstart, tokend ); 
			{{p = ((tokend))-1;}{goto st83;}}
		}{p = ((tokend))-1;}}
	goto st76;
tr129:
#line 617 "rlscan.rl"
	{tokend = p+1;{ 
			token( RE_Slash, tokstart, tokend ); 
			{{p = ((tokend))-1;}{goto st83;}}
		}{p = ((tokend))-1;}}
	goto st76;
tr130:
#line 626 "rlscan.rl"
	{tokend = p;{ token( RE_SqOpen ); {{p = ((tokend))-1;}{stack[top++] = 76; goto st74;}} }{p = ((tokend))-1;}}
	goto st76;
tr131:
#line 627 "rlscan.rl"
	{tokend = p+1;{ token( RE_SqOpenNeg ); {{p = ((tokend))-1;}{stack[top++] = 76; goto st74;}} }{p = ((tokend))-1;}}
	goto st76;
tr132:
#line 614 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, tokstart+1, tokend ); }{p = ((tokend))-1;}}
	goto st76;
tr133:
#line 613 "rlscan.rl"
	{tokend = p+1;{ updateCol(); }{p = ((tokend))-1;}}
	goto st76;
tr134:
#line 605 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\0' ); }{p = ((tokend))-1;}}
	goto st76;
tr135:
#line 606 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\a' ); }{p = ((tokend))-1;}}
	goto st76;
tr136:
#line 607 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\b' ); }{p = ((tokend))-1;}}
	goto st76;
tr137:
#line 611 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\f' ); }{p = ((tokend))-1;}}
	goto st76;
tr138:
#line 609 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\n' ); }{p = ((tokend))-1;}}
	goto st76;
tr139:
#line 612 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\r' ); }{p = ((tokend))-1;}}
	goto st76;
tr140:
#line 608 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\t' ); }{p = ((tokend))-1;}}
	goto st76;
tr141:
#line 610 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, '\v' ); }{p = ((tokend))-1;}}
	goto st76;
tr142:
#line 634 "rlscan.rl"
	{tokend = p+1;{ token( RE_Char, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st76;
tr143:
#line 629 "rlscan.rl"
	{tokend = p+1;{
			scan_error() << "unterminated regular expression" << endl;
		}{p = ((tokend))-1;}}
	goto st76;
tr144:
#line 624 "rlscan.rl"
	{tokend = p+1;{ token( RE_Star ); }{p = ((tokend))-1;}}
	goto st76;
tr145:
#line 623 "rlscan.rl"
	{tokend = p+1;{ token( RE_Dot ); }{p = ((tokend))-1;}}
	goto st76;
st76:
#line 1 "rlscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out76;
case 76:
#line 1 "rlscan.rl"
	{tokstart = p;}
#line 2370 "rlscan.cpp"
	switch( (*p) ) {
		case 0: goto tr143;
		case 42: goto tr144;
		case 46: goto tr145;
		case 47: goto st77;
		case 91: goto st78;
		case 92: goto st79;
	}
	goto tr142;
st77:
	if ( ++p == pe )
		goto _out77;
case 77:
	if ( (*p) == 105 )
		goto tr129;
	goto tr128;
st78:
	if ( ++p == pe )
		goto _out78;
case 78:
	if ( (*p) == 94 )
		goto tr131;
	goto tr130;
st79:
	if ( ++p == pe )
		goto _out79;
case 79:
	switch( (*p) ) {
		case 10: goto tr133;
		case 48: goto tr134;
		case 97: goto tr135;
		case 98: goto tr136;
		case 102: goto tr137;
		case 110: goto tr138;
		case 114: goto tr139;
		case 116: goto tr140;
		case 118: goto tr141;
	}
	goto tr132;
tr149:
#line 639 "rlscan.rl"
	{tokend = p;{ token( TK_Word, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st80;
tr151:
#line 640 "rlscan.rl"
	{tokend = p;{ updateCol(); }{p = ((tokend))-1;}}
	goto st80;
tr153:
#line 643 "rlscan.rl"
	{tokend = p+1;{
			scan_error() << "unterminated write statement" << endl;
		}{p = ((tokend))-1;}}
	goto st80;
tr155:
#line 641 "rlscan.rl"
	{tokend = p+1;{ token( ';' ); {{p = ((tokend))-1;}{goto st83;}} }{p = ((tokend))-1;}}
	goto st80;
st80:
#line 1 "rlscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out80;
case 80:
#line 1 "rlscan.rl"
	{tokstart = p;}
#line 2436 "rlscan.cpp"
	switch( (*p) ) {
		case 0: goto tr153;
		case 32: goto st81;
		case 59: goto tr155;
		case 95: goto st82;
	}
	if ( (*p) < 65 ) {
		if ( 9 <= (*p) && (*p) <= 10 )
			goto st81;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st82;
	} else
		goto st82;
	goto st15;
st15:
	goto _out15;
st81:
	if ( ++p == pe )
		goto _out81;
case 81:
	if ( (*p) == 32 )
		goto st81;
	if ( 9 <= (*p) && (*p) <= 10 )
		goto st81;
	goto tr151;
st82:
	if ( ++p == pe )
		goto _out82;
case 82:
	if ( (*p) == 95 )
		goto st82;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st82;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st82;
	} else
		goto st82;
	goto tr149;
tr164:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
#line 701 "rlscan.rl"
	{tokend = p+1;{ updateCol(); }{p = ((tokend))-1;}}
	goto st83;
tr165:
#line 685 "rlscan.rl"
	{tokend = p;{ token( TK_Word, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st83;
tr206:
#line 688 "rlscan.rl"
	{tokend = p;{ token( TK_UInt, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st83;
tr209:
#line 689 "rlscan.rl"
	{tokend = p;{ token( TK_Hex, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st83;
tr211:
#line 693 "rlscan.rl"
	{tokend = p;{ token( TK_Literal, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st83;
tr212:
#line 693 "rlscan.rl"
	{tokend = p+1;{ token( TK_Literal, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st83;
tr213:
#line 695 "rlscan.rl"
	{tokend = p;{ token( RE_SqOpen ); {{p = ((tokend))-1;}{stack[top++] = 83; goto st74;}} }{p = ((tokend))-1;}}
	goto st83;
tr214:
#line 696 "rlscan.rl"
	{tokend = p+1;{ token( RE_SqOpenNeg ); {{p = ((tokend))-1;}{stack[top++] = 83; goto st74;}} }{p = ((tokend))-1;}}
	goto st83;
tr215:
#line 746 "rlscan.rl"
	{tokend = p;{ token( TK_Middle ); }{p = ((tokend))-1;}}
	goto st83;
tr216:
#line 735 "rlscan.rl"
	{tokend = p+1;{ token( TK_MiddleGblError ); }{p = ((tokend))-1;}}
	goto st83;
tr217:
#line 719 "rlscan.rl"
	{tokend = p+1;{ token( TK_MiddleFromState ); }{p = ((tokend))-1;}}
	goto st83;
tr218:
#line 727 "rlscan.rl"
	{tokend = p+1;{ token( TK_MiddleEOF ); }{p = ((tokend))-1;}}
	goto st83;
tr219:
#line 743 "rlscan.rl"
	{tokend = p+1;{ token( TK_MiddleLocalError ); }{p = ((tokend))-1;}}
	goto st83;
tr220:
#line 711 "rlscan.rl"
	{tokend = p+1;{ token( TK_MiddleToState ); }{p = ((tokend))-1;}}
	goto st83;
tr221:
#line 759 "rlscan.rl"
	{tokend = p;{ token( TK_ColonGt ); }{p = ((tokend))-1;}}
	goto st83;
tr222:
#line 760 "rlscan.rl"
	{tokend = p+1;{ token( TK_ColonGtGt ); }{p = ((tokend))-1;}}
	goto st83;
tr223:
#line 772 "rlscan.rl"
	{tokend = p;{ updateCol(); }{p = ((tokend))-1;}}
	goto st83;
tr225:
#line 794 "rlscan.rl"
	{tokend = p;{ token( *tokstart ); }{p = ((tokend))-1;}}
	goto st83;
tr227:
#line 757 "rlscan.rl"
	{tokend = p+1;{ token( TK_DoubleArrow ); }{p = ((tokend))-1;}}
	goto st83;
tr228:
#line 703 "rlscan.rl"
	{tokend = p+1;{ token( TK_ColonEquals ); }{p = ((tokend))-1;}}
	goto st83;
tr230:
#line 753 "rlscan.rl"
	{tokend = p+1;{ token( TK_DotDot ); }{p = ((tokend))-1;}}
	goto st83;
tr231:
#line 755 "rlscan.rl"
	{tokend = p+1;{ token( TK_DashDash ); }{p = ((tokend))-1;}}
	goto st83;
tr232:
#line 756 "rlscan.rl"
	{tokend = p+1;{ token( TK_Arrow ); }{p = ((tokend))-1;}}
	goto st83;
tr233:
#line 754 "rlscan.rl"
	{tokend = p+1;{ token( TK_StarStar ); }{p = ((tokend))-1;}}
	goto st83;
tr234:
#line 764 "rlscan.rl"
	{tokend = p+1;{ token( TK_BarStar ); }{p = ((tokend))-1;}}
	goto st83;
tr235:
#line 730 "rlscan.rl"
	{tokend = p+1;{ token( TK_StartGblError ); }{p = ((tokend))-1;}}
	goto st83;
tr236:
#line 714 "rlscan.rl"
	{tokend = p+1;{ token( TK_StartFromState ); }{p = ((tokend))-1;}}
	goto st83;
tr237:
#line 722 "rlscan.rl"
	{tokend = p+1;{ token( TK_StartEOF ); }{p = ((tokend))-1;}}
	goto st83;
tr238:
#line 749 "rlscan.rl"
	{tokend = p+1;{ token( TK_StartCond ); }{p = ((tokend))-1;}}
	goto st83;
tr239:
#line 738 "rlscan.rl"
	{tokend = p+1;{ token( TK_StartLocalError ); }{p = ((tokend))-1;}}
	goto st83;
tr240:
#line 706 "rlscan.rl"
	{tokend = p+1;{ token( TK_StartToState ); }{p = ((tokend))-1;}}
	goto st83;
tr241:
#line 731 "rlscan.rl"
	{tokend = p+1;{ token( TK_AllGblError ); }{p = ((tokend))-1;}}
	goto st83;
tr242:
#line 715 "rlscan.rl"
	{tokend = p+1;{ token( TK_AllFromState ); }{p = ((tokend))-1;}}
	goto st83;
tr243:
#line 723 "rlscan.rl"
	{tokend = p+1;{ token( TK_AllEOF ); }{p = ((tokend))-1;}}
	goto st83;
tr244:
#line 750 "rlscan.rl"
	{tokend = p+1;{ token( TK_AllCond ); }{p = ((tokend))-1;}}
	goto st83;
tr245:
#line 739 "rlscan.rl"
	{tokend = p+1;{ token( TK_AllLocalError ); }{p = ((tokend))-1;}}
	goto st83;
tr246:
#line 707 "rlscan.rl"
	{tokend = p+1;{ token( TK_AllToState ); }{p = ((tokend))-1;}}
	goto st83;
tr247:
#line 732 "rlscan.rl"
	{tokend = p+1;{ token( TK_FinalGblError ); }{p = ((tokend))-1;}}
	goto st83;
tr248:
#line 716 "rlscan.rl"
	{tokend = p+1;{ token( TK_FinalFromState ); }{p = ((tokend))-1;}}
	goto st83;
tr249:
#line 724 "rlscan.rl"
	{tokend = p+1;{ token( TK_FinalEOF ); }{p = ((tokend))-1;}}
	goto st83;
tr250:
#line 751 "rlscan.rl"
	{tokend = p+1;{ token( TK_LeavingCond ); }{p = ((tokend))-1;}}
	goto st83;
tr251:
#line 740 "rlscan.rl"
	{tokend = p+1;{ token( TK_FinalLocalError ); }{p = ((tokend))-1;}}
	goto st83;
tr252:
#line 708 "rlscan.rl"
	{tokend = p+1;{ token( TK_FinalToState ); }{p = ((tokend))-1;}}
	goto st83;
tr253:
#line 733 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotStartGblError ); }{p = ((tokend))-1;}}
	goto st83;
tr254:
#line 717 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotStartFromState ); }{p = ((tokend))-1;}}
	goto st83;
tr255:
#line 725 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotStartEOF ); }{p = ((tokend))-1;}}
	goto st83;
tr256:
#line 761 "rlscan.rl"
	{tokend = p+1;{ token( TK_LtColon ); }{p = ((tokend))-1;}}
	goto st83;
tr258:
#line 741 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotStartLocalError ); }{p = ((tokend))-1;}}
	goto st83;
tr259:
#line 709 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotStartToState ); }{p = ((tokend))-1;}}
	goto st83;
tr260:
#line 734 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotFinalGblError ); }{p = ((tokend))-1;}}
	goto st83;
tr261:
#line 718 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotFinalFromState ); }{p = ((tokend))-1;}}
	goto st83;
tr262:
#line 726 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotFinalEOF ); }{p = ((tokend))-1;}}
	goto st83;
tr263:
#line 742 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotFinalLocalError ); }{p = ((tokend))-1;}}
	goto st83;
tr264:
#line 710 "rlscan.rl"
	{tokend = p+1;{ token( TK_NotFinalToState ); }{p = ((tokend))-1;}}
	goto st83;
tr265:
#line 1 "rlscan.rl"
	{	switch( act ) {
	case 62:
	{ token( KW_Machine ); }
	break;
	case 63:
	{ token( KW_Include ); }
	break;
	case 64:
	{ 
			token( KW_Write );
			{{p = ((tokend))-1;}{goto st80;}}
		}
	break;
	case 65:
	{ token( KW_Action ); }
	break;
	case 66:
	{ token( KW_AlphType ); }
	break;
	case 67:
	{ 
			token( KW_GetKey );
			inlineBlockType = SemiTerminated;
			{{p = ((tokend))-1;}{goto st32;}}
		}
	break;
	case 68:
	{ 
			token( KW_Access );
			inlineBlockType = SemiTerminated;
			{{p = ((tokend))-1;}{goto st32;}}
		}
	break;
	case 69:
	{ 
			token( KW_Variable );
			inlineBlockType = SemiTerminated;
			{{p = ((tokend))-1;}{goto st32;}}
		}
	break;
	case 70:
	{ token( KW_When ); }
	break;
	case 71:
	{ token( KW_Eof ); }
	break;
	case 72:
	{ token( KW_Err ); }
	break;
	case 73:
	{ token( KW_Lerr ); }
	break;
	case 74:
	{ token( KW_To ); }
	break;
	case 75:
	{ token( KW_From ); }
	break;
	case 76:
	{ token( TK_Word, tokstart, tokend ); }
	break;
	default: break;
	}
	{p = ((tokend))-1;}}
	goto st83;
tr266:
#line 794 "rlscan.rl"
	{tokend = p+1;{ token( *tokstart ); }{p = ((tokend))-1;}}
	goto st83;
tr267:
#line 790 "rlscan.rl"
	{tokend = p+1;{
			scan_error() << "unterminated ragel section" << endl;
		}{p = ((tokend))-1;}}
	goto st83;
tr268:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
#line 775 "rlscan.rl"
	{tokend = p+1;{
			updateCol();
			if ( singleLineSpec ) {
				endSection();
				{{p = ((tokend))-1;}{goto st23;}}
			}
		}{p = ((tokend))-1;}}
	goto st83;
tr277:
#line 698 "rlscan.rl"
	{tokend = p+1;{ token( RE_Slash ); {{p = ((tokend))-1;}{goto st76;}} }{p = ((tokend))-1;}}
	goto st83;
tr295:
#line 783 "rlscan.rl"
	{tokend = p+1;{ 
			token( '{' );
			curly_count = 1; 
			inlineBlockType = CurlyDelimited;
			{{p = ((tokend))-1;}{goto st32;}}
		}{p = ((tokend))-1;}}
	goto st83;
tr298:
#line 688 "rlscan.rl"
	{{ token( TK_UInt, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st83;
tr299:
#line 794 "rlscan.rl"
	{{ token( *tokstart ); }{p = ((tokend))-1;}}
	goto st83;
tr300:
#line 766 "rlscan.rl"
	{tokend = p+1;{ 
			updateCol();
			endSection();
			{{p = ((tokend))-1;}{goto st23;}}
		}{p = ((tokend))-1;}}
	goto st83;
st83:
#line 1 "rlscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out83;
case 83:
#line 1 "rlscan.rl"
	{tokstart = p;}
#line 2830 "rlscan.cpp"
	switch( (*p) ) {
		case 0: goto tr267;
		case 9: goto st84;
		case 10: goto tr268;
		case 32: goto st84;
		case 34: goto tr269;
		case 35: goto tr270;
		case 36: goto st88;
		case 37: goto st89;
		case 39: goto tr273;
		case 42: goto st91;
		case 45: goto st92;
		case 46: goto st93;
		case 47: goto tr277;
		case 48: goto tr278;
		case 58: goto st97;
		case 60: goto st99;
		case 61: goto st101;
		case 62: goto st102;
		case 64: goto st103;
		case 91: goto st105;
		case 95: goto tr166;
		case 97: goto st106;
		case 101: goto st120;
		case 102: goto st123;
		case 103: goto st126;
		case 105: goto st131;
		case 108: goto st137;
		case 109: goto st140;
		case 116: goto st146;
		case 118: goto st147;
		case 119: goto st154;
		case 123: goto tr295;
		case 124: goto st160;
		case 125: goto tr297;
	}
	if ( (*p) < 65 ) {
		if ( 49 <= (*p) && (*p) <= 57 )
			goto st95;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr266;
st84:
	if ( ++p == pe )
		goto _out84;
case 84:
	switch( (*p) ) {
		case 9: goto st84;
		case 32: goto st84;
	}
	goto tr223;
tr269:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st85;
st85:
	if ( ++p == pe )
		goto _out85;
case 85:
#line 2893 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr161;
		case 34: goto st86;
		case 92: goto st17;
	}
	goto st16;
tr161:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st16;
st16:
	if ( ++p == pe )
		goto _out16;
case 16:
#line 2912 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr161;
		case 34: goto st86;
		case 92: goto st17;
	}
	goto st16;
st86:
	if ( ++p == pe )
		goto _out86;
case 86:
	if ( (*p) == 105 )
		goto tr212;
	goto tr211;
st17:
	if ( ++p == pe )
		goto _out17;
case 17:
	if ( (*p) == 10 )
		goto tr161;
	goto st16;
tr270:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st87;
st87:
	if ( ++p == pe )
		goto _out87;
case 87:
#line 2941 "rlscan.cpp"
	if ( (*p) == 10 )
		goto tr164;
	goto st18;
st18:
	if ( ++p == pe )
		goto _out18;
case 18:
	if ( (*p) == 10 )
		goto tr164;
	goto st18;
st88:
	if ( ++p == pe )
		goto _out88;
case 88:
	switch( (*p) ) {
		case 33: goto tr241;
		case 42: goto tr242;
		case 47: goto tr243;
		case 63: goto tr244;
		case 94: goto tr245;
		case 126: goto tr246;
	}
	goto tr225;
st89:
	if ( ++p == pe )
		goto _out89;
case 89:
	switch( (*p) ) {
		case 33: goto tr247;
		case 42: goto tr248;
		case 47: goto tr249;
		case 63: goto tr250;
		case 94: goto tr251;
		case 126: goto tr252;
	}
	goto tr225;
tr273:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st90;
st90:
	if ( ++p == pe )
		goto _out90;
case 90:
#line 2986 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr157;
		case 39: goto st86;
		case 92: goto st20;
	}
	goto st19;
tr157:
#line 445 "rlscan.rl"
	{ 
		lastnl = p; 
		column = 0;
		line++;
	}
	goto st19;
st19:
	if ( ++p == pe )
		goto _out19;
case 19:
#line 3005 "rlscan.cpp"
	switch( (*p) ) {
		case 10: goto tr157;
		case 39: goto st86;
		case 92: goto st20;
	}
	goto st19;
st20:
	if ( ++p == pe )
		goto _out20;
case 20:
	if ( (*p) == 10 )
		goto tr157;
	goto st19;
st91:
	if ( ++p == pe )
		goto _out91;
case 91:
	if ( (*p) == 42 )
		goto tr233;
	goto tr225;
st92:
	if ( ++p == pe )
		goto _out92;
case 92:
	switch( (*p) ) {
		case 45: goto tr231;
		case 62: goto tr232;
	}
	goto tr225;
st93:
	if ( ++p == pe )
		goto _out93;
case 93:
	if ( (*p) == 46 )
		goto tr230;
	goto tr225;
tr278:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st94;
st94:
	if ( ++p == pe )
		goto _out94;
case 94:
#line 3050 "rlscan.cpp"
	if ( (*p) == 120 )
		goto st21;
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st95;
	goto tr206;
st95:
	if ( ++p == pe )
		goto _out95;
case 95:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st95;
	goto tr206;
st21:
	if ( ++p == pe )
		goto _out21;
case 21:
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st96;
	} else if ( (*p) > 70 ) {
		if ( 97 <= (*p) && (*p) <= 102 )
			goto st96;
	} else
		goto st96;
	goto tr298;
st96:
	if ( ++p == pe )
		goto _out96;
case 96:
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st96;
	} else if ( (*p) > 70 ) {
		if ( 97 <= (*p) && (*p) <= 102 )
			goto st96;
	} else
		goto st96;
	goto tr209;
st97:
	if ( ++p == pe )
		goto _out97;
case 97:
	switch( (*p) ) {
		case 61: goto tr228;
		case 62: goto st98;
	}
	goto tr225;
st98:
	if ( ++p == pe )
		goto _out98;
case 98:
	if ( (*p) == 62 )
		goto tr222;
	goto tr221;
st99:
	if ( ++p == pe )
		goto _out99;
case 99:
	switch( (*p) ) {
		case 33: goto tr253;
		case 42: goto tr254;
		case 47: goto tr255;
		case 58: goto tr256;
		case 62: goto st100;
		case 94: goto tr258;
		case 126: goto tr259;
	}
	goto tr225;
st100:
	if ( ++p == pe )
		goto _out100;
case 100:
	switch( (*p) ) {
		case 33: goto tr216;
		case 42: goto tr217;
		case 47: goto tr218;
		case 94: goto tr219;
		case 126: goto tr220;
	}
	goto tr215;
st101:
	if ( ++p == pe )
		goto _out101;
case 101:
	if ( (*p) == 62 )
		goto tr227;
	goto tr225;
st102:
	if ( ++p == pe )
		goto _out102;
case 102:
	switch( (*p) ) {
		case 33: goto tr235;
		case 42: goto tr236;
		case 47: goto tr237;
		case 63: goto tr238;
		case 94: goto tr239;
		case 126: goto tr240;
	}
	goto tr225;
st103:
	if ( ++p == pe )
		goto _out103;
case 103:
	switch( (*p) ) {
		case 33: goto tr260;
		case 42: goto tr261;
		case 47: goto tr262;
		case 94: goto tr263;
		case 126: goto tr264;
	}
	goto tr225;
tr166:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 685 "rlscan.rl"
	{act = 76;}
	goto st104;
tr192:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 662 "rlscan.rl"
	{act = 67;}
	goto st104;
tr193:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 667 "rlscan.rl"
	{act = 68;}
	goto st104;
tr194:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 679 "rlscan.rl"
	{act = 72;}
	goto st104;
tr195:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 680 "rlscan.rl"
	{act = 73;}
	goto st104;
tr196:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 681 "rlscan.rl"
	{act = 74;}
	goto st104;
tr197:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 656 "rlscan.rl"
	{act = 65;}
	goto st104;
tr198:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 677 "rlscan.rl"
	{act = 70;}
	goto st104;
tr199:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 682 "rlscan.rl"
	{act = 75;}
	goto st104;
tr200:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 678 "rlscan.rl"
	{act = 71;}
	goto st104;
tr201:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 650 "rlscan.rl"
	{act = 62;}
	goto st104;
tr202:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 651 "rlscan.rl"
	{act = 63;}
	goto st104;
tr203:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 652 "rlscan.rl"
	{act = 64;}
	goto st104;
tr204:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 657 "rlscan.rl"
	{act = 66;}
	goto st104;
tr205:
#line 1 "rlscan.rl"
	{tokend = p+1;}
#line 672 "rlscan.rl"
	{act = 69;}
	goto st104;
st104:
	if ( ++p == pe )
		goto _out104;
case 104:
#line 3257 "rlscan.cpp"
	if ( (*p) == 95 )
		goto tr166;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr265;
st105:
	if ( ++p == pe )
		goto _out105;
case 105:
	if ( (*p) == 94 )
		goto tr214;
	goto tr213;
st106:
	if ( ++p == pe )
		goto _out106;
case 106:
	switch( (*p) ) {
		case 95: goto tr166;
		case 99: goto st107;
		case 108: goto st114;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st107:
	if ( ++p == pe )
		goto _out107;
case 107:
	switch( (*p) ) {
		case 95: goto tr166;
		case 99: goto st108;
		case 116: goto st111;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st108:
	if ( ++p == pe )
		goto _out108;
case 108:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto st109;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st109:
	if ( ++p == pe )
		goto _out109;
case 109:
	switch( (*p) ) {
		case 95: goto tr166;
		case 115: goto st110;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st110:
	if ( ++p == pe )
		goto _out110;
case 110:
	switch( (*p) ) {
		case 95: goto tr166;
		case 115: goto tr193;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st111:
	if ( ++p == pe )
		goto _out111;
case 111:
	switch( (*p) ) {
		case 95: goto tr166;
		case 105: goto st112;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st112:
	if ( ++p == pe )
		goto _out112;
case 112:
	switch( (*p) ) {
		case 95: goto tr166;
		case 111: goto st113;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st113:
	if ( ++p == pe )
		goto _out113;
case 113:
	switch( (*p) ) {
		case 95: goto tr166;
		case 110: goto tr197;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st114:
	if ( ++p == pe )
		goto _out114;
case 114:
	switch( (*p) ) {
		case 95: goto tr166;
		case 112: goto st115;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st115:
	if ( ++p == pe )
		goto _out115;
case 115:
	switch( (*p) ) {
		case 95: goto tr166;
		case 104: goto st116;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st116:
	if ( ++p == pe )
		goto _out116;
case 116:
	switch( (*p) ) {
		case 95: goto tr166;
		case 116: goto st117;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st117:
	if ( ++p == pe )
		goto _out117;
case 117:
	switch( (*p) ) {
		case 95: goto tr166;
		case 121: goto st118;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st118:
	if ( ++p == pe )
		goto _out118;
case 118:
	switch( (*p) ) {
		case 95: goto tr166;
		case 112: goto st119;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st119:
	if ( ++p == pe )
		goto _out119;
case 119:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto tr204;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st120:
	if ( ++p == pe )
		goto _out120;
case 120:
	switch( (*p) ) {
		case 95: goto tr166;
		case 111: goto st121;
		case 114: goto st122;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st121:
	if ( ++p == pe )
		goto _out121;
case 121:
	switch( (*p) ) {
		case 95: goto tr166;
		case 102: goto tr200;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st122:
	if ( ++p == pe )
		goto _out122;
case 122:
	switch( (*p) ) {
		case 95: goto tr166;
		case 114: goto tr194;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st123:
	if ( ++p == pe )
		goto _out123;
case 123:
	switch( (*p) ) {
		case 95: goto tr166;
		case 114: goto st124;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st124:
	if ( ++p == pe )
		goto _out124;
case 124:
	switch( (*p) ) {
		case 95: goto tr166;
		case 111: goto st125;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st125:
	if ( ++p == pe )
		goto _out125;
case 125:
	switch( (*p) ) {
		case 95: goto tr166;
		case 109: goto tr199;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st126:
	if ( ++p == pe )
		goto _out126;
case 126:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto st127;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st127:
	if ( ++p == pe )
		goto _out127;
case 127:
	switch( (*p) ) {
		case 95: goto tr166;
		case 116: goto st128;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st128:
	if ( ++p == pe )
		goto _out128;
case 128:
	switch( (*p) ) {
		case 95: goto tr166;
		case 107: goto st129;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st129:
	if ( ++p == pe )
		goto _out129;
case 129:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto st130;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st130:
	if ( ++p == pe )
		goto _out130;
case 130:
	switch( (*p) ) {
		case 95: goto tr166;
		case 121: goto tr192;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st131:
	if ( ++p == pe )
		goto _out131;
case 131:
	switch( (*p) ) {
		case 95: goto tr166;
		case 110: goto st132;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st132:
	if ( ++p == pe )
		goto _out132;
case 132:
	switch( (*p) ) {
		case 95: goto tr166;
		case 99: goto st133;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st133:
	if ( ++p == pe )
		goto _out133;
case 133:
	switch( (*p) ) {
		case 95: goto tr166;
		case 108: goto st134;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st134:
	if ( ++p == pe )
		goto _out134;
case 134:
	switch( (*p) ) {
		case 95: goto tr166;
		case 117: goto st135;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st135:
	if ( ++p == pe )
		goto _out135;
case 135:
	switch( (*p) ) {
		case 95: goto tr166;
		case 100: goto st136;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st136:
	if ( ++p == pe )
		goto _out136;
case 136:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto tr202;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st137:
	if ( ++p == pe )
		goto _out137;
case 137:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto st138;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st138:
	if ( ++p == pe )
		goto _out138;
case 138:
	switch( (*p) ) {
		case 95: goto tr166;
		case 114: goto st139;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st139:
	if ( ++p == pe )
		goto _out139;
case 139:
	switch( (*p) ) {
		case 95: goto tr166;
		case 114: goto tr195;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st140:
	if ( ++p == pe )
		goto _out140;
case 140:
	switch( (*p) ) {
		case 95: goto tr166;
		case 97: goto st141;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st141:
	if ( ++p == pe )
		goto _out141;
case 141:
	switch( (*p) ) {
		case 95: goto tr166;
		case 99: goto st142;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st142:
	if ( ++p == pe )
		goto _out142;
case 142:
	switch( (*p) ) {
		case 95: goto tr166;
		case 104: goto st143;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st143:
	if ( ++p == pe )
		goto _out143;
case 143:
	switch( (*p) ) {
		case 95: goto tr166;
		case 105: goto st144;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st144:
	if ( ++p == pe )
		goto _out144;
case 144:
	switch( (*p) ) {
		case 95: goto tr166;
		case 110: goto st145;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st145:
	if ( ++p == pe )
		goto _out145;
case 145:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto tr201;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st146:
	if ( ++p == pe )
		goto _out146;
case 146:
	switch( (*p) ) {
		case 95: goto tr166;
		case 111: goto tr196;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st147:
	if ( ++p == pe )
		goto _out147;
case 147:
	switch( (*p) ) {
		case 95: goto tr166;
		case 97: goto st148;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st148:
	if ( ++p == pe )
		goto _out148;
case 148:
	switch( (*p) ) {
		case 95: goto tr166;
		case 114: goto st149;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st149:
	if ( ++p == pe )
		goto _out149;
case 149:
	switch( (*p) ) {
		case 95: goto tr166;
		case 105: goto st150;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st150:
	if ( ++p == pe )
		goto _out150;
case 150:
	switch( (*p) ) {
		case 95: goto tr166;
		case 97: goto st151;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st151:
	if ( ++p == pe )
		goto _out151;
case 151:
	switch( (*p) ) {
		case 95: goto tr166;
		case 98: goto st152;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st152:
	if ( ++p == pe )
		goto _out152;
case 152:
	switch( (*p) ) {
		case 95: goto tr166;
		case 108: goto st153;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st153:
	if ( ++p == pe )
		goto _out153;
case 153:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto tr205;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st154:
	if ( ++p == pe )
		goto _out154;
case 154:
	switch( (*p) ) {
		case 95: goto tr166;
		case 104: goto st155;
		case 114: goto st157;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st155:
	if ( ++p == pe )
		goto _out155;
case 155:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto st156;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st156:
	if ( ++p == pe )
		goto _out156;
case 156:
	switch( (*p) ) {
		case 95: goto tr166;
		case 110: goto tr198;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st157:
	if ( ++p == pe )
		goto _out157;
case 157:
	switch( (*p) ) {
		case 95: goto tr166;
		case 105: goto st158;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st158:
	if ( ++p == pe )
		goto _out158;
case 158:
	switch( (*p) ) {
		case 95: goto tr166;
		case 116: goto st159;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st159:
	if ( ++p == pe )
		goto _out159;
case 159:
	switch( (*p) ) {
		case 95: goto tr166;
		case 101: goto tr203;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr166;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr166;
	} else
		goto tr166;
	goto tr165;
st160:
	if ( ++p == pe )
		goto _out160;
case 160:
	if ( (*p) == 42 )
		goto tr234;
	goto tr225;
tr297:
#line 1 "rlscan.rl"
	{tokend = p+1;}
	goto st161;
st161:
	if ( ++p == pe )
		goto _out161;
case 161:
#line 4213 "rlscan.cpp"
	if ( (*p) == 37 )
		goto st22;
	goto tr225;
st22:
	if ( ++p == pe )
		goto _out22;
case 22:
	if ( (*p) == 37 )
		goto tr300;
	goto tr299;
	}
	_out23: cs = 23; goto _out; 
	_out24: cs = 24; goto _out; 
	_out25: cs = 25; goto _out; 
	_out0: cs = 0; goto _out; 
	_out1: cs = 1; goto _out; 
	_out26: cs = 26; goto _out; 
	_out27: cs = 27; goto _out; 
	_out28: cs = 28; goto _out; 
	_out2: cs = 2; goto _out; 
	_out3: cs = 3; goto _out; 
	_out29: cs = 29; goto _out; 
	_out4: cs = 4; goto _out; 
	_out5: cs = 5; goto _out; 
	_out6: cs = 6; goto _out; 
	_out30: cs = 30; goto _out; 
	_out31: cs = 31; goto _out; 
	_out32: cs = 32; goto _out; 
	_out33: cs = 33; goto _out; 
	_out34: cs = 34; goto _out; 
	_out7: cs = 7; goto _out; 
	_out8: cs = 8; goto _out; 
	_out35: cs = 35; goto _out; 
	_out9: cs = 9; goto _out; 
	_out10: cs = 10; goto _out; 
	_out36: cs = 36; goto _out; 
	_out11: cs = 11; goto _out; 
	_out12: cs = 12; goto _out; 
	_out13: cs = 13; goto _out; 
	_out37: cs = 37; goto _out; 
	_out38: cs = 38; goto _out; 
	_out14: cs = 14; goto _out; 
	_out39: cs = 39; goto _out; 
	_out40: cs = 40; goto _out; 
	_out41: cs = 41; goto _out; 
	_out42: cs = 42; goto _out; 
	_out43: cs = 43; goto _out; 
	_out44: cs = 44; goto _out; 
	_out45: cs = 45; goto _out; 
	_out46: cs = 46; goto _out; 
	_out47: cs = 47; goto _out; 
	_out48: cs = 48; goto _out; 
	_out49: cs = 49; goto _out; 
	_out50: cs = 50; goto _out; 
	_out51: cs = 51; goto _out; 
	_out52: cs = 52; goto _out; 
	_out53: cs = 53; goto _out; 
	_out54: cs = 54; goto _out; 
	_out55: cs = 55; goto _out; 
	_out56: cs = 56; goto _out; 
	_out57: cs = 57; goto _out; 
	_out58: cs = 58; goto _out; 
	_out59: cs = 59; goto _out; 
	_out60: cs = 60; goto _out; 
	_out61: cs = 61; goto _out; 
	_out62: cs = 62; goto _out; 
	_out63: cs = 63; goto _out; 
	_out64: cs = 64; goto _out; 
	_out65: cs = 65; goto _out; 
	_out66: cs = 66; goto _out; 
	_out67: cs = 67; goto _out; 
	_out68: cs = 68; goto _out; 
	_out69: cs = 69; goto _out; 
	_out70: cs = 70; goto _out; 
	_out71: cs = 71; goto _out; 
	_out72: cs = 72; goto _out; 
	_out73: cs = 73; goto _out; 
	_out74: cs = 74; goto _out; 
	_out75: cs = 75; goto _out; 
	_out76: cs = 76; goto _out; 
	_out77: cs = 77; goto _out; 
	_out78: cs = 78; goto _out; 
	_out79: cs = 79; goto _out; 
	_out80: cs = 80; goto _out; 
	_out15: cs = 15; goto _out; 
	_out81: cs = 81; goto _out; 
	_out82: cs = 82; goto _out; 
	_out83: cs = 83; goto _out; 
	_out84: cs = 84; goto _out; 
	_out85: cs = 85; goto _out; 
	_out16: cs = 16; goto _out; 
	_out86: cs = 86; goto _out; 
	_out17: cs = 17; goto _out; 
	_out87: cs = 87; goto _out; 
	_out18: cs = 18; goto _out; 
	_out88: cs = 88; goto _out; 
	_out89: cs = 89; goto _out; 
	_out90: cs = 90; goto _out; 
	_out19: cs = 19; goto _out; 
	_out20: cs = 20; goto _out; 
	_out91: cs = 91; goto _out; 
	_out92: cs = 92; goto _out; 
	_out93: cs = 93; goto _out; 
	_out94: cs = 94; goto _out; 
	_out95: cs = 95; goto _out; 
	_out21: cs = 21; goto _out; 
	_out96: cs = 96; goto _out; 
	_out97: cs = 97; goto _out; 
	_out98: cs = 98; goto _out; 
	_out99: cs = 99; goto _out; 
	_out100: cs = 100; goto _out; 
	_out101: cs = 101; goto _out; 
	_out102: cs = 102; goto _out; 
	_out103: cs = 103; goto _out; 
	_out104: cs = 104; goto _out; 
	_out105: cs = 105; goto _out; 
	_out106: cs = 106; goto _out; 
	_out107: cs = 107; goto _out; 
	_out108: cs = 108; goto _out; 
	_out109: cs = 109; goto _out; 
	_out110: cs = 110; goto _out; 
	_out111: cs = 111; goto _out; 
	_out112: cs = 112; goto _out; 
	_out113: cs = 113; goto _out; 
	_out114: cs = 114; goto _out; 
	_out115: cs = 115; goto _out; 
	_out116: cs = 116; goto _out; 
	_out117: cs = 117; goto _out; 
	_out118: cs = 118; goto _out; 
	_out119: cs = 119; goto _out; 
	_out120: cs = 120; goto _out; 
	_out121: cs = 121; goto _out; 
	_out122: cs = 122; goto _out; 
	_out123: cs = 123; goto _out; 
	_out124: cs = 124; goto _out; 
	_out125: cs = 125; goto _out; 
	_out126: cs = 126; goto _out; 
	_out127: cs = 127; goto _out; 
	_out128: cs = 128; goto _out; 
	_out129: cs = 129; goto _out; 
	_out130: cs = 130; goto _out; 
	_out131: cs = 131; goto _out; 
	_out132: cs = 132; goto _out; 
	_out133: cs = 133; goto _out; 
	_out134: cs = 134; goto _out; 
	_out135: cs = 135; goto _out; 
	_out136: cs = 136; goto _out; 
	_out137: cs = 137; goto _out; 
	_out138: cs = 138; goto _out; 
	_out139: cs = 139; goto _out; 
	_out140: cs = 140; goto _out; 
	_out141: cs = 141; goto _out; 
	_out142: cs = 142; goto _out; 
	_out143: cs = 143; goto _out; 
	_out144: cs = 144; goto _out; 
	_out145: cs = 145; goto _out; 
	_out146: cs = 146; goto _out; 
	_out147: cs = 147; goto _out; 
	_out148: cs = 148; goto _out; 
	_out149: cs = 149; goto _out; 
	_out150: cs = 150; goto _out; 
	_out151: cs = 151; goto _out; 
	_out152: cs = 152; goto _out; 
	_out153: cs = 153; goto _out; 
	_out154: cs = 154; goto _out; 
	_out155: cs = 155; goto _out; 
	_out156: cs = 156; goto _out; 
	_out157: cs = 157; goto _out; 
	_out158: cs = 158; goto _out; 
	_out159: cs = 159; goto _out; 
	_out160: cs = 160; goto _out; 
	_out161: cs = 161; goto _out; 
	_out22: cs = 22; goto _out; 

	_out: {}
	}
#line 882 "rlscan.rl"

		/* Check if we failed. */
		if ( cs == rlscan_error ) {
			/* Machine failed before finding a token. I'm not yet sure if this
			 * is reachable. */
			scan_error() << "scanner error" << endl;
			exit(1);
		}

		/* Decide if we need to preserve anything. */
		char *preserve = tokstart;

		/* Now set up the prefix. */
		if ( preserve == 0 )
			have = 0;
		else {
			/* There is data that needs to be shifted over. */
			have = pe - preserve;
			memmove( buf, preserve, have );
			unsigned int shiftback = preserve - buf;
			if ( tokstart != 0 )
				tokstart -= shiftback;
			tokend -= shiftback;

			preserve = buf;
		}
	}

	delete[] buf;
}

void scan( char *fileName, istream &input, ostream &output )
{
	Scanner scanner( fileName, input, output, 0, 0, 0 );
	scanner.init();
	scanner.do_scan();

	InputLoc eofLoc;
	eofLoc.fileName = fileName;
	eofLoc.col = 1;
	eofLoc.line = scanner.line;
}

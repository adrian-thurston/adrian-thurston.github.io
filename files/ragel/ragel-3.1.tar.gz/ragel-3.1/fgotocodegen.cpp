/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "fgotocodegen.h"
#include "redfsm.h"
#include "parsetree.h"
#include "bstmap.h"


/* Init base data. */
FGotoCodeGen::FGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
: 
	GotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &FGotoCodeGen::EXEC_ACTIONS()
{
	/* Loop the actions. */
	for ( ActionTableMap::Iter act = redFsm->actionMap; act.lte(); act++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "f" << act->id << ":\n";

		/* Loop the items in the list of action items. */
		for ( ActionTable::Iter item = act->key; item.lte(); item++ ) {
			/* Get the action data. */
			Action *action = parseData->actionIndex[item->value];

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "#line " << action->loc.line << " \""; LDIR_PATH(inputFile) << "\"\n";

			/* Wrap the block in brakets. */
			out << "\t{"; ACTION(action, 0) << "}\n";
		}

		out << "\tgoto again;\n";
	}
	return out;
}

std::ostream &FGotoCodeGen::FINISH_CASES()
{
	for ( RedStateList::Iter st = redFsm->firstFinState; st.lte(); st++ ) {
		if ( st->outAction != 0 ) {
			/* Write the case label. */
			out << "\t\tcase " << st->id << ": ";

			/* Jump to the func. */
			out << "goto f" << st->outAction->id << ";\n";
		}
	}

	return out;
}

/* Init base data. */
CFGotoCodeGen::CFGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &CFGotoCodeGen::CALL( NameInst *name, int targState )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	out << "{fsm->_st[fsm->_top++] = _cs; _cs = " << 
			targ->value->id << "; goto again;}";
	return out;
}

std::ostream &CFGotoCodeGen::RET()
{
	out << "{_cs = fsm->_st[--fsm->_top]; goto again;}";
	return out;
}

void CFGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() )
		out << "	fsm->_top = 0;\n";
	
	INIT_CODE() <<
		"	if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	int _len = dlen+1;\n"
		"	int _cs = fsm->_cs;\n"
		"\n";
	
	if ( anyOutActions() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out << 
		"again:\n"
		"	_p++, _len--;\n"
		"	if ( _cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( _len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS( false ) <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyActions() )
		EXEC_ACTIONS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyOutActions() ) {
		out <<
			"finishInput:\n"
			"	_len = 1;\n"
			"	switch( _cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"	if ( _cs == 0 )\n"
			"		goto out_err;\n"
			"\n";
	}

	out << 
		"out_ok:\n"
		"	fsm->_cs = _cs;\n"
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	fsm->_cs = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyOutActions() ) {
		/* Call into execute to invoke out actions. */
		out << "	return "; FSM_NAME() << "_execute( fsm, 0, -1 );\n";
	}
	else {
		out << 
			"	if ( fsm->_cs == 0 )\n"
			"		return -1;\n"
			"	if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out << 
		"}\n"
		"\n";
}

/* Init base data. */
CCFGotoCodeGen::CCFGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &CCFGotoCodeGen::CALL( NameInst *name, int targState )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	out << "{this->_st[this->_top++] = _cs; _cs = " << 
			targ->value->id << "; goto again;}";
	return out;
}

std::ostream &CCFGotoCodeGen::RET()
{
	out << "{_cs = this->_st[--this->_top]; goto again;}";
	return out;
}

void CCFGotoCodeGen::writeOutHeader()
{
	out << 
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Init the fsm. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() )
		out << "	this->_top = 0;\n";

	INIT_CODE() <<
		"	if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	int _len = dlen+1;\n"
		"	int _cs = this->_cs;\n"
		"\n";

	if ( anyOutActions() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out << 
		"again:\n"
		"	_p++, _len--;\n"
		"	if ( _cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( _len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS( false ) <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyActions() )
		EXEC_ACTIONS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyOutActions() ) {
		out <<
			"finishInput:\n"
			"	_len = 1;\n"
			"	switch( _cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"	if ( _cs == 0 )\n"
			"		goto out_err;\n"
			"\n";
	}

	out <<
		"out_ok:\n"
		"	this->_cs = _cs;\n"
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	this->_cs = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";

	if ( anyOutActions() ) {
		/* May need to execute action code. Call into exectue to handle the
		 * finishing code. */
		out << "	return execute( 0, -1 );\n";
	}
	else {
		out << 
			"	if ( this->_cs == 0 )\n"
			"		return -1;\n"
			"	if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out <<
		"}\n"
		"\n";
}

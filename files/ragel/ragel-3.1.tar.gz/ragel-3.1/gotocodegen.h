/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _GOTOCODEGEN_H
#define _GOTOCODEGEN_H

#include <iostream>
#include "fsmcodegen.h"

/* Forwards. */
struct ParseData;
struct NameInst;
struct RedTransAp;
struct RedStateAp;

/*
 * Goto driven fsm.
 */
class GotoCodeGen : public FsmCodeGen
{
public:
	GotoCodeGen( char *fsmName, ParseData *parseData, 
			RedFsmAp *redFsm, std::ostream &out );

	std::ostream &FIRST_FINAL_STATE();
	std::ostream &ACTION_SWITCH();
	std::ostream &STATE_GOTOS( bool wantAdvance );
	std::ostream &TRANSITIONS();
	std::ostream &EXEC_FUNCS();
	std::ostream &EXIT_STATES();
	std::ostream &FINISH_CASES();
	std::ostream &STACK( int size );
	virtual std::ostream &TRANS_GOTO( RedTransAp *trans, int level );
	std::ostream &GOTO( NameInst *name );

	void emitSingleSwitch( RedStateAp *state, bool wantAdvance );
	void emitRangeBSearch( RedStateAp *state, int level, int low, int high );

	/* Called from STATE_GOTOS just before writing the gotos for each state. */
	virtual void aboveStateGotos( RedStateAp *state ) { }

	/* Set up labelNeeded flag for each state. */
	void setLabelsNeeded();
};

/*
 * class CGotoCodeGen
 */
class CGotoCodeGen : public GotoCodeGen
{
public:
	CGotoCodeGen( char *fsmName, ParseData *parseData, 
			RedFsmAp *redFsm, std::ostream &out );

	std::ostream &CALL( NameInst *name, int targState );
	std::ostream &RET();

	virtual void writeOutHeader();
	virtual void writeOutCode();
};

/*
 * class CCGotoCodeGen
 */
class CCGotoCodeGen : public GotoCodeGen
{
public:
	CCGotoCodeGen( char *fsmName, ParseData *parseData, 
			RedFsmAp *redFsm, std::ostream &out );

	std::ostream &CALL( NameInst *name, int targState );
	std::ostream &RET();

	virtual void writeOutHeader();
	virtual void writeOutCode();
};


#endif /* _GOTOCODEGEN_H */

#define VERSION "6.7"
#define PUBDATE "May 2011"

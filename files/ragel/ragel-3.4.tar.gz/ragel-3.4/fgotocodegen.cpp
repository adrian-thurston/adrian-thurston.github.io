/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "fgotocodegen.h"
#include "redfsm.h"
#include "parsetree.h"
#include "bstmap.h"


/* Init base data. */
FGotoCodeGen::FGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
: 
	GotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &FGotoCodeGen::EXEC_ACTIONS()
{
	/* Loop the actions. */
	for ( ActionTableMap::Iter act = redFsm->actionMap; act.lte(); act++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "f" << act->id << ":\n";

		/* Loop the items in the list of action items. */
		for ( ActionTable::Iter item = act->key; item.lte(); item++ ) {
			/* Get the action data. */
			Action *action = parseData->actionIndex[item->value];

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "#line " << action->loc.line << " \""; LDIR_PATH(inputFile) << "\"\n";

			/* Wrap the block in brakets. */
			out << "\t{"; ACTION(action, 0, false) << "}\n";
		}

		out << "\tgoto again;\n";
	}
	return out;
}

std::ostream &FGotoCodeGen::FINISH_CASES()
{
	for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ ) {
		/* States that are final and have an out action need a case. */
		if ( st->eofAction != 0 ) {
			/* Write the case label. */
			out << "\t\tcase " << st->id << ": ";

			/* Jump to the func. */
			out << "goto f" << st->eofAction->id << ";\n";
		}
	}

	return out;
}

/* Init base data. */
CFGotoCodeGen::CFGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &CFGotoCodeGen::CALL( NameInst *name, int targState, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	out << "{fsm->_st[fsm->_top++] = _cs; _cs = " << 
			targ->value->id << "; goto again;}";
	return out;
}

std::ostream &CFGotoCodeGen::RET( bool inFinish )
{
	out << "{_cs = fsm->_st[--fsm->_top]; goto again;}";
	return out;
}

void CFGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() || anyActionRets() )
		out << "	fsm->_top = 0;\n";
	
	INIT_CODE() <<
		"	if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	"; ALPH_TYPE() << " *_pe = data+dlen;\n"
		"	int _cs = fsm->_cs;\n"
		"\n";
	
	out << 
		"again:\n"
		"	if ( ++_p == _pe )\n"
		"		goto out;\n";

	if ( anyEofActions() ) {
		out <<
			"	if ( _p == 0 )\n"
			"		goto eofActions;\n"
			"\n";
	}

	out <<
		"	switch ( _cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyActions() )
		EXEC_ACTIONS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyEofActions() ) {
		out <<
			"eofActions:\n"
			"	_p = 0; _pe = (("; ALPH_TYPE() << "*)0)+1;\n"
			"	switch( _cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"\n";
	}

	out << 
		"out:\n"
		"	fsm->_cs = _cs;\n";

	if ( redFsm->errState != 0 ) {
		out <<
			"	if ( _cs == "; ERROR_STATE() << " )\n"
			"		return -1;\n";
	}

	out <<
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyEofActions() ) {
		/* Call into execute to invoke out actions. */
		out << "	return "; FSM_NAME() << "_execute( fsm, 0, 1 );\n";
	}
	else {
		if ( redFsm->errState != 0 ) {
			out << 
				"	if ( fsm->_cs == "; ERROR_STATE() << " )\n"
				"		return -1;\n";
		}

		out <<
			"	if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out << 
		"}\n"
		"\n";
}

/* Init base data. */
CCFGotoCodeGen::CCFGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &CCFGotoCodeGen::CALL( NameInst *name, int targState, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	out << "{this->_st[this->_top++] = _cs; _cs = " << 
			targ->value->id << "; goto again;}";
	return out;
}

std::ostream &CCFGotoCodeGen::RET( bool inFinish )
{
	out << "{_cs = this->_st[--this->_top]; goto again;}";
	return out;
}

void CCFGotoCodeGen::writeOutHeader()
{
	out << 
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Init the fsm. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() || anyActionRets() )
		out << "	this->_top = 0;\n";

	INIT_CODE() <<
		"	if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	"; ALPH_TYPE() << " *_pe = data+dlen;\n"
		"	int _cs = this->_cs;\n"
		"\n";

	out << 
		"again:\n"
		"	if ( ++_p == _pe )\n"
		"		goto out;\n";

	if ( anyEofActions() ) {
		out <<
			"	if ( _p == 0 )\n"
			"		goto eofActions;\n"
			"\n";
	}

	out <<
		"	switch ( _cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyActions() )
		EXEC_ACTIONS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyEofActions() ) {
		out <<
			"eofActions:\n"
			"	_p = 0; _pe = (("; ALPH_TYPE() << "*)0)+1;\n"
			"	switch( _cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"\n";
	}

	out <<
		"out:\n"
		"	this->_cs = _cs;\n";

	if ( redFsm->errState != 0 ) {
		out <<
			"	if ( _cs == "; ERROR_STATE() << " )\n"
			"		return -1;\n";
	}

	out <<
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";

	if ( anyEofActions() ) {
		/* May need to execute action code. Call into exectue to handle the
		 * finishing code. */
		out << "	return execute( 0, 1 );\n";
	}
	else {
		if ( redFsm->errState != 0 ) {
			out << 
				"	if ( this->_cs == "; ERROR_STATE() << " )\n"
				"		return -1;\n";
		}

		out <<
			"	if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out <<
		"}\n"
		"\n";
}

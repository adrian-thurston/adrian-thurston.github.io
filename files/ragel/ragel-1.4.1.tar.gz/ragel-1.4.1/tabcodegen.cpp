/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "tabcodegen.h"

#define SPEC_ANY_FLAT    0x01
#define SPEC_ANY_SINGLE  0x02
#define SPEC_ANY_RANGE   0x04
#define SPEC_ANY_DEF     0x08
#define SPEC_IS_FINAL    0x10
#define SPEC_OUT_FUNC    0x20

/* Integer array line length. */
#define IALL 8

using std::endl;

/* Pass init data to base class. */
TabCodeGen::TabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
:
	FsmCodeGen(fsmName, machine, parseData, out)
{
}

int TabCodeGen::makeStateSpec( FsmMachState *state )
{
	int retSpec = 0;
	/* Regular single index. */
	if ( state->numIndex > 0 )
		retSpec |= SPEC_ANY_SINGLE;
	/* Range index. */
	if ( state->numRange > 0 )
		retSpec |= SPEC_ANY_RANGE;
	/* Default index. */
	if ( state->dflIndex != TRANS_ERR_TRANS )
		retSpec |= SPEC_ANY_DEF;
	/* Out function? */
	if ( state->outFuncs != FUNC_NO_FUNC )
		retSpec |= SPEC_OUT_FUNC;
	/* Final state? */
	if ( state->isFinState )
		retSpec |= SPEC_IS_FINAL;
	return retSpec;
}

int TabCodeGen::getStateLen( int stateSpec )
{
	/* Basic len of 3. */
	int stateLen = 3;
	if ( stateSpec & SPEC_ANY_FLAT )
		stateLen += 1;
	if ( stateSpec & SPEC_ANY_SINGLE )
		stateLen += 1;
	if ( stateSpec & SPEC_ANY_RANGE )
		stateLen += 1;
	if ( stateSpec & SPEC_OUT_FUNC )
		stateLen += 1;
	return stateLen;
}

int *TabCodeGen::newStatePosArray()
{
	/* Calculate the positions of each state. */
	int *statePos = new int[machine->numStates];
	for ( int sp = 0, s = 0; s < machine->numStates; s++ ) {
		/* Save the position. */
		statePos[s] = sp;

		/* Move over the state. */
		int spec = makeStateSpec( &machine->allStates[s] );
		sp += getStateLen( spec );
	}
	return statePos;
}

std::ostream &TabCodeGen::STATE_OUT_FUNC(FsmMachState *state)
{
	/* This function is only called if there are any out functions, so need
	 * not guard against there being none. */
	out << machine->transFuncIndex[state->outFuncs];
	return out;
}

std::ostream &TabCodeGen::TRANS_FUNC(FsmMachTrans *trans)
{
	/* If there are any out funcs, emit them. Function indicies are indexes
	 * into transFuncIndex and should be dereferenced to get the index
	 * into the array of all transitions. */
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else
		out << "f+" << machine->transFuncIndex[trans->funcs];
	return out;
}

std::ostream &TabCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	StringListEl *flel = parseData->funcList.head;
	for ( int fnum = 0; flel != NULL; fnum++, flel = flel->next ) {
		out << "\tcase " << fnum << ": {";
		out << flel->data;
		out << "break;}" << endl;
	}
	return out;
}

std::ostream &TabCodeGen::STATES()
{
	int curKeyOffset = 0, curIndOffset = 0;
	int totalStateNum = 0;

	/* Initial indent. */
	out << "\t";

	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Get the spec and write it. The len is encoded in the spec. */
		int stateSpec = makeStateSpec( state );
		int stateLen = getStateLen( stateSpec );
		out << ( ( stateLen << 8 ) |  stateSpec ) << ", ";
		if ( ++totalStateNum % IALL == 0 )
			out << "\n\t";

		/* Write the key offset. */
		out << curKeyOffset << ", ";
		if ( ++totalStateNum % IALL == 0 )
			out << "\n\t";

		/* Write the index offset. */
		out << curIndOffset << ", ";
		if ( ++totalStateNum % IALL == 0 )
			out << "\n\t";

		/* Emit length of single index. */
		if ( stateSpec & SPEC_ANY_SINGLE ) {
			out << state->numIndex << ", ";
			if ( ++totalStateNum % IALL == 0 )
				out << "\n\t";
		}

		/* Emit length of range index. */
		if ( stateSpec & SPEC_ANY_RANGE ) {
			out << state->numRange << ", ";
			if ( ++totalStateNum % IALL == 0 )
				out << "\n\t";
		}

		/* If there is an out func, write it. */
		if ( stateSpec & SPEC_OUT_FUNC ) {
			STATE_OUT_FUNC( state ) << ", ";
			if ( ++totalStateNum % IALL == 0 )
				out << "\n\t";
		}

		/* Move the key and index offsets ahead. */
		curKeyOffset += state->numIndex + state->numRange*2;
		curIndOffset += state->numIndex + state->numRange;
		if ( stateSpec & SPEC_ANY_DEF )
			curIndOffset += 1;
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::KEYS()
{
	out << '\t';
	int totalTrans = 0;
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Walk the single list. */
		for ( int j = 0; j < state->numIndex; j++ ) {
			KEY( state->transIndKey[j] ) << ", ";

			/* Put in a line break every 8 */
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}

		/* Walk the range list. Note the 2 times for the keys */
		for ( int j = 0; j < state->numRange*2; j++ ) {
			KEY( state->rangeIndKey[j] ) << ", ";

			/* Put in a line break every 8 */
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::INDICIES()
{
	/* Keep a count of the num of items in the array written. */
	int totalTrans = 0;

	/* Write out initial indentation. */
	out << '\t';
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Get the state spec. */
		int stateSpec = makeStateSpec( state );

		/* Walk the single index list . */
		for ( int j = 0; j < state->numIndex; j++ ) {
			out << state->transIndPtr[j] << ", ";
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}

		/* Walk the range list. */
		for ( int j = 0; j < state->numRange; j++ ) {
			out << state->rangeIndPtr[j] << ", ";
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}

		/* The state's default index goes next. */
		if ( stateSpec & SPEC_ANY_DEF ) {
			out << state->dflIndex << ", ";
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::INDEX_TYPE()
{
	if ( machine->numTrans <= 256 )
		out << "unsigned char";
	else if ( machine->numTrans <= 256*256 )
		out << "unsigned short";
	else 
		out << "unsigned int";
	return out;
}


std::ostream &TabCodeGen::TRANSITIONS( int *statePos )
{
	/* Keep a count of the num of items in the array written. */
	int totalTransData = 0;

	out << '\t';
	for ( int i = 0; i < machine->numTrans; i++ ) {
		/* Get the transition. */
		FsmMachTrans *trans = &machine->allTrans[i];

		/* Write out the target state. */
		if ( trans->toState == STATE_ERR_STATE )
			out << "0, ";
		else
			out << "s+" << statePos[trans->toState] << ", ";
		if ( ++totalTransData % IALL == 0 )
			out << "\n\t";

		/* Write the function for the transition. */
		if ( trans->funcs == FUNC_NO_FUNC )
			out << "0, ";
		else
			out << "f+" << machine->transFuncIndex[trans->funcs] << ", ";
		if ( ++totalTransData % IALL == 0 )
			out << "\n\t";
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::BSEARCH()
{
	out <<
		"/* Binary search an array of keys looking for a key. */\n"
		"static "; ALPH_TYPE() << " *"; FSM_NAME() << "BSearch( "; ALPH_TYPE() << 
				" c, "; ALPH_TYPE() << " *keys, int len )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *lower = keys;\n"
		"	"; ALPH_TYPE() << " *mid;\n"
		"	"; ALPH_TYPE() << " *upper = keys + len - 1;\n"
		"	while (1) {\n"
		"		if ( upper < lower )\n"
		"			return 0;\n"
		"\n"
		"		/* Find the midpoint. */\n"
		"		mid = lower + ((upper-lower) >> 1);\n"
		"\n"
		"		if ( c < *mid )\n"
		"			upper = mid - 1;\n"
		"		else if ( c > *mid )\n"
		"			lower = mid + 1;\n"
		"		else\n"
		"			return mid;\n"
		"	}\n"
		"}\n";

	return out;
}

std::ostream &TabCodeGen::RANGE_BSEARCH()
{
	out <<
		"/* Binary search an array of keys looking for a key. */\n"
		"static "; ALPH_TYPE() << " *"; FSM_NAME() << "RangeBSearch( "; ALPH_TYPE() << 
				" c, "; ALPH_TYPE() << " *keys, int len )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *lower = keys;\n"
		"	"; ALPH_TYPE() << " *mid;\n"
		"	"; ALPH_TYPE() << " *upper = keys + len - 2;\n"
		"	while (1) {\n"
		"		if ( upper < lower )\n"
		"			return 0;\n"
		"\n"
		"		/* Find the midpoint. Be sure to settle on the\n"
		"		 * lower end of a range. */\n"
		"		mid = lower + (((upper-lower) >> 1) & ~1);\n"
		"\n"
		"		if ( c < mid[0] )\n"
		"			upper = mid - 2;\n"
		"		else if ( c > mid[1] )\n"
		"			lower = mid + 2;\n"
		"		else {\n"
		"			/* The key was found in the range mid, return it. */\n"
		"			return mid;\n"
		"		}\n"
		"	}\n"
		"}\n";

	return out;
}

std::ostream &TabCodeGen::LOCATE_TRANS()
{
	out <<
		"		/* Get required data. */\n"
		"		specs = *cs++;\n"
		"		keys = k + *cs++;\n"
		"		inds = i + *cs++;\n"
		"\n"
		"		/* Try flat index. */\n"
		"		if ( specs & SPEC_ANY_FLAT ) {\n"
		"			int indsLen = *cs++;\n"
		"			keys += 2;\n"
		"			inds += indsLen;\n"
		"		}\n"
		"\n"
		"		/* Try binary search single. */\n"
		"		if ( specs & SPEC_ANY_SINGLE ) {\n"
		"			/* Try to find the key. */\n"
		"			int indsLen = *cs++;\n"
		"			"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
							"BSearch( *p, keys, indsLen );\n"
		"\n"
		"			if ( match != 0 ) {\n"
		"				trans = t + (inds[match - keys]<<1);\n"
		"				goto match;\n"
		"			}\n"
		"\n"
		"			/* Advance over the keys and indicies. */\n"
		"			keys += indsLen;\n"
		"			inds += indsLen;\n"
		"		}\n"
		"\n"
		"		/* Try binary search range. */\n"
		"		if ( specs & SPEC_ANY_RANGE ) {\n"
		"			/* Try to find the key. */\n"
		"			int indsLen = *cs++;\n"
		"			"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
							"RangeBSearch( *p, keys, (indsLen<<1) );\n"
		"\n"
		"			if ( match != 0 ) {\n"
		"				trans = t + (inds[(match - keys)>>1]<<1);\n"
		"				goto match;\n"
		"			}\n"
		"\n"
		"			/* Advance over the keys and indicies. */\n"
		"			keys += (indsLen<<1);\n"
		"			inds += indsLen;\n"
		"		}\n"
		"\n"
		"		/* Try the default transition. */\n"
		"		if ( specs & SPEC_ANY_DEF ) {\n"
		"			trans = t + ((*inds)<<1);\n"
		"			goto match;\n"
		"		}\n";

	return out;
}


/* Pass init data to base. */
CTabCodeGen::CTabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
:
	TabCodeGen(fsmName, machine, parseData, out)
{
}


/* Generate the header portion. */
void CTabCodeGen::writeOutHeader()
{
	out << 
		"/* Forward dec state for the transition structure. */\n"
		"struct "; FSM_NAME() << "StateStruct;\n"
		"\n"
		"/* Only non-static data: current state, acceptance indicator. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int *curState;\n"
		"	int accept;\n"
		"\n";
		STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, ";
				ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define f "; FSM_NAME() << "_f\n"
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		/* "#define CTL_HOLD         0x01\n"
		 * "#define CTL_GOTO         0x02\n"
		 * "#define CTL_HGOTO        0x04\n" */
		"\n";

	/* If there are any transtion functions then output the array. If there
	 * are none, don't bother emitting an empty array that won't be used. */
	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of transitions. */\n"
		"static int *"; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_start;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n";

	/* State machine function execution. */
	out <<
 		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"static int "; FSM_NAME() << "ExecFuncs( "; FSM_NAME() 
				<< " *fsm, int *funcs, "; ALPH_TYPE() << " *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() << "\n"
		"		}\n"
		"	}\n"
		"	return 0;\n"
		"}\n"
		"\n";

	/* Accept routine. */
	out <<
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	int *cs = fsm->curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int specs, **trans, *funcs;\n"
		"		"; ALPH_TYPE() << " *keys;\n"
		"		"; INDEX_TYPE() << " *inds;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"		/* No match. */\n"
		"		cs = 0;\n"
		"		goto finished;\n"
		"\n"
		"match:\n"
		"		/* Move to the new state. */\n"
		"		cs = *trans++;\n"
		"\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( (funcs = *trans) != 0 ) { \n"
		"			"; FSM_NAME() << "ExecFuncs( fsm, funcs, p );\n"
		/* "			int jmp = "; FSM_NAME() << "ExecFuncs( fsm, funcs, p );\n"
		 * "			if ( jmp & CTL_HOLD )\n"
		 * "				p--, len++;\n"
		 * "			else if ( jmp & CTL_GOTO )\n"
		 * "				cs = fsm->curState;\n"
		 * "			else if ( jmp & CTL_HGOTO ) {\n"
		 * "				p--, len++;\n"
		 * "				cs = fsm->curState;\n"
		 * "			}\n" */
		"		}\n"
		"	}\n"
		"finished:\n"
		"	fsm->curState = cs;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int *cs = fsm->curState;\n"
		"	if ( cs != 0 && *cs & SPEC_IS_FINAL ) {\n";

	/* If there are any functions, then emit the finishing action execute. */
	if ( anyTransFuncs() ) {
		out <<
			"		/* If finishing in a final state then execute the\n"
			"		 * out functions for it. (if any). */\n"
			"		if ( *cs & SPEC_OUT_FUNC ) {\n"
			"			cs += (*cs>>8)-1;\n"
			"			"; FSM_NAME() << "ExecFuncs( fsm, f + *cs, 0 );\n"
			"		}\n"
			"\n";
	}

	out << 
		"		/* The machine accepts. */\n"
		"		fsm->accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		fsm->curState = 0;\n"
		"	}\n"
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef f\n"
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		/* "#undef CTL_HOLD\n"
		 * "#undef CTL_GOTO\n"
		 * "#undef CTL_HGOTO\n" */
		"\n";

	/* Finished with this. */
	delete[] statePos;
}

/* Init base class. */
CCTabCodeGen::CCTabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out ) :
		TabCodeGen(fsmName, machine, parseData, out)
{
}

void CCTabCodeGen::writeOutHeader()
{
	out <<
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Constructor calls init. */\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Initialize the machine for execution. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int *curState;\n"
		"	int accept;\n"
		"\n";
		STRUCT_DATA() << "\n"
		"\n"
		"private:\n"
		"	int ExecFuncs( int *funcs, "; ALPH_TYPE() << " *p );\n"
		"};\n"
		"\n";
}

void CCTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define f "; FSM_NAME() << "_f\n"
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		/* "#define CTL_HOLD         0x01\n" */
		/* "#define CTL_GOTO         0x02\n" */
		/* "#define CTL_HGOTO        0x04\n" */
		"\n";

	/* If there are any transtion functions then output the array. If there
	 * are none, don't bother emitting an empty array that won't be used. */
	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of transitions. */\n"
		"static int *"; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Constructor. */
	out <<
		"/* Make sure the machine is initted. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "()\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = "; FSM_NAME() << "_start;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n";

	/* State machine function execution. */
	out <<
 		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"int "; FSM_NAME() << "::ExecFuncs( int *funcs, "; ALPH_TYPE() << " *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() << "\n"
		"		}\n"
		"	}\n"
		"	return 0;\n"
		"}\n"
		"\n";

	/* Accept routine. */
	out <<
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	int *cs = curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int specs, **trans, *funcs;\n"
		"		"; ALPH_TYPE() << " *keys;\n"
		"		"; INDEX_TYPE() << " *inds;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"		/* No match. */\n"
		"		cs = 0;\n"
		"		goto finished;\n"
		"\n"
		"match:\n"
		"		/* Move to the new state. */\n"
		"		cs = *trans++;\n"
		"\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( (funcs = *trans) != 0 ) { \n"
		"			ExecFuncs( funcs, p );\n"
		/* "			int jmp = ExecFuncs( funcs, p );\n"
		 * "			if ( jmp & CTL_HOLD )\n"
		 * "				p--, len++;\n"
		 * "			else if ( jmp & CTL_GOTO )\n"
		 * "				cs = curState;\n"
		 * "			else if ( jmp & CTL_HGOTO ) {\n"
		 * "				p--, len++;\n"
		 * "				cs = curState;\n"
		 * "			}\n" */
		"		}\n"
		"	}\n"
		"finished:\n"
		"	curState = cs;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int *cs = curState;\n"
		"	if ( cs != 0 && *cs & SPEC_IS_FINAL ) {\n";

	/* If there are any functions, then emit the finishing action execute. */
	if ( anyTransFuncs() ) {
		out <<
			"		/* If finishing in a final state then execute the\n"
			"		 * out functions for it. (if any). */\n"
			"		if ( *cs & SPEC_OUT_FUNC ) {\n"
			"			cs += (*cs>>8)-1;\n"
			"			ExecFuncs( f + *cs, 0 );\n"
			"		}\n"
			"\n";
	}

	out << 
		"		/* The machine accepts. */\n"
		"		accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		curState = 0;\n"
		"	}\n"
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef f\n"
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		/* "#undef CTL_HOLD\n"
		 * "#undef CTL_GOTO\n"
		 * "#undef CTL_HGOTO\n" */
		"\n";

	/* Finished with this. */
	delete[] statePos;
}

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

#include <new>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "table.h"

#ifdef AAPL_NAMESPACE
namespace Aapl {
#endif

/* SVector */
template < class T, class Resize = ResizeExpn > class SVector
	: public STable<T>, public Resize
{
public:
	/**
	 * \brief Initialize an empty vector with no space allocated.  
	 *
	 * If a linear resizer is used, the step defaults to 256 units of T. For a
	 * runtime vector both up and down allocation schemes default to
	 * Exponential.
	 */
	SVector() { }

	/* Create a vector with an intial number of elements. */
	SVector( int size ) { setAsNew( size ); }

	/* Create a vector of specific size and allocation. */
	SVector( int size, int allocLen );

	/* Shallow copy. */
	SVector( const SVector &v );

	/* Shallow copy. */
	SVector(TabHead<T> *head);

	/* Free all mem used by the vector. */
	~SVector() { empty(); }

	/* Delete all items. */
	void empty();

	/**
	 * \brief Deep copy another vector into this vector.
	 *
	 * Copies the entire contents of the other vector into this vector. Any
	 * existing contents are first deleted. Equivalent to setAs.
	 */
	void deepCopy( const SVector &v )     { setAs(v.data, v.length()); }

	/* Perform a shallow copy of another vector. */
	SVector &operator=( const SVector &v );

	/* Perform a shallow copy of another vector by the header. */
	SVector &operator=( TabHead<T> *head );


	/*@{*/
	/* Insert one element at position pos. */
	void insert(int pos, const T &val)   { insert(pos, &val, 1); }

	/* Insert an array of values. */
	void insert(int pos, const T *val, int len);

	/* Insert the contents of another vector. */
	void insert(int pos, const SVector &v);

	/* Insert len copies of val into the vector. */
	void insertDup(int pos, const T &val, int len);

	/* Insert one new item using the default constructor. */
	void insertNew(int pos)              { insertNew(pos, 1); }

	/* Insert len new items using default constructor. */
	void insertNew(int pos, int len);
	/*@}*/

	/*@{*/
	/* Delete one element. */
	void remove(int pos)                 { remove(pos, 1); }

	/* Delete a number of elements. */
	void remove(int pos, int len);
	/*@}*/

	/*@{*/
	/* Replace a single element. */
	void replace(int pos, const T &val)  { replace(pos, &val, 1); }

	/* Replace with an array of values. */
	void replace(int pos, const T *val, int len);

	/* Replace with the contents of another vector. */
	void replace(int pos, const SVector &v);

	/* Replace len items with len copies of val. */
	void replaceDup(int pos, const T &val, int len);

	/* Replace one item at pos with a constructed object. */
	void replaceNew(int pos)             { replaceNew(pos, 1); }

	/* Replace len items at pos with newly constructed objects. */
	void replaceNew(int pos, int len);
	/*@}*/

	/*@{*/
	/* Set the vector to be val exactly. */
	void setAs(const T &val)             { setAs(&val, 1); }

	/* Set to the contents of an array. */
	void setAs(const T *val, int len);

	/* Set to the contents of another vector. */
	void setAs(const SVector &v);

	/* Set as len copies of item. */
	void setAsDup(const T &item, int len);

	/* Set as a newly constructed object using the default constructor. */
	void setAsNew()                      { setAsNew(1); }

	/* Set as newly constructed objects using the default constructor. */
	void setAsNew(int len);
	/*@}*/

	/*@{*/
	/* Append a single element. */
	void append(const T &val)                { replace(length(), &val, 1); }

	/* Append an array of elements. */
	void append(const T *val, int len)       { replace(length(), val, len); }

	/* Append to the end of the vector from another vector. */
	void append(const SVector &v);

	/* Append len copies of item. */
	void appendDup(const T &item, int len)   { replaceDup(length(), item, len); }

	/* Append a newly created item. Uses the copy constructor. */
	void appendNew()                         { replaceNew(length(), 1); }

	/* Append newly created items. Uses the copy constructor. */
	void appendNew(int len)                  { replaceNew(length(), len); }
	/*@}*/
	
	/*@{*/
	/* Prepend a single element. */
	void prepend(const T &val)               { insert(0, &val, 1); }

	/* Prepend an array of elements. */
	void prepend(const T *val, int len)      { insert(0, val, len); }

	/* Prepend to the front of the vector from another vector. */
	void prepend(const SVector &v);

	/* Prepend len copies of item. */
	void prependDup(const T &item, int len)  { insertDup(0, item, len); }

	/* Prepend a newly created item. Uses the copy constructor to init. */
	void prependNew()                        { insertNew(0, 1); }

	/* Prepend newly created items. Uses the copy constructor to init. */
	void prependNew(int len)                 { insertNew(0, len); }
	/*@}*/

	/* Convenience access. */
	T &operator[](int i) const { return data[i]; }
	operator T *() const       { return data; }
	int size() const           { return length(); }

	/* first, last. */
	T *first() const  { return data; }
	T *last() const   { return data+length()-1; }

	/* Sentinals. */
	T *sfirst() const { return data-1; }
	T *slast() const  { return data+length(); }

	/* SVector Iterator. */
	struct Iterator
	{
		/* Construct, assign. */
		Iterator() : ptr(0) { }
		Iterator(T *ptr) : ptr(ptr) { }
		Iterator(const SVector &v) : ptr(v.data) { }

		Iterator &operator=(T *ptr)              { this->ptr = ptr; return *this; }
		Iterator &operator=(const SVector &v)    { ptr = v.data; return *this;}

		/* Cast, dereference, arrow ops. */
		operator T*() const   { return ptr; }
		T &operator *() const { return *ptr; }
		T *operator->() const { return ptr; }
		T &value() const      { return *ptr; }

		/* Arithmetic. */
		T *operator++()       { return ++ptr; }
		T *operator--()       { return --ptr; }
		T *operator++(int)    { return ptr++; }
		T *operator--(int)    { return ptr--; }

		/* List-like. */
		T *next()           { return ++ptr; }
		T *prev()           { return --ptr; }

		/* The iterator is simply a pointer. */
		T *ptr;
	};

protected:
#ifdef VECT_COMPLEX
 	void makeRawSpaceFor(int pos, int len);
#endif

	void setAsCommon(int len);
	int replaceCommon(int pos, int len);
	int insertCommon(int pos, int len);

	void upResize(int len);
	void upResizeDup(int len);
	void upResizeFromEmpty(int len);
	void downResize(int len);
	void downResizeDup(int len);
};


/* Create a vector with an intial number of elements and size. */
template<class T, class Resize> SVector<T, Resize>::
		SVector( int size, int allocLen )
{
	/* Allocate the space if we are given a positive allocLen. */
	if ( allocLen > 0 ) {
		/* Allocate the data needed. */
		TabHead<T> *head = (TabHead<T>*) malloc( sizeof(TabHead<T>) + 
				sizeof(T) * allocLen );
		if ( head == 0 )
			throw std::bad_alloc();

		/* Set up the header and save the data pointer. */
		head->refCount = 1;
		head->allocLen = allocLen;
		head->length = 0;
		data = (T*) (head + 1);
	}

	/* Grow to the size specified. If we did not have enough space
	 * allocated that is ok. Table will be grown to the right size. */
	setAsNew( size );
}

/**
 * \brief Perform a shallow copy of the vector.
 *
 * Takes a reference to the contents of the other vector.
 */
template<class T, class Resize> SVector<T, Resize>::
		SVector(const SVector<T, Resize> &v)
{
	/* Take a reference to other, if any data is allocated. */
	if ( v.data == 0 )
		data = 0;
	else {
		/* Get the source header, up the refcount and ref it. */
		TabHead<T> *srcHead = ((TabHead<T>*) v.data) - 1;
		srcHead->refCount += 1;
		data = (T*) (srcHead + 1);
	}
}

/**
 * \brief Perform a shallow copy of the vector from only the header.
 *
 * Takes a reference to the contents specified by the header.
 */
template<class T, class Resize> SVector<T, Resize>::
		SVector(TabHead<T> *head)
{
	/* Take a reference to other, if the header is no-null. */
	if ( head == 0 )
		data = 0;
	else {
		head->refCount += 1;
		data = (T*) (head + 1);
	}
}


/**
 * \brief Shallow copy another vector into this vector.
 *
 * Takes a reference to the other vector. The contents of this vector are
 * first emptied. 
 *
 * \returns A reference to this.
 */
template<class T, class Resize> SVector<T, Resize> &SVector<T, Resize>::
		operator=( const SVector &v )
{
	/* First clean out the current contents. */
	empty();

	/* Take a reference to other, if any data is allocated. */
	if ( v.data == 0 )
		data = 0;
	else {
		/* Get the source header, up the refcount and ref it. */
		TabHead<T> *srcHead = ((TabHead<T>*) v.data) - 1;
		srcHead->refCount += 1;
		data = (T*) (srcHead + 1);
	}
	return *this;
}

/**
 * \brief Shallow copy another vector into this vector from only the header.
 *
 * Takes a reference to the other header vector. The contents of this vector
 * are first emptied. 
 *
 * \returns A reference to this.
 */
template<class T, class Resize> SVector<T, Resize> &SVector<T, Resize>::
		operator=( TabHead<T> *head )
{
	/* First clean out the current contents. */
	empty();

	/* Take a reference to other, if the header is no-null. */
	if ( head == 0 )
		data = 0;
	else {
		head->refCount += 1;
		data = (T*) (head + 1);
	}
	return *this;
}

/* Append to the end of the vector from another vector. */
template<class T, class Resize> void SVector<T, Resize>::
		append(const SVector<T, Resize> &v)
{
	assert( &v != this );
	replace( length(), v.data, v.length() );
}

/**
 * \brief Prepend the contents of vector v to the front of the vector. 
 *
 * Copy constructors are used to place the elements in the vector.
 */
template<class T, class Resize> void SVector<T, Resize>::
		prepend(const SVector<T, Resize> &v)
{
	assert( &v != this );
	insert( 0, v.data, v.length() );
}

/* Set to the contents of another vector. */
template<class T, class Resize> void SVector<T, Resize>::
		setAs(const SVector<T, Resize> &v)
{
	assert( &v != this );
	setAs( v.data, v.length() );
}

/* Replace with the all the contents of another vector. */
template<class T, class Resize> void SVector<T, Resize>::
		replace(int pos, const SVector<T, Resize> &v)
{
	assert(&v != this);
	replace( pos, v.data, v.length() );
}

/* Insert all the contents of another vector into this vector. */
template<class T, class Resize> void SVector<T, Resize>::
		insert(int pos, const SVector<T, Resize> &v)
{
	assert(&v != this);
	insert( pos, v.data, v.length() );
}

/* Up resize the data for len elements using Resize::upResize to tell us the
 * new length. Reads and writes allocLen. Does not read or write length.
 * Assumes that there is some data allocated already. */
template<class T, class Resize> void SVector<T, Resize>::
		upResize(int len)
{
	/* Get the current header. */
	TabHead<T> *head = ((TabHead<T>*)data) - 1;

	/* Ask the resizer what the new length will be. */
	int newLen = Resize::upResize(head->allocLen, len);

	/* Did the data grow? */
	if ( newLen > head->allocLen ) {
		head->allocLen = newLen;

		/* Table exists already, resize it up. */
		head = (TabHead<T>*) realloc( head, sizeof(TabHead<T>) + 
				sizeof(T) * newLen );
		if ( head == 0 )
			throw std::bad_alloc();

		/* Save the data pointer. */
		data = (T*) (head + 1);
	}
}

/* Allocates a new buffer for an up resize that requires a duplication of the
 * data. Uses Resize::upResize to get the allocation length.  Reads and writes
 * allocLen. This upResize does write the new length.  Assumes that there is
 * some data allocated already. */
template<class T, class Resize> void SVector<T, Resize>::
		upResizeDup(int len)
{
	/* Get the current header. */
	TabHead<T> *head = ((TabHead<T>*)data) - 1;

	/* Ask the resizer what the new length will be. */
	int newLen = Resize::upResize(head->allocLen, len);

	/* Dereferencing the existing data, decrement the refcount. */
	head->refCount -= 1;

	/* Table exists already, resize it up. */
	head = (TabHead<T>*) malloc( sizeof(TabHead<T>) + sizeof(T) * newLen );
	if ( head == 0 )
		throw std::bad_alloc();

	head->refCount = 1;
	head->allocLen = newLen;
	head->length = len;

	/* Save the data pointer. */
	data = (T*) (head + 1);
}

/* Up resize the data for len elements using Resize::upResize to tell us the
 * new length. Reads and writes allocLen. This upresize DOES write length.
 * Assumes that no data is allocated. */
template<class T, class Resize> void SVector<T, Resize>::
		upResizeFromEmpty(int len)
{
	/* There is no table yet. If the len is zero, then there is no need to
	 * create a table. */
	if ( len > 0 ) {
		/* Ask the resizer what the new length will be. */
		int newLen = Resize::upResize(0, len);

		/* If len is greater than zero then we are always allocating the table. */
		TabHead<T> *head = (TabHead<T>*) malloc( sizeof(TabHead<T>) + 
				sizeof(T) * newLen );
		if ( head == 0 )
			throw std::bad_alloc();

		/* Set up the header and save the data pointer. Note that we set the
		 * length here. This differs from the other upResizes. */
		head->refCount = 1;
		head->allocLen = newLen;
		head->length = len;
		data = (T*) (head + 1);
	}
}

/* Down resize the data for len elements using Resize::downResize to determine
 * the new length. Reads and writes allocLen. Does not read or write length. */
template<class T, class Resize> void SVector<T, Resize>::
		downResize(int len)
{
	/* If there is already no length, then there is nothing we can do. */
	if ( data != 0 ) {
		/* Get the current header. */
		TabHead<T> *head = ((TabHead<T>*)data) - 1;

		/* Ask the resizer what the new length will be. */
		int newLen = Resize::downResize( head->allocLen, len );

		/* Did the data shrink? */
		if ( newLen < head->allocLen ) {
			if ( newLen == 0 ) {
				/* Simply free the data. */
				free( head );
				data = 0;
			}
			else {
				/* Save the new allocated length. */
				head->allocLen = newLen;

				/* Not shrinking to size zero, realloc it to the smaller size. */
				head = (TabHead<T>*) realloc( head, sizeof(TabHead<T>) + 
						sizeof(T) * newLen );
				if ( head == 0 )
					throw std::bad_alloc();
				
				/* Save the new data ptr. */
				data = (T*) (head + 1);
			}
		}
	}
}

/* Allocate a new buffer for a down resize and duplication of the array.  The
 * new array will be len long and allocation size will be determined using
 * Resize::downResize with the old array's allocLen. Does not actually copy
 * any data. Reads and writes allocLen and writes the new len. */
template<class T, class Resize> void SVector<T, Resize>::
		downResizeDup(int len)
{
	/* If there is already no length, then there is nothing we can do. */
	if ( data != 0 ) {
		/* Get the current header. */
		TabHead<T> *head = ((TabHead<T>*)data) - 1;

		/* Ask the resizer what the new length will be. */
		int newLen = Resize::downResize( head->allocLen, len );

		/* Detaching from the existing head, decrement the refcount. */
		head->refCount -= 1;

		/* Not shrinking to size zero, malloc it to the smaller size. */
		head = (TabHead<T>*) malloc( sizeof(TabHead<T>) + sizeof(T) * newLen );
		if ( head == 0 )
			throw std::bad_alloc();

		/* Save the new allocated length. */
		head->refCount = 1;
		head->allocLen = newLen;
		head->length = len;

		/* Save the data pointer. */
		data = (T*) (head + 1);
	}
}

#ifdef AAPL_NAMESPACE
}
#endif

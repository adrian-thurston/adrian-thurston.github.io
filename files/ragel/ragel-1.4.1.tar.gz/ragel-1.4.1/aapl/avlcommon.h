/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndef becuase it is not intended to
 * be included by the user. */

#include <assert.h>

#ifdef AAPL_NAMESPACE
namespace Aapl {
#endif

#ifdef WALKABLE
/* This is used by AvlTree, AvlMel and AvlMelKey so it
 * must be protected by global ifdefs. */
#ifndef __AAPL_AVLINODE__
#define __AAPL_AVLINODE__

/**
 * \brief Tree node properties for linked AVL trees.
 *
 * AvliNode needs to be inherited by classes that intend to be nodes in an
 * AvliTree. 
 */
template<class AvlNodeNode> struct AvliNode 
{
	/**
	 * \brief Tree pointers connecting nodes in a tree.
	 */
	AvlNodeNode *left, *right, *parent;

	/**
	 * \brief Linked list pointers.
	 */
	AvlNodeNode *prev, *next;

	/**
	 * \brief Height of the tree rooted at this node.
	 *
	 * Height is required by the AVL balancing algorithm.
	 */
	int height;
};
#endif /* __AAPL_AVLINODE__ */

#else /* not WALKABLE */

/* This is used by All the non walkable trees so it must be
 * protected by a global ifdef. */
#ifndef __AAPL_AVLNODE__
#define __AAPL_AVLNODE__
/**
 * \brief Tree node properties for linked AVL trees.
 *
 * AvlNode needs to be inherited by classes that intend to be nodes in an
 * AvlTree. 
 */
template<class AvlNodeNode> struct AvlNode
{
	/**
	 * \brief Tree pointers connecting nodes in a tree.
	 */
	AvlNodeNode *left, *right, *parent;

	/**
	 * \brief Height of the tree rooted at this node.
	 *
	 * Height is required by the AVL balancing algorithm.
	 */
	int height;
};
#endif /* __AAPL_AVLNODE__ */
#endif /* def WALKABLE */


#if defined( AVLTREE_MAP )

#ifdef WALKABLE

/**
 * \brief Tree node for AvliMap
 *
 * Stores the key and value pair.
 */
template <class Key, class Value> struct AvliMapNode :
		public AvliNode< AvliMapNode<Key, Value> >
{
	AvliMapNode(const Key &key) 
		: key(key) { }
	AvliMapNode(const Key &key, const Value &value) 
		: key(key), value(value) { }

	const Key &getKey() { return key; }

	/** \brief The key. */
	Key key;

	/** \brief The value. */
	Value value;
};
#else /* not WALKABLE */

/**
 * \brief Tree node for AvlMap
 *
 * Stores the key and value pair.
 */
template <class Key, class Value> struct AvlMapNode :
		public AvlNode< AvlMapNode<Key, Value> >
{
	AvlMapNode(const Key &key) 
		: key(key) { }
	AvlMapNode(const Key &key, const Value &value) 
		: key(key), value(value) { }

	const Key &getKey() { return key; }

	/** \brief The key. */
	Key key;

	/** \brief The value. */
	Value value;
};
#endif /* def WALKABLE */

#elif defined( AVLTREE_SET )

#ifdef WALKABLE
/**
 * \brief Tree node for AvliSet
 *
 * Stores the key.
 */
template <class Key> struct AvliSetNode :
		public AvliNode< AvliSetNode<Key> >
{
	AvliSetNode(const Key &key) : key(key) { }

	const Key &getKey() { return key; }

	/** \brief The key. */
	Key key;
};
#else /* not WALKABLE */
/**
 * \brief Tree node for AvlSet
 *
 * Stores the key.
 */
template <class Key> struct AvlSetNode :
		public AvlNode< AvlSetNode<Key> >
{
	AvlSetNode(const Key &key) : key(key) { }

	const Key &getKey() { return key; }

	/** \brief The key. */
	Key key;
};
#endif /* def WALKABLE */

#endif /* AVLTREE_SET */

/* Common AvlTree Class */
template <AVLMEL_TEMPDEF> class AvlTree
#ifdef WALKABLE
		: public BASELIST
#endif
{
public:
	/**
	 * \brief Create an empty tree.
	 */
#ifdef WALKABLE
	AvlTree() : root(0), nodeCount(0) { }
#else
	AvlTree() : root(0), head(0), tail(0), nodeCount(0) { }
#endif

	/** 
	 * \brief Perform a deep copy of the tree. 
	 *
	 * Each node is duplicated for the new tree. Copy constructors are used to
	 * create the new nodes.
	 */
	AvlTree(const AvlTree &other);

#if defined( AVLTREE_MAP ) || defined( AVLTREE_SET )
	/**
	 * \brief Clear the contents of the tree.
	 *
	 * All nodes are deleted.
	 */
	~AvlTree() { empty(); }
#else
	/**
	 * \brief Abandon all nodes in the tree. 
	 *
	 * Tree nodes are not deleted.
	 */
	~AvlTree() {}
#endif

	/* Performs a shallow copy of another avl tree into this avl tree. If this
	 * tree is non-empty then its contents are lost (not freed). */
	void shallowCopy( const AvlTree &tree );

	/* Perform a deep copy of another tree into this tree. */
	AvlTree &operator=( const AvlTree &tree );

	/* Insert a node into the tree. */
	Node *insert(Node *node, Node **lastFound = 0);
	Node *insert(const Key &key, Node **lastFound = 0);
#if defined( AVLTREE_MAP )
	Node *insert(const Key &key, const Value &val,
			Node **lastFound = 0 );
#endif

	/* Find a node in the tree. Returns the node if 
	 * key exists, false otherwise. */
	Node *find(const Key &key) const;

	/* Detach a node from the tree. */
	Node *detach(const Key &key);
	Node *detach(Node *node);

	/* Detach and delete a node from the tree. */
	bool remove(const Key &key);
	void remove(Node *node);

	/* Free all memory used by tree. */
	void empty();

	/* Abandon all nodes in the tree. Does not delete nodes. */
	void abandon();

	/** Root node of the tree. */
	Node *root;

#ifndef WALKABLE
	Node *head, *tail;
#endif

	/** The number of nodes in the tree. */
	int nodeCount;

	int size() const           { return nodeCount; }

#ifdef WALKABLE
	/* First, last. */
	Node *first() const { return BASELIST::head; }
	Node *last() const  { return BASELIST::tail; }

	/* Sentinals. */
	Node *sfirst() const { return 0; }
	Node *slast() const  { return 0; }

	/* AvlTree  Iterator. */
	struct Iterator
	{
		/* Construct, assign. */
		Iterator() : ptr(0) { }
		Iterator(Node *ptr) : ptr(ptr) { }
		Iterator(const AvlTree &tree) : ptr(tree.head) { }

		Iterator &operator=(Node *ptr)
				{ this->ptr = ptr; return *this; }
		Iterator &operator=(const AvlTree &tree)
				{ ptr = tree.head; return *this; }

		/* Cast, dereference, arrow ops. */
		operator Node*() const      { return ptr; }
		Node &operator *() const    { return *ptr; }
		Node *operator->() const    { return ptr; }

		/* Arithmetic. */
		inline Node *operator++();
		inline Node *operator--();
		inline Node *operator++(int);
		inline Node *operator--(int);

		/* List like. */
		inline Node *next();
		inline Node *prev();

		/* The iterator is simply a pointer. */
		Node *ptr;
	};

#else

	/* First, last. */
	Node *first() const { return head; }
	Node *last() const  { return tail; }

	/* Sentinals. */
	Node *sfirst() const { return 0; }
	Node *slast() const  { return 0; }

	struct Iterator 
	{
		/* Construct, assign. */
		Iterator() : ptr(0) { }
		Iterator(Node *ptr) : ptr(ptr) { }
		Iterator(const AvlTree &tree) : ptr(tree.head) { }

		Iterator &operator=(Node *ptr)
				{ this->ptr = ptr; return *this; }
		Iterator &operator=(const AvlTree &tree)
				{ ptr = tree.head; return *this; }

		/* Cast, dereference, arrow ops. */
		operator Node*() const      { return ptr; }
		Node &operator *() const    { return *ptr; }
		Node *operator->() const    { return ptr; }
#if defined ( AVLTREE_MAP )
		Key &key() const            { return ptr->key; }
		Value &value() const        { return ptr->value; }
#elif defined ( AVLTREE_SET )
		Key &key() const            { return ptr->key; }
#endif

		/* Arithmetic. */
		inline Node *operator++();
		inline Node *operator--();
		inline Node *operator++(int);
		inline Node *operator--(int);

		/* List like. */
		inline Node *next();
		inline Node *prev();

		void findNext();
		void findPrev();

		/* The iterator is simply a pointer. */
		Node *ptr;
	};

#endif

protected:
	/* Recursive worker for the copy constructor. */
	Node *CopyBranch( Node *node );

	/* Recursively delete nodes in the tree. */
	void DeleteChildrenOf(Node *n);

	/* Rebalance the tree beginning at the leaf whose 
	 * grandparent is unbalanced. */
	Node *Rebalance(Node *start);

	/* Move up the tree from a given node, recalculating the heights. */
	void RecalcHeights(Node *start);

	/* Move up the tree and find the first node whose 
	 * grand-parent is unbalanced. */
	Node *FindFirstUnbalGP(Node *start);

	/* Move up the tree and find the first node which is unbalanced. */
	Node *FindFirstUnbalNode(Node *start);

	/* Replace a node in the tree with another node not in the tree. */
	void ReplaceNode(Node *node, Node *replacement);

	/* Remove a node from the tree and put another (normally a child of node)
	 * in its place. */
	void RemoveNode(Node *node, Node *filler);

	/* Insertion direction. */
	enum InsDir { left, right };

	/* Once an insertion point is found at a leaf then do the insert. */
	void AttachRebal( Node *node, Node *parentNode, InsDir direction );
};


/* Copy constructor. New up each item. */
template <AVLMEL_TEMPDEF> AvlTree<AVLMEL_TEMPUSE>::
		AvlTree(const AvlTree<AVLMEL_TEMPUSE> &other)
#ifdef WALKABLE
:
	/* Make an empty list, copyBranch will fill in the details for us. */
	BASELIST()
#endif
{
	nodeCount = other.nodeCount;
	root = other.root;

#ifndef WALKABLE
	head = 0;
	tail = 0;
#endif

	/* If there is a root, copy the tree. */
	if ( other.root != 0 )
		root = CopyBranch( other.root );
}

template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::
		shallowCopy(const AvlTree<AVLMEL_TEMPUSE> &other)
{
	nodeCount = other.nodeCount;
	root = other.root;

	head = other.head;
	tail = other.tail;
#ifdef WALKABLE
	length = other.length;
#endif
}

#if defined( AVLTREE_MAP ) || defined( AVLTREE_SET )

/**
 * \brief Deep copy another tree into this tree.
 *
 * Copies the entire contents of the other tree into this tree. Copy
 * constructors are used to create the new nodes. Any existing nodes are first
 * deleted.
 */
template <AVLMEL_TEMPDEF> AvlTree<AVLMEL_TEMPUSE> &AvlTree<AVLMEL_TEMPUSE>::
	operator=( const AvlTree &other )
{
	/* Clear the list first. */
	empty();

	/* Reset the list pointers, the tree copy will 
	 * fill in the list for us. */
	head = 0;
	tail = 0;
#ifdef WALKABLE
	length = 0;
#endif

	/* Copy the entire tree. */
	nodeCount = other.nodeCount;
	root = other.root;
	if ( other.root != 0 )
		root = CopyBranch( other.root );
	return *this;
}

#else

/**
 * \brief Deep copy another tree into this tree.
 *
 * Copies the entire contents of the other tree into this tree. Copy
 * constructors are used to create the new nodes. Any existing nodes are
 * abandoned.
 *
 * \returns A reference to this.
 */
template <AVLMEL_TEMPDEF> AvlTree<AVLMEL_TEMPUSE> &AvlTree<AVLMEL_TEMPUSE>::
	operator=( const AvlTree &other )
{
	/* Reset the list pointers, the tree copy will 
	 * fill in the list for us. */
	head = 0;
	tail = 0;
#ifdef WALKABLE
	length = 0;
#endif

	/* Copy the entire tree. */
	nodeCount = other.nodeCount;
	root = other.root;
	if ( other.root != 0 )
		root = CopyBranch( other.root );
	return *this;
}

#endif



/*
 * Iterator operators.
 */

#ifdef WALKABLE
/* Prefix ++ */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator++()       
{
	ptr = ptr->BASENODE(next);
	return ptr;
}

/* Prefix -- */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator--()       
{
	ptr = ptr->BASENODE(prev);
	return ptr;
}

/* Postfix ++ */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator++(int)       
{
	Node *rtn = ptr; 
	ptr = ptr->BASENODE(next);
	return rtn;
}

/* Postfix -- */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator--(int)       
{
	Node *rtn = ptr;
	ptr = ptr->BASENODE(prev);
	return rtn;
}

/* next */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::next()
{
	ptr = ptr->BASENODE(next);
	return ptr;
}

/* prev */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::prev()
{
	ptr = ptr->BASENODE(prev);
	return ptr;
}
#else

/* Move ahead one. */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::Iterator::
		findNext()
{
	/* Try to go right once then infinite left. */
	if ( ptr->BASENODE(right) != 0 ) {
		ptr = ptr->BASENODE(right);
		while ( ptr->BASENODE(left) != 0 )
			ptr = ptr->BASENODE(left);
	}
	else {
		/* Go up to parent until we were just a left child. */
		while ( true ) {
			Node *last = ptr;
			ptr = ptr->BASENODE(parent);
			if ( ptr == 0 || ptr->BASENODE(left) == last )
				break;
		}
	}
}

/* Move back one. */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::Iterator::
		findPrev()
{
	/* Try to go left once then infinite right. */
	if ( ptr->BASENODE(left) != 0 ) {
		ptr = ptr->BASENODE(left);
		while ( ptr->BASENODE(right) != 0 )
			ptr = ptr->BASENODE(right);
	}
	else {
		/* Go up to parent until we were just a left child. */
		while ( true ) {
			Node *last = ptr;
			ptr = ptr->BASENODE(parent);
			if ( ptr == 0 || ptr->BASENODE(right) == last )
				break;
		}
	}
}


/* Prefix ++ */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator++()       
{
	findNext();
	return ptr;
}

/* Prefix -- */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator--()       
{
	findPrev();
	return ptr;
}

/* Postfix ++ */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator++(int)       
{
	Node *rtn = ptr; 
	findNext();
	return rtn;
}

/* Postfix -- */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::
		operator--(int)       
{
	Node *rtn = ptr;
	findPrev();
	return rtn;
}

/* next */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::next()
{
	findNext();
	return ptr;
}

/* prev */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::Iterator::prev()
{
	findPrev();
	return ptr;
}

#endif


/* Recursive worker for tree copying. */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		CopyBranch( Node *node )
{
	/* Duplicate node. Either the base node's copy constructor or defaul
	 * constructor will get called. Both will suffice for initting the
	 * pointers to null when they need to be. */
	Node *retVal = new Node(*node);

	/* If the left tree is there, copy it. */
	if ( retVal->BASENODE(left) ) {
		retVal->BASENODE(left) = CopyBranch(retVal->BASENODE(left));
		retVal->BASENODE(left)->BASENODE(parent) = retVal;
	}

#ifdef WALKABLE
	BASELIST::addAfter( tail, retVal );
#else
	if ( head == 0 )
		head = retVal;
	tail = retVal;
#endif

	/* If the right tree is there, copy it. */
	if ( retVal->BASENODE(right) ) {
		retVal->BASENODE(right) = CopyBranch(retVal->BASENODE(right));
		retVal->BASENODE(right)->BASENODE(parent) = retVal;
	}
	return retVal;
}

/* Once an insertion position is found, attach a node to the tree. */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::
		AttachRebal( Node *node, Node *parentNode, InsDir direction )
{
	/* Set node's parent. */
	node->BASENODE(parent) = parentNode;

	/* New node always starts as a leaf with height 1. */
	node->BASENODE(left) = 0;
	node->BASENODE(right) = 0;
	node->BASENODE(height) = 1;

	/* Are we inserting in the tree somewhere? */
	if ( parentNode != 0 ) {
		/* We have a parent so we are somewhere in the tree. */
		if (direction == left) {
			parentNode->BASENODE(left) = node;
#ifdef WALKABLE
			BASELIST::addBefore( parentNode, node );
#endif
		}
		else {
			parentNode->BASENODE(right) = node;
#ifdef WALKABLE
			BASELIST::addAfter( parentNode, node );
#endif
		}

#ifndef WALKABLE
		/* Maintain the first and last pointers. */
		if ( head->BASENODE(left) == node )
			head = node;

		/* Maintain the first and last pointers. */
		if ( tail->BASENODE(right) == node )
			tail = node;
#endif
	}
	else {
		/* No parent node so we are inserting the root. */
		root = node;
#ifdef WALKABLE
		BASELIST::addAfter( tail, node );
#else
		head = tail = node;
#endif
	}


	/* Recalculate the heights. */
	RecalcHeights(parentNode);

	/* Find the first unbalance. */
	Node *ub = FindFirstUnbalGP(node);

	/* Rebalance. */
	if ( ub != 0 )
	{
		/* We assert that after this single rotation the 
		 * tree is now properly balanced. */
		Rebalance(ub);
	}
}


/**
 * \brief Insert an existing node into the tree. 
 *
 * If the insert succeeds and lastFound is given then it is set to the node
 * inserted. If the insert fails then lastFound is set to the existing node in
 * the tree that has the same key as node. If the node's avl pointers are
 * already in use then undefined behaviour results.
 * 
 * \returns The node inserted upon success, null upon failure.
 */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		insert( Node *node, Node **lastFound )
{
	int keyRelation;
	Node *curNode = root, *parentNode = 0;
	InsDir direction = left;

	while (true)
	{
		if ( curNode == 0 )
		{
			/* We are at an external node and did not find the
			 * key we were looking for.  */
			nodeCount++;

			/* Attach underneath the leaf and rebalance. */
			AttachRebal( node, parentNode, direction );

			if ( lastFound != 0 )
				*lastFound = node;
			return node;
		}

		keyRelation = BASECOMPARE(compare( node->BASEKEY(getKey()), 
				curNode->BASEKEY(getKey()) ));

		/* Do we go left? */
		if ( keyRelation < 0 )
		{
			direction = left;
			parentNode = curNode;
			curNode = curNode->BASENODE(left);
		}
		/* Do we go right? */
		else if ( keyRelation > 0 )
		{
			direction = right;
			parentNode = curNode;
			curNode = curNode->BASENODE(right);
		}
		/* We have hit the target. */
		else
		{
			if ( lastFound != 0 )
				*lastFound = curNode;
			return 0;
		}
	}
}

/**
 * \brief Insert a new node into the tree with given key.
 *
 * If the key is not already in the tree then a new node is made using the
 * Node(const Key &key) constructor and the insert succeeds. If lastFound is
 * given then it is set to the node inserted. If the insert fails then
 * lastFound is set to the existing node in the tree that has the same key as
 * node.
 * 
 * \returns The new node upon success, null upon failure.
 */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		insert( const Key &key, Node **lastFound )
{
	int keyRelation;
	Node *curNode = root, *parentNode = 0;
	InsDir direction = left;

	while (true)
	{
		if ( curNode == 0 )
		{
			/* We are at an external node and did not find the
			 * key we were looking for.  */
			nodeCount++;

			/* Create the new node. */
			Node *node = new Node( key );

			/* Attach underneath the leaf and rebalance. */
			AttachRebal( node, parentNode, direction );

			if ( lastFound != 0 )
				*lastFound = node;
			return node;
		}

		keyRelation = BASECOMPARE(compare( key, curNode->BASEKEY(getKey()) ));

		/* Do we go left? */
		if ( keyRelation < 0 )
		{
			direction = left;
			parentNode = curNode;
			curNode = curNode->BASENODE(left);
		}
		/* Do we go right? */
		else if ( keyRelation > 0 )
		{
			direction = right;
			parentNode = curNode;
			curNode = curNode->BASENODE(right);
		}
		/* We have hit the target. */
		else
		{
			if ( lastFound != 0 )
				*lastFound = curNode;
			return 0;
		}
	}
}

#if defined( AVLTREE_MAP )
/**
 * \brief Insert a new node into the tree with key and value. 
 *
 * If the key is not already in the tree then a new node is constructed and
 * the insert succeeds. If lastFound is given then it is set to the node
 * inserted. If the insert fails then lastFound is set to the existing node in
 * the tree that has the same key as node. This insert routine is only
 * available in AvlMap because it is the only class that knows about a Value
 * type.
 * 
 * \returns The new node upon success, null upon failure.
 */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		insert( const Key &key, const Value &val, Node **lastFound )
{
	int keyRelation;
	Node *curNode = root, *parentNode = 0;
	InsDir direction = left;

	while (true)
	{
		if ( curNode == 0 )
		{
			/* We are at an external node and did not find the
			 * key we were looking for.  */
			nodeCount++;

			/* Create the new node. */
			Node *node = new Node( key, val );

			/* Attach underneath the leaf and rebalance. */
			AttachRebal( node, parentNode, direction );

			if ( lastFound != 0 )
				*lastFound = node;
			return node;
		}

		keyRelation = BASECOMPARE(compare(key, curNode->getKey()));

		/* Do we go left? */
		if ( keyRelation < 0 )
		{
			direction = left;
			parentNode = curNode;
			curNode = curNode->BASENODE(left);
		}
		/* Do we go right? */
		else if ( keyRelation > 0 )
		{
			direction = right;
			parentNode = curNode;
			curNode = curNode->BASENODE(right);
		}
		/* We have hit the target. */
		else
		{
			if ( lastFound != 0 )
				*lastFound = curNode;
			return 0;
		}
	}
}
#endif


/**
 * \brief Find a node in the tree with the given key.
 *
 * \returns The node if key exists, null if the key does not exist.
 */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		find(const Key &key) const
{
	Node *curNode = root;
	int keyRelation;

	while (curNode) {
		keyRelation = BASECOMPARE(compare( key, curNode->BASEKEY(getKey()) ));

		/* Do we go left? */
		if ( keyRelation < 0 )
			curNode = curNode->BASENODE(left);
		/* Do we go right? */
		else if ( keyRelation > 0 )
			curNode = curNode->BASENODE(right);
		/* We have hit the target. */
		else {
			return curNode;
		}
	}
	return 0;
}


/**
 * \brief Find a node, then detach it from the tree. 
 * 
 * The node is not deleted.
 *
 * \returns The node detached if the key is found, othewise returns null.
 */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		detach(const Key &key)
{
	Node *node = find( key );
	if ( node ) {
		detach(node);
	}

	return node;
}

/**
 * \brief Detach a node from the tree. 
 *
 * If the node is not in the tree then undefined behaviour results.
 * 
 * \returns The node given.
 */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		detach(Node *node)
{
	Node *replacement, *fixfrom;
	int lheight, rheight;

#ifdef WALKABLE
	/* Remove the node from the ordered list. */
	BASELIST::detach( node );
#endif
	
	/* Update nodeCount. */
	nodeCount--;

	/* Find a replacement node. */
	if (node->BASENODE(right))
	{
		/* Find the leftmost node of the right subtree. */
		replacement = node->BASENODE(right);
		while (replacement->BASENODE(left))
			replacement = replacement->BASENODE(left);

		/* If replacing the node the with its child then we need to start
		 * fixing at the replacement, otherwise we start fixing at the
		 * parent of the replacement. */
		if (replacement->BASENODE(parent) == node)
			fixfrom = replacement;
		else
			fixfrom = replacement->BASENODE(parent);

#ifndef WALKABLE
		if ( node == head )
			head = replacement;
#endif

		RemoveNode(replacement, replacement->BASENODE(right));
		ReplaceNode(node, replacement);
	}
	else if (node->BASENODE(left))
	{
		/* Find the rightmost node of the left subtree. */
		replacement = node->BASENODE(left);
		while (replacement->BASENODE(right))
			replacement = replacement->BASENODE(right);

		/* If replacing the node the with its child then we need to start
		 * fixing at the replacement, otherwise we start fixing at the
		 * parent of the replacement. */
		if (replacement->BASENODE(parent) == node)
			fixfrom = replacement;
		else
			fixfrom = replacement->BASENODE(parent);

#ifndef WALKABLE
		if ( node == tail )
			tail = replacement;
#endif

		RemoveNode(replacement, replacement->BASENODE(left));
		ReplaceNode(node, replacement);
	}
	else
	{
		/* We need to start fixing at the parent of the node. */
		fixfrom = node->BASENODE(parent);

#ifndef WALKABLE
		if ( node == head )
			head = node->BASENODE(parent);
		if ( node == tail )
			tail = node->BASENODE(parent);
#endif

		/* The node we are deleting is a leaf node. */
		RemoveNode(node, 0);
	}

	/* If fixfrom is null it means we just deleted
	 * the root of the tree. */
	if ( fixfrom == 0 )
		return node;

	/* Fix the heights after the deletion. */
	RecalcHeights(fixfrom);

	/* Fix every unbalanced node going up in the tree. */
	Node *ub = FindFirstUnbalNode(fixfrom);
	while ( ub )
	{
		/* Find the node to rebalance by moving down from the first unbalanced
		 * node 2 levels in the direction of the greatest heights. On the
		 * second move down, the heights may be equal ( but not on the first ).
		 * In which case go in the direction of the first move. */
		lheight = ub->BASENODE(left) ? ub->BASENODE(left)->BASENODE(height) : 0;
		rheight = ub->BASENODE(right) ? ub->BASENODE(right)->BASENODE(height) : 0;
		assert( lheight != rheight );
		if (rheight > lheight)
		{
			ub = ub->BASENODE(right);
			lheight = ub->BASENODE(left) ?
					ub->BASENODE(left)->BASENODE(height) : 0;
			rheight = ub->BASENODE(right) ? 
					ub->BASENODE(right)->BASENODE(height) : 0;
			if (rheight > lheight)
				ub = ub->BASENODE(right);
			else if (rheight < lheight)
				ub = ub->BASENODE(left);
			else
				ub = ub->BASENODE(right);
		}
		else
		{
			ub = ub->BASENODE(left);
			lheight = ub->BASENODE(left) ? 
					ub->BASENODE(left)->BASENODE(height) : 0;
			rheight = ub->BASENODE(right) ? 
					ub->BASENODE(right)->BASENODE(height) : 0;
			if (rheight > lheight)
				ub = ub->BASENODE(right);
			else if (rheight < lheight)
				ub = ub->BASENODE(left);
			else
				ub = ub->BASENODE(left);
		}


		/* Rebalance returns the grandparant of the subtree formed
		 * by the nodes that were rebalanced.
		 * We must continue upward from there rebalancing. */
		fixfrom = Rebalance(ub);

		/* Find the next unbalaced node. */
		ub = FindFirstUnbalNode(fixfrom);
	}

	return node;
}

/**
 * \brief Detach and delete a node from the tree. 
 *
 * If the node is not in the tree then undefined behaviour results.
 */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::
		remove(Node *node)
{
	/* Detach and delete. */
	detach(node);
	delete node;
}

/**
 * \brief Find, detach and delete a node from the tree. 
 *
 * \returns True if the node was found and deleted, false otherwise.
 */
template <AVLMEL_TEMPDEF> bool AvlTree<AVLMEL_TEMPUSE>::
		remove(const Key &key)
{
	/* Assume not found. */
	bool retVal = false;

	/* Look for the key. */
	Node *node = find( key );
	if ( node != 0 ) {
		/* If found, detach the node and delete. */
		detach( node );
		delete node;
		retVal = true;
	}

	return retVal;
}

/**
 * \brief Empty the tree and delete all the nodes. 
 *
 * Resets the tree to its initial state.
 */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::empty()
{
	if ( root ) {
		/* Recursively delete from the tree structure. */
		DeleteChildrenOf(root);
		delete root;
		root = 0;
		nodeCount = 0;

#ifdef WALKABLE
		head = 0;
		tail = 0;
		length = 0;
#endif
	}
}

/**
 * \brief Forget all nodes in the tree. 
 *
 * Does not delete nodes. Resets the the tree to it's initial state.
 */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::abandon()
{
	root = 0;
	nodeCount = 0;

#ifdef WALKABLE
	head = 0;
	tail = 0;
	length = 0;
#endif
}

/* Recursively delete all the children of a node. */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::
		DeleteChildrenOf( Node *node )
{
	/* Recurse left. */
	if (node->BASENODE(left)) {
		DeleteChildrenOf(node->BASENODE(left));

		/* Delete left node. */
		delete node->BASENODE(left);
		node->BASENODE(left) = 0;
	}

	/* Recurse right. */
	if (node->BASENODE(right)) {
		DeleteChildrenOf(node->BASENODE(right));

		/* Delete right node. */
		delete node->BASENODE(right);
		node->BASENODE(left) = 0;
	}
}

/* Rebalance from a node whose gradparent is unbalanced. Only
 * call on a node that has a grandparent. */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		Rebalance(Node *n)
{
	int lheight, rheight;
	Node *a, *b, *c;
	Node *t1, *t2, *t3, *t4;

	Node *p = n->BASENODE(parent);      /* parent (Non-NUL). L*/
	Node *gp = p->BASENODE(parent);     /* Grand-parent (Non-NULL). */
	Node *ggp = gp->BASENODE(parent);   /* Great grand-parent (may be NULL). */

	if (gp->BASENODE(right) == p)
	{
		/*  gp
		 *   \
		 *    p
		 */
		if (p->BASENODE(right) == n)
		{
			/*  gp
			 *   \
			 *    p
			 *     \
			 *      n
			 */
			a = gp;
			b = p;
			c = n;
			t1 = gp->BASENODE(left);
			t2 = p->BASENODE(left);
			t3 = n->BASENODE(left);
			t4 = n->BASENODE(right);
		}
		else
		{
			/*  gp
			 *     \
			 *       p
			 *      /
			 *     n
			 */
			a = gp;
			b = n;
			c = p;
			t1 = gp->BASENODE(left);
			t2 = n->BASENODE(left);
			t3 = n->BASENODE(right);
			t4 = p->BASENODE(right);
		}
	}
	else
	{
		/*    gp
		 *   /
		 *  p
		 */
		if (p->BASENODE(right) == n)
		{
			/*      gp
			 *    /
			 *  p
			 *   \
			 *    n
			 */
			a = p;
			b = n;
			c = gp;
			t1 = p->BASENODE(left);
			t2 = n->BASENODE(left);
			t3 = n->BASENODE(right);
			t4 = gp->BASENODE(right);
		}
		else
		{
			/*      gp
			 *     /
			 *    p
			 *   /
			 *  n
			 */
			a = n;
			b = p;
			c = gp;
			t1 = n->BASENODE(left);
			t2 = n->BASENODE(right);
			t3 = p->BASENODE(right);
			t4 = gp->BASENODE(right);
		}
	}

	/* Perform rotation.
	 */

	/* Tie b to the great grandparent. */
	if ( ggp == 0 )
		root = b;
	else if ( ggp->BASENODE(left) == gp )
		ggp->BASENODE(left) = b;
	else
		ggp->BASENODE(right) = b;
	b->BASENODE(parent) = ggp;

	/* Tie a as a leftchild of b. */
	b->BASENODE(left) = a;
	a->BASENODE(parent) = b;

	/* Tie c as a rightchild of b. */
	b->BASENODE(right) = c;
	c->BASENODE(parent) = b;

	/* Tie t1 as a leftchild of a. */
	a->BASENODE(left) = t1;
	if ( t1 != 0 ) t1->BASENODE(parent) = a;

	/* Tie t2 as a rightchild of a. */
	a->BASENODE(right) = t2;
	if ( t2 != 0 ) t2->BASENODE(parent) = a;

	/* Tie t3 as a leftchild of c. */
	c->BASENODE(left) = t3;
	if ( t3 != 0 ) t3->BASENODE(parent) = c;

	/* Tie t4 as a rightchild of c. */
	c->BASENODE(right) = t4;
	if ( t4 != 0 ) t4->BASENODE(parent) = c;

	/* The heights are all recalculated manualy and the great
	 * grand-parent is passed to RecalcHeights() to ensure
	 * the heights are correct up the tree.
	 *
	 * Note that RecalcHeights() cuts out when it comes across
	 * a height that hasn't changed.
	 */

	/* Fix height of a. */
	lheight = a->BASENODE(left) ? a->BASENODE(left)->BASENODE(height) : 0;
	rheight = a->BASENODE(right) ? a->BASENODE(right)->BASENODE(height) : 0;
	a->BASENODE(height) = (lheight > rheight ? lheight : rheight) + 1;

	/* Fix height of c. */
	lheight = c->BASENODE(left) ? c->BASENODE(left)->BASENODE(height) : 0;
	rheight = c->BASENODE(right) ? c->BASENODE(right)->BASENODE(height) : 0;
	c->BASENODE(height) = (lheight > rheight ? lheight : rheight) + 1;

	/* Fix height of b. */
	lheight = a->BASENODE(height);
	rheight = c->BASENODE(height);
	b->BASENODE(height) = (lheight > rheight ? lheight : rheight) + 1;

	/* Fix height of b's parents. */
	RecalcHeights(ggp);
	return ggp;
}

/* Recalculates the heights of all the ancestors of node. */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::
		RecalcHeights(Node *node)
{
	int lheight, rheight, new_height;
	while ( node != 0 )
	{
		lheight = node->BASENODE(left) ? node->BASENODE(left)->BASENODE(height) : 0;
		rheight = node->BASENODE(right) ? node->BASENODE(right)->BASENODE(height) : 0;

		new_height = (lheight > rheight ? lheight : rheight) + 1;

		/* If there is no chage in the height, then there will be no
		 * change in any of the ancestor's height. We can stop going up.
		 * If there was a change, continue upward. */
		if (new_height == node->BASENODE(height))
			return;
		else
			node->BASENODE(height) = new_height;

		node = node->BASENODE(parent);
	}
}

/* Finds the first node whose grandparent is unbalanced. */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		FindFirstUnbalGP(Node *node)
{
	int lheight, rheight, balanceProp;
	Node *gp;

	if ( node == 0 || node->BASENODE(parent) == 0 ||
			node->BASENODE(parent)->BASENODE(parent) == 0 )
		return 0;
	
	/* Don't do anything if we we have no grandparent. */
	gp = node->BASENODE(parent)->BASENODE(parent);
	while ( gp != 0 )
	{
		lheight = gp->BASENODE(left) ? gp->BASENODE(left)->BASENODE(height) : 0;
		rheight = gp->BASENODE(right) ? gp->BASENODE(right)->BASENODE(height) : 0;
		balanceProp = lheight - rheight;

		if ( balanceProp < -1 || balanceProp > 1 )
			return node;

		node = node->BASENODE(parent);
		gp = gp->BASENODE(parent);
	}
	return 0;
}


/* Finds the first node that is unbalanced. */
template <AVLMEL_TEMPDEF> Node *AvlTree<AVLMEL_TEMPUSE>::
		FindFirstUnbalNode(Node *node)
{
	if ( node == 0 )
		return 0;
	
	while ( node != 0 )
	{
		int lheight = node->BASENODE(left) ? 
				node->BASENODE(left)->BASENODE(height) : 0;
		int rheight = node->BASENODE(right) ? 
				node->BASENODE(right)->BASENODE(height) : 0;
		int balanceProp = lheight - rheight;

		if ( balanceProp < -1 || balanceProp > 1 )
			return node;

		node = node->BASENODE(parent);
	}
	return 0;
}

/* Replace a node in the tree with another node not in the tree. */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::
		ReplaceNode(Node *node, Node *replacement)
{
	Node *parent = node->BASENODE(parent),
		*left = node->BASENODE(left),
		*right = node->BASENODE(right);

	replacement->BASENODE(left) = left;
	if (left)
		left->BASENODE(parent) = replacement;
	replacement->BASENODE(right) = right;
	if (right)
		right->BASENODE(parent) = replacement;

	replacement->BASENODE(parent) = parent;
	if (parent)
	{
		if (parent->BASENODE(left) == node)
			parent->BASENODE(left) = replacement;
		else
			parent->BASENODE(right) = replacement;
	}
	else
		root = replacement;

	replacement->BASENODE(height) = node->BASENODE(height);
}

/* Removes a node from a tree and puts filler in it's place.
 * Filler should be null or a child of node. */
template <AVLMEL_TEMPDEF> void AvlTree<AVLMEL_TEMPUSE>::
		RemoveNode(Node *node, Node *filler)
{
	Node *parent = node->BASENODE(parent);

	if (parent)
	{
		if (parent->BASENODE(left) == node)
			parent->BASENODE(left) = filler;
		else
			parent->BASENODE(right) = filler;
	}
	else
		root = filler;
	
	if (filler)
		filler->BASENODE(parent) = parent;

	return;
}

#ifdef AAPL_NAMESPACE
}
#endif

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "gotocodegen.h"
#include "bstmap.h"

using std::endl;

/* Init base data. */
GotoCodeGen::GotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	FsmCodeGen(fsmName, machine, parseData, out),
	needErrorLabel(false)
{
}

/* Emit the goto to take for a given transition. */
std::ostream &GotoCodeGen::TRANS_GOTO( FsmMachTrans *trans, int level )
{
	if ( trans->funcs != FUNC_NO_FUNC )
		TABS(level) << "goto tr" << trans - machine->allTrans << ";";
	else {
		/* Get the index of the state we go to. */
		if ( trans->toState != STATE_ERR_STATE )
			TABS(level) << "goto st" << trans->toState << ";";
		else {
			TABS(level) << "goto err;";
			needErrorLabel = true;
		}
	}
	return out;
}

void GotoCodeGen::emitRangeBSearch( FsmMachState *state, int level, int low, int high )
{
	/* Get the mid position, staying on the lower end of the range. */
	int mid = ((low + high) / 2) & ~1;

	/* Get the transition to take on hitting the mid. */
	FsmMachTrans *trans = &machine->allTrans[state->rangeIndPtr[mid/2]];

	/* Determine if we need to look higher or lower. */
	bool anyLower = mid != low;
	bool anyHigher = mid != high;

	/* Determine if the keys at mid are the limits of the alphabet. */
	bool limitLow = state->rangeIndKey[mid] == parseData->lowerKey;
	bool limitHigh = state->rangeIndKey[mid+1] == parseData->upperKey;

	if ( anyLower && anyHigher ) {
		/* Can go lower and higher than mid. */
		TABS(level) << "if ( *p < "; KEY(state->rangeIndKey[mid]) << " ) {\n";
		emitRangeBSearch( state, level+1, low, mid-2 );
		TABS(level) << "} else if ( *p > "; KEY(state->rangeIndKey[mid+1]) << " ) {\n";
		emitRangeBSearch( state, level+1, mid+2, high );
		TABS(level) << "} else\n";
		TRANS_GOTO(trans, level+1) << "\n";
	}
	else if ( anyLower && !anyHigher ) {
		/* Can go lower than mid but not higher. */
		TABS(level) << "if ( *p < "; KEY(state->rangeIndKey[mid]) << " ) {\n";
		emitRangeBSearch( state, level+1, low, mid-2 );

		/* if the higher is the highest in the alphabet then there is no
		 * sense testing it. */
		if ( limitHigh ) {
			TABS(level) << "} else\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			TABS(level) << "} else if ( *p <= "; KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
	else if ( !anyLower && anyHigher ) {
		/* Can go higher than mid but not lower. */
		TABS(level) << "if ( *p > "; KEY(state->rangeIndKey[mid+1]) << " ) {\n";
		emitRangeBSearch( state, level+1, mid+2, high );

		/* If the lower end is the lowest in the alphabet then there is no
		 * sense testing it. */
		if ( limitLow ) {
			TABS(level) << "} else\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			TABS(level) << "} else if ( *p >= "; KEY(state->rangeIndKey[mid]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
	else {
		/* Cannot go higher or lower than mid. It's mid or bust. What
		 * tests to do depends on limits of alphabet. */
		if ( !limitLow && !limitHigh ) {
			TABS(level) << "if ( "; KEY(state->rangeIndKey[mid]) << " <= *p && *p <= ";
				KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else if ( limitLow && !limitHigh ) {
			TABS(level) << "if ( *p <= "; KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else if ( !limitLow && limitHigh ) {
			TABS(level) << "if ( "; KEY(state->rangeIndKey[mid]) << " <= *p )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			/* Both high and low are at the limit. No tests to do. */
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
}

/* Write the switch of functions a la tabcodegen. */
std::ostream &GotoCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	StringListEl *flel = parseData->funcList.head;
	int fnum = 0;
	while ( flel != NULL ) {
		out << "\tcase " << fnum << ": {\n";
		out << flel->data;
		out << "break;}" << endl;
		fnum += 1;
		flel = flel->next;
	}
	return out;
}


/* Emit the switch statement for jumping into the machine. Our current state
 * is represented by an integer and we need to use it to get into the correct
 * place in the machine. */
std::ostream &GotoCodeGen::JUMP_IN_SWITCH()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "\t\tcase " << st << ": goto st" << st << ";\n";
	}
	out << "\t\tdefault: return;\n";
	return out;
};

std::ostream &GotoCodeGen::STATE_GOTOS()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Emit any transitions that have functions and that go to 
		 * this state. */
		FsmMachTrans *trans = machine->allTrans;
		for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
			if ( trans->toState == st && trans->funcs != FUNC_NO_FUNC ) {
				/* Write the label for the transition so it can be jumped to. */
				out << "tr" << tr << ":\n";

				/* Write out the specific machine's representation of 
				 * executing the funcs. */
				transFunc( trans );

				out << "\tgoto st" << st << ";\n";
			}
		}

		out << "st" << st << ":\n";
		out << "\tif ( --len == 0 )\n";
		out << "\t\tgoto out" << st << ";\n";

		/* Get the fsm machine state. */
		FsmMachState *state = machine->allStates+st;

		if ( state->numIndex == 0 ) {
			/* If there are no single keys. We need to at least advance the
			 * pointer to the current char. */
			out << "\t++p;\n";
		}
		if ( state->numIndex == 1 ) {
			/* If there is a single single key then write it out as an if. */
			out << "\tif ( *++p == "; KEY(state->transIndKey[0]) << " )\n\t\t"; 
			TRANS_GOTO(&machine->allTrans[state->transIndPtr[0]], 0) << "\n";
		}
		else if ( state->numIndex > 1 ) {
			/* Write out single keys in a switch if there is more than one. */
			out << "\tswitch( *++p ) {\n";

			/* Write out the single indicies. */
			for ( int j = 0; j < state->numIndex; j++ ) {
				out << "\t\tcase "; KEY(state->transIndKey[j]) << ": ";

				/* Emit the transition. */
				FsmMachTrans *trans = &machine->allTrans[state->transIndPtr[j]];
				TRANS_GOTO(trans, 0) << "\n";
			}
			/* Close off the transition switch. */
			out << "\t}\n";
		}

		/* Default case is to binary search for the ranges, if that fails then */
		if ( state->numRange > 0 )
			emitRangeBSearch( state, 1, 0, (state->numRange-1)*2 );

		/* Get the default index and write it. Default will always be used. */
		trans = &machine->allTrans[state->dflIndex];
		TRANS_GOTO( trans, 1 ) << "\n";
	}
	return out;
}

std::ostream &GotoCodeGen::EXIT_STATES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "out" << st << ":\n\t";
		FSM_PREFIX() << "curState = " << st << ";\n" << "\treturn;\n";
	}
	return out;
}

std::ostream &GotoCodeGen::FINISH_SWITCH()
{
	out << "\tswitch( cs ) {" << endl;
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		out << "\t\tcase " << st << ": ";
		if ( state->isFinState )
			out << "accept = 1; ";

		/* If there are out functions, write them. */
		if ( state->outFuncs != FUNC_NO_FUNC ) {
			int *funcs = machine->allTransFuncs + 
					machine->transFuncIndex[state->outFuncs];

			/* The first number is the length. */
			int flen = *funcs++;
			while ( flen-- > 0 ) {
				out << "{" << getCodeBuiltin(*funcs) << "}";
				funcs += 1;
			}
		}
		out << "break;" << endl;
	}
	out << "\t}\n";
	return out;
}

std::ostream &GotoCodeGen::ERROR_LABEL()
{
	if ( needErrorLabel ) {
		out << "err:\n\t"; 
		FSM_PREFIX() << "curState = -1;\n";
	}
	return out;
}

/* Init base data. */
CGotoCodeGen::CGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out ) 
: 
	GotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\t";
	FSM_NAME();
	out << "ExecFuncs( fsm, f+" << machine->transFuncIndex[state->outFuncs]
			<< ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit them the call the execute them. */
	out << "\t";
	FSM_NAME();
	out << "ExecFuncs( fsm, f+" << machine->transFuncIndex[trans->funcs]
			<< ", p );\n";
}


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}


void CGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"#define f "; FSM_NAME() << "_f\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Function exection. We do not inline this as in tab\n"
		" * code gen because if we did, we might as well just expand \n"
		" * the function as in the faster goto code generator. */\n"
		"static void "; FSM_NAME() << "ExecFuncs( "; FSM_NAME() << 
				" *fsm, int *funcs, "; ALPH_TYPE() << " *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() <<
		"		}\n"
		"	}\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data - 1;\n"
		"	int len = dlen + 1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( "; FSM_PREFIX() << "curState ) {\n";
		JUMP_IN_SWITCH() <<
		"	}\n"
		"\n";
		STATE_GOTOS() <<
		"\n";
		EXIT_STATES() <<
		"\n";
		ERROR_LABEL() <<
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int cs = fsm->curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() <<
		"	fsm->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n"
		"#undef f\n"
		"\n";
}

/* Init base data. */
CCGotoCodeGen::CCGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	GotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( f+" << machine->transFuncIndex[state->outFuncs]
			<< ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( f+" << machine->transFuncIndex[trans->funcs] 
			<< ", p );\n";
}

/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n"
		"	/* The start state. */\n"
		"	static int startState;\n"
		"\n"
		"	/* Function exection. We do not inline this as in tab code gen\n"
		"	 * because if we did, we might as well just expand the function \n"
		"	 * as in the faster goto code generator. */\n"
		"	void ExecFuncs( int *funcs, "; ALPH_TYPE() << " *p );\n"
		"\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"\n";
}

void CCGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"#define f "; FSM_NAME() << "_f\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* Make sure the fsm is initted. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = startState;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"void "; FSM_NAME() << "::ExecFuncs( int *funcs, "; ALPH_TYPE() << " *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() <<
		"		}\n"
		"	}\n"
		"}\n"
		"\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data - 1;\n"
		"	int len = dlen + 1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( curState ) {\n";
		JUMP_IN_SWITCH() << "\n"
		"	}\n"
		"\n";
		STATE_GOTOS() <<
		"\n";
		EXIT_STATES() <<
		"\n";
		ERROR_LABEL() <<
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int cs = curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	this->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n"
		"#undef f\n"
		"\n";
}

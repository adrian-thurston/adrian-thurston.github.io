/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMATTACH_CPP
#define _RLFSM_FSMATTACH_CPP

#include <string.h>
#include <assert.h>

/* Insert a transition into an inlist. The head must be supplied. Also sets
 * fromState and toState. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		attachTrans( State *from, State *to, Transition *&head, Transition *trans )
{
	/* Assert that the state is not attached. */
	assert( trans->fromState == 0 );
	assert( trans->toState == 0 );

	trans->next = head;
	trans->prev = 0;

	/* If in trans list is not empty, set the head->prev to trans. */
	if ( head )
		head->prev = trans;

	/* Now insert ourselves at the front of the list. */
	head = trans;

	/* The transition is now attached. Remember the parties involved. */
	trans->fromState = from;
	trans->toState = to;

	/* Keep track of foreign transitions for from and to. */
	if ( from != to ) {
		if ( misfitAccounting ) {
			/* If the number of foreign in transitions is about to go up to 1 then
			 * move it from the misfit list to the main list. */
			if ( to->foreignInTrans == 0 )
				stateList.append( misfitList.detach( to ) );
		}
		
		to->foreignInTrans += 1;
	}
};

/* Detach a transition from an inlist. The head of the inlist must be supplied.
 * Also reset the transitions's fromState and toState pointers. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		detachTrans( State *from, State *to, Transition *&head, Transition *trans )
{
	/* Assert that the state is indeed attached. */
	assert( trans->fromState == from );
	assert( trans->toState == to );

	/* Detach in the inTransList. */
	if ( trans->prev == 0 ) 
		head = trans->next; 
	else
		trans->prev->next = trans->next; 

	if ( trans->next != 0 ) 
		trans->next->prev = trans->prev; 
	
	/* A detached state does not link any states. */
	trans->fromState = 0;
	trans->toState = 0;

	/* Keep track of foreign transitions for from and to. */
	if ( from != to ) {
		to->foreignInTrans -= 1;
		
		if ( misfitAccounting ) {
			/* If the number of foreign in transitions goes down to 0 then move it
			 * from the main list to the misfit list. */
			if ( to->foreignInTrans == 0 )
				misfitList.append( stateList.detach( to ) );
		}
	}
}

/* Attach states on the default transition, range list or on out/in list key.
 * Type of attaching and the onChar used is controlled by keyType. First makes
 * a new transition. If there is already a transition out from fromState on the
 * default, then will assertion fail. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		attachStates( State *from, State *to, FsmKeyType keyType, 
			FsmKey onChar1, FsmKey onChar2 )
{
	/* Make the new transition. */
	Transition *retVal = new Transition();

	switch ( keyType ) {
	case KeyTypeSingle: {
		/* Make a ptr for the new transition. If one is there already, then
		 * assertion fail. */
		TransEl *outTel = from->outList.insertSingle( onChar1, isAlphSigned );
		assert( outTel != 0 );

		/* Set the out list pointer to the new trans. */
		outTel->value = retVal;

		/* Set the lower key so we can map the transition back to the record
		 * in the from state's outList. */
		retVal->lowerKey = onChar1;

		/* Attach using the inList pointer as the head pointer. */
		attachTrans( from, to, to->inListHead, retVal );
		break;
	}
	case KeyTypeRange: {
		TransEl *outTel1, *outTel2;

		/* Make the out ptrs for the new transition. We need outTel1 immediately
		 * before outTel2. Note that the onChar's may be the same. If the insert
		 * of onChar1 fails then assertion fail on the grounds of overlap. */
		outTel1 = from->outRange.insertSingle( onChar1, isAlphSigned );
		assert( outTel1 != 0 );

		/* Use the vector insert to insert the high end of the range into 
		 * the table. The high end may be the same as the low end. */
		int outTelInd = outTel1 - from->outRange.data;
		from->outRange.TransListVect::insert( outTelInd+1, TransEl( onChar2, 0 ) );

		/* Get the two entries as pointers. */
		outTel1 = &from->outRange.data[outTelInd];
		outTel2 = &from->outRange.data[outTelInd+1];

		/* Set the out list pointer to the new trans. Both low and high get
		 * the same ptr. */
		outTel1->value = retVal;
		outTel2->value = retVal;

		/* Set the lower key in the trans so we can map the trans back to the
		 * record in the outRange. */
		retVal->lowerKey = onChar1;

		/* Attach using inRange as the head pointer. */
		attachTrans( from, to, to->inRangeHead, retVal );
		break;
	}
	case KeyTypeDefault: {
		/* If there is already a default, then assertion fail. */
		assert( from->outDefault == 0 );

		/* Attach using the new transition and defInTrans as the head. */
		from->outDefault = retVal;

		/* The lower key is not used for default transitions, but set it for
		 * consistency anyways. */
		retVal->lowerKey = onChar1;

		/* Attach using inDef as the head pointer. */
		attachTrans( from, to, to->inDefHead, retVal );
		break;
	}}

	return retVal;
}

/* Attach for out/in lists, range lists or for default transition. Type of
 * attaching is controlled by the keyType parameter. This attach should be
 * used when a transition already is allocated and it must be attached. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		attachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, FsmKey onChar )
{
	switch ( keyType ) {
	case KeyTypeSingle: {
		/* Set the lower key so we can map the transition back to the record
		 * in the from state's outList. */
		trans->lowerKey = onChar;

		/* Attach using the inList pointer as the head pointer. */
		attachTrans( from, to, to->inListHead, trans );
		break;
	}
	case KeyTypeRange: {
		/* Set the lower key in the trans so we can map the trans back to the
		 * record in the outRange. */
		trans->lowerKey = onChar;

		/* Attach using the inRange pointer as the head pointer. */
		attachTrans( from, to, to->inRangeHead, trans );
		break;
	}
	case KeyTypeDefault: {
		/* Lower char is not used. */
		trans->lowerKey = 0;

		/* Attach using inDef as the head pointer. */
		attachTrans( from, to, to->inDefHead, trans );
		break;
	}}
}

/* Detach for out/in lists or for default transition. The type of detaching is
 * controlled by the keyType parameter. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		detachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, FsmKey onChar )
{
	switch ( keyType ) {
	case KeyTypeSingle: {
		/* Detach using to's inList as the head pointer. */
		detachTrans( from, to, to->inListHead, trans );
		break;
	}
	case KeyTypeRange: {
		/* Detach using to's inRange pointer as the head. */
		detachTrans( from, to, to->inRangeHead, trans );
		break;
	}
	case KeyTypeDefault: {
		/* Detach using the to's inDefHead as the head pointer. */
		detachTrans( from, to, to->inDefHead, trans );
		break;
	}}
}


/* Detach a state from the graph. Detaches and deletes transitions in and out
 * of the state. Empties inList and outList. Removes the state from the final
 * state set. A detached state becomes useless and should be deleted. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		detachState( State *state )
{
	/* Detach the in transitions from the inList list of transitions. */
	while ( state->inListHead != 0 ) {
		/* Get pointers to the trans and the state. */
		Transition *trans = state->inListHead;
		State *fromState = trans->fromState;

		/* Detach the transitions from the source state. */
		detachStates( fromState, state, trans, KeyTypeSingle, trans->lowerKey );

		/* Search for a range in from list that this key is in. */
		TransEl *rangeEl = fromState->outRange.findRange( trans->lowerKey, isAlphSigned );

		/* If the key is in a range of from or if from has a default
		 * transition we cannont delete the key-value pair from it's out
		 * list because that effectively adds the key to the set of keys
		 * following the range or the default trans. Instead null out the
		 * transition pointer. */
		if ( rangeEl != 0 || fromState->outDefault != 0 ) {
			/* From has a default transition, we must null out the trans ptr. */
			TransEl *fromTel = fromState->outList.findSingle( trans->lowerKey, isAlphSigned );
			fromTel->value = 0;
		}
		else {
			/* There is no default trans, safe to remove the key-value pair. */
			fromState->outList.removeSingle( trans->lowerKey, isAlphSigned );
		}

		/* Finished with the transition. */
		delete trans;
	}

	/* Detach the in transitions from the inRange list of transitions. */
	while ( state->inRangeHead ) {
		/* Get pointers to the trans and the state. */
		Transition *trans = state->inRangeHead;
		State *fromState = trans->fromState;

		/* Detach the transitions from the source state. */
		detachStates( fromState, state, trans, KeyTypeRange, trans->lowerKey );

		/* Find the transition element in from's out range. It should
		 * always be there. . */
		TransEl *fromTel = fromState->outRange.findLower( trans->lowerKey, isAlphSigned );
		assert( fromTel != 0 );

		/* If from has a default transition we cannot delete the key-value
		 * pair from it's out range because that effectively adds the keys to
		 * the set of keys following the default trans.  Instead null out
		 * the transition pointer. */
		if ( fromState->outDefault != 0 ) {
			/* From has a default transition, we must null out the trans ptr. */
			fromTel[0].value = 0;
			fromTel[1].value = 0;
		}
		else {
			/* Remove two items at pos fromTel. Uses Vector::remove. */
			int pos = fromTel - fromState->outRange.data;
			fromState->outRange.TransListVect::remove( pos, 2 );
		}

		/* Finished with the transition. */
		delete trans;
	}

	/* Detach default in transitions. */
	while ( state->inDefHead ) {
		/* Get pointers to the trans and the state. */
		Transition *trans = state->inDefHead;
		State *fromState = trans->fromState;

		/* Detach. */
		detachStates( fromState, state, trans, KeyTypeDefault, 0 );

		/* From state no longer has a default trans, null it out. */
		fromState->outDefault = 0;

		/* Finsished with the trans. */
		delete trans;
	}

	/* Remove the entry points in on the machine. */
	int *entryId = state->entryIds.data;
	int i, numEntryIds = state->entryIds.length;
	for ( i = 0; i < numEntryIds; i++, entryId++ ) {
		EntryEl *entryEl = entryPoints.find( *entryId );
		assert( entryEl != 0 );
		entryPoints.remove( entryEl );
	}

	/* Clear the entry ids. */
	state->entryIds.empty();

	/* Detach the out transitions. */
	TransEl *tel = state->outList.data;
	int ntel = state->outList.length;
	for ( i = 0; i < ntel; i++, tel++ ) {
		if ( tel->value != 0 ) {
			detachStates( state, tel->value->toState, tel->value, 
					KeyTypeSingle, tel->key );
			delete tel->value;
		}
	}

	/* Delete all of the out transition pointers. */
	state->outList.empty();

	/* Detach out range transitions. */
	tel = state->outRange.data;
	ntel = state->outRange.length;
	for ( i = 0; i < ntel; i+=2, tel+=2 ) {
		if ( tel->value != 0 ) {
			detachStates( state, tel->value->toState, tel->value,
					KeyTypeRange, tel->key );
			delete tel->value;
		}
	}

	/* Delete all of the out range pointers. */
	state->outRange.empty();

	/* Detach the default out transition. */
	if ( state->outDefault != 0 ) {
		detachStates( state, state->outDefault->toState, state->outDefault, 
				KeyTypeDefault, 0 );
		delete state->outDefault;
	}

	/* Unset final stateness before detaching from graph. */
	if ( state->stateBits & SB_ISFINAL )
		finStateSet.remove( state );
}


/* Duplicate a transition. Makes a new transition that is attached to the same
 * dest as srcTrans. The new transition has functions and priority taken from
 * srcTrans. If leavingFsm is set, then outPrior and outFuncs are taken from
 * the from state. Used for merging a transition in to a free spot. The trans
 * can just be dropped in. It does not conflict with an existing trans and need
 * not be crossed. Returns the new transition. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		dupTrans( State *from, FsmKeyType keyType, FsmKey onChar,
			Transition *srcTrans, bool leavingFsm )
{
	/* Make a new transition. */
	Transition *newTrans = new Transition();

	/* We can attach the transition, one does not exist. */
	attachStates( from, srcTrans->toState, newTrans, keyType, onChar );
		
	/* Call the user callback to add in the original source transition. */
	newTrans->addInTrans( srcTrans );

	/* Add in the from state's out data. This will pickup any out functions or
	 * and/or set the priority from the out prior. This must happen after the
	 * adding in of the trans, so that out priority overrides the priority
	 * from the source trans. */
	if ( leavingFsm )
		newTrans->leavingFromState( from );

	return newTrans;
}


/* In crossing, src trans overwrites the existing one because it has a
 * higher priority. The existing destTrans is deleted and replaced with
 * a copy of srcTrans. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		overwriteTrans( MergeData &md, State *from, FsmKeyType keyType, FsmKey onChar,
			Transition *destTrans, Transition *srcTrans, bool leavingFsm )
{
	/* Toast the existing transition. */
	detachStates( from, destTrans->toState, destTrans, keyType, onChar );

	/* Delete the existing transition, it is being replaced and make a brand
	 * new one to replace it. This is for completeness of concept. Fsm graphs
	 * built on top of this template expect it. */
	delete destTrans;
	Transition *newTrans = new Transition();

	/* We can attach the transition, one does not exist. */
	attachStates( from, srcTrans->toState, newTrans, keyType, onChar );

	/* Add in src trans to the new transition. We don't need to merge in the
	 * from out trans data, that was done already. */
	newTrans->addInTrans( srcTrans );

	/* Return the replacement transition. */
	return newTrans;
}

/* In crossing, src trans and dest trans go to two different states. Make one
 * state from the sets of states that src and dest trans go to. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		fsmAttachStates( MergeData &md, State *from, FsmKeyType keyType, 
			FsmKey onChar, Transition *destTrans, Transition *srcTrans, 
			bool leavingFsm )
{
	/* The priorities are equal. We must merge the transitions. Does the
	 * existing trans go to the state we are to attach to? ie, are we to
	 * simply double up the transition? */
	State *toState = srcTrans->toState;
	State *existingState = destTrans->toState;

	if ( existingState == toState ) {
		/* The transition is a double up to the same state.  Copy the src
		 * trans into itself. We don't need to merge in the from out trans
		 * data, that was done already. */
		destTrans->addInTrans( srcTrans );
	}
	else {
		/* The trans is not a double up. Dest trans cannot be the same as src
		 * trans. Set up the state set. */
		StateSet stateSet;

		/* We go to all the states the existing trans goes to, plus... */
		if ( existingState->stateDictNode == 0 )
			stateSet.insert( existingState );
		else
			stateSet.insert( existingState->stateDictNode->stateSet );

		/* ... all the states that we have been told to go to. */
		if ( toState->stateDictNode == 0 )
			stateSet.insert( toState );
		else
			stateSet.insert( toState->stateDictNode->stateSet );

		/* Look for the state. If it is not there already, make it. */
		FsmSDNode<State> *lastFound;
		if ( md.stateDict.insert( stateSet, &lastFound ) ) {
			/* Make a new state representing the combination of states in
			 * stateSet. It gets added to the fill list.  This means that we
			 * need to fill in it's transitions sometime in the future.  We
			 * don't do that now (ie, do not recurse). */
			State *combinState = newState();

			/* Link up the dict node and the state. */
			lastFound->targState = combinState;
			combinState->stateDictNode = lastFound;

			/* Add to the fill list. */
			md.fillListAppend( combinState );
		}

		/* Get the state insertted/deleted. */
		State *targ = lastFound->targState;

		/* Detach the state from existing state. */
		detachStates( from, existingState, destTrans, keyType, onChar );

		/* Re-attach to the new target. */
		attachStates( from, targ, destTrans, keyType, onChar );

		/* Add in src trans to the existing transition that we redirected to
		 * the new state. We don't need to merge in the from out trans data,
		 * that was done already. */
		destTrans->addInTrans( srcTrans );
	}

	return destTrans;
}

/* Find the trans with the higher priority. If src is lower priority then dest then
 * src is ignored. If src is higher priority than dest, then src overwrites dest. If
 * the priorities are equal, then they are merged. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		crossTransitions( MergeData &md, State *from, FsmKeyType keyType, 
			FsmKey onChar, Transition *destTrans, Transition *srcTrans, 
			bool leavingFsm )
{
	Transition *retTrans, *dupSrcTrans;

	/* Set up a dummy transition that will serve as the source transition.
	 * This duplicate will be set as an out trans from the from state and then
	 * it will be used for the cross. This lets the source pick up any out
	 * transition date of from before priorities are compared. */
	dupSrcTrans = new Transition();
	dupSrcTrans->fromState = srcTrans->fromState;
	dupSrcTrans->toState = srcTrans->toState;

	/* Add in the original source transition. */
	dupSrcTrans->addInTrans( srcTrans );

	/* Add in the from state's out data. This will pickup any out functions or
	 * and/or set the priority from the out prior. It is important that this
	 * happens after the adding in of the trans, so that out priority
	 * overrides the priority from the source trans. */
	if ( leavingFsm )
		dupSrcTrans->leavingFromState( from );

	/* Compare the priority of the dest and src transitions. */
	int compareRes = Transition::comparePrior( destTrans, dupSrcTrans );
	if ( compareRes < 0 ) {
		/* Src trans has a higher priority than dest, src overwrites dest. */
		retTrans = overwriteTrans( md, from, keyType, onChar, destTrans, 
				dupSrcTrans, leavingFsm );
	}
	else if ( compareRes > 0 ) {
		/* The existing trans has a higher priority. We do nothing. No new transition
		 * is made. Return destTrans. */
		retTrans = destTrans;
	}
	else {
		/* Src trans and dest trans have the same priority, they must be merged. */
		retTrans = fsmAttachStates( md, from, keyType, onChar, destTrans, 
				dupSrcTrans, leavingFsm );
	}

	/* Finished with this temporary. */
	delete dupSrcTrans;

	/* Return the transition that resulted from the cross. */
	return retTrans;
}

/* When copying out transitions, a transition exists only in the dest out list.
 * Since the key is not in src, we must consider a default transition.  Dest
 * may get crossed with it. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		keyInDestEl( MergeData &md, State *dest, State *src, TransEl *destTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm )
{
	Transition *retTrans = 0;

	/* Is there a default transition? */
	if ( defTrans != 0 ) {
		/* There is a default, is destTel set? */
		if ( destTel->value != 0 ) {
			/* Cross dest trans with the default from src. */
			retTrans = crossTransitions( md, dest, keyType, destTel->key, 
					destTel->value, defTrans, leavingFsm );
		}
		else {
			/* Dest trans el is not set, copy the default from src in. */
			retTrans = dupTrans( dest, keyType, destTel->key, defTrans, leavingFsm );
		}
	}
	else {
		/* No default transition from src. Just use what was in dest already. */
		retTrans = destTel->value;		
	}
	return retTrans;
}

/* When copying out transitions, a transition exists only in the src out list.
 * Since the key is not in dest, we must consider a default transition. Src may
 * get crossed with one of those. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		keyInSrcEl( MergeData &md, State *dest, State *src, TransEl *srcTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm )
{
	Transition *retTrans = 0;

	if ( defTrans != 0 ) {
		/* Dest has default trans. Src's trans may be crossed with it. */
		if ( srcTel->value != 0 ) {
			/* Cross src trans with the default. First get a copy of the default
			 * to pretend as if it was already in dest on the key. */
			Transition *newTrans = dupTrans( dest, keyType, srcTel->key,
					defTrans, false );
			retTrans = crossTransitions( md, dest, keyType, srcTel->key,
					newTrans, srcTel->value, leavingFsm );
		}
		else {
			/* Dup dest's default into retTrans. */
			retTrans = dupTrans( dest, keyType, srcTel->key, defTrans, false );
		}
	}
	else {
		/* Dest has no default transition. */
		if ( srcTel->value != 0 ) {
			/* Dup src's trans into the new transition element. */
			retTrans = dupTrans( dest, keyType, srcTel->key, 
					srcTel->value, leavingFsm );
		}
		else {
			/* Src is explicitly off. New transition element must also be off
			 * explicitly. */
			retTrans = 0;
		}
	}
	return retTrans;
}

/* When copying out transitions, a transition exists (on the same key) in both
 * src and dest. We need to determine if the transitions are explicitly unset.
 * No crossing with any default transition or with range transitions will
 * happen. Note that the default or range are assumed only when there is no
 * key. */
template < class Graph, class State, class Transition >
		Transition *FsmGraph<Graph, State, Transition>::
		keyInBothEl( MergeData &md, State *dest, State *src, TransEl *destTel,
			TransEl *srcTel, FsmKeyType keyType, bool leavingFsm )
{
	Transition *retTrans = 0;

	if ( destTel->value != 0 && srcTel->value != 0 ) {
		/* Transitions are set in both, must cross them. */
		retTrans = crossTransitions( md, dest, keyType, destTel->key,
				destTel->value, srcTel->value, leavingFsm );
	}
	else if ( destTel->value != 0 ) {
		/* Transition is set only in destTel. Continue using destTel. */
		retTrans = destTel->value;
	}
	else if ( srcTel->value != 0 ) {
		/* Transition is set only in srcTel. Dup it. */
		retTrans = dupTrans( dest, keyType, srcTel->key, srcTel->value, leavingFsm );
	}
	else {
		/* Transition is unset in both. Stays unset.  */
		retTrans = 0;
	}

	return retTrans;
}

/* Copying the default transition. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		copyDefTrans( MergeData &md, State *dest, State *src, bool leavingFsm )
{
	if ( dest->outDefault != 0 && src->outDefault != 0 ) {
		/* Must cross the default out transitions. */
		dest->outDefault = crossTransitions( md, dest, KeyTypeDefault, 0,
					dest->outDefault, src->outDefault, leavingFsm );
	}
	else if ( src->outDefault != 0 ) {
		/* A default trans only in src, copy it to dest. */
		dest->outDefault = dupTrans( dest, KeyTypeDefault, 0,
				src->outDefault, leavingFsm );
	}
	else {
		/* Leave dest->outDefault as is. */
	}
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		changeRangeLowerKey( Transition *trans, FsmKey oldKey, FsmKey newKey )
{
	/* Be certain that the the we are changing from the correct old key and
	 * set the new key. */
	assert( FsmKey::eq( trans->lowerKey, oldKey, isAlphSigned ) );
	trans->lowerKey = newKey;
}

/* Copy the transitions in srcList to the outlist of dest. If srcList comes from
 * a final state and out transitions should be copied in then leavingFsm can be
 * set true. SrcList should not be the outList of dest, otherwise you would
 * be copying the contents of srcList into itself as it's iterated: bad news. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		outTransCopy( MergeData &md, State *dest, State *src, bool leavingFsm )
{
	/* For making destination lists. */
	TransEl newTel;

	/* The destination lists. */
	TransList destList, destRange;

	/* Set up an iterator to stop at breaks. */
	PairIterator outPair(dest, src, isAlphSigned, true);
	while ( ! outPair.atEnd() ) {
		switch ( outPair.userState ) {

		case PairIterator::TransInS1:
			/* Call worker using above computed default and single key type. */
			newTel.value = keyInDestEl( md, dest, src, outPair.s1Tel, 
					KeyTypeSingle, outPair.defTrans, leavingFsm );

			/* Add newTel to the new out list, get the key from s1Tel. */
			newTel.key = outPair.s1Tel->key;
			destList.append( newTel );
			break;

		case PairIterator::TransInS2:
			/* Call worker using above computed default and single key type. */
			newTel.value = keyInSrcEl( md, dest, src, outPair.s2Tel, 
					KeyTypeSingle, outPair.defTrans, leavingFsm );

			/* Add newTel to the new out list. Get the key from srcTel, easy. */
			newTel.key = outPair.s2Tel->key;
			destList.append( newTel );
			break;

		case PairIterator::TransOverlap:
			/* Call worker for transitions in both using single key type. */
			newTel.value = keyInBothEl( md, dest, src, outPair.s1Tel, 
					outPair.s2Tel, KeyTypeSingle, leavingFsm );

			/* Add it to the new out list. Get the key from destTel 
			 * (could be either). */
			newTel.key = outPair.s1Tel->key;
			destList.append( newTel );
			break;

		case PairIterator::RangeInS1:
			/* Ranges may get crossed with src's default transition. */
			newTel.value = keyInDestEl( md, dest, src, outPair.s1Tel,
					KeyTypeRange, outPair.defTrans, leavingFsm );

			/* Add the new range to the new out range. */
			newTel.key = outPair.s1Tel[0].key;
			destRange.append( newTel );
			newTel.key = outPair.s1Tel[1].key;
			destRange.append( newTel );
			break;

		case PairIterator::RangeInS2:
			/* Ranges may get crossed with dests's default transition. */
			newTel.value = keyInSrcEl( md, dest, src, outPair.s2Tel, 
					KeyTypeRange, outPair.defTrans, leavingFsm );

			/* Add newTel to the new out range. Get the keys from srcTel, easy. */
			newTel.key = outPair.s2Tel[0].key;
			destRange.append( newTel );
			newTel.key = outPair.s2Tel[1].key;
			destRange.append( newTel );
			break;

		case PairIterator::RangeOverlap:
			/* Call worker for transitions in both using range type. */
			newTel.value = keyInBothEl( md, dest, src, outPair.s1Tel, 
					outPair.s2Tel, KeyTypeRange, leavingFsm );

			/* Add newTel to the new out range. Get the keys from destTel. Keys could
			 * come from either dest or src. */
			newTel.key = outPair.s1Tel[0].key;
			destRange.append( newTel );
			newTel.key = outPair.s1Tel[1].key;
			destRange.append( newTel );
			break;

		case PairIterator::BreakS1:
			/* The source range may be null, in which case, no need to copy. */
			if ( outPair.s1Tel[0].value == 0 ) {
				/* Init the new broken off range to null. */
				outPair.s1Tel[0].value = outPair.s1Tel[1].value = 0;
			}
			else {
				/* The dest trans needs to be copied. The copy goes into the
				 * first half of the break because that is the only value we
				 * have access to. */
				outPair.s1Tel[0].value = outPair.s1Tel[1].value = 
						dupTrans( dest, KeyTypeRange, outPair.s1Tel[0].key, 
						outPair.s1Tel[0].value, false );

				/* The lower char is the key of in transitions and the next
				 * trans is having its lower char changed. This must be
				 * reflected by the move of the transition to the new in
				 * transition list. */
				changeRangeLowerKey( outPair.s1NextTel[0].value, outPair.s1Tel[0].key,
						outPair.s1NextTel[0].key );
			}
			break;

		case PairIterator::BreakS2:
			/* We do not care about duplicating transitions from src. They are 
			 * merely sourced so do not need to be duplicated to protected 
			 * against writing twice. */
			break;
		}
		outPair++;
	}

	/* Last thing to do is copy default transitions. */
	copyDefTrans( md, dest, src, leavingFsm );

	/* Transfer destList into dest->outList. */
	dest->outList.empty();
	dest->outList.shallowCopy( destList );
	destList.abandon();

	/* Transfer destRange into dest->outRange. */
	dest->outRange.empty();
	dest->outRange.shallowCopy( destRange );
	destRange.abandon();
}


/* Move all the transitions that go into src so that they go into dest.  */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		inTransMove( State *dest, State *src )
{
	/* Do not try to move in trans to and from the same state. */
	assert( dest != src );

	/* Move the transitions in inList. */
	while ( src->inListHead != 0 ) {
		/* Get trans and from state. */
		Transition *trans = src->inListHead;
		State *fromState = trans->fromState;

		/* Detach from src, reattach to dest. */
		detachStates( fromState, src, trans, KeyTypeSingle, trans->lowerKey );
		attachStates( fromState, dest, trans, KeyTypeSingle, trans->lowerKey );
	}

	/* Move the transitions in inRange. */
	while ( src->inRangeHead != 0 ) {
		/* Get trans and from state. */
		Transition *trans = src->inRangeHead;
		State *fromState = trans->fromState;

		/* Detach from src, reattach to dest. */
		detachStates( fromState, src, trans, KeyTypeRange, trans->lowerKey );
		attachStates( fromState, dest, trans, KeyTypeRange, trans->lowerKey );
	}

	/* Move the default transitions. */
	while ( src->inDefHead != 0 ) {
		/* Get trans and from state. */
		Transition *trans = src->inDefHead;
		State *fromState = trans->fromState;

		/* Detach from src, reattach to dest. */
		detachStates( fromState, src, trans, KeyTypeDefault, 0 );
		attachStates( fromState, dest, trans, KeyTypeDefault, 0 );
	}
}

#endif /* _RLFSM_FSMATTACH_CPP */

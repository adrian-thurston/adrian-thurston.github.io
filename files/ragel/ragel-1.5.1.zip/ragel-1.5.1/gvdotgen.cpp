/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


#include "gvdotgen.h"
#include "fsmap.h"

using namespace std;

GraphvizDotGen::GraphvizDotGen( char *fsmName, ParseData *parseData, 
		FsmAp *graph, ostream &out )
:
	fsmName(fsmName),
	parseData(parseData),
	graph(graph),
	out(out)
{
}

void GraphvizDotGen::writeDotFile( )
{
	/* Need state numbers. */
	graph->setStateNumbers();

	out << 
		"digraph " << fsmName << " {\n"
		"	rankdir=LR;\n";
	
	/* Define the psuedo start state. Entry into it will be done after the
	 * start state has been defined as either final or not final. */
	out << "	ENTRY [ shape = point ];\n";

	/* Attributes common to all nodes. */
	out << "	node [ fixedsize = true, height = 0.65 ];\n";

	/* List Final states. */
	out << 
		"	node [ shape = doublecircle ];\n"
		"	";
	for ( FsmAp::StateSet::Iter fin = graph->finStateSet; fin.lte(); fin++ ) {
		out << "" << (*fin)->alg.stateNum;
		if ( ! fin.last() )
			out << " ";
	}
	out << ";\n";

	/* List transitions. */
	out <<
		"	node [ shape = circle ];\n";

	/* Walk the states. */
	StateAp *state = graph->stateList.head;
	for ( ; state != 0; state = state->next ) {
		FsmUniOutIter<StateAp, TransAp, long, FaKeyOps> outIt( state, graph );
		for ( ; outIt.lte(); outIt++ ) {
			out << "\t" << state->alg.stateNum  << " -> ";
			if ( outIt.trans == 0 )
				out << "ERR";
			else
				out << "" << outIt.trans->toState->alg.stateNum;
			out << " [ label = \"";
			if ( outIt.lowerKey == outIt.upperKey )
				out << outIt.lowerKey;
			else
				out << outIt.lowerKey << "-" << outIt.upperKey;
			out << "\" ];\n";
		}

		/* Default transision? */
		if ( state->outDefault != 0 ) {
			out << "\t" << state->alg.stateNum  << " -> " << 
					"" << state->outDefault->toState->alg.stateNum << 
					" [ label = \"def\" ];\n";
		}
	}

	/* Entry into the pseudo start state. */
	out << "	ENTRY -> " << graph->findEntry(0)->alg.stateNum << ";\n";

	out <<
		"}\n";
}

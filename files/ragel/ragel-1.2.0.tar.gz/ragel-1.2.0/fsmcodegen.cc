/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmcodegen.h"
#include "rl.h"

/* Init a code gen with no code. */
FsmCodeGen::FsmCodeGen( char *fsmName, FsmMachine<int> *machine,
		ParseData *parseData, ostream &out ) :
		header(0), code(0), fsmName(fsmName), machine(machine),
		parseData(parseData), out(out)
{
	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Given a func index get the string version of the func that will
 * go to the output. Assumes the functions are indexed starting at 0. */
char *FsmCodeGen::GetCodeBuiltin(int index)
{
	if ( 0 <= index && index < parseData->funcList.listLength ) {
		/* Walk the list of functions, to find the given index. */
		StringListEl *flel = parseData->funcList.head;
		for ( int fnum = 0; fnum < index; fnum++ )
			flel = flel->next;
		return flel->data;
	}
	return NULL;
}


/* Write out the code section. Use the header class member which will
 * be set by whatever super class is used. */
void FsmCodeGen::WriteOutHeader( )
{
	writeOutScan( header );
}

/* Write out the code section. Use the header class member which will
 * be set by whatever super class is used. */
void FsmCodeGen::WriteOutCode( )
{
	writeOutScan( code );
}

/* Associate a section name with a function call for handling 
 * the section name. */
void FsmCodeGen::registerSection( char *secName, SectionType call )
{
	/* Insert into the dict, ignoring whether or not if failed.
	 * We always overwrite existing entries so that super classes
	 * can override handlers that are set up by base classes. */
	BstMapEl< char*, SectionType > *lastFound;
	sectionDict.insert( secName, call, &lastFound );
	lastFound->value = call;
}

void FsmCodeGen::selectSection( char *sname )
{
	BstMapEl<char*, SectionType> *res = sectionDict.find( sname );
	if ( res == 0 )
		out << "\n<<ragel internal error: section " << sname << " not found>>\n";
	else
		res->value( this );
}

void FsmCodeGen::writeOutScan( char *data )
{
	char *sectionStart = 0;
	char *cur = data;
	enum { inData, inSection } state = inData;

	while ( *cur != 0 ) {
		if ( state == inData ) {
			if ( *cur == '@' ) {
				sectionStart = cur + 1;
				state = inSection;
			}
			else
				out << *cur;
		}
		else if ( *cur == '@' ) {
			/* We got to the end of a section name. */
			*cur = 0;
			selectSection( sectionStart );
			*cur = '@';
			state = inData;
		}
		cur++;
	}
}

/* Write out the fsm name. */
void FsmCodeGen::FSMNAME()
{
	out << fsmName;
}

void FsmCodeGen::STRUCT_DATA()
{
	/* Walk the list of data, printing the cases. */
	StringListEl *del = parseData->dataList.head;
	while ( del != NULL ) {
		out << del->data;
		del = del->next;
	}
}

void FsmCodeGen::INIT_CODE()
{
	/* Walk the list of pre funcs, printing the sections. */
	StringListEl *del = parseData->initCodeList.head;
	while ( del != NULL ) {
		out.form( "{ %s }\n", del->data );
		del = del->next;
	}
}

void FsmCodeGen::ANY_FUNCS()
{
	if ( machine->numTransFuncs > 0 )
		out << "1";
	else
		out << "0";
}

void FsmCodeGen::ANY_INDICIES()
{
	bool indiciesFound = false;
	FsmMachState *pSt = machine->allStates;
	for ( int st = 0; st < machine->numStates; st++, pSt++ ) {
		if ( pSt->numIndex > 0 ) {
			indiciesFound = true;
			break;
		}
	}
	if ( indiciesFound )
		out << "1";
	else
		out << "0";
}

/* Emit the offset of the start state as a decimal integer. */
void FsmCodeGen::START_STATE_OFFSET()
{
	out << machine->startState;
};


/* Write out the array of all functions including the lengths of each
 * function vector. */
void FsmCodeGen::FUNCTIONS()
{
	int totalFunc = 0;
	out << '\t';
	for ( int fnum = 0; fnum < machine->numTransFuncs; fnum++ ) {
		int func = machine->allTransFuncs[fnum];
		out.form("%i", func );

		/* If we are not in the last func, then write out a comma 
		 * and possibly a line break. */
		if ( fnum < machine->numTransFuncs-1 ) {
			out << ", ";

			/* Put in a line break every 8 */
			if ( totalFunc % 8 == 7 )
				out << "\n\t";
		} 
		totalFunc += 1;
	}
}

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_BSTSET_H
#define _AAPL_BSTSET_H

#include "compare.h"
#include "vector.h"

#define BASE_COMPARE(name) Compare::name
#define BST_TEMPL_DECLARE class Key, class Compare, class Resize = ExpnResize
#define BST_TEMPL_DEF class Key, class Compare, class Resize
#define BST_TEMPL_USE Key, Compare, Resize
#define GET_KEY(el) (*el)
#define BsTable BstSet
#define Element Key
#define BSTSET

#include "bstcommon.h"

#undef BASECOMPARE
#undef BST_TEMPL_DECLARE
#undef BST_TEMPL_DEF
#undef BST_TEMPL_USE
#undef GET_KEY
#undef BsTable
#undef Element
#undef BSTSET

/* Set interface. */
template <class Key, class Compare, class Resize> bool BstSet<Key, Compare, Resize>::
		set(const Key &item, Key **lastFound = NULL)
{
	Key *el = insert( item, lastFound );
	return el != NULL;
}

template <class Key, class Compare, class Resize> void BstSet<Key, Compare, Resize>::
		set(const BstSet &otherSet)
{
	Key *otherItem = otherSet.table;
	int otherLen = otherSet.tableLength;
	for (int i = 0; i < otherLen; i++, otherItem++)
		set(*otherItem);
}

template <class Key, class Compare, class Resize> bool BstSet<Key, Compare, Resize>::
		unSet(const Key &key)
{
	bool retVal = false;
	Key *el = find(key);
	if ( el != NULL )
	{
		Vector< Key >::remove(el - table);
		retVal = true;
	}
	return retVal;
}

template <class Key, class Compare, class Resize> bool BstSet<Key, Compare, Resize>::
		isSet(const Key &item)
{
	/* Look for the key. */
	Key *el = find( item );
	return el != NULL;
}

#endif /* _AAPL_BSTSET_H */

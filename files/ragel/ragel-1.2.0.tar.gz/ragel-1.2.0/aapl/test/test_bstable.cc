/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <stdio.h>

#include "bstable.h"
#include "bstmap.h"
#include "bstset.h"

struct MyElement  : public OrdCmp<int>
{
	MyElement() {}
	MyElement(int key) : key(key) { }
	const int &getKey() { return key; }
	int key;
};

template class BsTable<MyElement, int>;

void testBSTable1()
{
	BstMap<int, int, OrdCmp<int> > table;

	table.insert(1, 3);
	table.insert(3, 1);
	table.insert(5, 0);
	table.insert(7, 1);
	table.insert(4, 8);
	table.insert(2, 0);
	table.insert(6, 1);

	table.remove(2);
	table.remove(3);
	table.remove(6);
	table.remove(4);
	table.remove(5);
	table.remove(7);

	BstMapEl<int, int> *tab = table.table;
	int len = table.tableLength;
	for (int i = 0; i < len; i++, tab++)
		printf("(%i) maps to %i\n", tab->key, tab->value);
}

struct CompoundKey
{
	int Key1;
	int Key2;
};

struct CompoundKeyCompare
{
	inline static int Compare(const CompoundKey &key1, const CompoundKey &key2)
	{
		if ( key1.Key1 < key2.Key1 )
			return -1;
		else if ( key1.Key1 > key2.Key1 )
			return 1;
		else
		{
			if ( key1.Key2 < key2.Key2 )
				return -1;
			else if ( key1.Key2 > key2.Key2 )
				return 1;
			else
				return 0;
		}
	}
};

void testBSTable2()
{
	BstMap<CompoundKey, int, CompoundKeyCompare > table;

	CompoundKey k;

	k.Key1 = 1; k.Key2 = 2;
	table.insert(k, 10);

	k.Key1 = 1; k.Key2 = 3;
	table.insert(k, 10);

	k.Key1 = 2; k.Key2 = 2;
	table.insert(k, 10);

	k.Key1 = 0; k.Key2 = 2;
	table.insert(k, 10);

	k.Key1 = 2; k.Key2 = -10;
	table.insert(k, 10);

	BstMapEl<CompoundKey, int> *tab = table.table;
	int len = table.tableLength;
	for (int i = 0; i < len; i++, tab++)
		printf("(%i, %i) maps to %i\n", tab->key.Key1, tab->key.Key2, tab->value);
}

struct KeyStruct
{
	/* Constructors. */
	KeyStruct() : key(0) { }
	KeyStruct(int i) : key(i)
		{ cout << "KeyStruct(" << key << ")" << endl; }
	KeyStruct(const KeyStruct &o) : key(o.key)
		{ cout << "KeyStruct(KeyStruct &)" << endl; }

	/* Destructors. */
	~KeyStruct() { cout << "~KeyStruct = {" << key << "}" << endl; }

	int key;
};

struct KeyStructCompare
{
	static inline int Compare(const KeyStruct &k1, const KeyStruct &k2)
		{ return OrdCmp<int>::Compare(k1.key, k2.key); }
};

int testBSTable3()
{
	BstMap<KeyStruct, int, KeyStructCompare > tbl;

	cout << "ins res = " << tbl.insert(KeyStruct(0), 1) << endl;
	cout << "ins res = " << tbl.insert(KeyStruct(1), 1) << endl;
	return 0;
}

int testBSTable4()
{
	BstMap<int, int, OrdCmp<int> > tbl;

	tbl.insertMulti(1, 1);
	tbl.insertMulti(4, 1);
	tbl.insertMulti(2, 1);
	tbl.insertMulti(1, 1);
	tbl.insertMulti(1, 1);
	tbl.insertMulti(1, 3);
	tbl.insertMulti(3, 1);
	tbl.insertMulti(1, 0);
	tbl.insertMulti(7, 1);
	tbl.insertMulti(4, 8);
	tbl.insertMulti(1, 0);
	tbl.insertMulti(6, 1);

	BstMapEl<int, int> *low, *high;

	tbl.findMulti( 1, low, high );
	cout << high - low + 1 << endl;

	cout << tbl.removeMulti( 1 ) << endl;
	cout << tbl.findMulti( 1, low, high ) << endl;
	return 0;
}

int main()
{
	testBSTable1();
	testBSTable2();
	testBSTable3();
	return 0;
}

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

template <BST_TEMPL_DECLARE> class BsTable :
		public Vector< Element >
{
public:
	/* Init with allocLength space preallocated. */
	BsTable(int allocLength) : Vector< Element >( 0, allocLength ) {}

	/* Init with no space preallocated. */
	BsTable() { }

	Element *insert(const Key &key, Element **lastFound = NULL);
	Element *insertMulti(const Key &key);

#if defined( BSTMAP )
	Element *insert(const Key &key, const Value &val, 
			Element **lastFound = NULL);
	Element *insertMulti(const Key &key, const Value &val );
#endif

	Element *find(const Key &key, Element **lastFound = NULL) const;
	bool findMulti( const Key &key, Element *&lower,
			Element *&upper ) const;

	int remove(const Key &key);
	int remove(Element *item);
	int removeMulti(const Key &key);

#if defined( BSTSET )
	/* Set interface. */
	bool set(const Key &item, Element **lastFound = NULL);
	void set(const BsTable &otherSet);
	bool unSet(const Key &item);
	bool isSet(const Key &item);
#endif
};


template<BST_TEMPL_DEF> int BsTable<BST_TEMPL_USE>::
		remove(const Key &key)
{
	Element *el = find(key);
	if (el)
	{
		Vector< Element >::remove(el - table);
		return true;
	}
	else
		return false;
}

template <BST_TEMPL_DEF> int BsTable<BST_TEMPL_USE>::
		remove( Element *item )
{
	if (item != NULL)
	{
		Vector< Element >::remove(item - table);
		return true;
	}
	else
		return false;
}

template<BST_TEMPL_DEF> int BsTable<BST_TEMPL_USE>::
		removeMulti(const Key &key)
{
	Element *low, *high;
	if ( findMulti(key, low, high) )
	{
		int num = high - low + 1;
		Vector< Element >::remove(low - table, high - low + 1);
		return num;
	}
	else
		return 0;
}


template <BST_TEMPL_DEF> bool BsTable<BST_TEMPL_USE>::
		findMulti(const Key &key, Element *&low, Element *&high ) const
{
	Element *lower, *mid, *upper;
	int keyRelation;

	if (! table)
	{
		return false;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array. */
			return false;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(Compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			Element *lowEnd = table - 1;
			Element *highEnd = table + tableLength;

			lower = mid - 1;
			while ( lower != lowEnd && 
					BASE_COMPARE(Compare(key, GET_KEY(lower))) == 0 )
				lower--;

			upper = mid + 1;
			while ( upper != highEnd && 
					BASE_COMPARE(Compare(key, GET_KEY(upper))) == 0 )
				upper++;
			
			low = lower + 1;
			high = upper - 1;
			return true;
		}
	}
}

template <BST_TEMPL_DEF> Element *BsTable<BST_TEMPL_USE>::
		find( const Key &key, Element **lastFound ) const
{
	Element *lower, *mid, *upper;
	int keyRelation;

	if (! table)
		return 0;

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower ) {
			/* Did not find the key. Last found gets the insert location. */
			if ( lastFound != NULL )
				*lastFound = lower;
			return NULL;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(Compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			/* Key is found. Last found gets the found record. */
			if ( lastFound != NULL )
				*lastFound = mid;
			return mid;
		}
	}
}

template <BST_TEMPL_DEF> Element *BsTable<BST_TEMPL_USE>::
		insert(const Key &key, Element **lastFound)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(Compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != NULL )
				*lastFound = mid;
			return 0;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. After makeRawSpaceFor, lower pointer is no good. */
	tableLength = makeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = table + insertPos;
	return table + insertPos;
}


template <BST_TEMPL_DEF> Element *BsTable<BST_TEMPL_USE>::
		insertMulti(const Key &key)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(Compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			lower = mid;
			goto Insert;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = makeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key);

	/* Return the element inserted. */
	return table + insertPos;
}



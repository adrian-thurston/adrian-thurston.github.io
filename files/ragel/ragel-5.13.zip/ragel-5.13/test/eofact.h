#ifndef _EOFACT_H
#define _EOFACT_H

struct eofact
{
	int cs;
};

#endif

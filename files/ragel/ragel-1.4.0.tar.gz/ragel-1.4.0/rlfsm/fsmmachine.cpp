/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmmachine.h"

/* Free the inidicies. */
FsmMachState::~FsmMachState()
{
	if ( transIndPtr != 0 )
		delete[] transIndPtr;
	if ( transIndKey != 0 )
		delete[] transIndKey;
}

/* Free the indicies. */
FsmMachFlatState::~FsmMachFlatState()
{
	if ( transIndex != 0 )
		delete[] transIndex;
}

/* Inline compare of transistions. */
int FsmMachTransCompare::compare(const FsmMachTrans &t1,
			const FsmMachTrans &t2)
{
	if ( t1.toState < t2.toState )
		return -1;
	else if ( t1.toState > t2.toState )
		return 1;
	else {
		if ( t1.funcs < t2.funcs )
			return -1;
		else if ( t1.funcs > t2.funcs )
			return 1;
		else
			return 0;
	}
}

/* Construct an empty machine. */
FsmMachine::FsmMachine()
{
	startState = -1;
	allStates = 0;
	numStates = 0;
	allTrans = 0;
	numTrans = 0;

	allTransFuncs = 0;
	numTransFuncs = 0;

	transFuncIndex = 0;
	numTransFuncIndex = 0;

	isAlphSigned = true;
}

/* Delete all memory used by the machine. */
FsmMachine::~FsmMachine()
{
	if ( allStates != 0 )
		delete[] allStates;
	if ( allTrans != 0 )
		delete[] allTrans;
	if ( allTransFuncs != 0 )
		delete[] allTransFuncs;
	if ( transFuncIndex != 0 )
		delete[] transFuncIndex;
}

/* Count the number of indicies across the whole machine. */
int FsmMachine::numIndicies()
{
	int sum = 0;
	for ( int s = 0; s < numStates; s++ ) {
		FsmMachState *state = &allStates[s];
		sum += state->numIndex + state->numRange + 1;
	}
	return sum;
}

/* Make an fsm state where the transition indicies are one flat array.
 * bool allocIndicies controls whether or not the indicy array is made. */
void FsmMachine::makeFlatState( FsmMachFlatState &dest, 
		const FsmMachState &src, bool allocIndicies )
{
	/* This may not be made, so init it null. */
	dest.transIndex = 0;

	/* If there are no transitions, then our work is not hard. */
	if ( src.numIndex == 0 ) {
		dest.highIndex = 0;
		dest.lowIndex = 0;
		dest.transIndex = 0;
		dest.numIndex = 0;
		dest.dflIndex = 0;
		return;
	}

	/* Get high index and low index. */
	dest.lowIndex = src.transIndKey[0];
	dest.highIndex = src.transIndKey[src.numIndex-1] + 1;

	/* No default index, goes to error trans, which is index 0. */
	dest.dflIndex = src.dflIndex;

	/* The index array is high minus low long. */
	dest.numIndex = dest.highIndex - dest.lowIndex;

	if ( allocIndicies ) {
		dest.transIndex = new int[dest.numIndex];

		/* We can toss only a few transitions. */
		for ( int orig = 0,               /* loops src indicies */
				aInd = dest.lowIndex;     /* loops alphabet indicies. */
				orig < src.numIndex; orig++, aInd++ ) {
			/* Fill in gaps with the default transition. */
			while ( aInd < src.transIndKey[orig] ) {
				dest.transIndex[aInd - dest.lowIndex] = dest.dflIndex;
				aInd += 1;
			}
				
			/* Copy the trans index. */
			dest.transIndex[aInd - dest.lowIndex] = src.transIndPtr[orig];
		}
	}
}

/* Make an fsm state that is designed for a switch statement. Characters that
 * use the same transition are chunked together. */
void FsmMachine::makeSwitchState( FsmMachSwitchState &dest, 
		const FsmMachState &src )
{
	int *key = src.transIndKey;
	int *trans = src.transIndPtr;

	/* Build a mapping of transitions to chars on those transitions. */
	for ( int j = 0; j < src.numIndex; j++, key++, trans++) {
		/* Try to insert the pointer to the transition. We use
		 * lastfound so we don't care if it fails or not. We are
		 * just interested in the Vector<int> at the trans ptr. */
		BstMapEl< int, Vector<int> > *lastFound;
		dest.funcMap.insert( *trans, &lastFound );
			
		/* Now append the char for this transition to the vector. */
		Vector<int> &charVec = lastFound->value;
		charVec.append( *key );
	}

	/* We cannot pick a default index, the error trans is 
	 * used as the default. */
	dest.dflIndex = src.dflIndex;
}

void FsmMachine::makeIndiciesFromRange( FsmMachState *machState )
{
	/* Count the number of indicies. */
	int i, dest, numIndex = 0;
	for ( i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		numIndex += upper - lower + 1;
	}

	machState->transIndKey = new int[numIndex];
	machState->transIndPtr = new int[numIndex];
	machState->numIndex = numIndex;

	/* Set the indicies. */
	for ( dest = 0, i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		for ( int ind = lower; ind <= upper; ind++ ) {
			machState->transIndKey[dest] = ind;
			machState->transIndPtr[dest] = machState->rangeIndPtr[i];
			dest += 1;
		}
	}
}
		
void FsmMachine::moveRangesIntoIndicies( FsmMachState *machState )
{
	/* Nothing to do if there are no ranges. */
	if ( machState->rangeIndPtr == 0 )
		return;

	/* If there are no indicies then simply express the ranges as indicies. */
	if ( machState->transIndKey == 0 ) {
		makeIndiciesFromRange( machState );
	}
	else {
		int *indexKey = machState->transIndKey;
		int *indexPtr = machState->transIndPtr;
		int numIndex = machState->numIndex;

		makeIndiciesFromRange( machState );

		int *rangeKey = machState->transIndKey;
		int *rangePtr = machState->transIndPtr;
		int numRange = machState->numIndex;

		/* Pass one is to count. */
		int count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				count += numRange - range;
				break;
			}
			else if ( range == numRange ) {
				count += numIndex - index;
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] )
					range += 1;
				else if ( indexKey[index] < rangeKey[range] )
					index += 1;
				else {
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}

		machState->transIndKey = new int[count];
		machState->transIndPtr = new int[count];
		machState->numIndex = count;

		/* Pass two is to build. */
		count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				while ( range < numRange ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
					count += 1;
				}
				break;
			}
			else if ( range == numRange ) {
				while ( index < numIndex ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					count += 1;
				}
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
				}
				else if ( indexKey[index] < rangeKey[range] ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
				}
				else {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}
		delete[] indexKey;
		delete[] indexPtr;
		delete[] rangeKey;
		delete[] rangePtr;
	}

	delete[] machState->rangeIndKey;
	delete[] machState->rangeIndPtr;
	machState->rangeIndKey = 0;
	machState->rangeIndPtr = 0;
	machState->numRange = 0;
}

/* Move ranges into indicies for all states. */
void FsmMachine::moveRangesIntoIndicies( )
{
	for ( int s = 0; s < numStates; s++ )
		moveRangesIntoIndicies( &allStates[s] );
}

/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "gotocodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"

/* Init base data. */
GotoCodeGen::GotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FsmCodeGen(fsmName, parseData, machine, out)
{ }

/* Emit the goto to take for a given transition. */
std::ostream &GotoCodeGen::TRANS_GOTO( FsmMachTrans *trans, int level )
{
	if ( trans->funcs != FUNC_NO_FUNC )
		TABS(level) << "goto tr" << trans - machine->allTrans << ";";
	else {
		/* Get the index of the state we go to. */
		if ( trans->toState != STATE_ERR_STATE )
			TABS(level) << "goto st" << trans->toState << ";";
		else
			TABS(level) << "goto error;";
	}
	return out;
}

void GotoCodeGen::emitRangeBSearch( FsmMachState *state, int level, int low, int high )
{
	/* Get the mid position, staying on the lower end of the range. */
	int mid = ((low + high) / 2) & ~1;

	/* Get the transition to take on hitting the mid. */
	FsmMachTrans *trans = &machine->allTrans[state->rangeIndPtr[mid/2]];

	/* Determine if we need to look higher or lower. */
	bool anyLower = mid != low;
	bool anyHigher = mid != high;

	/* Determine if the keys at mid are the limits of the alphabet. */
	bool limitLow = state->rangeIndKey[mid] == parseData->lowerKey;
	bool limitHigh = state->rangeIndKey[mid+1] == parseData->upperKey;

	if ( anyLower && anyHigher ) {
		/* Can go lower and higher than mid. */
		TABS(level) << "if ( *p < "; KEY(state->rangeIndKey[mid]) << " ) {\n";
		emitRangeBSearch( state, level+1, low, mid-2 );
		TABS(level) << "} else if ( *p > "; KEY(state->rangeIndKey[mid+1]) << " ) {\n";
		emitRangeBSearch( state, level+1, mid+2, high );
		TABS(level) << "} else\n";
		TRANS_GOTO(trans, level+1) << "\n";
	}
	else if ( anyLower && !anyHigher ) {
		/* Can go lower than mid but not higher. */
		TABS(level) << "if ( *p < "; KEY(state->rangeIndKey[mid]) << " ) {\n";
		emitRangeBSearch( state, level+1, low, mid-2 );

		/* if the higher is the highest in the alphabet then there is no
		 * sense testing it. */
		if ( limitHigh ) {
			TABS(level) << "} else\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			TABS(level) << "} else if ( *p <= "; KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
	else if ( !anyLower && anyHigher ) {
		/* Can go higher than mid but not lower. */
		TABS(level) << "if ( *p > "; KEY(state->rangeIndKey[mid+1]) << " ) {\n";
		emitRangeBSearch( state, level+1, mid+2, high );

		/* If the lower end is the lowest in the alphabet then there is no
		 * sense testing it. */
		if ( limitLow ) {
			TABS(level) << "} else\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			TABS(level) << "} else if ( *p >= "; KEY(state->rangeIndKey[mid]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
	else {
		/* Cannot go higher or lower than mid. It's mid or bust. What
		 * tests to do depends on limits of alphabet. */
		if ( !limitLow && !limitHigh ) {
			TABS(level) << "if ( "; KEY(state->rangeIndKey[mid]) << " <= *p && *p <= ";
				KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else if ( limitLow && !limitHigh ) {
			TABS(level) << "if ( *p <= "; KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else if ( !limitLow && limitHigh ) {
			TABS(level) << "if ( "; KEY(state->rangeIndKey[mid]) << " <= *p )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			/* Both high and low are at the limit. No tests to do. */
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
}

std::ostream &GotoCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	for ( int fnum = 0; fnum < parseData->numFuncIndex; fnum++ ) {
		/* Get the function data. Print the case label.  */
		FuncListEl *flel = parseData->funcIndex[fnum];
		out << "\tcase " << fnum << ":\n";

		/* Write the preprocessor line info for going into the source file. */
		out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

		/* Write the block and close it off. */
		out << "\t{" << flel->data << "} break;\n";
	}

	/* Write the directive for going back into the output file. The line
	 * number is for the next line, so add one. */
	out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	return out;
}

/* Emit the switch statement for jumping into the machine. Our current state
 * is represented by an integer and we need to use it to get into the correct
 * place in the machine. */
std::ostream &GotoCodeGen::JUMP_IN_SWITCH()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "\t\tcase " << st << ": goto st" << st << ";\n";
	}
	out << "\t\tdefault: return;\n";
	return out;
};

std::ostream &GotoCodeGen::STATE_GOTOS()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Virtual function for writing the transitions above a state. */
		aboveStateGotos( st );

		/* Get the fsm machine state. */
		FsmMachState *state = machine->allStates+st;

		if ( state->labelNeeded ) {
			out << 
				"st" << st << ":\n"
				"	if ( --len == 0 )\n"
				"		goto out" << st << ";\n";
		}
		out << "case " << st << ":\n";


		if ( state->numIndex == 0 ) {
			/* If there are no single keys. We need to at least advance the
			 * pointer to the current char. */
			out << "\t++p;\n";
		}
		if ( state->numIndex == 1 ) {
			/* If there is a single single key then write it out as an if. */
			out << "\tif ( *++p == "; KEY(state->transIndKey[0]) << " )\n\t\t"; 
			TRANS_GOTO(&machine->allTrans[state->transIndPtr[0]], 0) << "\n";
		}
		else if ( state->numIndex > 1 ) {
			/* Write out single keys in a switch if there is more than one. */
			out << "\tswitch( *++p ) {\n";

			/* Write out the single indicies. */
			for ( int j = 0; j < state->numIndex; j++ ) {
				out << "\t\tcase "; KEY(state->transIndKey[j]) << ": ";

				/* Emit the transition. */
				FsmMachTrans *trans = &machine->allTrans[state->transIndPtr[j]];
				TRANS_GOTO(trans, 0) << "\n";
			}
			/* Close off the transition switch. */
			out << "\t}\n";
		}

		/* Default case is to binary search for the ranges, if that fails then */
		if ( state->numRange > 0 )
			emitRangeBSearch( state, 1, 0, (state->numRange-1)*2 );

		/* Get the default index and write it. Default will always be used. */
		FsmMachTrans *trans = &machine->allTrans[state->dflIndex];
		TRANS_GOTO( trans, 1 ) << "\n";
	}
	return out;
}

std::ostream &GotoCodeGen::TRANSITIONS()
{
	/* Emit any transitions that have functions and that go to 
	 * this state. */
	FsmMachTrans *trans = machine->allTrans;
	for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
		if ( trans->funcs != FUNC_NO_FUNC ) {
			/* Write the label for the transition so it can be jumped to. */
			out << "\ttr" << tr << ": ";

			/* Destination state. */
			out << "cs = " << trans->toState << "; ";

			/* Write out the transition func. */
			out << "goto f" << trans->funcs << ";\n";
		}
	}
	return out;
}

/* Set up labelNeeded flag for each state. */
void GotoCodeGen::setLabelsNeeded()
{
	for ( int st = 0; st < machine->numStates; st++ )
		machine->allStates[st].labelNeeded = false;
	
	FsmMachTrans *trans = machine->allTrans;
	for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
		if ( trans->toState != STATE_ERR_STATE && trans->funcs == FUNC_NO_FUNC )
			machine->allStates[trans->toState].labelNeeded = true;
	}
}

std::ostream &GotoCodeGen::EXEC_FUNCS()
{
	/* Make labels that set funcs and jump to execFuncs. Loop func indicies. */
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		out << "\tf" << i << ": funcs = f+" << 
				machine->transFuncIndex[i] << "; goto execFuncs;\n";
	}

	out <<
		"\n"
		"execFuncs:\n"
		"	nfuncs = *funcs++;\n"
		"	while ( nfuncs-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() <<
		"		}\n"
		"	}\n"
		"	goto again;\n";
	return out;
}

std::ostream &GotoCodeGen::EXIT_STATES()
{
	for ( int st = 0; st < machine->numStates; st++ )
		if ( machine->allStates[st].labelNeeded ) {
			out << "\tout" << st << ": cs = " << st << "; goto out;\n";
	}
	return out;
}

std::ostream &GotoCodeGen::FINISH_CASES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		if ( state->isFinState ) {
			out << "\t\tcase " << st << ": ";

			if ( state->outFuncs != FUNC_NO_FUNC ) {
				/* There are funcs, specify the func and break to them. */
				out << "acpt = 1; goto f" << state->outFuncs << ";\n";
			}
			else {
				/* No funcs, just accept. */
				out << "goto accept;\n";
			}
		}
	}
	
	return out;
}

/* Init base data. */
CGotoCodeGen::CGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out ) 
: 
	GotoCodeGen(fsmName, parseData, machine, out)
{ }


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}


void CGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n";
		STRUCT_DATA() <<
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"#define f "; FSM_NAME() << "_f\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data - 1;\n"
		"	int len = dlen + 1;\n"
		"	int cs = fsm->curState, acpt = 0;\n";

	if ( anyTransFuncs() )
		out << "\tint *funcs, nfuncs;\n";

	out <<
		"\n"
		"	if ( data == 0 )\n"
		"		goto finishInput;\n"
		"\n";

	if ( anyTransFuncs() )
		out << "again:\n";

	out <<
		"	if ( --len == 0 )\n"
		"		goto out;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() <<
		"\n"
		"finishInput:\n"
		"	switch( cs ) {\n";
		FINISH_CASES() << 
		"		default: goto error;\n"
		"	}\n"
		"\n";
	
	if ( anyFinWithNoOutFuncs() ) {
		out <<
			"accept:\n"
			"	acpt = 1;\n"
			"	goto out;\n"
			"\n";
	}

	out <<
		"error:\n"
		"	cs = 0;\n"
		"\n"
		"out:\n"
		"	fsm->curState = cs;\n"
		"	fsm->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	"; FSM_NAME() << "Execute( fsm, 0, 0 );\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n"
		"#undef f\n"
		"\n";
}

/* Init base data. */
CCGotoCodeGen::CCGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
: 
	GotoCodeGen(fsmName, parseData, machine, out)
{ }

/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCGotoCodeGen::FSM_PREFIX()
{
	return out;
}

void CCGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n"
		"\n"
		"	/* The start state. */\n"
		"	static int startState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"#define f "; FSM_NAME() << "_f\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* Make sure the fsm is initted. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	this->curState = startState;\n"
		"	this->accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data - 1;\n"
		"	int len = dlen + 1;\n"
		"	int cs = this->curState, acpt = 0;\n";

	if ( anyTransFuncs() )
		out << "\tint *funcs, nfuncs;\n";

	out <<
		"\n"
		"	if ( data == 0 )\n"
		"		goto finishInput;\n"
		"\n";

	if ( anyTransFuncs() )
		out << "again:\n";

	out <<
		"	if ( --len == 0 )\n"
		"		goto out;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() <<
		"\n"
		"finishInput:\n"
		"	switch( cs ) {\n";
		FINISH_CASES() << 
		"		default: goto error;\n"
		"	}\n"
		"\n";

	if ( anyFinWithNoOutFuncs() ) {
		out << 
			"accept:\n"
			"	acpt = 1;\n"
			"	goto out;\n"
			"\n";
	}

	out <<
		"error:\n"
		"	cs = 0;\n"
		"\n"
		"out:\n"
		"	this->curState = cs;\n"
		"	this->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	Execute( 0, 0 );\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return this->accept;\n"
		"}\n"
		"\n"
		"#undef f\n"
		"\n";
}

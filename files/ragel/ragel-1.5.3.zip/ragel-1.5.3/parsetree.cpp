/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <iomanip>
#include <errno.h>
#include <limits.h>
#include <stdlib.h>

/* Parsing. */
#include "ragel.h"
#include "ptreetypes.h"
#include "rlparse.h"
#include "parsetree.h"

/* Machine building. */
#include "fsmmachine.h"

/* Code generators. */
#include "tabcodegen.h"
#include "ftabcodegen.h"
#include "gotocodegen.h"
#include "fgotocodegen.h"
#include "ipgcodegen.h"

/* Dumping the fsm. */
#include "fsmdump.h"
#include "gvdotgen.h"

using namespace std;

/* The minimum chars are the absolute value of the real minimum because the
 * sign is stored separately in integers read in so they are compared in the
 * positive. Each is casted to an unsigned because the data part of the number
 * is in unsigned int size. 
 *
 * Not terribly portable...
 */
#define RL_MIN_CHAR    ((int)((char)0x80))
#define RL_MAX_CHAR    ((int)((char)0x7f))
#define RL_MIN_UCHAR   ((int)((unsigned char)0x0))
#define RL_MAX_UCHAR   ((int)((unsigned char)0xff))
#define RL_MIN_SHORT   ((int)((short)0x8000))
#define RL_MAX_SHORT   ((int)((short)0x7fff))
#define RL_MIN_USHORT  ((int)((unsigned short)0x0000))
#define RL_MAX_USHORT  ((int)((unsigned short)0xffff))
#define RL_MIN_INT     ((int)((int)0x80000000))
#define RL_MAX_INT     ((int)((int)0x7fffffff))
#define RL_MIN_UINT    ((int)((unsigned int)0x00000000))
#define RL_MAX_UINT    ((int)((unsigned int)0xffffffff))

InputLoc::InputLoc( const BISON_YYLTYPE &loc )
:
	line(loc.first_line), 
	col(loc.first_column)
{
}

FuncListEl::FuncListEl( const InputLoc &loc, char *name, char *data ) 
:
	loc(loc),
	name(name),
	data(data), 
	isRegFunc(false), 
	isOutFunc(false),
	regFuncNum(0),
	outFuncNum(0)
{
}

FuncListEl::~FuncListEl()
{
	delete[] data;
}

int curFuncOrdering = 0;

/* Perform minimization after an operation according 
 * to the command line args. */
void afterOpMinimize( FsmAp *fsm )
{
	/* Switch on the prefered minimization algorithm. */
	if ( minimizeEveryOp ) {
		if ( minimizeLevel != MinimizeNone ) {
			/* First clean up the graph. FsmAp operations may leave these lying
			 * around.  There should be no dead end states however. The
			 * subtract intersection operators are the only places where they
			 * may be created and those operators clean them up. */
			fsm->removeUnreachableStates();
		}

		switch ( minimizeLevel ) {
			case MinimizeNone:
				break;
			case MinimizeApprox:
				fsm->minimizeApproximate();
				break;
			case MinimizePartition1:
				fsm->minimizePartition1();
				break;
			case MinimizePartition2:
				fsm->minimizePartition2();
				break;
			case MinimizeStable:
				fsm->minimizeStable();
				break;
		}
	}
}

/* Count the transitions in the fsm by walking the state list. */
int countTransitions( FsmAp *fsm )
{
	int numTrans = 0;
	StateAp *state = fsm->stateList.head;
	while ( state != 0 ) {
		numTrans += state->outList.length();
		numTrans += state->outRange.length() / 2;
		if ( state->outDefault != 0 )
			numTrans += 1;
		state = state->next;
	}
	return numTrans;
}

/* Count the indicies in a fsm machine by walking array of states. */
int countIndicies( FsmMachine &machine )
{
	int sum = 0;
	for ( int state = 0; state < machine.numStates; state++ )
		sum += machine.allStates[state].numIndex;
	return sum;
}

long makeFsmKeyHex( char *str, const InputLoc &loc, ParseData *pd )
{
	long retVal = 0;

	/* Convert the number to a decimal. Reset errno so we can check for
	 * overflow or underflow. In the event of an error, sets the return val to
	 * the upper or lower bound being tested against. */
	errno = 0;
	unsigned long ul = strtoul( str, 0, 16 );

	switch ( pd->alphType ) {
	case AT_Char: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_UCHAR ) {
			error(loc) << "literal " << str << 
					" overflows char alphabet" << endl;
			ul = RL_MAX_UCHAR;
		}

		/* Cast to a char to get the proper sign, then extend to an integer. */
		retVal = (char)ul;
		break;
	}

	case AT_UnsignedChar: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_UCHAR ) {
			error(loc) << "literal " << str << 
					" overflows unsigned char alphabet" << endl;
			ul = RL_MAX_UCHAR;
		}

		/* Store cast to unsigned char, then extend to an integer. */
		retVal = (unsigned char)ul;
		break;
	}

	case AT_Short: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_USHORT ) {
			error(loc) << "literal " << str << 
					" overflows short alphabet" << endl;
			ul = RL_MAX_USHORT;
		}

		/* Cast to a short to get the proper sign, then extend to an integer. */
		retVal = (short)ul;
		break;
	}

	case AT_UnsignedShort: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_USHORT ) {
			error(loc) << "literal " << str << 
					" overflows unsigned short alphabet" << endl;
			ul = RL_MAX_USHORT;
		}

		/* Store cast to unsigned short, then extend to an integer. */
		retVal = (unsigned short)ul;
		break;
	}

	case AT_Int: {
		/* Check against upper bound. */
		if ( errno == ERANGE && ul == ULONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows int alphabet" << endl;
			ul = ULONG_MAX;
		}

		/* Store in integer format. */
		retVal = (int)ul;
		break;
	}

	case AT_UnsignedInt: {
		/* Check against upper bound. */
		if ( errno == ERANGE && ul == ULONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows unsigned int alphabet" << endl;
			ul = ULONG_MAX;
		}

		/* Store in integer format. */
		retVal = (int)ul;
		break;
	}}
	return retVal;
}

long makeFsmKeyDec( char *str, const InputLoc &loc, ParseData *pd )
{
	long retVal = 0;

	switch ( pd->alphType ) {
	case AT_Char: {
		/* Convert the number to a decimal. If there is overflow or underflow
		 * the num will be set to LONG_MIN/LONG_MAX which are way too low and
		 * high for char anyways so no need to check. */
		retVal = strtol( str, 0, 10 );

		/* Check against lower bound. */
		if ( retVal < RL_MIN_CHAR ) {
	 		error(loc) << "literal " << str << 
					" underflows char alphabet" << endl;
			retVal = RL_MIN_CHAR;
		}

		/* Check against upper bound. */
		if ( retVal > RL_MAX_CHAR ) {
			error(loc) << "literal " << str << 
					" overflows char alphabet" << endl;
			retVal = RL_MAX_CHAR;
		}
		break;
	}

	case AT_UnsignedChar: {
		/* Can't allow a negative decimal number for unsigned char type. */
		if ( str[0] == '-' ) {
			/* Recover by advancing over the dash. */
			error(loc) << "literal " << str << 
					" underflows unsigned char alphabet" << endl;
			str += 1;
		}

		/* Convert to an unsigned number and bounds check it. */
		unsigned long ul = strtoul( str, 0, 10 );
		if ( ul > RL_MAX_UCHAR ) {
			error(loc) << "literal " << str << 
					" overflows unsigned char alphabet" << endl;
			ul = RL_MAX_UCHAR;
		}

		/* Store in integer format. */
		retVal = (int) ul;
		break;
	}

	case AT_Short: {
		/* Convert the number to a decimal. If there is overflow or underflow
		 * the num will be set to the high or low limits which are exceed the
		 * bounds for short so no need to check. */
		retVal = strtol( str, 0, 10 );

		/* Check against lower bound. */
		if ( retVal < RL_MIN_SHORT ) {
	 		error(loc) << "literal " << str << 
					" underflows short alphabet" << endl;
			retVal = RL_MIN_SHORT;
		}

		/* Check against upper bound. */
		if ( retVal > RL_MAX_SHORT ) {
			error(loc) << "literal " << str << 
					" overflows short alphabet" << endl;
			retVal = RL_MAX_SHORT;
		}
		break;
	}

	case AT_UnsignedShort: {
		/* Can't allow a negative decimal number for unsigned short type. */
		if ( str[0] == '-' ) {
			/* Recover by skippping the dash. */
			error(loc) << "literal " << str << 
					" underflows unsigned short alphabet" << endl;
			str += 1;
		}

		/* Convert to an unsigned number and bounds check it. */
		unsigned long ul = strtoul( str, 0, 10 );
		if ( ul > RL_MAX_USHORT ) {
			error(loc) << "literal " << str << 
					" overflows unsigned short alphabet" << endl;
			ul = RL_MAX_USHORT;
		}

		/* Store in integer format. */
		retVal = (int) ul;
		break;
	}

	case AT_Int: {
		/* Convert the number to a decimal. First reset errno so we can check
		 * for overflow or underflow. */
		errno = 0;
		retVal = strtol( str, 0, 10 );

		/* Check lower bound. */
		if ( errno == ERANGE && retVal == LONG_MIN ) {
	 		error(loc) << "literal " << str << 
					" underflows int alphabet" << endl;
			retVal = LONG_MIN;
		}

		/* Check upper bound. */
		if ( errno == ERANGE && retVal == LONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows int alphabet" << endl;
			retVal = LONG_MAX;
		}
		break;
	}

	case AT_UnsignedInt: {
		/* Cannot allow negative numbers for an unsigned type. */
		if ( str[0] == '-' ) {
			/* Recover by skipping the dash. */
			error(loc) << "literal " << str << 
					" underflows unsigned int alphabet" << endl;
			str += 1;
		}

		/* Convert to an unsigned number and bounds check it. */
		errno = 0;
		unsigned int ul = strtoul( str, 0, 10 );
		if ( errno == ERANGE && ul == ULONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows unsigned int alphabet" << endl;
			ul = ULONG_MAX;
		}

		/* Store in integer format. */
		retVal = (int) ul;
		break;
	}}
	return retVal;
}

/* Make an fsm key in int format (what the fsm graph uses) from an alphabet
 * number returned by the parser. Validates that the number doesn't overflow
 * the alphabet type. */
long makeFsmKeyNum( char *str, const InputLoc &loc, ParseData *pd )
{
	/* Switch on hex/decimal format. */
	if ( str[0] == '0' && str[1] == 'x' )
		return makeFsmKeyHex( str, loc, pd );
	else
		return makeFsmKeyDec( str, loc, pd );

}

/* Make an fsm int format (what the fsm graph uses) from a single character.
 * Performs proper conversion depending on signed/unsigned property of the
 * alphabet. */
long makeFsmKeyChar( char c, ParseData *pd )
{
	long retVal;
	if ( pd->isAlphSigned() ) {
		/* Copy from a char type. */
		retVal = c;
	}
	else {
		/* Copy from an unsigned byte type. */
		retVal = (unsigned char)c;
	}
	return retVal;
}

/* Make an fsm key array in int format (what the fsm graph uses) from a string
 * of characters. Performs proper conversion depending on signed/unsigned
 * property of the alphabet. */
void makeFsmKeyArray( long *result, char *data, int len, ParseData *pd )
{
	if ( pd->isAlphSigned() ) {
		/* Copy from a char star type. */
		char *src = data;
		for ( int i = 0; i < len; i++ )
			result[i] = src[i];
	}
	else {
		/* Copy from an unsigned byte ptr type. */
		unsigned char *src = (unsigned char*) data;
		for ( int i = 0; i < len; i++ )
			result[i] = src[i];
	}
}

/* Make a builtin type. Depends on the signed nature of the alphabet type. */
FsmAp *makeBuiltin( BuiltinType builtin, ParseData *pd )
{
	/* FsmAp created to return. */
	FsmAp *retFsm = 0;
	bool isSigned = pd->isAlphSigned();

	switch ( builtin ) {
	case BT_Any: {
		/* All characters. */
		retFsm = new FsmAp( isSigned );
		retFsm->dotFsm( );
		break;
	}
	case BT_Ascii: {
		/* Ascii characters 0 to 127. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( 0, 127 );
		break;
	}
	case BT_Extend: {
		/* Ascii extended characters. This is the full byte range. Dependent
		 * on signed, vs no signed. If the alphabet is one byte then just use
		 * dot fsm. */
		retFsm = new FsmAp( isSigned );
		if ( pd->alphType == AT_Char || pd->alphType == AT_UnsignedChar )
			retFsm->dotFsm( );
		else if ( isSigned )
			retFsm->rangeFsm( -128, 127 );
		else
			retFsm->rangeFsm( 0, 255 );
		break;
	}
	case BT_Alpha: {
		/* Alpha [A-Za-z]. */
		FsmAp *upper = new FsmAp( isSigned ), *lower = new FsmAp( isSigned );
		upper->rangeFsm( 'A', 'Z' );
		lower->rangeFsm( 'a', 'z' );
		upper->unionOp( lower );
		upper->minimizePartition2();
		retFsm = upper;
		break;
	}
	case BT_Digit: {
		/* Digits [0-9]. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( '0', '9' );
		break;
	}
	case BT_Alnum: {
		/* Alpha numerics [0-9A-Za-z]. */
		FsmAp *digit = new FsmAp( isSigned ), *lower = new FsmAp( isSigned );
		FsmAp *upper = new FsmAp( isSigned );
		digit->rangeFsm( '0', '9' );
		upper->rangeFsm( 'A', 'Z' );
		lower->rangeFsm( 'a', 'z' );
		digit->unionOp( upper );
		digit->unionOp( lower );
		digit->minimizePartition2();
		retFsm = digit;
		break;
	}
	case BT_Lower: {
		/* Lower case characters. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( 'a', 'z' );
		break;
	}
	case BT_Upper: {
		/* Upper case characters. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( 'A', 'Z' );
		break;
	}
	case BT_Cntrl: {
		/* Control characters. */
		FsmAp *cntrl = new FsmAp( isSigned ), *highChar = new FsmAp( isSigned );
		cntrl->rangeFsm( 0, 31 );
		highChar->concatFsm( 127 );
		cntrl->unionOp( highChar );
		cntrl->minimizePartition2();
		retFsm = cntrl;
		break;
	}
	case BT_Graph: {
		/* Graphical ascii characters [!-~]. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( '!', '~' );
		break;
	}
	case BT_Print: {
		/* Printable characters. Same as graph except includes space. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( ' ', '~' );
		break;
	}
	case BT_Punct: {
		/* Punctuation. */
		FsmAp *range1 = new FsmAp( isSigned ), *range2 = new FsmAp( isSigned );
		FsmAp *range3 = new FsmAp( isSigned ), *range4 = new FsmAp( isSigned );
		range1->rangeFsm( '!', '/' );
		range2->rangeFsm( ':', '@' );
		range3->rangeFsm( '[', '`' );
		range4->rangeFsm( '{', '~' );
		range1->unionOp( range2 );
		range1->unionOp( range3 );
		range1->unionOp( range4 );
		range1->minimizePartition2();
		retFsm = range1;
		break;
	}
	case BT_Space: {
		/* Whitespace: [\t\v\f\n\r ]. */
		FsmAp *cntrl = new FsmAp( isSigned ), *space = new FsmAp( isSigned );
		cntrl->rangeFsm( '\t', '\r' );
		space->concatFsm( ' ' );
		cntrl->unionOp( space );
		cntrl->minimizePartition2();
		retFsm = cntrl;
		break;
	}
	case BT_Xdigit: {
		/* Hex digits [0-9A-Fa-f]. */
		FsmAp *digit = new FsmAp( isSigned ), *upper = new FsmAp( isSigned );
		FsmAp *lower = new FsmAp( isSigned );
		digit->rangeFsm( '0', '9' );
		upper->rangeFsm( 'A', 'F' );
		lower->rangeFsm( 'a', 'f' );
		digit->unionOp( upper );
		digit->unionOp( lower );
		digit->minimizePartition2();
		retFsm = digit;
		break;
	}}

	return retFsm;
}


/*
 * ParseData
 */

/* Initialize the structure that will collect info during the parse of a
 * machine. */
ParseData::ParseData( const String &fileName )
:	
	funcIndex(0),
	numFuncIndex(0),
	regFuncIndex(0),
	numRegFuncIndex(0),
	outFuncIndex(0),
	numOutFuncIndex(0),

	/* Collected explicit machines. */
	expIsOutPriorSet(false),
	expOutPriority(0),

	nextFuncNum(0), 
	machineGiven(false), 
	alphType(AT_Char),
	fileName(fileName),
	errorCount(0)
{
	/* Initialize the dictionary of graphs. This is our symbol table. The
	 * initialization needs to be done on construction which happens at the
	 * beginning of a machine spec so any assignment operators can reference
	 * the builtins. */
	initGraphDict( );
}

/* Clean up the data collected during a parse. */
ParseData::~ParseData()
{
	if ( funcIndex != 0 )
		delete[] funcIndex;

	/* Delete all the nodes in the function list. Will cause all the
	 * string data that represents the functions to be deallocated. */
	funcList.empty();
	dataList.empty();
	initCodeList.empty();
}

/* Is the alphabet type a signed type? */
bool ParseData::isAlphSigned()
{
	return alphType == AT_Char || alphType == AT_Short || alphType == AT_Int;
}

/* Initialize the graph dict with builtin types. */
void ParseData::initGraphDict( )
{
	/* All characters. */
	graphDict.insert( "any", new ExpressionNode( BT_Any ) );
	graphDict.insert( "ascii", new ExpressionNode( BT_Ascii ) );
	graphDict.insert( "extend", new ExpressionNode( BT_Extend ) );
	graphDict.insert( "alpha", new ExpressionNode( BT_Alpha ) );
	graphDict.insert( "digit", new ExpressionNode( BT_Digit ) );
	graphDict.insert( "alnum", new ExpressionNode( BT_Alnum ) );
	graphDict.insert( "lower", new ExpressionNode( BT_Lower ) );
	graphDict.insert( "upper", new ExpressionNode( BT_Upper ) );
	graphDict.insert( "cntrl", new ExpressionNode( BT_Cntrl ) );
	graphDict.insert( "graph", new ExpressionNode( BT_Graph ) );
	graphDict.insert( "print", new ExpressionNode( BT_Print ) );
	graphDict.insert( "punct", new ExpressionNode( BT_Punct ) );
	graphDict.insert( "space", new ExpressionNode( BT_Space ) );
	graphDict.insert( "xdigit", new ExpressionNode( BT_Xdigit ) );
}

/* Set the alphabet type. If type types are not valid returns false. */
bool ParseData::setAlphType( String s1, String s2 )
{
	bool valid = false;
	if ( strcmp( s1, "unsigned" ) == 0 ) {
		if ( strcmp( s2, "char" ) == 0 ) {
			alphType = AT_UnsignedChar;
			valid = true;
		}
		else if ( strcmp( s2, "short" ) == 0 ) {
			alphType = AT_UnsignedShort;
			valid = true;
		}
		else if ( strcmp( s2, "int" ) == 0 ) {
			alphType = AT_UnsignedInt;
			valid = true;
		}
	}
	return valid;
}

/* Set the alphabet type. If type types are not valid returns false. */
bool ParseData::setAlphType( String s1 )
{
	bool valid = false;
	if ( strcmp( s1, "char" ) == 0 ) {
		alphType = AT_Char;
		valid = true;
	}
	else if ( strcmp( s1, "short" ) == 0 ) {
		alphType = AT_Short;
		valid = true;
	}
	else if ( strcmp( s1, "int" ) == 0 ) {
		alphType = AT_Int;
		valid = true;
	}
	return valid;
}

void ParseData::setLowerUpperRange( )
{
	if ( lowerNum.length() != 0 ) {
		/* If ranges are given then interpret the alphabet type. */
		lowerKey = makeFsmKeyNum( lowerNum, rangeLowLoc, this );
		upperKey = makeFsmKeyNum( upperNum, rangeHighLoc, this );
	}
	else {
		/* Use default ranges for alphabet type. */
		switch ( alphType ) {
		case AT_Char:
			lowerKey = RL_MIN_CHAR;
			upperKey = RL_MAX_CHAR;
			break;
		case AT_UnsignedChar:
			lowerKey = RL_MIN_UCHAR;
			upperKey = RL_MAX_UCHAR;
			break;
		case AT_Short:
			lowerKey = RL_MIN_SHORT;
			upperKey = RL_MAX_SHORT;
			break;
		case AT_UnsignedShort:
			lowerKey = RL_MIN_USHORT;
			upperKey = RL_MAX_USHORT;
			break;
		case AT_Int:
			lowerKey = RL_MIN_INT;
			upperKey = RL_MAX_INT;
			break;
		case AT_UnsignedInt:
			lowerKey = RL_MIN_UINT;
			upperKey = RL_MAX_UINT;
			break;
		}
	}
}

/* Fill the function index for easy access to the functions. */
void ParseData::fillFuncIndex()
{
	/* Make the array of pointers to function list elements. */
	funcIndex = new FuncListEl*[funcList.size()];
	numFuncIndex = funcList.size();

	int funcNum = 0;
	for ( FuncList::Iter flel = funcList; flel.lte(); flel++ )
		funcIndex[funcNum++] = flel.ptr;
}

/* Set where functions called from. */
void ParseData::setFuncsWhereCalledFrom( FsmAp *graph )
{
	/* Loop all states. */
	FsmAp::StateList::Iter state = graph->stateList;
	for ( ; state.lte(); state++ ) {
		/* Loop each transition. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; outIt.lte(); outIt++ ) {
			/* The blocks of code that get executed as regular funcs. */
			FsmAp::TransFuncTable::Iter func = outIt.trans->transFuncTable;
			for ( ; func.lte(); func++ )
				funcIndex[func->value]->isRegFunc = true;
		}

		/* The blocks of code that get executed as out funcs. */
		FsmAp::TransFuncTable::Iter func = state->outTransFuncTable;
		for ( ; func.lte(); func++ )
			funcIndex[func->value]->isOutFunc = true;
	}
}

/* Make func indicies for regular and out funcs. */
void ParseData::fillSpecificFuncIndicies( )
{
	/* Count the number in each. */
	numRegFuncIndex = 0;
	numOutFuncIndex = 0;
	for ( FuncList::Iter flel = funcList; flel.lte(); flel++ ) {
		if ( flel->isRegFunc )
			numRegFuncIndex += 1;
		if ( flel->isOutFunc )
			numOutFuncIndex += 1;
	}

	/* Make arrays. */
	regFuncIndex = new FuncListEl*[numRegFuncIndex];
	outFuncIndex = new FuncListEl*[numOutFuncIndex];

	/* Fill in the arrays. */
	int curReg = 0, curOut = 0;
	for ( FuncList::Iter flel = funcList; flel.lte(); flel++ ) {
		if ( flel->isRegFunc ) {
			regFuncIndex[curReg] = flel.ptr;
			flel->regFuncNum = curReg;
			curReg += 1;
		}
		if ( flel->isOutFunc ) {
			outFuncIndex[curOut] = flel.ptr;
			flel->outFuncNum = curOut;
			curOut += 1;
		}
	}
}

/* Rewrite all transitions to the specific func indicies. NOT USED. */
void ParseData::rewriteFuncIndicies( FsmAp *graph )
{
	/* Loop all states. */
	FsmAp::StateList::Iter state = graph->stateList;
	for ( ; state.lte(); state++ ) {
		/* Loop each transition. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; outIt.lte(); outIt++ ) {
			/* The blocks of code that get executed as regular funcs. */
			FsmAp::TransFuncTable::Iter func = outIt.trans->transFuncTable;
			for ( ; func.lte(); func++ )
				func->value = funcIndex[func->value]->regFuncNum;
		}

		/* The blocks of code that get executed as out funcs. */
		FsmAp::TransFuncTable::Iter func = state->outTransFuncTable;
		for ( ; func.lte(); func++ )
			func->value = funcIndex[func->value]->outFuncNum;
	}
}

/* Make the graph from a graph dict node. Does minimization. */
FsmAp *ParseData::makeGraph( GraphDictEl *gdNode )
{
	/* Build the graph from a walk of the parse tree. */
	FsmAp *graph = gdNode->value->walk( this );

	/* Do final removal of unreachable states. There should be no dead end
	 * states however. The subtract and intersection operators are the
	 * only places where they may be created and those operators clean
	 * them up. */
	graph->removeUnreachableStates();

	/* If minimizing we can optimize the graph somewhat. */
	if ( minimizeLevel != MinimizeNone ) {
		/* No more fsm operations are to be done. Function ordering numbers are
		 * no longer of use and will just hinder minimization. Clear them. */
		graph->nullFunctionKeys();

		/* Transition priorities are no longer of use. We can clear them
		 * because they will just hinder minimization as well. Clear them. */
		graph->allTransPrior( 0 );			
		graph->clearLeaveFsmPrior();
	}

	/* Minimize here even if we minimized at every op. Now that function
	 * keys have been cleared we may get a more minimal fsm. */
	switch ( minimizeLevel ) {
		case MinimizeNone:
			break;
		case MinimizeApprox:
			graph->minimizeApproximate();
			break;
		case MinimizeStable:
			graph->minimizeStable();
			break;
		case MinimizePartition1:
			graph->minimizePartition1();
			break;
		case MinimizePartition2:
			graph->minimizePartition2();
			break;
	}
	
	return graph;
}

/* Find the graph possibly using the machine path. */
GraphDictEl *ParseData::findGraphMaybePath()
{
	GraphDictEl *rtnVal = 0;

	/* Check if this is the spec for which we generate a dot file. */
	if ( machinePath != 0 ) {
		/* There is a path, is this the right spec? If not, then the spec will
		 * get skipped. */
		if ( strcmp(machinePathSpec, fsmName) == 0 ) {
			/* If no name, use main. */
			char *name = machinePathName;
			if ( name == 0 )
				name = "main";

			/* Look for the machine. */
			rtnVal = graphDict.find(name);

			if ( rtnVal != 0 ) {
				/* Remember that we found the path specified. */
				machinePathFound = true;
			}
			else {
				/* No recovery action. fsm is skipped. */
				error(fsmStartSecLoc) << "machine " << name << 
						" not found in " << machinePathSpec << endl;
			}
		}
	}
	else {
		/* No machine path. Looking for main. */
		rtnVal = graphDict.find("main");
		if ( rtnVal == 0 ) {
			/* No recovery action, fsm is skipped. */
			error(fsmStartSecLoc) << "main graph not defined in fsm spec " 
					<< fsmName << endl;
		}
	}
	return rtnVal;
}

void ParseData::dumpFsm()
{
	/* If there were parse errors in this machine then stop now. */
	if ( errorCount > 0 )
		return;

	/* If there was no machine given, we cannot generate a graphviz output. */
	if ( ! machineGiven )
		return;
	
	/* Get the graph possbily using the machine path. If none found then there
	 * was an error or the fsm spec is to be skipped.*/
	GraphDictEl *dictEl = findGraphMaybePath();
	if ( dictEl == 0 )
		return;

	/* Make the graph, do minimization. */
	FsmAp *graph = makeGraph( dictEl );

	/* If any errors have occured in the input file then don't write anything. */
	if ( gblErrorCount > 0 )
		return;

	/* Create a dump object. */
	FsmDump dump( fsmName, this, graph, *outStream );

	/* Dump the fsm. */
	dump.dumpGraph( );
}

void ParseData::printFsm()
{
	/* FIXME: Not yet implemented. */
}


void ParseData::generateGraphviz( )
{
	/* If any errors were encountered during parse of fsm spec, bail on the
	 * generation. */
	if ( errorCount > 0 )
		return;
	
	/* If there was no machine given, we cannot generate a graphviz output. */
	if ( ! machineGiven )
		return;

	/* Get the graph possbily using the machine path. If none found then there
	 * was an error or the fsm spec is to be skipped.*/
	GraphDictEl *dictEl = findGraphMaybePath();
	if ( dictEl == 0 )
		return;

	/* Fill the function index for easy access to the functions. */
	fillFuncIndex();

	/* Make the graph, do minimization. */
	FsmAp *graph = makeGraph( dictEl );

	/* If any errors have occured in the input file then don't write anything. */
	if ( gblErrorCount > 0 )
		return;

	/* If a graphviz output has already been generated, emit a warning to say
	 * that no more can be done because graphviz will barf. */
	if ( graphvizDone ) {
		warning(fsmStartSecLoc) << "graphviz accepts only a "
				"single graph, try ragel with -M" << endl;
		return;
	}

	/* Make the generator. */
	GraphvizDotGen dotGen( fsmName, this, graph, *outStream );

	/* Write out with it. */
	dotGen.writeDotFile();

	/* Remember that we wrote out a dot file. */
	graphvizDone = true;
}


/* Generate the codegen depending on the command line options given. */
FsmCodeGen *ParseData::makeCodeGen( FsmMachine *machine )
{
	FsmCodeGen *codeGen = 0;
	switch ( outputFormat ) {
	case OutCCode:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFTables:
			codeGen = new CFTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenGoto:
			codeGen = new CGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFGoto:
			codeGen = new CFGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenIpGoto:
			codeGen = new CIpGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		}
		break;
	case OutCppCode:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CCTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFTables:
			codeGen = new CCFTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenGoto:
			codeGen = new CCGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFGoto:
			codeGen = new CCFGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenIpGoto:
			codeGen = new CCIpGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		}
		break;

	/* Called codegen when generating something else. */
	default:
		assert( false );
	}
	return codeGen;
}


/* Generate the code for an fsm. Assumes parseData is set up properly. Called
 * by parser code. */
void ParseData::generateCode( )
{
	/* The machine that will take the compressed fsm and the code generator. */
	FsmMachine *machine = 0;
	FsmCodeGen *codeGen = 0;

	/* If any errors were encountered during parse of fsm spec, bail on the
	 * generation. */
	if ( errorCount > 0 )
		return;

	/* Nothing to do if there is no datalist or machine given. */
	if ( dataList.length() == 0 && ! machineGiven )
		return;
	
	/* If the graph dict is given, find the main machine. */
	if ( machineGiven ) {
		/* Get the main line from the graph dict. */
		GraphDictEl *gdNode = graphDict.find("main");
		if ( gdNode == 0 ) {
			/* No recovery action, fsm is skipped. */
			error(fsmStartSecLoc) << "main graph not defined in fsm " 
					<< fsmName << endl;
			return;
		}

		/* Interpret the alphabet type. */
		setLowerUpperRange( );

		/* Fill the function index for easy access to the functions. */
		fillFuncIndex();

		/* Make the graph, do minimization. */
		FsmAp *graph = makeGraph( gdNode );

		/* Create a new machine and build it from the graph. */
		machine = new FsmMachine;
		buildMachine( machine, graph );
	}

	/* If any errors have occured in the input file then don't write anything. */
	if ( gblErrorCount > 0 )
		return;

	/* Make a code generator that will output the header/code. */
	codeGen = makeCodeGen( machine );

	/* Write line directive. */
	codeGen->startCodeGen();

	/* If the struct element was used then output the header portion. */
	if ( dataList.length() > 0 )
		codeGen->writeOutHeader( );
	
	/* If there was a machine given, gather info on it and write it out. */
	if ( machineGiven ) {
		codeGen->analyzeMachine();
		codeGen->writeOutCode( );
	}

	/* Write line directive. */
	codeGen->endCodeGen();

	/* Done with the code generator. */
	delete codeGen;
	delete machine;
}

/* Clean up after an expression node. */
ExpressionNode::~ExpressionNode()
{
	switch ( type ) {
		case Or: case Intersect: case Subtract:
			delete expression;
			delete term;
			break;
		case Term:
			delete term;
			break;
		case Builtin:
			break;
	}
}


/* Evaluate and expression node. */
FsmAp *ExpressionNode::walk( ParseData *pd )
{
	FsmAp *rtnVal = 0;
	switch ( type ) {
		case Or: {
			/* Evaluate the expression. */
			rtnVal = expression->walk( pd );
			/* Evaluate the term. */
			FsmAp *rhs = term->walk( pd );
			/* Perform union. */
			rtnVal->unionOp( rhs );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case Intersect: {
			/* Evaluate the expression. */
			rtnVal = expression->walk( pd );
			/* Evaluate the term. */
			FsmAp *rhs = term->walk( pd );
			/* Perform intersection. */
			rtnVal->intersectOp( rhs );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case Subtract: {
			/* Evaluate the expression. */
			rtnVal = expression->walk( pd );
			/* Evaluate the term. */
			FsmAp *rhs = term->walk( pd );
			/* Perform subtraction. */
			rtnVal->subtractOp( rhs );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case Term: {
			/* Return result of the term. */
			rtnVal = term->walk( pd );
			break;
		}
		case Builtin: {
			/* Duplicate the builtin. */
			rtnVal = makeBuiltin( builtin, pd );
			break;
		}
	}

	return rtnVal;
}

/* Clean up after a term node. */
TermNode::~TermNode()
{
	switch ( type ) {
		case Concat:
			delete term;
			delete factorWithAug;
			break;
		case FactorWithAug:
			delete factorWithAug;
			break;
	}
}

/* Evaluate a term node. */
FsmAp *TermNode::walk( ParseData *pd )
{
	FsmAp *rtnVal = 0;
	switch ( type ) {
		case Concat: {
			/* Evaluate the Term. */
			rtnVal = term->walk( pd );
			/* Evaluate the FactorWithRep. */
			FsmAp *rhs = factorWithAug->walk( pd );
			/* Perform concatenation. */
			rtnVal->concatOp( rhs, leavingFsm );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case FactorWithAug: {
			rtnVal = factorWithAug->walk( pd );
			break;
		}
	}
	return rtnVal;
}

/* Clean up after a factor with augmentation node. */
FactorWithAugNode::~FactorWithAugNode()
{
	delete factorWithRep;

	/* Walk the vector of parser funcs, deleting function names. */
}

/* Evaluate a factor with augmentation node. */
FsmAp *FactorWithAugNode::walk( ParseData *pd )
{
	/* First walk the list of functions, assigning the
	 * starting function ordering. */
	ParserFunc *func = funcs.data;
	int i, nFuncs = funcs.length();
	for ( i = 0; i < nFuncs; i++, func++ ) {
		if ( func->type == start )
			func->ordering = curFuncOrdering++;
	}

	/* Evaluate the factor with repetition. */
	FsmAp *rtnVal = factorWithRep->walk( pd );

	/* Now compute the remaining function call orderings. */
	func = funcs.data;
	nFuncs = funcs.length();
	for ( i = 0; i < nFuncs; i++, func++ ) {
		if ( func->type != start )
			func->ordering = curFuncOrdering++;
	}

	/* Assign functions. */
	func = funcs.data;
	nFuncs = funcs.length();
	for ( i = 0; i < nFuncs; i++, func++ )  {
		if ( func->func == FUNC_NUM_CLEAR ) {
			switch ( func->type ) {
			case start:
				/* Changing start functions affects potential minimization. */
				rtnVal->clearStartFsmFunc( );
				afterOpMinimize( rtnVal );
				break;
			case all:
				rtnVal->clearAllTransFunc( );
				break;
			case fin:
				rtnVal->clearFinFsmFunc( );
				break;
			case leave:
				rtnVal->clearLeaveFsmFunc( );
				break;
			case clearLeave:
				assert(false);
			}
		}
		else {
			switch ( func->type ) {
			case start:
				/* Start fsm funcs are a special case that may require
				 * minimization afterwards. */
				rtnVal->startFsmFunc( func->func, func->ordering );
				afterOpMinimize( rtnVal );
				break;
			case all:
				rtnVal->allTransFunc( func->func, func->ordering );
				break;
			case fin:
				rtnVal->finFsmFunc( func->func, func->ordering );
				break;
			case leave:
				rtnVal->leaveFsmFunc( func->func, func->ordering );
				break;
			case clearLeave:
				assert(false);
			}
		}
	}

	/* Assign priorities. */
	PriorityAug *aug = priorityAugs.data;
	int nAugs = priorityAugs.length();
	for ( i = 0; i < nAugs; i++, aug++ ) {
		switch ( aug->type ) {
			case start:
				rtnVal->startFsmPrior( aug->value );
				/* Start fsm priorities are a special case that may require
				 * minimization afterwards. */
				afterOpMinimize( rtnVal );
				break;
			case all:
				rtnVal->allTransPrior( aug->value );
				break;
			case fin:
				rtnVal->finFsmPrior( aug->value );
				break;
			case leave:
				rtnVal->leaveFsmPrior( aug->value );
				break;
			case clearLeave:
				rtnVal->clearLeaveFsmPrior();
				break;
		}
	}
	
	return rtnVal;
}

/* Clean up after a factor with repetition node. */
FactorWithRepNode::~FactorWithRepNode()
{
	switch ( type ) {
		case Star: case Optional: case Plus: case Negate:
			delete factorWithRep;
			break;
		case Factor:
			delete factor;
			break;
	}
}

/* Evaluate a factor with repetition node. */
FsmAp *FactorWithRepNode::walk( ParseData *pd )
{
	FsmAp *retFsm = 0;
	bool isSigned = pd->isAlphSigned();

	switch ( type ) {
	case Star: {
		/* Evaluate the FactorWithRep. */
		retFsm = factorWithRep->walk( pd );

		/* Perform the kleen star. */
		if ( leavingFsm ) {
			curFuncOrdering +=
					retFsm->shiftStartFuncOrder( curFuncOrdering );
		}

		if ( retFsm->findEntry(0)->isFinState() ) {
			warning(loc) << "applying kleene star to a machine that "
					"accpets zero length word" << endl;
		}

		retFsm->starOp( leavingFsm );

		/* Minimization. */
		afterOpMinimize( retFsm );
		break;
	}
	case Optional: {
		/* Make the null fsm. */
		FsmAp *nu = new FsmAp( isSigned );
		nu->nullFsm( );

		/* Evaluate the FactorWithRep. */
		retFsm = factorWithRep->walk( pd );

		/* Perform the question operator. */
		retFsm->unionOp( nu );

		/* Minimization. */
		afterOpMinimize( retFsm );
		break;
	}
	case Plus: {
		/* Evaluate the FactorWithRep. */
		retFsm = factorWithRep->walk( pd );

		/* Perform the plus operator. */
		FsmAp *dup = new FsmAp( *retFsm );
		/* If the op is a leaving op then the start func orders need to be
		 * shifted before doing the star. */
		if ( leavingFsm )
			curFuncOrdering += dup->shiftStartFuncOrder( curFuncOrdering );

		if ( dup->findEntry(0)->isFinState() ) {
			warning(loc) << "applying kleene star to a machine that "
					"accpets zero length word" << endl;
		}
		dup->starOp( leavingFsm );

		/* Intermediate minimization. */
		afterOpMinimize( dup );
		retFsm->concatOp( dup, leavingFsm );

		/* Minimization. */
		afterOpMinimize( retFsm );
		break;
	}
	case Negate: {
		/* Evaluate the FactorWithRep. */
		FsmAp *toNegate = factorWithRep->walk( pd );

		/* Negation is subtract from dot-star. */
		retFsm = new FsmAp( isSigned );
		retFsm->dotStarFsm( );
		retFsm->subtractOp( toNegate );

		/* Minimization. */
		afterOpMinimize( retFsm );
		break;
	}
	case Factor: {
		/* Evaluate the Factor. Pass it up. */
		retFsm = factor->walk( pd );
		break;
	}}
	return retFsm;
}

/* Clean up after a factor node. */
FactorNode::~FactorNode()
{
	switch ( type ) {
		case LiteralFsm:
			delete literal;
			break;
		case RangeFsm:
			delete range;
			break;
		case RegularExpression:
			delete regExp;
			break;
		case Explicit:
			delete explicitMach;
			break;
		case LookupExpression:
			break;
		case Expression:
			delete expression;
			break;
	}
}

/* Evaluate a factor node. */
FsmAp *FactorNode::walk( ParseData *pd )
{
	FsmAp *rtnVal = 0;
	switch ( type ) {
		case LiteralFsm:
			rtnVal = literal->walk( pd );
			break;
		case RangeFsm:
			rtnVal = range->walk( pd );
			break;
		case RegularExpression:
			rtnVal = regExp->walk( pd );
			break;
		case Explicit:
			rtnVal = explicitMach->walk( pd );
			break;
		case LookupExpression:
		case Expression:
			rtnVal = expression->walk( pd );
			break;
	}
	return rtnVal;
}

/* Clean up a range object. Must delete the two literals. */
Range::~Range()
{
	delete lowerLit;
	delete upperLit;
}

/* Evaluate a range. Gets the lower an upper key and makes an fsm range. */
FsmAp *Range::walk( ParseData *pd )
{
	long lowerKey = lowerLit->makeRangeEndPoint( pd );
	long upperKey = upperLit->makeRangeEndPoint( pd );

	/* Make the range fsm so we can have the key compare available. */
	FsmAp *retFsm = new FsmAp( pd->isAlphSigned() );

	/* Validate the range. */
	if ( retFsm->gt( lowerKey, upperKey ) ) {
		/* Recover by setting upper to lower; */
		error(lowerLit->loc) << "lower end of range " << lowerLit->str << 
				" is greater then upper end " << upperLit->str << endl;
		upperKey = lowerKey;
	}

	/* Return the range now that it is validated. */
	retFsm->rangeFsm( lowerKey, upperKey );
	return retFsm;
}

/* Return an fsm key for a literal that is a range end point. */
long Literal::makeRangeEndPoint( ParseData *pd )
{
	long retVal;
	switch ( type ) {
	case Number: {
		/* Make the fsm key from the number. */
		retVal = makeFsmKeyNum( str, loc, pd );
		break;
	}
	case LitString: {
		/* The string should be verified length one. */
		makeFsmKeyArray( &retVal, str, 1, pd );
		break;
	}
	case OrLitString: {
		/* Should not be used for a range. */
		assert( false );
		break;
	}}
	return retVal;
}

/* Evaluate a literal object. */
FsmAp *Literal::walk( ParseData *pd )
{
	/* FsmAp to return, is the alphabet signed. */
	FsmAp *rtnVal = 0;
	bool isSigned = pd->isAlphSigned();

	switch ( type ) {
	case Number: {
		/* Make the fsm key in int format. */
		long fsmKey = makeFsmKeyNum( str, loc, pd );
		/* Make the new machine. */
		rtnVal = new FsmAp( isSigned );
		rtnVal->concatFsm( fsmKey );
		break;
	}
	case LitString: {
		/* Make the array of keys in int format. */
		long *arr = new long[str.length()];
		makeFsmKeyArray( arr, str, str.length(), pd );

		/* Make the new machine. */
		rtnVal = new FsmAp( isSigned );
		rtnVal->concatFsm( arr, str.length() );
		delete[] arr;
		break;
	}
	case OrLitString: {
		/* Make the array of keys in int format. */
		long *arr = new long[str.length()];
		makeFsmKeyArray( arr, str, str.length(), pd );

		/* FIXME: arr must not contain any duplicate values. */
		rtnVal = new FsmAp( isSigned );
		rtnVal->orFsm( arr, str.length() );
		delete[] arr;
		break;
	}}
	return rtnVal;
}

/* Clean up after a regular expression object. */
RegExp::~RegExp()
{
	switch ( type ) {
		case RecurseItem:
			delete regExp;
			delete item;
			break;
		case Empty:
			break;
	}
}

/* Evaluate a regular expression object. */
FsmAp *RegExp::walk( ParseData *pd )
{
	FsmAp *rtnVal = 0;
	switch ( type ) {
		case RecurseItem: {
			/* Walk both items. */
			FsmAp *fsm1 = regExp->walk( pd );
			FsmAp *fsm2 = item->walk( pd );
			if ( fsm1 == 0 )
				rtnVal = fsm2;
			else {
				fsm1->concatOp( fsm2, false );
				rtnVal = fsm1;
			}
			break;
		}
		case Empty: {
			rtnVal = 0;
			break;
		}
	}
	return rtnVal;
}

/* Clean up after an item in a regular expression. */
ReItem::~ReItem()
{
	switch ( type ) {
		case Data:
		case Dot:
			break;
		case OrBlock:
		case NegOrBlock:
			delete orBlock;
			break;
	}
}

/* Evaluate a regular expression object. */
FsmAp *ReItem::walk( ParseData *pd )
{
	/* The fsm to return, is the alphabet signed? */
	FsmAp *rtnVal = 0;
	bool isSigned = pd->isAlphSigned();

	switch ( type ) {
		case Data: {
			/* Move the data into an integer array and make a concat fsm. */
			long *arr = new long[str.length()];
			makeFsmKeyArray( arr, str, str.length(), pd );

			/* Make the concat fsm. */
			rtnVal = new FsmAp( isSigned );
			rtnVal->concatFsm( arr, str.length() );

			/* If the data item is stared, it should be of length one. */
			assert( ! (str.length() > 1 && star ) );
			delete[] arr;
			break;
		}
		case Dot: {
			/* Make the dot fsm. */
			rtnVal = new FsmAp( isSigned );
			rtnVal->dotFsm( );
			break;
		}
		case OrBlock: {
			/* Get the or block and minmize it. */
			rtnVal = orBlock->walk( pd );
			rtnVal->minimizePartition2();
			break;
		}
		case NegOrBlock: {
			/* Get the or block and minimize it. */
			FsmAp *fsm = orBlock->walk( pd );
			fsm->minimizePartition2();

			/* Make a dot fsm and subtract from it. */
			rtnVal = new FsmAp( isSigned );
			rtnVal->dotFsm( );
			rtnVal->subtractOp( fsm );
			rtnVal->minimizePartition2();
			break;
		}
	}

	/* If the item is followed by a star, then apply the star op. */
	if ( star ) {
		if ( rtnVal->findEntry(0)->isFinState() ) {
			warning(loc) << "applying kleene star to a machine that "
					"accpets zero length word" << endl;
		}

		rtnVal->starOp(false);
		rtnVal->minimizePartition2();
	}
	return rtnVal;
}

/* Clean up after an or block of a regular expression. */
ReOrBlock::~ReOrBlock()
{
	switch ( type ) {
		case RecurseItem:
			delete orBlock;
			delete item;
			break;
		case Empty:
			break;
	}
}


/* Evaluate an or block of a regular expression. */
FsmAp *ReOrBlock::walk( ParseData *pd )
{
	FsmAp *rtnVal = 0;
	switch ( type ) {
		case RecurseItem: {
			/* Evaluate the two fsm. */
			FsmAp *fsm1 = orBlock->walk( pd );
			FsmAp *fsm2 = item->walk( pd );
			if ( fsm1 == 0 )
				rtnVal = fsm2;
			else {
				fsm1->unionOp( fsm2 );
				rtnVal = fsm1;
			}
			break;
		}
		case Empty: {
			rtnVal = 0;
			break;
		}
	}
	return rtnVal;;
}

/* Evaluate an or block item of a regular expression. */
FsmAp *ReOrItem::walk( ParseData *pd )
{
	/* The return value, is the alphabet signed? */
	FsmAp *rtnVal = 0;
	bool isSigned = pd->isAlphSigned();
	switch ( type ) {
	case Data: {
		/* Put the or data into an array of ints. */
		long *arr = new long[str.length()];
		makeFsmKeyArray( arr, str, str.length(), pd );

		/* Make the or machine. FIXME: keys must be unique. */
		rtnVal = new FsmAp( isSigned );
		rtnVal->orFsm( arr, str.length() );
		delete[] arr;
		break;
	}
	case Range: {
		/* Make the upper and lower keys. */
		long lowerKey = makeFsmKeyChar( lower, pd );
		long upperKey = makeFsmKeyChar( upper, pd );

		/* Make the range machine. */
		rtnVal = new FsmAp( isSigned );
		rtnVal->rangeFsm( lowerKey, upperKey );
		break;
	}}
	return rtnVal;
}

/* Construct an explicit machine. */
ExplicitMachine::ExplicitMachine( const InputLoc &loc, const ExpStateList &sl )
:
	loc(loc),
	stateList()
{
	/* Transfer the state list in. */
	stateList.shallowCopy( sl );
}

/* Generate an explicit machine. */
FsmAp *ExplicitMachine::walk( ParseData *pd )
{
	/* Machine to return. */
	FsmAp *rtnVal;
	cout << "making explicit machine" << endl;
	for ( ExpStateList::Iter state = stateList; state.lte(); state++ ) {
		cout << "> " << state->name <<
			" prior set: " << state->isOutPriorSet << " out prior: " << state->outPriority << 
			" nfuncs: " << state->outFuncs.length() << " start: " << state->isStart << 
			" final: " << state->isFinState << endl;
		
		for ( ExpTransList::Iter tl = state->transList; tl.lte(); tl++ ) {
			cout << "   expr: " << tl->expression << " targ: " << 
				tl->targState << endl;
		}
	}

	/* Make sure there is not more than one start state. */
	bool startStateSeen = false;
	for ( ExpStateList::Iter state = stateList; state.lte(); state++ ) {
		/* If the state is start state... */
		if ( state->isStart ) {
			/* ... and a start state has been seen then barf. */
			if ( startStateSeen ) {
				/* No recovery action needed. */
				error(loc) << "explicit machine has more than "
						"one start state" << endl;
			}
			startStateSeen = true;
		}
	}

	/* Make sure there is a start state. */
	if ( !startStateSeen ) {
		/* No recovery action needed. */
		error(loc) << "explicit machine does not have a start state" << endl;
	}
	
	/* Only allow final states to have out priorities or out functions. */
	for ( ExpStateList::Iter state = stateList; state.lte(); state++ ) {
		/* If the state is not a final stat then check for priors/funcs. */
		if ( !state->isFinState ) {
			/* Cannot have an out priority. */
			if ( state->isOutPriorSet ) {
				/* No recovery action needed. */
				error(state->loc) << "only final states may have "
						"out priorities" << endl;
			}
			/* Cannot have any functions. */
			if ( state->outFuncs.length() > 0 ) {
				/* No recovery action needed. */
				error(state->loc) << "only final states may have "
						"out functions" << endl;
			}
		}
	}

	/* Map states to corresponding states in the graph returned. */
	AvlMap<char *, StateAp*, CmpStr> stateMap;

	/* Make the new machine and corresponding states. Keep a map of state
	 * names to states in the machine to return. */
	rtnVal = new FsmAp( pd->isAlphSigned() );
	for ( ExpStateList::Iter state = stateList; state.lte(); state++ ) {
		/* Make a new state. */
		StateAp *newState = rtnVal->newState();

		/* Keep a map to the state. */
		stateMap.insert( state->name, newState );
	}

	/* Fill in each state. */
	for ( ExpStateList::Iter state = stateList; state.lte(); state++ ) {
		/* Get the fsm state. */
		StateAp *stateAp = stateMap.find( state->name )->value;

		/* Out priority? */
		if ( state->isOutPriorSet ) {
			stateAp->isOutPriorSet = true;
			stateAp->outPriority = state->outPriority;
		}

		/* Leaving functions. */
		int nFuncs = state->outFuncs.length();
		if ( nFuncs > 0 ) {
			SBstMapEl<int, int> *funcs = new SBstMapEl<int, int>[nFuncs];
			for ( int pos = 0; pos < nFuncs; pos++ ) {
				funcs[pos].key = curFuncOrdering++;
				funcs[pos].value = state->outFuncs.data[pos];
			}

			/* Append the leaving funcs. */
			stateAp->outTransFuncTable.setAs( funcs, nFuncs );
			delete[] funcs;
		}

		/* Start state status? */
		if ( state->isStart )
			rtnVal->setEntry( 0, stateAp );

		/* Final state status? */
		if ( state->isFinState )
			rtnVal->setFinState( stateAp );
	}

	return rtnVal;
}

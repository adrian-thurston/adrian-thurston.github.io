/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _GOTOCODEGEN_H
#define _GOTOCODEGEN_H

#include <iostream>
#include "fsmcodegen.h"

/* Forwards. */
struct FsmMachine;
struct FsmMachState;
struct FsmMachTrans;
struct ParseData;

/*
 * Goto driven fsm.
 */
class GotoCodeGen : public FsmCodeGen
{
public:
	GotoCodeGen( char *fsmName, ParseData *parseData, 
			FsmMachine *machine, std::ostream &out );

	std::ostream &FUNC_SWITCH();
	std::ostream &JUMP_IN_SWITCH();
	std::ostream &STATE_GOTOS( );
	std::ostream &TRANSITIONS();
	std::ostream &EXEC_FUNCS();
	std::ostream &EXIT_STATES();
	std::ostream &FINISH_CASES();
	std::ostream &TRANS_GOTO( FsmMachTrans *trans, int level );

	/* This is needed by emitTransGoto, but defined in the language dependent
	 * classes, so it is virtual. */
	virtual std::ostream &FSM_PREFIX() 
		{ return out; }

	void emitRangeBSearch( FsmMachState *state, int level, int low, int high );

	/* Called from STATE_GOTOS just before writing the gotos for each state. */
	virtual void aboveStateGotos( int st ) { }

	/* Set up labelNeeded flag for each state. */
	void setLabelsNeeded();
};

/*
 * class CGotoCodeGen
 */
class CGotoCodeGen : public GotoCodeGen
{
public:
	CGotoCodeGen( char *fsmName, ParseData *parseData, 
			FsmMachine *machine, std::ostream &out );

	virtual std::ostream &FSM_PREFIX();

	virtual void writeOutHeader();
	virtual void writeOutCode();
};

/*
 * class CCGotoCodeGen
 */
class CCGotoCodeGen : public GotoCodeGen
{
public:
	CCGotoCodeGen( char *fsmName, ParseData *parseData, 
			FsmMachine *machine, std::ostream &out );

	virtual std::ostream &FSM_PREFIX();

	virtual void writeOutHeader();
	virtual void writeOutCode();

protected:
	void stateOutFunc(FsmMachState *state);
};


#endif /* _GOTOCODEGEN_H */

/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _PARSETREE_H
#define _PARSETREE_H

#include "ptreetypes.h"
#include "astring.h"
#include "avlmap.h"
#include "bstmap.h"
#include "astring.h"
#include "vectsimp.h"

#define FUNC_NUM_CLEAR -1

/* Forwards. */
struct FsmMachine;
struct FsmCodeGen;
struct FsmAp;

/* Types of builtin machines. */
enum BuiltinType
{
	BT_Any,
	BT_Ascii,
	BT_Extend,
	BT_Alpha,
	BT_Digit,
	BT_Alnum,
	BT_Lower,
	BT_Upper,
	BT_Cntrl,
	BT_Graph,
	BT_Print,
	BT_Punct,
	BT_Space,
	BT_Xdigit
};

/* Location in an input file. */
struct InputLoc
{
	InputLoc( ) 
		: line(0), col(0) { }
	InputLoc( const BISON_YYLTYPE &loc );

	int line;
	int col;
};

/* Element in a generic list of strings. */
struct StringListEl : public DListEl<StringListEl>
{
public:
	StringListEl( const InputLoc &loc, char *data ) 
			: loc(loc), data(data) { }
	~StringListEl() { delete[] data; }

	InputLoc loc;
	char *data;
};

/* List of string elements. Used for functions and data to go
 * into the fsm struct. */
typedef DList<StringListEl> StringList;

/* Element in list of actions. Contains the string for the 
 * code to exectute. */
struct FuncListEl : public DListEl<FuncListEl>
{
public:
	FuncListEl( const InputLoc &loc, char *name, char *data );
	~FuncListEl();

	InputLoc loc;
	char *name;
	char *data;
	bool isRegFunc;
	bool isOutFunc;
	int regFuncNum;
	int outFuncNum;
};

/* A list of functions. */
typedef DList<FuncListEl> FuncList;

/* Global counting the function ordering. */
extern int curFuncOrdering;

/* Store the value and type of a priority augmentation. */
struct PriorityAug
{
	PriorityAug( AugType type, int val ) :
		type(type), value(val) { }

	AugType type;
	int value;
};

/* Structrue represents a function assigned to some FactorWithAug
 * node. The factor with aug will keep an array of these. */
struct ParserFunc
{
	ParserFunc( int func, int ordering, AugType type ) :
		func(func), ordering(0), type(type) { }

	int func;
	int ordering;
	AugType type;
};

struct ExpressionNode;
struct TermNode;
struct FactorWithAugNode;
struct FactorWithRepNode;
struct FactorNode;
struct Literal;
struct Range;
struct RegExp;
struct ReItem;
struct ReOrBlock;
struct ReOrItem;
struct ExplicitMachine;

typedef AvlMapEl<char*, ExpressionNode*> GraphDictEl;
typedef AvlMap<char*, ExpressionNode*, CmpStr> GraphDict;

/*
 * FuncDict
 */
typedef BstMapEl<char*, int> FuncDictEl;
typedef BstMap<char*, int, CmpStr> FuncDict;

enum AlphType
{
	AT_Char,
	AT_UnsignedChar,
	AT_Short,
	AT_UnsignedShort,
	AT_Int,
	AT_UnsignedInt
};

enum ExpKeyType {
	SingleCharLit,
	Number
};

/* Single transition in an explicit state machine. */
struct ExpTrans
{
	ExpTrans( ExpressionNode *expression, char *targState )
			: expression(expression), targState(targState) {}

	ExpressionNode *expression;
	char *targState;
};

/* List of explicit machine transitions. */
typedef VectSimp<int> ExpOutFuncs;
typedef Vector<ExpTrans> ExpTransList;

#define ESM_START 0x1
#define ESM_FINAL 0x2

/* State in an explicit state machine. */
struct ExpState
{
	ExpState( const InputLoc &loc, bool isStart, bool isFinState, char *name, 
			const ExpOutFuncs &outFuncs, bool isOutPriorSet, int outPriority, 
			const ExpTransList &transList )
	:
		loc(loc),
		isStart(isStart),
		isFinState(isFinState),
		name(name),
		outFuncs(outFuncs),
		isOutPriorSet(isOutPriorSet),
		outPriority(outPriority),
		transList(transList)
	{ }

	/* Line info. */
	InputLoc loc;

	/* State attributes. */
	bool isStart, isFinState;

	/* Name of state. */
	char *name;

	/* List of out functions if the state is final. */
	ExpOutFuncs outFuncs;

	/* Out priority if the state is final. */
	bool isOutPriorSet;
	int outPriority;

	/* Transition list for the state. */
	ExpTransList transList;

	/* Pointers for the double list of explicit machine states. */
	ExpState *prev, *next;
};

/* List of explicit machine states. */
typedef DList<ExpState> ExpStateList;

/* Class to collect information about the machine during the 
 * parse of input. */
class ParseData
{
public:
	/* Create a new parse data object. This is done at the beginning of every
	 * fsm specification. */
	ParseData( const String &fileName );
	~ParseData();

	/*
	 * Setting up the graph dict.
	 */

	/* Initialize a graph dict with the basic fsms. */
	void initGraphDict( );

	/* Make an index of pointers to the function blocks. */
	void fillFuncIndex();

	/* Set where functions called from. */
	void setFuncsWhereCalledFrom( FsmAp *graph );

	/* Make func indicies for regular and out funcs. */
	void fillSpecificFuncIndicies();

	/* Rewrite all transitions to the specific func indicies. */
	void rewriteFuncIndicies( FsmAp *graph );

	/* Set the alphabet type. If type types are not valid returns false. */
	bool setAlphType( String s1, String s2 );
	bool setAlphType( String s1 );

	/* Make the graph from a graph dict node. Does minimization. */
	FsmAp *makeGraph( GraphDictEl *gdNode );

	/* Find the graph possibly using the machine path. */
	GraphDictEl *findGraphMaybePath();

	/* Dumping and printing. */
	void dumpFsm();
	void printFsm();

	/* Generate graphviz code. */
	void generateGraphviz();

	/* Generate and write out the fsm. */
	void generateCode( );
	void doGenerateCode( GraphDictEl *gdNode );
	FsmCodeGen *makeCodeGen( FsmMachine *machine );

	/* Set the lower and upper range from the lower and upper number keys. */
	void setLowerUpperRange( );

	/*
	 * Querying the parse data
	 */

	/* Is the alphabet a signed type? */
	bool isAlphSigned();
	
	/*
	 * Data collected during the parse.
	 */

	/* Dictionary of graphs. When done we will lookup "main" */
	GraphDict graphDict;

	/* Dictionary of functions. Lets functions be defined and then 'called'.
	 * They are not really called though, just used. */
	FuncDict funcDict;

	/* List of functions. Will be pasted into a switch statement. */
	FuncList funcList;
	FuncListEl **funcIndex;
	int numFuncIndex;
	FuncListEl **regFuncIndex;
	int numRegFuncIndex;
	FuncListEl **outFuncIndex;
	int numOutFuncIndex;

	/* List of sections of data to add to the fsm struct. */
	StringList dataList;

	/* Collecting explicit machines. */
	ExpOutFuncs expOutFuncs;
	bool expIsOutPriorSet;
	int expOutPriority;
	ExpTransList expTransList;
	ExpStateList expStateList;

	/* The func id of the next function. */
	int nextFuncNum;

	/* If a machine is given this is set. */
	bool machineGiven;

	/* Code sections to put before and after the function execute section. */
	StringList initCodeList;

	/* Alphabet type. */
	AlphType alphType;

	/* The alphabet range. */
	String lowerNum, upperNum;
	long lowerKey, upperKey;
	InputLoc rangeLowLoc, rangeHighLoc;

	/* The name and location of the fsm. */
	String fsmName;
	InputLoc fsmStartSecLoc;
	InputLoc fsmEndSecLoc;

	/* The name of the file the fsm is from. */
	String fileName;

	/* Number of errors encountered parsing the fsm spec. */
	int errorCount;
};

/*
 * ExpressionNode
 */
struct ExpressionNode
{
	enum ExpressionNodeType { Or, Intersect, Subtract, Term, Builtin };

	/* Construct with an expression on the left and a term on the right. */
	ExpressionNode( ExpressionNode *expression, TermNode *term, 
		ExpressionNodeType type) : expression(expression), 
		term(term), builtin(builtin), type(type) { }

	/* Construct with only a term. */
	ExpressionNode( TermNode *term ) :
		expression(0), term(term), builtin(builtin), type(Term) { }
	
	/* Construct with a builtin type. */
	ExpressionNode( BuiltinType builtin ) :
		expression(0), term(0), builtin(builtin), type(Builtin) { }

	~ExpressionNode();

	/* Evaluate the expression. */
	FsmAp *walk( ParseData *pd );

	/* Data stored by the node. */
	ExpressionNode *expression;
	TermNode *term;
	BuiltinType builtin;
	ExpressionNodeType type;
};

/*
 * TermNode
 */
struct TermNode 
{
	enum TermNodeType { Concat, FactorWithAug };

	TermNode( bool leavingFsm, TermNode *term, FactorWithAugNode *factorWithAug ) :
		leavingFsm(leavingFsm), term(term), 
		factorWithAug(factorWithAug), type(Concat) { }

	TermNode( FactorWithAugNode *factorWithAug ) :
		leavingFsm(true), term(0), 
		factorWithAug(factorWithAug), type(FactorWithAug) { }
	
	~TermNode();

	FsmAp *walk( ParseData *pd );

	bool leavingFsm;
	TermNode *term;
	FactorWithAugNode *factorWithAug;
	TermNodeType type;
};

/*
 * FactorWithAugNode
 */
struct FactorWithAugNode
{
	FactorWithAugNode(FactorWithRepNode *factorWithRep ) :
		funcs(), priorityAugs(), factorWithRep(factorWithRep) { }

	~FactorWithAugNode();

	FsmAp *walk( ParseData *pd );

	Vector<ParserFunc> funcs;
	Vector<PriorityAug> priorityAugs;

	FactorWithRepNode *factorWithRep;
	FactorWithAugNode *factorWithAug;
};

/*
 * FactorWithRepNode
 */
struct FactorWithRepNode
{
	enum FactorWithRepType
		{ Star, Optional, Plus, Negate, Factor };

	FactorWithRepNode( const InputLoc &loc, bool leavingFsm, 
			FactorWithRepNode *factorWithRep, FactorWithRepType type ) :
		loc(loc), leavingFsm(leavingFsm), factorWithRep(factorWithRep), 
		factor(0), type(type) { }

	FactorWithRepNode( const InputLoc &loc, FactorNode *factor ) :
		loc(loc), leavingFsm(true), factorWithRep(0), 
		factor(factor), type(Factor) { }

	~FactorWithRepNode();

	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	bool leavingFsm;
	FactorWithRepNode *factorWithRep;
	FactorNode *factor;
	FactorWithRepType type;
};

/*
 * FactorNode
 */
struct FactorNode 
{
	/* Language elements a factor node can be. */
	enum FactorType {
		LiteralFsm, 
		RangeFsm, 
		RegularExpression, 
		Explicit,
		Expression,
		LookupExpression
	}; 

	/* Construct with a literal fsm. */
	FactorNode( Literal *literal ) :
		literal(literal), type(LiteralFsm) { }

	/* Construct with a range. */
	FactorNode( Range *range ) : 
		range(range), type(RangeFsm) { }
	
	/* Construct with a regular expression. */
	FactorNode( RegExp *regExp ) :
		regExp(regExp), type(RegularExpression) { }

	/* Construct with an explicit machine. */
	FactorNode( ExplicitMachine *explicitMach ) :
		explicitMach(explicitMach), type(Explicit) { }

	/* Construct with an expression. */
	FactorNode( ExpressionNode *expression, FactorType type ) :
		expression(expression), type(type) {}

	/* Cleanup. */
	~FactorNode();

	/* Evaluation. */
	FsmAp *walk( ParseData *pd );

	Literal *literal;
	Range *range;
	RegExp *regExp;
	ExplicitMachine *explicitMach;
	ExpressionNode *expression;
	int lower, upper;
	FactorType type;
};

/* A range machine. Only ever composed of two literals. */
struct Range
{
	Range( Literal *lowerLit, Literal *upperLit ) 
		: lowerLit(lowerLit), upperLit(upperLit) { }

	~Range();
	FsmAp *walk( ParseData *pd );

	Literal *lowerLit;
	Literal *upperLit;
};

/* Some literal machine. Can be a number or literal string. */
struct Literal
{
	enum LiteralType { Number, LitString, OrLitString };

	Literal( const InputLoc &loc, String str, LiteralType type )
		: loc(loc), str(str), type(type) { }

	long makeRangeEndPoint( ParseData *pd );
	FsmAp *walk( ParseData *pd );
	
	InputLoc loc;
	String str;
	LiteralType type;
};

/* Regular expression. */
struct RegExp
{
	enum RegExpType { RecurseItem, Empty };

	/* Constructors. */
	RegExp() 
		: type(Empty) { }
	RegExp(RegExp *regExp, ReItem *item) 
		: regExp(regExp), item(item), type(RecurseItem) { }

	~RegExp();
	FsmAp *walk( ParseData *pd );

	RegExp *regExp;
	ReItem *item;
	RegExpType type;
};

/* An item in a regular expression. */
struct ReItem
{
	enum ReItemType { Data, Dot, OrBlock, NegOrBlock };
	
	ReItem( const InputLoc &loc, char c ) 
		: loc(loc), str(&c, 1), star(false), type(Data) { }
	ReItem( const InputLoc &loc, ReItemType type )
		: loc(loc), star(false), type(type) { }
	ReItem( const InputLoc &loc, ReOrBlock *orBlock, ReItemType type )
		: loc(loc), orBlock(orBlock), star(false), type(type) { }

	~ReItem();
	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	String str;
	ReOrBlock *orBlock;
	bool star;
	ReItemType type;
};

/* An or block item. */
struct ReOrBlock
{
	enum ReOrBlockType { RecurseItem, Empty };

	/* Constructors. */
	ReOrBlock()
		: type(Empty) { }
	ReOrBlock(ReOrBlock *orBlock, ReOrItem *item)
		: orBlock(orBlock), item(item), type(RecurseItem) { }

	~ReOrBlock();
	FsmAp *walk( ParseData *pd );
	
	ReOrBlock *orBlock;
	ReOrItem *item;
	ReOrBlockType type;
};

/* An item in an or block. */
struct ReOrItem
{
	enum ReOrItemType { Data, Range };

	ReOrItem( char c ) 
		: str(&c, 1), type(Data) { }
	ReOrItem( char lower, char upper )
		: lower(lower), upper(upper), type(Range) { }

	FsmAp *walk( ParseData *pd );

	String str;
	char lower;
	char upper;
	ReOrItemType type;
};

/* An explicit machine. */
struct ExplicitMachine
{
	ExplicitMachine( const InputLoc &loc, const ExpStateList &stateList );

	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	ExpStateList stateList;
};


#endif /* _PARSETREE_H */

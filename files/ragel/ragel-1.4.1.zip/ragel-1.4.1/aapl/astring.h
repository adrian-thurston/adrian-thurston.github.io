/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_SHRSTR_H
#define _AAPL_SHRSTR_H

#include <new>
#include <stdlib.h>

#ifdef AAPL_NAMESPACE
namespace Aapl {
#endif

#ifdef AAPL_DOCUMENTATION

/**
 * \defgroup astring String
 * \brief Implicitly shared copy-on-write string.
 * 
 * @{
 */

/**
 * \class String
 * \brief Implicitly shared copy-on-write string.
 */

/*@}*/

class String
{
public:
	/**
	 * \brief Create a null string. Data points to NULL.
	 */
	String();

	/**
	 * \brief Construct a string from a c-style string.
	 *
	 * A new buffer is allocated for the c string. Initially, this string will
	 * be the only String class referencing the data.
	 */
	String( const char *s );

	/**
	 * \brief Construct a string from a single char.
	 *
	 * A new buffer is allocated for the c char. Initially, this string will
	 * be the only String class referencing the data.
	 */
	String( const char c );

	/**
	 * \brief Construct a string from another String.
	 *
	 * A refernce to the buffer allocated for s is taken. A new buffer is
	 * not allocated.
	 */
	String( const String &s );

	/**
	 * \brief Clean up the string.
	 *
	 * If the string is not null, the referenced data is detached. If no other
	 * string refernces the detached data, it is deleted.
	 */
	~String();

	/**
	 * \brief Set the string from a c-style string.
	 *
	 * If this string is not null, the current buffer is dereferenced and
	 * possibly deleted. A new buffer is allocated (or possibly the old buffer
	 * reused) for the string. Initially, this string will be the only String
	 * class referencing the data.
	 *
	 * If s is null, then this string becomes a null ptr.
	 *
	 * \returns A reference to this.
	 */
	String &operator=( const char *s );

	/**
	 * \brief Set the string from a single char.
	 *
	 * The current buffer is dereferenced and possibly deleted. A new buffer
	 * is allocated (or possibly the old buffer reused) for the string.
	 * Initially, this string will be the only String class referencing the
	 * data.
	 *
	 * If s is null, then this string becomes a null ptr.
	 *
	 * \returns A reference to this.
	 */
	String &operator=( const char c );


	/**
	 * \brief Set the string from another String.
	 *
	 * If this string is not null, the current buffer is dereferenced and
	 * possibly deleted. A reference to the buffer allocated for s is taken.
	 * A new buffer is not allocated.
	 *
	 * If s is null, then this string becomes a null ptr.
	 *
	 * \returns a reference to this.
	 */
	String &operator=( const String &s );

	/**
	 * \brief Append a c string to the end of this string.
	 *
	 * If this string shares its allocation with another, a copy is first
	 * taken. The buffer for this string is grown and s is appended to the
	 * end.
	 * 
	 * If s is null nothing happens.
	 *
	 * \returns a reference to this.
	 */
	String &operator+=( const char *s );

	/**
	 * \brief Append a single char to the end of this string.
	 *
	 * If this string shares its allocation with another, a copy is first
	 * taken. The buffer for this string is grown and s is appended to the
	 * end.
	 * 
	 * \returns a reference to this.
	 */
	String &operator+=( const char c );

	/**
	 * \brief Append a String to the end of this string.
	 *
	 * If this string shares its allocation with another, a copy is first
	 * taken. The buffer for this string is grown and the data of s is
	 * appeneded to the end.
	 *
	 * If s is null nothing happens.
	 *
	 * returns a reference to this.
	 */
	String &operator+=( const String &s );

	/**
	 * \brief Cast to a char star.
	 *
	 * \returns the string data. A null string returns 0.
	 */
	operator char*() const;

	/**
	 * \brief Get the length of the string
	 *
	 * If the string is null, then undefined behaviour results.
	 *
	 * \returns the length of the string.
	 */
	int getLen() const;

	/**
	 * \brief Pointer to the data.
	 *
	 * Publically accessible pointer to the data. Immediately in front of the
	 * string data block is the string header which stores the refcount and
	 * length. Consequently, care should be taken if modifying this pointer.
	 */
	char *data;
};

/**
 * \relates String
 * \brief Concatenate a c-style string and a String.
 *
 * \returns The concatenation of the two strings in a String.
 */
String operator+( const String &s1, const char *s2 );

/**
 * \relates String
 * \brief Concatenate a String and a c-style string.
 *
 * \returns The concatenation of the two strings in a String.
 */
String operator+( const char *s1, const String &s2 );

/**
 * \relates String
 * \brief Concatenate two String classes.
 *
 * \returns The concatenation of the two strings in a String.
 */
String operator+( const String &s1, const String &s2 );

#endif 

/* Header located just before string data. Keeps the length and a refcount on
 * the data. */
struct StringHead
{
	int refCount;
	int length;
};

template<class T> class StringTmpl
{
public:
	/**
	 * \brief Create a null string.
	 */
	StringTmpl() : str(0) { }

	/* Clean up the string. */
	~StringTmpl();

	/* Construct a string from a c-style string. */
	StringTmpl( const char *s );

	/* Construct a string from a single char. */
	StringTmpl( const char c );

	/* Construct a string from another StringTmpl.  */
	StringTmpl( const StringTmpl &s );

	/* Set the string from a c-style string. */
	StringTmpl &operator=( const char *s );

	/* Set the string from a single char. */
	StringTmpl &operator=( const char c );

	/* Set the string from another StringTmpl. */
	StringTmpl &operator=( const StringTmpl &s );

	/* Append a c string to the end of this string. */
	StringTmpl &operator+=( const char *s );

	/* Append a single char to the end of this string. */
	StringTmpl &operator+=( const char c );

	/* Append an StringTmpl to the end of this string. */
	StringTmpl &operator+=( const StringTmpl &s );

	/**
	 * \brief Cast to a char star.
	 *
	 * \returns the string data.
	 */
	operator char*() const { return str; }

	/* Return the length of the string. Must check for null str pointer. */
	int getLen() const { return str ? (((StringHead*)str)-1)->length : 0; }

	/**
	 * \brief Pointer to the data.
	 */
	char *str;

protected:
	/* Append a string of length len (not counting null) to this string. */
	void append( const char *s, int len );

 	template<class FT> friend StringTmpl<FT> operator+( 
			const StringTmpl<FT> &s1, const char *s2 );
	template<class FT> friend StringTmpl<FT> operator+( 
			const char *s1, const StringTmpl<FT> &s2 );
	template<class FT> friend StringTmpl<FT> operator+( 
			const StringTmpl<FT> &s1, const StringTmpl<FT> &s2 );

private:
	/* A dummy struct solely to make a constructor that will never be
	 * ambiguous with the public constructors. */
	struct DisAmbig { int dummy; };
	StringTmpl( char *str, const DisAmbig & ) : str(str) { }
};

/* Free all mem used by the string. */
template<class T> StringTmpl<T>::~StringTmpl()
{
	if ( str != 0 ) {
		/* If we are the only ones referencing the string, then delete it. */
		StringHead *head = ((StringHead*) str) - 1;
		head->refCount -= 1;
		if ( head->refCount == 0 )
			free( head );
	}
}

/* Create from a c-style string. */
template<class T> StringTmpl<T>::StringTmpl( const char *s )
{
	if ( s == 0 )
		str = 0;
	else {
		/* Find the length and allocate the space for the shared string. */
		int length = strlen( s );
		StringHead *head = (StringHead*) malloc( 
				sizeof(StringHead) + length+1 );
		if ( head == 0 )
			throw std::bad_alloc();

		/* Init the header. */
		head->refCount = 1;
		head->length = length;

		/* Copy in the data and save the pointer to it. */
		str = (char*) (head+1);
		memcpy( str, s, length+1 );
	}
}

/* Create from a single character. */
template<class T> StringTmpl<T>::StringTmpl( const char c )
{
	/* Find the length and allocate the space for the shared string. */
	StringHead *head = (StringHead*) malloc( sizeof(StringHead) + 2 );
	if ( head == 0 )
		throw std::bad_alloc();

	/* Init the header. */
	head->refCount = 1;
	head->length = 1;

	/* Copy in the data and save the pointer to it. */
	str = (char*) (head+1);
	str[0] = c;
	str[1] = 0;
}


/* Create from another string class. */
template<class T> StringTmpl<T>::StringTmpl( const StringTmpl &s )
{
	if ( s.str == 0 )
		str = 0;
	else {
		/* Take a reference to the string. */
		StringHead *strHead = ((StringHead*)s.str) - 1;
		strHead->refCount += 1;
		str = (char*) (strHead+1);
	}
}

/* Set this string to be the c string exactly. The old string is discarded.
 * Returns a reference to this. */
template<class T> StringTmpl<T> &StringTmpl<T>::operator=( const char *s )
{
	if ( s == 0 ) {
		/* Just free the data, we are being set to null. */
		if ( str != 0 ) {
			StringHead *head = ((StringHead*)str) - 1;
			head->refCount -= 1;
			if ( head->refCount == 0 )
				free(head);
			str = 0;
		}
	}
	else {
		/* Find the length of the string we are setting. */
		int length = strlen( s );

		/* Detach from the existing string. */
		StringHead *head = ((StringHead*)str) - 1;
		if ( str != 0 && --head->refCount == 0 ) {
			/* Resuse the space. */
			head = (StringHead*) realloc( head, sizeof(StringHead) + length+1 );
		}
		else {
			/* Need to make new space, there is no usable old space. */
			head = (StringHead*) malloc( sizeof(StringHead) + length+1 );
		}
		if ( head == 0 )
			throw std::bad_alloc();

		/* Init the header. */
		head->refCount = 1;
		head->length = length;

		/* Copy in the data and save the pointer to it. */
		str = (char*) (head+1);
		memcpy( str, s, length+1 );
	}
	return *this;
}

/* Set this string to be the single char exactly. The old string is discarded.
 * Returns a reference to this. */
template<class T> StringTmpl<T> &StringTmpl<T>::operator=( const char c )
{
	/* Detach from the existing string. */
	StringHead *head = ((StringHead*)str) - 1;
	if ( str != 0 && --head->refCount == 0 ) {
		/* Resuse the space. */
		head = (StringHead*) realloc( head, sizeof(StringHead) + 2 );
	}
	else {
		/* Need to make new space, there is no usable old space. */
		head = (StringHead*) malloc( sizeof(StringHead) + 2 );
	}
	if ( head == 0 )
		throw std::bad_alloc();

	/* Init the header. */
	head->refCount = 1;
	head->length = 1;

	/* Copy in the data and save the pointer to it. */
	str = (char*) (head+1);
	str[0] = c;
	str[1] = 0;

	return *this;
}

/* Set this string to be the StringTmpl s exactly. The old string is
 * discarded. */
template<class T> StringTmpl<T> &StringTmpl<T>::operator=( const StringTmpl &s )
{
	/* Detach from the existing string. */
	if ( str != 0 ) {
		StringHead *head = ((StringHead*)str) - 1;
		head->refCount -= 1;
		if ( head->refCount == 0 )
			free( head );
	}

	if ( s.str != 0 ) {
		/* Take a reference to the string. */
		StringHead *strHead = ((StringHead*)s.str) - 1;
		strHead->refCount += 1;
		str = (char*)(strHead+1);
	}
	else {
		/* Setting from a null string, just null our pointer. */
		str = 0;
	}
	return *this;
}

/* Append a c-style string to the end of this string. Returns a reference to
 * this */
template<class T> StringTmpl<T> &StringTmpl<T>::operator+=( const char *s )
{
	/* Find the length of the string appended. */
	if ( s != 0 ) {
		int addedLen = strlen( s );
		append( s, addedLen );
	}
	return *this;
}

/* Append a single char to the end of this string. Returns a reference to
 * this */
template<class T> StringTmpl<T> &StringTmpl<T>::operator+=( const char c )
{
	/* Make a temporary buffer to append with. */
	char buf[2] = { c, 0 };
	append( buf, 2 );
	return *this;
}


/* Append an StringTmpl string to the end of this string. Returns a reference
 * to this */
template<class T> StringTmpl<T> &StringTmpl<T>::operator+=( const StringTmpl &s )
{
	/* Find the length of the string appended. */
	if ( s.str != 0 ) {
		int addedLen = (((StringHead*)s.str) - 1)->length;
		append( s, addedLen );
	}
	return *this;
}


/* Append a string of length len (not counting null) to this string. */
template<class T> void StringTmpl<T>::append( const char *s, int len )
{
	/* Find the length of this and the string appended. */
	StringHead *head = (((StringHead*)str) - 1);
	int thisLen = head->length;

	if ( head->refCount == 1 ) {
		/* No other string is using the space, grow this space. */
		head = (StringHead*) realloc( head, 
				sizeof(StringHead) + thisLen + len + 1 );
		if ( head == 0 )
			throw std::bad_alloc();
		str = (char*) (head+1);

		/* Adjust the length. */
		head->length += len;
	}
	else {
		/* Another string is using this space, make new space. */
		head->refCount -= 1;
		StringHead *newHead = (StringHead*) malloc(
				sizeof(StringHead) + thisLen + len + 1 );
		if ( newHead == 0 )
			throw std::bad_alloc();
		str = (char*) (newHead+1);

		/* Set the new header and data from this. */
		newHead->refCount = 1;
		newHead->length = thisLen + len;
		memcpy( str, head+1, thisLen );
	}

	/* Copy in the data from s. */
	memcpy( str + thisLen, s, len+1 );
}

/*  Concatenate a String and a c-style string. */
template<class T> StringTmpl<T> operator+( const StringTmpl<T> &s1, const char *s2 )
{
	/* Find s2 length and alloc the space for the result. */
	int str1Len = (((StringHead*)(s1.str)) - 1)->length;
	int str2Len = strlen( s2 );

	StringHead *head = (StringHead*) malloc( sizeof(StringHead) + 
			str1Len + str2Len + 1 );
	if ( head == 0 )
		throw std::bad_alloc();

	/* Set up the header. */
	head->refCount = 1;
	head->length = str1Len + str2Len;

	/* Save the pointer to data and copy the data in. */
	char *str = (char*) (head+1);
	memcpy( str, s1.str, str1Len );
	memcpy( str + str1Len, s2, str2Len + 1 );
	return StringTmpl<T>( str, StringTmpl<T>::DisAmbig() );
}

/* Concatenate a c-style string and a String. */
template<class T> StringTmpl<T> operator+( const char *s1, const StringTmpl<T> &s2 )
{
	/* Find s2 length and alloc the space for the result. */
	int str1Len = strlen( s1 );
	int str2Len = (((StringHead*)(s2.str)) - 1)->length;

	StringHead *head = (StringHead*) malloc( sizeof(StringHead) + 
			str1Len + str2Len + 1 );
	if ( head == 0 )
		throw std::bad_alloc();

	/* Set up the header. */
	head->refCount = 1;
	head->length = str1Len + str2Len;

	/* Save the pointer to data and copy the data in. */
	char *str = (char*) (head+1);
	memcpy( str, s1, str1Len );
	memcpy( str + str1Len, s2.str, str2Len + 1 );
	return StringTmpl<T>( str, StringTmpl<T>::DisAmbig() );
}

/* Add two StringTmpl strings. */
template<class T> StringTmpl<T> operator+( const StringTmpl<T> &s1, const StringTmpl<T> &s2 )
{
	/* Find s2 length and alloc the space for the result. */
	int str1Len = (((StringHead*)(s1.str)) - 1)->length;
	int str2Len = (((StringHead*)(s2.str)) - 1)->length;
	StringHead *head = (StringHead*) malloc( sizeof(StringHead) + 
			str1Len + str2Len + 1 );
	if ( head == 0 )
		throw std::bad_alloc();

	/* Set up the header. */
	head->refCount = 1;
	head->length = str1Len + str2Len;

	/* Save the pointer to data and copy the data in. */
	char *str = (char*) (head+1);
	memcpy( str, s1.str, str1Len );
	memcpy( str + str1Len, s2.str, str2Len + 1 );
	return StringTmpl<T>( str, StringTmpl<T>::DisAmbig() );
}

typedef StringTmpl<char> String;

#ifdef AAPL_NAMESPACE
}
#endif

#endif /* _AAPL_SHRSTR_H */

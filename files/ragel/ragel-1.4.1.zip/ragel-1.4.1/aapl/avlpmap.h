/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_AVLPMAP_H
#define _AAPL_AVLPMAP_H

/**
 * \addtogroup avltree 
 * @{
 */

/**
 * \class AvlPmap
 * \brief Key and value oriented AVL tree for void* size key and value.
 *
 * AvlPmap is an instantiation of AvlMap with void* types. It has a small
 * inline interface on top of AvlMap that performs casting of types.
 * AvlPmap is useful when a large number of maps are needed but code bloat
 * caused by multiple instantiations of templates in not acceptable.
 *
 * AvlPmap stores key and value pairs in nodes managed by the tree.  It is
 * intendend to be similar to standard map templates.  AvlPmap requires that a
 * Key type and a Value type be given. A compare class need not be specified.
 * The key and value must be castable to a void* type.  Items can be inserted
 * with just a key or with a key and value pair.
 *
 * AvlPmap assumes all elements in the tree are allocated on the heap and
 * are to be managed by the tree. This means that the class destructor will
 * delete the contents of the tree. A deep copy will cause existing elements
 * to be deleted first.
 *
 * \include ex_avlpmap.cpp
 */

/*@}*/

#include "compare.h"
#include "avlmap.h"

typedef AvlMapNode< void*, void* > AvlPmapNode;

/* Common AvlTree Class */
template < class Key, class Value > class AvlPmap
		: public AvlMap< void*, void*, CmpOrd<void*> >
{
public:
	typedef AvlMap< void*, void*, CmpOrd<void*> > BaseTree;

	/* Insert a node into the tree. */
	AvlPmapNode *insert(const Key &key, AvlPmapNode **lastFound = 0 )
		{ return BaseTree::insert( (void*const)key, lastFound ); }
	AvlPmapNode *insert(const Key &key, const Value &val, AvlPmapNode **lastFound = 0 )
		{ return BaseTree::insert( (void *const)key, (void *const)val, lastFound ); }

	/* Find a node in the tree. Returns the node if 
	 * key exists, false otherwise. */
	AvlPmapNode *find(const Key &key) const
		{ return BaseTree::find( (void*const)key ); }

	/* Remove a node in the tree. */
	AvlPmapNode *detach(const Key &key)
		{ return BaseTree::detach( (void*const)key ); }

	static Key key( AvlPmapNode *node )
		{ return (Key) node->key; }
	static Value value( AvlPmapNode *node )
		{ return (Value) node->value; }
};


#endif /* _AAPL_AVLPMAP_H */

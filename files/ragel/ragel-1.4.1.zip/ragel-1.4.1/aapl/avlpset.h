/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_AVLPSET_H
#define _AAPL_AVLPSET_H

/**
 * \addtogroup avltree 
 * @{
 */

/**
 * \class AvlPset
 * \brief Key-only oriented tree for a void* size key.
 *
 * AvlPset is an instantiation of AvlSet with a void* type. It has a small
 * inline interface on top of AvlSet that performs casting of types. AvlPset
 * is useful when a large number of sets are needed but code bloat caused by
 * multiple instantiations of templates in not acceptable.
 *
 * AvlPset stores only keys in nodes managed by the tree. AvlPset requires
 * that a Key type be given. A compare class is not needed. The key type must
 * be castable to a void*. Items are inserted with just a key value.
 *
 * AvlPset assumes all elements in the tree are allocated on the heap and are
 * to be managed by the tree. This means that the class destructor will
 * delete the contents of the tree. A deep copy will cause existing elements
 * to be deleted first.
 *
 * \include ex_avlpset.cpp
 */

/*@}*/

#include "compare.h"
#include "avlset.h"

typedef AvlSetNode< void* > AvlPsetNode;

/* Common AvlTree Class */
template < class Key > class AvlPset
		: public AvlSet< void*, CmpOrd<void*> >
{
public:
	typedef AvlSet< void*, CmpOrd<void*> > BaseTree;

	/* Insert a node into the tree. */
	AvlPsetNode *insert(const Key &key, AvlPsetNode **lastFound = 0 )
		{ return BaseTree::insert( (void*)key, lastFound ); }

	/* Find a node in the tree. Returns the node if 
	 * key exists, false otherwise. */
	AvlPsetNode *find(const Key &key) const
		{ return BaseTree::find( (void*)key ); }

	/* Remove a node in the tree. */
	AvlPsetNode *detach(const Key &key)
		{ return BaseTree::detach( (void*)key ); }

	static Key key( AvlPsetNode *node )
		{ return (Key) node->key; }
};


#endif /* _AAPL_AVLPSET_H */

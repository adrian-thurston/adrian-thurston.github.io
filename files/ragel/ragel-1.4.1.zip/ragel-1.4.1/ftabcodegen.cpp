/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "ftabcodegen.h"

/* Integer array line length. */
#define IALL 8

/* Transition array line length. */
#define TALL 4

/* Init base data. */
FTabCodeGen::FTabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	TabCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out-func for a state. */
std::ostream &FTabCodeGen::STATE_OUT_FUNC(FsmMachState *state)
{
	/* This function is only called if there are any out functions, so need
	 * not guard against there being none. */
	out << state->outFuncs+1;
	return out;
}

/* Write out the function for a transition. */
std::ostream &FTabCodeGen::TRANS_FUNC(FsmMachTrans *trans)
{
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else
		out << trans->funcs+1;
	return out;
}

/* Write out the function switch. This switch is keyed on the 
 * values of the func index. */
std::ostream &FTabCodeGen::FUNC_SWITCH()
{
	/* Loop over all func indicies. */
	int *allTransFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "\tcase " << i+1 << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = allTransFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			out << "\t{" << getCodeBuiltin( *funcs ) << "}\n";
			funcs += 1;
		}
		out << "\tbreak;\n";
	}
	return out;
}

std::ostream &FTabCodeGen::TRANSITIONS( int *statePos )
{
	/* Initial indentation. */
	out << '\t';
	FsmMachTrans *trans = machine->allTrans;
	for ( int i = 0; i < machine->numTrans; i++, trans++ ) {
		if ( trans->toState == STATE_ERR_STATE )
			out << "{0, ";
		else
			out << "{s+" << statePos[trans->toState] << ", ";

		/* Write the function for the state. Close transition. */
		if ( trans->funcs == FUNC_NO_FUNC )
			out << "0";
		else
			out << trans->funcs+1;
		out << "}";

		/* If not on the last transition, output a command 
		 * and possibly a line break. */
		if ( i < machine->numTrans-1 ) {
			out << ", ";

			/* Put in a break every 4, but only if not the last. */
			if ( i % TALL == TALL-1 )
				out << "\n\t";
		}
	}
	return out;
}

std::ostream &FTabCodeGen::LOCATE_TRANS()
{
	out <<
		"		/* Get required data. */\n"
		"		specs = *cs++;\n"
		"		keys = k + *cs++;\n"
		"		inds = i + *cs++;\n"
		"\n"
		"		/* Try flat index. */\n"
		"		if ( specs & SPEC_ANY_FLAT ) {\n"
		"			int indsLen = *cs++;\n"
		"			keys += 2;\n"
		"			inds += indsLen;\n"
		"		}\n"
		"\n"
		"		/* Try binary search single. */\n"
		"		if ( specs & SPEC_ANY_SINGLE ) {\n"
		"			/* Try to find the key. */\n"
		"			int indsLen = *cs++;\n"
		"			"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
						"BSearch( *p, keys, indsLen );\n"
		"\n"
		"			if ( match != 0 ) {\n"
		"				trans = t + inds[match - keys];\n"
		"				goto match;\n"
		"			}\n"
		"\n"
		"			/* Advance over the keys and indicies. */\n"
		"			keys += indsLen;\n"
		"			inds += indsLen;\n"
		"		}\n"
		"\n"
		"		/* Try binary search range. */\n"
		"		if ( specs & SPEC_ANY_RANGE ) {\n"
		"			/* Try to find the key. */\n"
		"			int indsLen = *cs++;\n"
		"			"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
						"RangeBSearch( *p, keys, (indsLen<<1) );\n"
		"\n"
		"			if ( match != 0 ) {\n"
		"				trans = t + inds[(match - keys)>>1];\n"
		"				goto match;\n"
		"			}\n"
		"\n"
		"			/* Advance over the keys and indicies. */\n"
		"			keys += (indsLen<<1);\n"
		"			inds += indsLen;\n"
		"		}\n"
		"\n"
		"		/* Try the default transition. */\n"
		"		if ( specs & SPEC_ANY_DEF ) {\n"
		"			trans = t + *inds;\n"
		"			goto match;\n"
		"		}\n";

	return out;
}



/* Init base class. */
CFTabCodeGen::CFTabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	FTabCodeGen(fsmName, machine, parseData, out)
{
}

void CFTabCodeGen::writeOutHeader()
{
	out <<
		"/* Forward dec state for the transition structure. */\n"
		"struct "; FSM_NAME() << "StateStruct;\n"
		"\n"
		"/* A single transition. */\n"
		"struct "; FSM_NAME() << "TransStruct\n"
		"{\n"
		"	int *toState;\n"
		"	int funcs;\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "TransStruct "; FSM_NAME() << "Trans;\n"
		"\n"
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int *curState;\n"
		"	int accept;\n"
		"\n";
		STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_start;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n";

	/* State machine function execution. */
	out <<
 		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"static void "; FSM_NAME() << "ExecFuncs( "; FSM_NAME() 
				<< " *fsm, int funcs, "; ALPH_TYPE() << " *p )\n"
		"{\n"
		"	switch ( funcs ) {\n";
		FUNC_SWITCH() << "\n"
		"	}\n"
		"}\n"
		"\n";

	/* Accept routine. */
	out <<
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	int *cs = fsm->curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int specs;\n"
		"		"; ALPH_TYPE() << " *keys;\n"
		"		"; INDEX_TYPE() << " *inds;\n"
		"		"; FSM_NAME() << "Trans *trans;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"		/* No match. */\n"
		"		cs = 0;\n"
		"		goto finished;\n"
		"\n"
		"match:\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( trans->funcs != 0 )\n"
		"			"; FSM_NAME() << "ExecFuncs( fsm, trans->funcs, p );\n"
		"\n"
		"		/* Move to the new state. */\n"
		"		cs = trans->toState;\n"
		"	}\n"
		"finished:\n"
		"	fsm->curState = cs;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int *cs = fsm->curState;\n"
		"	if ( cs != 0 && *cs & SPEC_IS_FINAL ) {\n";

	/* If there are any functions, then emit the finishing action execute. */
	if ( anyTransFuncs() ) {
		out <<
			"		/* If finishing in a final state then execute the\n"
			"		 * out functions for it. (if any). */\n"
			"		if ( *cs & SPEC_OUT_FUNC ) {\n"
			"			cs += (*cs>>8)-1;\n"
			"			"; FSM_NAME() << "ExecFuncs( fsm, *cs, 0 );\n"
			"		}\n"
			"\n";
	}

	out << 
		"		/* The machine accepts. */\n"
		"		fsm->accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		fsm->curState = 0;\n"
		"	}\n"
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}


/* Init base data. */
CCFTabCodeGen::CCFTabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	FTabCodeGen(fsmName, machine, parseData, out)
{
}

void CCFTabCodeGen::writeOutHeader()
{
	out <<
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* A single transition. */\n"
		"	struct Trans\n"
		"	{\n"
		"		int *toState;\n"
		"		int funcs;\n"
		"	};\n"
		"\n"
		"	/* Constructor. */\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int *curState;\n"
		"	int accept;\n"
		"\n";
		STRUCT_DATA() << "\n"
		"\n"
		"private:\n"
		"	void ExecFuncs( int funcs, "; ALPH_TYPE() << " *p );\n"
		"};\n"
		"\n";
}

void CCFTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "::Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Constructor. */
	out <<
		"/* Make sure the machine is initted. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "()\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = "; FSM_NAME() << "_start;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n";

	/* State machine function execution. */
	out <<
 		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"void "; FSM_NAME() << "::ExecFuncs( int funcs, "; ALPH_TYPE() << " *p )\n"
		"{\n"
		"	switch ( funcs ) {\n";
		FUNC_SWITCH() << "\n"
		"	}\n"
		"}\n"
		"\n";

	/* Accept routine. */
	out <<
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n";


	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	int *cs = curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int specs;\n"
		"		"; ALPH_TYPE() << " *keys;\n"
		"		"; INDEX_TYPE() << " *inds;\n"
		"		"; FSM_NAME() << "::Trans *trans;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"		/* No match. */\n"
		"		cs = 0;\n"
		"		goto finished;\n"
		"\n"
		"match:\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( trans->funcs != 0 )\n"
		"			ExecFuncs( trans->funcs, p );\n"
		"\n"
		"		/* Move to the new state. */\n"
		"		cs = trans->toState;\n"
		"	}\n"
		"finished:\n"
		"	curState = cs;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int *cs = curState;\n"
		"	if ( cs != 0 && *cs & SPEC_IS_FINAL ) {\n";

	/* If there are any functions, then emit the finishing action execute. */
	if ( anyTransFuncs() ) {
		out <<
			"		/* If finishing in a final state then execute the\n"
			"		 * out functions for it. (if any). */\n"
			"		if ( *cs & SPEC_OUT_FUNC ) {\n"
			"			cs += (*cs>>8)-1;\n"
			"			ExecFuncs( *cs, 0 );\n"
			"		}\n"
			"\n";
	}

	out << 
		"		/* The machine accepts. */\n"
		"		accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		curState = 0;\n"
		"	}\n"
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}

#define VERSION "6.8"
#define PUBDATE "Feb 2013"

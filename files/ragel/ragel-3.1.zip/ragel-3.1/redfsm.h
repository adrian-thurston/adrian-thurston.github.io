/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _REDFSM_H
#define _REDFSM_H

#include <assert.h>
#include "vector.h"
#include "compare.h"
#include "bstmap.h"
#include "bstset.h"
#include "avlmap.h"
#include "avltree.h"
#include "avlbasic.h"
#include "fsmgraph.h"

#define TRANS_ERR_TRANS   0
#define STATE_ERR_STATE   0
#define FUNC_NO_FUNC      0

/* Forwards. */
struct RedStateAp;
struct TransAp;
struct StateAp;
struct FsmAp;

/* Reduced action. */
struct RedAction
:
	public AvlTreeEl<RedAction>
{
	RedAction( const ActionTable &key )
		: key(key) { }
	
	const ActionTable &getKey() 
		{ return key; }

	ActionTable key;
	int id;
	int location;
};
typedef AvlTree<RedAction, ActionTable, CmpActionTable> ActionTableMap;

/* Reduced transition. */
struct RedTransAp
:
	public AvlTreeEl<RedTransAp>
{
	RedTransAp( RedStateAp *targ, RedAction *action, int id )
		: targ(targ), action(action), id(id) { }

	RedStateAp *targ;
	RedAction *action;
	int id;
};

/* Compare of transitions for the final reduction of transitions. Comparison
 * is on target and the pointer to the shared action table. It is assumed that
 * when this is used the action tables have been reduced. */
struct CmpRedTransAp
{
	static int compare( const RedTransAp &t1, const RedTransAp &t2 )
	{
		if ( t1.targ < t2.targ )
			return -1;
		else if ( t1.targ > t2.targ )
			return 1;
		else if ( t1.action < t2.action )
			return -1;
		else if ( t1.action > t2.action )
			return 1;
		else
			return 0;
	}
};

typedef AvlBasic<RedTransAp, CmpRedTransAp> TransApSet;

/* Element in out range. */
struct RedTransEl
{
	/* Constructors. */
	RedTransEl( long lowKey, long highKey, RedTransAp *value ) 
		: lowKey(lowKey), highKey(highKey), value(value) { }

	long lowKey, highKey;
	RedTransAp *value;
};

typedef Vector<RedTransEl> RedTransList;

/* Reduced state. */
struct RedStateAp
{
	RedStateAp( bool isFinal, RedAction *outAction, 
			RedAction *errAction, int id ) : 
		defTrans(0), isFinal(isFinal), labelNeeded(false),
		outAction(outAction), errAction(errAction), id(id) { }

	RedTransList outSingle;
	RedTransList outRange;
	RedTransAp *defTrans;

	bool isFinal;
	bool labelNeeded;
	RedAction *outAction;
	RedAction *errAction;
	int id;
	int position;

	/* Pointers for the list of states. */
	RedStateAp *prev, *next;
};

/* List of states. */
typedef DList<RedStateAp> RedStateList;

/* Entry points. */
struct RedEntryListEl
{
	RedEntryListEl( int key, RedStateAp *value )
		: key(key), value(value) { }

	int key;
	RedStateAp *value;
};
typedef Vector<RedEntryListEl> RedEntryList;
typedef BstMapEl<int, RedStateAp*> RedEntryMapEl;
typedef BstMap<int, RedStateAp*> RedEntryMap;

/* Set of reduced transitons. Comparison is by pointer. */
typedef BstSet< RedTransAp*, CmpOrd<RedTransAp*> > RedTransSet;

/* Next version of the fsm machine. */
struct RedFsmAp
{
	RedFsmAp( FsmAp *graph, bool complete );

	FsmAp *graph;
	KeyOps *keyOps;

	int nextActionId;
	int nextTransId;
	int nextStateId;

	TransApSet transSet;
	ActionTableMap actionMap;
	RedStateList stateList;
	RedEntryList entryList;
	RedEntryMap entryMap;
	RedStateAp *startState;
	RedStateAp *firstFinState;
	RedStateAp *errState;
	RedTransAp *errTrans;
	RedTransAp *errActionTrans;
	int numFinStates;

	/* Pick single transitions from the ranges. */
	void moveTransToSingle( RedStateAp *state );
	void chooseSingleTrans();

	/* Pick a default transition from the ranges. */
	void moveToDefault( RedTransAp *defTrans, RedStateAp *state );
	RedTransAp *chooseDefaultTrans( RedStateAp *state );
	void chooseDefaultTrans();

	/* Is is it possible to extend a range by bumping ranges that span only
	 * one character to the singles array. */
	bool canExtend( const RedTransList &list, int pos );

	/*
	 * Building the initial machine.
	 */
	
	void assignActionLocs();

	/* Move default transitions to ranges and remove transition elements with
	 * null targets. */
	bool doesExtend( RedTransList &destRange, const RedTransEl &redTel );

	RedTransAp *getErrorTrans( StateAp *state );
	void appendToRange( RedTransList &destRange, const RedTransEl &redTel, 
			StateAp *state, bool complete );
	void finishRange( RedTransList &destRange, StateAp *state, bool complete );
	void defaultToRange( RedTransList &destRange, StateAp *state, bool complete );

	/* Is every char in the alphabet covered? */
	bool alphabetCovered( RedTransList &outRange );

	/* Reduce transitions. Collects them all in. */
	RedTransAp *reduceTrans( TransAp *trans );
	void reduceMachine( bool complete );
};


#endif /* _REDFSM_H */

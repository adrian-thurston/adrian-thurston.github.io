/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "ftabcodegen.h"

/* Registers all the section names and inits the code and data pointers. */
FTabCodeGen::FTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		TabCodeGen(fsmName, machine, parseData, out)
{
	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Write out the out-func for a state. */
void FTabCodeGen::stateOutFunc(FsmMachState *state)
{
	if ( state->outFuncs == FUNC_NO_FUNC )
		out << "0";
	else {
		/* There are out funcs. Write out the pointer into the array
		 * of funcs and the number of funcs. */
		out << state->outFuncs+1;
	}
}

/* Write out the function for a transition. */
void FTabCodeGen::transFunc(FsmMachTrans *trans)
{
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else {
		out << trans->funcs+1;
	}
}

/* Write out the function switch. This switch is keyed on the 
 * values of the func index. */
void FTabCodeGen::FUNC_SWITCH()
{
	/* Loop over all func indicies. */
	int *allTransFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "\tcase " << i+1 << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = allTransFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			out << "\t{" << getCodeBuiltin( *funcs ) << "}\n";
			funcs += 1;
		}
		out << "\tbreak;\n";
	}
}

/* Registers all the section names and inits the code and data pointers. */
CFTabCodeGen::CFTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		FTabCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}


char CFTabCodeGen::header[] = 
"
/* Forward dec state for the transition structure. */
struct @FSMNAME@StateStruct;

/* A single transition. */
struct @FSMNAME@TransStruct
{
	struct @FSMNAME@StateStruct *toState;
	int funcs;
};
typedef struct @FSMNAME@TransStruct @FSMNAME@Trans;

/* A single state. */
struct @FSMNAME@StateStruct
{
	int lowIndex;
	int highIndex;
	void *transIndex;
	int dflIndex;
	int outFuncs;
	int isFinState;
};
typedef struct @FSMNAME@StateStruct @FSMNAME@State;

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	@FSMNAME@State *curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CFTabCodeGen::code[] = "

#define s @FSMNAME@_s
#define i @FSMNAME@_i
#define t @FSMNAME@_t

/* The array of indicies into the transition array. */
#if @ANY_INDICIES@
static @INDEX_TYPE@ @FSMNAME@_i[] = {
@INDICIES@
};
#endif

/* The aray of states. */
static @FSMNAME@State @FSMNAME@_s[] = {
@STATES@
};

/* The array of trainsitions. */
static @FSMNAME@Trans @FSMNAME@_t[] = {
@TRANSITIONS@
};

/* The start state. */
static @FSMNAME@State *@FSMNAME@_startState = s+@START_STATE_OFFSET@;

#undef f
#undef s
#undef i
#undef t


/***************************************************************************
 * Execute functions pointed to by funcs until the null function is found. 
 */
inline static void @FSMNAME@ExecFuncs( @FSMNAME@ *fsm, int funcs, char *p )
{
	switch ( funcs ) {
@FUNC_SWITCH@
	}
}

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}

/****************************************
 * @FSMNAME@Accept
 *
 * Did the fsm accept? 
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}


/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen )
{
	char *p = data;
	int len = dlen;

	@FSMNAME@State *cs = fsm->curState;
	for ( ; len > 0; p++, len-- ) {
		int c = (unsigned char)*p;
		@FSMNAME@Trans *trans;

		if ( cs == 0 )
			goto finished;

		/* If the character is within the index bounds then get the
		 * transition for it. If it is out of the transition bounds
		 * we will use the default transition. */
		if ( cs->lowIndex <= c && c < cs->highIndex ) {
			/* Use the index to look into the transition array. */
			trans = @FSMNAME@_t + 
				((@INDEX_TYPE@*)cs->transIndex)[c - cs->lowIndex];
		}
		else {
			/* Use the default index as the char is out of range. */
			trans = @FSMNAME@_t + cs->dflIndex;
		}

		/* If there are functions for this transition then execute them. */
		if ( trans->funcs >= 0 )
			@FSMNAME@ExecFuncs( fsm, trans->funcs, p );

		/* Move to the new state. */
		cs = trans->toState;
	}
finished:
	fsm->curState = cs;
}

/**********************************************************************
 * @FSMNAME@Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	@FSMNAME@State *cs = fsm->curState;
	if ( cs != 0 && cs->isFinState ) {
		/* If finishing in a final state then execute the
		 * out functions for it. (if any). */
		if ( cs->outFuncs != 0 )
			@FSMNAME@ExecFuncs( fsm, cs->outFuncs, NULL );
		fsm->accept = 1;
	}
	else {
		/* If we are not in a final state then this
		 * is an error. Move to the error state. */
		fsm->curState = 0;
	}
}
";


/* Registers all the section names and inits the code and data pointers. */
CCFTabCodeGen::CCFTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		FTabCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CCFTabCodeGen::header[] = 
"

class @FSMNAME@
{
public:
	/* Function and index type. */
	typedef int Func;

	/* Forward dec state for the transition structure. */
	struct State;

	/* A single transition. */
	struct Trans
	{
		State *toState;
		int funcs;
	};

	/* A single state. */
	struct State
	{
		int lowIndex;
		int highIndex;
		void *transIndex;
		int dflIndex;
		int outFuncs;
		int isFinState;
	};

	/* Constructor. */
	@FSMNAME@();

	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int dlen );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	State *curState;
	int accept;

	inline void ExecFuncs( int funcs, char *p );

	@STRUCT_DATA@
};


";

char CCFTabCodeGen::code[] = "

#define s @FSMNAME@_s
#define i @FSMNAME@_i
#define t @FSMNAME@_t

/* The array of indicies into the transition array. */
#if @ANY_INDICIES@
static @INDEX_TYPE@ @FSMNAME@_i[] = {
@INDICIES@
};
#endif

/* The aray of states. */
static @FSMNAME@::State @FSMNAME@_s[] = {
@STATES@
};

/* The array of trainsitions. */
static @FSMNAME@::Trans @FSMNAME@_t[] = {
@TRANSITIONS@
};

/* The start state. */
static @FSMNAME@::State *@FSMNAME@_startState = s+@START_STATE_OFFSET@;


/***************************************************************************
 * Execute functions pointed to by funcs until the null function is found. 
 */
inline void @FSMNAME@::ExecFuncs( int funcs, char *p )
{
	switch ( funcs ) {
@FUNC_SWITCH@
	}
}


/****************************************
 * Constructor
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@::Init( )
{
	curState = @FSMNAME@_startState;
	accept = 0;
	@INIT_CODE@
}

/****************************************
 * Did the fsm accept? 
 */
int @FSMNAME@::Accept( )
{
	return accept;
}



/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int dlen )
{
	char *p = data;
	int len = dlen;

	State *cs = curState;
	for ( ; len > 0; p++, len-- ) {
		int c = (unsigned char)*p;
		Trans *trans;

		if ( cs == 0 )
			goto finished;

		/* If the character is within the index bounds then get the
		 * transition for it. If it is out of the transition bounds
		 * we will use the default transition. */
		if ( cs->lowIndex <= c && c < cs->highIndex ) {
			/* Use the index to look into the transition array. */
			trans = @FSMNAME@_t + 
				((@INDEX_TYPE@*)cs->transIndex)[c - cs->lowIndex];
		}
		else {
			/* Use the default index as the char is out of range. */
			trans = @FSMNAME@_t + cs->dflIndex;
		}

		/* If there are functions for this transition then execute them. */
		if ( trans->funcs != 0 )
			ExecFuncs( trans->funcs, p );

		/* Move to the new state. */
		cs = trans->toState;
	}
finished:
	curState = cs;
}


/**********************************************************************
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	State *cs = curState;
	if ( cs != 0 && cs->isFinState ) {
		/* If finishing in a final state then execute the
		 * out functions for it. (if any). */
		if ( cs->outFuncs != 0 )
			ExecFuncs( cs->outFuncs, NULL );
		accept = 1;
	}
	else {
		/* If we are not in a final state then this
		 * is an error. Move to the error state. */
		curState = 0;
	}
}

";


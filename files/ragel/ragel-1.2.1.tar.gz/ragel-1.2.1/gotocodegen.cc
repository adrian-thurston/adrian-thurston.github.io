/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "gotocodegen.h"
#include "bstmap.h"

using std::endl;

/* Registers all the section names and inits the code and data pointers. */
GotoCodeGen::GotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		FsmCodeGen(fsmName, machine, parseData, out)
{
	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Emit the goto to take for a given transition. */
void GotoCodeGen::emitTransGoto( int curState, FsmMachTrans *trans )
{
	if ( trans->funcs != FUNC_NO_FUNC )
		out << "goto tr" << trans - machine->allTrans << ";\n";
	else {
		/* Get the index of the state we go to. */
		if ( trans->toState != STATE_NO_STATE )
			out << "goto st" << trans->toState << ";\n";
		else {
			out << "goto err;\n";
			needErrorLabel = true;
		}
	}
}


/* Write the switch of functions a la tabcodegen. */
void GotoCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	StringListEl *flel = parseData->funcList.head;
	int fnum = 0;
	while ( flel != NULL ) {
		out << "\tcase " << fnum << ": {\n";
		out << flel->data;
		out << "break;}" << endl;
		fnum += 1;
		flel = flel->next;
	}
}


/* Emit the switch statement for jumping into the machine. Our current state
 * is represented by an integer and we need to use it to get into the correct
 * place in the machine. */
void GotoCodeGen::JUMP_IN_SWITCH()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "\t\tcase " << st << ": goto st" << st << ";\n";
	}
};

void GotoCodeGen::STATE_GOTOS()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Emit any transitions that have functions and that go to 
		 * this state. */
		FsmMachTrans *trans = machine->allTrans;
		for ( int j = 0; j < machine->numTrans; j++, trans++ ) {
			if ( trans->toState == st && trans->funcs != FUNC_NO_FUNC ) {
				/* Write the label for the transition so it can be jumped to. */
				out << "tr" << j << ":\n";

				/* Write out the specific machine's representation of 
				 * executing the funcs. */
				transFunc( trans );

				out << "\tgoto st" << st << ";\n";
			}
		}

		out << "st" << st << ":\n";
		out << "\tif ( --len == 0 )\n";
		out << "\t\tgoto out" << st << ";\n";
		out << "\tswitch( (alph) *++p ) {\n";

		/* Get the fsm machine state. */
		FsmMachState *state = machine->allStates+st;

		/* Make the switch oriented state. */
		FsmMachSwitchState swState;
		machine->makeSwitchState( swState, *state );

		/* Write out the switch cases. */
		for ( int j = 0; j < swState.funcMap.size(); j++ ) {
			out << "\t\t";
			/* Write out all the characters that follow this transition. */
			Vector<int> &charVec = swState.funcMap[j].value;
			for ( int k = 0; k < charVec.size(); k++ ) {
				out << "case " << charVec[k] << ": ";
				if ( k % 4 == 3 )
					out << "\n\t\t";
			}
			/* Emit the transition. */
			FsmMachTrans *trans = machine->allTrans + 
					swState.funcMap.table[j].key;
			emitTransGoto( st, trans );
		}

		/* Get the default index and write it. Default will always be used. */
		trans = machine->allTrans + swState.dflIndex;
		out << "\t\tdefault: ";
		emitTransGoto( st, trans );

		/* Close off the transition switch. */
		out << "\t}\n";
	}

	/* Write any transitions that have functions and that go to
 	 * the error state. */
}

void GotoCodeGen::EXIT_STATES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "out" << st << ":\n\t";
		selectSection("FSM_PREFIX");
		out << "curState = " << st << ";\n";
		out << "\treturn;\n";
	}
}

void GotoCodeGen::FINISH_SWITCH()
{
	out << "\tswitch( cs ) {" << endl;
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		out << "\t\tcase " << st << ": ";
		if ( state->isFinState )
			out << "accept = 1; ";

		/* If there are out functions, write them. */
		if ( state->outFuncs != FUNC_NO_FUNC ) {
			int *funcs = machine->allTransFuncs + 
					machine->transFuncIndex[state->outFuncs];

			/* The first number is the length. */
			int flen = *funcs++;
			while ( flen-- > 0 ) {
				out << "{" << getCodeBuiltin(*funcs) << "}";
				funcs += 1;
			}
		}
		out << "break;" << endl;
	}
	out << "}" << endl;
}

void GotoCodeGen::ERROR_LABEL()
{
	if ( needErrorLabel ) {
		out << "err:\n";
		selectSection("FSM_PREFIX");
		out << "curState = 0;\n";
	}
}

/* Registers all the section names and inits the code and data pointers. */
CGotoCodeGen::CGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		GotoCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;

	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\t";
	FSMNAME();
	out << "ExecFuncs( fsm, f+" << machine->transFuncIndex[state->outFuncs]
			<< ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit them the call the execute them. */
	out << "\t";
	FSMNAME();
	out << "ExecFuncs( fsm, f+" << machine->transFuncIndex[trans->funcs]
			<< ", p );\n";
}


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
void CGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
}


char CGotoCodeGen::header[] = 
"

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	int curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CGotoCodeGen::code[] = "

/* The start state. */
static int @FSMNAME@_startState = @START_STATE_OFFSET@;

#define f @FSMNAME@_f
#define alph unsigned char

/* The array of functions. */
#if @ANY_FUNCS@
static int @FSMNAME@_f[] = {
@FUNCTIONS@
};
#endif

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}

/***************************************************************************
 * Function exection. We do not inline this as in tab
 * code gen because if we did, we might as well just expand 
 * the function as in the faster goto code generator.
 */
static void @FSMNAME@ExecFuncs( @FSMNAME@ *fsm, int *funcs, char *p )
{
	int len = *funcs++;
	while ( len-- > 0 ) {
		switch ( *funcs++ ) {
@FUNC_SWITCH@
		}
	}
}

/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen )
{
	/* Prime these to one back to simulate entering the 
	 * machine on a transition. */ 
	register char *p = data - 1;
	register int len = dlen + 1;

	/* Switch statment to enter the machine. */
	switch ( @FSM_PREFIX@curState ) {
@JUMP_IN_SWITCH@
	}
@STATE_GOTOS@
@EXIT_STATES@
@ERROR_LABEL@
}

/**********************************************************************
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	int cs = fsm->curState;
	int accept = 0;
@FINISH_SWITCH@
	fsm->accept = accept;
}

/*******************************************************
 * Did the machine accept?
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}

#undef f
#undef alph

";

/* Registers all the section names and inits the code and data pointers. */
CCGotoCodeGen::CCGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		GotoCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;

	needErrorLabel = false;

	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( f+" << machine->transFuncIndex[state->outFuncs]
			<< ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( f+" << machine->transFuncIndex[trans->funcs] 
			<< ", p );\n";
}

/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
void CCGotoCodeGen::FSM_PREFIX()
{
}


char CCGotoCodeGen::header[] = 
"

/* Only non-static data: current state. */
class @FSMNAME@
{
public:
	@FSMNAME@();

	/* Init the fsm. */
	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int dlen );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	int curState;
	int accept;
	/* The start state. */
	static int startState;

	/* Function exection. We do not inline this as in tab code gen
	 * because if we did, we might as well just expand the function 
	 * as in the faster goto code generator. */
	void ExecFuncs( int *funcs, char * );

	@STRUCT_DATA@
};

";

char CCGotoCodeGen::code[] = "

/* The start state. */
int @FSMNAME@::startState = @START_STATE_OFFSET@;

/* some defines to lessen the code size. */
#define f @FSMNAME@_f
#define alph unsigned char

/* The array of functions. */
#if @ANY_FUNCS@
static int @FSMNAME@_f[] = {
@FUNCTIONS@
};
#endif


/****************************************
 * Make sure the fsm is initted.
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * Initialize the fsm.
 */
void @FSMNAME@::Init( )
{
	curState = startState;
	accept = 0;
	@INIT_CODE@
}

/***************************************************************************
 * Execute functions pointed to by funcs until the null function is found. 
 */
void @FSMNAME@::ExecFuncs( int *funcs, char *p )
{
	int len = *funcs++;
	while ( len-- > 0 ) {
		switch ( *funcs++ ) {
@FUNC_SWITCH@
		}
	}
}


/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int dlen )
{
	/* Prime these to one back to simulate entering the 
	 * machine on a transition. */ 
	register char *p = data - 1;
	register int len = dlen + 1;

	/* Switch statment to enter the machine. */
	switch ( curState ) {
@JUMP_IN_SWITCH@
	}
@STATE_GOTOS@
@EXIT_STATES@
@ERROR_LABEL@
}

/**********************************************************************
 * @FSMNAME@::Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	int cs = curState;
	int accept = 0;
@FINISH_SWITCH@
	this->accept = accept;
}

/*******************************************************
 * @FSMNAME@::Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@::Accept( )
{
	return accept;
}

#undef f
#undef alph

";



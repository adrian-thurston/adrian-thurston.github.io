/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "avlimap.h"

#define AVLTREE_MAP
#define WALKABLE
#include "avlverify.h"
#undef WALKABLE
#undef AVLTREE_MAP

/* Having the action change perion larger than the number of initial entries
 * means that it will take longer to get to all the cases, but all the
 * cases will be more thoroughly tested. The tree will be more likely to
 * empty out completely and fill up with all of the entries. */
#define INITIAL_ENTRIES 64831
#define ACTION_CHANGE_PERIOD 120233
#define VERIFY_PERIOD 1119
#define COPY_PERIOD 1351
#define INCREMENT_VARIATION 10
#define STATS_PERIOD 211
#define OUTBUFSIZE 100


/* Instantiate the entire tree. */
template class AvliMap< int, int, CmpOrd<int> >;
template class AvliMapVer< int, int, CmpOrd<int> >;

int increment = 0;
int curIndex = 0;
int action = 1;
int curRound = 0;

void ExpandTab(char *buf, char *dstBuf)
{
	int pos = 10;
	char *src = buf;
	char *dst = dstBuf;

	while ( *src != 0 ) {
		if ( *src == '\t' ) {
			*dst++ = ' ';
			while ( dst - dstBuf < pos )
				*dst++ = ' ';
			pos += 10;
		}
		else
			*dst++ = *src;
		src++;
	}
	*dst = 0;
}

/* Replace the current stats line with new stats. For one tree. */
void PrintStats( int nodeCount, AvliMapNode<int,int> *head )
{
	/* Print stats. */
	char buf1[OUTBUFSIZE];
	char buf2[OUTBUFSIZE];

	if ( curRound % STATS_PERIOD == 0 ) {
		memset( buf1, '\b', OUTBUFSIZE );
		fwrite( buf1, 1, OUTBUFSIZE, stdout );
		sprintf(buf1, "%i\t%i\t%s\t%s\t%i\t%i\t%i\t", curRound, increment,
				action&0x1 ? "yes" : "no", action&0x2 ? "yes" : "no", 
				curIndex, nodeCount, head ? head->height : 0 );
		ExpandTab(buf1, buf2);
		fputs(buf2, stdout);
		fflush(stdout);
	}
}

/* Find a new curIndex to use. If the increment is 0 then get
 * a random curIndex. Otherwise use the increment. */
void NewIndex()
{
	if ( increment == 0 )
		curIndex = random() % INITIAL_ENTRIES;
	else
		curIndex = (curIndex + increment) % INITIAL_ENTRIES;
}

/* Print the header to the stats. For one tree. */
void PrintHeader()
{
	char buf[OUTBUFSIZE];
	ExpandTab( "round\tinc\tins\trem\tindex\tnodes\theight\n", buf);
	fputs(buf, stdout);
}


int main()
{
	srandom( time(0) );

	typedef AvliMapNode< int, int > TreeNode;
	AvliMapVer< int, int, CmpOrd<int> > tree;

	PrintHeader();

	for ( curRound = 0; true; curRound++ ) {
		/* Do we change our action? */
		if ( curRound % ACTION_CHANGE_PERIOD == 0 ) {
			increment = random() % 2;
			if ( increment > 0 )
				increment = random() % INCREMENT_VARIATION;

			action = (random()%3) + 1;
		}

		/* Dump stats. */
		PrintStats( tree.nodeCount, tree.root );

		/* Insert one? */
		if ( action&0x1 ) {
			NewIndex();
			tree.insert( curIndex, curIndex );
		}

		/* Delete one? */
		if ( action&0x2 ) {
			NewIndex();
			TreeNode *node = tree.detach( curIndex );
			if ( node != 0 )
				delete node;
		}

		/* Verify? */
		if ( curRound % VERIFY_PERIOD == 0 )
			tree.VerifyIntegrity();

		/* Test the copy constructor? */
		if ( curRound % COPY_PERIOD == 0 ) {
			AvliMapVer< int, int, CmpOrd<int> > copy(tree);
			copy.VerifyIntegrity();
			copy.empty();
		}

	}	
	return 0;
}

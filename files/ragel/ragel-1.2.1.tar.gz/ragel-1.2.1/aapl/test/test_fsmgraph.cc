/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <iomanip>

#include "fsmgraph.h"
#include "fsmbase.cc"
#include "fsmgraph.cc"

using std::ostream;
using std::cout;
using std::endl;

struct State;
struct Trans : public FsmTrans<State, Trans, int, CmpOrd<int> > {};
struct State : public FsmState<State, int, Trans> {}; 

typedef FsmGraph<State, int, Trans> Fsm;
template class FsmGraph<State, int, Trans>;
void dumpGraph( ostream &out, Fsm *fsm );

int testGraph1(int argc, char **argv)
{
	Fsm *fsm, *b, *c;

	fsm = Fsm::RangeFsm('a', 'z');
	dumpGraph( cout, fsm );

	b = Fsm::RangeFsm('m', 'q');
	dumpGraph( cout, b );

	c = Fsm::RangeFsm(0, 100000);
	dumpGraph( cout, b );

	fsm->Or(b);
	fsm->Or(c);
	dumpGraph( cout, fsm );

	delete fsm;

	return 0;
}

int main(int argc, char **argv)
{
	return testGraph1(argc, argv);
}

/**
 * Dump the target state, priority, and functions of a transition
 */
void dumpTransData( ostream &out, Trans *trans )
{
	cout << trans->toState->num << " [" << trans->priority << "](";

	/* Print the functions, adding in commas in between. */
	Trans::TransFuncEl *tfel = trans->transFuncTable.table;
	int nfunc = trans->transFuncTable.tableLength;
	for ( int i = 0; i < nfunc-1; i++, tfel++ )
		out << tfel->value << ",";

	/* Print the last function without the comma. */
	if ( nfunc > 0 )
		out << tfel->value;
		
	out << ")";
}

/**
 * Dump a transition. Trans should not be null.
 */
void dumpTrans( ostream &out, int onChar, Trans *trans )
{
	out << " " << onChar << " ";
	if ( trans != NULL )
		dumpTransData( out, trans );
	else
		out << "xx []()";
	out << " |";
}

/**
 * Dump a range transition.
 */
void dumpRangePair( ostream &out, int onChar1, int onChar2, Trans *trans )
{
	out << " " << onChar1 << ".." << onChar2 << " ";
	if ( trans != NULL )
		dumpTransData( out, trans );
	else
		out << "xx []()";
	out << " |";
}

/**
 * Dump a default transition.
 */
void dumpDefTrans( ostream &out, Trans *trans )
{
	out << " df ";
	dumpTransData( out, trans );
	out << " |";
}

/**
 * Walk a list of transitions and dump the individual transitions.
 */
void dumpTransList( ostream &out, State::TransListType *list )
{
	State::TransEl *tel = list->table;
	int ntel = list->tableLength;
	for ( int i = 0; i < ntel; i++, tel++ )
		dumpTrans( out, tel->key, tel->value );
}

/**
 * Walk a list of range transitions and dump the individual transitions.
 */
void dumpTransRange( ostream &out, State::TransListType *list )
{
	State::TransEl *tel = list->table;
	for ( int i = 0; i < list->tableLength; i+=2, tel+=2 )
		dumpRangePair( out, tel[0].key, tel[1].key, tel[0].value );
}


/**
 * Dump a graph to ostream out.
 */
void dumpGraph( ostream &out, Fsm *fsm )
{
	/* Set the state numbers so we print something nice! */
	fsm->SetStateNumbers();

	/* Some header info. */
	out << "StartState: " << fsm->startState->num <<
			"  " << "Final States:";

	/* Dump Final states. */
	State **st = fsm->finStateSet.table;
	int nst = fsm->finStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ )
		out << " " << (*st)->num << " |";
	out << endl;

	/* Walk the list of states, printing. */
	State *state = fsm->head;
	while (state) {
		out << state->num << " [";
		if ( state->isOutPriorSet )
			out << state->outPriority;
		out << "](";

		/* Print the functions, adding in commas in between. */
		Trans::TransFuncEl *tfel = state->outTransFuncTable.table;
		int nfunc = state->outTransFuncTable.tableLength;
		for ( int i = 0; i < nfunc-1; i++, tfel++ )
			out << tfel->value << ",";

		/* Print the last function without the comma. */
		if ( nfunc > 0 )
			out << tfel->value;

		out << ")\n->";

		/* If there is a default trans, dump it. */
		if ( state->defOutTrans != NULL )
			dumpDefTrans( out, state->defOutTrans );

		/* Dump the range transitions. */
		dumpTransRange( out, &state->outRange );

		/* Dump the single transitions. */
		dumpTransList( out, &state->outList );

		out << endl;
		state = state->next;
	}
}

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_MERGESORT_H
#define _AAPL_MERGESORT_H

/**
 * Note that MergeSort needs some temporary space to do its thing and
 * the = operator is used to move data to a temporary store and memcpy
 * moves it back to it's original location. Destructors are not called
 * on the temporary store so if the = opertor is overloaded to act like
 * a copy construcor and news stuff up, the storage will be lost.
 *
 * This really belongs as two template function calls but unfortanately
 * the solaris compiler (5.0) is not capable of doing to lookup on
 * the template specialization. I believe this is because the class Compare
 * is part of the template but does not exist in the parameter list.
 * Even calling the function in the form MergeSort<char*,StringCompare>( ... )
 * does not work. So it it is a class.
 */
template <class T, class Compare> class MergeSort
{
public:
	/* Sorting interface routine. */
	static void Sort(T *data, int len);

private:
	/* Recursive worker. */
	static void DoSort(T *tmpStor, T *data, int len);
};


/**
 * Recursive mergesort worker. Split data, make recursive calls, merge
 * results.
 */
template< class T, class Compare> 
	void MergeSort<T,Compare>::DoSort(T *tmpStor, T *data, int len)
{
	if ( len <= 1 )
		return;

	int mid = len / 2;

	DoSort( tmpStor, data, mid );
	DoSort( tmpStor + mid, data + mid, len - mid );
	
	/* Merge the data. */
	T *endLower = data + mid, *lower = data;
	T *endUpper = data + len, *upper = data + mid;
	T *dest = tmpStor;
	while ( true ) {
		if ( lower == endLower ) {
			/* Possibly upper left. */
			while ( upper != endUpper )
				*dest++ = *upper++;
			break;
		}
		else if ( upper == endUpper ) {
			/* Only lower left. */
			while ( lower != endLower )
				*dest++ = *lower++;
			break;
		}
		else {
			/* Both upper and lower left. */
			if ( Compare::Compare(*lower, *upper) <= 0 )
				*dest++ = *lower++;
			else
				*dest++ = *upper++;
		}
	}

	/* Copy back from the tmpStor array. */
	memcpy( data, tmpStor, sizeof( T ) * len );
}

/**
 * Mergesort an array of data.
 */
template< class T, class Compare> 
	void MergeSort<T,Compare>::Sort(T *data, int len)
{
	/* Allocate the tmp space needed by merge sort, sort and free. */
	T *tmpStor = (T*) new char[sizeof( T ) * len];
	DoSort(tmpStor, data, len );
	delete[] (char*) tmpStor;
}

#endif /* _AAPL_MERGESORT_H */

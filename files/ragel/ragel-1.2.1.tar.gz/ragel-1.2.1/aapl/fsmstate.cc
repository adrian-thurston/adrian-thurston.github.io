/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMSTATE_CC
#define _AAPL_FSMSTATE_CC

#include <string.h>
#include <assert.h>

/**
 * Construct a mark index for a specified number of states. Must new up
 * an array that is states^2 in size.
 */
template < class State > MarkIndexTmpl<State>::
		MarkIndexTmpl( int states ) : numStates(states)
{
	/* Total pairs is states^2. Actually only use half of these. */
	int total = states * states;

	/* New up chars so that individual DListEl constructors are
	 * not called. Zero out the mem manually. */
	array = (StatePair*) new char[sizeof(StatePair) * total];
	memset( array, 0, sizeof(StatePair) * total );
}

/**
 * Free the array used to store state pairs.
 */
template < class State >MarkIndexTmpl<State>::~MarkIndexTmpl()
{
	delete[] (char*) array;
}

/**
 * Mark a pair of states. States are specified by their number. The
 * marked states are moved from the unmarked list to the marked list.
 */
template < class State > void MarkIndexTmpl<State>::
		MarkPair(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	assert( ! array[pos].isMarked );
	array[pos].isMarked = true;
	markedList.append( unmarkedList.detach( &array[pos] ) );
}

/**
 * Returns true if the pair of states are marked. Returns false otherwise.
 * Ordering of states given does not matter.
 */
template < class State > bool MarkIndexTmpl<State>::
		IsPairMarked(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	return array[pos].isMarked;
}

/**
 * Get the unique StatePair structure for the given pair of states. Ordering
 * does not matter.
 */
template < class State > MarkIndexTmpl<State>::StatePair *MarkIndexTmpl<State>::
		GetPair(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	return array + pos;
}

/**
 * Insert a function into a transition's function table.
 */
template < class State, class Transition,
		class TransFunc, class TransFuncCmp >
		void FsmTrans<State, Transition, TransFunc, TransFuncCmp>::
		SetFunction( TransFunc func, int transOrder )
{
	transFuncTable.insertMulti( transOrder, func );
}

/**
 * Set all the functions from a specified TransFuncTable into the transition's
 * function table.
 */
template < class State, class Transition,
		class TransFunc, class TransFuncCmp >
		void FsmTrans<State, Transition, TransFunc, TransFuncCmp>::
		SetFunctions( TransFuncTable &funcTable )
{
	TransFuncEl *tfel = funcTable.table;
	int ntfel = funcTable.tableLength;
	for ( int i = 0; i < ntfel; i++, tfel++ )
		transFuncTable.insertMulti( tfel->key, tfel->value );
}


/**
 * Compare two transition function tables. Simply provides easy access to 
 * TransFuncTableCompare::Compare.
 */
template < class State, class Transition,
		class TransFunc, class TransFuncCmp >
		int FsmTrans<State, Transition, TransFunc, TransFuncCmp>::
		CompareFuncs( const TransFuncTable &funcs1, const TransFuncTable &funcs2 )
{
	return TransFuncTableCompare::Compare( funcs1, funcs2 );
}

/**
 * Compares two transitions according to priority and functions. Does
 * not consider to state or from state.
 */
template < class State, class Transition, class TransFunc, class TransFuncCmp >
		int FsmTrans<State, Transition, TransFunc, TransFuncCmp>::
		CompareTransData( FsmTrans *trans1, FsmTrans *trans2 )
{
	if ( trans1->priority < trans2->priority )
		return -1;
	else if ( trans1->priority > trans2->priority )
		return 1;
	else {
		int cmpResult = TransFuncTableCompare::
				Compare(trans1->transFuncTable, trans2->transFuncTable);
		if ( cmpResult != 0 )
			return cmpResult;
	}
	return 0;
}

/**
 * Compares two transitions according to target state, priority and functions.
 * Does not consider from state.
 */
template < class State, class Transition, class TransFunc, class TransFuncCmp >
		int FsmTrans<State, Transition, TransFunc, TransFuncCmp>::
		CompareTrans( FsmTrans *trans1, FsmTrans *trans2 )
{
	/* Test target states. */
	if ( trans1->toState < trans2->toState )
		return -1;
	else if ( trans1->toState > trans2->toState )
		return 1;
	else {
		/* Test priority. */
		if ( trans1->priority < trans2->priority )
			return -1;
		else if ( trans1->priority > trans2->priority )
			return 1;
		else {
			/* Test function table. */
			int cmpResult = TransFuncTableCompare::
					Compare(trans1->transFuncTable, trans2->transFuncTable);
			if ( cmpResult != 0 )
				return cmpResult;
		}
	}

	return 0;
}

/**
 * Compares two transitions according to target state, priority and functions.
 * Does not consider from state. Either of the pointers may be null.
 */
template < class State, class Transition, class TransFunc, class TransFuncCmp >
		int FsmTrans<State, Transition, TransFunc, TransFuncCmp>::
		CompareTransPtrs( FsmTrans *trans1, FsmTrans *trans2 )
{
	if ( (trans1 != NULL) ^ (trans2 != NULL) ) {
		/* Exactly one of the transitions is set. */
		if ( trans1 != NULL )
			return -1;
		else
			return 1;
	}
	else if ( trans1 != NULL ) {
		/* Both of the transitions are set. Test target state, priority and
		 * funcs. */
		if ( trans1->toState < trans2->toState )
			return -1;
		else if ( trans1->toState > trans2->toState )
			return 1;
		else {
			/* Test priority. */
			if ( trans1->priority < trans2->priority )
				return -1;
			else if ( trans1->priority > trans2->priority )
				return 1;
			else {
				/* Test function table. */
				int cmpResult = TransFuncTableCompare::
						Compare(trans1->transFuncTable, trans2->transFuncTable);
				if ( cmpResult != 0 )
					return cmpResult;
			}
		}
	}
	/* Else, neither of the transitiosn are set. */

	return 0;
}

/**
 * Given a transition key, find the range the key is in. If the key is in a range, 
 * returns a pointer to the lower end of the range. If the key is not in a range,
 * returns NULL. Implemented with a binary search.
 */
template< class Transition > BstMapEl<int, Transition*> *
		FsmTransList<Transition>::findRange( int onChar )
{
	TransEl *endPoint, *result;

	/* Can't succeed with an empty table. */
	if ( tableLength == 0 )
		return NULL;

	result = find( onChar, &endPoint );
	if ( result != NULL ) {
		/* The key was found, we are right on an endpoint of a range. If on the
		 * high end of a range, return the low end. */
		if ( (result - table) & 0x1 )
			result -= 1;
	}
	else {
		/* The key was not found. endPoint gives the place we would insert at to
		 * put the key in the table. If endPoint is the high end of a range, then
		 * key is in that range. */
        if ( (endPoint - table) & 0x1 )
			result = endPoint - 1;
	}
	return result;
}



/**
 * Create a new fsm state. State has not out transitions or in transitions, not
 * out out transition data and not number.
 */
template< class State, class TransFunc, class Transition >
		FsmState<State, TransFunc, Transition>::FsmState()
{
	/* General State data. */
	num = 0;
	stateMap = NULL;

	/* No default transitions. */
	defOutTrans = NULL;
	defInTrans = NULL;

	/* No out priority by default. */
	isOutPriorSet = false;
	outPriority = 0;

	/* Fsm State data. */
	isFinState = false;
	isMarked = false;
	stateBits = 0;
	stateDictNode = NULL;
}

/**
 * Copy everything except the transitions. That is left up to the FsmGraph copy
 * constructor.
 */
template< class State, class TransFunc, class Transition >
		FsmState<State, TransFunc, Transition>::FsmState(const FsmState &other)
:
	outList(other.outList), inList(other.inList),
	outRange(other.outRange), inRange(other.inRange),
	outTransFuncTable(other.outTransFuncTable)
{
	/* General State data. */
	num = other.num;
	stateMap = NULL;

	/* Get the out priority stuff. */
	isOutPriorSet = other.isOutPriorSet;
	outPriority = other.outPriority;

	/* Fsm state data. */
	isFinState = other.isFinState;
	isMarked = other.isMarked;
	stateBits = other.stateBits;
	stateDictNode = other.stateDictNode;

	/* Zero out the in list pointers (not keys). */
	TransEl *tel = inList.table;
	for ( int i = 0; i < inList.tableLength; i++, tel++ )
		tel->value = NULL;

	/* Zero out the in range pointers (not keys). */
	tel = inRange.table;
	for ( int i = 0; i < inRange.tableLength; i++, tel++ )
		tel->value = NULL;

	/* Get the defOutTrans but zero out the defInTrans. */
	defOutTrans = other.defOutTrans;
	defInTrans = NULL;
}

/**
 * If there is a state dict node, then delete it. Everything else is left
 * up the FsmGraph destructor.
 */
template< class State, class TransFunc, class Transition >
		FsmState<State, TransFunc, Transition>::~FsmState()
{
	if ( stateDictNode != NULL )
		delete stateDictNode;
}

/**
 * Insert the contents of funcTable into this state's out functions.
 */
template< class State, class TransFunc, class Transition >
		void FsmState<State, TransFunc, Transition>::
		SetOutFunctions( TransFuncTable &funcTable )
{
	TransFuncEl *tfel = funcTable.table;
	int ntfel = funcTable.tableLength;
	for ( int i = 0; i < ntfel; i++, tfel++ )
		outTransFuncTable.insertMulti( tfel->key, tfel->value );
}

/**
 * Compare the out transition data of two states. Compares out priorities and
 * out transitions.
 */
template< class State, class TransFunc, class Transition >
		int FsmState<State, TransFunc, Transition>::
		CompareOutTrans( const FsmState &state1, const FsmState &state2 )
{
	/* If only one out priority is set then differ. */
	if ( state1.isOutPriorSet && !state2.isOutPriorSet )
		return -1;
	else if ( !state1.isOutPriorSet && state2.isOutPriorSet )
		return 1;
	else if ( state1.isOutPriorSet && state2.isOutPriorSet ) {
		/* Both priorities set, compare the priorites. */
		int outPriorCmp = CmpOrd<int>::Compare(
				state1.outPriority, state2.outPriority );
		if ( outPriorCmp != 0 )
			return outPriorCmp;
	}

	/* Test outTransFuncTable. */
	int outTransCmp = Transition::CompareFuncs(
			state1.outTransFuncTable, state2.outTransFuncTable);
	if ( outTransCmp != 0 )
		return outTransCmp;

	return 0;
}

/**************************************************************************
 * FsmState::Compare
 *
 * Compare two pointers to states (actually compares the states they point to).
 * Compare States according to:
 *  Final state status.
 *  Out transition data.
 *  Default transitions.
 *  Length of lists.
 *    Do any onChar values differ
 *    Do any of the targeted states differ.
 *    Do any of the transitions differ.
 */
template< class State, class TransFunc, class Transition >
		int FsmState<State, TransFunc, Transition>::
		Compare( const PState state1 , const PState state2 )
{
	/* Test final state status. */
	if ( state1->isFinState != state2->isFinState ) {
		if (state1->isFinState)
			return -1;
		else
			return 1;
	}
	
	/* Compare the out transitions. */
	int outTransCmp = CompareOutTrans( *state1, *state2 );
	if ( outTransCmp )
		return outTransCmp;

	/* Test transition table length. */
	if ( state1->outList.tableLength != state2->outList.tableLength ) {
		if ( state1->outList.tableLength < state2->outList.tableLength )
			return -1;
		else
			return 1;
	}

	/* Test default transitions. */
	int funcCmp = Transition::CompareTransPtrs( state1->defOutTrans, 
			state2->defOutTrans );
	if ( funcCmp != 0 )
		return funcCmp;

	/* Walk the lists, testing onChars, targets, and transitions. At this
	 * point, the lists are know to be the same length. */
	TransEl *el1 = state1->outList.table;
	TransEl *el2 = state2->outList.table;
	int nel = state1->outList.tableLength;
	for ( int i = 0; i < nel; i++, el1++, el2++ ) {
		/* Test onChar. */
		if ( el1->key != el2->key ) {
			if ( el1->key < el2->key )
				return -1;
			else
				return 1;
		}

		/* Test transitions. Test includes target state, priority and funcs. */
		int funcCmp = Transition::CompareTransPtrs( el1->value, el2->value );
		if ( funcCmp != 0 )
			return funcCmp;
	}

	/* Got through the entire state comparison, deem them equal. */
	return 0;
}

#endif /* _AAPL_FSMSTATE_CC */

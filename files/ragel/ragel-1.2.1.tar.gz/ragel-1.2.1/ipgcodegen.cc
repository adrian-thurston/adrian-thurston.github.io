/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "ipgcodegen.h"
#include "bstmap.h"

/* Inits the code and data pointers. There are no code generation 
 * functions to register. */
IpGotoCodeGen::IpGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		GotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void IpGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	int *funcs = machine->allTransFuncs + 
			machine->transFuncIndex[state->outFuncs];

	/* The first number is the length. */
	int flen = *funcs++;
	while ( flen-- > 0 ) {
		out << "{" << getCodeBuiltin(*funcs) << "}";
		funcs += 1;
	}
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void IpGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* Get the funcs. */
	int *funcs = machine->allTransFuncs + 
			machine->transFuncIndex[trans->funcs];

	/* The first number is the length. */
	int flen = *funcs++;
	while ( flen-- > 0 ) {
		out << "\t{" << getCodeBuiltin(*funcs) << "}\n";
		funcs += 1;
	}
}

/* Registers all the section names and inits the code and data pointers. */
CIpGotoCodeGen::CIpGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		IpGotoCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;

	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
void CIpGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
}

char CIpGotoCodeGen::header[] = 
"

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	int curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CIpGotoCodeGen::code[] = "

/* The start state. */
static int @FSMNAME@_startState = @START_STATE_OFFSET@;

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}

#define alph unsigned char

/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen )
{
	/* Prime these to one back to simulate entering the 
	 * machine on a transition. */ 
	register char *p = data-1;
	register int len = dlen+1;

	/* Switch statment to enter the machine. */
	switch ( @FSM_PREFIX@curState ) {
@JUMP_IN_SWITCH@
	}
@STATE_GOTOS@
@EXIT_STATES@
@ERROR_LABEL@
}

/**********************************************************************
 * @FSMNAME@Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	int cs = fsm->curState;
	int accept = 0;
@FINISH_SWITCH@
	fsm->accept = accept;
}

/*******************************************************
 * @FSMNAME@Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}

#undef alph
";

/* Registers all the section names and inits the code and data pointers. */
CCIpGotoCodeGen::CCIpGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		IpGotoCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;

	needErrorLabel = false;

	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}


/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
void CCIpGotoCodeGen::FSM_PREFIX()
{
}


char CCIpGotoCodeGen::header[] = 
"

/* Only non-static data: current state. */
class @FSMNAME@
{
public:
	@FSMNAME@();

	/* Init the fsm. */
	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int dlen );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	int curState;
	int accept;
	@STRUCT_DATA@

	/* The start state. */
	static int startState;
};

";

char CCIpGotoCodeGen::code[] = "

/* The start state. */
int @FSMNAME@::startState = @START_STATE_OFFSET@;

/****************************************
 * @FSMNAME@::@FSMNAME@
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * @FSMNAME@::Init
 */
void @FSMNAME@::Init( )
{
	curState = startState;
	accept = 0;
	@INIT_CODE@
}


#define alph unsigned char

/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int dlen )
{
	/* Prime these to one back to simulate entering the 
	 * machine on a transition. */ 
	register char *p = data-1;
	register int len = dlen+1;

	/* Switch statment to enter the machine. */
	switch ( curState ) {
@JUMP_IN_SWITCH@
	}
@STATE_GOTOS@
@EXIT_STATES@
@ERROR_LABEL@
}

/**********************************************************************
 * @FSMNAME@::Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	int cs = curState;
	int accept = 0;
@FINISH_SWITCH@
	this->accept = accept;
}

/*******************************************************
 * @FSMNAME@::Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@::Accept( )
{
	return accept;
}

#undef alph

";

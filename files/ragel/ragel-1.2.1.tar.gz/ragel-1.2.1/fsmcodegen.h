/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _FSMCODEGEN_H
#define _FSMCODEGEN_H

#include <iostream>
#include <fstream>
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"

class FsmCodeGen;
typedef void (*SectionType)(FsmCodeGen *codeGen);

#define codegen

/***********************************************************************
 * class FsmCodeGen
 */
class FsmCodeGen
{
public:
	FsmCodeGen( char *fsmName, FsmMachine<int> *machine, 
			ParseData *parseData, ostream &out );
	virtual ~FsmCodeGen() {}

	void WriteOutHeader( );
	void WriteOutCode( );

protected:
	void writeOutScan( char *data );
	void selectSection( char *sname );

	BstMap<char*, SectionType, CmpStr> sectionDict;
	void registerSection( char *secName, SectionType call );
	char *getCodeBuiltin(int index);

	char *header;
	char *code;

	char *fsmName;
	FsmMachine<int> *machine;
	ParseData *parseData;
	ostream &out;

	/* These are used in all machines generators for generic writing 
	 * of out functions. */
	virtual void stateOutFunc(FsmMachState *state) { }
	virtual void transFunc(FsmMachTrans *trans) { }

public:
	void codegen FSMNAME();
	void codegen STRUCT_DATA();
	void codegen INIT_CODE();
	void codegen ANY_FUNCS();
	void codegen ANY_INDICIES();
	void codegen START_STATE_OFFSET();
	void codegen FUNCTIONS();

private:
	void registerSections();
};


#endif /* _FSMCODEGEN_H */

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "selcodegen.h"


/* Registers all the section names and inits the code and data pointers. */
SelCodeGen::SelCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData ) : FsmCodeGen(fsmName, machine, parseData)
{
	RegisterSection( "START_STATE", sel_START_STATE );
	RegisterSection( "STATE_SWITCH", sel_STATE_SWITCH );
	RegisterSection( "FINISH_SWITCH", sel_FINISH_SWITCH );
}

void sel_STATE_SWITCH( FsmCodeGen *codeGen, ostream &out )
{
	out << "switch( cs ) {" << endl;
	for ( int stIndex = 0; stIndex < codeGen->machine->numStates; stIndex++ ) {
		FsmMachState<int> *state = codeGen->machine->allStates+stIndex;

		int numIndex = codeGen->machine->allStates[stIndex].numIndex;
		FsmMachTrans<int> **ind = state->transIndex;

		/* Use void* here for simplicity. */
		BSTable< void*, Vector<int>, OrdinalCompare<void*> > funcMap;

		for ( int j = 0; j < numIndex; j++, ind++) {
			/* Try to insert the pointer to the transition. We use
			 * lastfound so we don't care if it fails or not. We are
			 * just interested in the Vector<int> at the trans ptr. */
			BSElement< void*, Vector<int> > *lastFound;
			funcMap.Insert( *ind, &lastFound );
			
			/* Now apend the char for this transition to the vector. */
			Vector<int> &charVec = lastFound->Value;
			charVec.Append( state->lowIndex + j );
		}

		out.form("case %i: {\n", stIndex);
		out << "switch ( c ) {" << endl;
		for ( int j = 0; j < funcMap.TableLength; j++ ) {
			Vector<int> &charVec = funcMap.Table[j].Value;
			for ( int k = 0; k < charVec.TableLength; k++ ) {
				out.form("case %i:", charVec.Table[k] );
				if ( k % 4 == 3 )
					out << endl;
			}
			FsmMachTrans<int> *trans = (FsmMachTrans<int>*) funcMap.Table[j].Key;
			int toState;
			if ( trans->toState != 0 )
				toState = trans->toState - codeGen->machine->allStates;
			else
				toState = -1;
			out << "{";
			if ( toState != stIndex )
				out.form( "cs = %i;", toState );
			int *funcs = trans->funcs;
			if ( funcs ) {
				while ( *funcs != 0 ) {
					out.form("{%s}", codeGen->GetCodeBuiltin( *funcs ) );
					funcs += 1;
				}
			}
			out << "break;}" << endl;
		}
		out << "default:{cs = -1;break;}}" << endl;
		out << "break;}" << endl;
	}
	out << "}" << endl;
}

void sel_FINISH_SWITCH( FsmCodeGen *codeGen, ostream &out )
{
	out << "switch( cs ) {" << endl;
	for ( int stIndex = 0; stIndex < codeGen->machine->numStates; stIndex++ ) {
		FsmMachState<int> *state = codeGen->machine->allStates+stIndex;

		out.form("case %i: {\n", stIndex);
		if ( state->isFinState )
			out << "accept = 1;" << endl;
		int *funcs = state->outFuncs;
		if ( funcs ) {
			while ( *funcs != 0 ) {
				out.form("{%s}", codeGen->GetCodeBuiltin( *funcs ) );
				funcs += 1;
			}
		}

		out << "break;}" << endl;
	}
	out << "}" << endl;

}

void sel_START_STATE( FsmCodeGen *codeGen, ostream &out )
{
	out << (codeGen->machine->startState - codeGen->machine->allStates);
};


/* Registers all the section names and inits the code and data pointers. */
CSelCodeGen::CSelCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData ) : SelCodeGen(fsmName, machine, parseData)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CSelCodeGen::header[] = 
"

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	int curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int len );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CSelCodeGen::code[] = "

/* The start state. */
static int @FSMNAME@_startState = @START_STATE@;

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}


/**********************************************************************
 * @FSMNAME@Execute
 *
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int len )
{
	int cs = fsm->curState;
	for ( ; len > 0; data++, len-- ) {
		unsigned char c = *(unsigned char*)data;
		@PRE_FUNC_LIST@
		@STATE_SWITCH@
		@POST_FUNC_LIST@
	}
	fsm->curState = cs;
}

/**********************************************************************
 * @FSMNAME@Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	int cs = fsm->curState;
	int accept = 0;
	@FINISH_SWITCH@
	fsm->accept = accept;
}
/*******************************************************
 * @FSMNAME@Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}

";

/* Registers all the section names and inits the code and data pointers. */
CCSelCodeGen::CCSelCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData ) : SelCodeGen(fsmName, machine, parseData)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CCSelCodeGen::header[] = 
"

/* Only non-static data: current state. */
class @FSMNAME@
{
public:
	@FSMNAME@();

	/* Init the fsm. */
	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int len );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	int curState;
	int accept;
	@STRUCT_DATA@

	/* The start state. */
	static int startState;
};

";

char CCSelCodeGen::code[] = "

/* The start state. */
int @FSMNAME@::startState = @START_STATE@;

/****************************************
 * @FSMNAME@::@FSMNAME@
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * @FSMNAME@::Init
 */
void @FSMNAME@::Init( )
{
	curState = startState;
	accept = 0;
	@INIT_CODE@
}


/**********************************************************************
 * @FSMNAME@::Execute
 *
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int len )
{
	int cs = curState;
	for ( ; len > 0; data++, len-- ) {
		unsigned char c = *(unsigned char*)data;
		@PRE_FUNC_LIST@
		@STATE_SWITCH@
		@POST_FUNC_LIST@
	}
	curState = cs;
}

/**********************************************************************
 * @FSMNAME@::Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	int cs = curState;
	int accept = 0;
	@FINISH_SWITCH@
	this->accept = accept;
}

/*******************************************************
 * @FSMNAME@::Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@::Accept( )
{
	return accept;
}

";



/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


#include "fsm.h"

#include "fsmgraph.cc"
template class FsmTransition< State, Transition, int, OrdinalCompare<int> >;
template class FsmState<State, int, Transition>;
template class FsmGraph<State, int, Transition>;

void DumpTransition( ostream &out, int onChar, Transition *trans )
{
	out.form(" %.2i %.2x [%i](", trans->toState->Num,
			onChar, trans->priority );

	/* Print the functions, adding in commas in between. */
//	Transition::TransitionFuncEl *tfel = trans->transFuncTable.Table;
//	int ntfel = trans->transFuncTable.TableLength;
//	for ( int i = 0; i < ntfel-1; i++, tfel++ )
//		out.form("%s,", tfel->Value);
//
//	/* Print the last function without the comma. */
//	if ( ntfel > 0 )
//		out.form("%s", tfel->Value);
		
	/* Print the functions, adding in commas in between. */
	Transition::TransitionFuncEl *tfel = trans->transFuncTable.Table;
	int nfunc = trans->transFuncTable.TableLength;
	for ( int i = 0; i < nfunc-1; i++, tfel++ )
		out.form("%i,", tfel->Value);

	/* Print the last function without the comma. */
	if ( nfunc > 0 )
		out.form("%i", tfel->Value);
		
	out << ") |";
}

void DumpTransitions( ostream &out, State::TransListType *list )
{
	State::TransEl *tel = list->Table;
	int ntel = list->TableLength;
	for ( int i = 0; i < ntel; i++, tel++ )
		DumpTransition( out, tel->Key, tel->Value );

	out << endl;
}

void DumpGraph( ostream &out, Fsm *fsm )
{
	/* Set the state numbers so we print something nice! */
	fsm->SetStateNumbers();

	/* Some header info. */
	out.form("StartState: %.2i  ", fsm->StartState->Num);
	out.form("Final States:");

	/* Dump Final states. */
	State **st = fsm->FinStateSet.Table;
	int nst = fsm->FinStateSet.TableLength;
	for ( int i = 0; i < nst; i++, st++ )
		out.form(" %.2i |", (*st)->Num );
	out << endl;

	/* Walk the list of states, printing. */
	State *state = fsm->Head;
	while (state) {
		out.form("%.2i [%i] (", state->Num, state->outPriority );

//		/* Print the functions, adding in commas in between. */
//		Transition::TransitionFuncEl *tfel = state->outTransition.transFuncTable.Table;
//		int ntfel = state->outTransition.transFuncTable.TableLength;
//		for ( int i = 0; i < ntfel-1; i++, tfel++ )
//			out.form("%i,", tfel->Value);
//
//		/* Print the last function without the comma. */
//		if ( ntfel > 0 )
//			out.form("%i", tfel->Value);

		/* Print the functions, adding in commas in between. */
		Transition::TransitionFuncEl *tfel = state->outTransFuncTable.Table;
		int nfunc = state->outTransFuncTable.TableLength;
		for ( int i = 0; i < nfunc-1; i++, tfel++ )
			out.form("%i,", tfel->Value);

		/* Print the last function without the comma. */
		if ( nfunc > 0 )
			out.form("%i", tfel->Value);

		out << ")\n->";

		DumpTransitions(out, &state->OutList);
		state = state->Next;
	}
}


/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "tabcodegen.h"

/* Registers all the section names and inits the code and data pointers. */
TabCodeGen::TabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData ) : FsmCodeGen(fsmName, machine, parseData)
{
	RegisterSection( "FUNCTIONS", tab_FUNCTIONS );
	RegisterSection( "FUNC_SWITCH", tab_FUNC_SWITCH );

	RegisterSection( "START_STATE_OFFSET", tab_START_STATE_OFFSET );
	RegisterSection( "GBL_LOW_INDEX", tab_GBL_LOW_INDEX );
	RegisterSection( "GBL_HIGH_INDEX", tab_GBL_HIGH_INDEX );
	RegisterSection( "INDEX_TYPE", tab_INDEX_TYPE );

	RegisterSection( "INDICIES", tab_INDICIES );
	RegisterSection( "STATES", tab_STATES );
	RegisterSection( "TRANSITIONS", tab_TRANSITIONS );
}

void tab_FUNCTIONS( FsmCodeGen *codeGen, ostream &out )
{
	if ( codeGen->machine->numTransFuncs <= 0 )
		return;
	
	for ( int i = 0; i < codeGen->machine->numTransFuncs; i++ )  {
		int func = codeGen->machine->allTransFuncs[i];
		out.form("\t%i", func );
		if ( i < codeGen->machine->numTransFuncs-1 )
			out << ",\n";
	}
}

void tab_FUNC_SWITCH( FsmCodeGen *codeGen, ostream &out )
{
	/* Walk the list of functions, printing the cases. */
	StringListEl *flel = codeGen->parseData->funcList.Head;
	int fnum = 1;
	while ( flel != NULL ) {
		out.form( "\tcase %d: {\n", fnum );
		out << flel->data;
		out << "break;}" << endl;
		fnum += 1;
		flel = flel->Next;
	}
}

void tab_STATES( FsmCodeGen *codeGen, ostream &out )
{
	int curIndex = 0;
	for ( int i = 0; i < codeGen->machine->numStates; i++ ) {
		FsmMachState<int> *state = codeGen->machine->allStates+i;

		out.form("\t{ %i, %i, ", state->lowIndex,
				state->highIndex );

		if ( state->transIndex )
			out.form( "i+%i, ", curIndex );
		else
			out << "0, ";

		ASSERT( state->errIndex );
		out.form( "%i, ", state->errIndex - codeGen->machine->allTrans );

		if ( state->outFuncs != 0 )
			out.form("f+%i, ", state->outFuncs - codeGen->machine->allTransFuncs );
		else
			out << "0, ";

		out.form( "%i }", state->isFinState );
		if ( i < codeGen->machine->numStates-1 )
			out << ",\n";

		curIndex += state->numIndex;
	}
}

void tab_INDICIES( FsmCodeGen *codeGen, ostream &out )
{
	out << '\t';
	int totalTrans = 0;
	FsmMachTrans<int> *transBase = codeGen->machine->allTrans;
	for ( int i = 0; i < codeGen->machine->numStates; i++ ) {
		int numIndex = codeGen->machine->allStates[i].numIndex;
		FsmMachTrans<int> **ind = codeGen->machine->allStates[i].transIndex;

		for ( int j = 0; j < numIndex; j++, ind++) {
			out.form( "%i", *ind - transBase);

			if ( i < codeGen->machine->numStates-1 || j < numIndex-1 ) {
				out << ", ";

				/* Put in a line break every 8, but only if
				 * not the last index. */
				if ( totalTrans % 8 == 7 )
					out << "\n\t";
			} 

			/* update the number of trans output. */
			totalTrans += 1;
		}
	}
}

void tab_INDEX_TYPE( FsmCodeGen *codeGen, ostream &out )
{
	if ( codeGen->machine->numTrans <= 256 )
		out << "unsigned char";
	else if ( codeGen->machine->numTrans <= 256*256 )
		out << "unsigned short";
	else 
		out << "unsigned int";
}


void tab_TRANSITIONS( FsmCodeGen *codeGen, ostream &out )
{
	out << '\t';
	FsmMachTrans<int> *trans = codeGen->machine->allTrans;
	for ( int i = 0; i < codeGen->machine->numTrans; i++, trans++ ) {
		if ( trans->toState == 0 )
			out << "{0, ";
		else
			out.form( "{s+%i, ", trans->toState - codeGen->machine->allStates );

		if ( trans->funcs != 0 )
			out.form( "f+%i}", trans->funcs - codeGen->machine->allTransFuncs );
		else
			out << "0}";

		if ( i < codeGen->machine->numTrans-1 ) {
			out << ", ";

			/* Put in a break every 4, but only if not the last. */
			if ( i % 4 == 3 )
				out << "\n\t";
		}
	}
}


void tab_START_STATE_OFFSET( FsmCodeGen *codeGen, ostream &out )
{
	out << (codeGen->machine->startState - codeGen->machine->allStates);
};

void tab_GBL_LOW_INDEX( FsmCodeGen *codeGen, ostream &out )
{
	out << codeGen->machine->gblLowIndex;
};

void tab_GBL_HIGH_INDEX( FsmCodeGen *codeGen, ostream &out )
{
	out << codeGen->machine->gblHighIndex;
};


/* Registers all the section names and inits the code and data pointers. */
CTabCodeGen::CTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData ) : TabCodeGen(fsmName, machine, parseData)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CTabCodeGen::header[] = 
"
/* User specified function. */
typedef int @FSMNAME@Func;

/* Forward dec state for the transition structure. */
struct @FSMNAME@StateStruct;

/* A single transition. */
struct @FSMNAME@TransStruct
{
	struct @FSMNAME@StateStruct *toState;
	@FSMNAME@Func *funcs;
};
typedef struct @FSMNAME@TransStruct @FSMNAME@Trans;

/* A single state. */
struct @FSMNAME@StateStruct
{
	int lowIndex;
	int highIndex;
	@INDEX_TYPE@ *transIndex;
	@INDEX_TYPE@ errIndex;
	@FSMNAME@Func *outFuncs;
	int isFinState;
};
typedef struct @FSMNAME@StateStruct @FSMNAME@State;

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	@FSMNAME@State *curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int len );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CTabCodeGen::code[] = "

#define f @FSMNAME@_f
#define s @FSMNAME@_s
#define i @FSMNAME@_i
#define t @FSMNAME@_t

static @FSMNAME@Func @FSMNAME@_f[];
static @FSMNAME@State @FSMNAME@_s[];
static @INDEX_TYPE@ @FSMNAME@_i[];
static @FSMNAME@Trans @FSMNAME@_t[];


/* The array of functions. */
static @FSMNAME@Func @FSMNAME@_f[] = {
@FUNCTIONS@
};

/* The aray of states. */
static @FSMNAME@State @FSMNAME@_s[] = {
@STATES@
};

/* The array of indicies into the transition array. */
static @INDEX_TYPE@ @FSMNAME@_i[] = {
@INDICIES@
};

/* The array of trainsitions. */
static @FSMNAME@Trans @FSMNAME@_t[] = {
@TRANSITIONS@
};

/* The start state. */
static @FSMNAME@State *@FSMNAME@_startState = s+@START_STATE_OFFSET@;
static @FSMNAME@Trans *@FSMNAME@_errIndex = t;

/* Global low and high indicies. */
static int @FSMNAME@_gblLowIndex = @GBL_LOW_INDEX@;
static int @FSMNAME@_gblHighIndex = @GBL_HIGH_INDEX@;

#undef f
#undef s
#undef i
#undef t


/***************************************************************************
 * @FSMNAME@ExecFuncs
 *
 * Execute functions pointed to by funcs until the null function is found. 
 */
inline static void @FSMNAME@ExecFuncs( @FSMNAME@ *fsm, @FSMNAME@Func *funcs, int c )
{
	while ( *funcs != 0 ) {
		switch ( *funcs ) {
@FUNC_SWITCH@
		}
		funcs += 1;
	}
}

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}

/****************************************
 * @FSMNAME@Accept
 *
 * Did the fsm accept? 
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}


/**********************************************************************
 * @FSMNAME@Execute
 *
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int len )
{
	@FSMNAME@State *cs = fsm->curState;
	for ( ; len > 0; data++, len-- ) {
		int c = *(unsigned char*)data;
		@FSMNAME@Trans *trans;

		if ( cs == 0 )
			goto finished;

		if ( @FSMNAME@_gblLowIndex <= c && c < @FSMNAME@_gblHighIndex ) {
			/* If the character is within the index bounds then get the
			 * transition for it. If it is out of the transition bounds
			 * we will use the error transition. */
			if ( cs->lowIndex <= c && c < cs->highIndex ) {
				/* Use the index to look into the transition array. */
				trans = @FSMNAME@_t + cs->transIndex[c - cs->lowIndex];
			}
			else {
				/* Use the error index as the char is out of range. */
				trans = @FSMNAME@_t + cs->errIndex;
			}
		}
		else {
			trans = @FSMNAME@_errIndex;
		}

		@PRE_FUNC_LIST@

		/* If there are functions for this transition then execute them. */
		if ( trans->funcs != 0 )
			@FSMNAME@ExecFuncs( fsm, trans->funcs, c );

		@POST_FUNC_LIST@

		/* Move to the new state. */
		cs = trans->toState;
	}
finished:
	fsm->curState = cs;
}

/**********************************************************************
 * @FSMNAME@Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	@FSMNAME@State *cs = fsm->curState;
	if ( cs != 0 && cs->isFinState ) {
		/* If finishing in a final state then execute the
		 * out functions for it. (if any). */
		if ( cs->outFuncs != 0 )
			@FSMNAME@ExecFuncs( fsm, cs->outFuncs, -1 );
		fsm->accept = 1;
	}
	else {
		/* If we are not in a final state then this
		 * is an error. Move to the errror state. */
		fsm->curState = 0;
	}
}
";


/* Registers all the section names and inits the code and data pointers. */
CCTabCodeGen::CCTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData ) : TabCodeGen(fsmName, machine, parseData)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CCTabCodeGen::header[] = 
"

class @FSMNAME@
{
public:
	/* Function and index type. */
	typedef int Func;

	/* Forward dec state for the transition structure. */
	struct State;

	/* A single transition. */
	struct Trans
	{
		State *toState;
		Func *funcs;
	};

	/* A single state. */
	struct State
	{
		int lowIndex;
		int highIndex;
		@INDEX_TYPE@ *transIndex;
		@INDEX_TYPE@ errIndex;
		Func *outFuncs;
		int isFinState;
	};

	/* Constructor. */
	@FSMNAME@();

	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int len );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	State *curState;
	int accept;

	inline void ExecFuncs( Func *funcs, int c );

	static Func f[];
	static State s[];
	static @INDEX_TYPE@ i[];
	static Trans t[];

	/* The start state. */
	static State *startState;
	static Trans *errIndex;

	static int gblLowIndex;
	static int gblHighIndex;


	@STRUCT_DATA@
};


";

char CCTabCodeGen::code[] = "


/* The array of functions. */
@FSMNAME@::Func @FSMNAME@::f[] = {
@FUNCTIONS@
};

/* The aray of states. */
@FSMNAME@::State @FSMNAME@::s[] = {
@STATES@
};

/* The array of indicies into the transition array. */
@INDEX_TYPE@ @FSMNAME@::i[] = {
@INDICIES@
};

/* The array of trainsitions. */
@FSMNAME@::Trans @FSMNAME@::t[] = {
@TRANSITIONS@
};

/* The start state. */
@FSMNAME@::State *@FSMNAME@::startState = s+@START_STATE_OFFSET@;
@FSMNAME@::Trans *@FSMNAME@::errIndex = t;


/* Global low and high indicies. */
int @FSMNAME@::gblLowIndex = @GBL_LOW_INDEX@;
int @FSMNAME@::gblHighIndex = @GBL_HIGH_INDEX@;



/***************************************************************************
 * Execute functions pointed to by funcs until the null function is found. 
 */
inline void @FSMNAME@::ExecFuncs( Func *funcs, int c )
{
	while ( *funcs != 0 ) {
		switch ( *funcs ) {
@FUNC_SWITCH@
		}
		funcs += 1;
	}
}


/****************************************
 * Constructor
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@::Init( )
{
	curState = startState;
	accept = 0;
	@INIT_CODE@
}

/****************************************
 * Did the fsm accept? 
 */
int @FSMNAME@::Accept( )
{
	return accept;
}



/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int len )
{
	State *cs = curState;
	for ( ; len > 0; data++, len-- ) {
		int c = *(unsigned char*)data;
		Trans *trans;

		if ( cs == 0 )
			goto finished;

		if ( gblLowIndex <= c && c < gblHighIndex ) {
			/* If the character is within the index bounds then get the
			 * transition for it. If it is out of the transition bounds
			 * we will use the error transition. */
			if ( cs->lowIndex <= c && c < cs->highIndex ) {
				/* Use the index to look into the transition array. */
				trans = t + cs->transIndex[c - cs->lowIndex];
			}
			else {
				/* Use the error index as the char is out of range. */
				trans = t + cs->errIndex;
			}
		}
		else {
			trans = errIndex;
		}

		@PRE_FUNC_LIST@

		/* If there are functions for this transition then execute them. */
		if ( trans->funcs != 0 )
			ExecFuncs( trans->funcs, c );

		@POST_FUNC_LIST@

		/* Move to the new state. */
		cs = trans->toState;
	}
finished:
	curState = cs;
}


/**********************************************************************
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	State *cs = curState;
	if ( cs != 0 && cs->isFinState ) {
		/* If finishing in a final state then execute the
		 * out functions for it. (if any). */
		if ( cs->outFuncs != 0 )
			ExecFuncs( cs->outFuncs, -1 );
		accept = 1;
	}
	else {
		/* If we are not in a final state then this
		 * is an error. Move to the errror state. */
		curState = 0;
	}
}

";


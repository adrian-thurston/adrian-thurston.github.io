/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <fstream>

#include "support.h"
#include "rl.h"
#include "parsetree.h"
#include "paramcheck.h"
#include "fsm.h"
#include "selcodegen.h"
#include "tabcodegen.h"
#include "ftabcodegen.h"
#include "vector.h"

/* Io globals. */
ofstream *outputStream = 0;
char *inputFile = 0;
char *outputFile = 0;

/* Print stats? Dump the final fsm? */
bool printStats = false;
bool dumpFinal = false;

/* Controls condensing. */
CondenseLevel condenseLevel = CondenseNone;
bool condenseEveryOp = false;

enum CodeGenerationEnum {
	C_Code,
	CC_Code
} codeGeneration = C_Code;
char *defExtension = ".c";

enum CodeStyleEnum {
	GenTables,
	GenSwitch,
	GenFTables
} codeStyle = GenTables;
	

/**********************************************************
 * Usage
 *
 * Print a summary of the options.
 */
void Usage()
{
	cout <<
"usage: ragel [options] file\n"
"options:\n"
"   -h, -H, -?   Disply this usage.\n"
"   -o <file>    Write output to <file>.\n"
"   -s           Print stats on the compiled fsm.\n"
"   -f           Dump the final fsm.\n"
"\n"
"   -e           Condense fsms after every operation.\n"
"   -n           No condensing (default).\n"
"   -a           Use approximate condensing algorithm. Is the fastest\n"
"                condensing and is suitable for most cases.\n"
"   -b           Use standard condensing algorthm. Costly algorithm that\n"
"                guarantees the most condense fsm possible.\n"
"   -1           Use experimental optimized condensing algorithm one. May\n"
"                produce incorrect fsm.\n"
"   -2           Use experimental optimized condensing algorithm two. May\n"
"                produce incorrect fsm.\n"
"\n"
"   -c           Generate c code (default).\n"
"   -C           Generate c++ code.\n"
"\n"
"   -t           Generate a table driven fsm (default).\n"
"   -y           Generate a table driven fsm with switch statement driven\n"
"                functions.\n"
"   -w           Generate a switch statement driven fsm.\n"
	;	
}

/*********************************************************************
 * FindFileExtension
 *
 * Scans a string looking for the file extension. If there is a file
 * extension then pointer returned points to inside the the string
 * passed in. Otherwise returns null.
 */
char *FindFileExtension( char *stemFile )
{
	char *ppos = stemFile + strlen(stemFile) - 1;
	/* Scan backwards from the end looking for the first dot.
	 * If we encounter a '/' before the first dot, then stop the scan. */
	while ( 1 ) {
		/* If we found a dot or got to the beginning of the string then
		 * we are done. */
		if ( ppos == stemFile || *ppos == '.' )
			break;

		/* If we hit a / then there is no extension. Done. */
		if ( *ppos == '/' ) {
			ppos = stemFile;
			break;
		}
		ppos--;
	} 

	/* If we got to the front of the string then bail we 
	 * did not find an extension  */
	if ( ppos == stemFile )
		ppos = 0;

	return ppos;
}

/*********************************************************************
 * FileNameFromStem
 *
 * Make a file name from a stem. Removes the old filename suffix and
 * replaces it with a new one. Returns a newed up string. 
 */
char *FileNameFromStem( char *stemFile, char *suffix )
{
	int len = strlen( stemFile );
	ASSERT( len > 0 );

	/* Get the extension. */
	char *ppos = FindFileExtension( stemFile );

	/* If an extension was found, then shorten what we think the len is. */
	if ( ppos != 0 )
		len = ppos - stemFile;

	/* Make the return string from the stem and the suffix. */
	char *retVal = new char[ len + strlen( suffix ) + 1 ];
	strncpy( retVal, stemFile, len );
	strcpy( retVal + len, suffix );

	return retVal;
}


/*****************************************************
 * CountTransitions
 *
 * Count the transitions in the fsm by walking the state list.
 */
int CountTransitions( Fsm *fsm )
{
	int numTrans = 0;
	State *state = fsm->Head;
	while ( state != NULL ) {
		numTrans += state->OutList.TableLength;
		state = state->Next;
	}
	return numTrans;
}

/* Move up a transition index and count the number of transistions that are
 * identical to the given trans. */
int CountIdenTransUp( FsmMachTrans<int> **sindex, int max, FsmMachTrans<int> *modelTrans )
{
	FsmMachTrans<int> **trans = sindex;
	int counted = 0;
	/* Stop when we see a differing trans or if we have counted the max. */
	while ( *trans == modelTrans && counted < max ) {
		trans += 1;
		counted += 1;
	}
	return counted;
}

/* Move down a transition index and count the number of transistions that are
 * identical to the given trans */
int CountIdenTransDown( FsmMachTrans<int> **sindex, int max, FsmMachTrans<int> *modelTrans )
{
	FsmMachTrans<int> **trans = sindex;
	int counted = 0;
	/* Stop when we see a differeing trans or if we have counted the max. */
	while ( *trans == modelTrans && counted < max ) {
		trans -= 1;
		counted += 1;
	}
	return counted;
}

/* Low and high indexes go right to both ends and the transitions are 
 * the same. We can save space by using the transition that is on both
 * endpoints as the error transition. */
void ChopIdenticalEnds( FsmMachine<int> *machine, FsmMachState<int> *state )
{
	/* Now we chop down the left and the right. */
	FsmMachTrans<int> *trans = state->transIndex[machine->gblLowIndex];

	int lowChop = CountIdenTransUp( state->transIndex, state->numIndex, trans );
	int highChop = CountIdenTransDown( state->transIndex+state->numIndex-1,
			state->numIndex, trans );

	/* Set the error index to the end transition. */
	state->errIndex = trans;

	/* If either lowChop or highChop is the number of indicies then all the 
	 * transitions are the same. We don't need any transition index, all trans 
	 * use the errIndex. */
	if ( lowChop == state->numIndex || highChop == state->numIndex ) {
		/* If one hits the max the other must as well. */
		ASSERT( lowChop == highChop );

		state->lowIndex = 0;
		state->highIndex = 0;
		state->numIndex = 0;
		delete[] state->transIndex;
		state->transIndex = 0;
	}
	else {
		/* Recompute low and high index. */
		state->lowIndex += lowChop;
		state->highIndex -= highChop;
		state->numIndex -= lowChop + highChop;

		FsmMachTrans<int> **oldIndex = state->transIndex;
		state->transIndex = new FsmMachTrans<int>*[state->numIndex];
		memcpy( state->transIndex, oldIndex + lowChop, 
				sizeof(FsmMachTrans<int>*)*state->numIndex );
		delete[] oldIndex;
	}
}


/* Because in ragel the alphabet is in the range gblLowIndex to gblHighIndex
 * we can reduce the size of the index table by having an err trans index
 * for each state. If the char is out of the lowIndex and highIndex range
 * then we consult the err trans for the state. This will save space on
 * states where there is say one or two special case transitions and the
 * remainder are some other default transition. Then we do not need to
 * store the transitions on the low and high end.  SetErrorStates finds
 * the optimal use of an error state in order to use as little transition
 * indicies as possible.
 */
void SetErrorStates( FsmMachine<int> *machine )
{
	for ( int i = 0; i < machine->numStates; i++ ) {
		FsmMachState<int> *state = machine->allStates+i;

		/* Skip out on states with no transitions. */
		if ( state->numIndex == 0 )
			continue;

		if ( state->lowIndex == machine->gblLowIndex 
				&& state->highIndex == machine->gblHighIndex ) {
			/* If low and high are the same then use it as error. We can compare
			 * the pointers here because at this point, there are no two trans
			 * with the same values inside. */
			if ( state->transIndex[machine->gblLowIndex] == 
					state->transIndex[machine->gblHighIndex-1] )
				ChopIdenticalEnds( machine, state );
			/* else, find longest stretch on low and longest stretch on
			 * high and use the longest as the error trans */
		}
		#if 0
		case lowIndex == 0 && highIndex <  256
			/* find longest stretch of identical trans from low end
			 * is it less then the hight end? if so we can improve. */
		case lowIndex >  0 && highIndex == 256
			/* find longest stretch of identical trans from high end
			 * is it less then the low end? if so we can improve. */
			
		case lowIndex >  0 && highIndex <  256
			/* Can't do anyting. */
		#endif
	}
}

void GlobFunctions( FsmMachine<int> *machine )
{
	/* Only to be done if the machine has functions. */
	if ( machine->numTransFuncs == 0 )
		return;

	/* Make a map of function calls to their globbed indicies. */
	int *globMap = new int[machine->numTransFuncs];
	memset( globMap, 0, sizeof(int)*machine->numTransFuncs );

	int globIndex = 1, funcIndex = 0;
	/* Loop over all funcs. */
	while ( funcIndex < machine->numTransFuncs ) {
		/* 	We are at the start of a glob, set the glob index. */
		globMap[funcIndex] = globIndex;

		/* Skip over the function list to the start of the next glob. */
		while ( machine->allTransFuncs[funcIndex] != 0 )
			funcIndex++;
		funcIndex++; /* Skip the null terminator. */

		/* Next glob. */
		globIndex++;
	}

	/* Now walk the transition list and the state list replacing all function
	 * indicies with their glob index counterpart. */
	for ( int trans = 0; trans < machine->numTrans; trans++ ) {
		int *funcs = machine->allTrans[trans].funcs;
		if ( funcs != 0 ) {
			machine->allTrans[trans].funcs = 
				(int*) globMap[funcs - machine->allTransFuncs];
		}
	}
	for ( int state = 0; state < machine->numStates; state ++ ) {
		int *funcs = machine->allStates[state].outFuncs;
		if ( funcs != 0 ) {
			machine->allStates[state].outFuncs = 
				(int*) globMap[funcs - machine->allTransFuncs];
		}
	}
	delete[] globMap;
}


/**************************************************************
 * Generate the code for a fsm. Assumes parseData is set up
 * properly. Called by parser code.
 */
void GenerateFsm( char *fsmName, ParseData *parseData )
{
	/* The machine that will take the compressed fsm. */
	FsmMachine<int> fsmMachine;

	/* Make a code generator that will output the header/code. */
	FsmCodeGen *codeGen;
	switch ( codeGeneration ) {
	case C_Code:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CTabCodeGen( fsmName, &fsmMachine, parseData );
			break;
		case GenSwitch:
			codeGen = new CSelCodeGen( fsmName, &fsmMachine, parseData );
			break;
		case GenFTables:
			codeGen = new CFTabCodeGen( fsmName, &fsmMachine, parseData );
			break;
		}
		break;
	case CC_Code:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CCTabCodeGen( fsmName, &fsmMachine, parseData );
			break;
		case GenSwitch:
			codeGen = new CCSelCodeGen( fsmName, &fsmMachine, parseData );
			break;
		case GenFTables:
			codeGen = new CCFTabCodeGen( fsmName, &fsmMachine, parseData );
			break;
		}
		break;
	}

	/* If the struct element was used then output the header portion. */
	if ( parseData->dataList.ListLength > 0 ) {
		codeGen->WriteOutHeader( *outputStream );
	}

	/* If the graph dict is given, then output the code portion. */
	if ( parseData->machineGiven ) {
		/* Get the main line from the graph dict. */
		GraphDictNode *gdNode = parseData->graphDict.Find("main");
		if ( gdNode == NULL ) {
			fprintf( stderr, "main graph not defined\n" );
			exit(1);
		}

		Fsm *graph = gdNode->Value->Walk();

		/* We need to condense here only if we are not condensing every op. */
		if ( ! condenseEveryOp ) {
			switch ( condenseLevel ) {
				case CondenseNone:
					break;
				case CondenseApprox:
					graph->CondenseApproximate();
					break;
				case CondenseStable:
					graph->CondenseStable();
					break;
				case CondenseOptimized1:
					graph->CondenseOptimized1();
					break;
				case CondenseOptimized2:
					ASSERTNOTREACHED();
					break;
			}
		}

		if ( dumpFinal )
			DumpGraph( cout, graph );

		if ( printStats ) {
			cout << "graph states:        " << graph->ListLength << endl;
			cout << "graph transitions:   " << CountTransitions( graph ) << endl;
		}

		/* Build the machine from the graph and output it. */
		graph->BuildFsmMachine( fsmMachine );

		if ( printStats ) {
			cout << "machine states:      " << fsmMachine.numStates << endl;
			cout << "machine transitions: " << fsmMachine.numTrans << endl;
			cout << "machine indicies:    " << fsmMachine.NumIndicies() << endl;
		}

		/* Further compress the runnable machine. This kind of compression
		 * makes it more work to write out a switch style fsm. */
		if ( codeStyle != GenSwitch )
			SetErrorStates( &fsmMachine );

		/* If we are making the func swith version of the tables we need to
		 * glob function calls. */
		if ( codeStyle == GenFTables )
			GlobFunctions( &fsmMachine );

		if ( printStats ) {
			cout << "compressed indicies: " << fsmMachine.NumIndicies() << endl;
		}

		codeGen->WriteOutCode( *outputStream );
	}
}

int main(int argc, char **argv)
{
	/* Paramater specification. */
	ParameterCheck pc("ytwCco:senab12fhH?-:", argc, argv);
	char *ext;

	while ( pc.Check() ) {
		switch ( pc.state ) {
		case ParameterCheck::match:
			switch ( pc.parameter ) {
			case 'o':
				if ( *pc.parameterArg == 0 ) {
					/* Complain, someone used -o "" */
					cerr << PROGNAME ": zero length output file name given" << endl;
					goto ErrNoCleanUp;
				}
				else if ( outputFile != 0 ) {
					/* Complain, two output files given. */
					cerr << PROGNAME ": output file already given" << endl;
				}
				else {
					/* Ok, remember the output file name. */
					outputFile = pc.parameterArg;
				}
				break;
			case 's':
				printStats = true;
				break;
			case 'e':
				condenseEveryOp = true;
				break;
			case 'n':
				condenseLevel = CondenseNone;
				break;
			case 'a':
				condenseLevel = CondenseApprox;
				break;
			case 'b':
				condenseLevel = CondenseStable;
				break;
			case '1':
				condenseLevel = CondenseOptimized1;
				break;
			case '2':
				condenseLevel = CondenseOptimized2;
				break;
			case 'f':
				dumpFinal = true;
				break;
			case 'c':
				codeGeneration = C_Code;
				defExtension = ".c";
				break;
			case 'C':
				codeGeneration = CC_Code;
				defExtension = ".cc";
				break;
			case 't':
				codeStyle = GenTables;
				break;
			case 'w':
				codeStyle = GenSwitch;
				break;
			case 'y':
				codeStyle = GenFTables;
				break;
			case 'H': case 'h': case '?':
				Usage();
				exit(0);
			case '-':
				if ( strcasecmp(pc.parameterArg, "help") == 0 ) {
					Usage();
					exit(0);
				}
				else {
					/* Print usage and die on invalid param. */
					fprintf( stderr, "invalid param specified\n" );
					goto ErrNoCleanUp;
				}
			}
			break;

		case ParameterCheck::invalid:
			/* Print usage and die on invalid param. */
			fprintf( stderr, "invalid param specified\n" );
			goto ErrNoCleanUp;

		case ParameterCheck::noparam:
			/* It is interpreted as an input file. */
			if ( *pc.curArg == 0 ) {
				cerr << PROGNAME ": zero length input file name given" << endl;
				goto ErrNoCleanUp;
			}
			if ( inputFile != 0 ) {
				cerr << PROGNAME ": input file already given" << endl;
				goto ErrNoCleanUp;
			}
			/* Remember the filename. */
			inputFile = pc.curArg;
			break;
		}
	}

	/* If the user wants condense optimal2 then condense every op
	 * must also be specified */
	if ( condenseLevel == CondenseOptimized2 && ! condenseEveryOp ) {
		fprintf( stderr, "warning: condensing at optimal level 2 implies -e\n");
		condenseEveryOp = true;
	}

	/* Look for no input file specified. */
	if ( inputFile == 0 ) {
		cerr << PROGNAME ": no input file" << endl;
		goto ErrNoCleanUp;
	}

	/* If no output file name is given, then we must make one. */
	if ( outputFile == NULL ) {
		ext = FindFileExtension( inputFile );
		if ( ext != NULL && strcmp( ext, ".rh" ) == 0 )
			outputFile = FileNameFromStem( inputFile, ".h" );
		else 
			outputFile = FileNameFromStem( inputFile, defExtension );
	}

	/* Make sure we are not writing to the same file as the input file. */
	if ( strcmp( inputFile, outputFile  ) == 0 ) {
		cerr << PROGNAME ":output file \"" << outputFile  << 
				"\" is the same as the input file \"" << inputFile << "\"" << endl;
		goto ErrNoCleanUp;
	}

	/* Open the input file for reading. */
	rlin = fopen( inputFile, "rt" );
	if ( rlin == NULL ) {
		fprintf( stderr, "could not open %s for reading\n", inputFile );
		exit(1);
	}

	/* Open the output file stream now. Use c++ style streams
	 * as that is what the FsmCodeWriteOut code uses. */
	outputStream = new ofstream( outputFile );
	if ( outputStream->bad() ) {
		fprintf( stderr, "error opening %s for writing\n", outputFile );
		exit(1);
	}

	/* Put a header on the output to indicate that the file was machine generated. */
	*outputStream << FsmCodeGen::outputHeader;

	/* Parse the input! */
	rlparse();

	/* Finished. */
	return 0;

ErrNoCleanUp:
	return -1;
}


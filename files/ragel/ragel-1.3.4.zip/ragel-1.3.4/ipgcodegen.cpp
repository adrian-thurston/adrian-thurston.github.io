/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "ipgcodegen.h"
#include "bstmap.h"

/* Inits the code and data pointers. There are no code generation 
 * functions to register. */
IpGotoCodeGen::IpGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	GotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void IpGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	int *funcs = machine->allTransFuncs + 
			machine->transFuncIndex[state->outFuncs];

	/* The first number is the length. */
	int flen = *funcs++;
	while ( flen-- > 0 ) {
		out << "{" << getCodeBuiltin(*funcs) << "}";
		funcs += 1;
	}
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void IpGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* Get the funcs. */
	int *funcs = machine->allTransFuncs + 
			machine->transFuncIndex[trans->funcs];

	/* The first number is the length. */
	int flen = *funcs++;
	while ( flen-- > 0 ) {
		out << "\t{" << getCodeBuiltin(*funcs) << "}\n";
		funcs += 1;
	}
}

/* Init base data. */
CIpGotoCodeGen::CIpGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	IpGotoCodeGen(fsmName, machine, parseData, out)
{
}


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CIpGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}

void CIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"#define alph unsigned char\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	register char *p = data-1;\n"
		"	register int len = dlen+1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( "; FSM_PREFIX() << "curState ) {\n";
		JUMP_IN_SWITCH() << "\n"
		"	}\n";
		STATE_GOTOS() << "\n";
		EXIT_STATES() << "\n";
		ERROR_LABEL() << "\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int cs = fsm->curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	fsm->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n"
		"#undef alph\n";
}

/* Init base data. */
CCIpGotoCodeGen::CCIpGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	IpGotoCodeGen(fsmName, machine, parseData, out)
{
}


/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCIpGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( char *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"\n"
		"	/* The start state. */\n"
		"	static int startState;\n"
		"};\n"
		"\n";
}

void CCIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Make sure the machine is initialized. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = startState;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"\n"
		"#define alph unsigned char\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( char *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	register char *p = data-1;\n"
		"	register int len = dlen+1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( curState ) {\n";
		JUMP_IN_SWITCH() << "\n"
		"	}\n";
		STATE_GOTOS() << "\n";
		EXIT_STATES() << "\n";
		ERROR_LABEL() << "\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int cs = curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	this->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n"
		"#undef alph\n"
		"\n";
}

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmcodegen.h"
#include "rl.h"

/* Init code gen with in parameters. */
FsmCodeGen::FsmCodeGen( char *fsmName, FsmMachine *machine,
		ParseData *parseData, ostream &out ) :
	fsmName(fsmName), 
	machine(machine),
	parseData(parseData), 
	out(out)
{
}

/* Given a func index get the string version of the func that will
 * go to the output. Assumes the functions are indexed starting at 0. */
char *FsmCodeGen::getCodeBuiltin(int index)
{
	if ( 0 <= index && index < parseData->funcList.length ) {
		/* Walk the list of functions, to find the given index. */
		StringListEl *flel = parseData->funcList.head;
		for ( int fnum = 0; fnum < index; fnum++ )
			flel = flel->next;
		return flel->data;
	}
	return NULL;
}

/* Are there any indicies in use? If a machine has no indicies then it has no
 * transitions and isn't really of much use. This should return true most of
 * the time. */
bool FsmCodeGen::anyIndicies()
{
	bool indiciesFound = false;
	FsmMachState *pSt = machine->allStates;
	for ( int st = 0; st < machine->numStates; st++, pSt++ ) {
		if ( pSt->numIndex > 0 ) {
			indiciesFound = true;
			break;
		}
	}
	return indiciesFound;
}

/* Does the machine have any functions. */
bool FsmCodeGen::anyTransFuncs()
{
	return machine->numTransFuncs > 0;
}


/* Write out the fsm name. */
std::ostream &FsmCodeGen::FSM_NAME()
{
	out << fsmName;
	return out;
}

std::ostream &FsmCodeGen::STRUCT_DATA()
{
	/* Walk the list of data, printing the cases. */
	StringListEl *del = parseData->dataList.head;
	while ( del != NULL ) {
		out << del->data;
		del = del->next;
	}
	return out;
}

std::ostream &FsmCodeGen::INIT_CODE()
{
	/* Walk the list of pre funcs, printing the sections. */
	StringListEl *del = parseData->initCodeList.head;
	while ( del != NULL ) {
		out << "{ " << del->data << " }\n";
		del = del->next;
	}
	return out;
}

/* Emit the offset of the start state as a decimal integer. */
std::ostream &FsmCodeGen::START_STATE_OFFSET()
{
	out << machine->startState;
	return out;
};


/* Write out the array of all functions including the lengths of each
 * function vector. */
std::ostream &FsmCodeGen::FUNCTIONS()
{
	int totalFunc = 0;
	out << '\t';
	for ( int fnum = 0; fnum < machine->numTransFuncs; fnum++ ) {
		int func = machine->allTransFuncs[fnum];
		out << func;

		/* If we are not in the last func, then write out a comma 
		 * and possibly a line break. */
		if ( fnum < machine->numTransFuncs-1 ) {
			out << ", ";

			/* Put in a line break every 8 */
			if ( totalFunc % 8 == 7 )
				out << "\n\t";
		} 
		totalFunc += 1;
	}
	return out;
}

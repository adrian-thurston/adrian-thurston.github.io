/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMSTATE_CPP
#define _RLFSM_FSMSTATE_CPP

#include <string.h>
#include <assert.h>

/* Return and re-entry for the co-routine iterators. This should ALWAYS be
 * used inside of a block. */
#define CO_RETURN(label) \
	itState = label; \
	return; \
	entry##label: backIn = true

/* Return and re-entry for the co-routine iterators. This should ALWAYS be
 * used inside of a block. */
#define CO_RETURN2(label, uState) \
	itState = label; \
	userState = uState; \
	return; \
	entry##label: backIn = true

/* Construct a mark index for a specified number of states. Must new up
 * an array that is states^2 in size. */
template < class State > MarkIndex<State>::
		MarkIndex( int states ) : numStates(states)
{
	/* Total pairs is states^2. Actually only use half of these, but we allocate
	 * them all to make indexing into the array easier. */
	int total = states * states;

	/* New up chars so that individual DListEl constructors are
	 * not called. Zero out the mem manually. */
	array = new bool[total];
	memset( array, 0, sizeof(bool) * total );
}

/* Free the array used to store state pairs. */
template < class State >MarkIndex<State>::~MarkIndex()
{
	delete[] array;
}

/* Mark a pair of states. States are specified by their number. The
 * marked states are moved from the unmarked list to the marked list. */
template < class State > void MarkIndex<State>::
		markPair(int state1, int state2)
{
	int pos = ( state1 >= state2 ) ?
		( state1 * numStates ) + state2 :
		( state2 * numStates ) + state1;

	array[pos] = true;
}

/* Returns true if the pair of states are marked. Returns false otherwise.
 * Ordering of states given does not matter. */
template < class State > bool MarkIndex<State>::
		isPairMarked(int state1, int state2)
{
	int pos = ( state1 >= state2 ) ?
		( state1 * numStates ) + state2 :
		( state2 * numStates ) + state1;

	return array[pos];
}

/*
 * Callbacks.
 */

/* Add in another transition into this transition. */
template < class State, class Transition >
		void FsmTrans<State, Transition>::
		addInTrans( Transition *srcTrans )
{
}

/* Add in the out data of a state into a transition. */
template < class State, class Transition >
		void FsmTrans<State, Transition>::
		leavingFromState( State *srcState )
{
}

/* Compare two transitions according to their relative priority. Since the
 * base transition has no priority associated with it, the default is to
 * return equal. */
template < class State, class Transition >
		int FsmTrans<State, Transition>::
		comparePrior( Transition *trans1, Transition *trans2 )
{
	return 0;
}

/* Compare two transitions accroding to the data contained in the transition.
 * Since the base transition has no data, the default is to return equal. */
template < class State, class Transition >
		int FsmTrans<State, Transition>::
		compareTransData( Transition *trans1, Transition *trans2 )
{
	return 0;
}

/*
 * Transition comparison.
 */

/* Compare target partitions. Either pointer may be null. */
template < class State, class Transition >
		int FsmTrans<State, Transition>::
		comparePartPtr( Transition *trans1, Transition *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. If either are set then both
		 * should be set. The initial partitioning should guarantee this for
		 * us. So this case should never happen. */
		assert( false );
	}
	else if ( trans1 != 0 ) {
		/* Both of transitions are set. */
		return CmpOrd< MinPartition<State>* >::compare( 
				trans1->toState->alg.partition, trans2->toState->alg.partition );
	}
	return 0;
}


/* Compares two transition pointers according to priority and functions.
 * Either pointer may be null. Does not consider to state or from state. */
template < class State, class Transition >
		int FsmTrans<State, Transition>::
		compareDataPtr( Transition *trans1, Transition *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. */
		if ( trans1 != 0 )
			return -1;
		else
			return 1;
	}
	else if ( trans1 != 0 ) {
		/* Both of the transition pointers are set. */
		int compareRes = Transition::compareTransData( trans1, trans2 );
		if ( compareRes != 0 )
			return compareRes;
	}

	/* Neither of the transitions are set. */
	return 0;
}

/* Compares two transitions according to target state, priority and functions.
 * Does not consider from state. Either of the pointers may be null. */
template < class State, class Transition >
		int FsmTrans<State, Transition>::
		compareFullPtr( Transition *trans1, Transition *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. */
		if ( trans1 != 0 )
			return -1;
		else
			return 1;
	}
	else if ( trans1 != 0 ) {
		/* Both of the transition pointers are set. Test target state,
		 * priority and funcs. */
		if ( trans1->toState < trans2->toState )
			return -1;
		else if ( trans1->toState > trans2->toState )
			return 1;
		else {
			/* Test transition data. */
			int compareRes = Transition::compareTransData( trans1, trans2 );
			if ( compareRes != 0 )
				return compareRes;
		}
	}

	/* Neither of the transition pointers are set. */
	return 0;
}


template < class State, class Transition >
		bool FsmTrans<State, Transition>::
		shouldMarkPtr( MarkIndex<State> &markIndex, FsmTrans *trans1, FsmTrans *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. The initial mark round
		 * should rule out this case. */
		assert( false );
	}
	else if ( trans1 != 0 ) {
		/* Both of the transitions are set. If the target pair is marked, then
		 * the pair we are considering gets marked. */
		return markIndex.isPairMarked( trans1->toState->alg.stateNum, 
				trans2->toState->alg.stateNum );
	}

	/* Neither of the transitiosn are set. */
	return false;
}

/* Given a transition key, find the range the key is in. If the key is in a range, 
 * returns a pointer to the lower end of the range. If the key is not in a range,
 * returns NULL. Implemented with a binary search. */
template< class Transition > BstMapEl<int, Transition*> *
		FsmTransList<Transition>::findRange( int onChar ) const
{
	TransEl *endPoint, *result;

	/* Can't succeed with an empty table. */
	if ( length == 0 )
		return 0;

	result = find( onChar, &endPoint );
	if ( result != 0 ) {
		/* The key was found, we are right on an endpoint of a range. If on the
		 * high end of a range, return the low end. */
		if ( (result - data) & 0x1 )
			result -= 1;
	}
	else {
		/* The key was not found. endPoint gives the place we would insert at to
		 * put the key in the table. If endPoint is the high end of a range, then
		 * key is in that range. */
        if ( (endPoint - data) & 0x1 )
			result = endPoint - 1;
	}
	return result;
}

/* Find a transition range given the lower end of the range. */
template< class Transition > BstMapEl<int, Transition*> *
		FsmTransList<Transition>::findLower( int onChar ) const
{
	/* Like a regular find, but we must handle the case that the upper and 
	 * and lower are identical and the binary search has returned the upper. */
	TransEl *tel = find( onChar );
	if ( tel != 0 ) {
		/* A result was found. */
		if ( (tel - data) & 0x1 ) {
			/* We got the high end. If the high == low, then return the low.
			 * Otherwise fail ( we are looking for the low end). */
			if ( tel[0].key == tel[-1].key )
				tel = tel - 1;
			else 
				tel = 0;
		}
	}
	return tel;
}


/* Create a new fsm state. State has not out transitions or in transitions,
 * not out out transition data and not number. */
template< class State, class Transition >
		FsmState<State, Transition>::FsmState()
:
	/* No out transitions. */
	outList(),
	outRange(),
	outDefault(0),

	/* No in transitions. */
	inListHead(0),
	inRangeHead(0),
	inDefHead(0),

	/* No entry points. */
	entryIds(),

	/* No transitions in from other states. */
	foreignInTrans(0),

	/* Only used during merging. Normally null. */
	stateDictNode(0),

	/* No state identification bits. */
	stateBits(0)
{
}

/* Copy everything except actual the transitions. That is left up to the
 * FsmGraph copy constructor. */
template< class State, class Transition >
		FsmState<State, Transition>::FsmState(const FsmState &other)
:
	/* Copy the out pointers directly. 
	 * The transitions will be duplicated later. */
	outList(other.outList),
	outRange(other.outRange),
	outDefault(other.outDefault),

	/* All in transitions are cleared. They will be filled in when the
	 * individual transitions are duplicated and attached. */
	inListHead(0),
	inRangeHead(0),
	inDefHead(0),

	/* Duplicate the entry id set. This is a set of integers 
	 * and as such needs no fixing. */
	entryIds(other.entryIds),

	/* No transitions in from other states. */
	foreignInTrans(0),

	/* This is only used during merging. Normally null. */
	stateDictNode(0),

	/* Fsm state data. */
	stateBits(other.stateBits)
{
}

/* If there is a state dict node, then delete it. Everything else is left
 * up the FsmGraph destructor. */
template< class State, class Transition >
		FsmState<State, Transition>::~FsmState()
{
	if ( stateDictNode != 0 )
		delete stateDictNode;
}

/*
 * Callbacks.
 */

/* Callback invoked when two states are made into one by the minimization
 * process. */
template< class State, class Transition >
		void FsmState<State, Transition>::
		fuseInState( State *otherState )
{
}

/* Callback invoked when otherState is added into this state during the
 * merging process. */
template< class State, class Transition >
		void FsmState<State, Transition>::
		addInState( State *srcState )
{
}

/* Callback invoked when a state looses its final state status. This is where
 * properties of final states get unset. At the point of invocation, it is
 * unspecified whether or not isFinState is set. */
template< class State, class Transition >
		void FsmState<State, Transition>::
		relinquishFinal( )
{
	/* Kill the out transitions. Reset the priority. */
	outTransFuncTable.empty();
	isOutPriorSet = false;
	outPriority = 0;
}


/* Compare the out transition data of two states. Compares out priorities and
 * out transitions. The base state has no data so always returns zero. */
template< class State, class Transition >
		int FsmState<State, Transition>::
		compareStateData( const State *state1, const State *state2 )
{
	return 0;
}

/* Compare two states using pointers to the states. With the approximate
 * compare the idea is that if the compare finds them the same, they can
 * immediately be merged. */
template< class State, class Transition >
		int ApproxCompare<State, Transition>::
		compare( const State *state1 , const State *state2 )
{
	int compareRes;

	/* Test final state status. */
	if ( (state1->stateBits & SB_ISFINAL) && !(state2->stateBits & SB_ISFINAL) )
		return -1;
	else if ( !(state1->stateBits & SB_ISFINAL) && (state2->stateBits & SB_ISFINAL) )
		return 1;
	
	/* Compare the out transitions. */
	compareRes = State::compareStateData( state1, state2 );
	if ( compareRes )
		return compareRes;

	/* Test default transitions. */
	compareRes = Transition::compareFullPtr( state1->outDefault, 
			state2->outDefault );
	if ( compareRes != 0 )
		return compareRes;

	/* Use a pair iterator to get the transition pairs. */
	PairIterator outPair(state1, state2, false);
	while ( ! outPair.atEnd() ) {
		switch ( outPair.userState ) {

		case PairIterator::TransInS1:
		case PairIterator::RangeInS1:
			compareRes = Transition::compareFullPtr( 
					outPair.s1Tel->value, outPair.defTrans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::TransInS2:
		case PairIterator::RangeInS2:
			compareRes = Transition::compareFullPtr( 
					outPair.defTrans, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::RangeOverlap:
		case PairIterator::TransOverlap:
			compareRes = Transition::compareFullPtr( 
					outPair.s1Tel->value, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::BreakS1:
		case PairIterator::BreakS2:
			break;
		}
		outPair++;
	}

	/* Got through the entire state comparison, deem them equal. */
	return 0;
}

/* Compare class for the sort that does the intial partition of compaction. */
template< class State, class Transition >
		int InitPartitionCompare<State, Transition>::
		compare( const State *state1 , const State *state2 )
{
	int compareRes;

	/* Test final state status. */
	if ( (state1->stateBits & SB_ISFINAL) && !(state2->stateBits & SB_ISFINAL) )
		return -1;
	else if ( !(state1->stateBits & SB_ISFINAL) && (state2->stateBits & SB_ISFINAL) )
		return 1;

	/* Compare the out transitions. */
	compareRes = State::compareStateData( state1, state2 );
	if ( compareRes != 0 )
		return compareRes;

	/* Test default transitions. */
	compareRes = Transition::compareDataPtr( state1->outDefault, 
			state2->outDefault );
	if ( compareRes != 0 )
		return compareRes;

	/* Use a pair iterator to get the transition pairs. */
	PairIterator outPair(state1, state2, false);
	while ( ! outPair.atEnd() ) {
		switch ( outPair.userState ) {

		case PairIterator::TransInS1:
		case PairIterator::RangeInS1:
			compareRes = Transition::compareDataPtr( 
					outPair.s1Tel->value, outPair.defTrans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::TransInS2:
		case PairIterator::RangeInS2:
			compareRes = Transition::compareDataPtr( 
					outPair.defTrans, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::RangeOverlap:
		case PairIterator::TransOverlap:
			compareRes = Transition::compareDataPtr( 
					outPair.s1Tel->value, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::BreakS1:
		case PairIterator::BreakS2:
			break;
		}
		outPair++;
	}

	return 0;
}

/* Compare class for the sort that does the partitioning. */
template< class State, class Transition >
		int PartitionCompare<State, Transition>::
		compare( const State *state1, const State *state2 )
{
	int compareRes;

	/* Test default transitions. */
	compareRes = Transition::comparePartPtr( state1->outDefault, state2->outDefault );
	if ( compareRes != 0 )
		return compareRes;

	/* Use a pair iterator to get the transition pairs. */
	PairIterator outPair(state1, state2, false);
	while ( ! outPair.atEnd() ) {
		switch ( outPair.userState ) {

		case PairIterator::TransInS1:
		case PairIterator::RangeInS1:
			compareRes = Transition::comparePartPtr( 
					outPair.s1Tel->value, outPair.defTrans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::TransInS2:
		case PairIterator::RangeInS2:
			compareRes = Transition::comparePartPtr( 
					outPair.defTrans, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::RangeOverlap:
		case PairIterator::TransOverlap:
			compareRes = Transition::comparePartPtr( 
					outPair.s1Tel->value, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIterator::BreakS1:
		case PairIterator::BreakS2:
			break;
		}
		outPair++;
	}

	return 0;
}

/* Compare class for the sort that does the partitioning. */
template< class State, class Transition > bool MarkCompare<State, Transition>::
		shouldMark( MarkIndex<State> &markIndex, const State *state1, 
			const State *state2 )
{
	/* Test default transitions. */
	if ( Transition::shouldMarkPtr( markIndex, state1->outDefault, 
			state2->outDefault ) )
		return true;

	/* Use a pair iterator to get the transition pairs. */
	PairIterator outPair(state1, state2, false);
	while ( ! outPair.atEnd() ) {
		switch ( outPair.userState ) {

		case PairIterator::TransInS1:
		case PairIterator::RangeInS1:
			if ( Transition::shouldMarkPtr( markIndex, 
					outPair.s1Tel->value, outPair.defTrans ) )
				return true;
			break;

		case PairIterator::TransInS2:
		case PairIterator::RangeInS2:
			if ( Transition::shouldMarkPtr( markIndex,
					outPair.defTrans, outPair.s2Tel->value ) )
				return true;
			break;

		case PairIterator::RangeOverlap:
		case PairIterator::TransOverlap:
			if ( Transition::shouldMarkPtr( markIndex,
					outPair.s1Tel->value, outPair.s2Tel->value ) )
				return true;
			break;

		case PairIterator::BreakS1:
		case PairIterator::BreakS2:
			break;
		}
		outPair++;
	}

	return false;
}


/** Init the iterator by advancing to the first item. */
template< class State, class Transition >
		FsmOutIterator<State, Transition>::FsmOutIterator( State *state )
:
	state(state),
	itState(Begin)
{
	findNext();
}

/** Is the iterator at the end? */
template< class State, class Transition >
		bool FsmOutIterator<State, Transition>::atEnd()
{
	return itState == End;
}

/** Postfix operator. Save result for return then increment. */
template< class State, class Transition >
		Transition *FsmOutIterator<State, Transition>::operator++(int)
{
	Transition *retVal = trans;
	findNext();
	return retVal;
}

/** Prefix operator. Icrement first, then return result. */
template< class State, class Transition >
		Transition *FsmOutIterator<State, Transition>::operator++()
{
	findNext();
	return trans;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case atEnd returns true. */
template< class State, class Transition >
		void FsmOutIterator<State, Transition>::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:     goto entryBegin;
		case Trans:     goto entryTrans;
		case Range:     goto entryRange;
		case Default:   goto entryDefault;
		case End:       goto entryEnd;
	}

	entryBegin:

	/* Loop over outList transitions. */
	transEl = state->outList.data;
	nTransEl = state->outList.length;
	for ( i = 0; i < nTransEl; i++, transEl++ ) {
		if ( transEl->value != 0 ) {
			/* Save the state of the iterator and return. */
			trans = transEl->value;
			CO_RETURN( Trans );
		}
	}

	/* Loop over outRange transitions. */
	transEl = state->outRange.data;
	nTransEl = state->outRange.length;
	for ( i = 0; i < nTransEl; i+=2, transEl+=2 ) {
		if ( transEl->value != 0 ) {
			/* Save the state of the iterator and return. */
			trans = transEl->value;
			CO_RETURN( Range );
		}
	}

	/* Process default transition. */
	if ( state->outDefault != 0 ) {
		/* Save the state of the iterator and return. */
		trans = state->outDefault;
		CO_RETURN( Default );
	}

	CO_RETURN( End );
}

/** Init the iterator by advancing to the first item. */
template< class State, class Transition >
		FsmInIterator<State, Transition>::FsmInIterator( State *state )
:
	state(state),
	itState(Begin)
{
	findNext();
}

/** Is the iterator at the end? */
template< class State, class Transition >
		bool FsmInIterator<State, Transition>::atEnd()
{
	return itState == End;
}

/** Postfix operator. Save result for return then increment. */
template< class State, class Transition >
		Transition *FsmInIterator<State, Transition>::operator++(int)
{
	Transition *retVal = trans;
	findNext();
	return retVal;
}

/** Prefix operator. Icrement first, then return result. */
template< class State, class Transition >
		Transition *FsmInIterator<State, Transition>::operator++()
{
	findNext();
	return trans;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case atEnd returns true. */
template< class State, class Transition >
		void FsmInIterator<State, Transition>::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:     goto entryBegin;
		case Trans:     goto entryTrans;
		case Range:     goto entryRange;
		case Default:   goto entryDefault;
		case End:       goto entryEnd;
	}

	entryBegin:

	/* Loop over inList transitions. */
	trans = state->inListHead;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Trans );

			/* Next transition. */
		trans = trans->next;
	}

	/* Loop over inRange transitions. */
	trans = state->inRangeHead;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Range );

		/* Next transition. */
		trans = trans->next;
	}

	/* Loop over the list of transitions at the default trans. */
	trans = state->inDefHead;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Default );

		/* Next transition. */
		trans = trans->next;
	}

	/* Done, go into end state. */
	CO_RETURN( End );
}

/** Init the iterator by advancing to the first item. */
template< class State, class Transition >
		FsmPairIterator<State, Transition>::
		FsmPairIterator( const State *state1, const State *state2, bool wantBreaks )
:
	state1(state1),
	state2(state2),
	itState(Begin),
	wantBreaks(wantBreaks)
{
	findNext();
}

/** Is the iterator at the end? */
template< class State, class Transition >
		bool FsmPairIterator<State, Transition>::atEnd()
{
	return itState == End;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case atEnd returns true. */
template< class State, class Transition >
		void FsmPairIterator<State, Transition>::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Temporary vars used for finding ranges and defaults. */
	TransEl *rangeTel;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:              goto entryBegin;
		case ConsumeS1Trans:     goto entryConsumeS1Trans;
		case ConsumeS2Trans:     goto entryConsumeS2Trans;
		case OnlyInS1Trans:      goto entryOnlyInS1Trans;
		case OnlyInS2Trans:      goto entryOnlyInS2Trans;
		case InBothTrans:        goto entryInBothTrans;
		case ConsumeS1Range:     goto entryConsumeS1Range;
		case ConsumeS2Range:     goto entryConsumeS2Range;
		case OnlyInS1Range:      goto entryOnlyInS1Range;
		case OnlyInS2Range:      goto entryOnlyInS2Range;
		case S1SticksOut:        goto entryS1SticksOut;
		case S1SticksOutBreak:   goto entryS1SticksOutBreak;
		case S2SticksOut:        goto entryS2SticksOut;
		case S2SticksOutBreak:   goto entryS2SticksOutBreak;
		case S1DragsBehind:      goto entryS1DragsBehind;
		case S1DragsBehindBreak: goto entryS1DragsBehindBreak;
		case S2DragsBehind:      goto entryS2DragsBehind;
		case S2DragsBehindBreak: goto entryS2DragsBehindBreak;
		case ExactOverlap:       goto entryExactOverlap;
		case End:                goto entryEnd;
	}

	entryBegin:

	/* Pointers used to walk through out lists concurrently. */
	s1Tel = state1->outList.data;
	s1EndTel = s1Tel + state1->outList.length;
	s2Tel = state2->outList.data;
	s2EndTel = s2Tel + state2->outList.length;

	/* Concurrently scan both out lists. */
	while ( true ) {
		if ( s1Tel == s1EndTel ) {
			/* We are at the end of state1's transitions. Process the rest of
			 * state2's transitions. */
			while ( s2Tel != s2EndTel ) {
				/* Find a transition to serve as the default. If s2Tel->Key is
				 * in a range in state1, use that range (which may be null),
				 * otherwise use state1->default. */
				rangeTel = state1->outRange.findRange( s2Tel->key );
				if ( rangeTel != 0 )
					defTrans = rangeTel->value;
				else
					defTrans = state1->outDefault;

				/* Trans is only in s2. */
				CO_RETURN2( ConsumeS2Trans, TransInS2 );

				s2Tel++;
			}
			break;
		}
		else if ( s2Tel == s2EndTel ) {
			/* We are at the end of state2's transitions. Process the rest of
			 * state1's transitions. */
			while ( s1Tel != s1EndTel ) {
				/* Find a transition to serve as the default. If s1Tel->key is
				 * in a range in state2, use that range (which may be null),
				 * otherwise use state2->default. */
				rangeTel = state2->outRange.findRange( s1Tel->key );
				if ( rangeTel != 0 )
					defTrans = rangeTel->value;
				else
					defTrans = state2->outDefault;

				/* Trans is only in s1. */
				CO_RETURN2( ConsumeS1Trans, TransInS1 );

				s1Tel++;
			}
			break;
		}
		/* Both state1 and state2 tels are good. */
		else if ( s1Tel->key < s2Tel->key ) {
			/* A trans exists in state1 on s1Tel->key but not in state2 on
			 * s2Tel->key.  Find a transition from state2 to serve as the
			 * default. If s1Tel->key in a range in state2, use that range
			 * (which may be null), otherwise use state2->default. */
			rangeTel = state2->outRange.findRange( s1Tel->key );
			if ( rangeTel != 0 )
				defTrans = rangeTel->value;
			else
				defTrans = state2->outDefault;

			/* Trans is only in s1. */
			CO_RETURN2( OnlyInS1Trans, TransInS1 );

			s1Tel++;
		}
		else if ( s1Tel->key > s2Tel->key ) {
			/* A trans exists in state2 on s2Tel->key but not in state1 on
			 * s1Tel->key.  Find a transition from state1 to serve as the
			 * default. If s2Tel->key in a range in state1, use that range
			 * (which may be null), otherwise use state1->default. */
			rangeTel = state1->outRange.findRange( s2Tel->key );
			if ( rangeTel != 0 )
				defTrans = rangeTel->value;
			else
				defTrans = state1->outDefault;

			/* Trans is only in s2. */
			CO_RETURN2( OnlyInS2Trans, TransInS2 );

			s2Tel++;
		}
		else {
			/* Keys match up. Trans on the same char. */

			/* Trans is in both. */
			CO_RETURN2( InBothTrans, TransOverlap );

			s1Tel++;
			s2Tel++; 
		}
	}


	/* Pointers used to walk through out ranges concurrently. This needs to be
	 * done a little differently than with the out list. Two head pointers are
	 * maintained, one being the head of the out range the other being a
	 * pointer to the virtual head, so we can modify the head range without
	 * changing the out ranges. */
	s1Range = state1->outRange.data;
	s1Tel = s1Range;
	s1EndTel = s1Range + state1->outRange.length;

	/* Pointers for state 2. */
	s2Range = state2->outRange.data;
	s2Tel = s2Range;
	s2EndTel = s2Range + state2->outRange.length;

	/* Concurrently scan both out ranges. */
	while ( true ) {
		if ( s1Range == s1EndTel ) {
			/* We are at the end of state1's ranges. Process the rest of
			 * state2's ranges. */
			while ( s2Range != s2EndTel ) {
				/* Range is only in s2. */
				defTrans = state1->outDefault;
				CO_RETURN2( ConsumeS2Range, RangeInS2 );

				s2Range += 2;
				s2Tel = s2Range;
			}
			break;
		}
		else if ( s2Range == s2EndTel ) {
			/* We are at the end of state2's ranges. Process the rest of
			 * state1's ranges. */
			while ( s1Range != s1EndTel ) {
				/* Range is only in s1. */
				defTrans = state2->outDefault;
				CO_RETURN2( ConsumeS1Range, RangeInS1 );

				s1Range += 2;
				s1Tel = s1Range;
			}
			break;
		}
		/* Both state1's and state2's transition elements are good.
		 * The signiture of no overlap is a back key being in front of a
		 * front key. */
		else if ( s1Tel[1].key < s2Tel[0].key ) {
			/* A range exists in state1 that does not overlap with state2. */
			defTrans = state2->outDefault;
			CO_RETURN2( OnlyInS1Range, RangeInS1 );

			s1Range += 2;
			s1Tel = s1Range;
		}
		else if ( s2Tel[1].key < s1Tel[0].key ) {
			/* A range exists in state2 that does not overlap with state1. */
			defTrans = state1->outDefault;
			CO_RETURN2( OnlyInS2Range, RangeInS2 );

			s2Range += 2;
			s2Tel = s2Range;
		}
		/* There is overlap, must mix the ranges in some way. */
		else if ( s1Tel[0].key < s2Tel[0].key ) {
			/* Range from state1 sticks out front. Must break it into
			 * non-overlaping and overlaping segments. */

			/* First get a copy of the head of range 1. We may be copying from the
			 * copy, this we cannot tell without looking at the pointers. Just
			 * do it anyways. */
			s1HeadTel[0] = s1Tel[0];
			s1HeadTel[1] = s1Tel[1];
			s1Tel = s1HeadTel;

			/* Now do the break. We must save the old end of the range and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s1NextTel[0] = s1Tel[0];
			s1NextTel[1] = s1Tel[1];
			s1Tel[1].key = s2Tel[0].key - 1;
			s1NextTel[0].key = s2Tel[0].key;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s1. This gives them a
				 * chance to duplicate s1Tel[0,1].value. */
				CO_RETURN2( S1SticksOutBreak, BreakS1 );
			}

			/* Broken off range is only in s1. */
			defTrans = state2->outDefault;
			CO_RETURN2( S1SticksOut, RangeInS1 );

			/* Advance over the part sticking out front. */
			s1Tel[0] = s1NextTel[0];
			s1Tel[1] = s1NextTel[1];
		}
		else if ( s2Tel[0].key < s1Tel[0].key ) {
			/* Range from state2 sticks out front. Must break it into
			 * non-overlaping and overlaping segments. */

			/* First get a copy of the head of range 2. We may be copying from the
			 * copy, this we cannot tell without looking at the pointers. Just
			 * do it anyways. */
			s2HeadTel[0] = s2Tel[0];
			s2HeadTel[1] = s2Tel[1];
			s2Tel = s2HeadTel;

			/* Now do the break. We must save the old end of the range and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s2NextTel[0] = s2Tel[0];
			s2NextTel[1] = s2Tel[1];
			s2Tel[1].key = s1Tel[0].key - 1;
			s2NextTel[0].key = s1Tel[0].key;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s2. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S2SticksOutBreak, BreakS2 );
			}

			/* Broken off range is only in s2. */
			defTrans = state1->outDefault;
			CO_RETURN2( S2SticksOut, RangeInS2 );

			/* Advance over the part sticking out front. */
			s2Tel[0] = s2NextTel[0];
			s2Tel[1] = s2NextTel[1];
		}
		/* Low ends are even. Are the high ends even? */
		else if ( s1Tel[1].key < s2Tel[1].key ) {
			/* Range from state2 goes longer than the range from state1. We
			 * must break the range from state2 into an evenly overlaping
			 * segment. */

			/* We are going to break range 2, copy it first. We may be copying
			 * from the copy. We cannot tell without looking at the pointers.
			 * Just do it anyways. */
			s2HeadTel[0] = s2Tel[0];
			s2HeadTel[1] = s2Tel[1];
			s2Tel = s2HeadTel;

			/* Now do the break. We must save the old end of range 2 and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s2NextTel[0] = s2Tel[0];
			s2NextTel[1] = s2Tel[1];
			s2Tel[1].key = s1Tel[1].key;
			s2NextTel[0].key = s1Tel[1].key + 1;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s2. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S2DragsBehindBreak, BreakS2 );
			}

			/* Breaking s2 produces exact overlap. */
			CO_RETURN2( S2DragsBehind, RangeOverlap );

			/* Advance over the front we just broke off of range 2. */
			s2Tel[0] = s2NextTel[0];
			s2Tel[1] = s2NextTel[1];

			/* Advance over the entire s1Tel. We have consumed it. */
			s1Range += 2;
			s1Tel = s1Range;
		}
		else if ( s2Tel[1].key < s1Tel[1].key ) {
			/* Range from state1 goes longer than the range from state2. We
			 * must break the range from state1 into an evenly overlaping
			 * segment. */

			/* We are going to break range 1, copy it first. We may be copying
			 * from the copy. We connot tell this without looking at the
			 * pointers. Just do it anyways. */
			s1HeadTel[0] = s1Tel[0];
			s1HeadTel[1] = s1Tel[1];
			s1Tel = s1HeadTel;

			/* Now do the break. We must save the old end of range 1 and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s1NextTel[0] = s1Tel[0];
			s1NextTel[1] = s1Tel[1];
			s1Tel[1].key = s2Tel[1].key;
			s1NextTel[0].key = s2Tel[1].key + 1;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s1. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S1DragsBehindBreak, BreakS1 );
			}

			/* Breaking s1 produces exact overlap. */
			CO_RETURN2( S1DragsBehind, RangeOverlap );

			/* Advance over the front we just broke off of range 1. */
			s1Tel[0] = s1NextTel[0];
			s1Tel[1] = s1NextTel[1];

			/* Advance over the entire s2Tel. We have consumed it. */
			s2Range += 2;
			s2Tel = s2Range;
		}
		else {
			/* There is an exact overlap. */
			CO_RETURN2( ExactOverlap, RangeOverlap );

			s1Range += 2;
			s1Tel = s1Range;
			s2Range += 2;
			s2Tel = s2Range;
		}
	}

	/* Done, go into end state. */
	CO_RETURN( End );
}


#endif /* _RLFSM_FSMSTATE_CPP */

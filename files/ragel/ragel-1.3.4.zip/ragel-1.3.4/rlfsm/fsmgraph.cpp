/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMGRAPH_CPP
#define _RLFSM_FSMGRAPH_CPP

#include <assert.h>

#include "fsmgraph.h"
#include "mergesort.h"

/* Other graph code files. */
#include "fsmstate.cpp"
#include "fsmbase.cpp"
#include "fsmattach.cpp"
#include "fsmmin.cpp"

/* Make a new state. The new state will be put on the graph's
 * list of state. The new state can be created final or non final. */
template < class Graph, class State, class Transition >
		State *FsmGraph<Graph, State, Transition>::
		newState()
{
	/* Make the new state to return. */
	State *state = new State();

	if ( misfitAccounting ) {
		/* Create the new state on the misfit list. All states are created
		 * with no foreign in transitions. */
		misfitList.append( state );
	}
	else {
		/* Create the new state. */
		stateList.append( state );
	}

	/* Return the new state. */
	return state;
}

/* Create an fsm that is a concatenation of the characters in the given string. */
template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		concatFsm( char *str, int len )
{
	/* New Graph */
	Graph *retVal = new Graph;

	/* Make the first state and set it as the start state. */
	State *last = retVal->newState();
	retVal->setEntry( 0, last );

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *newState = retVal->newState();
		retVal->attachStates( last, newState, KeyTypeSingle, str[i], 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->setFinState( last );
	return retVal;
}

template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		concatFsm( int *str, int len )
{
	/* New Graph */
	Graph *retVal = new Graph;

	/* Make the first state and set it as the start state. */
	State *last = retVal->newState();
	retVal->setEntry( 0, last );

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *newState = retVal->newState();
		retVal->attachStates( last, newState, KeyTypeSingle, str[i], 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->setFinState( last );
	return retVal;
}


template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		concatFsm( int chr )
{
	/* New Graph. */
	Graph *retVal = new Graph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on the character. */
	retVal->attachStates( start, end, KeyTypeSingle, chr, 0 );

	return retVal;
}

template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		orFsm( char *set, int len )
{
	/* New Graph. */
	Graph *retVal = new Graph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on all the chars in the given string of characters. */
	for ( int i = 0; i < len; i++ )
		retVal->attachStates( start, end, KeyTypeSingle, set[i], 0 );

	return retVal;
}

template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		orFsm( int *set, int len )
{
	/* New Graph. */
	Graph *retVal = new Graph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on all the integers in the given string of ints. */
	for ( int i = 0; i < len; i++ )
		retVal->attachStates( start, end, KeyTypeSingle, set[i], 0 );

	return retVal;
}

template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		nullFsm()
{
	/* New Graph. */
	Graph *retVal = new Graph;

	/* Give it one state with no transitions making it
	 * the start state and final state. */
	State *startState = retVal->newState();
	retVal->setEntry( 0, startState );
	retVal->setFinState( startState );

	/* Return new Graph. */
	return retVal;
}

/* Make a graph with two states and the default transition between them. */
template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		dotFsm()
{
	/* New graph. */
	Graph *retVal = new Graph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on the any char. */
	retVal->attachStates( start, end, KeyTypeDefault, 0, 0 );

	return retVal;
}

/* Make a graph with one state (which is final) and a default transition back
 * to itself. */
template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		dotStarFsm()
{
	/* New graph. */
	Graph *retVal = new Graph;

	/* One state which is final and is the start state. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );
	retVal->setFinState( start );

	/* Attach start to start on default. */
	retVal->attachStates( start, start, KeyTypeDefault, 0, 0 );

	return retVal;
}

/* Make a graph with one two states and a range of transitions between them. */
template < class Graph, class State, class Transition >
		Graph *FsmGraph<Graph, State, Transition>::
		rangeFsm( int low, int high )
{
	/* New Graph. */
	Graph *retVal = new Graph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach using the range of characters. */
	retVal->attachStates( start, end, KeyTypeRange, low, high );

	return retVal;
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		starOp( bool leavingFsm )
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of the original start state. */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );

	/* Get a copy of the final state set before creating the new
	 * start state. It may get set final and we don't want the start
	 * state to be included in the final state set. If it is included
	 * in the final state set then all the final states after it get
	 * the transitions of the start state doubled up. That's incorrect.*/
	StateSet finStateSetCopy( finStateSet );

	/* This will be the new start state. It will be set final after the
	 * merging of the final states with the start state is complete. */
	State *newStart = newState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* From here on we need the new start state as start state set. */
	startStateSet.setAs( newStart );

	/* For all the final states, merge with the new start state. */
	State **st = finStateSetCopy.data;
	int nst = finStateSetCopy.length;
	for (int i = 0; i < nst; i++, st++)
		mergeStates( md, *st, startStateSet, leavingFsm );

	/* Now it is safe to merge the start state with itself (provided it
	 * is set final). */
	if ( newStart->stateBits & SB_ISFINAL )
		mergeStates( md, newStart, startStateSet, leavingFsm );

	/* Now ensure the new start state is a final state. */
	setFinState( newStart );

	/* Fill in any states that were newed up as combinations of others. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		concatOp( Graph *other, bool leavingFsm )
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Build a state set consisting of other's start state. */
	StateSet startStateSet;
	startStateSet.insert( other->findEntry(0) );

	/* Unset other's start state before bringing in the entry points. */
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Bring in other's states into our state lists. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Get a copy of our final state set before we clobber it. We need to
	 * iterate over it while it may change due to the merging process. */
	StateSet finStateSetCopy( finStateSet );

	/* Unset all of our final states and get the final states from other. */
	unsetAllFinStates();
	finStateSet.insert( other->finStateSet );
	
	/* Since other's lists are empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our former final states with the start state of other. */
	State **st = finStateSetCopy.data;
	int nst = finStateSetCopy.length;
	for (int i = 0; i < nst; i++, st++) {
		State *state = *st;

		/* Merge the former final state with other's start state. */
		mergeStates( md, state, startStateSet, leavingFsm );

		/* If the former final state was not reset final then we must clear
		 * the state's out trans data. If it got reset final then it gets to
		 * keep its out trans data. This must be done before fillInStates gets
		 * called to prevent the data from being sourced. */
		if ( ! (state->stateBits & SB_ISFINAL) )
			state->relinquishFinal();
	}

	/* Fill in any new states made from merging. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}


template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		doOr( Graph *other )
{
	/* For the merging process. */
	MergeData md;

	/* Build a state set consisting of both start states */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );
	startStateSet.insert( other->findEntry(0) );

	/* Both of the original start states loose their start state status. */
	unsetEntry( 0 );
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Merge the lists. This will move all the states from other
	 * into this. No states will be deleted. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Move the final set data from other into this. */
	finStateSet.insert(other->finStateSet);
	other->finStateSet.empty();

	/* Since other's list is empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Create a new start state. */
	State *newStart = newState();
	setEntry( 0, newStart );

	/* Merge the start states. */
	mergeStates( md, newStart, startStateSet, false );

	/* Fill in any new states made from merging. */
	fillInStates( md );
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		unionOp( Graph *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Call Worker routine. */
	doOr( other );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		intersectOp( Graph *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits on this and other to want each other. */
	setFinBits( SB_WANTOTHER1 );
	other->setFinBits( SB_WANTOTHER2 );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetIncompleteFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		subtractOp( Graph *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits of other to be killers. */
	other->setFinBits( SB_KILLOTHERS );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetIncompleteFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}


/* Unset any final states that are no longer to be final due to final bits. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		unsetIncompleteFinals()
{
	/* Duplicate the final state set before we begin modifying it. */
	StateSet fin( finStateSet );

	for ( int s = 0; s < fin.length; s++ ) {
		State *state = fin.data[s];

		if ( state->stateBits & SB_KILLOTHERS ) {
			/* One final state is a killer, don't set final. */
			unsetFinState( state );
		}

		if ( state->stateBits & SB_WANTOTHER && 
				(state->stateBits & SB_WANTOTHER) != SB_WANTOTHER )
		{
			/* One state wants the other but it is not there. */
			unsetFinState( state );
		}

		/* All states should have their killing and wanting state bits
		 * cleared. Non final states should never have had those state bits
		 * set in the first place. */
		state->stateBits &= ~ (SB_WANTOTHER | SB_KILLOTHERS);
	}
}

/* Ensure that the start state is free of entry points (aside from the fact
 * that it is the start state). If the start state has entry points then Make a
 * new start state by merging with the old one. Useful before modifying start
 * transitions. If the existing start state has any entry points other than the
 * start state entry then modifying its transitions changes more than the start
 * transitions. So isolate the start state by separating it out such that it
 * only has start stateness as it's entry point. */
template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		isolateStartState( )
{
	/* For the merging process. */
	MergeData md;

	/* Bail out if the start state is already isolated. */
	if ( isStartStateIsolated() )
		return;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of only the start state. */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );

	/* This will be the new start state. The existing start
	 * state is merged with it. */
	State *newStart = newState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* Stfil and stateDict will be empty because the merging of the old start
	 * state into the new one will not have any conflicting transitions. */
	assert( md.stateDict.nodeCount == 0 );
	assert( md.stfillHead == 0 );

	/* The old start state may be unreachable. Remove the misfits and turn off
	 * misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		mergeStates( MergeData &md, State *destState, StateSet &stateSet, 
				bool leavingFsm )
{
	/* If a merge is to make transitions that leave an fsm then the state set
	 * should have only one element in it. This is to protect against writing
	 * and reading of out trans data as determined by the order of state in
	 * state set. */
	assert( ! ( leavingFsm && stateSet.size() > 1 ));

	State **stp = stateSet.data;
	int nst = stateSet.length;
	for ( int i = 0; i < nst; i++, stp++ ) {
		State *src = *stp;

		/* Get the out transitions. */
		outTransCopy( md, destState, src, leavingFsm );

		/* Get its bits and final state status. */
		destState->stateBits |= ( src->stateBits & ~SB_ISFINAL );
		if ( src->stateBits & SB_ISFINAL )
			setFinState( destState );

		/* Call user routine. */
		destState->addInState( src );
	}
}

template < class Graph, class State, class Transition >
		void FsmGraph<Graph, State, Transition>::
		fillInStates( MergeData &md )
{
	/* Merge any states that are awaiting merging. This will likey cause
	 * other states to be added to the stfil list. */
	State *state = md.stfillHead;
	while ( state != 0 ) {
		mergeStates( md, state, state->stateDictNode->stateSet, false );
		state = state->alg.next;
	}

	/* Delete the state sets of all states that are on the fill list. */
	state = md.stfillHead;
	while ( state != 0 ) {
		/* Delete and reset the state set. */
		delete state->stateDictNode;
		state->stateDictNode = 0;

		/* Next state in the stfill list. */
		state = state->alg.next;
	}

	/* StateDict will still have it's ptrs/size set but all of it's nodes
	 * will be deleted so we don't need to clean it up. */
}


#endif /* _RLFSM_FSMGRAPH_CPP */

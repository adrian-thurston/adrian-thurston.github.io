/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmbuild.h"

/* Construct the fsm builder. Inits the pointers to the graph, and machine. */
FsmBuild::FsmBuild( FsmAp &graph, FsmMachine &machine )
:
	graph(graph), 
	machine(machine),
	curFuncOffset(0), 
	curTransOffset(0), 
	numFuncs(0)
{
}

/* Creates machine states and assignes each state state in the graph to the
 * corresponding state in the array of machine states. */
void FsmBuild::initMachineStates( )
{
	/* Make the array of states. */
	int numStates = graph.stateList.length+1;
	FsmMachState *machStates = new FsmMachState[numStates];

	/* Make all the states first and set the mapto values. */
	StateAp *state = graph.stateList.head;
	FsmMachState *curState = machStates;
	for ( int i = 0; i < numStates; i++, curState++ ) {
		/* Init the state. */
		curState->transIndKey = 0;
		curState->transIndPtr = 0;
		curState->numIndex = 0;
		curState->rangeIndKey = 0;
		curState->rangeIndPtr = 0;
		curState->numRange = 0;
		curState->dflIndex = TRANS_ERR_TRANS;
		curState->outFuncs = FUNC_NO_FUNC;

		if ( i == 0 ) {
			/* The error state is not final and is not mapped to from any
			 * graph state. */
			curState->isFinState = false;
		}
		else {
			/* If the original state is a final state, set the new state final. */
			curState->isFinState = (state->stateBits & SB_ISFINAL) ? true : false;

			/* Set the mapto value and go to next state. */
			state->alg.machState = (machStates + i);
			state = state->next;
		}
	}

	/* Get the start state and such. */
	FsmMachState *startState = graph.findEntry( 0 )->alg.machState;

	/* Set number of states, the state array and the start state. */
	machine.numStates = numStates;
	machine.allStates = machStates;
	machine.startState = startState - machStates;
}


void FsmBuild::reduceFuncTable( TransFuncTable &funcTable )
{
	/* Only need to reduce if the transition function is set. */
	if ( funcTable.length() > 0 ) {
		/* Result of the insert and the last found. */
		TransFuncSetEl *result, *lastFound;

		/* Try to insert in the function map using the next func offset. */
		result = transFuncSet.insert( funcTable, curFuncOffset, &lastFound );

		if ( result != 0 ) {
			/* The insert succeeded. Increment the count of functions
			 * and the offset into the function index. */
			numFuncs += funcTable.length() + 1;
			curFuncOffset += 1;
		}
		else {
			/* The func already exists take a reference to it to
			 * reduce mem usage. */
			funcTable = lastFound->key;
		}
	}
}

void FsmBuild::reduceFunctions( )
{
	/* For each state... */
	StateAp *state = graph.stateList.head;
	while ( state != 0 ) {
		/* Reduce the func table of each transition going out of the state. */
		FsmOutIterator<StateAp, TransAp> outIt( state );
		for ( ; ! outIt.atEnd(); outIt++ )
			reduceFuncTable( outIt.trans->transFuncTable );

		/* Reduce the state's func table of out transitions. */
		reduceFuncTable( state->outTransFuncTable );

		/* Next state. */
		state = state->next;
	}
}

void FsmBuild::reduceTransitions( )
{
	/* For each state... */
	StateAp *state = graph.stateList.head;
	while ( state != 0 ) {
		/* For each transition going out of the state. */
		FsmAp::OutIterator outIt( state );
		for ( ; ! outIt.atEnd(); outIt++ ) {
			/* Result of the insert and the last found. */
			TransSetEl *result, *lastFound;

			/* Try to insert in the map. */
			result = transSet.insert( outIt.trans, curTransOffset, &lastFound );

			if ( result != 0 ) {
				/* The insert succeeded. Increment the count of transitions. */
				curTransOffset += 1;
			}
			else {
				/* The func already so exists take a reference to it. */
				if ( outIt.itState == FsmAp::OutIterator::Default ) {
					/* Set from the transition stored in the set. */
					delete outIt.state->outDefault;
					outIt.state->outDefault = lastFound->key;
				}
				else {
					/* Set from the transition stored in the set. */
					delete outIt.transEl->value;
					outIt.transEl->value = lastFound->key;
				}
			}
		}
		state = state->next;
	}
}

void FsmBuild::emptyReduced()
{
	/* In the reduced form, the transition are not deleted by iterating the
	 * out list because they are shared across the whole graph. Just delete
	 * all the states. */
	graph.stateList.empty();

	/* Delete thet transitions from the transSet. */
	TransSet::Iterator it = transSet.first();
	for ( ; it != transSet.slast(); it++ )
		delete it->key;
}

void FsmBuild::buildFunctionList()
{
	/* Only proceed if there are any functions. */
	if ( transFuncSet.size() > 0 ) {
		/* There was space used. New up the funclist array and then fill it in. */
		int *transFuncs = new int[numFuncs];

		/* The size of funcListMap gives the number of function 
		 * indicies and lengths. */
		machine.transFuncIndex = new int[transFuncSet.size()];
		machine.numTransFuncIndex = transFuncSet.size();

		/* For each funclist in the funclist map, copy the list over. Also
		 * copy the indicies into the transfuncs. This is pointer plus len. */
		TransFuncSet::Iterator it = transFuncSet.first();
		for( int writeTo = 0; it != transFuncSet.slast(); it++ ) {
			/* Get a pointer to the function table. */
			TransFuncTable &funcTab = it->key;

			/* Set the index pointer and number of funcs for the func offset. */
			machine.transFuncIndex[it->value] = writeTo;

			/* The first element is the length. */
			transFuncs[writeTo++] = funcTab.size();

			/* Copy the transFuncs at the writeTo offset. */
			TransFuncTable::Iterator funcIt = funcTab.first();
			for ( ; funcIt != funcTab.slast(); writeTo++, funcIt++ )
				transFuncs[writeTo] = funcIt->value;
		}

		/* Set the transition funcs ptr and the number of trans funcs. */
		machine.allTransFuncs = transFuncs;
		machine.numTransFuncs = numFuncs;
	}
}


/* Make the global array of unique transitions. */
void FsmBuild::buildTransitionArray()
{
	/* Save the items in the transMap to trans */
	FsmMachTrans *trans = 0;

	/* New up the transition table. */
	trans = new FsmMachTrans[curTransOffset];

	/* Walk the transMap and copy to the transitions. The location of the
	 * transition must be the offsets in the value field because that is what
	 * the index array uses. */
	TransSet::Iterator it = transSet.first();
	for ( ; it != transSet.slast(); it++ ) {
		/* Handle the case of there being no no target state. */
		if ( it->key->toState == 0 ) {
			/* The target state is the error state. */
			trans[it->value].toState = STATE_ERR_STATE;
		}
		else {
			/* Get the machine state representing toState. */
			FsmMachState *state = it->key->toState->alg.machState;

			/* Save the target state. */
			trans[it->value].toState = state - machine.allStates;
		}

		/* Set the transitions functions in the machine trans. */
		if ( it->key->transFuncTable.length() == 0 ) {
			/* No functions for this transition. */
			trans[it->value].funcs = FUNC_NO_FUNC;
		}
		else {
			/* Find the function in the func map. */
			TransFuncSetEl *tfsel = transFuncSet.find( it->key->transFuncTable );
			trans[it->value].funcs = tfsel->value;
		}
	}

	/* Set the transitions pointer and the number of transitions. */
	machine.allTrans = trans;
	machine.numTrans = curTransOffset;
}

/* Build a machine state from a graph state. Is responsible for creating the
 * transitions of the new state. */
void FsmBuild::buildMachineState( FsmMachState *machState, StateAp *state )
{
	/* 
	 * Build the transition list.
	 */
	int ntel = state->outList.size();
	machState->numIndex = ntel;
	if ( ntel > 0 ) {
		machState->transIndKey = new int[ntel];
		machState->transIndPtr = new int[ntel];
	}

	/* For each transition add the functions to the global function map and
	 * then add the transition to the global transition map. */
	TransListType::Iterator outIt = state->outList.first();
	for ( int writeTo = 0; 
			outIt != state->outList.slast(); 
			writeTo++, outIt++ )
	{
		/* Assume using the error transition. */
		int transOffset = TRANS_ERR_TRANS;

		/* The transition may not be set. */
		if ( outIt->value != 0 ) {
			TransSetEl *tsel = transSet.find( outIt->value );
			transOffset = tsel->value;
		}

		/* Set the index for this character. */
		machState->transIndKey[writeTo] = outIt->key;
		machState->transIndPtr[writeTo] = transOffset;
	}

	/*
	 * Now do ranges.
	 */
	ntel = state->outRange.size();
	machState->numRange = ntel/2;
	if ( ntel > 0 ) {
		machState->rangeIndKey = new int[ntel];
		machState->rangeIndPtr = new int[ntel/2];
	}

	/* For each range transition add the functions to the global function map
	 * and then add the transition to globabl map. */
	outIt = state->outRange.first();
	for ( int wi = 0, wj = 0; 
			outIt != state->outRange.slast(); 
			wi += 2, wj++, outIt++, outIt++ )
	{
		/* Get the first lower transition element. */
		TransEl *transEl = outIt;

		/* Assume using the error transition. */
		int transOffset = TRANS_ERR_TRANS;

		/* The transition may not be set. */
		if ( outIt->value != 0 ) {
			TransSetEl *tsel = transSet.find( transEl->value );
			transOffset = tsel->value;
		}

		/* Set the index for this character. */
		machState->rangeIndKey[wi] = transEl[0].key;
		machState->rangeIndKey[wi+1] = transEl[1].key;
		machState->rangeIndPtr[wj] = transOffset;
	}

	/* Make the default transition if there. Otherwise it will remain as err. */
	if ( state->outDefault != 0 ) {
		TransSetEl *tsel = transSet.find( state->outDefault );
		machState->dflIndex = tsel->value;
	}
}

/* Construct a compact runnable machine from this graph. Machine is put in
 * the machine object passed in. */
void FsmBuild::build()
{
	/* Create the machine states. */
	initMachineStates();

	/* Before reducing functions all function keys should be zero so that they
	 * don't interfere with the reduction. */
	graph.nullFunctionKeys();

	/* Make the global error transition. The rest of the fsm building code
	 * works on the assumption that the error trans is index 0. */
	transSet.insert( new TransAp(), curTransOffset++ );

	/* Reduce the functions and then the transitions. */
	reduceFunctions();
	reduceTransitions();

	/* Make the array of functions from the transFuncSet. */
	buildFunctionList();

	/* Make the global array of unique transitions. */
	buildTransitionArray();

	/* For each state build the machine state. */
	StateAp *state = graph.stateList.head;
	while ( state != 0 ) {
		/* Get the fsm state. */
		FsmMachState *machState = state->alg.machState;

		/* Use the base class to make the machine state. This call will modify
		 * funcListMap, curFuncOffset, and transMap. */
		buildMachineState( machState, state );

		/* A hack until output supports range transitions, move the ranges into
		 * the the indicies. */
		moveRangesIntoIndicies( machState );

		/* Set the state's out functions in the state. */
		if ( state->outTransFuncTable.length() == 0 ) {
			/* No functions for this transition. */
			machState->outFuncs = FUNC_NO_FUNC;
		}
		else {
			/* Find the function in the func map. */
			TransFuncSetEl *tfsel = transFuncSet.find( state->outTransFuncTable );
			machState->outFuncs = tfsel->value;
		}

		/* Next state. */
		state = state->next;
	}

	/* The graph needs to be cleared out by a delete that is aware that the
	 * transitions have been reduced. */
	emptyReduced();
}

void FsmBuild::makeIndiciesFromRange( FsmMachState *machState )
{
	/* Count the number of indicies. */
	int i, dest, numIndex = 0;
	for ( i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		numIndex += upper - lower + 1;
	}

	machState->transIndKey = new int[numIndex];
	machState->transIndPtr = new int[numIndex];
	machState->numIndex = numIndex;

	/* Set the indicies. */
	for ( dest = 0, i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		for ( int ind = lower; ind <= upper; ind++ ) {
			machState->transIndKey[dest] = ind;
			machState->transIndPtr[dest] = machState->rangeIndPtr[i];
			dest += 1;
		}
	}
}
		
void FsmBuild::moveRangesIntoIndicies( FsmMachState *machState )
{
	/* Nothing to do if there are no ranges. */
	if ( machState->rangeIndPtr == 0 )
		return;

	/* If there are no indicies then simply express the ranges as indicies. */
	if ( machState->transIndKey == 0 ) {
		makeIndiciesFromRange( machState );
	}
	else {
		int *indexKey = machState->transIndKey;
		int *indexPtr = machState->transIndPtr;
		int numIndex = machState->numIndex;

		makeIndiciesFromRange( machState );

		int *rangeKey = machState->transIndKey;
		int *rangePtr = machState->transIndPtr;
		int numRange = machState->numIndex;

		/* Pass one is to count. */
		int count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				count += numRange - range;
				break;
			}
			else if ( range == numRange ) {
				count += numIndex - index;
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] )
					range += 1;
				else if ( indexKey[index] < rangeKey[range] )
					index += 1;
				else {
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}

		machState->transIndKey = new int[count];
		machState->transIndPtr = new int[count];
		machState->numIndex = count;

		/* Pass two is to build. */
		count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				while ( range < numRange ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
					count += 1;
				}
				break;
			}
			else if ( range == numRange ) {
				while ( index < numIndex ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					count += 1;
				}
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
				}
				else if ( indexKey[index] < rangeKey[range] ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
				}
				else {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}
		delete[] indexKey;
		delete[] indexPtr;
		delete[] rangeKey;
		delete[] rangePtr;
	}

	delete[] machState->rangeIndKey;
	delete[] machState->rangeIndPtr;
	machState->rangeIndKey = 0;
	machState->rangeIndPtr = 0;
	machState->numRange = 0;
}



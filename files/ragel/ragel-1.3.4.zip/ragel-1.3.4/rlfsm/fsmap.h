/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMAP_H
#define _RLFSM_FSMAP_H

#include "fsmgraph.h"
#include "sbstmap.h"
#include "avlmap.h"

struct TransAp;
struct StateAp;

/* Compare of a whole Func table element (key & value). */
struct TransFuncElCmp
{
	static int compare( const SBstMapEl<int, int> &func1, 
			const SBstMapEl<int, int> &func2 )
	{
		int compareRes = CmpOrd<int>::compare( func1.key, func2.key );
		if ( compareRes != 0 )
			return compareRes;
		return CmpOrd<int>::compare( func1.value, func2.value );
	}
};

/* Transition class that implements actions and priorities. */
struct TransAp : public FsmTrans< StateAp, TransAp >
{
	/* Init the priority. */
	TransAp() : priority(0) { }

	/* Transistion Func Element and the table. */
	typedef SBstMapEl< int, int > TransFuncEl;
	typedef SBstMap< int, int, CmpOrd<int> > TransFuncTable;

	/* Plain Func list that imposes no ordering. */
	typedef Vector<int> TransFuncList;

	/* Comparison for TransFuncList. */
	typedef CmpTable< int, CmpOrd<int> > TransFuncListCompare;

	/* The function table and priority for the transition. */
	TransFuncTable transFuncTable;
	int priority;

	/* Compare of a TransFuncTable. */
	typedef CmpSTable< TransFuncEl, TransFuncElCmp > TransFuncTableCompare;

	/* Set functions on the transition. */
	void setFunction( int func, int transOrder );
	void setFunctions( TransFuncTable &funcTable );

	/*
	 * Callback implementations
	 */

	/* Compare transitions on relative priority. */
	static int comparePrior( TransAp *trans1, TransAp *trans2 );

	/* Compare priority and function table of transitions. */
	static int compareTransData( TransAp *trans1, TransAp *trans2 );

	/* Add in the properties of srcTrans into this. */
	void addInTrans( TransAp *srcTrans );

	/* This trans is going to be made a leaving-graph-trans from srcState. */
	void leavingFromState( StateAp *srcState );
};


/* State class that implements actions and priorities. */
struct StateAp : public FsmState< StateAp, TransAp >
{
	StateAp();
	StateAp(const StateAp &other);

	/* Transistion func element and the table. */
	typedef SBstMapEl< int, int > TransFuncEl;
	typedef SBstMap< int, int, CmpOrd<int> > TransFuncTable;

	/* Compare of a TransFuncTable. */
	typedef CmpSTable< TransFuncEl, TransFuncElCmp > TransFuncTableCompare;

	/* Copy in functions to our out function table. */
	void setOutFunctions( TransFuncTable &funcTable );

	/* 
	 * State Data
	 */

	/* Is the out priority set? If so then it can be transfered to out
	 * transistions. Otherwise ignore it. */
	bool isOutPriorSet;

	/* Transition data to add to any transition leaving an fsm via this state. */
	int outPriority;
	TransFuncTable outTransFuncTable;

	/*
	 * Callback implementations
	 */

	/* Compare states on data stored in the states. */
	static int compareStateData( const StateAp *state1, const StateAp *state2 );

	/* Invoked when two states are made into one by the minimization process. */
	void fuseInState( StateAp *otherState ) { }

	/* Invoked when otherState is added into this state during the merging process. */
	void addInState( StateAp *otherState );

	/* Invoked when a state looses its final state status. */
	void relinquishFinal( );
};


/* Graph class that implements actions and priorities. */
struct FsmAp : public FsmGraph< FsmAp, StateAp, TransAp >
{
	/* Transistion Func Element and the table. */
	typedef SBstMapEl< int, int > TransFuncEl;
	typedef SBstMap< int, int, CmpOrd<int> > TransFuncTable;

	/* The iterator types. */
	typedef FsmOutIterator<StateAp, TransAp> OutIterator;
	typedef FsmInIterator<StateAp, TransAp> InIterator;

	/*
	 * Transition functions and priorities.
	 */

	/* Set priorities on transtions. */
	void startFsmPrior( int prior );
	void allTransPrior( int prior );
	void finFsmPrior( int prior );
	void leaveFsmPrior( int prior );

	/* Set functions to execute. */
	void startFsmFunc( int func, int transOrder );
	void allTransFunc( int func, int transOrder );
	void finFsmFunc( int func, int transOrder );
	void leaveFsmFunc( int func, int transOrder );

	/* Shift the function ordering of the start transitions to start
	 * at fromOrder and increase in units of 1. Useful before staring. */
	int shiftStartFuncOrder( int fromOrder );

	/* Clear functions from transitions. */
	void clearStartFsmFunc();
	void clearAllTransFunc();
	void clearFinFsmFunc();
	void clearLeaveFsmFunc();

	/* Clear the leave fsm priority settings from the fsm. */
	void clearLeaveFsmPrior();

	/* Remove all transition data. Remove funcs and outfuncs, zero priorities
	 * and remove out priorities. */
	void clearAllTransData();

	/* Zero out all the function keys. */
	void nullFunctionKeys();

	/* Walk the list of states and verify state properties. */
	void verifyStates();
};

#endif /* _RLFSM_FSMAP_H */

/* A Bison parser, made from rlparse.y, by GNU bison 1.75.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef BISON_RLPARSE_HPP
# define BISON_RLPARSE_HPP

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     PP_Literal = 258,
     PP_Integer = 259,
     PP_Word = 260,
     PP_Comment = 261,
     PP_Character = 262,
     PP_Whitespace = 263,
     PP_Section = 264,
     RL_Integer = 265,
     RL_Hex = 266,
     RL_Word = 267,
     RL_Literal = 268,
     RL_DoubleDot = 269,
     RL_ReLiteralSlash = 270,
     RL_ReLiteralChar = 271,
     RL_ReLiteralOpen = 272,
     RL_ReLiteralOpenNeg = 273,
     RL_ReLiteralClose = 274,
     RL_ReLiteralDot = 275,
     RL_ReLiteralStar = 276,
     RL_ReLiteralSet = 277,
     RL_OrLiteral = 278,
     RL_Builtin = 279,
     RL_Data = 280,
     RL_Func = 281,
     RL_Init = 282,
     RL_Clear = 283
   };
#endif
#define PP_Literal 258
#define PP_Integer 259
#define PP_Word 260
#define PP_Comment 261
#define PP_Character 262
#define PP_Whitespace 263
#define PP_Section 264
#define RL_Integer 265
#define RL_Hex 266
#define RL_Word 267
#define RL_Literal 268
#define RL_DoubleDot 269
#define RL_ReLiteralSlash 270
#define RL_ReLiteralChar 271
#define RL_ReLiteralOpen 272
#define RL_ReLiteralOpenNeg 273
#define RL_ReLiteralClose 274
#define RL_ReLiteralDot 275
#define RL_ReLiteralStar 276
#define RL_ReLiteralSet 277
#define RL_OrLiteral 278
#define RL_Builtin 279
#define RL_Data 280
#define RL_Func 281
#define RL_Init 282
#define RL_Clear 283




#ifndef YYSTYPE
#line 44 "rlparse.y"
typedef union {
	char *data;
	char chr;
	int integer;
	TermNode *term;
	FactorWithRepNode *factorWithRep;
	FactorWithAugNode *factorWithAug;
	FactorNode *factor;
	ExpressionNode *expression;
	int pAug;
	int funcId;
	AugType augType;
	Fsm *fsm;
	RegExpSet regExpSet;
} yystype;
/* Line 1281 of /usr/share/bison/yacc.c.  */
#line 112 "rlparse.hpp"
# define YYSTYPE yystype
#endif

extern YYSTYPE rllval;


#endif /* not BISON_RLPARSE_HPP */


/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

#ifdef AAPL_NAMESPACE
namespace Aapl {
#endif

/* Binary search table */
template <BST_TEMPL_DECLARE> class BsTable :
		public Vector< Element, Resize >
{
public:
	/**
	 * \brief Default constructor.
	 *
	 * Create an empty binary search table.
	 */
	BsTable() { }

	/**
	 * \brief Construct a binary search table with an initial amount of
	 * allocation.
	 *
	 * The table is initialized to have room for allocLength elements. The
	 * table starts empty.
	 */
	BsTable(int allocLength) : Vector< Element >( 0, allocLength ) {}

	Element *insert(const Key &key, Element **lastFound = 0);
	Element *insertMulti(const Key &key);

#if defined( BSTMAP )
	Element *insert(const Key &key, const Value &val, 
			Element **lastFound = 0);
	Element *insertMulti(const Key &key, const Value &val );
#endif

	Element *find(const Key &key, Element **lastFound = 0) const;
	bool findMulti( const Key &key, Element *&lower,
			Element *&upper ) const;

	bool remove(const Key &key);
	bool remove(Element *item);
	bool removeMulti(const Key &key);

#if defined( BSTSET )
	/* Set interface. */
	bool set(const Key &item, Element **lastFound = 0);
	void set(const BsTable &otherSet);
	bool unSet(const Key &item);
	bool isSet(const Key &item);
#endif
};


/**
 * \brief Find the element with the given key and remove it.
 *
 * If multiple elements with the given key exist, then it is unspecified which
 * element will be removed.
 *
 * \returns True if an element is found and consequently removed, false
 * otherwise.
 */
template<BST_TEMPL_DEF> bool BsTable<BST_TEMPL_USE>::
		remove(const Key &key)
{
	Element *el = find(key);
	if (el)
	{
		Vector< Element >::remove(el - table);
		return true;
	}
	else
		return false;
}

/**
 * \brief Remove the element pointed to by item.
 *
 * If item does not point to an element in the tree, then undefined behaviour
 * results. If item is null, then remove has no effect.
 *
 * \returns True if item is not null, false otherwise.
 */
template <BST_TEMPL_DEF> bool BsTable<BST_TEMPL_USE>::
		remove( Element *item )
{
	if (item != 0)
	{
		Vector< Element >::remove(item - table);
		return true;
	}
	else
		return false;
}

/**
 * \brief Find and remove the entire range of elements with the given key.
 *
 * \returns The number of elements removed.
 */
template<BST_TEMPL_DEF> bool BsTable<BST_TEMPL_USE>::
		removeMulti(const Key &key)
{
	Element *low, *high;
	if ( findMulti(key, low, high) )
	{
		int num = high - low + 1;
		Vector< Element >::remove(low - table, num);
		return num;
	}
	else
		return 0;
}


/**
 * \brief Find a range of elements with the given key.
 *
 * If any elements with the given key exist then lower and upper are set to
 * the low and high ends of the continous range of elements with the key.
 * Lower and upper will point to the first and last elements with the key.
 *
 * \returns True if any elements are found, false otherwise.
 */

template <BST_TEMPL_DEF> bool BsTable<BST_TEMPL_USE>::
		findMulti(const Key &key, Element *&low, Element *&high ) const
{
	Element *lower, *mid, *upper;
	int keyRelation;

	if (! table)
	{
		return false;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array. */
			return false;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			Element *lowEnd = table - 1;
			Element *highEnd = table + tableLength;

			lower = mid - 1;
			while ( lower != lowEnd && 
					BASE_COMPARE(compare(key, GET_KEY(lower))) == 0 )
				lower--;

			upper = mid + 1;
			while ( upper != highEnd && 
					BASE_COMPARE(compare(key, GET_KEY(upper))) == 0 )
				upper++;
			
			low = lower + 1;
			high = upper - 1;
			return true;
		}
	}
}

/**
 * \brief Find an element with the given key.
 *
 * If the find succeeds then lastFound is set to the element found. If the
 * find fails then lastFound is set the location where the key would be
 * inserted. If there is more than one element in the tree with the given key,
 * then it is unspecified which element is returned as the match.
 *
 * \returns The element found on success, null on failure.
 */

template <BST_TEMPL_DEF> Element *BsTable<BST_TEMPL_USE>::
		find( const Key &key, Element **lastFound ) const
{
	Element *lower, *mid, *upper;
	int keyRelation;

	if (! table)
		return 0;

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower ) {
			/* Did not find the key. Last found gets the insert location. */
			if ( lastFound != 0 )
				*lastFound = lower;
			return 0;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			/* Key is found. Last found gets the found record. */
			if ( lastFound != 0 )
				*lastFound = mid;
			return mid;
		}
	}
}

template <BST_TEMPL_DEF> Element *BsTable<BST_TEMPL_USE>::
		insert(const Key &key, Element **lastFound)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != 0 )
				*lastFound = mid;
			return 0;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. After makeRawSpaceFor, lower pointer is no good. */
	tableLength = makeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key);

	/* Set lastFound */
	if ( lastFound != 0 )
		*lastFound = table + insertPos;
	return table + insertPos;
}


template <BST_TEMPL_DEF> Element *BsTable<BST_TEMPL_USE>::
		insertMulti(const Key &key)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASE_COMPARE(compare(key, GET_KEY(mid)));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			lower = mid;
			goto Insert;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = makeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key);

	/* Return the element inserted. */
	return table + insertPos;
}

#ifdef AAPL_NAMESPACE
}
#endif

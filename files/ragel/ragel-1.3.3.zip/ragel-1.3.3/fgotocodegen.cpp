/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "fgotocodegen.h"
#include "bstmap.h"


/* Init base data. */
FGotoCodeGen::FGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	GotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the function switch a la ftab codegen. */
std::ostream &FGotoCodeGen::FUNC_SWITCH()
{
	/* Loop over all func indicies. */
	int *allTransFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "\tcase " << i+1 << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = allTransFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			out << "\t{" << getCodeBuiltin(*funcs) << "}\n";
			funcs += 1;
		}
		out << "\tbreak;\n";
	}
	return out;
}


/* Init base data. */
CFGotoCodeGen::CFGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	FGotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CFGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\t";
	FSM_NAME();
	out << "ExecFuncs( fsm, " << state->outFuncs + 1 << ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CFGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit them the call the execute them. */
	out << "\t";
	FSM_NAME();
	out << "ExecFuncs( fsm, " << trans->funcs + 1 << ", p );\n";
}


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CFGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}

void CFGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Function exection. We do not inline this as in tab\n"
		" * code gen because if we did, we might as well just expand \n"
		" * the function as in the faster goto code generator. */\n"
		"static void "; FSM_NAME() << "ExecFuncs( "; FSM_NAME() << " *fsm, int func, char *p )\n"
		"{\n"
		"	switch ( func ) {\n";
		FUNC_SWITCH() << "\n"
		"	}\n"
		"}\n"
		"\n"
		"#define alph unsigned char\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	register char *p = data-1;\n"
		"	register int len = dlen+1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( "; FSM_PREFIX() << "curState ) {\n";
		JUMP_IN_SWITCH() << "\n"
		"	}\n";
		STATE_GOTOS() << "\n";
		EXIT_STATES() << "\n";
		ERROR_LABEL() << "\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int cs = fsm->curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	fsm->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n"
		"#undef alph\n";
}

/* Init base data. */
CCFGotoCodeGen::CCFGotoCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	FGotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCFGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( " << state->outFuncs+1 << ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCFGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( " << trans->funcs+1 << ", p );\n";
}


/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCFGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCFGotoCodeGen::writeOutHeader()
{
	out << 
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( char *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"\n"
		"	/* The start state. */\n"
		"	static int startState;\n"
		"\n"
		"	/* Function exection. We do not inline this as in tab code gen\n"
		"	 * because if we did, we might as well just expand the function \n"
		"	 * as in the faster goto code generator. */\n"
		"	void ExecFuncs( int func, char *p );\n"
		"};\n"
		"\n";
}

void CCFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* The constructor initializes the fsm. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = startState;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"void "; FSM_NAME() << "::ExecFuncs( int func, char *p )\n"
		"{\n"
		"	switch ( func ) {\n";
		FUNC_SWITCH() << "\n"
		"	}\n"
		"}\n"
		"\n"
		"#define alph unsigned char\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( char *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	register char *p = data-1;\n"
		"	register int len = dlen+1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( curState ) {\n";
		JUMP_IN_SWITCH() << "\n"
		"	}\n";
		STATE_GOTOS() << "\n";
		EXIT_STATES() << "\n";
		ERROR_LABEL() << "\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int cs = curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	this->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n"
		"#undef alph\n";
}

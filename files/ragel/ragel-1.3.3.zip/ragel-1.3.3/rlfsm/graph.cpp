/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_GRAPH_CPP
#define _RLFSM_GRAPH_CPP

#include <stdio.h>
#include <assert.h>
#include "graph.h"


/* Graph Copy Constructor */
template < class State, class Key, class Transition >
		Graph<State, Key, Transition>::Graph(Graph &graph) :
		LastTransElFrom(0), LastTransElTo(0)
{
	/* Create the states and record their map in the original state. */
	State *origState = graph.head;
	while ( origState != 0 ) {
		/* Make the new state. */
		State *newState = new State(*origState);

		/* Add the state to the  */
		AddToGraph( newState );

		/* Set the mapsTo item of the old state. */
		origState->stateMap = newState;

		/* next state. */
		origState = origState->next;
	}
	
	/* Derefernce all the state maps and resort. */
	State *state = head;
	while ( state != 0 ) {
		/* Walk the list of out and in transitions setting the toState values
		 * to their mapped values into the set of new states. */
		typename State::TransEl *el = state->InList.table;
		int len = state->InList.tableLength;
		for (int i = 0; i < len; i++, el++ )
			el->key.toState = el->key.toState->stateMap;

		el = state->OutList.table;
		len = state->OutList.tableLength;
		for (int i = 0; i < len; i++, el++ )
			el->key.toState = el->key.toState->stateMap;

		/* Re-sort the in and out trans lists. Remember they are bstables
		 * paritally keyed on the toState, which has changed. */
		MergeSort<typename State::TransEl,
				typename State::TransElCmp>::
				Sort (state->InList.table, state->InList.tableLength );
		MergeSort<typename State::TransEl,
				typename State::TransElCmp>::
				Sort(state->OutList.table, state->OutList.tableLength );

		state = state->next;
	}
}

template < class State, class Key, class Transition>
		Graph<State, Key, Transition>::~Graph()
{
	/* Go through all the transitions and delete. */
	State *state = head;
	while ( state != 0 ) {
		typename State::TransEl *tel = state->OutList.table;
		int tlen = state->OutList.tableLength;
		for ( int i = 0; i < tlen; i++, tel++ ) {
			if ( tel->value != 0 )
				delete tel->value;
		}
		state = state->next;
	}
}

template < class State, class Key, class Transition >
	bool Graph<State, Key, Transition>::AttachStates(
			State *from, State *to, Key onChar)
{
	bool retVal;
	if ( from->OutList.insert(
				typename State::TransKey(onChar, to), 0, &LastTransElFrom) ) {
		/* Adding the trans in the out list succeeded. Add it in the in trans. */
		to->InList.insert(typename State::TransKey(onChar, from), 0, &LastTransElTo);
		retVal = true;
	}
	else {
		/* Trans is already there. Do a lookup in the inlist so we can
		 * have a last found. If it is not there then we have a broken graph. */
		LastTransElTo = to->InList.find( typename State::TransKey(onChar, from) );
		assert( LastTransElTo != NULL );
		retVal = false;
	}

	return retVal;
}

template < class State, class Key, class Transition >
	Transition *Graph<State, Key, Transition>::AttachStatesWithTrans(
			State *from, State *to, Key onChar)
{
	if ( AttachStates( from, to, onChar ) ) {
		Transition *newTrans = new Transition;
		SetLastTrans( newTrans );
		return newTrans;
	}
	else
		return GetLastTrans();
}

template < class State, class Key, class Transition >
	Transition *Graph<State, Key, Transition>::DetachStates(
			State *from, State *to, Key onChar )
{
	Transition *retTrans = 0;

	/* Look for the transition key. */
	typename State::TransEl *transEl = 
			from->OutList.find( typename State::TransKey(onChar, to) );
	if ( transEl != NULL ) {
		/* Save the Transition. */
		retTrans = transEl->value;

		/* Remove from OutList. */
		from->OutList.remove( transEl );
	
		/* Remove from InList. */
		to->InList.remove( typename State::TransKey(onChar, from) );
	}

	return retTrans;
}

template < class State, class Key, class Transition>
		State *Graph<State, Key, Transition>
		::DetachState(State *state)
{
	DetachInTrans(state);
	DetachOutTrans(state);
	DList<State>::detach(state);
	return state;
}

template < class State, class Key, class Transition>
		State *Graph<State, Key, Transition>
		::DetachInTrans(State *state)
{
	/* Remove the outgoings assoc the incommings. */
	typename State::TransEl *tel = state->InList.table;
	int tlen = state->InList.tableLength;
	for (int i = 0; i < tlen; i++, tel++)
	{
		tel->key.toState->OutList.remove(
				typename State::TransKey(tel->key.onChar, state));
		if ( tel->value != 0 )
			delete tel->value;
	}

	state->InList.empty();
	return state;
}

template < class State, class Key, class Transition >
		State *Graph<State, Key, Transition>
		::DetachOutTrans(State *state)
{
	/* Remove the incommings assoc the outgoings. */
	typename State::TransEl *tel = state->OutList.table;
	int tlen = state->OutList.tableLength;
	for (int i = 0; i < tlen; i++, tel++)
	{
		tel->key.toState->InList.remove(
				typename State::TransKey(tel->key.onChar, state));
		if ( tel->value != 0 )
			delete tel->value;
	}

	state->OutList.empty();
	return state;
}

/* Number the states starting at 0. */
template < class State, class Key, class Transition >
		void Graph<State, Key, Transition>::SetStateNumbers()
{
	int curNum = 0;
	State *state = head;
	while (state != 0) {
		state->num = curNum;
		curNum++;
		state = state->next;
	}
}

template < class State, class Key, class Transition >
		void Graph<State, Key, Transition>::
		DumpTransitions( FILE *file, typename State::TransList *list )
{
	typename State::TransEl *tel = list->table;
	int tlen = list->tableLength;
	for ( int i = 0; i < tlen; i++, tel++ )
		fprintf(file, " %.2i %.2i |", tel->key.toState->num, tel->key.onChar );
	fprintf(file, "\n");
}

template < class State, class Key, class Transition >
		void Graph<State, Key, Transition>::
		Dump( FILE *file )
{
	/* Set the state numbers so we print something nice! */
	SetStateNumbers();

	/* Walk the list of states, printing. */
	State *state = head;
	while (state) {
		fprintf( file, "%.2i\n", state->num );
		DumpTransitions(file, &state->OutList);
		state = state->next;
	}
}

#endif /* _RLFSM_GRAPH_CPP */

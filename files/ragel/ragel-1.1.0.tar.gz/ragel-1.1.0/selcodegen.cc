/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "selcodegen.h"
#include "bstmap.h"


/* Registers all the section names and inits the code and data pointers. */
SelCodeGen::SelCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		FsmCodeGen(fsmName, machine, parseData, out )
{
	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

void SelCodeGen::emitTransistion( int curState, FsmMachTrans *trans )
{
	if ( trans->toState == STATE_NO_STATE )
		out << "cs = -1; ";
	else
		out.form( "cs = %i; ", trans->toState );

	if ( trans->funcs != FUNC_NO_FUNC ) {
		int *funcs = machine->allTransFuncs + 
				machine->transFuncIndex[trans->funcs];

		/* The first number is the length. */
		int flen = *funcs++;
		while ( flen-- > 0 ) {
			out.form("{%s}", GetCodeBuiltin( *funcs ) );
			funcs += 1;
		}
	}
	out << "break;";
}

void SelCodeGen::STATE_SWITCH()
{
	out << "\t\tswitch( cs ) {" << endl;
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the state. */
		FsmMachState *state = machine->allStates+st;

		/* Make the switch oriented state. */
		FsmMachSwitchState swState;
		machine->makeSwitchState( swState, *state, 0, 256 );

		out.form("\t\tcase %i: {\n", st);
		out << "\t\t\tswitch ( c ) {\n\t\t\t";
		for ( int j = 0; j < swState.funcMap.tableLength; j++ ) {
			/* Write out all the characters that follow the trans. */
			Vector<int> &charVec = swState.funcMap[j].value;
			for ( int k = 0; k < charVec.tableLength; k++ ) {
				out.form("case %i: ", charVec.table[k] );
				if ( k % 4 == 3 )
					out << "\n\t\t\t";
			}
			/* Get the transition to go to and write it. */
			FsmMachTrans *trans = machine->allTrans + 
					swState.funcMap.table[j].key;
			emitTransistion( st, trans );
			out << "\n\t\t\t";
		}

		/* Get the default index and emit it. Default will always be used. */
		FsmMachTrans *trans = machine->allTrans + swState.dflIndex;
		out << "default: ";
		emitTransistion( st, trans );
		/* Close off the transition switch. */
		out << "\n\t\t\t}\n";

		/* Close off the state */
		out << "\t\t\tbreak;\n";
		out << "\t\t}\n";
	}
	out << "\t\t}" << endl;
}

void SelCodeGen::FINISH_SWITCH()
{
	out << "\tswitch( cs ) {" << endl;
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		out.form("\t\tcase %i: ", st);
		if ( state->isFinState )
			out << "accept = 1; ";

		/* If there are out functions, write them. */
		if ( state->outFuncs != FUNC_NO_FUNC ) {
			int *funcs = machine->allTransFuncs + 
					machine->transFuncIndex[state->outFuncs];

			/* The first number is the length. */
			int flen = *funcs++;
			while ( flen-- > 0 ) {
				out.form("{%s}", GetCodeBuiltin( *funcs ) );
				funcs += 1;
			}
		}
		out << "break;" << endl;
	}
	out << "}" << endl;
}

/* Registers all the section names and inits the code and data pointers. */
CSelCodeGen::CSelCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		SelCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CSelCodeGen::header[] = 
"

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	int curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CSelCodeGen::code[] = "

/* The start state. */
static int @FSMNAME@_startState = @START_STATE_OFFSET@;

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}


/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen )
{
	char *p = data;
	int len = dlen;
	int cs = fsm->curState;
	for ( ; len > 0; p++, len-- ) {
		unsigned char c = (unsigned char)*p;
@STATE_SWITCH@
	}
	fsm->curState = cs;
}

/**********************************************************************
 * @FSMNAME@Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	int cs = fsm->curState;
	int accept = 0;
@FINISH_SWITCH@
	fsm->accept = accept;
}
/*******************************************************
 * @FSMNAME@Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}

";

/* Registers all the section names and inits the code and data pointers. */
CCSelCodeGen::CCSelCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		SelCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CCSelCodeGen::header[] = 
"

/* Only non-static data: current state. */
class @FSMNAME@
{
public:
	@FSMNAME@();

	/* Init the fsm. */
	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int dlen );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	int curState;
	int accept;
	@STRUCT_DATA@

	/* The start state. */
	static int startState;
};

";

char CCSelCodeGen::code[] = "

/* The start state. */
int @FSMNAME@::startState = @START_STATE_OFFSET@;

/****************************************
 * @FSMNAME@::@FSMNAME@
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * @FSMNAME@::Init
 */
void @FSMNAME@::Init( )
{
	curState = startState;
	accept = 0;
	@INIT_CODE@
}


/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int dlen )
{
	char *p = data;
	int len = dlen;
	int cs = curState;
	for ( ; len > 0; p++, len-- ) {
		unsigned char c = (unsigned char)*p;
@STATE_SWITCH@
	}
	curState = cs;
}

/**********************************************************************
 * @FSMNAME@::Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	int cs = curState;
	int accept = 0;
@FINISH_SWITCH@
	this->accept = accept;
}

/*******************************************************
 * @FSMNAME@::Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@::Accept( )
{
	return accept;
}

";



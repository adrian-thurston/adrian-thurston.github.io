/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "fgotocodegen.h"
#include "bstmap.h"


/* Registers all the section names and inits the code and data pointers. */
FGotoCodeGen::FGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		GotoCodeGen(fsmName, machine, parseData, out)
{
	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Write out the function switch a la ftab codegen. */
void FGotoCodeGen::FUNC_SWITCH()
{
	/* Loop over all func indicies. */
	int *allTransFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out.form( "\tcase %d:\n", i+1 );
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = allTransFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			out << "\t{" << GetCodeBuiltin( *funcs ) << "}\n";
			funcs += 1;
		}
		out.form( "\tbreak;\n" );
	}
}


/* Registers all the section names and inits the code and data pointers. */
CFGotoCodeGen::CFGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		FGotoCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;

	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CFGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\t";
	FSMNAME();
	out.form( "ExecFuncs( fsm, %i, p );\n", state->outFuncs + 1 );
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CFGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit them the call the execute them. */
	out << "\t";
	FSMNAME();
	out.form( "ExecFuncs( fsm, %i, p );\n", trans->funcs + 1 );
}


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
void CFGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
}

char CFGotoCodeGen::header[] = 
"

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	int curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CFGotoCodeGen::code[] = "

/* The start state. */
static int @FSMNAME@_startState = @START_STATE_OFFSET@;

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}

/***************************************************************************
 * Function exection. We do not inline this as in tab
 * code gen because if we did, we might as well just expand 
 * the function as in the faster goto code generator.
 */
static void @FSMNAME@ExecFuncs( @FSMNAME@ *fsm, int func, char *p )
{
	switch ( func ) {
@FUNC_SWITCH@
	}
}

#define alph unsigned char

/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen )
{
	/* Prime these to one back to simulate entering the 
	 * machine on a transition. */ 
	register char *p = data-1;
	register int len = dlen+1;

	/* Switch statment to enter the machine. */
	switch ( @FSM_PREFIX@curState ) {
@JUMP_IN_SWITCH@
	}
@STATE_GOTOS@
@EXIT_STATES@
@ERROR_LABEL@
}

/**********************************************************************
 * @FSMNAME@Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	int cs = fsm->curState;
	int accept = 0;
@FINISH_SWITCH@
	fsm->accept = accept;
}

/*******************************************************
 * @FSMNAME@Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}

#undef alph
";

/* Registers all the section names and inits the code and data pointers. */
CCFGotoCodeGen::CCFGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		FGotoCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;

	needErrorLabel = false;

	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCFGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out.form( "\tExecFuncs( %i, p );\n", state->outFuncs+1 );
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCFGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit the call to execute them. */
	out.form( "\tExecFuncs( %i, p );\n", trans->funcs+1 );
}


/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
void CCFGotoCodeGen::FSM_PREFIX()
{
}


char CCFGotoCodeGen::header[] = 
"

/* Only non-static data: current state. */
class @FSMNAME@
{
public:
	@FSMNAME@();

	/* Init the fsm. */
	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int dlen );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	int curState;
	int accept;
	@STRUCT_DATA@

	/* The start state. */
	static int startState;

	/* Function exection. We do not inline this as in tab code gen
	 * because if we did, we might as well just expand the function 
	 * as in the faster goto code generator. */
	void ExecFuncs( int func, char *p );
};

";

char CCFGotoCodeGen::code[] = "

/* The start state. */
int @FSMNAME@::startState = @START_STATE_OFFSET@;

/****************************************
 * @FSMNAME@::@FSMNAME@
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * @FSMNAME@::Init
 */
void @FSMNAME@::Init( )
{
	curState = startState;
	accept = 0;
	@INIT_CODE@
}

/***************************************************************************
 * Execute functions pointed to by funcs until the null function is found. 
 */
void @FSMNAME@::ExecFuncs( int func, char *p )
{
	switch ( func ) {
@FUNC_SWITCH@
	}
}

#define alph unsigned char

/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int dlen )
{
	/* Prime these to one back to simulate entering the 
	 * machine on a transition. */ 
	register char *p = data-1;
	register int len = dlen+1;

	/* Switch statment to enter the machine. */
	switch ( curState ) {
@JUMP_IN_SWITCH@
	}
@STATE_GOTOS@
@EXIT_STATES@
@ERROR_LABEL@
}

/**********************************************************************
 * @FSMNAME@::Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	int cs = curState;
	int accept = 0;
@FINISH_SWITCH@
	this->accept = accept;
}

/*******************************************************
 * @FSMNAME@::Accept
 *
 * Did the machine accept?
 */
int @FSMNAME@::Accept( )
{
	return accept;
}

#undef alph

";

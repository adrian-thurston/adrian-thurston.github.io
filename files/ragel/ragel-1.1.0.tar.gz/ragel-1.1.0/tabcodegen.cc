/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "tabcodegen.h"

/* Registers all the section names and inits the code and data pointers. */
TabCodeGen::TabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) :
		FsmCodeGen(fsmName, machine, parseData, out)
{
	/* Call the automatically generated functino that will register
	 * code generation callbacks. */
	registerSections();
}

void TabCodeGen::stateOutFunc(FsmMachState *state)
{
	/* If there are any out funcs, emit them. Function indicies are indexes
	 * into transFuncIndex and should be dereferenced to get the index
	 * into the array of all transitions. */
	if ( state->outFuncs == FUNC_NO_FUNC )
		out << "0";
	else {
		/* There are out funcs. Write out the pointer into the array
		 * of funcs and the number of funcs. */
		out.form("f+%i", machine->transFuncIndex[state->outFuncs] );
	}
}

void TabCodeGen::transFunc(FsmMachTrans *trans)
{
	/* If there are any out funcs, emit them. Function indicies are indexes
	 * into transFuncIndex and should be dereferenced to get the index
	 * into the array of all transitions. */
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else {
		out.form( "f+%i", machine->transFuncIndex[trans->funcs] );
	}
}

void TabCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	StringListEl *flel = parseData->funcList.head;
	int fnum = 0;
	while ( flel != NULL ) {
		out.form( "\tcase %d: {\n", fnum );
		out << flel->data;
		out << "break;}" << endl;
		fnum += 1;
		flel = flel->next;
	}
}

void TabCodeGen::STATES()
{
	int curIndex = 0;
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Make a flat fsm state from the state. Do not allocate the indicies. */
		FsmMachFlatState flatState;
		machine->makeFlatState( flatState, *state, 0, 256, false );
		
		/* Emit, low and high index. */
		out << "\t{ " << flatState.lowIndex << ", ";
		out << flatState.highIndex << ", ";

		/* If there are any indicies, emit the pointer to where they
		 * will start for this state. */
		if ( flatState.numIndex > 0 )
			out.form( "i+%i, ", curIndex );
		else
			out << "0, ";

		/* Emit the default index. If there is no default index, then this will
		 * be 0, pointing to the err transition. */
		out.form( "%i, ", flatState.dflIndex );

		/* Out functions for the state. */
		stateOutFunc( state );

		out.form( ", %i }", state->isFinState );
		if ( i < machine->numStates-1 )
			out << ",\n";

		curIndex += flatState.numIndex;
	}
}

void TabCodeGen::INDICIES()
{
	out << '\t';
	int totalTrans = 0;
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Make a flat fsm state from the state. Allocate the indicies. */
		FsmMachFlatState flatState;
		machine->makeFlatState( flatState, *state, 0, 256, true );

		/* Walk the indicies, writing them out. */
		int *ind = flatState.transIndex;
		for ( int j = 0; j < flatState.numIndex; j++, ind++) {
			out.form( "%i", *ind );
			if ( *ind > 256 )
				out << " ";


			/* If we are not in the last index, then write out a comma and possibly
			 * a line break. */
			if ( i < machine->numStates-1 || j < flatState.numIndex-1 ) {
				out << ", ";

				/* Put in a line break every 8 */
				if ( totalTrans % 8 == 7 )
					out << "\n\t";
			} 

			/* update the number of trans output. */
			totalTrans += 1;
		}
	}
}

void TabCodeGen::INDEX_TYPE()
{
	if ( machine->numTrans <= 256 )
		out << "unsigned char";
	else if ( machine->numTrans <= 256*256 )
		out << "unsigned short";
	else 
		out << "unsigned int";
}


void TabCodeGen::TRANSITIONS()
{
	out << '\t';
	FsmMachTrans *trans = machine->allTrans;
	for ( int i = 0; i < machine->numTrans; i++, trans++ ) {
		if ( trans->toState == STATE_NO_STATE )
			out << "{0, ";
		else
			out.form( "{s+%i, ", trans->toState );

		/* Write the function for the state. Close transition. */
		transFunc( trans );
		out << "}";

		/* If not on the last transition, output a command 
		 * and possibly a line break. */
		if ( i < machine->numTrans-1 ) {
			out << ", ";

			/* Put in a break every 4, but only if not the last. */
			if ( i % 4 == 3 )
				out << "\n\t";
		}
	}
}

/* Registers all the section names and inits the code and data pointers. */
CTabCodeGen::CTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) :
		TabCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CTabCodeGen::header[] = 
"

/* Forward dec state for the transition structure. */
struct @FSMNAME@StateStruct;

/* A single transition. */
struct @FSMNAME@TransStruct
{
	struct @FSMNAME@StateStruct *toState;
	int *funcs;
};
typedef struct @FSMNAME@TransStruct @FSMNAME@Trans;

/* A single state. */
struct @FSMNAME@StateStruct
{
	int lowIndex;
	int highIndex;
	void *transIndex;
	unsigned int dflIndex;
	int *outFuncs;
	int isFinState;
};
typedef struct @FSMNAME@StateStruct @FSMNAME@State;

/* Only non-static data: current state. */
struct @FSMNAME@Struct
{
	@FSMNAME@State *curState;
	int accept;
	@STRUCT_DATA@
};
typedef struct @FSMNAME@Struct @FSMNAME@;

/* Init the fsm. */
void @FSMNAME@Init( @FSMNAME@ *fsm );

/* Execute some chunk of data. */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen );

/* Indicate to the fsm tha there is no more data. */
void @FSMNAME@Finish( @FSMNAME@ *fsm );

/* Did the machine accept? */
int @FSMNAME@Accept( @FSMNAME@ *fsm );

";

char CTabCodeGen::code[] = "

static int @FSMNAME@_f[];
static @FSMNAME@State @FSMNAME@_s[];
static @INDEX_TYPE@ @FSMNAME@_i[];
static @FSMNAME@Trans @FSMNAME@_t[];

static @FSMNAME@Trans @FSMNAME@_t[];

#define f @FSMNAME@_f
#define s @FSMNAME@_s
#define i @FSMNAME@_i
#define t @FSMNAME@_t

/* The array of functions. */
#if @ANY_FUNCS@
static int @FSMNAME@_f[] = {
@FUNCTIONS@
};
#endif

/* The aray of states. */
static @FSMNAME@State @FSMNAME@_s[] = {
@STATES@
};

/* The array of indicies into the transition array. */
#if @ANY_INDICIES@
static @INDEX_TYPE@ @FSMNAME@_i[] = {
@INDICIES@
};
#endif

/* The array of transitions. */
static @FSMNAME@Trans @FSMNAME@_t[] = {
@TRANSITIONS@
};

/* The start state. */
static @FSMNAME@State *@FSMNAME@_startState = s+@START_STATE_OFFSET@;

#undef f
#undef s
#undef i
#undef t


/***************************************************************************
 * Execute functions pointed to by funcs until the null function is found. 
 */
inline static void @FSMNAME@ExecFuncs( @FSMNAME@ *fsm, int *funcs, char *p )
{
	int len = *funcs++;
	while ( len-- > 0 ) {
		switch ( *funcs++ ) {
@FUNC_SWITCH@
		}
	}
}

/****************************************
 * Init the fsm to a runnable state.
 */
void @FSMNAME@Init( @FSMNAME@ *fsm )
{
	fsm->curState = @FSMNAME@_startState;
	fsm->accept = 0;
	@INIT_CODE@
}

/****************************************
 * Did the fsm accept? 
 */
int @FSMNAME@Accept( @FSMNAME@ *fsm )
{
	return fsm->accept;
}


/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@Execute( @FSMNAME@ *fsm, char *data, int dlen )
{
	char *p = data;
	int len = dlen;

	@FSMNAME@State *cs = fsm->curState;
	for ( ; len > 0; p++, len-- ) {
		int c = (unsigned char) *p;
		@FSMNAME@Trans *trans;

		if ( cs == 0 )
			goto finished;

		/* If the character is within the index bounds then get the
		 * transition for it. If it is out of the transition bounds
		 * we will use the default transition. */
		if ( cs->lowIndex <= c && c < cs->highIndex ) {
			/* Use the index to look into the transition array. */
			trans = @FSMNAME@_t + 
				((@INDEX_TYPE@*)cs->transIndex)[c - cs->lowIndex];
		}
		else {
			/* Use the default index as the char is out of range. */
			trans = @FSMNAME@_t + cs->dflIndex;
		}

		/* If there are functions for this transition then execute them. */
		if ( trans->funcs != 0 )
			@FSMNAME@ExecFuncs( fsm, trans->funcs, p );

		/* Move to the new state. */
		cs = trans->toState;
	}
finished:
	fsm->curState = cs;
}

/**********************************************************************
 * @FSMNAME@Finish
 *
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@Finish( @FSMNAME@ *fsm )
{
	@FSMNAME@State *cs = fsm->curState;
	if ( cs != 0 && cs->isFinState ) {
		/* If finishing in a final state then execute the
		 * out functions for it. (if any). */
		if ( cs->outFuncs != 0 )
			@FSMNAME@ExecFuncs( fsm, cs->outFuncs, NULL );
		fsm->accept = 1;
	}
	else {
		/* If we are not in a final state then this
		 * is an error. Move to the error state. */
		fsm->curState = 0;
	}
}
";


/* Registers all the section names and inits the code and data pointers. */
CCTabCodeGen::CCTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) :
		TabCodeGen(fsmName, machine, parseData, out)
{
	FsmCodeGen::header = header;
	FsmCodeGen::code = code;
}

char CCTabCodeGen::header[] = 
"

class @FSMNAME@
{
public:
	/* Forward dec state for the transition structure. */
	struct State;

	/* A single transition. */
	struct Trans
	{
		State *toState;
		int *funcs;
	};

	/* A single state. */
	struct State
	{
		int lowIndex;
		int highIndex;
		void *transIndex;
		unsigned int dflIndex;
		int *outFuncs;
		int isFinState;
	};

	/* Constructor. */
	@FSMNAME@();

	void Init( );

	/* Execute some chunk of data. */
	void Execute( char *data, int dlen );

	/* Indicate to the fsm tha there is no more data. */
	void Finish( );

	/* Did the machine accept? */
	int Accept( );

	State *curState;
	int accept;

	inline void ExecFuncs( int *funcs, char *p );

	@STRUCT_DATA@
};


";

char CCTabCodeGen::code[] = "

#define RAGEL_MAX_UINT (~((unsigned int)0))
#define RAGEL_MAX_INT ((int)(RAGEL_MAX_UINT>>1))
#define RAGEL_MIN_INT ((int)((RAGEL_MAX_UINT>>1)+1))

static int @FSMNAME@_f[];
static @FSMNAME@::State @FSMNAME@_s[];
static @INDEX_TYPE@ @FSMNAME@_i[];
static @FSMNAME@::Trans @FSMNAME@_t[];

#define f @FSMNAME@_f
#define s @FSMNAME@_s
#define i @FSMNAME@_i
#define t @FSMNAME@_t

/* The array of functions. */
#if @ANY_FUNCS@
static int @FSMNAME@_f[] = {
@FUNCTIONS@
};
#endif

/* The aray of states. */
static @FSMNAME@::State @FSMNAME@_s[] = {
@STATES@
};

/* The array of indicies into the transition array. */
#if @ANY_INDICIES@
static @INDEX_TYPE@ @FSMNAME@_i[] = {
@INDICIES@
};
#endif

/* The array of trainsitions. */
static @FSMNAME@::Trans @FSMNAME@_t[] = {
@TRANSITIONS@
};

/* The start state. */
static @FSMNAME@::State *@FSMNAME@_startState = s+@START_STATE_OFFSET@;

#undef f
#undef s
#undef i
#undef t


/***************************************************************************
 * Execute functions pointed to by funcs until the null function is found. 
 */
inline void @FSMNAME@::ExecFuncs( int *funcs, char *p )
{
	int len = *funcs++;
	while ( len-- > 0 ) {
		switch ( *funcs++ ) {
@FUNC_SWITCH@
		}
	}
}


/****************************************
 * Constructor
 */
@FSMNAME@::@FSMNAME@( )
{
	Init();
}

/****************************************
 * @FSMNAME@Init
 */
void @FSMNAME@::Init( )
{
	curState = @FSMNAME@_startState;
	accept = 0;
	@INIT_CODE@
}

/****************************************
 * Did the fsm accept? 
 */
int @FSMNAME@::Accept( )
{
	return accept;
}



/**********************************************************************
 * Execute the fsm on some chunk of data. 
 */
void @FSMNAME@::Execute( char *data, int dlen )
{
	char *p = data;
	int len = dlen;

	State *cs = curState;
	for ( ; len > 0; p++, len-- ) {
		int c = (unsigned char)*p;
		Trans *trans;

		if ( cs == 0 )
			goto finished;

		/* If the character is within the index bounds then get the
		 * transition for it. If it is out of the transition bounds
		 * we will use the default transition. */
		if ( cs->lowIndex <= c && c < cs->highIndex ) {
			/* Use the index to look into the transition array. */
			trans = @FSMNAME@_t + 
				((@INDEX_TYPE@*)cs->transIndex)[c - cs->lowIndex];
		}
		else {
			/* Use the default index as the char is out of range. */
			trans = @FSMNAME@_t + cs->dflIndex;
		}

		/* If there are functions for this transition then execute them. */
		if ( trans->funcs != 0 )
			ExecFuncs( trans->funcs, p );

		/* Move to the new state. */
		cs = trans->toState;
	}
finished:
	curState = cs;
}


/**********************************************************************
 * Indicate to the fsm that the input is done. Does cleanup tasks.
 */
void @FSMNAME@::Finish( )
{
	State *cs = curState;
	if ( cs != 0 && cs->isFinState ) {
		/* If finishing in a final state then execute the
		 * out functions for it. (if any). */
		if ( cs->outFuncs != 0 )
			ExecFuncs( cs->outFuncs, NULL );
		accept = 1;
	}
	else {
		/* If we are not in a final state then this
		 * is an error. Move to the error state. */
		curState = 0;
	}
}

";


/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <setjmp.h>
#include <sys/time.h>
#include <sys/types.h>
#include <errno.h>
#include <signal.h>

#ifdef _WIN
#	define size_t int
#	include <winsock.h>
#else
#	include <unistd.h>
#	include <sys/types.h>
#	include <sys/socket.h>
#	include <netinet/in.h>
#	include <netinet/in.h>
#	include <arpa/inet.h>
#	include <netdb.h>
#endif

#include "config.h"
#include "event.h"
#include "support.h"

/* The maximum number of signals we are to support. The real signal limit
 * is dictated by the os. */
#define FIRST_SIGNAL 1
#define LAST_SIGNAL 64

/*
 * Static private data to the select routine. A class is used for
 * the fd sets so we can zero them in the constructor.
 */
struct EventGlobalData
{
	EventGlobalData();

	/* Global copies of fd sets. */
	fd_set readFdSet;
	fd_set writeFdSet;
	fd_set exceptFdSet;
	
	/* Working copied of fds sets. */
	fd_set wk_rfds;
	fd_set wk_wfds;
	fd_set wk_efds;

	/* The number of handlers registered for each signal. */
	int regSignalRef[LAST_SIGNAL+1];
	sigset_t pendSigSet;
};
static EventGlobalData gd;

/* Lists of connections. */
static ReadFdList readFdList;
static WriteFdList writeFdList;
static ExceptFdList exceptFdList;
static SigRegList sigRegList;

/* These must be global as registration may need to modify them. */
static ReadFdList::Iterator readCon;
static WriteFdList::Iterator writeCon;
static ExceptFdList::Iterator exceptCon;
static SigRegList::Iterator signalCon;

/* Was the list iterator modified? */
static bool readConMod = false;
static bool writeConMod = false;
static bool exceptConMod = false;
static bool signalConMod = false;

/* The highest registered fd. */
static int maxFd = -1;

/* Flags used by select loop. */
static bool inDangerZone = false;
static bool sigOccured = false;

/* Jump buf environment used if we need to jump 
 * out of a signal handler. */
static sigjmp_buf env;

/* The signal hndler type: pointer to function. */
typedef void (*SigHanderType)(int);

void SetSigHandler(int sig, SigHanderType handler);
void UnsetSigHandler(int sig);
void SigHandler(int sig);

/* Need to init the fd sets to zero. */
EventGlobalData::EventGlobalData()
{
	/* Start with empty fd sets. */
	FD_ZERO(&readFdSet);
	FD_ZERO(&writeFdSet);
	FD_ZERO(&exceptFdSet);

	FD_ZERO(&wk_rfds);
	FD_ZERO(&wk_wfds);
	FD_ZERO(&wk_efds);

	/* Clear out the signal recorders. */
	memset(regSignalRef, 0, sizeof(regSignalRef));
	sigemptyset( &gd.pendSigSet );

	/* Initialize the connection iterators so that unregistering
	 * does not cause them to change when they are not even in use. */
	readCon = readFdList.slast();
	writeCon = writeFdList.slast();
	exceptCon = exceptFdList.slast();
	signalCon = sigRegList.slast();
}


/***************************************************************
 * Init all the fds to -1, unregistered for read, write, except
 * and set the selector.
 */
EventHandler::EventHandler() : 
		readFd(-1),
		writeFd(-1),
		exceptFd(-1),
		readRegistered(false),
		writeRegistered(false), 
		exceptRegistered(false),
		eventSigRegCount(0)
{
	sigemptyset( &regSignals );
}

/*************************************************************
 * Ensure that the event handler is unregisterd for events.
 */
EventHandler::~EventHandler()
{
	unregisterRead();
	unregisterWrite();
	unregisterExcept();
}

/*
 * Default Event handlers will cause the 
 * connection to be deleted.
 */
int EventHandler::readReady()
{
	unregisterRead();
	return 0;
}
int EventHandler::writeReady()
{
	unregisterWrite();
	return 0;
}
int EventHandler::exceptReady()
{
	unregisterExcept();
	return 0;
}
int EventHandler::signalReady(int sig)
{
	unregisterSignal(sig);
	return 0;
}

/**************************************************************
 * If the connection is not already registered for reading,
 * puts itself on the read fd set list.
 */
void EventHandler::registerRead()
{
	if ( ! readRegistered )
	{
		/* Set the fd and append ourselves to the read Fd list. */
		FD_SET(readFd, &gd.readFdSet);
		readFdList.append(this);

		/* Update maxFd. */
		if ( readFd > maxFd )
			maxFd = readFd;

		/* State is now registered. */
		readRegistered = true;
	}
}

/************************************************************
 * If the connection is not already registered for writing,
 * puts itself on the write fd set list.
 */
void EventHandler::registerWrite()
{
	if ( ! writeRegistered )
	{
		/* Set the fd and append ourselves to the write Fd list. */
		FD_SET(writeFd, &gd.writeFdSet);
		writeFdList.append(this);

		/* Update maxFd. */
		if ( writeFd > maxFd )
			maxFd = writeFd;

		/* State is now registered. */
		writeRegistered = true;
	}
}

/***********************************************************
 * If the connection is not already registered for exceptions,
 * puts itself on the except fd set list.
 */
void EventHandler::registerExcept()
{
	if ( ! exceptRegistered )
	{
		/* Set the fd and append ourselves to the except Fd list. */
		FD_SET(exceptFd, &gd.exceptFdSet);
		exceptFdList.append(this);

		/* Update maxFd. */
		if ( exceptFd > maxFd )
			maxFd = exceptFd;

		/* State is now registered. */
		exceptRegistered = true;
	}
}

/* Register the event handler for a specific signal. */
void EventHandler::registerSignal(int sig)
{
	int isMem = sigismember( &regSignals, sig );
	if ( isMem == 0 ) {
		/* Add to our registered signals set. */
		sigaddset( &regSignals, sig );

		/* If this event handler has not been registered for
		 * any other signals, then put ourselves on the signal
		 * registration list. */
		if ( eventSigRegCount == 0 )
			sigRegList.append(this);
		eventSigRegCount += 1;
			
		/* If the signal was not previousrly registered, then 
		 * set a handler for it. */
		if ( gd.regSignalRef[sig] == 0 )
			SetSigHandler( sig, SigHandler );
		gd.regSignalRef[sig] += 1;
	}
}

/*****************************************************************
 * If the connection is registered for reading, removes itself
 * from the read fd set list.
 */
void EventHandler::unregisterRead()
{
	if ( readRegistered ) {
		/* Unset in the fd sets. */
		FD_CLR(readFd, &gd.readFdSet);
		FD_CLR(readFd, &gd.wk_rfds);

		/* Safely detach from the list. */
		if ( readCon == this ) {
			readConMod = true;
			readCon++;
		}
		readFdList.detach(this);

		/* It would be nice if we could fix maxFd here but that would
		 * require us to walk all registered connections. We will leave 
		 * maxFd unchanged here and fix it in the main select loop where
		 * we need to walk all fds anyways. */

		/* No longer registered. */
		readRegistered = false;
	}
}

/*****************************************************************
 * If the connection is registered for writing, removes itself
 * from the write fd set list.
 */
void EventHandler::unregisterWrite()
{
	if ( writeRegistered ) {
		/* Uset in the fd sets. */
		FD_CLR(writeFd, &gd.writeFdSet);
		FD_CLR(writeFd, &gd.wk_wfds);

		/* Safely detach from the list. */
		if ( writeCon == this ) {
			writeConMod = true;
			writeCon++;
		}
		writeFdList.detach(this);

		/* It would be nice if we could fix maxFd here but that would
		 * require us to walk all registered connections. We will leave 
		 * maxFd unchanged here and fix it in the main select loop where
		 * we need to walk all fds anyways. */

		/* No longer registered. */
		writeRegistered = false;
	}
}

/*****************************************************************
 * If the connection is registered for exceptions, removes itself
 * from the except fd set list.
 */
void EventHandler::unregisterExcept()
{
	if ( exceptRegistered ) {
		/* Uset in the fd sets. */
		FD_CLR(writeFd, &gd.exceptFdSet);
		FD_CLR(writeFd, &gd.wk_efds);

		/* Safely detach from the list. */
		if ( exceptCon == this ) {
			exceptConMod = true;
			exceptCon++;
		}
		exceptFdList.detach(this);

		/* It would be nice if we could fix maxFd here but that would
		 * require us to walk all registered connections. We will leave 
		 * maxFd unchanged here and fix it in the main select loop where
		 * we need to walk all fds anyways. */

		/* No longer registered. */
		exceptRegistered = false;
	}
}

/* Unregister an event handler for a signal. */
void EventHandler::unregisterSignal(int sig)
{
	int isMem = sigismember( &regSignals, sig );
	if ( isMem == 1 ) {
		/* Remove the signal from our set of registered signals. */
		sigdelset( &regSignals, sig );

		/* Do we need to take ourselves off the signal registered list? */
		eventSigRegCount -= 1;
		if ( eventSigRegCount == 0 ) {
			if ( signalCon == this ) {
				signalConMod = true;
				signalCon++;
			}
			sigRegList.detach(this);
		}

		/* Do we need to unregister the global signal handler? */
		gd.regSignalRef[sig] -= 1;
		if ( gd.regSignalRef[sig] == 0 )
			UnsetSigHandler( sig );
	}
}
     
/* Unregister an event handler for any signals it may be registered for. */
void EventHandler::unregisterAllSignals()
{
	for (int sig = FIRST_SIGNAL; sig <= LAST_SIGNAL; sig++ ) {
		/* Is the signal handler set? */
		int isMem = sigismember( &regSignals, sig );

		/* If the os says it is not a valid signal, then err. */
		if ( isMem < 0 )
			break;

		/* Unregister the signal if it is a mem. */
		if ( isMem == 1 )
			unregisterSignal( sig );
	}
}

/*******************************************************
 * Plain open with some fds
 */
int EventHandler::openFds(int rfd, int wfd, int efd)
{
	readFd = rfd;
	writeFd = wfd;
	exceptFd = efd;
	return 0;
}

/****************************************************************
 * Open a connection to some host, port. Sets read, write fd to
 * the opened socket.
 */
int EventHandler::openInet(char *hostname, unsigned short int port)
{
	struct sockaddr_in servername;
	struct hostent *hostinfo;

	/* Create the socket. */
	readFd = writeFd = socket(PF_INET, SOCK_STREAM, 0);
	if (readFd < 0)
		goto fail;

	/* Lookup the host. */
	servername.sin_family = AF_INET;
	servername.sin_port = htons (port);
	hostinfo = gethostbyname (hostname);
	if (hostinfo == NULL)
		goto close_fail;

	servername.sin_addr = *(struct in_addr *) hostinfo->h_addr;

	/* Connect to the listener. */
	if ( connect(readFd, (struct sockaddr *) &servername,
			sizeof(servername)) < 0 ) {
		goto close_fail;
	}

	/* All ok. */
	return 0;

close_fail:
	close(readFd);
fail:
	readFd = writeFd = -1;
	return -1;
}

/********************************************************
 * Opens up an inet listener on the given port.
 */
int EventHandler::listenInet(unsigned short int port)
{
	sockaddr_in sockName;
	int optionVal;

	/* Create the socket. */
	readFd = socket(PF_INET, SOCK_STREAM, 0);
	if (readFd < 0)
		goto fail;

	/* Set it's address to reusable. */
	optionVal = 1;
	setsockopt(readFd, SOL_SOCKET, SO_REUSEADDR,
			(char *)&optionVal, sizeof(int));

	/* Give the socket a name. */
	sockName.sin_family = AF_INET;
	sockName.sin_port = htons (port);
	sockName.sin_addr.s_addr = htonl (INADDR_ANY);
	if ( bind(readFd, (struct sockaddr *) &sockName, sizeof(sockName)) < 0 )
		goto close_fail;
	
	/* Set the socket to listen. */
	if ( listen(readFd, 1) < 0 )
		goto close_fail;

	/* All ok. */
	return 0;

close_fail:
	close(readFd);
fail:
	readFd = -1;
	return -1;
}


/***********************************************
 * Opens up unix namespace listener.
 */
int EventHandler::listenUnix(char *filename)
{
	sockaddr_un sockName;

	/* Create the socket. */
	readFd = socket(PF_INET, SOCK_STREAM, 0);
	if ( readFd < 0 )
		goto fail;

	/* Is the filename too long? */
	if ( strlen(filename) + 1 > sizeof(sockName.sun_path) )
		goto close_fail;

	/* Give the socket a name. */
	sockName.sun_family = AF_UNIX;
	strcpy(sockName.sun_path, filename);
	sockName.sun_path[sizeof(sockName.sun_path) - 1] = 0;
	if ( bind(readFd, (struct sockaddr *) &sockName,
			strlen(filename) + sizeof(sockName.sun_family)) < 0 ) {
		goto close_fail;
	}
	
	/* Set the socket to listen. */
	if ( listen(readFd, 1) < 0 )
		goto close_fail;

	return 0;

close_fail:
	close(readFd);
fail:
	readFd = -1;
	return -1;
}

/***************************************************
 * Register a signal hander.
 */
void SetSigHandler(int sig, SigHanderType handler)
{
	/* Get the existing action for the signal. */
	struct sigaction sa;
	sigaction(sig, NULL, &sa);

	/* Set the handler. We block all other signals while handling
	 * the signal. This will prevent us from missing a signal
	 * because of second signal occuring while already in a signal
	 * handler. If the second does the longjmp then the first will
	 * be lost. */
	sa.sa_handler = handler;
	sigfillset(&sa.sa_mask);
	sa.sa_flags &= ~SA_NODEFER;
	sigaction(sig, &sa, NULL);
}

/***************************************************
 * Unregister a signal hander.
 */
void UnsetSigHandler(int sig)
{
	/* Get the existing action for the signal. */
	struct sigaction sa;
	sigaction(sig, NULL, &sa);

	/* Set the handler to the default */
	sa.sa_handler = SIG_DFL;
	sigaction(sig, &sa, NULL);
}

/**************************************************
 * Generic signal handler used for all signals
 */
void SigHandler(int sig)
{
	struct sigaction sa;

	/* Set the handler again. */
	sigaction(sig, NULL, &sa);
	sa.sa_handler = SigHandler;
	sigaction(sig, &sa, NULL);

	/* Save the old value of sigOccured and declare 
	 * that a signal has occured. */
	bool sigAlready = sigOccured;
	sigOccured = true;

	/* Record that the signal occured. */
	sigaddset( &gd.pendSigSet, sig );
	
	/* If we are in the danger zone and a signal has not already
	 * been recorded then we must jump to before the danger zone. The
	 * timeout will then be properly set to zero. */
	if ( inDangerZone && !sigAlready )
		siglongjmp(env, 1);
}


/****************************************************************
 * Public select loop.
 */
int Selector::loop()
{
	int retVal;

	try
	{
		/* Call the select loop and return it's return value. */
		retVal = doSelectLoop();
	}
	catch ( Exit exit )
	{
		/* If we break out of the select loop, then return the
		 * return value specified with the break. */
		retVal = exit.retVal;
	}
	return retVal;
}

/***********************************************************************
 * Walk the lists of registered fd sets and call any appropriate event
 * handlers.
 */
void Selector::serviceReadyFds()
{
	/* Service all the descriptors that are available for reading. */
	readCon = readFdList.first();
	while ( readCon != readFdList.slast() ) {
		/* Take this opportunity to recalc maxfd. */
		if ( readCon->readFd > maxFd )
			maxFd = readCon->readFd;

		/* If the fd is set then call the event handler. */
		if ( FD_ISSET(readCon->readFd, &gd.wk_rfds) ) {
			/* Init the modified flag. If the readCon is modfied this
			 * will be set and we know not to increment it. */
			readConMod = false;

			/* Execute the handler. */
			int readRes = readCon->readReady();

			/* A negative result means to delete the connection. */
			if ( readRes < 0 )
				delete readCon;

			/* Only if the readCon was not incremented already do increment. */
			if ( ! readConMod )
				readCon++;
		}
		else {
			/* Event handler was not called, safe to go to the
			 * next element in the list. */
			readCon++;
		}
	}

	/* Service all the output descriptors that are available for writing. */
	writeCon = writeFdList.first();
	while ( writeCon != writeFdList.slast() ) {
		/* Take this opportunity to recalc maxfd. */
		if ( writeCon->writeFd > maxFd )
			maxFd = writeCon->writeFd;

		/* If the fd is set then call the event handler. */
		if ( FD_ISSET(writeCon->writeFd, &gd.wk_wfds) ) {
			/* Init the modified flag. If the writeCon is modfied this
			 * will be set and we know not to increment it. */
			writeConMod = false;

			/* Execute the handler. */
			int writeRes = writeCon->writeReady();

			/* A negative return val mean to delete the handler. */
			if ( writeRes < 0 )
				delete writeCon;

			/* Only if the writeCon was not incremented already do increment. */
			if ( ! writeConMod )
				writeCon++;
		}
		else {
			/* Event handler was not called, safe to go to the
			 * next element in the list. */
			writeCon++;
		}
	}

	/* Service all the output descriptors that are available for writing. */
	exceptCon = exceptFdList.first();
	while ( exceptCon != exceptFdList.slast() ) {
		/* Take this opportunity to recalc maxfd. */
		if ( exceptCon->exceptFd > maxFd )
			maxFd = exceptCon->exceptFd;

		/* If the fd is set then call the event handler. */
		if ( FD_ISSET(exceptCon->writeFd, &gd.wk_wfds) ) {
			/* Init the modified flag. If the exceptCon is modfied this
			 * will be set and we know not to increment it. */
			exceptConMod = false;

			/* Execute the handler. */
			int writeRes = exceptCon->exceptReady();

			/* A negative value means to delete the connection. */
			if ( writeRes < 0 )
				delete exceptCon;

			/* Only if the exceptCon was not incremented already do increment. */
			if ( ! exceptConMod )
				exceptCon++;
		}
		else {
			/* Event handler was not called, safe to go to the
			 * next element in the list. */
			exceptCon++;
		}
	}
}

/* Process pending signals. */
void Selector::serviceSignals(sigset_t *sigSet)
{
	/* Walk the set of pending signals. */
	for ( int sig = FIRST_SIGNAL; sig < LAST_SIGNAL; sig++ ) {
		/* Is the sig pending? */
		int isMem = sigismember( sigSet, sig );

		/* break when the os says 'not a valid signal'. */
		if ( isMem < 0 )
			break;
		
		/* Did the signal happen? */
		if ( isMem > 0 ) {
			printf("sig %i occured, walking registered handlers\n", sig);
			/* Walk the list of registered event handlers. */
			signalCon = sigRegList.first();
			while ( signalCon != sigRegList.slast() ) {
				/* If the event handler registered this sig then 
				 * call the event handler. */
				if ( sigismember( &signalCon->regSignals, sig ) == 1 ) {
					/* Init the modified flag. If the signalCon is modfied this
					 * will be set and we know not to increment it. */
					signalConMod = false;

					/* Execute the handler. */
					int eventRes = signalCon->signalReady(sig);

					/* A negative result means to delete the connection. */
					if ( eventRes < 0 )
						delete signalCon;

					/* Only if the signalCon was not incremented already do increment. */
					if ( ! signalConMod )
						signalCon++;
				}
				else {
					/* Event handler was not called, safe to go to the
					 * next element in the list. */
					signalCon++;
				}
			}
		}
	}
}

/***************************************************************
 * Wait for descriptor events and call handlers when they occur.
 */
int Selector::doSelectLoop()
{
	/* This is the entry point for signals that occur while in
	 * the danger zone. */
	sigsetjmp( env, true );

	while ( writeFdList.listLength > 0 ||
			 readFdList.listLength > 0 || 
			 exceptFdList.listLength > 0 )
	{
		/* Default to a blocking select call. */
		struct timeval tv, *ptv = 0;
		int selRes;

		/* Begin the segment of code in which we may need to longjmp
		 * out of the signal handler. */
		inDangerZone = true;

		/* If a signal has occured then use non-blocking select. */
		if ( sigOccured ) {
			ptv = &tv;
			tv.tv_sec = 0;
			tv.tv_usec = 0;
		}

		gd.wk_rfds = gd.readFdSet;
		gd.wk_wfds = gd.writeFdSet;
		gd.wk_efds = gd.exceptFdSet;

		do {
			/* We likely don't need to worry about returning from the select
			 * with EINTR but we handle it for completeness. The reason is that
			 * if there is no timeout then it means sigOccured is false 
			 * and we will longjmp back into the loop from the signal handler if
			 * any signal interrupts the select call. If the timeout is
			 * set a then a signal will not cause a longjmp but the signal
			 * would need to be timed just right to interrupt the select call,
			 * if it is even possible. */
			selRes = select( maxFd+1, &gd.wk_rfds, &gd.wk_wfds, &gd.wk_efds, ptv );
		}
		while ( selRes < 0 && (errno == EINTR || errno == EAGAIN) );

		/* On any other error, return the error. */
		if ( selRes < 0 )
			return selRes;

		/* No longer required to longjmp out of signal handlers. */
		inDangerZone = false;

		/* Handle signals. */
		if ( sigOccured ) {
			sigset_t pendingSigs;

			sigOccured = false;
			pendingSigs = gd.pendSigSet;

			printf("sigOccured\n");
			serviceSignals( &pendingSigs );
		}

		/* While we walk the descriptors we will also take the
		 * opportunity to recacluate the maxFd. Unregistering does 
		 * not cause it to shrink because unregistering should be 
		 * O(1). So in order for it to be able to shrink we must 
		 * reclaculate it.  */
		maxFd = -1;

		serviceReadyFds();
	}
	return 0;
}

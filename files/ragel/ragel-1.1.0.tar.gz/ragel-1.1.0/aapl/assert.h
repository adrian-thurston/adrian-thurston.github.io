/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_ASSERT_H
#define _AAPL_ASSERT_H


/* These assertions should cause segfaults or bus 
 * errors on most machines if they fail. */
#ifdef VERBOSE_ASSERT
#include <stdio.h>

#define ASSERT(condition) { \
	if (!(condition)) { \
		printf("\nASSERT(%s) failed at %s:%i\n",  \
			#condition, __FILE__, __LINE__ ); \
		*((void**)0xffffffff) = 0; \
	} \
}

#define ASSERTNOTREACHED() { \
	printf("\nASSERTNOTREACHED() at %s:%i\n", __FILE__, __LINE__ ); \
	*((void**)0xffffffff) = 0; \
}

#else

#define ASSERT(condition) { \
	if (!(condition)) *((void**)0xffffffff) = 0; \
}

#define ASSERTNOTREACHED() { \
	*((void**)0xffffffff) = 0; \
}

#endif

#endif /* _AAPL_ASSERT_H */

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _BYTE_ORDER_H
#define _BYTE_ORDER_H

#include "config.h"
#include "support.h"

enum ByteOrder {
	LittleEndian,
	BigEndian,
	PdpEndian,
	Unknown
};

/* void DetermineByteOrder()
 * 
 * Initialize the system byte order.
 * Must be done before any calls to Scan Int or Write Int.
 *
 * Will only exist if byte ordering is specified as a run-time test.
 */

/* extern ByteOrder SystemByteOrder;
 *
 * This enum is guaranteed to be set appropriately
 * after the first call to DetermineByteOrder.
 *
 * Will only exist if byte ordering is specified as a run-time test.
 */

#if defined(SBO_RUN_TIME)
	void DetermineByteOrder();
	extern ByteOrder SystemByteOrder;
#elif defined(SBO_LITTLE_ENDIAN)
#	define DetermineByteOrder()
#	define SystemByteOrder LittleEndian
#elif defined(SBO_BIG_ENDIAN)
#	define DetermineByteOrder()
#	define SystemByteOrder BigEndian
#elif defined(SBO_PDP_ENDIAN)
#	define DetermineByteOrder()
#	define SystemByteOrder PdpEndian
#else
#	error "No system byte order was defined."
#endif

/* Scan an integer from a communcations buffer. */
int ScanInt(byte *buf);

/* Write an integer to a communications buffer. */
void WriteInt(byte *buf, int i);

#endif /* _BYTE_ORDER_H */

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include <iostream>
#include <vector>
#include "vector.h"
#include "vectore.h"
#include "vectorel.h"
#include "vectorec.h"
#include "vectorle.h"
#include "vectorl.h"
#include "vectorlc.h"
#include "vectorce.h"
#include "vectorcl.h"
#include "vectorc.h"
#include "vectorr.h"
#include "assert.h"

template class Vector<int>;
template class VectorE<int>;
template class VectorL<int>;
template class VectorC<int>;
template class VectorR<int>;

void testVector1()
{
	int pos, len;
	char c, string[200];
	VectorL< char > v;

	while( scanf("%c", &c) == 1 )
	{
		switch (c) {
			case 'a':
				/* Get the string to append. */
				fgets(string, 200, stdin);

				/* hack off the newline. */
				len = strlen(string) - 1;
				string[len] = 0;

				v.append(string, len);
				break;

			case 'p':
				/* Get the string to prepend. */
				fgets(string, 200, stdin);

				/* hack off the newline. */
				len = strlen(string) - 1;
				string[len] = 0;

				v.prepend(string, len);
				break;

			case 's':
				/* Get the string to set. */
				fgets(string, 200, stdin);

				/* hack off the newline. */
				len = strlen(string) - 1;
				string[len] = 0;

				v.setAs(string, len);
				break;

			case 'r':
				/* Get the pos */
				scanf("%i ", &pos);

				/* Get the string to replace. */
				fgets(string, 200, stdin);

				/* hack off the newline. */
				len = strlen(string) - 1;
				string[len] = 0;

				v.replace(pos, string, len);
				break;
				
			case 'i':
				/* Get the pos */
				scanf("%i ", &pos);

				/* Get the string to insert. */
				fgets(string, 200, stdin);

				/* hack off the newline. */
				len = strlen(string) - 1;
				string[len] = 0;

				v.insert(pos, string, len);
				break;
				
			case 'd':
				/* Get the length to remove. */
				scanf("%i", &pos);
				scanf("%i", &len);
				v.remove(pos, len);
				break;

			case 'w':
				printf("L: %i  AL: %i\n", v.tableLength, v.allocLength);
				fwrite(v.table, 1, v.tableLength, stdout);
				fputc('\n', stdout);
				break;

			case 'q':
				goto end;

		}
	}

end:
	fwrite(v.table, 1, v.tableLength, stdout);
	fputc('\n', stdout);
}


/* Globals that the constructors and destructor count with. */
int defaultCount = 0, copyCount = 0, destructorCount = 0;

/* Assert the test, reset the globals for the next test. */
void assert(bool test)
{
	ASSERT( test );
	defaultCount = 0;
	copyCount = 0;
	destructorCount = 0;
}

/* Data structure whos constructors and destructor count callings. */
struct theData
{
	theData() : i(0) { defaultCount++; }
	theData(const theData &d) : i(1) { copyCount++; }
	~theData() { destructorCount++; }
	int i;
};

void testDelete()
{
	/* Simple Construct calls. */
	theData sampleData[10];
	assert( defaultCount == 10 );
	
	/* Initialization. */
	VectorL< theData > v1(10);
	assert( defaultCount == 10 );

	/* Delete some. */
	v1.remove( 5, 3 );
	assert( destructorCount == 3 );

	/* Delete some more. */
	v1.remove( 0, 4 );
	assert( destructorCount == 4 );

	/* Test length. */
	assert( v1.tableLength == 3 );
}

void testInsert()
{
	/* Simple Construct calls. */
	theData sampleData[10];
	assert( defaultCount == 10 );
	
	/* Initialization. */
	VectorL< theData > v1(6);
	assert( defaultCount == 6 );

	/* Copy Constructor. */
	VectorL< theData > v2(v1);
	assert( copyCount == 6 );

	/* Insert, some shifted over. */
	v1.insert(1, sampleData, 4);
	assert( v1.tableLength == 10 && destructorCount == 0 && copyCount == 4 );

	/* Insert, none shifted over. */
	v1.insert(10, sampleData, 4);
	assert( defaultCount == 0 && copyCount == 4 );

	/* Insert, none shifted over, some constructors called. */
	v1.insert(20, sampleData, 5);
	assert( destructorCount == 0 && copyCount == 5 && defaultCount == 6 );

	/* Ensure length is good. */
	assert( v1.tableLength == 25 );
}

void testSetAs()
{
	/* Simple Construct calls. */
	theData sampleData[10];
	assert( defaultCount == 10 );
	
	/* Initialization. */
	VectorL< theData > v1(6);
	assert( defaultCount == 6 );

	v1.setAs( sampleData, 10 );
	assert( destructorCount == 6 && copyCount == 10 && defaultCount == 0 );
}

void testReplace()
{
	/* Simple Construct calls. */
	theData sampleData[10];
	assert( defaultCount == 10 );
	
	/* Initialization. */
	VectorL< theData > v1(4);
	assert( defaultCount == 4 );

	/* Copy Constructor. */
	VectorL< theData > v2(v1);
	assert( copyCount == 4 );

	/* Replace, some remove, some new. */
	v1.replace(1, sampleData, 4);
	assert( destructorCount == 3 && copyCount == 4 );

	/* Replace, all remove. */
	v1.replace(0, sampleData, 5);
	assert( destructorCount == 5 && copyCount == 5 );

	/* Replace, all new. */
	v1.replace(5, sampleData, 2);
	assert( destructorCount == 0 && copyCount == 2 );

	/* Replace, all new, some must be initted. */
	v1.replace(10, sampleData, 2);
	assert( destructorCount == 0 && defaultCount == 3 && copyCount == 2 );

	/* Ensure length is good. */
	assert( v1.tableLength == 12 );
}

void testWithValues()
{
	VectorL< int > v1;
	VectorL< int > v2;

	int i = 1;
	v1.append( i );
	v2.setAs(v1);
	i = 2;
	v1.insert( 0, i );
	assert( v1.table[0] == 2 && v2.table[0] == 1 );

}

void testOperators1()
{
	VectorL<int> v;
	v.append( 10 );
	v.append( 11 );

	printf("%i\n", v.size());
	printf("%i\n", *((int*)v));
	printf("%i\n", v[1]);

	VectorL<int>::Iterator it;
	for ( it = v.first(); it != v.slast(); it+=1)
		cout << *it << endl;

	for ( it = v.last(); it != v.sfirst(); it-=1)
		cout << *it << endl;
}

void testOperators2()
{
	Vector< Vector<int> > vvi(1);
	Vector< Vector<int> >::Iterator it;
	for ( it = vvi; it != vvi.slast(); it++ )
		cout << it->size() << endl;
}


int main()
{
	testReplace();
	testInsert();
	testSetAs();
	testDelete();
	testWithValues();
	testOperators1();
	testOperators2();
	return 0;
}

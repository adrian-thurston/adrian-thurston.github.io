/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

#if defined( VECSET_EXPN_TABLE )
#	include "vector.h"
#	define VectSet VectSet
#	define Vector Vector
#elif defined( VECSET_LINEAR_TABLE )
#	include "vectorl.h"
#	define VectSet VectSetL
#	define Vector VectorL
#elif defined( VECSET_CONST_TABLE )
#	include "vectorc.h"
#	define VectSet VectSetC
#	define Vector VectorL
#else
#	error "no vector table type"
#endif

template <class KeyT, class Compare > class VectSet
		: public Vector<KeyT>
{
public:
#if defined( VECSET_CONST_TABLE )
	VectSet(int allocLength) : Vector<KeyT>(allocLength) {}
#else
	VectSet() { }
#endif

	typedef Vector<KeyT> BaseType;

	/* Set items in the vector set. */
	void Set(const VectSet<KeyT, Compare> &otherSet);
	bool Set(const KeyT &val, KeyT **lastFound = NULL);

	/* Unset an item in the vector set. */
	bool UnSet(const KeyT &val);

	/* Find and is set. */
	bool IsSet(const KeyT &val);
	KeyT *Find(const KeyT &val, KeyT **lastFound = NULL);
};

template < class KeyT, class Compare > KeyT *VectSet<KeyT, Compare>::
		Find(const KeyT &val, KeyT **lastFound)
{
	KeyT *lower, *mid, *upper;
	int keyRelation;

	if (! table) {
		if ( lastFound != NULL )
			*lastFound = 0;
		return 0;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1) {
		if ( upper < lower ) {
			if ( lastFound != NULL )
				*lastFound = 0;
			return 0;
		}

		mid = lower + ( (upper-lower) / 2);
		
		keyRelation = Compare::Compare( val, *mid );
		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* if ( keyRelation == 0 ) */ {
			if ( lastFound != NULL )
				*lastFound = mid;
			return mid;
		}
	}
}


template < class KeyT, class Compare > 
		bool VectSet<KeyT, Compare>::IsSet(const KeyT &val)
{
	KeyT *pos = Find(val);
	return pos != 0;
}

template< class KeyT, class Compare >
		bool VectSet<KeyT, Compare>::UnSet(const KeyT &val)
{
	KeyT *pos = Find(val);
	if (pos != 0) {
		BaseType::remove(pos - table);
		return true;
	}
	return false;
}

template< class KeyT, class Compare >
		bool VectSet<KeyT, Compare>::Set(const KeyT &val, KeyT **lastFound)
{
	KeyT *lower, *mid, *upper;
	int keyRelation, insertPos;

	if (! table) {
		/* table is empty. Do the insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower ) {
			/* Did not find the key in the table. Do the insert. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		
		keyRelation = Compare::Compare( val, *mid );
		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* if ( keyRelation == 0 ) */ {
			if ( lastFound != NULL )
				*lastFound = mid;
			return false;
		}
	}

Insert:
    /* Get the insert pos. */
    insertPos = lower - table;

    /* Do the insert. */
    BaseType::insert(insertPos, val);

	/* Set lastFound. */
	if ( lastFound != NULL )
		*lastFound = table + insertPos;
    
    return true; 
}

template < class KeyT, class Compare >
		void VectSet<KeyT, Compare>::
		Set(const VectSet<KeyT, Compare> &otherSet)
{
	KeyT *otherItem = otherSet.table;
	int otherLen = otherSet.tableLength;
	for (int i = 0; i < otherLen; i++, otherItem++)
		Set(*otherItem);
}

#undef VectSet
#undef Vector

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _GOTOCODEGEN_H
#define _GOTOCODEGEN_H

#include <iostream>
#include <fstream>
#include "fsmmachine.h"
#include "parsetree.h"
#include "fsmcodegen.h"


#define codegen

/***********************************************************************
 * class GotoCodeGen
 */
class GotoCodeGen : public FsmCodeGen
{
public:
	GotoCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );

	void codegen FUNC_SWITCH();
	void codegen JUMP_IN_SWITCH();
	void codegen STATE_GOTOS();
	void codegen EXIT_STATES();
	void codegen ERROR_LABEL();
	void codegen FINISH_SWITCH();

protected:
	void emitTransGoto( int curState, FsmMachTrans *trans );

	/* This gets set if the error label is needed. */
	bool needErrorLabel;
private:
	void registerSections();
};

/***********************************************************************
 * class CGotoCodeGen
 */
class CGotoCodeGen : public GotoCodeGen
{
public:
	CGotoCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );

	void codegen FSM_PREFIX();

protected:
	static char header[];
	static char code[];

	void stateOutFunc(FsmMachState *state);
	void transFunc(FsmMachTrans *trans);
private:
	void registerSections();
};

/***********************************************************************
 * class CCGotoCodeGen
 */
class CCGotoCodeGen : public GotoCodeGen
{
public:
	CCGotoCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );

	void codegen FSM_PREFIX();

protected:
	static char header[];
	static char code[];

	void stateOutFunc(FsmMachState *state);
	void transFunc(FsmMachTrans *trans);
private:
	void registerSections();
};


#endif /* _GOTOCODEGEN_H */

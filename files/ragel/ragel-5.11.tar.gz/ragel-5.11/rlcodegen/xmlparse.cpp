/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Using locations.  */
#define YYLSP_NEEDED 1



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TAG_unknown = 258,
     TAG_ragel = 259,
     TAG_ragel_def = 260,
     TAG_host = 261,
     TAG_state_list = 262,
     TAG_state = 263,
     TAG_trans_list = 264,
     TAG_t = 265,
     TAG_machine = 266,
     TAG_start_state = 267,
     TAG_action_list = 268,
     TAG_action_table_list = 269,
     TAG_action = 270,
     TAG_action_table = 271,
     TAG_alphtype = 272,
     TAG_element = 273,
     TAG_getkey = 274,
     TAG_state_actions = 275,
     TAG_entry_points = 276,
     TAG_sub_action = 277,
     TAG_cond_space_list = 278,
     TAG_cond_space = 279,
     TAG_cond_list = 280,
     TAG_c = 281,
     TAG_text = 282,
     TAG_goto = 283,
     TAG_call = 284,
     TAG_next = 285,
     TAG_goto_expr = 286,
     TAG_call_expr = 287,
     TAG_next_expr = 288,
     TAG_ret = 289,
     TAG_pchar = 290,
     TAG_char = 291,
     TAG_hold = 292,
     TAG_curs = 293,
     TAG_targs = 294,
     TAG_entry = 295,
     TAG_exec = 296,
     TAG_data = 297,
     TAG_lm_switch = 298,
     TAG_init_act = 299,
     TAG_set_act = 300,
     TAG_set_tokend = 301,
     TAG_get_tokend = 302,
     TAG_init_tokstart = 303,
     TAG_set_tokstart = 304,
     TAG_write = 305,
     TAG_curstate = 306,
     TAG_access = 307,
     TAG_break = 308,
     TAG_option = 309,
     XML_Word = 310,
     XML_Literal = 311
   };
#endif
/* Tokens.  */
#define TAG_unknown 258
#define TAG_ragel 259
#define TAG_ragel_def 260
#define TAG_host 261
#define TAG_state_list 262
#define TAG_state 263
#define TAG_trans_list 264
#define TAG_t 265
#define TAG_machine 266
#define TAG_start_state 267
#define TAG_action_list 268
#define TAG_action_table_list 269
#define TAG_action 270
#define TAG_action_table 271
#define TAG_alphtype 272
#define TAG_element 273
#define TAG_getkey 274
#define TAG_state_actions 275
#define TAG_entry_points 276
#define TAG_sub_action 277
#define TAG_cond_space_list 278
#define TAG_cond_space 279
#define TAG_cond_list 280
#define TAG_c 281
#define TAG_text 282
#define TAG_goto 283
#define TAG_call 284
#define TAG_next 285
#define TAG_goto_expr 286
#define TAG_call_expr 287
#define TAG_next_expr 288
#define TAG_ret 289
#define TAG_pchar 290
#define TAG_char 291
#define TAG_hold 292
#define TAG_curs 293
#define TAG_targs 294
#define TAG_entry 295
#define TAG_exec 296
#define TAG_data 297
#define TAG_lm_switch 298
#define TAG_init_act 299
#define TAG_set_act 300
#define TAG_set_tokend 301
#define TAG_get_tokend 302
#define TAG_init_tokstart 303
#define TAG_set_tokstart 304
#define TAG_write 305
#define TAG_curstate 306
#define TAG_access 307
#define TAG_break 308
#define TAG_option 309
#define XML_Word 310
#define XML_Literal 311




/* Copy the first part of user declarations.  */
#line 22 "xmlparse.y"


#include <iostream>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include "rlcodegen.h"
#include "vector.h"
#include "xmlparse.h"
#include "gendata.h"

using std::cerr;
using std::endl;

char *sourceFileName;
char *attrKey;
char *attrValue;
int curAction;
int curActionTable;
int curTrans;
int curState;
int curCondSpace;
int curStateCond;

Key readKey( char *td, char **end );
long readOffsetPtr( char *td, char **end );
unsigned long readLength( char *td );

CodeGenMap codeGenMap;



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 56 "xmlparse.y"
typedef union YYSTYPE {
	/* General data types. */
	char c;
	char *data;
	int integer;
	AttrList *attrList;

	/* Inline parse tree items. */
	InlineItem *ilitem;
	InlineList *illist;
} YYSTYPE;
/* Line 196 of yacc.c.  */
#line 241 "xmlparse.cpp"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 219 of yacc.c.  */
#line 265 "xmlparse.cpp"

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T) && (defined (__STDC__) || defined (__cplusplus))
# include <stddef.h> /* INFRINGES ON USER NAME SPACE */
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if defined (__STDC__) || defined (__cplusplus)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     define YYINCLUDED_STDLIB_H
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2005 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM ((YYSIZE_T) -1)
#  endif
#  ifdef __cplusplus
extern "C" {
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if (! defined (malloc) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if (! defined (free) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifdef __cplusplus
}
#  endif
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYLTYPE_IS_TRIVIAL) && YYLTYPE_IS_TRIVIAL \
             && defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short int yyss;
  YYSTYPE yyvs;
    YYLTYPE yyls;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short int) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short int yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  6
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   587

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  61
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  85
/* YYNRULES -- Number of rules. */
#define YYNRULES  137
/* YYNRULES -- Number of states. */
#define YYNSTATES  426

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   311

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    58,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      57,    60,    59,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     5,     6,    13,    18,    21,    22,    26,
      29,    30,    32,    34,    40,    45,    52,    57,    60,    61,
      63,    65,    67,    69,    71,    73,    83,    86,    87,    95,
     103,   112,   121,   130,   137,   141,   144,   145,   147,   149,
     151,   153,   155,   157,   165,   175,   178,   179,   188,   195,
     200,   203,   204,   211,   216,   219,   220,   222,   224,   226,
     234,   241,   246,   249,   250,   258,   265,   270,   273,   274,
     283,   290,   295,   298,   299,   309,   312,   313,   315,   317,
     319,   321,   323,   325,   327,   329,   331,   333,   335,   337,
     339,   341,   343,   345,   347,   349,   351,   353,   355,   357,
     359,   361,   370,   378,   386,   394,   403,   412,   421,   429,
     437,   445,   453,   461,   469,   477,   486,   494,   504,   507,
     508,   518,   526,   534,   542,   551,   559,   567,   575,   582,
     587,   590,   591,   600,   607,   612,   615,   617
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
      62,     0,    -1,    63,    -1,    -1,    64,    67,    57,    58,
       4,    59,    -1,    57,     4,    65,    59,    -1,    65,    66,
      -1,    -1,    55,    60,    56,    -1,    67,    68,    -1,    -1,
      69,    -1,    71,    -1,    70,    57,    58,     6,    59,    -1,
      57,     6,    65,    59,    -1,    72,    73,    57,    58,     5,
      59,    -1,    57,     5,    65,    59,    -1,    73,    74,    -1,
      -1,    78,    -1,    79,    -1,    80,    -1,    81,    -1,    82,
      -1,    75,    -1,    57,    50,    65,    59,    76,    57,    58,
      50,    59,    -1,    76,    77,    -1,    -1,    57,    54,    59,
      57,    58,    54,    59,    -1,    57,    17,    59,    57,    58,
      17,    59,    -1,    57,    19,    59,   110,    57,    58,    19,
      59,    -1,    57,    52,    59,   110,    57,    58,    52,    59,
      -1,    57,    51,    59,   110,    57,    58,    51,    59,    -1,
      83,    84,    57,    58,    11,    59,    -1,    57,    11,    59,
      -1,    84,    85,    -1,    -1,    86,    -1,    87,    -1,    90,
      -1,   106,    -1,   138,    -1,   142,    -1,    57,    12,    59,
      57,    58,    12,    59,    -1,    57,    21,    65,    59,    88,
      57,    58,    21,    59,    -1,    88,    89,    -1,    -1,    57,
      40,    65,    59,    57,    58,    40,    59,    -1,    91,    92,
      57,    58,     7,    59,    -1,    57,     7,    65,    59,    -1,
      92,    93,    -1,    -1,    94,    95,    57,    58,     8,    59,
      -1,    57,     8,    65,    59,    -1,    95,    96,    -1,    -1,
      97,    -1,    98,    -1,   102,    -1,    57,    20,    59,    57,
      58,    20,    59,    -1,    99,   100,    57,    58,    25,    59,
      -1,    57,    25,    65,    59,    -1,   100,   101,    -1,    -1,
      57,    26,    59,    57,    58,    26,    59,    -1,   103,   104,
      57,    58,     9,    59,    -1,    57,     9,    65,    59,    -1,
     104,   105,    -1,    -1,    57,    10,    65,    59,    57,    58,
      10,    59,    -1,   107,   108,    57,    58,    13,    59,    -1,
      57,    13,    65,    59,    -1,   108,   109,    -1,    -1,    57,
      15,    65,    59,   110,    57,    58,    15,    59,    -1,   110,
     111,    -1,    -1,   112,    -1,   113,    -1,   114,    -1,   115,
      -1,   116,    -1,   117,    -1,   118,    -1,   119,    -1,   127,
      -1,   120,    -1,   121,    -1,   122,    -1,   123,    -1,   124,
      -1,   125,    -1,   126,    -1,   128,    -1,   131,    -1,   133,
      -1,   132,    -1,   134,    -1,   135,    -1,   136,    -1,   137,
      -1,    57,    27,    65,    59,    57,    58,    27,    59,    -1,
      57,    28,    59,    57,    58,    28,    59,    -1,    57,    29,
      59,    57,    58,    29,    59,    -1,    57,    30,    59,    57,
      58,    30,    59,    -1,    57,    31,    59,   110,    57,    58,
      31,    59,    -1,    57,    32,    59,   110,    57,    58,    32,
      59,    -1,    57,    33,    59,   110,    57,    58,    33,    59,
      -1,    57,    34,    59,    57,    58,    34,    59,    -1,    57,
      35,    59,    57,    58,    35,    59,    -1,    57,    36,    59,
      57,    58,    36,    59,    -1,    57,    37,    59,    57,    58,
      37,    59,    -1,    57,    38,    59,    57,    58,    38,    59,
      -1,    57,    39,    59,    57,    58,    39,    59,    -1,    57,
      40,    59,    57,    58,    40,    59,    -1,    57,    41,    59,
     110,    57,    58,    41,    59,    -1,    57,    53,    59,    57,
      58,    53,    59,    -1,    57,    43,    65,    59,   129,    57,
      58,    43,    59,    -1,   129,   130,    -1,    -1,    57,    22,
      65,    59,   110,    57,    58,    22,    59,    -1,    57,    45,
      59,    57,    58,    45,    59,    -1,    57,    47,    59,    57,
      58,    47,    59,    -1,    57,    46,    59,    57,    58,    46,
      59,    -1,    57,    22,    59,   110,    57,    58,    22,    59,
      -1,    57,    48,    59,    57,    58,    48,    59,    -1,    57,
      44,    59,    57,    58,    44,    59,    -1,    57,    49,    59,
      57,    58,    49,    59,    -1,   139,   140,    57,    58,    14,
      59,    -1,    57,    14,    65,    59,    -1,   140,   141,    -1,
      -1,    57,    16,    65,    59,    57,    58,    16,    59,    -1,
     143,   144,    57,    58,    23,    59,    -1,    57,    23,    65,
      59,    -1,   144,   145,    -1,   145,    -1,    57,    24,    65,
      59,    57,    58,    24,    59,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   161,   161,   162,   169,   174,   184,   188,   193,   199,
     199,   203,   203,   206,   213,   225,   233,   262,   262,   266,
     267,   268,   269,   270,   271,   274,   294,   294,   298,   315,
     322,   329,   336,   343,   350,   355,   355,   359,   360,   361,
     362,   363,   364,   367,   374,   383,   383,   387,   400,   405,
     417,   417,   421,   428,   435,   435,   439,   440,   441,   444,
     457,   462,   474,   474,   478,   488,   495,   507,   507,   511,
     523,   528,   540,   540,   544,   565,   570,   576,   577,   578,
     579,   580,   581,   582,   583,   584,   585,   586,   587,   588,
     589,   590,   591,   592,   593,   594,   595,   596,   597,   598,
     599,   602,   609,   617,   625,   633,   641,   649,   657,   663,
     669,   675,   681,   687,   693,   701,   709,   716,   730,   734,
     739,   753,   760,   766,   773,   781,   787,   793,   800,   805,
     817,   817,   821,   851,   856,   868,   869,   872
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TAG_unknown", "TAG_ragel",
  "TAG_ragel_def", "TAG_host", "TAG_state_list", "TAG_state",
  "TAG_trans_list", "TAG_t", "TAG_machine", "TAG_start_state",
  "TAG_action_list", "TAG_action_table_list", "TAG_action",
  "TAG_action_table", "TAG_alphtype", "TAG_element", "TAG_getkey",
  "TAG_state_actions", "TAG_entry_points", "TAG_sub_action",
  "TAG_cond_space_list", "TAG_cond_space", "TAG_cond_list", "TAG_c",
  "TAG_text", "TAG_goto", "TAG_call", "TAG_next", "TAG_goto_expr",
  "TAG_call_expr", "TAG_next_expr", "TAG_ret", "TAG_pchar", "TAG_char",
  "TAG_hold", "TAG_curs", "TAG_targs", "TAG_entry", "TAG_exec", "TAG_data",
  "TAG_lm_switch", "TAG_init_act", "TAG_set_act", "TAG_set_tokend",
  "TAG_get_tokend", "TAG_init_tokstart", "TAG_set_tokstart", "TAG_write",
  "TAG_curstate", "TAG_access", "TAG_break", "TAG_option", "XML_Word",
  "XML_Literal", "'<'", "'/'", "'>'", "'='", "$accept", "input",
  "TagRagel", "TagRagelHead", "AttributeList", "Attribute",
  "HostOrDefList", "HostOrDef", "TagHost", "TagHostHead", "TagRagelDef",
  "RagelDefHead", "RagelDefItemList", "RagelDefItem", "TagWrite",
  "OptionList", "TagOption", "TagAlphType", "TagGetKeyExpr",
  "TagAccessExpr", "TagCurStateExpr", "TagMachine", "TagMachineHead",
  "MachineItemList", "MachineItem", "TagStartState", "TagEntryPoints",
  "EntryPointList", "TagEntry", "TagStateList", "TagStateListHead",
  "StateList", "TagState", "TagStateHead", "StateItemList", "StateItem",
  "TagStateActions", "TagStateCondList", "TagStateCondListHead",
  "StateCondList", "StateCond", "TagTransList", "TagTransListHead",
  "TransList", "TagTrans", "TagActionList", "TagActionListHead",
  "ActionList", "TagAction", "InlineList", "InlineItem", "TagText",
  "TagGoto", "TagCall", "TagNext", "TagGotoExpr", "TagCallExpr",
  "TagNextExpr", "TagRet", "TagPChar", "TagChar", "TagHold", "TagCurs",
  "TagTargs", "TagIlEntry", "TagExec", "TagBreak", "TagLmSwitch",
  "LmActionList", "TagInlineAction", "TagLmSetActId", "TagLmGetTokEnd",
  "TagLmSetTokEnd", "TagSubAction", "TagLmInitTokStart", "TagLmInitAct",
  "TagLmSetTokStart", "TagActionTableList", "TagActionTableListHead",
  "ActionTableList", "TagActionTable", "TagCondSpaceList",
  "TagCondSpaceListHead", "CondSpaceList", "TagCondSpace", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short int yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,    60,    47,    62,
      61
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,    61,    62,    62,    63,    64,    65,    65,    66,    67,
      67,    68,    68,    69,    70,    71,    72,    73,    73,    74,
      74,    74,    74,    74,    74,    75,    76,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    84,    85,    85,    85,
      85,    85,    85,    86,    87,    88,    88,    89,    90,    91,
      92,    92,    93,    94,    95,    95,    96,    96,    96,    97,
      98,    99,   100,   100,   101,   102,   103,   104,   104,   105,
     106,   107,   108,   108,   109,   110,   110,   111,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   129,
     130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
     140,   140,   141,   142,   143,   144,   144,   145
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     0,     6,     4,     2,     0,     3,     2,
       0,     1,     1,     5,     4,     6,     4,     2,     0,     1,
       1,     1,     1,     1,     1,     9,     2,     0,     7,     7,
       8,     8,     8,     6,     3,     2,     0,     1,     1,     1,
       1,     1,     1,     7,     9,     2,     0,     8,     6,     4,
       2,     0,     6,     4,     2,     0,     1,     1,     1,     7,
       6,     4,     2,     0,     7,     6,     4,     2,     0,     8,
       6,     4,     2,     0,     9,     2,     0,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     8,     7,     7,     7,     8,     8,     8,     7,     7,
       7,     7,     7,     7,     7,     8,     7,     9,     2,     0,
       9,     7,     7,     7,     8,     7,     7,     7,     6,     4,
       2,     0,     8,     6,     4,     2,     1,     8
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       3,     0,     0,     2,    10,     7,     1,     0,     0,     0,
       9,    11,     0,    12,    18,     0,     5,     6,     7,     7,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    17,
      24,    19,    20,    21,    22,    23,    36,     8,    16,    14,
       4,     0,     0,     0,     0,     7,     0,     0,     0,     0,
      13,    34,     0,    76,     0,    76,    76,     0,     0,    35,
      37,    38,    39,    51,    40,    73,    41,   131,    42,     0,
       0,     0,    27,     0,     0,    15,     7,     0,     7,     7,
       7,     7,     0,     0,     0,     0,     0,     0,   136,     0,
       0,    75,    77,    78,    79,    80,    81,    82,    83,    84,
      86,    87,    88,    89,    90,    91,    92,    85,    93,    94,
      96,    95,    97,    98,    99,   100,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    50,    55,     0,
      72,     0,   130,     7,     0,   135,     0,     0,     7,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     7,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    26,     0,     0,    49,     0,    71,   129,
      46,   134,    33,     7,     0,     0,     7,     0,     7,     0,
       0,     0,    29,    76,     0,     0,     0,     0,    76,    76,
      76,     0,     0,     0,     0,     0,     0,     0,    76,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    54,    56,    57,
      63,    58,    68,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   119,     0,     0,     0,     0,
       0,     0,     0,    30,     0,     0,    32,    31,     0,     0,
      45,    53,    48,     7,     0,     7,     0,     0,     0,    76,
      70,     0,   128,     0,   133,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      25,    43,     7,     0,     0,     0,     0,     0,     0,    62,
       0,    67,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   118,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    66,     0,    61,    52,     0,     0,     7,
       0,     0,     0,     0,     0,     0,   102,   103,   104,     0,
       0,     0,   108,   109,   110,   111,   112,   113,   114,     0,
       7,     0,   126,   121,   123,   122,   125,   127,   116,     0,
       0,    44,     0,     0,     0,     0,     0,     0,     0,   137,
     124,   101,   105,   106,   107,   115,     0,     0,    28,     0,
       0,     0,    60,     0,    65,     0,   132,    76,   117,     0,
      59,     0,     0,    74,     0,     0,     0,     0,     0,    47,
      64,     0,     0,    69,     0,   120
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     2,     3,     4,     8,    17,     7,    10,    11,    12,
      13,    14,    22,    29,    30,   116,   163,    31,    32,    33,
      34,    35,    36,    49,    59,    60,    61,   213,   260,    62,
      63,    83,   127,   128,   175,   217,   218,   219,   220,   267,
     309,   221,   222,   268,   311,    64,    65,    84,   130,    71,
      91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   291,   332,
     109,   110,   111,   112,   113,   114,   115,    66,    67,    85,
     132,    68,    69,    87,    88
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -53
static const short int yypact[] =
{
     -34,    37,    43,   -53,   -53,   -53,   -53,    11,   -30,     1,
     -53,   -53,    12,   -53,   -53,    10,   -53,   -53,   -53,   -53,
      67,    -7,    30,    68,   -27,   -25,    69,   120,    -3,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,    70,    71,    73,    74,   -53,    75,    80,   122,    83,
     -53,   -53,    84,   -53,   -20,   -53,   -53,    85,    -2,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,    86,
      87,    90,   -53,    91,    92,   -53,   -53,    93,   -53,   -53,
     -53,   -53,   131,    94,    96,    97,   126,   100,   -53,   142,
      45,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   119,   134,   166,   -17,
     127,   -15,    -9,    40,    41,   130,    -6,   -53,   -53,     7,
     -53,     8,   -53,   -53,    -4,   -53,   132,   149,   -53,   157,
     159,   161,   162,   163,   164,   167,   168,   169,   170,   171,
     172,   173,   174,   -53,   175,   176,   177,   178,   179,   180,
     181,   206,   -21,   -53,   135,   133,   -53,   183,   -53,   -53,
     -53,   -53,   -53,   -53,   235,   187,   -53,   233,   -53,   249,
      42,   248,   -53,   -53,    47,   215,   216,   218,   -53,   -53,
     -53,   219,   220,   224,   225,   226,   243,   251,   -53,    49,
     252,   253,   255,   256,   257,   260,   261,   262,   263,   140,
     264,   265,   266,   268,    50,   267,     6,   -53,   -53,   -53,
     -53,   -53,   -53,    52,   269,    55,   270,   273,   274,   275,
     277,   278,   279,   280,   282,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   293,   -53,   295,   296,   313,   321,
     322,   323,   326,   -53,   328,   276,   -53,   -53,   327,   -22,
     -53,   -53,   -53,   -53,   344,   -53,   307,   354,   355,   -53,
     -53,   356,   -53,   358,   -53,   221,   359,   292,   298,   312,
     258,   329,   361,   384,   400,   407,   408,   281,   405,   409,
     393,   391,   406,   422,   429,   430,   428,   431,   446,   423,
     -53,   -53,   -53,   461,    57,   450,    58,   449,   -13,   -53,
      -1,   -53,   452,   453,   488,   491,   487,   458,   459,   460,
     485,   489,   490,   463,   465,   466,   467,   468,   469,   470,
     479,    -5,   -53,   471,   472,   473,   474,   475,   476,   477,
     483,    63,   480,   -53,   482,   -53,   -53,   484,   513,   -53,
     532,   425,   526,   486,   492,   493,   -53,   -53,   -53,   494,
     495,   496,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   497,
     -53,   501,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   498,
     502,   -53,   527,   503,   499,    64,   504,   531,   505,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,    66,   506,   -53,   508,
     509,   511,   -53,   510,   -53,   512,   -53,   -53,   -53,   521,
     -53,   522,   514,   -53,   516,   515,   517,   539,   457,   -53,
     -53,   518,   528,   -53,   519,   -53
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
     -53,   -53,   -53,   -53,   -18,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -52,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,   -53,
     -53,   -53,   -53,   -53,   500
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const unsigned short int yytable[] =
{
      24,    25,   173,    73,    74,    76,    18,    19,    42,   349,
      77,    78,    79,   347,    43,   263,    44,   370,   302,    80,
     133,    81,   176,     1,   178,    15,   264,    54,    15,    16,
      15,   265,    38,   208,    39,    15,   303,   209,    15,    72,
      15,     5,   166,     6,   168,   348,    15,    45,    46,    47,
     169,    27,   174,   371,   181,    48,    82,   350,   119,    20,
     121,   122,   123,   124,   266,   177,   179,   137,     9,    21,
      23,    26,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,    28,   153,   154,
     155,   156,   157,   158,   159,    15,    15,    15,   160,   170,
     171,   227,    15,   161,    15,    15,   230,    15,   245,   261,
      15,   269,    15,    15,   271,   180,   343,   345,    15,    15,
     184,    15,   380,   403,    37,   407,    41,    57,    40,    50,
      51,   229,    52,    53,    55,   199,   234,   235,   236,    56,
      58,    70,   125,    86,    75,    89,   244,    90,   117,   118,
     133,   126,   120,   129,   131,   214,   137,   134,   223,   136,
     225,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   162,   153,   154,   155,
     156,   157,   158,   159,   167,   211,   210,   160,   137,   172,
     255,   182,   164,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   183,   153,
     154,   155,   156,   157,   158,   159,   185,   312,   186,   160,
     187,   188,   189,   190,   165,   207,   191,   192,   193,   194,
     195,   196,   197,   198,   200,   201,   202,   203,   204,   205,
     206,   212,   215,   137,   216,   304,   224,   306,   138,   139,
     140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
     150,   151,   152,   226,   153,   154,   155,   156,   157,   158,
     159,   228,   231,   232,   160,   233,   237,   238,   258,   315,
     137,   239,   240,   241,   341,   138,   139,   140,   141,   142,
     143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
     242,   153,   154,   155,   156,   157,   158,   159,   243,   246,
     247,   160,   248,   249,   250,   307,   320,   251,   252,   327,
     317,   253,   254,   256,   257,   259,   262,   318,   270,   272,
     273,   385,   275,   274,   276,   300,   277,   278,   279,   280,
     281,   282,   319,   283,   284,   285,   286,   287,   288,   289,
     290,   137,   396,   292,   293,   414,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   294,   153,   154,   155,   156,   157,   158,   159,   295,
     296,   297,   160,   137,   298,   299,   301,   321,   138,   139,
     140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
     150,   151,   152,   305,   153,   154,   155,   156,   157,   158,
     159,   308,   310,   313,   160,   137,   314,   316,   323,   322,
     138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
     148,   149,   150,   151,   152,   324,   153,   154,   155,   156,
     157,   158,   159,   325,   328,   326,   160,   137,   331,   329,
     333,   330,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   334,   153,   154,
     155,   156,   157,   158,   159,   335,   337,   336,   160,   137,
     338,   340,   342,   387,   138,   139,   140,   141,   142,   143,
     144,   145,   146,   147,   148,   149,   150,   151,   152,   339,
     153,   154,   155,   156,   157,   158,   159,   344,   346,   351,
     160,   352,   353,   354,   355,   422,   359,   356,   357,   358,
     369,   360,   362,   361,   363,   364,   365,   366,   367,   368,
     372,   373,   374,   375,   376,   377,   378,   379,   384,   381,
     382,   386,   388,   383,   397,   389,   405,   400,   416,   421,
     424,   390,   391,   392,   393,   394,   395,   398,   402,   399,
     401,   415,     0,   404,   406,   408,   409,   412,   410,   411,
       0,   413,   417,   418,   419,     0,   420,   423,   425,     0,
       0,     0,     0,     0,     0,     0,     0,   135
};

static const short int yycheck[] =
{
      18,    19,     8,    55,    56,     7,     5,     6,    11,    10,
      12,    13,    14,    26,    17,     9,    19,    22,    40,    21,
      24,    23,    15,    57,    16,    55,    20,    45,    55,    59,
      55,    25,    59,    54,    59,    55,    58,    58,    55,    59,
      55,     4,    59,     0,    59,    58,    55,    50,    51,    52,
      59,    58,    58,    58,    58,    58,    58,    58,    76,    58,
      78,    79,    80,    81,    58,    58,    58,    22,    57,    57,
      60,     4,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    57,    43,    44,
      45,    46,    47,    48,    49,    55,    55,    55,    53,    59,
      59,    59,    55,    58,    55,    55,    59,    55,    59,    59,
      55,    59,    55,    55,    59,   133,    59,    59,    55,    55,
     138,    55,    59,    59,    56,    59,     6,     5,    59,    59,
      59,   183,    59,    59,    59,   153,   188,   189,   190,    59,
      57,    57,    11,    57,    59,    58,   198,    57,    57,    57,
      24,    57,    59,    57,    57,   173,    22,    57,   176,    17,
     178,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    57,    43,    44,    45,
      46,    47,    48,    49,    57,    52,    51,    53,    22,    59,
      50,    59,    58,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    59,    43,
      44,    45,    46,    47,    48,    49,    59,   269,    59,    53,
      59,    59,    59,    59,    58,    19,    59,    59,    59,    59,
      59,    59,    59,    59,    59,    59,    59,    59,    59,    59,
      59,    58,     7,    22,    57,   263,    13,   265,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    14,    43,    44,    45,    46,    47,    48,
      49,    23,    57,    57,    53,    57,    57,    57,    12,    58,
      22,    57,    57,    57,   302,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      57,    43,    44,    45,    46,    47,    48,    49,    57,    57,
      57,    53,    57,    57,    57,     8,    58,    57,    57,    38,
      28,    59,    59,    59,    59,    57,    59,    29,    59,    59,
      57,   349,    57,    59,    57,    59,    58,    58,    58,    57,
      57,    57,    30,    58,    58,    58,    58,    58,    58,    58,
      57,    22,   370,    58,    58,   407,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    58,    43,    44,    45,    46,    47,    48,    49,    58,
      58,    58,    53,    22,    58,    57,    59,    58,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    59,    43,    44,    45,    46,    47,    48,
      49,    57,    57,    57,    53,    22,    58,    58,    34,    58,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    35,    43,    44,    45,    46,
      47,    48,    49,    36,    39,    37,    53,    22,    57,    40,
      44,    58,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    45,    43,    44,
      45,    46,    47,    48,    49,    46,    48,    47,    53,    22,
      49,    58,    21,    58,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    53,
      43,    44,    45,    46,    47,    48,    49,    57,    59,    57,
      53,    58,    24,    22,    27,    58,    31,    59,    59,    59,
      41,    32,    59,    33,    59,    59,    59,    59,    59,    59,
      59,    59,    59,    59,    59,    59,    59,    54,    25,    59,
      58,     9,    16,    59,    43,    59,    15,    20,    26,    10,
      22,    59,    59,    59,    59,    59,    59,    59,    59,    57,
      57,    40,    -1,    59,    59,    59,    58,    57,    59,    58,
      -1,    59,    58,    57,    59,    -1,    59,    59,    59,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    87
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,    57,    62,    63,    64,     4,     0,    67,    65,    57,
      68,    69,    70,    71,    72,    55,    59,    66,     5,     6,
      58,    57,    73,    60,    65,    65,     4,    58,    57,    74,
      75,    78,    79,    80,    81,    82,    83,    56,    59,    59,
      59,     6,    11,    17,    19,    50,    51,    52,    58,    84,
      59,    59,    59,    59,    65,    59,    59,     5,    57,    85,
      86,    87,    90,    91,   106,   107,   138,   139,   142,   143,
      57,   110,    59,   110,   110,    59,     7,    12,    13,    14,
      21,    23,    58,    92,   108,   140,    57,   144,   145,    58,
      57,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   131,
     132,   133,   134,   135,   136,   137,    76,    57,    57,    65,
      59,    65,    65,    65,    65,    11,    57,    93,    94,    57,
     109,    57,   141,    24,    57,   145,    17,    22,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    43,    44,    45,    46,    47,    48,    49,
      53,    58,    57,    77,    58,    58,    59,    57,    59,    59,
      59,    59,    59,     8,    58,    95,    15,    58,    16,    58,
      65,    58,    59,    59,    65,    59,    59,    59,    59,    59,
      59,    59,    59,    59,    59,    59,    59,    59,    59,    65,
      59,    59,    59,    59,    59,    59,    59,    19,    54,    58,
      51,    52,    58,    88,    65,     7,    57,    96,    97,    98,
      99,   102,   103,    65,    13,    65,    14,    59,    23,   110,
      59,    57,    57,    57,   110,   110,   110,    57,    57,    57,
      57,    57,    57,    57,   110,    59,    57,    57,    57,    57,
      57,    57,    57,    59,    59,    50,    59,    59,    12,    57,
      89,    59,    59,     9,    20,    25,    58,   100,   104,    59,
      59,    59,    59,    57,    59,    57,    57,    58,    58,    58,
      57,    57,    57,    58,    58,    58,    58,    58,    58,    58,
      57,   129,    58,    58,    58,    58,    58,    58,    58,    57,
      59,    59,    40,    58,    65,    59,    65,     8,    57,   101,
      57,   105,   110,    57,    58,    58,    58,    28,    29,    30,
      58,    58,    58,    34,    35,    36,    37,    38,    39,    40,
      58,    57,   130,    44,    45,    46,    47,    48,    49,    53,
      58,    65,    21,    59,    57,    59,    59,    26,    58,    10,
      58,    57,    58,    24,    22,    27,    59,    59,    59,    31,
      32,    33,    59,    59,    59,    59,    59,    59,    59,    41,
      22,    58,    59,    59,    59,    59,    59,    59,    59,    54,
      59,    59,    58,    59,    25,    65,     9,    58,    16,    59,
      59,    59,    59,    59,    59,    59,    65,    43,    59,    57,
      20,    57,    59,    59,    59,    15,    59,    59,    59,    58,
      59,    58,    57,    59,   110,    40,    26,    58,    57,    59,
      59,    10,    58,    59,    22,    59
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (0)


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
              (Loc).first_line, (Loc).first_column,	\
              (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, &yylloc, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval, &yylloc)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value, Location);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short int *bottom, short int *top)
#else
static void
yy_stack_print (bottom, top)
    short int *bottom;
    short int *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname[yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");

# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */






/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()
    ;
#endif
#endif
{
  /* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;
/* Location data for the look-ahead symbol.  */
YYLTYPE yylloc;

  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short int yyssa[YYINITDEPTH];
  short int *yyss = yyssa;
  short int *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;

  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  /* The locations where the error started and ended. */
  YYLTYPE yyerror_range[2];

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;
#if YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short int *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short int *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
	YYSTACK_RELOCATE (yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a look-ahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to look-ahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
  *++yylsp = yylloc;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, yylsp - yylen, yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 3:
#line 162 "xmlparse.y"
    {
		/* Assume the frontend died if we get no input. It will emit an error.
		 * Cause us to return an error code. */
		gblErrorCount += 1;
	;}
    break;

  case 5:
#line 174 "xmlparse.y"
    {
		Attribute *fileNameAttr = (yyvsp[-1].attrList)->find( "filename" );
		if ( fileNameAttr == 0 )
			xml_error((yylsp[-2])) << "tag <ragel> requires a filename attribute" << endl;
		else
			sourceFileName = fileNameAttr->value;
		openOutput( sourceFileName );
	;}
    break;

  case 6:
#line 184 "xmlparse.y"
    {
		(yyval.attrList) = (yyvsp[-1].attrList);
		(yyval.attrList)->append( Attribute( attrKey, attrValue ) );
	;}
    break;

  case 7:
#line 188 "xmlparse.y"
    {
		(yyval.attrList) = new AttrList;
	;}
    break;

  case 8:
#line 193 "xmlparse.y"
    {
		attrKey = (yyvsp[-2].data);
		attrValue = (yyvsp[0].data);
	;}
    break;

  case 13:
#line 207 "xmlparse.y"
    {
		if ( outputFormat == OutCCode || outputFormat == OutDCode )
			*outStream << xmlData.data;
	;}
    break;

  case 14:
#line 213 "xmlparse.y"
    {
		Attribute *lineAttr = (yyvsp[-1].attrList)->find( "line" );
		if ( lineAttr == 0 )
			xml_error((yylsp[-2])) << "tag <host> requires a line attribute" << endl;
		else {
			int line = atoi( lineAttr->value );
			if ( outputFormat == OutCCode || outputFormat == OutDCode )
				lineDirective( *outStream, sourceFileName, line );
		}
	;}
    break;

  case 15:
#line 227 "xmlparse.y"
    {
		if ( gblErrorCount == 0 )
			cgd->generate();
	;}
    break;

  case 16:
#line 233 "xmlparse.y"
    {
		bool wantComplete = outputFormat != OutGraphvizDot;

		char *fsmName = 0;
		Attribute *nameAttr = (yyvsp[-1].attrList)->find( "name" );
		if ( nameAttr != 0 ) {
			fsmName = nameAttr->value;

			CodeGenMapEl *mapEl = codeGenMap.find( fsmName );
			if ( mapEl != 0 )
				cgd = mapEl->value;
			else {
				cgd = new CodeGenData( sourceFileName, fsmName, wantComplete );
				codeGenMap.insert( fsmName, cgd );
			}
		}
		else {
			cgd = new CodeGenData( sourceFileName, fsmName, wantComplete );
		}

		cgd->writeOps = 0;
		cgd->writeData = false;
		cgd->writeInit = false;
		cgd->writeExec = false;
		cgd->writeEOF = false;
		::keyOps = &cgd->thisKeyOps;
	;}
    break;

  case 25:
#line 276 "xmlparse.y"
    {
		Attribute *what = (yyvsp[-6].attrList)->find( "what" );
		if ( what == 0 ) {
			xml_error((yylsp[-7])) << "tag <write> requires a what attribute" << endl;
		}
		else {
			if ( strcmp( what->value, "data" ) == 0 )
				cgd->writeData = true;
			else if ( strcmp( what->value, "init" ) == 0 )
				cgd->writeInit = true;
			else if ( strcmp( what->value, "exec" ) == 0 )
				cgd->writeExec = true;
			else if ( strcmp( what->value, "eof" ) == 0 )
				cgd->writeEOF = true;
		}
	;}
    break;

  case 28:
#line 299 "xmlparse.y"
    {
		if ( strcmp( xmlData.data, "noend" ) == 0 )
			cgd->writeOps |= WO_NOEND;
	 	else if ( strcmp( xmlData.data, "noerror" ) == 0 )
			cgd->writeOps |= WO_NOERROR;
		else if ( strcmp( xmlData.data, "noprefix" ) == 0 )
			cgd->writeOps |= WO_NOPREFIX;
		else if ( strcmp( xmlData.data, "nofinal" ) == 0 )
			cgd->writeOps |= WO_NOFF;
		else {
			warning() << "unrecognized write option" << endl;
		}
	;}
    break;

  case 29:
#line 316 "xmlparse.y"
    {
		if ( ! cgd->setAlphType( xmlData.data ) )
			xml_error((yylsp[-5])) << "tag <alphtype> specifies unknown alphabet type" << endl;
	;}
    break;

  case 30:
#line 324 "xmlparse.y"
    {
		cgd->getKeyExpr = (yyvsp[-4].illist);
	;}
    break;

  case 31:
#line 331 "xmlparse.y"
    {
		cgd->accessExpr = (yyvsp[-4].illist);
	;}
    break;

  case 32:
#line 338 "xmlparse.y"
    {
		cgd->curStateExpr = (yyvsp[-4].illist);
	;}
    break;

  case 33:
#line 345 "xmlparse.y"
    {
		cgd->finishMachine();
	;}
    break;

  case 34:
#line 350 "xmlparse.y"
    {
		cgd->createMachine();
	;}
    break;

  case 43:
#line 368 "xmlparse.y"
    {
		unsigned long startState = strtoul( xmlData.data, 0, 10 );
		cgd->setStartState( startState );
	;}
    break;

  case 44:
#line 376 "xmlparse.y"
    {
		Attribute *errorAttr = (yyvsp[-6].attrList)->find( "error" );
		if ( errorAttr != 0 )
			cgd->setForcedErrorState();
	;}
    break;

  case 47:
#line 388 "xmlparse.y"
    {
		Attribute *nameAttr = (yyvsp[-5].attrList)->find( "name" );
		if ( nameAttr == 0 )
			xml_error((yylsp[-6])) << "tag <entry_points>::<entry> requires a name attribute" << endl;
		else {
			char *data = xmlData.data;
			unsigned long entry = strtoul( data, &data, 10 );
			cgd->addEntryPoint( nameAttr->value, entry );
		}
	;}
    break;

  case 49:
#line 405 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-1].attrList)->find( "length" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-2])) << "tag <state_list> requires a length attribute" << endl;
	 	else {
			unsigned long length = strtoul( lengthAttr->value, 0, 10 );
			cgd->initStateList( length );
			curState = 0;
		}
	;}
    break;

  case 52:
#line 423 "xmlparse.y"
    {
		curState += 1;
	;}
    break;

  case 53:
#line 428 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-1].attrList)->find( "final" );
		if ( lengthAttr != 0 )
			cgd->setFinal( curState );
	;}
    break;

  case 59:
#line 445 "xmlparse.y"
    {
		char *ad = xmlData.data;

		long toStateAction = readOffsetPtr( ad, &ad );
		long fromStateAction = readOffsetPtr( ad, &ad );
		long eofAction = readOffsetPtr( ad, &ad );

		cgd->setStateActions( curState, toStateAction,
				fromStateAction, eofAction );
	;}
    break;

  case 61:
#line 462 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-1].attrList)->find( "length" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-2])) << "tag <cond_list> requires a length attribute" << endl;
	 	else {
			ulong length = readLength( lengthAttr->value );
			cgd->initStateCondList( curState, length );
			curStateCond = 0;
		}
	;}
    break;

  case 64:
#line 479 "xmlparse.y"
    {
		char *td = xmlData.data;
		Key lowKey = readKey( td, &td );
		Key highKey = readKey( td, &td );
		long condId = readOffsetPtr( td, &td );
		cgd->addStateCond( curState, lowKey, highKey, condId );
	;}
    break;

  case 65:
#line 490 "xmlparse.y"
    {
		cgd->finishTransList( curState );
	;}
    break;

  case 66:
#line 495 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-1].attrList)->find( "length" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-2])) << "tag <trans_list> requires a length attribute" << endl;
	 	else {
			unsigned long length = strtoul( lengthAttr->value, 0, 10 );
			cgd->initTransList( curState, length );
			curTrans = 0;
		}
	;}
    break;

  case 69:
#line 512 "xmlparse.y"
    {
		char *td = xmlData.data;
		Key lowKey = readKey( td, &td );
		Key highKey = readKey( td, &td );
		long targ = readOffsetPtr( td, &td );
		long action = readOffsetPtr( td, &td );

		cgd->newTrans( curState, curTrans++, lowKey, highKey, targ, action );
	;}
    break;

  case 71:
#line 528 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-1].attrList)->find( "length" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-2])) << "tag <action_list> requires a length attribute" << endl;
	 	else {
			unsigned long length = strtoul( lengthAttr->value, 0, 10 );
			cgd->initActionList( length );
			curAction = 0;
		}
	;}
    break;

  case 74:
#line 546 "xmlparse.y"
    {
		Attribute *lineAttr = (yyvsp[-6].attrList)->find( "line" );
		Attribute *colAttr = (yyvsp[-6].attrList)->find( "col" );
		Attribute *nameAttr = (yyvsp[-6].attrList)->find( "name" );
		if ( lineAttr == 0 || colAttr == 0)
			xml_error((yylsp[-7])) << "tag <action> requires a line and col attributes" << endl;
	 	else {
			unsigned long line = strtoul( lineAttr->value, 0, 10 );
			unsigned long col = strtoul( colAttr->value, 0, 10 );

			char *name = 0;
			if ( nameAttr != 0 )
				name = nameAttr->value;

			cgd->newAction( curAction++, name, line, col, (yyvsp[-4].illist) );
		}
	;}
    break;

  case 75:
#line 565 "xmlparse.y"
    {
		/* Append the item to the list, return the list. */
		(yyvsp[-1].illist)->append( (yyvsp[0].ilitem) );
		(yyval.illist) = (yyvsp[-1].illist);
	;}
    break;

  case 76:
#line 570 "xmlparse.y"
    {
		/* Start with empty list. */
		(yyval.illist) = new InlineList;
	;}
    break;

  case 101:
#line 603 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Text );
		(yyval.ilitem)->data = strdup(xmlData.data);
	;}
    break;

  case 102:
#line 610 "xmlparse.y"
    {
		int targ = strtol( xmlData.data, 0, 10 );
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Goto );
		(yyval.ilitem)->targId = targ;
	;}
    break;

  case 103:
#line 618 "xmlparse.y"
    {
		int targ = strtol( xmlData.data, 0, 10 );
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Call );
		(yyval.ilitem)->targId = targ;
	;}
    break;

  case 104:
#line 626 "xmlparse.y"
    {
		int targ = strtol( xmlData.data, 0, 10 );
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Next );
		(yyval.ilitem)->targId = targ;
	;}
    break;

  case 105:
#line 635 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::GotoExpr );
		(yyval.ilitem)->children = (yyvsp[-4].illist);
	;}
    break;

  case 106:
#line 643 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::CallExpr );
		(yyval.ilitem)->children = (yyvsp[-4].illist);
	;}
    break;

  case 107:
#line 651 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::NextExpr );
		(yyval.ilitem)->children = (yyvsp[-4].illist);
	;}
    break;

  case 108:
#line 658 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Ret );
	;}
    break;

  case 109:
#line 664 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::PChar );
	;}
    break;

  case 110:
#line 670 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Char );
	;}
    break;

  case 111:
#line 676 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Hold );
	;}
    break;

  case 112:
#line 682 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Curs );
	;}
    break;

  case 113:
#line 688 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Targs );
	;}
    break;

  case 114:
#line 694 "xmlparse.y"
    {
		int targ = strtol( xmlData.data, 0, 10 );
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Entry );
		(yyval.ilitem)->targId = targ;
	;}
    break;

  case 115:
#line 703 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Exec );
		(yyval.ilitem)->children = (yyvsp[-4].illist);
	;}
    break;

  case 116:
#line 710 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::Break );
	;}
    break;

  case 117:
#line 718 "xmlparse.y"
    {
		bool handlesError = false;
		Attribute *handlesErrorAttr = (yyvsp[-6].attrList)->find( "handles_error" );
		if ( handlesErrorAttr != 0 )
			handlesError = true;

		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::LmSwitch );
		(yyval.ilitem)->children = (yyvsp[-4].illist);
		(yyval.ilitem)->handlesError = handlesError;
	;}
    break;

  case 118:
#line 730 "xmlparse.y"
    {
		(yyval.illist) = (yyvsp[-1].illist);
		(yyval.illist)->append( (yyvsp[0].ilitem) );
	;}
    break;

  case 119:
#line 734 "xmlparse.y"
    {
		(yyval.illist) = new InlineList;
	;}
    break;

  case 120:
#line 741 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::SubAction );
		(yyval.ilitem)->children = (yyvsp[-4].illist);

		Attribute *idAttr = (yyvsp[-6].attrList)->find( "id" );
		if ( idAttr != 0 ) {
			unsigned long id = strtoul( idAttr->value, 0, 10 );
			(yyval.ilitem)->lmId = id;
		}
	;}
    break;

  case 121:
#line 754 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::LmSetActId );
		(yyval.ilitem)->lmId = strtol( xmlData.data, 0, 10 );
	;}
    break;

  case 122:
#line 761 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::LmGetTokEnd );
	;}
    break;

  case 123:
#line 767 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::LmSetTokEnd );
		(yyval.ilitem)->offset = strtol( xmlData.data, 0, 10 );
	;}
    break;

  case 124:
#line 775 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::SubAction );
		(yyval.ilitem)->children = (yyvsp[-4].illist);
	;}
    break;

  case 125:
#line 782 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::LmInitTokStart );
	;}
    break;

  case 126:
#line 788 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::LmInitAct );
	;}
    break;

  case 127:
#line 794 "xmlparse.y"
    {
		(yyval.ilitem) = new InlineItem( InputLoc(), InlineItem::LmSetTokStart );
		cgd->hasLongestMatch = true;
	;}
    break;

  case 129:
#line 805 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-1].attrList)->find( "length" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-2])) << "tag <action_table_list> requires a length attribute" << endl;
	 	else {
			unsigned long length = strtoul( lengthAttr->value, 0, 10 );
			cgd->initActionTableList( length );
			curActionTable = 0;
		}
	;}
    break;

  case 132:
#line 822 "xmlparse.y"
    {
		/* Find the length of the action table. */
		Attribute *lengthAttr = (yyvsp[-5].attrList)->find( "length" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-6])) << "tag <at> requires a length attribute" << endl;
	 	else {
			unsigned long length = strtoul( lengthAttr->value, 0, 10 );

			/* Collect the action table. */
			RedAction *redAct = cgd->allActionTables + curActionTable;
			redAct->actListId = curActionTable;
			redAct->key.setAsNew( length );
			char *ptr = xmlData.data;
			int pos = 0;
			while ( *ptr != 0 ) {
				unsigned long actionId = strtoul( ptr, &ptr, 10 );
				redAct->key[pos].key = 0;
				redAct->key[pos].value = cgd->allActions+actionId;
				pos += 1;
			}

			/* Insert into the action table map. */
			cgd->redFsm->actionMap.insert( redAct );
		}

		curActionTable += 1;
	;}
    break;

  case 134:
#line 856 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-1].attrList)->find( "length" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-2])) << "tag <cond_space_list> requires a length attribute" << endl;
	 	else {
			ulong length = readLength( lengthAttr->value );
			cgd->initCondSpaceList( length );
			curCondSpace = 0;
		}
	;}
    break;

  case 137:
#line 873 "xmlparse.y"
    {
		Attribute *lengthAttr = (yyvsp[-5].attrList)->find( "length" );
		Attribute *idAttr = (yyvsp[-5].attrList)->find( "id" );
		if ( lengthAttr == 0 )
			xml_error((yylsp[-6])) << "tag <cond_space> requires a length attribute" << endl;
	 	else {
			if ( lengthAttr == 0 )
				xml_error((yylsp[-6])) << "tag <cond_space> requires an id attribute" << endl;
		 	else {
				unsigned long condSpaceId = strtoul( idAttr->value, 0, 10 );
				ulong length = readLength( lengthAttr->value );

				char *td = xmlData.data;
				Key baseKey = readKey( td, &td );

				cgd->newCondSpace( curCondSpace, condSpaceId, baseKey );
				for ( ulong a = 0; a < length; a++ ) {
					long actionOffset = readOffsetPtr( td, &td );
					cgd->condSpaceItem( curCondSpace, actionOffset );
				}
				curCondSpace += 1;
			}
		}
	;}
    break;


      default: break;
    }

/* Line 1126 of yacc.c.  */
#line 2355 "xmlparse.cpp"

  yyvsp -= yylen;
  yyssp -= yylen;
  yylsp -= yylen;

  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  int yytype = YYTRANSLATE (yychar);
	  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
	  YYSIZE_T yysize = yysize0;
	  YYSIZE_T yysize1;
	  int yysize_overflow = 0;
	  char *yymsg = 0;
#	  define YYERROR_VERBOSE_ARGS_MAXIMUM 5
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;

#if 0
	  /* This is so xgettext sees the translatable formats that are
	     constructed on the fly.  */
	  YY_("syntax error, unexpected %s");
	  YY_("syntax error, unexpected %s, expecting %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
#endif
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytname[yytype];
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytname[yyx];
		yysize1 = yysize + yytnamerr (0, yytname[yyx]);
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + yystrlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow && yysize <= YYSTACK_ALLOC_MAXIMUM)
	    yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg)
	    {
	      /* Avoid sprintf, as that infringes on the user's name space.
		 Don't have undefined behavior even if the translation
		 produced a string with the wrong number of "%s"s.  */
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      goto yyexhaustedlab;
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
    }

  yyerror_range[0] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
        }
      else
	{
	  yydestruct ("Error: discarding", yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (0)
     goto yyerrorlab;

  yyerror_range[0] = yylsp[1-yylen];
  yylsp -= yylen;
  yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[0] = *yylsp;
      yydestruct ("Error: popping", yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;

  yyerror_range[1] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the look-ahead.  YYLOC is available though. */
  YYLLOC_DEFAULT (yyloc, yyerror_range - 1, 2);
  *++yylsp = yyloc;

  /* Shift the error token. */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval, &yylloc);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK;
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 898 "xmlparse.y"


unsigned long readLength( char *td )
{
	return strtoul( td, 0, 10 );
}

Key readKey( char *td, char **end )
{
	if ( keyOps->isAlphSigned )
		return Key( strtol( td, end, 10 ) );
	else
		return Key( strtoul( td, end, 10 ) );
}

long readOffsetPtr( char *td, char **end )
{
	while ( *td == ' ' || *td == '\t' )
		td++;

	if ( *td == 'x' ) {
		if ( end != 0 )
			*end = td + 1;
		return -1;
	}

	return strtol( td, end, 10 );
}

void yyerror( char *err )
{
	/* Bison won't give us the location, but in the last call to the scanner we
	 * saved a pointer to the locationn variable. Use that. instead. */
	error(::yylloc->first_line, ::yylloc->first_column) << err << endl;
}



#define VERSION "6.5"
#define PUBDATE "May 2009"

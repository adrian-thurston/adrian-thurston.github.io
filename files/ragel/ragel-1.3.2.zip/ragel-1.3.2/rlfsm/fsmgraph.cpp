/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMGRAPH_CPP
#define _RLFSM_FSMGRAPH_CPP

#include <assert.h>

#include "fsmgraph.h"
#include "mergesort.h"
#include "fsmstate.cpp"
#include "fsmbase.cpp"
#include "fsmattach.cpp"

/* Simple singly linked list append routine for the fill list. The new state
 * goes to the end of the list. */
template < class State > void FsmMergeData<State>::fillListAppend( State *state )
{
	state->alg.next = 0;

	if ( stfillHead == 0 ) {
		/* List is empty, state becomes head and tail. */
		stfillHead = state;
		stfillTail = state;
	}
	else {
		/* List is not empty, state goes after last element. */
		stfillTail->alg.next = state;
		stfillTail = state;
	}
}

/* Make a new state. The new state will be put on the graph's
 * list of state. The new state can be created final or non final. */
template < class State, class TransFunc, class Transition >
		State *FsmGraph<State, TransFunc, Transition>::
		newState()
{
	/* Make the new state to return. */
	State *state = new State();

	if ( misfitAccounting ) {
		/* Create the new state on the misfit list. All states are created
		 * with no foreign in transitions. */
		misfitList.append( state );
	}
	else {
		/* Create the new state. */
		stateList.append( state );
	}

	/* Return the new state. */
	return state;
}

/* Create an fsm that is a concatenation of the characters in the given string. */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		concatFsm( char *str, int len )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state and set it as the start state. */
	State *last = retVal->newState();
	retVal->setEntry( 0, last );

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *newState = retVal->newState();
		retVal->attachStates( last, newState, KeyTypeSingle, str[i], 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->setFinState( last );
	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		concatFsm( int *str, int len )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state and set it as the start state. */
	State *last = retVal->newState();
	retVal->setEntry( 0, last );

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *newState = retVal->newState();
		retVal->attachStates( last, newState, KeyTypeSingle, str[i], 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->setFinState( last );
	return retVal;
}


template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		concatFsm( int chr )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on the character. */
	retVal->attachStates( start, end, KeyTypeSingle, chr, 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		orFsm( char *set, int len )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on all the chars in the given string of characters. */
	for ( int i = 0; i < len; i++ )
		retVal->attachStates( start, end, KeyTypeSingle, set[i], 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		orFsm( int *set, int len )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on all the integers in the given string of ints. */
	for ( int i = 0; i < len; i++ )
		retVal->attachStates( start, end, KeyTypeSingle, set[i], 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		nullFsm()
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Give it one state with no transitions making it
	 * the start state and final state. */
	State *startState = retVal->newState();
	retVal->setEntry( 0, startState );
	retVal->setFinState( startState );

	/* Return new Graph. */
	return retVal;
}

/* Make a graph with two states and the default transition between them. */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		dotFsm()
{
	/* New graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach on the any char. */
	retVal->attachStates( start, end, KeyTypeDefault, 0, 0 );

	return retVal;
}

/* Make a graph with one state (which is final) and a default transition back
 * to itself. */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		dotStarFsm()
{
	/* New graph. */
	FsmGraph *retVal = new FsmGraph;

	/* One state which is final and is the start state. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );
	retVal->setFinState( start );

	/* Attach start to start on default. */
	retVal->attachStates( start, start, KeyTypeDefault, 0, 0 );

	return retVal;
}

/* Make a graph with one two states and a range of transitions between them. */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		rangeFsm( int low, int high )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->newState();
	retVal->setEntry( 0, start );

	State *end = retVal->newState();
	retVal->setFinState( end );

	/* Attach using the range of characters. */
	retVal->attachStates( start, end, KeyTypeRange, low, high );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		star(bool leavingFsm)
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of the original start state. */
	StateSet startStateSet;
	startStateSet.set( findEntry(0) );

	/* Get a copy of the final state set before creating the new
	 * start state. It may get set final and we don't want the start
	 * state to be included in the final state set. If it is included
	 * in the final state set then all the final states after it get
	 * the transitions of the start state doubled up. That's incorrect.*/
	StateSet finStateSetCopy( finStateSet );

	/* This will be the new start state. It will be set final after the
	 * merging of the final states with the start state is complete. */
	State *newStart = newState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* From here on we need the new start state as start state set. */
	startStateSet.setAs( newStart );

	/* For all the final states, merge with the new start state. */
	State **st = finStateSetCopy.table;
	int nst = finStateSetCopy.tableLength;
	for (int i = 0; i < nst; i++, st++)
		mergeStates( md, *st, startStateSet, leavingFsm );

	/* Now it is safe to merge the start state with itself (provided it
	 * is set final). */
	if ( newStart->isFinState )
		mergeStates( md, newStart, startStateSet, leavingFsm );

	/* Now ensure the new start state is a final state. */
	setFinState( newStart );

	/* Fill in any states that were newed up as combinations of others. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		concat(FsmGraph *other, bool leavingFsm)
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Build a state set consisting of other's start state. */
	StateSet startStateSet;
	startStateSet.set( other->findEntry(0) );

	/* Unset other's start state before bringing in the entry points. */
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Bring in other's states into our state lists. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Get a copy of our final state set before we clobber it. We need to
	 * iterate over it while it may change due to the merging process. */
	StateSet finStateSetCopy( finStateSet );

	/* Unset all of our final states and get the final states from other. */
	unsetAllFinStates();
	finStateSet.set( other->finStateSet );
	
	/* Since other's lists are empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our former final states with the start state of other. */
	State **st = finStateSetCopy.table;
	int nst = finStateSetCopy.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		State *state = *st;

		/* Merge the former final state with other's start state. */
		mergeStates( md, state, startStateSet, leavingFsm );

		/* If the former final state was not reset final then we must clear
		 * the state's out trans data. If it got reset final then it gets to
		 * keep its out trans data. This must be done before fillInStates gets
		 * called to prevent the data from being sourced. */
		if ( ! state->isFinState ) {
			/* Kill the out transitions. Reset the priority. */
			state->outTransFuncTable.empty();
			state->isOutPriorSet = false;
			state->outPriority = 0;
		}
	}

	/* Fill in any new states made from merging. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		doOr(FsmGraph *other)
{
	/* For the merging process. */
	MergeData md;

	/* Build a state set consisting of both start states */
	StateSet startStateSet;
	startStateSet.set( findEntry(0) );
	startStateSet.set( other->findEntry(0) );

	/* Both of the original start states loose their start state status. */
	unsetEntry( 0 );
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Merge the lists. This will move all the states from other
	 * into this. No states will be deleted. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Move the final set data from other into this. */
	finStateSet.set(other->finStateSet);
	other->finStateSet.empty();

	/* Since other's list is empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Create a new start state. */
	State *newStart = newState();
	setEntry( 0, newStart );

	/* Merge the start states. */
	mergeStates( md, newStart, startStateSet, false );

	/* Fill in any new states made from merging. */
	fillInStates( md );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		or(FsmGraph *other)
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Call Worker routine. */
	doOr( other );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		intersect(FsmGraph *other)
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits on this and other to want each other. */
	setFinBits( SB_WANTOTHER1 );
	other->setFinBits( SB_WANTOTHER2 );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetIncompleteFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		subtract(FsmGraph *other)
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits of other to be killers. */
	other->setFinBits( SB_KILLOTHERS );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetIncompleteFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}


/* Unset any final states that are no longer to be final due to final bits. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		unsetIncompleteFinals()
{
	/* Duplicate the final state set before we begin modifying it. */
	StateSet fin( finStateSet );

	for ( int s = 0; s < fin.tableLength; s++ ) {
		State *state = fin.table[s];

		if ( state->stateBits & SB_KILLOTHERS ) {
			/* One final state is a killer, don't set final. */
			unsetFinState( state );
		}

		if ( state->stateBits & SB_WANTOTHER && 
				(state->stateBits & SB_WANTOTHER) != SB_WANTOTHER )
		{
			/* One state wants the other but it is not there. */
			unsetFinState( state );
		}

		/* All states should have their state bits cleared. Non final states
		 * should never have had their state bits set in the first place. */
		state->stateBits = 0;
	}
}

/* Determine if there are any entry points into a start state other than the
 * start state. Setting starting transitions requires that the start state be
 * isolated. In most cases a start state will already be isolated. */
template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		isStartStateIsolated()
{
	/* Get the start State. */
	State *start = findEntry( 0 );

	/* If there are any in transitions then the state is not isolated. */
	if ( start->inListHead != 0 || 
			start->inRangeHead != 0 || 
			start->inDefHead != 0 )
	{
		return false;
	}

	/* If there are any entry points other than the start state then it
	 * is not isolated. */
	if ( start->entryIds.tableLength > 1 )
		return false;

	return true;
}


/* Ensure that the start state is free of entry points (aside from the fact
 * that it is the start state). If the start state has entry points then Make a
 * new start state by merging with the old one. Useful before modifying start
 * transitions. If the existing start state has any entry points other than the
 * start state entry then modifying its transitions changes more than the start
 * transitions. So isolate the start state by separating it out such that it
 * only has start stateness as it's entry point. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		isolateStartState( )
{
	/* For the merging process. */
	MergeData md;

	/* Bail out if the start state is already isolated. */
	if ( isStartStateIsolated() )
		return;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of only the start state. */
	StateSet startStateSet;
	startStateSet.set( findEntry(0) );

	/* This will be the new start state. The existing start
	 * state is merged with it. */
	State *newStart = newState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* Stfil and stateDict will be empty because the merging of the old start
	 * state into the new one will not have any conflicting transitions. */
	assert( md.stateDict.nodeCount == 0 );
	assert( md.stfillHead == 0 );

	/* The old start state may be unreachable. Remove the misfits and turn off
	 * misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/* Bring in other's entry points. Assumes others states are going to be
 * copied into this machine. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		copyInEntryPoints( FsmGraph *other )
{
	EntryEl *entryEl = other->entryPoints.table;
	int neel = other->entryPoints.tableLength;
	for ( int i = 0; i < neel; i++, entryEl++ ) {
		/* Insert the item and assert that it succeeded. */
		EntryEl *resEl = entryPoints.insert( entryEl->key, entryEl->value );
		assert( resEl != 0 );
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		setStateNumbers()
{
	int curNum = 0;
	State *state = stateList.head;
	while (state != 0) {
		state->num = curNum;
		curNum++;
		state = state->next;
	}
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		unsetAllFinStates()
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ ) {
		State *state = *st;
		state->isFinState = false;
	}
	finStateSet.empty();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		setFinBits( int finStateBits )
{
	for ( int s = 0; s < finStateSet.tableLength; s++ )
		finStateSet.table[s]->stateBits = finStateBits;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		mergeStates( MergeData &md, State *destState, StateSet &stateSet, 
				bool leavingFsm )
{
	/* If a merge is to make transitions that leave an fsm then the state set
	 * should have only one element in it. This is to protect against writing
	 * and reading of out trans data as determined by the order of state in
	 * state set. */
	assert( ! ( leavingFsm && stateSet.size() > 1 ));

	State **stp = stateSet.table;
	int nst = stateSet.tableLength;
	for ( int i = 0; i < nst; i++, stp++ ) {
		State *src = *stp;

		/* Get the out transitions. */
		outTransCopy2( md, destState, src, leavingFsm );

		/* Get its bits and final state status. */
		destState->stateBits |= src->stateBits;
		if ( src->isFinState )
			setFinState( destState );

		/* Merge the outTransFuncTable. */
		if ( src == destState ) {
			/* Duplicate the list. */
			typename Transition::TransFuncTable
					srcTransTable( src->outTransFuncTable );
			destState->setOutFunctions( srcTransTable );
		}
		else {
			/* Get the out functions. */
			destState->setOutFunctions( src->outTransFuncTable );
		}

		if ( src->isOutPriorSet ) {
			destState->isOutPriorSet = true;
			destState->outPriority = src->outPriority;
		}

		/* Call user routine. */
		destState->mergeState( src );
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		fillInStates( MergeData &md )
{
	/* Merge any states that are awaiting merging. This will likey cause
	 * other states to be added to the stfil list. */
	State *state = md.stfillHead;
	while ( state != 0 ) {
		mergeStates( md, state, state->stateDictNode->stateSet, false );
		state = state->alg.next;
	}

	/* Delete the state sets of all states that are on the fill list. */
	state = md.stfillHead;
	while ( state != 0 ) {
		/* Delete and reset the state set. */
		delete state->stateDictNode;
		state->stateDictNode = 0;

		/* Next state in the stfill list. */
		state = state->alg.next;
	}

	/* StateDict will still have it's ptrs/size set but all of it's nodes
	 * will be deleted so we don't need to clean it up. */
}

template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		partitionRound( State **statePtrs, MinPartition<State> *parts, int numParts )
{
	/* For each partition. */
	for ( int p = 0; p < numParts; p++ ) {
		/* Fill the pointer array with the states in the partition. */
		int s, numStates = parts[p].list.listLength;
		State *state = parts[p].list.head;
		for ( s = 0; state != 0; s++, state = state->next )
			statePtrs[s] = state;

		/* Sort the states using the partitioning compare. */
		MergeSort< State*, PartitionCompare<State, Transition> >::sort( 
				statePtrs, numStates );

		/* Assign the states into partitions based on the results of the sort. */
		int destPart = p, firstNewPart = numParts;
		for ( s = 1; s < numStates; s++ ) {
			/* If this state differs from the last then move to the next partition. */
			if ( PartitionCompare<State, Transition>::Compare( 
					statePtrs[s-1], statePtrs[s] ) < 0 )
			{
				/* The new partition is the next avail spot. */
				destPart = numParts;
				numParts += 1;
			}

			/* If the state is not staying in the first partition, then
			 * transfer it to its destination partition. */
			if ( destPart != p ) {
				State *state = parts[p].list.detach( statePtrs[s] );
				parts[destPart].list.append( state );
			}
		}

		/* Fix the partition pointer for all the states that got moved to a new
		 * partition. This must be done after the states are transfered so the
		 * result of the sort is not altered. */
		for ( int newPart = firstNewPart; newPart < numParts; newPart++ ) {
			State *state = parts[newPart].list.head;
			while ( state != 0 ) {
				state->alg.partition = &parts[newPart];
				state = state->next;
			}
		}
	}

	return numParts;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		minimizePartition1()
{
	/* Nothing to do if there are no states. */
	if (stateList.listLength == 0)
		return;

	/* 
	 * First thing is to partition the states by final state status and
	 * transition functions. This gives us an initial partitioning to work
	 * with.
	 */

	/* Fill up an array of pointers to the states for easy sorting. */
	int s, numStates = stateList.listLength;
	State** statePtrs = new State*[numStates];
	State *state = stateList.head;
	for ( s = 0; s < numStates; s++ ) {
		statePtrs[s] = state;
		state = state->next;
	}
		
	/* Sort the states using the array of states. */
	MergeSort< State*, InitPartitionCompare<State, Transition> >::sort( 
			statePtrs, numStates );

	/* An array of lists of states is used to partition the states. */
	MinPartition<State> *parts = new MinPartition<State>[numStates];

	/* Assign the states into partitions. */
	int destPart = 0;
	for ( s = 0; s < numStates; s++ ) {
		/* If this state differs from the last then move to the next partition. */
		if ( s > 0 && InitPartitionCompare<State, Transition>::Compare( 
				statePtrs[s-1], statePtrs[s] ) < 0 )
		{
			/* Move to the next partition. */
			destPart += 1;
		}

		/* Put the state into its partition. */
		statePtrs[s]->alg.partition = &parts[destPart];
		parts[destPart].list.append( statePtrs[s] );
	}

	/* We just moved all the states from the main list into partitions without
	 * taking them off the main list. So clean up the main list now. */
	stateList.abandon();

	/* Split partitions. */
	int numParts = destPart + 1;
	while ( true ) {
		/* Test all partitions for splitting. */
		int newNum = partitionRound( statePtrs, parts, numParts );

		/* When no partitions can be split, stop. */
		if ( newNum == numParts )
			break;

		numParts = newNum;
	}

	/* Fuse states in the same partition. The states will end up back on the
	 * main list. */
	fusePartitions( parts, numParts );

	/* Cleanup. */
	delete[] statePtrs;
	delete[] parts;
}

template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		splitCandidates( State **statePtrs, MinPartition<State> *parts, int numParts )
{
	/* The lists of unsplitable (partList) and splitable partitions. 
	 * Only partitions in the splitable list are check for needing splitting. */
	DList< MinPartition<State> > partList, splittable;

	/* Initially, all partitions are born from a split (the initial
	 * partitioning) and can cause other partitions to be split. So any
	 * partition with a state with a transition out to another partition is a
	 * candidate for splitting. This will make every partition except possibly
	 * partitions of final states split candidates. */
	for ( int p = 0; p < numParts; p++ ) {
		/* Assume not active. */
		parts[p].active = false;

		/* Look for a trans out of any state in the partition. */
		State *state = parts[p].list.head;
		while ( state != 0 ) {
			/* If there is at least one transition out to another state then 
			 * the partition becomes splittable. */
			FsmOutIterator<State, Transition> outIt( state );
			if ( ! outIt.atEnd() ) {
				parts[p].active = true;
				break;
			}
			state = state->next;
		}

		/* If it was found active then it goes on the splittable list. */
		if ( parts[p].active )
			splittable.append( &parts[p] );
		else
			partList.append( &parts[p] );
	}

	/* While there are partitions that are splittable, pull one off and try
	 * to split it. If it splits, determine which partitions may now be split
	 * as a result of the newly split partition. */
	while ( splittable.listLength > 0 ) {
		MinPartition<State> *partition = splittable.detachFirst();

		/* Fill the pointer array with the states in the partition. */
		int s, numStates = partition->list.listLength;
		State *state = partition->list.head;
		for ( s = 0; state != 0; s++, state = state->next )
			statePtrs[s] = state;

		/* Sort the states using the partitioning compare. */
		MergeSort< State*, PartitionCompare<State, Transition> >::sort( 
				statePtrs, numStates );

		/* Assign the states into partitions based on the results of the sort. */
		MinPartition<State> *destPart = partition;
		int firstNewPart = numParts;
		for ( s = 1; s < numStates; s++ ) {
			/* If this state differs from the last then move to the next partition. */
			if ( PartitionCompare<State, Transition>::Compare(
					statePtrs[s-1], statePtrs[s] ) < 0 )
			{
				/* The new partition is the next avail spot. */
				destPart = &parts[numParts];
				numParts += 1;
			}

			/* If the state is not staying in the first partition, then
			 * transfer it to its destination partition. */
			if ( destPart != partition ) {
				State *state = partition->list.detach( statePtrs[s] );
				destPart->list.append( state );
			}
		}

		/* Fix the partition pointer for all the states that got moved to a new
		 * partition. This must be done after the states are transfered so the
		 * result of the sort is not altered. */
		int newPart;
		for ( newPart = firstNewPart; newPart < numParts; newPart++ ) {
			State *state = parts[newPart].list.head;
			while ( state != 0 ) {
				state->alg.partition = &parts[newPart];
				state = state->next;
			}
		}

		/* Put the partition we just split and any new partitions that came out
		 * of the split onto the inactive list. */
		partition->active = false;
		partList.append( partition );
		for ( newPart = firstNewPart; newPart < numParts; newPart++ ) {
			parts[newPart].active = false;
			partList.append( &parts[newPart] );
		}

		if ( destPart == partition )
			continue;

		/* Now determine which partitions are splittable as a result of
		 * splitting partition by walking the in lists of the states in
		 * partitions that got split. Partition is the faked first item in the
		 * loop. */
		MinPartition<State> *causalPart = partition;
		newPart = firstNewPart - 1;
		while ( newPart < numParts ) {
			State *state = causalPart->list.head;
			while ( state != 0 ) {
				FsmInIterator<State, Transition> inIt( state );
				for ( ; !inIt.atEnd(); inIt++ ) {
					MinPartition<State> *fromPart = 
							inIt.trans->fromState->alg.partition;
					if ( ! fromPart->active ) {
						fromPart->active = true;
						partList.detach( fromPart );
						splittable.append( fromPart );
					}
				}
				state = state->next;
			}

			newPart += 1;
			causalPart = &parts[newPart];
		}
	}
	return numParts;
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		minimizePartition2()
{
	/* Nothing to do if there are no states. */
	if (stateList.listLength == 0)
		return;

	/* 
	 * First thing is to partition the states by final state status and
	 * transition functions. This gives us an initial partitioning to work
	 * with.
	 */

	/* Fill up an array of pointers to the states for easy sorting. */
	int s, numStates = stateList.listLength;
	State** statePtrs = new State*[numStates];
	State *state = stateList.head;
	for ( s = 0; s < numStates; s++ ) {
		statePtrs[s] = state;
		state = state->next;
	}
		
	/* Sort the states using the array of states. */
	MergeSort< State*, InitPartitionCompare<State, Transition> >::sort( 
			statePtrs, numStates );

	/* An array of lists of states is used to partition the states. */
	MinPartition<State> *parts = new MinPartition<State>[numStates];

	/* Assign the states into partitions. */
	int destPart = 0;
	for ( s = 0; s < numStates; s++ ) {
		/* If this state differs from the last then move to the next partition. */
		if ( s > 0 && InitPartitionCompare<State, Transition>::Compare( 
				statePtrs[s-1], statePtrs[s] ) < 0 )
		{
			/* Move to the next partition. */
			destPart += 1;
		}

		/* Put the state into its partition. */
		statePtrs[s]->alg.partition = &parts[destPart];
		parts[destPart].list.append( statePtrs[s] );
	}

	/* We just moved all the states from the main list into partitions without
	 * taking them off the main list. So clean up the main list now. */
	stateList.abandon();

	/* Split partitions. */
	int numParts = splitCandidates( statePtrs, parts, destPart+1 );

	/* Fuse states in the same partition. The states will end up back on the
	 * main list. */
	fusePartitions( parts, numParts );

	/* Cleanup. */
	delete[] statePtrs;
	delete[] parts;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		initialMarkRound( MarkIndex<State> &markIndex )
{
	State *p = stateList.head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = stateList.head;
		while ( q != p ) {
			/* If the states differ on final state status, out transitions or
			 * any transition data then they should be separated on the initial
			 * round. */
			if ( InitPartitionCompare<State, Transition>::Compare( p, q ) != 0 )
				markIndex.markPair(p->num, q->num);

			q = q->next;
		}
		p = p->next;
	}
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		markRound( MarkIndex<State> &markIndex )
{
	bool pairWasMarked = false;
	State *p = stateList.head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = stateList.head;
		while ( q != p ) {
			/* Should we mark the pair? */
			if ( !markIndex.isPairMarked( p->num, q->num ) ) {
				if ( MarkCompare<State, Transition>::shouldMark( markIndex, p, q ) ) {
					markIndex.markPair(p->num, q->num);
					pairWasMarked = true;
				}
			}
			q = q->next;
		}
		p = p->next;
	}

	return pairWasMarked;
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		minimizeStable()
{
	/* Set the state numbers. */
	setStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex<State> markIndex(stateList.listLength);

	/* Mark pairs where final stateness, out trans, or trans data differ. */
	initialMarkRound( markIndex );

	/* While the last round of marking succeeded in marking a state
	 * continue to do another round. */
	int modified = markRound( markIndex );
	while (modified)
		modified = markRound( markIndex );

	/* Merge pairs that are unmarked. */
	fuseUnmarkedPairs( markIndex );
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		minimizeRound()
{
	/* Nothing to do if there are no states. */
	if (stateList.listLength == 0)
		return false;

	/* Fill up an array of pointers to the states. */
	State **statePtrs = new State*[stateList.listLength];
	State *state = stateList.head;
	State **dst = statePtrs;
	while ( state != 0 ) {
		*dst = state;
		dst += 1;
		state = state->next;
	}

	bool modified = false;

	/* Sort The list. */
	MergeSort< State*, ApproxCompare<State, Transition> >::sort( 
			statePtrs, stateList.listLength );

	/* Walk the list looking for duplicates next to each other, 
	 * merge in any duplicates. */
	State **pLast = statePtrs;
	State **pState = statePtrs + 1;
	for ( int i = 1; i < stateList.listLength; i++, pState++ ) {
		if ( ApproxCompare<State, Transition>::Compare( *pLast, *pState ) == 0 ) {
			/* Last and pState are the same, so fuse together. Move forward
			 * with pState but not with pLast. If any more are identical, we
			 * must */
			fuseEquivStates( *pLast, *pState );
			modified = true;
		}
		else {
			/* Last and this are different, do not set to merge them. Move
			 * pLast to the current (it may be way behind from merging many
			 * states) and pState forward one to consider the next pair. */
			pLast = pState;
		}
	}
	delete[] statePtrs;
	return modified;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		minimizeApproximate()
{
	/* While the last minimization round succeeded in compacting states,
	 * continue to try to compact states. */
	while ( true ) {
		bool modified = minimizeRound();
		if ( ! modified )
			break;
	}
}


/* Remove states that have no path to them from the start state. Recursively
 * traverses the graph marking states that have paths into them. Then removes
 * all states that did not get marked. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		removeUnreachableStates()
{
	State *state, *next;

	/* Mark all the states that can be reached
	 * through the existing transition set. */
	markReachableFromHere( findEntry(0) );

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = stateList.head;
	while ( state ) {
		next = state->next;

		if ( state->isMarked )
			state->isMarked = false;
		else {
			detachState( state );
			stateList.detach( state );
			delete state;
		}

		state = next;
	}
}

/* Remove states that that do not lead to a final states. Works recursivly traversing
 * the graph in reverse (starting from all final states) and marking seen states. Then
 * removes states that did not get marked. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		removeDeadEndStates()
{
	State *state, *next;

	/* Mark all states that have paths to the final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ )
		markReachableFromHereReverse( *st );

	/* Start state gets honorary marking. If the machine accepts nothing we
	 * still want the start state to hang around. This must be done before the
	 * recursive call on all the final states so that it does not cause the
	 * start state in transitions to be skipped when the start state is
	 * visited by the traversal. */
	findEntry(0)->isMarked = true;

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = stateList.head;
	while (state) {
		next = state->next;

		if (state->isMarked)
			state->isMarked = false;
		else {
			detachState( state );
			stateList.detach( state );
			delete state;
		}
		
		state = next;
	}
}

/* Remove states on the misfit list. To work properly misfit accounting should
 * be on when this is called. The detaching of a state will likely cause
 * another misfit to be collected and it can then be removed. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		removeMisfits()
{
	while ( misfitList.listLength > 0 ) {
		/* Get the first state. */
		State *state = misfitList.head;

		/* Detach and delete. */
		detachState( state );

		/* The state was previously on the misfit list and detaching can only
		 * remove in transitions so the state must still be on the misfit
		 * list. */
		misfitList.detach( state );
		delete state;
	}
}

/* Remove the out data from non final states. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		stripNonFinalStates()
{
	State *state = stateList.head;
	while ( state != NULL ) {
		if ( ! state->isFinState ) {
			state->outTransFuncTable.empty();
			state->isOutPriorSet = false;
			state->outPriority = 0;
		}
		state = state->next;
	}
}

/* Walk the list of states and verify that non final states do not have out
 * data, that all stateBits are cleared, and that there are no states with
 * zero foreign in transitions. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		verifyStates()
{
	State *state = stateList.head;
	while ( state != NULL ) {
		if ( ! state->isFinState ) {
			assert( state->outTransFuncTable.tableLength == 0 );
			assert( !state->isOutPriorSet );
			assert( state->outPriority == 0 );
		}

		assert( state->stateBits == 0 );
		assert( state->foreignInTrans > 0 );

		state = state->next;
	}
}

/* Fuse src into dest because they have been deemed equivalent states.
 * Involves moving transitions into src to go into dest and invoking
 * callbacks. Src is deleted detached from the graph and deleted. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		fuseEquivStates( State *dest, State *src )
{
	/* This would get ugly. */
	assert( dest != src );

	/* Cur is a duplicate. We can merge it with trail. */
	inTransMove( dest, src );

	/* For each entry point into src, move it to dest. */
	while ( src->entryIds.tableLength > 0 ) {
		/* Change the first one. */
		int entry = src->entryIds.table[0];
		changeEntry( entry, dest );
	}

	/* Now that the ids are copied, clear src's entry id set. */
	src->entryIds.empty();
	
	/* Call user routine. */
	dest->fuseState( src );

	detachState( src );
	stateList.detach( src );
	delete src;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		fuseUnmarkedPairs( MarkIndex<State> &markIndex )
{
	State *p = stateList.head, *nextP, *q;

	/* Definition: The primary state of an equivalence class is the first state
	 * encounterd that belongs to the equivalence class. All equivalence
	 * classes have primary state including equivalence classes with one state
	 * in it. */

	/* For each unmarked pair merge p into q and delete p. q is always the
	 * primary state of it's equivalence class. We wouldn't have landed on it
	 * here if it were not, because it would have been deleted.
	 *
	 * Proof that q is the primaray state of it's equivalence class: Assume q
	 * is not the primary state of it's equivalence class, then it would be
	 * merged into some state that came before it and thus p would be
	 * equivalent to that state. But q is the first state that p is equivalent
	 * to so we have a contradiction. */

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		nextP = p->next;

		q = stateList.head;
		while ( q != p ) {
			/* If one of p or q is a final state then mark. */
			if ( ! markIndex.isPairMarked(p->num, q->num) ) {
				fuseEquivStates( q, p );
				break;
			}
			q = q->next;
		}
		p = nextP;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		fusePartitions( MinPartition<State> *parts, int numParts )
{
	/* For each partition, fuse state 2, 3, ... into state 1. */
	for ( int p = 0; p < numParts; p++ ) {
		/* Assume that there will always be at least one state. */
		State *first = parts[p].list.head, *toFuse = first->next;

		/* Put the first state back onto the main state list. Don't bother
		 * removing it from the partition list first. */
		stateList.append( first );

		/* Fuse the rest of the state into the first. */
		while ( toFuse != 0 ) {
			/* Save the next. We will trash it before it is needed. */
			State *next = toFuse->next;

			/* Put the state to be fused in to the first back onto the main
			 * list before it is fuse.  the graph. The state needs to be on
			 * the main list for the detach from the graph to work.  Don't
			 * bother removing the state from the partition list first. We
			 * need not maintain it. */
			stateList.append( toFuse );

			/* Now fuse to the first. */
			fuseEquivStates( first, toFuse );

			/* Go to the next that we saved before trashing the next pointer. */
			toFuse = next;
		}

		/* We transfered the states from the partition list into the main list without
		 * removing the states from the partition list first. Clean it up. */
		parts[p].list.abandon();
	}
}

#endif /* _RLFSM_FSMGRAPH_CPP */

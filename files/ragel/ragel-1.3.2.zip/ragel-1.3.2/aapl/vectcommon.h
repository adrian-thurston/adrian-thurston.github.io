/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

#include <new>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "table.h"

#ifdef AAPL_NAMESPACE
namespace Aapl {
#endif

/* Vector */
template < class T, class Resize = ResizeExpn > class Vector
	: public Table<T>, public Resize
{
public:
	/**
	 * \brief Initialize an empty vector with no space allocated.  
	 *
	 * If a linear resizer is used, the step defaults to 256 units of T. For a
	 * runtime vector both up and down allocation schemes default to
	 * Exponential.
	 */
	Vector() { }

	/* Create a vector with an intial number of elements. */
	Vector( int size ) { setAsNew( size ); }

	/* Create a vector of specific size and allocation. */
	Vector( int size, int allocLength );

	/* Deep copy. */
	Vector( const Vector &v );

	/* Free all mem used by the vector. */
	~Vector() { empty(); }

	/* Delete all items. */
	void empty();

	/* Abandon the contents of the vector without deleteing. */
	void abandon();

	/* Performs a shallow copy of another vector into this vector. If this
	 * vector is non-empty then its contents are lost (not freed). */
	void shallowCopy( const Vector &v );

	/**
	 * \brief Deep copy another vector into this vector.
	 *
	 * Copies the entire contents of the other vector into this vector. Any
	 * existing contents are first deleted. Equivalent to setAs.
	 */
	void deepCopy( const Vector &v )     { setAs(v.table, v.tableLength); }

	/* Perform a deep copy of another vector into this vector. */
	Vector &operator=( const Vector &v );


	/*@{*/
	/* Insert one element at position pos. */
	void insert(int pos, const T &val)   { insert(pos, &val, 1); }

	/* Insert an array of values. */
	void insert(int pos, const T *val, int len);

	/* Insert the contents of another vector. */
	void insert(int pos, const Vector &v);

	/* Insert len copies of val into the vector. */
	void insertDup(int pos, const T &val, int len);

	/* Insert one new item using the default constructor. */
	void insertNew(int pos)              { insertNew(pos, 1); }

	/* Insert len new items using default constructor. */
	void insertNew(int pos, int len);
	/*@}*/

	/*@{*/
	/* Delete one element. */
	void remove(int pos)                 { remove(pos, 1); }

	/* Delete a number of elements. */
	void remove(int pos, int len);
	/*@}*/

	/*@{*/
	/* Replace a single element. */
	void replace(int pos, const T &val)  { replace(pos, &val, 1); }

	/* Replace with an array of values. */
	void replace(int pos, const T *val, int len);

	/* Replace with the contents of another vector. */
	void replace(int pos, const Vector &v);

	/* Replace len items with len copies of val. */
	void replaceDup(int pos, const T &val, int len);

	/* Replace one item at pos with a constructed object. */
	void replaceNew(int pos)             { replaceNew(pos, 1); }

	/* Replace len items at pos with newly constructed objects. */
	void replaceNew(int pos, int len);
	/*@}*/

	/*@{*/
	/* Set the vector to be val exactly. */
	void setAs(const T &val)             { setAs(&val, 1); }

	/* Set to the contents of an array. */
	void setAs(const T *val, int len);

	/* Set to the contents of another vector. */
	void setAs(const Vector &v);

	/* Set as len copies of item. */
	void setAsDup(const T &item, int len);

	/* Set as a newly constructed object using the default constructor. */
	void setAsNew()                      { setAsNew(1); }

	/* Set as newly constructed objects using the default constructor. */
	void setAsNew(int len);
	/*@}*/

	/*@{*/
	/* Append a single element. */
	void append(const T &val)                { replace(tableLength, &val, 1); }

	/* Append an array of elements. */
	void append(const T *val, int len)       { replace(tableLength, val, len); }

	/* Append to the end of the vector from another vector. */
	void append(const Vector &v);

	/* Append len copies of item. */
	void appendDup(const T &item, int len)   { replaceDup(tableLength, item, len); }

	/* Append a newly created item. Uses the copy constructor. */
	void appendNew()                         { replaceNew(tableLength, 1); }

	/* Append newly created items. Uses the copy constructor. */
	void appendNew(int len)                  { replaceNew(tableLength, len); }
	/*@}*/
	
	/*@{*/
	/* Prepend a single element. */
	void prepend(const T &val)               { insert(0, &val, 1); }

	/* Prepend an array of elements. */
	void prepend(const T *val, int len)      { insert(0, val, len); }

	/* Prepend to the front of the vector from another vector. */
	void prepend(const Vector &v);

	/* Prepend len copies of item. */
	void prependDup(const T &item, int len)  { insertDup(0, item, len); }

	/* Prepend a newly created item. Uses the copy constructor to init. */
	void prependNew()                        { insertNew(0, 1); }

	/* Prepend newly created items. Uses the copy constructor to init. */
	void prependNew(int len)                 { insertNew(0, len); }
	/*@}*/


	/* Convenience access. */
	T &operator[](int i) const { return table[i]; }
	operator T *() const       { return table; }
	int size() const           { return tableLength; }

	/* first, last. */
	T *first() const  { return table; }
	T *last() const   { return table+tableLength-1; }

	/* Sentinals. */
	T *sfirst() const { return table-1; }
	T *slast() const  { return table+tableLength; }

	/* Vector Iterator. */
	struct Iterator
	{
		/* Construct, assign. */
		Iterator() : ptr(0) { }
		Iterator(T *ptr) : ptr(ptr) { }
		Iterator(const Vector &v) : ptr(v.table) { }

		Iterator &operator=(T *ptr)              { this->ptr = ptr; return *this; }
		Iterator &operator=(const Vector &v)    { ptr = v.table; return *this;}

		/* Cast, dereference, arrow ops. */
		operator T*() const   { return ptr; }
		T &operator *() const { return *ptr; }
		T *operator->() const { return ptr; }
		T &value() const      { return *ptr; }

		/* Arithmetic. */
		T *operator++()       { return ++ptr; }
		T *operator--()       { return --ptr; }
		T *operator++(int)    { return ptr++; }
		T *operator--(int)    { return ptr--; }

		/* List-like. */
		T *next()           { return ++ptr; }
		T *prev()           { return --ptr; }

		/* The iterator is simply a pointer. */
		T *ptr;
	};

protected:
#ifdef VECT_COMPLEX
 	int makeRawSpaceFor(int pos, int len);
#endif

	void upResize(int len);
	void downResize(int len);
};

/* Create a vector with an intial number of elements and size. */
template<class T, class Resize> Vector<T, Resize>::
		Vector( int size, int allocLength )
{
	/* Allocate the space if we are given a positive allocLength. */
	this->allocLength = allocLength;
	if ( allocLength > 0 ) {
		table = (T*) malloc(sizeof(T) * allocLength);
		if ( table == NULL )
			throw std::bad_alloc();
	}

	/* Grow to the size specified. If we did not have enough space
	 * allocated that is ok. Table will be grown to right size. */
	setAsNew( size );
}

/**
 * \brief Forget all elements in the vector.
 *
 * The contents of the vector are reset to null without without the space
 * being freed.
 */
template<class T, class Resize> void Vector<T, Resize>::
		abandon()
{
	table = NULL;
	tableLength = 0;
	allocLength = 0;
}

/**
 * \brief Shallow copy another vector into this vector. 
 *
 * The dynamic array of the other vector is copied into this vector by
 * reference. If this vector is non-empty then its contents are lost. This
 * routine must be used with care. After a shallow copy one vector should
 * abandon its contents to prevent both destructors from attempting to free
 * the common array.
 */
template<class T, class Resize> void Vector<T, Resize>::
		shallowCopy( const Vector &v )
{
	table = v.table;
	tableLength = v.tableLength;
	allocLength = v.allocLength;
}

/**
 * \brief Deep copy another vector into this vector.
 *
 * Copies the entire contents of the other vector into this vector. Any
 * existing contents are first deleted. Equivalent to setAs.
 *
 * \returns A reference to this.
 */
template<class T, class Resize> Vector<T, Resize> &Vector<T, Resize>::
		operator=( const Vector &v )
{
	setAs(v.table, v.tableLength); 
	return *this;
}

/* Append to the end of the vector from another vector. */
template<class T, class Resize> void Vector<T, Resize>::
		append(const Vector<T, Resize> &v)
{
	assert(&v != this);
	replace(tableLength, v.table, v.tableLength);
}

/**
 * \brief Prepend the contents of vector v to the front of the vector. 
 *
 * Copy constructors are used to place the elements in the vector.
 */
template<class T, class Resize> void Vector<T, Resize>::
		prepend(const Vector<T, Resize> &v)
{
	assert(&v != this);
	insert(0, v.table, v.tableLength);
}

/* Set to the contents of another vector. */
template<class T, class Resize> void Vector<T, Resize>::
		setAs(const Vector<T, Resize> &v)
{
	assert( &v != this );
	setAs(v.table, v.tableLength);
}

/* Replace with the all the contents of another vector. */
template<class T, class Resize> void Vector<T, Resize>::
		replace(int pos, const Vector<T, Resize> &v)
{
	assert(&v != this);
	replace( pos, v.table, v.tableLength );
}

/* Insert all the contents of another vector into this vector. */
template<class T, class Resize> void Vector<T, Resize>::
		insert(int pos, const Vector<T, Resize> &v)
{
	assert(&v != this);
	insert(pos, v.table, v.tableLength);
}

/* Up resize the table for len elements using Resize::upResize to tell us the
 * new length. Reads and writes allocLength. Does not read or write tableLength. */
template<class T, class Resize> void Vector<T, Resize>::
		upResize(int len)
{
	/* Ask the resizer what the new length will be. */
	int newLen = Resize::upResize(allocLength, len);

	/* Did the table grow? */
	if ( newLen > allocLength ) {
		allocLength = newLen;
		if ( table != NULL ) {
			/* Table exists already, resize it up. */
			table = (T*) realloc( table, sizeof(T) * newLen );
			if ( table == NULL )
				throw std::bad_alloc();
		}
		else {
			/* Create the table. */
			table = (T*) malloc( sizeof(T) * newLen );
			if ( table == NULL )
				throw std::bad_alloc();
		}
	}
}

/* Down resize the table for len elements using Resize::downResize to determine
 * the new length. Reads and writes allocLength. Does not read or write tableLength. */
template<class T, class Resize> void Vector<T, Resize>::
		downResize(int len)
{
	/* Ask the resizer what the new length will be. */
	int newLen = Resize::downResize( allocLength, len );

	/* Did the table shrink? */
	if ( newLen < allocLength ) {
		allocLength = newLen;
		if ( newLen == 0 ) {
			/* Simply free the table. */
			free( table );
			table = NULL;
		}
		else {
			/* Not shrinking to size zero, realloc it to the smaller size. */
			table = (T*) realloc( table, sizeof(T) * newLen );
			if ( table == NULL )
				throw std::bad_alloc();
		}
	}
}

#ifdef AAPL_NAMESPACE
}
#endif


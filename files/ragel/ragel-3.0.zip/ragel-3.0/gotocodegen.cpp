/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "gotocodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"

/* Init base data. */
GotoCodeGen::GotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FsmCodeGen(fsmName, parseData, machine, out)
{ }

/* Emit the goto to take for a given transition. */
std::ostream &GotoCodeGen::TRANS_GOTO( FsmMachTrans *trans, int level )
{
	TABS(level) << "goto tr" << trans - machine->allTrans << ";";
	return out;
}

void GotoCodeGen::emitRangeBSearch( FsmMachState *state, int level, int low, int high )
{
	/* Get the mid position, staying on the lower end of the range. */
	int mid = ((low + high) / 2) & ~1;

	/* Get the transition to take on hitting the mid. */
	FsmMachTrans *trans = &machine->allTrans[state->rangeIndPtr[mid/2]];

	/* Determine if we need to look higher or lower. */
	bool anyLower = mid != low;
	bool anyHigher = mid != high;

	/* Determine if the keys at mid are the limits of the alphabet. */
	bool limitLow = state->rangeIndKey[mid] == parseData->lowerKey;
	bool limitHigh = state->rangeIndKey[mid+1] == parseData->upperKey;

	if ( anyLower && anyHigher ) {
		/* Can go lower and higher than mid. */
		TABS(level) << "if ( *_p < "; KEY(state->rangeIndKey[mid]) << " ) {\n";
		emitRangeBSearch( state, level+1, low, mid-2 );
		TABS(level) << "} else if ( *_p > "; KEY(state->rangeIndKey[mid+1]) << " ) {\n";
		emitRangeBSearch( state, level+1, mid+2, high );
		TABS(level) << "} else\n";
		TRANS_GOTO(trans, level+1) << "\n";
	}
	else if ( anyLower && !anyHigher ) {
		/* Can go lower than mid but not higher. */
		TABS(level) << "if ( *_p < "; KEY(state->rangeIndKey[mid]) << " ) {\n";
		emitRangeBSearch( state, level+1, low, mid-2 );

		/* if the higher is the highest in the alphabet then there is no
		 * sense testing it. */
		if ( limitHigh ) {
			TABS(level) << "} else\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			TABS(level) << "} else if ( *_p <= "; KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
	else if ( !anyLower && anyHigher ) {
		/* Can go higher than mid but not lower. */
		TABS(level) << "if ( *_p > "; KEY(state->rangeIndKey[mid+1]) << " ) {\n";
		emitRangeBSearch( state, level+1, mid+2, high );

		/* If the lower end is the lowest in the alphabet then there is no
		 * sense testing it. */
		if ( limitLow ) {
			TABS(level) << "} else\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			TABS(level) << "} else if ( *_p >= "; KEY(state->rangeIndKey[mid]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
	else {
		/* Cannot go higher or lower than mid. It's mid or bust. What
		 * tests to do depends on limits of alphabet. */
		if ( !limitLow && !limitHigh ) {
			TABS(level) << "if ( "; KEY(state->rangeIndKey[mid]) << " <= *_p && *_p <= ";
				KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else if ( limitLow && !limitHigh ) {
			TABS(level) << "if ( *_p <= "; KEY(state->rangeIndKey[mid+1]) << " )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else if ( !limitLow && limitHigh ) {
			TABS(level) << "if ( "; KEY(state->rangeIndKey[mid]) << " <= *_p )\n";
			TRANS_GOTO(trans, level+1) << "\n";
		}
		else {
			/* Both high and low are at the limit. No tests to do. */
			TRANS_GOTO(trans, level+1) << "\n";
		}
	}
}

std::ostream &GotoCodeGen::FIRST_FINAL_STATE()
{
	/* First non final is the number of machine states (includes error state)
	 * minus the number of final states. */
	out << (machine->numStates - machine->numFinStates);
	return out;
}

std::ostream &GotoCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	for ( int fnum = 0; fnum < parseData->numActionIndex; fnum++ ) {
		/* Get the function data. Print the case label.  */
		Action *action = parseData->actionIndex[fnum];
		out << "\tcase " << fnum << ":\n";

		/* Write the preprocessor line info for going into the source file. */
		out << "# " << action->loc.line << " \""; LDIR_PATH(inputFile) << "\"\n";

		/* Write the block and close it off. */
		out << "\t{"; ACTION(action, 0) << "} break;\n";
	}

	/* Write the directive for going back into the output file. The line
	 * number is for the next line, so add one. */
	out << "# " << outFilter->line + 1 << " \""; LDIR_PATH(outputFile) << "\"\n";
	return out;
}

/* Emit the switch statement for jumping into the machine. Our current state
 * is represented by an integer and we need to use it to get into the correct
 * place in the machine. */
std::ostream &GotoCodeGen::JUMP_IN_SWITCH()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "\t\tcase " << st << ": goto st" << st << ";\n";
	}
	out << "\t\tdefault: return;\n";
	return out;
};

std::ostream &GotoCodeGen::STATE_GOTOS( bool wantAdvance )
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Virtual function for writing the transitions above a state. */
		aboveStateGotos( st );

		/* Get the fsm machine state. */
		FsmMachState *state = machine->allStates+st;

		if ( state->labelNeeded ) {
			out << 
				"st" << st << ":\n"
				"	if ( --_len == 0 )\n"
				"		goto out" << st << ";\n";
		}
		out << "case " << st << ":\n";


		if ( state->numIndex == 0 ) {
			/* If there are no single keys. We may need to at least advance
			 * the pointer to the current char. */
			if ( wantAdvance )
				out << "\t++_p;\n";
		}
		if ( state->numIndex == 1 ) {
			/* If there is a single single key then write it out as an if. */
			out << "\tif ( *";
			if ( wantAdvance )
				out << "++";
			out << "_p == "; KEY(state->transIndKey[0]) << " )\n\t\t"; 

			/* Virtual function for writing the target of the transition. */
			TRANS_GOTO(&machine->allTrans[state->transIndPtr[0]], 0) << "\n";
		}
		else if ( state->numIndex > 1 ) {
			/* Write out single keys in a switch if there is more than one. */
			out << "\tswitch( *";
			if ( wantAdvance )
				out << "++";
			out << "_p ) {\n";

			/* Write out the single indicies. */
			for ( int j = 0; j < state->numIndex; j++ ) {
				out << "\t\tcase "; KEY(state->transIndKey[j]) << ": ";

				/* Emit the transition. */
				FsmMachTrans *trans = &machine->allTrans[state->transIndPtr[j]];
				TRANS_GOTO(trans, 0) << "\n";
			}
			/* Close off the transition switch. */
			out << "\t}\n";
		}

		/* Default case is to binary search for the ranges, if that fails then */
		if ( state->numRange > 0 )
			emitRangeBSearch( state, 1, 0, (state->numRange-1)*2 );

		/* Get the default index and write it. Default will always be used. */
		FsmMachTrans *trans = &machine->allTrans[state->dflIndex];
		TRANS_GOTO( trans, 1 ) << "\n";
	}
	return out;
}

std::ostream &GotoCodeGen::TRANSITIONS()
{
	/* Emit any transitions that have functions and that go to 
	 * this state. */
	FsmMachTrans *trans = machine->allTrans;
	for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
		/* Write the label for the transition so it can be jumped to. */
		out << "\ttr" << tr << ": ";

		/* Destination state. */
		out << "_cs = " << trans->toState << "; ";

		if ( trans->funcs == FUNC_NO_FUNC ) {
			/* No code to execute, just loop around. */
			out << "goto again;\n";
		}
		else {
			/* Write out the transition func. */
			out << "goto f" << trans->funcs << ";\n";
		}
	}
	return out;
}

/* Set up labelNeeded flag for each state. */
void GotoCodeGen::setLabelsNeeded()
{
	for ( int st = 0; st < machine->numStates; st++ )
		machine->allStates[st].labelNeeded = false;
}

std::ostream &GotoCodeGen::EXEC_FUNCS()
{
	/* Make labels that set funcs and jump to execFuncs. Loop func indicies. */
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		out << "\tf" << i << ": funcs = "; FSM_NAME() << "_f+" << 
				machine->transFuncIndex[i] << "; goto execFuncs;\n";
	}

	out <<
		"\n"
		"execFuncs:\n"
		"	nfuncs = *funcs++;\n"
		"	while ( nfuncs-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() <<
		"		}\n"
		"	}\n"
		"	goto again;\n";
	return out;
}

std::ostream &GotoCodeGen::EXIT_STATES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		if ( machine->allStates[st].labelNeeded ) {
			out << "\tout" << st << ": _cs = " << st;

			if ( st == STATE_ERR_STATE )
				out << "; goto out_err;\n";
			else
				out << "; goto out_ok;\n";
		}
	}
	return out;
}

std::ostream &GotoCodeGen::FINISH_CASES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		if ( state->isFinState && state->outFuncs != FUNC_NO_FUNC ) {
			/* Write the case label. */
			out << "\t\tcase " << st << ": ";

			/* Write the goto func. */
			out << "goto f" << state->outFuncs << ";\n";
		}
	}
	
	return out;
}

std::ostream &GotoCodeGen::GOTO( NameInst *name )
{
	/* Lookup the target. FIXME: this may return more than one. */
	FsmMachine::EntryMapEl *targ = machine->entryMap.find( name->id );
	out << "{_cs = " << targ->value << "; goto again;}";
	return out;
}

std::ostream &GotoCodeGen::STACK( int size )
{
	out << "int _top, _st[" << size << "];";
	return out;
}

/* Init base data. */
CGotoCodeGen::CGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out ) 
: 
	GotoCodeGen(fsmName, parseData, machine, out)
{ }

std::ostream &CGotoCodeGen::CALL( NameInst *name, int targState )
{
	/* Lookup the target. FIXME: this may return more than one. */
	FsmMachine::EntryMapEl *targ = machine->entryMap.find( name->id );
	out << "{fsm->_st[fsm->_top++] = _cs; _cs = " << 
			targ->value << "; goto again;}";
	return out;
}

std::ostream &CGotoCodeGen::RET()
{
	out << "{_cs = fsm->_st[--fsm->_top]; goto again;}";
	return out;
}


void CGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Init the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_OFFSET() << ";\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() )
		out << "	fsm->_top = 0;\n";

	INIT_CODE() <<
		"	if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	int _len = dlen+1;\n"
		"	int _cs = fsm->_cs;\n";

	if ( anyTransFuncs() )
		out << "\tint *funcs, nfuncs;\n";

	out << "\n";

	if ( anyOutTransFuncs() ) {
		out << 
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out << 
		"again:\n"
		"	_p++, _len--;\n"
		"	if ( _cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( _len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS( false ) <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyOutTransFuncs() ) {
		out << 
			"finishInput:\n"
			"	_len = 1;\n"
			"	switch( _cs ) {\n";
			FINISH_CASES() << 
			"	}\n"
			"	if ( _cs == 0 )\n"
			"		goto out_err;\n"
			"\n";
	}
	
	out <<
		"out_ok:\n"
		"	fsm->_cs = _cs;\n"
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	fsm->_cs = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyOutTransFuncs() ) {
		/* May need to execute code in the action loop. Must use special
		 * params to execute func. */
		out << "	return "; FSM_NAME() << "_execute( fsm, 0, -1 );\n";
	}
	else {
		out << 
			"	if ( fsm->_cs == 0 )\n"
			"		return -1;\n"
			"	if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out <<
		"}\n"
		"\n";
}

/* Init base data. */
CCGotoCodeGen::CCGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
: 
	GotoCodeGen(fsmName, parseData, machine, out)
{ }

std::ostream &CCGotoCodeGen::CALL( NameInst *name, int targState )
{
	/* Lookup the target. FIXME: this may return more than one. */
	FsmMachine::EntryMapEl *targ = machine->entryMap.find( name->id );
	out << "{this->_st[this->_top++] = _cs; _cs = " << 
			targ->value << "; goto again;}";
	return out;
}

std::ostream &CCGotoCodeGen::RET()
{
	out << "{_cs = this->_st[--this->_top]; goto again;}";
	return out;
}

void CCGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Init the fsm. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_OFFSET() << ";\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() )
		out << "	this->_top = 0;\n";

	INIT_CODE() <<
		"	if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";
	
	out <<
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	int _len = dlen+1;\n"
		"	int _cs = this->_cs;\n";

	if ( anyTransFuncs() )
		out << "\tint *funcs, nfuncs;\n";

	out << "\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out << 
		"again:\n"
		"	_p++, _len--;\n"
		"	if ( _cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( _len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS( false ) <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"finishInput:\n"
			"	_len = 1;\n"
			"	switch( _cs ) {\n";
			FINISH_CASES() << 
			"	}\n"
			"	if ( _cs == 0 )\n"
			"		goto out_err;\n"
			"\n";
	}

	out <<
		"out_ok:\n"
		"	this->_cs = _cs;\n"
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	this->_cs = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n";
	
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";
	
	if ( anyOutTransFuncs() ) {
		/* May need to execute code in the action loop. Must use special
		 * params to execute func. */
		out << "	return execute( 0, -1 );\n";
	}
	else {
		out << 
			"	if ( this->_cs == 0 )\n"
			"		return -1;\n"
			"	if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out <<
		"}\n"
		"\n";
}

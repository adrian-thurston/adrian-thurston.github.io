/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <iomanip>
#include <errno.h>
#include <limits.h>
#include <stdlib.h>

/* Parsing. */
#include "ragel.h"
#include "ptreetypes.h"
#include "rlparse.h"
#include "parsedata.h"
#include "parsetree.h"

/* Machine building. */
#include "fsmmachine.h"

/* Code generators. */
#include "tabcodegen.h"
#include "ftabcodegen.h"
#include "gotocodegen.h"
#include "fgotocodegen.h"
#include "ipgotocodegen.h"

/* Dumping the fsm. */
#include "fsmdump.h"
#include "gvdotgen.h"

using namespace std;

char machineMain[] = "main";

/* The minimum chars are the absolute value of the real minimum because the
 * sign is stored separately in integers read in so they are compared in the
 * positive. Each is casted to an unsigned because the data part of the number
 * is in unsigned int size. 
 *
 * FIXME: Not terribly portable...
 */
#define RL_MIN_CHAR    ((int)((char)0x80))
#define RL_MAX_CHAR    ((int)((char)0x7f))
#define RL_MIN_UCHAR   ((int)((unsigned char)0x0))
#define RL_MAX_UCHAR   ((int)((unsigned char)0xff))
#define RL_MIN_SHORT   ((int)((short)0x8000))
#define RL_MAX_SHORT   ((int)((short)0x7fff))
#define RL_MIN_USHORT  ((int)((unsigned short)0x0000))
#define RL_MAX_USHORT  ((int)((unsigned short)0xffff))
#define RL_MIN_INT     ((int)((int)0x80000000))
#define RL_MAX_INT     ((int)((int)0x7fffffff))
#define RL_MIN_UINT    ((int)((unsigned int)0x00000000))
#define RL_MAX_UINT    ((int)((unsigned int)0xffffffff))

InputLoc::InputLoc( const BISON_YYLTYPE &loc )
:
	line(loc.first_line), 
	col(loc.first_column)
{
}

Action::Action( const InputLoc &loc, char *name, char *data, int id )
:
	loc(loc),
	name(name),
	data(data), 
	id(id),

	nameTargs(0),

	isRegAction(false), 
	isOutAction(false),
	regActionId(0),
	outActionId(0)
{
}

Action::~Action()
{
	delete[] name;
	delete[] data;
}

/* Initialization. */
BlockIter::BlockIter( char *bd )
{
	ptr = bd;
	i = 0;
	loadNext();
}

void BlockIter::operator=( char *bd )
{
	ptr = bd;
	i = 0;
	loadNext();
}
		
void BlockIter::loadNext()
{
	type = *ptr++;
	data = ptr;
	if ( type == CB_TEXT || type == CB_JUMP || 
			type == CB_CALL || type == CB_STACK )
		ptr += strlen(data);
	ptr += 1;
}


/* Perform minimization after an operation according 
 * to the command line args. */
void afterOpMinimize( FsmAp *fsm )
{
	/* Switch on the prefered minimization algorithm. */
	if ( minimizeEveryOp ) {
		if ( minimizeLevel != MinimizeNone ) {
			/* First clean up the graph. FsmAp operations may leave these lying
			 * around.  There should be no dead end states however. The
			 * subtract intersection operators are the only places where they
			 * may be created and those operators clean them up. */
			fsm->removeUnreachableStates();
		}

		switch ( minimizeLevel ) {
			case MinimizeNone:
				break;
			case MinimizeApprox:
				fsm->minimizeApproximate();
				break;
			case MinimizePartition1:
				fsm->minimizePartition1();
				break;
			case MinimizePartition2:
				fsm->minimizePartition2();
				break;
			case MinimizeStable:
				fsm->minimizeStable();
				break;
		}
	}
}

/* Count the transitions in the fsm by walking the state list. */
int countTransitions( FsmAp *fsm )
{
	int numTrans = 0;
	StateAp *state = fsm->stateList.head;
	while ( state != 0 ) {
		numTrans += state->outList.length();
		numTrans += state->outRange.length() / 2;
		if ( state->outDefault != 0 )
			numTrans += 1;
		state = state->next;
	}
	return numTrans;
}

/* Count the indicies in a fsm machine by walking array of states. */
int countIndicies( FsmMachine &machine )
{
	int sum = 0;
	for ( int state = 0; state < machine.numStates; state++ )
		sum += machine.allStates[state].numIndex;
	return sum;
}

long makeFsmKeyHex( char *str, const InputLoc &loc, ParseData *pd )
{
	long retVal = 0;

	/* Convert the number to a decimal. Reset errno so we can check for
	 * overflow or underflow. In the event of an error, sets the return val to
	 * the upper or lower bound being tested against. */
	errno = 0;
	unsigned long ul = strtoul( str, 0, 16 );

	switch ( pd->alphType ) {
	case AT_Char: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_UCHAR ) {
			error(loc) << "literal " << str << 
					" overflows char alphabet" << endl;
			ul = RL_MAX_UCHAR;
		}

		/* Cast to a char to get the proper sign, then extend to an integer. */
		retVal = (char)ul;
		break;
	}

	case AT_UnsignedChar: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_UCHAR ) {
			error(loc) << "literal " << str << 
					" overflows unsigned char alphabet" << endl;
			ul = RL_MAX_UCHAR;
		}

		/* Store cast to unsigned char, then extend to an integer. */
		retVal = (unsigned char)ul;
		break;
	}

	case AT_Short: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_USHORT ) {
			error(loc) << "literal " << str << 
					" overflows short alphabet" << endl;
			ul = RL_MAX_USHORT;
		}

		/* Cast to a short to get the proper sign, then extend to an integer. */
		retVal = (short)ul;
		break;
	}

	case AT_UnsignedShort: {
		/* Check against upper bound. */
		if ( ul > RL_MAX_USHORT ) {
			error(loc) << "literal " << str << 
					" overflows unsigned short alphabet" << endl;
			ul = RL_MAX_USHORT;
		}

		/* Store cast to unsigned short, then extend to an integer. */
		retVal = (unsigned short)ul;
		break;
	}

	case AT_Int: {
		/* Check against upper bound. */
		if ( errno == ERANGE && ul == ULONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows int alphabet" << endl;
			ul = ULONG_MAX;
		}

		/* Store in integer format. */
		retVal = (int)ul;
		break;
	}

	case AT_UnsignedInt: {
		/* Check against upper bound. */
		if ( errno == ERANGE && ul == ULONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows unsigned int alphabet" << endl;
			ul = ULONG_MAX;
		}

		/* Store in integer format. */
		retVal = (int)ul;
		break;
	}}
	return retVal;
}

long makeFsmKeyDec( char *str, const InputLoc &loc, ParseData *pd )
{
	long retVal = 0;

	switch ( pd->alphType ) {
	case AT_Char: {
		/* Convert the number to a decimal. If there is overflow or underflow
		 * the num will be set to LONG_MIN/LONG_MAX which are way too low and
		 * high for char anyways so no need to check. */
		retVal = strtol( str, 0, 10 );

		/* Check against lower bound. */
		if ( retVal < RL_MIN_CHAR ) {
	 		error(loc) << "literal " << str << 
					" underflows char alphabet" << endl;
			retVal = RL_MIN_CHAR;
		}

		/* Check against upper bound. */
		if ( retVal > RL_MAX_CHAR ) {
			error(loc) << "literal " << str << 
					" overflows char alphabet" << endl;
			retVal = RL_MAX_CHAR;
		}
		break;
	}

	case AT_UnsignedChar: {
		/* Can't allow a negative decimal number for unsigned char type. */
		if ( str[0] == '-' ) {
			/* Recover by advancing over the dash. */
			error(loc) << "literal " << str << 
					" underflows unsigned char alphabet" << endl;
			str += 1;
		}

		/* Convert to an unsigned number and bounds check it. */
		unsigned long ul = strtoul( str, 0, 10 );
		if ( ul > RL_MAX_UCHAR ) {
			error(loc) << "literal " << str << 
					" overflows unsigned char alphabet" << endl;
			ul = RL_MAX_UCHAR;
		}

		/* Store in integer format. */
		retVal = (int) ul;
		break;
	}

	case AT_Short: {
		/* Convert the number to a decimal. If there is overflow or underflow
		 * the num will be set to the high or low limits which are exceed the
		 * bounds for short so no need to check. */
		retVal = strtol( str, 0, 10 );

		/* Check against lower bound. */
		if ( retVal < RL_MIN_SHORT ) {
	 		error(loc) << "literal " << str << 
					" underflows short alphabet" << endl;
			retVal = RL_MIN_SHORT;
		}

		/* Check against upper bound. */
		if ( retVal > RL_MAX_SHORT ) {
			error(loc) << "literal " << str << 
					" overflows short alphabet" << endl;
			retVal = RL_MAX_SHORT;
		}
		break;
	}

	case AT_UnsignedShort: {
		/* Can't allow a negative decimal number for unsigned short type. */
		if ( str[0] == '-' ) {
			/* Recover by skippping the dash. */
			error(loc) << "literal " << str << 
					" underflows unsigned short alphabet" << endl;
			str += 1;
		}

		/* Convert to an unsigned number and bounds check it. */
		unsigned long ul = strtoul( str, 0, 10 );
		if ( ul > RL_MAX_USHORT ) {
			error(loc) << "literal " << str << 
					" overflows unsigned short alphabet" << endl;
			ul = RL_MAX_USHORT;
		}

		/* Store in integer format. */
		retVal = (int) ul;
		break;
	}

	case AT_Int: {
		/* Convert the number to a decimal. First reset errno so we can check
		 * for overflow or underflow. */
		errno = 0;
		retVal = strtol( str, 0, 10 );

		/* Check lower bound. */
		if ( errno == ERANGE && retVal == LONG_MIN ) {
	 		error(loc) << "literal " << str << 
					" underflows int alphabet" << endl;
			retVal = LONG_MIN;
		}

		/* Check upper bound. */
		if ( errno == ERANGE && retVal == LONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows int alphabet" << endl;
			retVal = LONG_MAX;
		}
		break;
	}

	case AT_UnsignedInt: {
		/* Cannot allow negative numbers for an unsigned type. */
		if ( str[0] == '-' ) {
			/* Recover by skipping the dash. */
			error(loc) << "literal " << str << 
					" underflows unsigned int alphabet" << endl;
			str += 1;
		}

		/* Convert to an unsigned number and bounds check it. */
		errno = 0;
		unsigned int ul = strtoul( str, 0, 10 );
		if ( errno == ERANGE && ul == ULONG_MAX ) {
			error(loc) << "literal " << str << 
					" overflows unsigned int alphabet" << endl;
			ul = ULONG_MAX;
		}

		/* Store in integer format. */
		retVal = (int) ul;
		break;
	}}
	return retVal;
}

/* Make an fsm key in int format (what the fsm graph uses) from an alphabet
 * number returned by the parser. Validates that the number doesn't overflow
 * the alphabet type. */
long makeFsmKeyNum( char *str, const InputLoc &loc, ParseData *pd )
{
	/* Switch on hex/decimal format. */
	if ( str[0] == '0' && str[1] == 'x' )
		return makeFsmKeyHex( str, loc, pd );
	else
		return makeFsmKeyDec( str, loc, pd );
}

/* Make an fsm int format (what the fsm graph uses) from a single character.
 * Performs proper conversion depending on signed/unsigned property of the
 * alphabet. */
long makeFsmKeyChar( char c, ParseData *pd )
{
	long retVal;
	if ( pd->isAlphSigned() ) {
		/* Copy from a char type. */
		retVal = c;
	}
	else {
		/* Copy from an unsigned byte type. */
		retVal = (unsigned char)c;
	}
	return retVal;
}

/* Make an fsm key array in int format (what the fsm graph uses) from a string
 * of characters. Performs proper conversion depending on signed/unsigned
 * property of the alphabet. */
void makeFsmKeyArray( long *result, char *data, int len, ParseData *pd )
{
	if ( pd->isAlphSigned() ) {
		/* Copy from a char star type. */
		char *src = data;
		for ( int i = 0; i < len; i++ )
			result[i] = src[i];
	}
	else {
		/* Copy from an unsigned byte ptr type. */
		unsigned char *src = (unsigned char*) data;
		for ( int i = 0; i < len; i++ )
			result[i] = src[i];
	}
}

/* Make a builtin type. Depends on the signed nature of the alphabet type. */
FsmAp *makeBuiltin( BuiltinMachine builtin, ParseData *pd )
{
	/* FsmAp created to return. */
	FsmAp *retFsm = 0;
	bool isSigned = pd->isAlphSigned();

	switch ( builtin ) {
	case BT_Any: {
		/* All characters. */
		retFsm = new FsmAp( isSigned );
		retFsm->dotFsm( );
		break;
	}
	case BT_Ascii: {
		/* Ascii characters 0 to 127. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( 0, 127 );
		break;
	}
	case BT_Extend: {
		/* Ascii extended characters. This is the full byte range. Dependent
		 * on signed, vs no signed. If the alphabet is one byte then just use
		 * dot fsm. */
		retFsm = new FsmAp( isSigned );
		if ( pd->alphType == AT_Char || pd->alphType == AT_UnsignedChar )
			retFsm->dotFsm( );
		else if ( isSigned )
			retFsm->rangeFsm( -128, 127 );
		else
			retFsm->rangeFsm( 0, 255 );
		break;
	}
	case BT_Alpha: {
		/* Alpha [A-Za-z]. */
		FsmAp *upper = new FsmAp( isSigned ), *lower = new FsmAp( isSigned );
		upper->rangeFsm( 'A', 'Z' );
		lower->rangeFsm( 'a', 'z' );
		upper->unionOp( lower );
		upper->minimizePartition2();
		retFsm = upper;
		break;
	}
	case BT_Digit: {
		/* Digits [0-9]. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( '0', '9' );
		break;
	}
	case BT_Alnum: {
		/* Alpha numerics [0-9A-Za-z]. */
		FsmAp *digit = new FsmAp( isSigned ), *lower = new FsmAp( isSigned );
		FsmAp *upper = new FsmAp( isSigned );
		digit->rangeFsm( '0', '9' );
		upper->rangeFsm( 'A', 'Z' );
		lower->rangeFsm( 'a', 'z' );
		digit->unionOp( upper );
		digit->unionOp( lower );
		digit->minimizePartition2();
		retFsm = digit;
		break;
	}
	case BT_Lower: {
		/* Lower case characters. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( 'a', 'z' );
		break;
	}
	case BT_Upper: {
		/* Upper case characters. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( 'A', 'Z' );
		break;
	}
	case BT_Cntrl: {
		/* Control characters. */
		FsmAp *cntrl = new FsmAp( isSigned ), *highChar = new FsmAp( isSigned );
		cntrl->rangeFsm( 0, 31 );
		highChar->concatFsm( 127 );
		cntrl->unionOp( highChar );
		cntrl->minimizePartition2();
		retFsm = cntrl;
		break;
	}
	case BT_Graph: {
		/* Graphical ascii characters [!-~]. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( '!', '~' );
		break;
	}
	case BT_Print: {
		/* Printable characters. Same as graph except includes space. */
		retFsm = new FsmAp( isSigned );
		retFsm->rangeFsm( ' ', '~' );
		break;
	}
	case BT_Punct: {
		/* Punctuation. */
		FsmAp *range1 = new FsmAp( isSigned ), *range2 = new FsmAp( isSigned );
		FsmAp *range3 = new FsmAp( isSigned ), *range4 = new FsmAp( isSigned );
		range1->rangeFsm( '!', '/' );
		range2->rangeFsm( ':', '@' );
		range3->rangeFsm( '[', '`' );
		range4->rangeFsm( '{', '~' );
		range1->unionOp( range2 );
		range1->unionOp( range3 );
		range1->unionOp( range4 );
		range1->minimizePartition2();
		retFsm = range1;
		break;
	}
	case BT_Space: {
		/* Whitespace: [\t\v\f\n\r ]. */
		FsmAp *cntrl = new FsmAp( isSigned ), *space = new FsmAp( isSigned );
		cntrl->rangeFsm( '\t', '\r' );
		space->concatFsm( ' ' );
		cntrl->unionOp( space );
		cntrl->minimizePartition2();
		retFsm = cntrl;
		break;
	}
	case BT_Xdigit: {
		/* Hex digits [0-9A-Fa-f]. */
		FsmAp *digit = new FsmAp( isSigned ), *upper = new FsmAp( isSigned );
		FsmAp *lower = new FsmAp( isSigned );
		digit->rangeFsm( '0', '9' );
		upper->rangeFsm( 'A', 'F' );
		lower->rangeFsm( 'a', 'f' );
		digit->unionOp( upper );
		digit->unionOp( lower );
		digit->minimizePartition2();
		retFsm = digit;
		break;
	}}

	return retFsm;
}

/*
 * ParseData
 */

/* Initialize the structure that will collect info during the parse of a
 * machine. */
ParseData::ParseData( const String &fileName )
:	
	actionIndex(0),
	numActionIndex(0),
	regActionIndex(0),
	numRegActionIndex(0),
	outActionIndex(0),
	numOutActionIndex(0),

	nextActionId(0), 
	nextPriorKey(0),
	nextNameId(0),

	machineGiven(false), 
	alphType(AT_Char),
	fileName(fileName),
	errorCount(0),

	curActionOrd(0),
	curPriorOrd(0),

	rootName(0)
{
	/* Initialize the dictionary of graphs. This is our symbol table. The
	 * initialization needs to be done on construction which happens at the
	 * beginning of a machine spec so any assignment operators can reference
	 * the builtins. */
	initGraphDict();
}

/* Clean up the data collected during a parse. */
ParseData::~ParseData()
{
	if ( actionIndex != 0 )
		delete[] actionIndex;

	/* Delete all the nodes in the action list. Will cause all the
	 * string data that represents the actions to be deallocated. */
	actionList.empty();
	dataList.empty();
	initCodeList.empty();
}

/* Make a name id in the current name instantiation scope if it is not
 * already there. */
NameInst *ParseData::addNameInst( char *label )
{
	NameMapEl *lastEl;
	if ( curNameInst->children.insert( label, &lastEl ) ) {
		/* Create the name instantitaion object. */
		lastEl->value = new NameInst( label, nextNameId++ );
	}
	return lastEl->value;
}

NameInst *ParseData::findNameInst( char *label )
{
	NameMapEl *entryEl = curNameInst->children.find( label );
	return entryEl != 0 ? entryEl->value : 0;
}

void ParseData::unsetObsoleteEntries( FsmAp *graph )
{
	/* Loop the reference names and increment the usage. Names that are no
	 * longer needed will be unset in graph. */
	for ( NameVect::Iter ref = curNameInst->referencedNames; ref.lte(); ref++ ) {
		/* Get the name. */
		NameInst *name = *ref;
		name->numUses += 1;

		/* If the name is no longer needed unset its corresponding entry. */
		if ( name->numUses == name->numRefs )
			graph->unsetEntry( name->id );
	}
}

void ParseData::resolveJump( Action *action, char *data, int i )
{
	/* If only referenced by one factor with aug, then search at that local
	 * level first. Then check the global level. */
	NameMapEl *nameEl = 0;
	if ( action->actionRefs.length() == 1 ) {
		/* Get the place where the reference happens. */
		FactorWithAug *refFrom = action->actionRefs[0];

		/* Look for the name in the owning scope of the factor with aug. */
		nameEl = refFrom->inNameScope->children.find( data );
	}

	/* If not found in the local scope, look in global. */
	if ( nameEl == 0 )
		nameEl = rootName->children.find( data );

	if ( nameEl != 0 ) {
		/* Save the resolved name and note the reference in the name. This
		 * will cause the entry point to survive to the end of the graph
		 * generating walk. */
		action->nameTargs[i] = nameEl->value;
		nameEl->value->numRefs += 1;
	}
	else {
		/* If not found then complain. */
		error(action->loc) << "could not resolve target " << data << endl;
	}
}

/* Resolve references to labels in actions. */
void ParseData::resolveActionNameRefs()
{
	for ( ActionList::Iter act = actionList; act.lte(); act++ ) {
		/* Count the number of items in the action. */
		int numItems = 0;
		for ( BlockIter item = act->data; item.lte(); item++ )
			numItems += 1;

		/* Allocate array of name targs for resolved actions. */
		act->nameTargs = new NameInst*[numItems];
		memset( act->nameTargs, 0, sizeof(NameInst*)*numItems );

		for ( BlockIter item = act->data; item.lte(); item++ ) {
			switch ( item.type ) {
			case CB_JUMP:
				resolveJump( act, item.data, item.i );
				break;
			case CB_CALL:
				resolveJump( act, item.data, item.i );
				break;
			case CB_HOLD:
			case CB_CHAR:
			case CB_TEXT:
			case CB_RET:
				/* Uniniteresting, skip. */
				break;
			}
		}
	}
}

/* Walk a name tree starting at from and fill the name index. */
void ParseData::fillNameIndex( NameInst *from )
{
	/* Fill the value for from in the name index. */
	nameIndex[from->id] = from;

	/* Walk the name map. */
	for ( NameMap::Iter name = from->children; name.lte(); name++ )
		fillNameIndex( name->value );

	/* Walk the list of anonymous children. */
	for ( NameVect::Iter anon = from->anonChildren; anon.lte(); anon++ )
		fillNameIndex( *anon );
}

/* Build the name tree and supporting data structures. */
void ParseData::makeNameTree()
{
	/* Create the root name and set up curNameInst for the walk. */
	rootName = new NameInst( 0, nextNameId++ );
	curNameInst = rootName;

	/* First make the name tree. */
	for ( GraphList::Iter glel = instanceList; glel.lte(); glel++ ) {
		/* Recurse on the instance. */
		glel->value->makeNameTree( this );
	}
	
	/* The number of nodes in the tree can now be given by nextNameId */
	nameIndex = new NameInst*[nextNameId];
	memset( nameIndex, 0, sizeof(NameInst*)*nextNameId );
	fillNameIndex( rootName );
}


/* Is the alphabet type a signed type? */
bool ParseData::isAlphSigned()
{
	return alphType == AT_Char || alphType == AT_Short || alphType == AT_Int;
}

void ParseData::createBuiltin( char *name, BuiltinMachine builtin )
{
	Expression *expression = new Expression( builtin );
	Join *join = new Join( expression );
	VarDef *varDef = new VarDef( name, join );
	GraphDictEl *graphDictEl = new GraphDictEl( name, varDef );
	graphDict.insert( graphDictEl );
}

/* Initialize the graph dict with builtin types. */
void ParseData::initGraphDict( )
{
	createBuiltin( "any", BT_Any );
	createBuiltin( "ascii", BT_Ascii );
	createBuiltin( "extend", BT_Extend );
	createBuiltin( "alpha", BT_Alpha );
	createBuiltin( "digit", BT_Digit );
	createBuiltin( "alnum", BT_Alnum );
	createBuiltin( "lower", BT_Lower );
	createBuiltin( "upper", BT_Upper );
	createBuiltin( "cntrl", BT_Cntrl );
	createBuiltin( "graph", BT_Graph );
	createBuiltin( "print", BT_Print );
	createBuiltin( "punct", BT_Punct );
	createBuiltin( "space", BT_Space );
	createBuiltin( "xdigit", BT_Xdigit );
}

/* Set the alphabet type. If type types are not valid returns false. */
bool ParseData::setAlphType( String s1, String s2 )
{
	bool valid = false;
	if ( strcmp( s1, "unsigned" ) == 0 ) {
		if ( strcmp( s2, "char" ) == 0 ) {
			alphType = AT_UnsignedChar;
			valid = true;
		}
		else if ( strcmp( s2, "short" ) == 0 ) {
			alphType = AT_UnsignedShort;
			valid = true;
		}
		else if ( strcmp( s2, "int" ) == 0 ) {
			alphType = AT_UnsignedInt;
			valid = true;
		}
	}
	return valid;
}

/* Set the alphabet type. If type types are not valid returns false. */
bool ParseData::setAlphType( String s1 )
{
	bool valid = false;
	if ( strcmp( s1, "char" ) == 0 ) {
		alphType = AT_Char;
		valid = true;
	}
	else if ( strcmp( s1, "short" ) == 0 ) {
		alphType = AT_Short;
		valid = true;
	}
	else if ( strcmp( s1, "int" ) == 0 ) {
		alphType = AT_Int;
		valid = true;
	}
	return valid;
}

void ParseData::setLowerUpperRange( )
{
	if ( lowerNum.length() != 0 ) {
		/* If ranges are given then interpret the alphabet type. */
		lowerKey = makeFsmKeyNum( lowerNum, rangeLowLoc, this );
		upperKey = makeFsmKeyNum( upperNum, rangeHighLoc, this );
	}
	else {
		/* Use default ranges for alphabet type. */
		switch ( alphType ) {
		case AT_Char:
			lowerKey = RL_MIN_CHAR;
			upperKey = RL_MAX_CHAR;
			break;
		case AT_UnsignedChar:
			lowerKey = RL_MIN_UCHAR;
			upperKey = RL_MAX_UCHAR;
			break;
		case AT_Short:
			lowerKey = RL_MIN_SHORT;
			upperKey = RL_MAX_SHORT;
			break;
		case AT_UnsignedShort:
			lowerKey = RL_MIN_USHORT;
			upperKey = RL_MAX_USHORT;
			break;
		case AT_Int:
			lowerKey = RL_MIN_INT;
			upperKey = RL_MAX_INT;
			break;
		case AT_UnsignedInt:
			lowerKey = RL_MIN_UINT;
			upperKey = RL_MAX_UINT;
			break;
		}
	}
}

/* Fill the action index for easy access to the actions. */
void ParseData::fillActionIndex()
{
	/* Make the array of pointers to action list elements. */
	actionIndex = new Action*[actionList.size()];
	numActionIndex = actionList.size();

	int actionId = 0;
	for ( ActionList::Iter flel = actionList; flel.lte(); flel++ )
		actionIndex[actionId++] = flel.ptr;
}

/* Set where actions are used: regular or out transitions. */
void ParseData::setActionsWhereUsed( FsmAp *graph )
{
	/* Loop all states. */
	FsmAp::StateList::Iter state = graph->stateList;
	for ( ; state.lte(); state++ ) {
		/* Loop each transition. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; outIt.lte(); outIt++ ) {
			/* The blocks of code that get executed as regular actions. */
			ActionTable::Iter act = outIt.trans->actionTable;
			for ( ; act.lte(); act++ )
				actionIndex[act->value]->isRegAction = true;
		}

		/* The blocks of code that get executed as out actions. */
		ActionTable::Iter act = state->outActionTable;
		for ( ; act.lte(); act++ )
			actionIndex[act->value]->isOutAction = true;
	}
}

/* Make actions indicies for regular and out actions. */
void ParseData::fillSpecificActionIndicies( )
{
	/* Count the number in each. */
	numRegActionIndex = 0;
	numOutActionIndex = 0;
	for ( ActionList::Iter flel = actionList; flel.lte(); flel++ ) {
		if ( flel->isRegAction )
			numRegActionIndex += 1;
		if ( flel->isOutAction )
			numOutActionIndex += 1;
	}

	/* Make arrays. */
	regActionIndex = new Action*[numRegActionIndex];
	outActionIndex = new Action*[numOutActionIndex];

	/* Fill in the arrays. */
	int curReg = 0, curOut = 0;
	for ( ActionList::Iter flel = actionList; flel.lte(); flel++ ) {
		if ( flel->isRegAction ) {
			regActionIndex[curReg] = flel.ptr;
			flel->regActionId = curReg;
			curReg += 1;
		}
		if ( flel->isOutAction ) {
			outActionIndex[curOut] = flel.ptr;
			flel->outActionId = curOut;
			curOut += 1;
		}
	}
}

/* Rewrite all transitions to the specific action indicies. NOT USED. */
void ParseData::rewriteActionIndicies( FsmAp *graph )
{
	/* Loop all states. */
	FsmAp::StateList::Iter state = graph->stateList;
	for ( ; state.lte(); state++ ) {
		/* Loop each transition. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; outIt.lte(); outIt++ ) {
			/* The blocks of code that get executed as regular actions. */
			ActionTable::Iter act = outIt.trans->actionTable;
			for ( ; act.lte(); act++ )
				act->value = actionIndex[act->value]->regActionId;
		}

		/* The blocks of code that get executed as out actions. */
		ActionTable::Iter act = state->outActionTable;
		for ( ; act.lte(); act++ )
			act->value = actionIndex[act->value]->outActionId;
	}
}

void ParseData::printNameInst( NameInst *nameInst, int level )
{
	for ( int i = 0; i < level; i++ )
		cerr << "  ";
	cerr << (nameInst->name != 0 ? nameInst->name : "<ANON>") << 
			"  id: " << nameInst->id << 
			"  refs: " << nameInst->numRefs << endl;
	for ( NameMap::Iter name = nameInst->children; name.lte(); name++ )
		printNameInst( name->value, level+1 );
	for ( NameVect::Iter anon = nameInst->anonChildren; anon.lte(); anon++ )
		printNameInst( *anon, level+1 );
}


/* Make the graph from a graph dict node. Does minimization and state sorting. */
FsmAp *ParseData::makeInstance( GraphDictEl *gdNode )
{
	/* Build the graph from a walk of the parse tree. */
	FsmAp *graph = gdNode->value->walk( this );

	/* Remove unreachable states. There should be no dead end states however.
	 * The subtract and intersection operators are the only places where they
	 * may be created and those operators clean them up. */
	graph->removeUnreachableStates();

	/* If minimizing we can optimize the graph somewhat. */
	if ( minimizeLevel != MinimizeNone ) {
		/* No more fsm operations are to be done. Action ordering numbers are
		 * no longer of use and will just hinder minimization. Clear them. */
		graph->nullActionKeys();

		/* Transition priorities are no longer of use. We can clear them
		 * because they will just hinder minimization as well. Clear them. */
		graph->clearAllPriorities();
	}

	/* Minimize here even if we minimized at every op. Now that function
	 * keys have been cleared we may get a more minimal fsm. */
	switch ( minimizeLevel ) {
		case MinimizeNone:
			break;
		case MinimizeApprox:
			graph->minimizeApproximate();
			break;
		case MinimizeStable:
			graph->minimizeStable();
			break;
		case MinimizePartition1:
			graph->minimizePartition1();
			break;
		case MinimizePartition2:
			graph->minimizePartition2();
			break;
	}

	return graph;
}

void ParseData::printNameTree()
{
	/* Print the name instance map. */
	for ( NameMap::Iter ch = rootName->children; ch.lte(); ch++ )
		printNameInst( ch->value, 0 );
	
	cerr << "name index:" << endl;
	/* Show that the name index is correct. */
	for ( int ni = 0; ni < nextNameId; ni++ ) {
		cerr << ni << ": ";
		char *name = nameIndex[ni]->name;
		cerr << ( name != 0 ? name : "<ANON>" ) << endl;
	}
}

FsmAp *ParseData::makeGraph( GraphDictEl *dictEl )
{
	/* Build the name tree and supporting data structures. */
	makeNameTree();

	/* Resove action code name references. */
	resolveActionNameRefs();

	/* Resove name references in the tree. */
	for ( GraphList::Iter glel = instanceList; glel.lte(); glel++ )
		glel->value->resolveNameRefs( this );

	FsmAp *mainGraph = 0;
	if ( dictEl != 0 ) {
		/* Just building the specified graph. */
		mainGraph = makeInstance( dictEl );
	}
	else {
		/* Make all the instantiations, we know that main exists in this list. */
		int numOthers = 0;
		FsmAp **graphs = new FsmAp*[instanceList.length()];
		for ( GraphList::Iter glel = instanceList; glel.lte();  glel++ ) {
			if ( strcmp( glel->key, machineMain ) == 0 ) {
				/* Main graph is always instantiated. */
				mainGraph = makeInstance( glel );
			}
			else {
				/* Check to see if the instance is ever referenced. */
				if ( glel->value->nameScope->numRefs > 0 )
					graphs[numOthers++] = makeInstance( glel );
			}
		}

		if ( numOthers > 0 ) {
			/* Add all the other graphs into main. */
			mainGraph->globOp( graphs, numOthers );
		}

		delete[] graphs;
	}

	/* Now sort the states into non-final and final. */
	mainGraph->sortStatesByFinal();

	return mainGraph;
}

/* Dump either a specific machine or main machine and all instantiations (in
 * the case dictEl == 0). */
void ParseData::dumpFsm( GraphDictEl *dictEl )
{
	/* Make the graph, do minimization. */
	FsmAp *graph = makeGraph( dictEl );

	/* If any errors have occured in the input file then don't write anything. */
	if ( gblErrorCount > 0 )
		return;

	/* Create a dump object. */
	FsmDump dump( fsmName, this, graph, *outStream );

	/* Dump the fsm. */
	dump.dumpGraph( );
}

/* Four different things can happen here, there can be an error, the machine
 * can be ignore, the main machine can be output by default and a specific
 * machine can be output. */
void ParseData::dumpFsm()
{
	/* Bail if there was no machine given. Nothing to output. */
	if ( ! machineGiven )
		return;

	/* A machine was given, proceed. */
	if ( machinePath != 0 ) {
		/* There is a path specified, is this the right machine spec?
		 * Otherwise the spec will get skipped. */
		if ( strcmp(machinePathSpec, fsmName) == 0 ) {
			/* Remember that we found the path specified. */
			machinePathFound = true;

			/* If no name, use main. */
			char *name = machinePathName;
			if ( name == 0 )
				name = machineMain;

			/* Look for the machine. */
			GraphDictEl *dictEl = graphDict.find(name);
			if ( dictEl != 0 ) {
				/* Good, found the specified machine dump it. */
				dumpFsm( dictEl );
			}
			else {
				/* No recovery action. fsm is skipped. */
				error(fsmStartSecLoc) << "machine " << name << 
						" not found in " << machinePathSpec << endl;
			}
		}
	}
	else {
		/* No machine path. Looking for main. Make sure it was given. */
		GraphDictEl *mainEl = graphDict.find( machineMain );
		if ( mainEl == 0 ) {
			/* No recovery action, fsm is skipped. */
			error(fsmStartSecLoc) << "main graph not defined in \"" 
					<< fsmName << "\"" << endl;
		}

		/* Dump the main machine. */
		dumpFsm( 0 );
	}
}

void ParseData::printFsm()
{
	/* FIXME: Not yet implemented. */
	assert( false );
}

void ParseData::generateGraphviz( GraphDictEl *dictEl )
{
	/* Fill the action index for easy access to the action. */
	fillActionIndex();

	/* Make the graph, do minimization. */
	FsmAp *graph = makeGraph( dictEl );

	/* If any errors have occured in the input file then don't write anything. */
	if ( gblErrorCount > 0 )
		return;

	/* If a graphviz output has already been generated, emit a warning to say
	 * that no more can be done because graphviz will barf. */
	if ( graphvizDone ) {
		warning(fsmStartSecLoc) << "graphviz accepts only a "
				"single graph, try ragel with -M" << endl;
		return;
	}

	/* Make the generator. */
	GraphvizDotGen dotGen( fsmName, this, graph, *outStream );

	/* Write out with it. */
	dotGen.writeDotFile();

	/* Remember that we wrote out a dot file. */
	graphvizDone = true;
}

void ParseData::generateGraphviz( )
{
	/* If there was no machine given, we cannot generate graphviz output. */
	if ( ! machineGiven )
		return;

	/* A machine was given, proceed. */
	if ( machinePath != 0 ) {
		/* There is a path specified, is this the right machine spec?
		 * Otherwise the spec will get skipped. */
		if ( strcmp(machinePathSpec, fsmName) == 0 ) {
			/* Remember that we found the path specified. */
			machinePathFound = true;

			/* If no name, use main. */
			char *name = machinePathName;
			if ( name == 0 )
				name = machineMain;

			/* Look for the machine. */
			GraphDictEl *dictEl = graphDict.find(name);
			if ( dictEl != 0 ) {
				/* Good, found the specified machine dump it. */
				generateGraphviz( dictEl );
			}
			else {
				/* No recovery action. fsm is skipped. */
				error(fsmStartSecLoc) << "machine " << name << 
						" not found in " << machinePathSpec << endl;
			}
		}
	}
	else {
		/* No machine path. Looking for main. Make sure it was given. */
		GraphDictEl *mainEl = graphDict.find( machineMain );
		if ( mainEl == 0 ) {
			/* No recovery action, fsm is skipped. */
			error(fsmStartSecLoc) << "main graph not defined in \"" 
					<< fsmName << "\"" << endl;
		}

		/* Generate graphviz for the main machine. */
		generateGraphviz( 0 );
	}
}


/* Generate the codegen depending on the command line options given. */
FsmCodeGen *ParseData::makeCodeGen( FsmMachine *machine )
{
	FsmCodeGen *codeGen = 0;
	switch ( outputFormat ) {
	case OutCCode:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFTables:
			codeGen = new CFTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenGoto:
			codeGen = new CGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFGoto:
			codeGen = new CFGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenIpGoto:
			codeGen = new CIpGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		}
		break;
	case OutCppCode:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CCTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFTables:
			codeGen = new CCFTabCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenGoto:
			codeGen = new CCGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenFGoto:
			codeGen = new CCFGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		case GenIpGoto:
			codeGen = new CCIpGotoCodeGen( fsmName, this, machine, *outStream );
			break;
		}
		break;

	/* Called codegen when generating something else. */
	default:
		assert( false );
	}
	return codeGen;
}

/* Generate the code for an fsm. Assumes parseData is set up properly. Called
 * by parser code. */
void ParseData::generateCode( )
{
	/* The machine that will take the compressed fsm and the code generator. */
	FsmMachine *machine = 0;
	FsmCodeGen *codeGen = 0;

	/* Nothing to do if there is no datalist or machine given. */
	if ( dataList.length() == 0 && ! machineGiven )
		return;
	
	/* If the graph dict is given, find the main machine. */
	if ( machineGiven ) {
		/* Look for the main instance. The parser prevents main from going
		 * into the graph dictionary as a variable def and not an instance. */
		GraphDictEl *mainEl = graphDict.find( machineMain );
		if ( mainEl == 0 ) {
			/* No recovery action, fsm is skipped. */
			error(fsmStartSecLoc) << "main graph not defined in \"" 
					<< fsmName << "\"" << endl;
			return;
		}

		/* Interpret the alphabet type. */
		setLowerUpperRange( );

		/* Fill the action index for easy access to the actions. */
		fillActionIndex();

		/* Make the main graph. */
		FsmAp *mainGraph = makeGraph( 0 );

		/* Create a new machine and build it from the graph. */
		machine = new FsmMachine;
		buildMachine( machine, mainGraph );
	}

	/* If any errors have occured in the input file then don't write anything. */
	if ( gblErrorCount > 0 )
		return;

	/* Make a code generator that will output the header/code. */
	codeGen = makeCodeGen( machine );

	/* Write line directive. */
	codeGen->startCodeGen();

	/* If the struct element was used then output the header portion. */
	if ( dataList.length() > 0 )
		codeGen->writeOutHeader( );
	
	/* If there was a machine given, gather info on it and write it out. */
	if ( machineGiven ) {
		codeGen->analyzeMachine();
		codeGen->writeOutCode( );
	}

	/* Write line directive. */
	codeGen->endCodeGen();

	/* Done with the code generator. */
	delete codeGen;
	delete machine;
}


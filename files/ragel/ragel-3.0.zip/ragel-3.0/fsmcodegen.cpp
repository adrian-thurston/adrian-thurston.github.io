/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "fsmcodegen.h"
#include "parsetree.h"
#include "fsmmachine.h"

/* Determine if a string is only whitespace. Code blocks that are only
 * whitespace need not be output. */
bool onlyWhitespace( char *str )
{
	while ( *str != 0 ) {
		if ( *str != ' ' && *str != '\t' && *str != '\n' &&
				*str != '\v' && *str != '\f' && *str != '\r' )
			return false;
		str += 1;
	}
	return true;
}

using std::ostream;

/* Init code gen with in parameters. */
FsmCodeGen::FsmCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, ostream &out )
:
	fsmName(fsmName), 
	parseData(parseData), 
	machine(machine),
	out(out),
	bAnyReg(false),
	bAnyOut(false),
	bAnyFinWithNoOut(false),
	bAnyActionCalls(false),
	bAnyActionRets(false)
{
}

void FsmCodeGen::startCodeGen()
{
	/* Write the preprocessor line info for going to the output file. */
	out << "# " << outFilter->line + 1 << " \""; LDIR_PATH(outputFile) << "\"\n";
}

void FsmCodeGen::endCodeGen()
{
	/* Write the preprocessor line info for to the input file. */
	out << "# " << parseData->fsmEndSecLoc.line  << " \""; LDIR_PATH(inputFile) << "\"\n";
}

/* Are there any indicies in use? If a machine has no indicies then it has no
 * transitions and isn't really of much use. This should return true most of
 * the time. */
bool FsmCodeGen::anyIndicies()
{
	bool indiciesFound = false;
	FsmMachState *pSt = machine->allStates;
	for ( int st = 0; st < machine->numStates; st++, pSt++ ) {
		if ( pSt->numIndex > 0 ) {
			indiciesFound = true;
			break;
		}
	}
	return indiciesFound;
}

/* Does the machine have any functions. */
bool FsmCodeGen::anyTransFuncs()
{
	return machine->numTransFuncs > 0;
}

/* Gather various info on the machine. */
void FsmCodeGen::analyzeMachine()
{
	/* Set up the label needed flag for each state. */
	setLabelsNeeded();

	/* Find if there are any regular functions and out functions. */
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Check for funcs on transitions. */
		FsmMachState *state = &machine->allStates[st];
		for ( int tr = 0; tr < state->numIndex; tr++ ) {
			FsmMachTrans *trans = &machine->allTrans[state->transIndPtr[tr]];
			if ( trans->funcs != FUNC_NO_FUNC )
				bAnyReg = true;
		}

		/* Check for out funcs. */
		if ( state->isFinState ) {
			if ( state->outFuncs == FUNC_NO_FUNC )
				bAnyFinWithNoOut = true;
			else
				bAnyOut = true;
		}
	}

	/* Check if there are any calls inaction code. */
	for ( ActionList::Iter act = parseData->actionList; act.lte(); act++ ) {
		/* Only consider actions that are referenced. */
		if ( act->actionRefs.length() > 0 ) {
			for ( BlockIter item = act->data; item.lte(); item++ ) {
				if ( item.type == CB_CALL )
					bAnyActionCalls = true;
				else if ( item.type == CB_RET )
					bAnyActionRets = true;
			}
		}
	}
}


/* Write out the fsm name. */
std::ostream &FsmCodeGen::FSM_NAME()
{
	out << fsmName;
	return out;
}

std::ostream &FsmCodeGen::USER_STRUCT( char *data )
{
	for ( BlockIter item = data; item.lte(); item++ ) {
		switch ( item.type ) {
		case CB_STACK:
			STACK(atoi(item.data));
			break;
		case CB_TEXT:
			out << item.data;
			break;
		}
	}
	/* There may not be a trailing newline. Add one. */
	out << "\n";
	return out;
}

std::ostream &FsmCodeGen::STRUCT_DATA()
{
	bool anyBlocksWritten = false;

	/* Walk the list of data, printing the cases. */
	StringListEl *del = parseData->dataList.head;
	while ( del != NULL ) {
		/* Don't bother with blocks that are only whitespace. */
		if ( ! onlyWhitespace( del->data ) ) {
			/* Remember that we wrote a blcok so that we know to write a line
			 * directive back to the output file. */
			anyBlocksWritten = true;

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "# " << del->loc.line << " \"";
			LDIR_PATH(inputFile) << "\"\n";

			/* Write the block. */
			USER_STRUCT( del->data );
		}
		del = del->next;
	}

	/* If any blocks were written, then write the directive for going back
	 * into the output file. The line number is for the next line, so add one. */
	if ( anyBlocksWritten ) {
		out << "# " << outFilter->line + 1 << " \"";
		LDIR_PATH(outputFile) << "\"\n";
	}

	return out;
}

std::ostream &FsmCodeGen::INIT_CODE()
{
	bool anyBlocksWritten = false;

	/* Walk the list of pre funcs, printing the sections. */
	StringListEl *del = parseData->initCodeList.head;
	while ( del != NULL ) {
		/* Don't bother with blocks that are only whitespace. */
		if ( ! onlyWhitespace( del->data ) ) {
			/* Remember that we wrote a blcok so that we know to write a line
			 * directive back to the output file. */
			anyBlocksWritten = true;

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "# " << del->loc.line << " \"";
			LDIR_PATH(inputFile) << "\"\n";

			/* Write the block. */
			out << "{" << del->data << "}\n";
		}
		del = del->next;
	}

	/* If any blocks were written, then write the directive for going back
	 * into the output file. The line number is for the next line, so add one. */
	if ( anyBlocksWritten ) {
		out << "# " << outFilter->line + 1 << " \"";
		LDIR_PATH(outputFile) << "\"\n";
	}

	return out;
}

/* Emit the offset of the start state as a decimal integer. */
std::ostream &FsmCodeGen::START_STATE_OFFSET()
{
	out << machine->startState;
	return out;
};

/* Write out the array of regular and out functions. Includes the lengths of
 * each function vector as the first element. */
std::ostream &FsmCodeGen::FUNCTIONS()
{
	out << '\t';
	int totalFuncs = 0;

	/* Do out functions. */
	int *array = machine->allTransFuncs;
	int len = machine->numTransFuncs;
	for ( int fnum = 0; fnum < len; fnum++ ) {
		int func = array[fnum];
		out << func;

		/* If we are not in the last func, then write out a comma 
		 * and possibly a line break. */
		if ( fnum < len-1 ) {
			out << ", ";

			/* Put in a line break every 8 */
			if ( totalFuncs % 8 == 7 )
				out << "\n\t";
		} 
		totalFuncs += 1;
	}
	return out;
}


/* Emit the alphabet data type. */
std::ostream &FsmCodeGen::ALPH_TYPE()
{
	switch ( parseData->alphType ) {
	case AT_Char:
		out << "char";
		break;
	case AT_UnsignedChar:
		out << "unsigned char";
		break;
	case AT_Short:
		out << "short";
		break;
	case AT_UnsignedShort:
		out << "unsigned short";
		break;
	case AT_Int:
		out << "int";
		break;
	case AT_UnsignedInt:
		out << "unsigned int";
		break;
	}

	return out;
}

/* Write out level number of tabs. Makes the nested binary search nice
 * looking. */
std::ostream &FsmCodeGen::TABS( int level )
{
	while ( level-- > 0 )
		out << "\t";
	return out;
}

/* Write out a key from the fsm code gen. Depends on wether or not the key is
 * signed. */
std::ostream &FsmCodeGen::KEY( int fsmKey )
{
	if ( parseData->isAlphSigned() )
		out << fsmKey;
	else
		out << (unsigned int) fsmKey << 'u';
	return out;
}

/* Write out action code which is segmented into statements interpreted by
 * ragel for rewriting and text that is passed through as is. */
std::ostream &FsmCodeGen::ACTION( Action *action, int targState )
{
	for ( BlockIter item = action->data; item.lte(); item++ ) {
		switch ( item.type ) {
		case CB_HOLD:
			out << "_p--, _len++;";
			break;
		case CB_CHAR:
			out << "(*_p)";
			break;
		case CB_TEXT:
			out << item.data;
			break;
		case CB_JUMP:
			GOTO( action->nameTargs[item.i] );
			break;
		case CB_CALL:
			CALL( action->nameTargs[item.i], targState );
			break;
		case CB_RET:
			RET();
			break;
		}
	}
	return out;
}

/* Write out paths in line directives. Escapes any special characters. */
std::ostream &FsmCodeGen::LDIR_PATH( char *path )
{
	for ( char *pc = path; *pc != 0; pc++ ) {
		if ( *pc == '\\' )
			out << "\\\\";
		else
			out << *pc;
	}
	return out;
}

/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMGRAPH_H
#define _RLFSM_FSMGRAPH_H

#include <assert.h>
#include "vector.h"
#include "bstset.h"
#include "compare.h"
#include "avltree.h"
#include "dlist.h"
#include "bstmap.h"

using namespace Aapl;

/* Flags that control merging. */
#define SB_KILLOTHERS 0x01
#define SB_WANTOTHER1 0x02
#define SB_WANTOTHER2 0x04
#define SB_WANTOTHER  0x06

struct FsmMachState;

/* Differnt types of keys that transitions can be attached on. */
enum FsmKeyType {
	KeyTypeSingle,
	KeyTypeRange,
	KeyTypeDefault
};

/***
 * This is the marked index for a state pair. Used in minimization. It keeps
 * track of whether or not the state pair is marked.
 */
template <class State> struct MarkIndex
{
	MarkIndex(int states);
	~MarkIndex();

	void markPair(int state1, int state2);
	bool isPairMarked(int state1, int state2);

private:
	int numStates;
	bool *array;
};

/***
 * Compare of a whole Func table element (key & value).
 */
template <class TransFunc, class TransFuncCmp> struct TransFuncElCmp
{
	static int Compare( const BstMapEl<int, TransFunc> &func1, 
			const BstMapEl<int, TransFunc> &func2 )
	{
		int res = CmpOrd<int>::Compare( func1.key, func2.key );
		if ( res != 0 )
			return res;
		else
			return TransFuncCmp::Compare( func1.value, func2.value );
	}
};

/**
 * A single transition for an fsm.
 */
template < class State, class Transition, class TransFunc,
		class TransFuncCmp > struct FsmTrans
{
	FsmTrans( ) : fromState(0), toState(0), priority(0) {}

	Transition *next, *prev;
	State *fromState;
	State *toState;

	/* Transistion Func Element and the table. */
	typedef BstMapEl< int, TransFunc > TransFuncEl;
	typedef BstMap< int, TransFunc, CmpOrd<int> > TransFuncTable;

	/* Compare of a TransFuncTable. */
	typedef CmpTable< TransFuncEl, TransFuncElCmp<TransFunc, TransFuncCmp> > 
			TransFuncTableCompare;

	/* Plain Func list that imposes no ordering. */
	typedef Vector<TransFunc> TransFuncList;

	/* Comparison for TransFuncList. */
	typedef CmpTable<TransFunc, TransFuncCmp> TransFuncListCompare;

	/* The function table and priority for the transition. */
	TransFuncTable transFuncTable;
	int priority;

	/* Compare function tables. */
	static inline int CompareFuncs( const TransFuncTable &funcs1,
			const TransFuncTable &funcs2 );

	/* Compare priority and function table of transitions. */
	static inline int CompareTransDataOBS( FsmTrans *trans1, FsmTrans *trans2 );

	/* Compare priority and function table of transitions. Either of the
	 * pointers may be null. */
	static inline int CompareDataPtr( FsmTrans *trans1, FsmTrans *trans2 );

	/* Compare target, priority and function table of transitions. Either
	 * pointer may be null. */
	static inline int CompareFullPtr( FsmTrans *trans1, FsmTrans *trans2 );

	/* Compare target partitions. Either pointer may be null. */
	static inline int ComparePartPtr( FsmTrans *trans1, FsmTrans *trans2 );

	/* Check marked status of target states. Either pointer may be null. */
	static inline bool ShouldMarkPtr( MarkIndex<State> &markIndex, 
			FsmTrans *trans1, FsmTrans *trans2 );

	/* Set functions on the transition. */
	void SetFunction( TransFunc func, int transOrder );
	void SetFunctions( TransFuncTable &funcTable );

	/* For the user. */
	void MergeTransition( FsmTrans *otherTrans ) { }
};

/***
 * FsmSDNode
 */
template<class State> struct FsmSDNode :
		public AvlNode< FsmSDNode<State> >,
		public CmpTable< State*, CmpOrd<State*> >
{
	typedef BstSet< State*, CmpOrd<State*> > StateSet;

	FsmSDNode(const StateSet &stateSet) : stateSet(stateSet) { }

	const StateSet &getKey() { return stateSet; }
	StateSet stateSet;
	State *targState;
};

/***
 * Data needed for a merge operation.
 */
template < class State > struct FsmMergeData
{
	typedef BstSet< State*, CmpOrd<State*> > StateSet;
	typedef AvlTree<FsmSDNode<State>, StateSet> StateDict;
	typedef DList< State > StateList;

	StateDict stateDict;
	StateList stfil;
};

/* Extend binary search map with functions useful for ranges. */
template < class Transition > struct FsmTransList :
		BstMap< int, Transition*, CmpOrd<int> >
{
	typedef BstMapEl< int, Transition* > TransEl;

	/* Given a transition key, find the range the key is in. */
	TransEl *findRange( int onChar ) const;
	TransEl *findLower( int onChar ) const;
};

template < class State > struct MinPartition 
		: public DListEl< MinPartition<State> >
{
	MinPartition() : active(false) { }

	DList<State> list;
	bool active;
};

/**
 * A single state for an fsm.
 */
template < class State, class TransFunc, class Transition > 
		struct FsmState : public DListEl<State>
{
	FsmState();
	FsmState(const FsmState &other);
	~FsmState();

	/* Transition lists element and the table. */
	typedef FsmTransList<Transition> TransListType;
	typedef BstMapEl< int, Transition* > TransEl;

	/* Transistion func element and the table. */
	typedef BstMapEl< int, TransFunc > TransFuncEl;
	typedef BstMap< int, TransFunc, CmpOrd<int> > TransFuncTable;

	TransListType outList;
	TransListType inList;

	TransListType outRange;
	TransListType inRange;

	Transition *defOutTrans;
	Transition *defInTrans;

	int num;

	union {
		/* When duplicating the fsm we need to map each 
		 * state to the new state representing it. */
		State *stateMap;

		/* When building the runnable machine, this maps graph states to
		 * machine states representing it. */
		FsmMachState *machState;

		/* When minimizing machines, this maps the group the state is in. */
		MinPartition<State> *partition;
	} alg;

	/* Is the state a final state. */
	bool isFinState;

	/* Is the state Marked during the MarkReachableFromHere process. */
	bool isMarked;

	/* Bits controlling the behaviour of the state during collapsing to dfa. */
	int stateBits;

	/* Transition data to add to any transition leaving a fsm via this state. */
	int outPriority;
	bool isOutPriorSet;
	TransFuncTable outTransFuncTable;

	/* StateSet, FsmSDNode */
	typedef BstSet< State*, CmpOrd<State*> > StateSet;
	typedef AvlTree<FsmSDNode<State>, StateSet> StateDict;

	/* A pointer to a dict node that contains the set of states
	 * this state represents. */
	FsmSDNode<State> *stateDictNode;

	/* User routines. */
	void FuseState( State *otherState ) { }
	void MergeState( State *otherState ) { }

	static int CompareOutTrans( const FsmState &state1, 
			const FsmState &state2 );
	void SetOutFunctions( TransFuncTable &funcTable );
};

/**
 * Iterator for a state's out transitions. This iterator does not adhere to
 * Aapl's standard iterator interface due to the exceptional requirements.
 * Objects being iterated over come from 3 sources: out transitions, out
 * ranges and the default transitions. Pointers in those segments may be null.
 */
template < class State, class Transition > struct FsmOutIterator
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IteratorState {
		Begin,
		Trans,
		Range,
		Default,
		End
	};

	FsmOutIterator( State *state );

	/* Query iterator. */
	bool atEnd();
	Transition *operator++(int);
	Transition *operator++();

	/* Transistion list element. */
	typedef BstMapEl< int, Transition* > TransEl;

	/* The trans pointer available outside this class. */
	Transition *trans;

	/* Loop variables. */
	TransEl *transEl;
	int nTransEl, i;

	/* Iterator state. */
	State *state;
	IteratorState itState;

private:
	void findNext();
};

/**
 * Iterator for a state's in transitions. This iterator does not adhere to
 * Aapl's standard iterator interface due to the exceptional requirements.
 * Objects being iterated over come from 3 sources: in transitions, in
 * ranges and the default transitions. These points are lists of transitions.
 */
template < class State, class Transition > struct FsmInIterator
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IteratorState {
		Begin,
		Trans,
		Range,
		Default,
		End
	};

	FsmInIterator( State *state );

	/* Query iterator. */
	bool atEnd();
	Transition *operator++(int);
	Transition *operator++();

	/* Transistion list element. */
	typedef BstMapEl< int, Transition* > TransEl;

	/* The trans pointer available outside this class. */
	Transition *trans;

	/* Loop variables. */
	TransEl *transEl;
	int nTransEl, i;

	/* Iterator state. */
	State *state;
	IteratorState itState;

private:
	void findNext();
};

template < class State, class Transition > struct FsmPairIterator
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IteratorState {
		Begin,
		ConsumeS1Trans, ConsumeS2Trans,
		OnlyInS1Trans,  OnlyInS2Trans,
		InBothTrans,
		ConsumeS1Range, ConsumeS2Range,
		OnlyInS1Range,  OnlyInS2Range,
		S1SticksOut,    S1SticksOutBreak,
		S2SticksOut,    S2SticksOutBreak,
		S1DragsBehind,  S1DragsBehindBreak,
		S2DragsBehind,  S2DragsBehindBreak,
		ExactOverlap,   End
	};

	/** Encodes the different states that are meaningful to the user. */
	enum UserState {
		TransInS1,  TransInS2,
		TransOverlap,
		RangeInS1,  RangeInS2,
		RangeOverlap,
		BreakS1,    BreakS2
	};

	FsmPairIterator( const State *state1, const State *state2, bool wantBreaks );

	/* Query iterator. */
	bool atEnd();
	void operator++(int) { findNext(); }
	void operator++()    { findNext(); }

	typedef BstMapEl< int, Transition* > TransEl;

	/* Iterator state. */
	const State *state1;
	const State *state2;
	IteratorState itState;
	UserState userState;


	TransEl *s1Tel, *s1EndTel;
	TransEl *s2Tel, *s2EndTel;
	TransEl *s1Range, *s2Range;
	int savedKey;
	Transition *savedTrans;
	TransEl s1HeadTel[2], s2HeadTel[2];
	TransEl s1NextTel[2], s2NextTel[2];
	Transition *defTrans;

	bool wantBreaks;

private:
	void findNext();
};

template < class State, class Transition > class ApproxCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;

public:
	static int Compare( const State *pState1, const State *pState2 );
};

template < class State, class Transition > class InitPartitionCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;
public:
	static int Compare( const State *pState1, const State *pState2 );
};

template < class State, class Transition > class PartitionCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;
public:
	static int Compare( const State *pState1, const State *pState2 );
};

template < class State, class Transition > class MarkCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;
public:
	static bool ShouldMark( MarkIndex<State> &markIndex, const State *pState1, 
			const State *pState2 );
};


/**
 * Contains all the fsm operators, nfa to dfa conversion and minimization
 * algorithms.
 */
template < class State, class TransFunc, class Transition > struct FsmGraph
{
public:
	/* Constructor/Destructor. */
	FsmGraph() {}
	FsmGraph(const FsmGraph &graph);
	~FsmGraph();

	/* Transistion Func Element and the table. */
	typedef BstMapEl< int, TransFunc > TransFuncEl;
	typedef BstMap< int, TransFunc, CmpOrd<int> > TransFuncTable;
	
	/**
	 * StateSet, StateDict
	 */
	typedef BstSet< State*, CmpOrd<State*> > StateSet;
	typedef AvlTree< FsmSDNode<State>, StateSet > StateDict;

	/* The list of states. */
	typedef DListEl< State > ListEl;
	typedef DList< State > StateList;

	/* List of transtions out of a state. */
	typedef FsmTransList<Transition> TransListType;
	typedef BstMapEl<int, Transition*> TransEl;
	typedef Vector< BstMapEl<int, Transition*> > TransListVect;

	/* Data required on a merge. */
	typedef FsmMergeData<State> MergeData;

	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;

	/* The list of states. */
	DList<State> stateList;

	/* Start state and final state list. */
	State *startState;
	StateSet finStateSet;

	/* Set and Unset a state as final. */
	void SetFinState(State *state);
	void UnsetFinState(State *state);

	/* Make a new start state that has no entry points. Will not change the
	 * identity of the fsm. */
	void IsolateStartState( );

	/*
	 * Transition functions and priorities.
	 */

	/* Set priorities on transtions. */
	void StartFsmPrior( int prior );
	void AllTransPrior( int prior );
	void FinFsmPrior( int prior );
	void LeaveFsmPrior( int prior );

	/* Set functions to execute. */
	void StartFsmFunc( TransFunc func, int transOrder );
	void AllTransFunc( TransFunc func, int transOrder );
	void FinFsmFunc( TransFunc func, int transOrder );
	void LeaveFsmFunc( TransFunc func, int transOrder );

	/* Shift the function ordering of the start transitions to start
	 * at fromOrder and increase in units of 1. Useful before staring. */
	int ShiftStartFuncOrder( int fromOrder );

	/* Clear functions from transitions. */
	void ClearStartFsmFunc();
	void ClearAllTransFunc();
	void ClearFinFsmFunc();
	void ClearLeaveFsmFunc();

	/* Clear the leave fsm priority settings from the fsm. */
	void ClearLeaveFsmPrior();

	/* Remove all transition data. Remove funcs and outfuncs, zero priorities
	 * and remove out priorities. */
	void ClearAllTransData();

	/* Zero out all the function keys. */
	void NullFunctionKeys();

	/* Remove all out funcs and out priorites on non final states. */
	void StripNonFinalStates();

	/*
	 * Basic attaching and detaching.
	 */

	/* Common to attaching/detaching list and default. */
	void AttachTrans(State *from, State *to, Transition *&head, Transition *trans);
	void DetachTrans(State *from, State *to, Transition *&head, Transition *trans);

	/* Attach/Detach for out/in lists or for default transition. */
	Transition *AttachStates( State *from, State *to, FsmKeyType keyType, 
			int onChar1, int onChar2 );
	void AttachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, int onChar );
	void DetachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, int onChar );

	void ChangeRangeLowerKey( Transition *trans, int oldKey, int newKey );

	/* Detach a state from the graph. */
	State *DetachState( State *state );

	/*
	 * NFA to DFA conversion routines.
	 */

	/* Duplicate a transition that will dropin to a free spot. */
	Transition *DupTrans( State *from, FsmKeyType keyType, int onChar,
			Transition *srcTrans, bool leavingFsm );

	/* In crossing, src trans overwrites the existing one because it has a
	 * higher priority. */
	Transition *OverwriteTrans( MergeData &md, State *from, FsmKeyType keyType, 
			int onChar, Transition *destTrans, Transition *srcTrans,
			int newTransPrior, bool leavingFsm );

	/* In crossing, src trans and dest trans are merged. */
	Transition *FsmAttachStates( MergeData &md, State *from, FsmKeyType keyType,
			int onChar, Transition *destTrans, Transition *srcTrans,
			int newTransPrior, bool leavingFsm );

	/* Cross a src transition with one that is already occupying a spot. */
	Transition *CrossTransitions( MergeData &md, State *from, FsmKeyType keyType, 
			int onChar, Transition *destTrans, Transition *srcTrans,
			bool leavingFsm );

	/* Common to copying transition lists and ranges. */
	Transition *KeyInDestEl( MergeData &md, State *dest, State *src, TransEl *destTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm );
	Transition *KeyInSrcEl( MergeData &md, State *dest, State *src, TransEl *srcTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm );
	Transition *KeyInBothEl( MergeData &md, State *dest, State *src, TransEl *destTel,
			TransEl *srcTel, FsmKeyType keyType, bool leavingFsm );

	/* Copy individual out from outRange. */
	void KeyInDestRangeEl( MergeData &md, State *dest, State *src, 
				TransEl *destTel, bool leavingFsm );
	void KeyInSrcRangeEl( MergeData &md, State *dest, State *src, 
				TransEl *srcTel, bool leavingFsm );
	void KeyRangeExactOverlap( MergeData &md, State *dest, State *src, 
				TransEl *destTel, TransEl *srcTel, bool leavingFsm );
	void KeyRangeOverlap( MergeData &md, State *dest, State *src, 
				TransEl *&destTel, TransEl *&srcTel, bool leavingFsm );

	/* Copy individual out transitions. */
	void KeyInDestTransEl( MergeData &md, State *dest, State *src, 
				TransEl *destTel, bool leavingFsm );
	void KeyInSrcTransEl( MergeData &md, State *dest, State *src, 
				TransEl *srcTel, bool leavingFsm );
	void KeyInBothTransEl( MergeData &md, State *dest, State *src, 
				TransEl *destTel, TransEl *srcTel, bool leavingFsm );
	
	/* Copy the default transition. */
	void CopyDefTrans( MergeData &md, State *dest, State *src, bool leavingFsm );

	/* Copy the out transitions from src to dest. */
	void OutRangeCopy( MergeData &md, State *dest, State *src, bool leavingFsm );

	/* Copy the out transitions from src to dest. */
	void OutTransCopy( MergeData &md, State *dest, State *src, bool leavingFsm );

	/* Copy the out transitions from src to dest. */
	void OutTransCopy2( MergeData &md, State *dest, State *src, bool leavingFsm );
	
	/* Merge a set of states into newState. */
	void MergeStates( MergeData &md, State *newState, StateSet &stateSet, 
			bool leavingFsm );

	/* Make all states that are combinations of other states and that
	 * have not yet had their out transitions filled in. This will 
	 * empty out stateDict and stFil. */
	void FillInStates( MergeData &md );

	/*
	 * Various.
	 */

	/* New up a state and add it to the graph. */
	State *NewState(bool isFinState = false);

	/* Build basic fsms. */
	static FsmGraph *ConcatFsm( char *str, int len );
	static FsmGraph *ConcatFsm( int *str, int len );
	static FsmGraph *ConcatFsm( int chr );
	static FsmGraph *OrFsm( char *set, int len );
	static FsmGraph *OrFsm( int *set, int len );
	static FsmGraph *NullFsm( );
	static FsmGraph *DotFsm();
	static FsmGraph *DotStarFsm();
	static FsmGraph *RangeFsm( int low, int high );

	/* Fsm Operators. */
	void Star( bool leavingFsm );
	void Concat( FsmGraph *other, bool leavingFsm );
	void Or( FsmGraph *other );
	void Intersect( FsmGraph *other );
	void Subtract (FsmGraph *other );

	/* Underlying worker behind Or, Intersect and Subtract. */
	void DoOr(FsmGraph *other);

	/* Set State numbers starting at 0. */
	void SetStateNumbers();

	/* Unset all final states. */
	void UnsetAllFinStates();

	/* Set the bits of final states and clear the bits of non final states. */
	void SetFinBits( int finStateBits );

	/* Assert that there are no out funcs/priorities on non final states. */
	void VerifyOutFuncs();

	/* Run a sanity check on the machine. */
	void VerifyIntegrity();

	/*
	 * Path pruning
	 */

	/* Mark all states reachable from state. */
	void MarkReachableFromHereReverse( State *state );

	/* Mark all states reachable from state. */
	void MarkReachableFromHere( State *state );

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void RemoveDeadEndStates();

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void RemoveUnreachableStates();

	/*
	 * FSM Minimization
	 */

	/* Minimization by partitioning. */
	void MinimizePartition1();
	void MinimizePartition2();

	/* Minimize the final state Machine. The result is the minimal fsm. Slow
	 * but stable, correct minimization. Uses n^2 space (lookout) and average
	 * n^2 time. Worst case n^3 time, but a that is a very rare case. */
	void MinimizeStable();

	/* Minimize the final state machine. Does not find the minimal fsm, but a
	 * pretty good approximation. Does not use any extra space. Average n^2
	 * time. Worst case n^3 time, but a that is a very rare case. */
	void MinimizeApproximate();

	/* This is the worker for the minimize approximate solution. It merges
	 * states that have identical out transitions. */
	bool MinimizeRound( );

	/* Given an intial partioning of states, split partitions that have out trans
	 * to differing partitions. */
	int PartitionRound( State **statePtrs, MinPartition<State> *parts, int numParts );

	/* Split partitions that have a transition to a previously split partition, until
	 * there are no more partitions to split. */
	int SplitCandidates( State **statePtrs, MinPartition<State> *parts, int numParts );

	/* Fuse together states in the same partition. */
	void FusePartitions( MinPartition<State> *parts, int numParts );

	/* Mark pairs where out final stateness differs, out trans data differs,
	 * trans pairs go to a marked pair or trans data differs. Should get 
	 * alot of pairs. */
	void InitialMarkRound( MarkIndex<State> &markIndex );

	/* One marking round on all state pairs. Considers if trans pairs go
	 * to a marked state only. Returns whether or not a pair was marked. */
	bool MarkRound( MarkIndex<State> &markIndex );

	/* Move the in trans into src into dest. */
	void InTransMove(State *dest, State *src);
	
	/* Make state src and dest the same state. */
	void FuseEquivStates(State *dest, State *src);

	/* Find any states that didn't get marked by the marking algorithm and
	 * merge them into the primary states of their equivalence class. */
	void FuseUnmarkedPairs( MarkIndex<State> &markIndex );
};

#endif /* _RLFSM_FSMGRAPH_H */

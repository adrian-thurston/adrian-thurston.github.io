/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMBUILD_H
#define _RLFSM_FSMBUILD_H

#include "fsmgraph.h"
#include "fsmmachine.h"

/**************************************************************
 * Contains the data necessary for making the fsm machine.
 */
template < class State, class TransFunc, class Transition > class FsmBuild
{
	/* Types that the builder operates on. */
	typedef FsmGraph<State, TransFunc, Transition> FsmGraphType;
	typedef FsmMachine<TransFunc> FsmMachType;
	typedef BstMap< int, TransFunc, CmpOrd<int> > TransFuncTable;
	typedef Vector<TransFunc> TransFuncList;

public:
	/* Construct the fsm builder. */
	FsmBuild( FsmGraphType &graph, FsmMachType &machine );	

	/* Build a runnable, compressed machine from this graph. */
	void build( );

private:
	/* Borrowed from FsmGraph. */
	typedef BstMapEl< int, Transition* > TransEl;

	/* A map between function lists and indexes into the unique
	 * location of those indicies. */
	typedef BstMap<TransFuncList, int, 
			typename Transition::TransFuncListCompare> FuncListMap;
	typedef BstMapEl<TransFuncList, int> FuncListMapEl;

	/* The graph is the source, the machine is the destination. */
	FsmGraphType &graph;
	FsmMachType &machine;

	/* A map between transitions and lists of characters that go on those
	 * transitions. Used in minimizing the outlist of a state. */
	typedef BstMap<FsmMachTrans, int, FsmMachTransCompare> TransMap;
	typedef BstMapEl<FsmMachTrans, int> TransMapEl;

	/* Make a func list from a func table. Simly copies the value data over. */
	void funcTableToFuncList( TransFuncList &funcList, TransFuncTable &funcTable);

	FuncListMap funcListMap;
	TransMap transMap;
	int curFuncOffset;
	int curTransOffset;
	int numFuncs;

	/* Make the states for a new machine. */
	void initMachineStates( );

	/* Make a machine transition from a graph transition. */
	int makeMachineTrans( Transition *trans );

	/* Make a machine state from a graph state. */
	void makeMachineState( FsmMachState *machState, State *state );

	/* Expand the ranges into the indicies. */
	void moveRangesIntoIndicies( FsmMachState *machState );

	void makeIndiciesFromRange( FsmMachState *machState );

	/* Add functions from a func table to the func map and return the index
	 * of the functions. If the func table is empty, the index will be -1. */
	int addFuncsToMap( TransFuncTable &funcTable );
};

/**************************************************************************
 * Construct the fsm builder. Inits the pointers to the graph, and machine.
 */
template < class State, class TransFunc, class Transition >
		FsmBuild<State, TransFunc, Transition>::
		FsmBuild( FsmGraphType &graph, FsmMachType &machine ) :
			graph(graph), machine(machine),
			curFuncOffset(0), curTransOffset(0), numFuncs(0)
{
}

/*************************************************************
 * Convert a funcTable (which imposes ordering on funcs) to
 * a func list, which has no sense of the ordering of the funcs.
 */
template < class State, class TransFunc, class Transition >
		void FsmBuild<State, TransFunc, Transition>::
		funcTableToFuncList( TransFuncList &funcList, TransFuncTable &funcTable )
{
	typename Transition::TransFuncEl *tfel = funcTable.table;
	int ntfel = funcTable.tableLength;
	for ( int i = 0; i < ntfel; i++, tfel++ )
		funcList.append( tfel->value );
}

/*************************************************************************
 * Add functions from a func table to the func map and return the index
 * of the functions. If the func table is empty, the index will be -1.
 */
template < class State, class TransFunc, class Transition >
		int FsmBuild<State, TransFunc, Transition>::
		addFuncsToMap( TransFuncTable &funcTable )
{
	int funcIndex = FUNC_NO_FUNC;
	if ( funcTable.tableLength > 0 ) {
		/* Make a new trans func list from the trans func table (we don't
		 * care about the ordering numbers on the transitions so we make 
		 * a list without the ordering). */
		typename Transition::TransFuncList transFuncList;
		funcTableToFuncList( transFuncList, funcTable );

		/* If not in the function list map then insert. */
		FuncListMapEl *lastFound;
		if ( funcListMap.insert( transFuncList, curFuncOffset, &lastFound ) ) {
			numFuncs += funcTable.tableLength + 1;
			curFuncOffset += 1;
		}

		/* Get the offset as what was found/inserted in the map. */
		funcIndex = lastFound->value;
	}
	return funcIndex;
}

/*************************************************************************
 * Construct a compact runnable machine from this graph. Machine is put in
 * the machine object passed in.
 */
template < class State, class TransFunc, class Transition >
		void FsmBuild<State, TransFunc, Transition>::build( )
{
	/* Create the machine states. */
	initMachineStates( );

	/* The data we need around to make machine states from graph states.
	 * Gives us the transition map, the running offset of transition ids,
	 * the function map and the running offset of function ids. */

	/* Make the global error transition. The rest of the fsm building code works on
	 * the assumption that the error trans is index 0. */
	FsmMachTrans errTrans;
	errTrans.toState = STATE_NO_STATE;
	errTrans.funcs = FUNC_NO_FUNC;
	transMap.insert( errTrans, curTransOffset );
	curTransOffset++;

	State *state = graph.stateList.head;
	while ( state != 0 ) {
		/* Get the fsm state. */
		FsmMachState *machState = state->alg.machState;

		/* Use the base class to make the machine state. This call will modify
		 * funcListMap, curFuncOffset, and transMap. */
		makeMachineState( machState, state );

		/* A hack until output supports range transitions, move the ranges into
		 * the the indicies. */
		moveRangesIntoIndicies( machState );

		/* Add the functions in the outFuncs for this state to the funcs map. */
		machState->outFuncs = addFuncsToMap( state->outTransFuncTable );

		/* Next state. */
		state = state->next;
	}

	/* Save the items in the transMap to trans */
	FsmMachTrans *trans = 0;
	if ( transMap.tableLength > 0 ) {
		/* New up the Transition table. */
		trans = new FsmMachTrans[curTransOffset];

		/* Walk the transMap and copy to the transitions. The location of the
		 * transition must be the offsets in the value field because that is
		 * what the index array uses. */
		TransMapEl *tmel = transMap.table;
		int tmlen = transMap.tableLength;
		for ( int i = 0; i < tmlen; i++, tmel++ )
			trans[tmel->value] = tmel->key;
	}

	/* Set the transitions pointer and the number of transitions. */
	machine.allTrans = trans;
	machine.numTrans = curTransOffset;

	/* If there are any function lists in the function map then we need to copy
	 * them to the new machine. */
	TransFunc *transFuncs = 0;
	if ( funcListMap.size() > 0 ) {
		/* There was space used. New up the funclist array and then fill it in. */
		transFuncs = new TransFunc[numFuncs];

		/* The size of funcListMap gives the number of function 
		 * indicies and lengths. */
		machine.transFuncIndex = new int[funcListMap.size()];
		machine.numTransFuncIndex = funcListMap.size();

		/* For each funclist in the funclist map, copy the list over. Also
		 * copy the indicies into the transfuncs. This is pointer plus len. */
		FuncListMapEl *flel = funcListMap.first();
		int writeTo = 0, nflel = funcListMap.size();
		for ( int i = 0; i < nflel; i++, flel++ ) {
			/* Get a ref to the trans func list. */
			typename Transition::TransFuncList &tfl = flel->key;

			/* Set the index pointer and number of funcs for the func offset. */
			machine.transFuncIndex[flel->value] = writeTo;

			/* The first element is the length. */
			transFuncs[writeTo] = tfl.size();
			writeTo += 1;

			/* Copy the transFuncs at the writeTo offset. Maybe trans funcs 
			 * should be vector and vector.overwrite should be used. This 
			 * will do for now. This issue may go away as TransFunc may be 
			 * hardcoded to type int. */
			memcpy(transFuncs + writeTo, tfl.table,
					tfl.size() * sizeof(TransFunc));

			/* Increment the dest by the number of funcs in this func list. */
			writeTo += tfl.size();
		}

		/* Set the transition funcs ptr and the number of trans funcs. */
		machine.allTransFuncs = transFuncs;
		machine.numTransFuncs = numFuncs;
	}
}

/* Creates machine states and assignes each state to a its corresponding
 * state in the fsm graph from which it will be built.
 * Also takes the opprotunity to compute gblLowIndex and gblHighIndex.
 */
template < class State, class TransFunc, class Transition >
		void FsmBuild<State, TransFunc, Transition>::
		initMachineStates( )
{
	/* Make the array of states. */
	int numStates = graph.stateList.listLength;
	FsmMachState *machStates = new FsmMachState[numStates];

	/* Make all the states first and set the mapto values. */
	State *state = graph.stateList.head;
	FsmMachState *curState = machStates;
	for ( int i = 0; i < numStates; i++, curState++ ) {
		/* Init the state. */
		curState->transIndKey = NULL;
		curState->transIndPtr = NULL;
		curState->numIndex = 0;
		curState->rangeIndKey = NULL;
		curState->rangeIndPtr = NULL;
		curState->numRange = 0;
		curState->dflIndex = TRANS_ERR_TRANS;
		curState->outFuncs = FUNC_NO_FUNC;

		/* If the original state is a final state, set the new state final. */
		curState->isFinState = state->isFinState;

		/* Set the mapto value and go to next state. */
		state->alg.machState = (machStates + i);
		state = state->next;
	}

	/* Get the start state. */
	machine.numStates = numStates;
	machine.allStates = machStates;
	machine.startState = graph.startState->alg.machState - machStates;
}

/**
 * Make a machine transition from a graph transition. Returns the transition
 * offset for the state.
 */
template < class State, class TransFunc, class Transition >
		int FsmBuild<State, TransFunc, Transition>::
		makeMachineTrans( Transition *trans )
{
	/* Get the machine state. */
	FsmMachState *state = trans->toState->alg.machState;

	/* Add the functions to the map, retrieving the offset. */
	int newFuncOffset = addFuncsToMap( trans->transFuncTable );

	/* We now have the transition for looking up in the transMap. */
	FsmMachTrans machineTrans;
	machineTrans.toState = state - machine.allStates;
	machineTrans.funcs = newFuncOffset;

	/* If not in the transition map, insert it. */
	TransMapEl *lastFound;
	if ( transMap.insert( machineTrans, curTransOffset, &lastFound ) )
		curTransOffset +=1;

	/* Return the last transition inserted/found. */
	return lastFound->value;
}

/**
 * Build a machine state from a graph state. Is responsible for creating the
 * transitions of the new state.
 */
template < class State, class TransFunc, class Transition >
		void FsmBuild<State, TransFunc, Transition>::
		makeMachineState( FsmMachState *machState, State *state )
{
	TransEl *tel = state->outList.table;
	int i, j, ntel = state->outList.tableLength;
	machState->numIndex = ntel;
	if ( ntel > 0 ) {
		machState->transIndKey = new int[ntel];
		machState->transIndPtr = new int[ntel];
	}

	/* For each transition add the functions to the global function map and
	 * then add the transition to the global transition map. */
	for ( i = 0; i < ntel; i++, tel++ ) {
		/* Assume using the error transition. */
		int transOffset = TRANS_ERR_TRANS;

		/* The transition may not be set. */
		if ( tel->value != NULL )
			transOffset = makeMachineTrans( tel->value );

		/* Set the index for this character. */
		machState->transIndKey[i] = tel->key;
		machState->transIndPtr[i] = transOffset;
	}

	/*
	 * Now do ranges.
	 */
	tel = state->outRange.table;
	ntel = state->outRange.tableLength;
	machState->numRange = ntel/2;
	if ( ntel > 0 ) {
		machState->rangeIndKey = new int[ntel];
		machState->rangeIndPtr = new int[ntel/2];
	}

	/* For each range transition add the functions to the global function map
	 * and then add the transition to globabl map. */
	for ( i = 0, j = 0; i < ntel; i+=2, j++ ) {
		/* Assume using the error transition. */
		int transOffset = TRANS_ERR_TRANS;

		/* The transition may not be set. */
		if ( tel[i].value != NULL )
			transOffset = makeMachineTrans( tel[i].value );

		/* Set the index for this character. */
		machState->rangeIndKey[i] = tel[i].key;
		machState->rangeIndKey[i+1] = tel[i+1].key;
		machState->rangeIndPtr[j] = transOffset;
	}

	/* Make the default transition if there. Otherwise it will remain as err. */
	if ( state->defOutTrans != NULL )
		machState->dflIndex = makeMachineTrans( state->defOutTrans );
}

template < class State, class TransFunc, class Transition >
		void FsmBuild<State, TransFunc, Transition>::
		makeIndiciesFromRange( FsmMachState *machState )
{
	/* Count the number of indicies. */
	int i, dest, numIndex = 0;
	for ( i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		numIndex += upper - lower + 1;
	}

	machState->transIndKey = new int[numIndex];
	machState->transIndPtr = new int[numIndex];
	machState->numIndex = numIndex;

	/* Set the indicies. */
	for ( dest = 0, i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		for ( int ind = lower; ind <= upper; ind++ ) {
			machState->transIndKey[dest] = ind;
			machState->transIndPtr[dest] = machState->rangeIndPtr[i];
			dest += 1;
		}
	}
}
		
template < class State, class TransFunc, class Transition >
		void FsmBuild<State, TransFunc, Transition>::
		moveRangesIntoIndicies( FsmMachState *machState )
{
	/* Nothing to do if there are no ranges. */
	if ( machState->rangeIndPtr == 0 )
		return;

	/* If there are no indicies then simply express the ranges as indicies. */
	if ( machState->transIndKey == 0 ) {
		makeIndiciesFromRange( machState );
	}
	else {
		int *indexKey = machState->transIndKey;
		int *indexPtr = machState->transIndPtr;
		int numIndex = machState->numIndex;

		makeIndiciesFromRange( machState );

		int *rangeKey = machState->transIndKey;
		int *rangePtr = machState->transIndPtr;
		int numRange = machState->numIndex;

		/* Pass one is to count. */
		int count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				count += numRange - range;
				break;
			}
			else if ( range == numRange ) {
				count += numIndex - index;
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] )
					range += 1;
				else if ( indexKey[index] < rangeKey[range] )
					index += 1;
				else {
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}

		machState->transIndKey = new int[count];
		machState->transIndPtr = new int[count];
		machState->numIndex = count;

		/* Pass two is to build. */
		count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				while ( range < numRange ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
					count += 1;
				}
				break;
			}
			else if ( range == numRange ) {
				while ( index < numIndex ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					count += 1;
				}
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
				}
				else if ( indexKey[index] < rangeKey[range] ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
				}
				else {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}
		delete[] indexKey;
		delete[] indexPtr;
		delete[] rangeKey;
		delete[] rangePtr;
	}

	delete[] machState->rangeIndKey;
	delete[] machState->rangeIndPtr;
	machState->rangeIndKey = 0;
	machState->rangeIndPtr = 0;
	machState->numRange = 0;
}


#endif /* _RLFSM_FSMBUILD_H */

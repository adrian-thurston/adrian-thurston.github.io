/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_GRAPH_H
#define _RLFSM_GRAPH_H

#include "dlist.h"
#include "bstmap.h"
#include "mergesort.h"


template < class State,
			class Key,
			class Transition > struct GraphState 
		: public DListEl<State>
{
	GraphState() : stateMap(0), num(0) {}

	/****************************************
	 * TransKey
	 *
	 * This is they key that identifies a transition. Transitions
	 * are keyed on the character that they act on and the state
	 * they go to.
	 */
	struct TransKey
	{
		TransKey() : onChar(0), toState(0) {}
		TransKey(const Key &onChar, State *toState) :
				onChar(onChar), toState(toState) { }

		/* Character the trans is on. */
		Key onChar;

		/* State the trans goes to. */
		State *toState;
	};


	/****************************************
	 * TransKeyCmp
	 *
	 * Compare TransitionKeys. onChars are first order and State are second
	 * order. This ensures that transitions that are on the same character
	 * always end up next to each other in the TransList. When it
	 * comes time to find non-deterministic transitions, our life becomes
	 * much easier.
	 */
	struct TransKeyCmp
	{
		static inline int Compare(const TransKey &key1,
				const TransKey &key2)
		{
			if ( key1.onChar < key2.onChar )
				return -1;
			else if ( key1.onChar > key2.onChar )
				return 1;
			else
			{
				if ( key1.toState < key2.toState )
					return -1;
				else if ( key1.toState > key2.toState )
					return 1;
				else
					return 0;
			}
		}
	};

	/****************************************
	 * TransEl
	 *
	 * This structure is the element in the transition list.
	 * It contains the Key(TransKey) and the value(Transition).
	 */
	typedef BstMapEl<TransKey, Transition*> TransEl;

	/****************************************
	 * TransElCmp
	 */
	struct TransElCmp
	{
		static inline int Compare(const TransEl &el1,
				const TransEl &el2)
			{ return TransKeyCmp::Compare(el1.key, el2.key); }
	};

	/****************************************
	 * TransList
	 *
	 * This structure is the list of transions. Every state maintains
	 * two of these: InList and OutList.
	 */
	typedef BstMap<TransKey, Transition*, TransKeyCmp> TransList;

	/* TransitionLists. */
	TransList InList, OutList;

	/* When duplicating the fsm we need a map of state to new state. */
	State *stateMap;

	/* The number of the state, for printing. */
	int num;
};

/****************************************
 * template Graph
 */
template < class State,
			class Key,
			class Transition > struct Graph
		: public DList< State >
{
public:
	typename State::TransEl *LastTransElFrom, *LastTransElTo;

	Graph() : DList<State>(), LastTransElFrom(0), LastTransElTo(0) {}
	Graph(Graph &graph);
	~Graph();

	void SetStateNumbers();

	Transition *GetLastTrans() { return LastTransElFrom->value; }
	void SetLastTrans(Transition *trans) {
		LastTransElFrom->value = trans;
		LastTransElTo->value = trans;
	}

	bool AttachStates(State *from, State *to, Key onChar);
	Transition *AttachStatesWithTrans(State *from, State *to, Key onChar);
	Transition *DetachStates(State *from, State *to, Key onChar);

	void AddToGraph(State *state)
		{ DList<State>::append( state ); }
	State *DetachState(State *state);

	State *DetachInTrans(State *state);
	State *DetachOutTrans(State *state);

	void DumpTransitions( FILE *file, typename State::TransList *list );
	void Dump( FILE *file );
};

#endif /* _RLFSM_GRAPH_H */

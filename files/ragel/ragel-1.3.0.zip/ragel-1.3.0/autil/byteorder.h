/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Autil.
 *
 *  Autil is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Autil is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Autil; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _BYTE_ORDER_H
#define _BYTE_ORDER_H

#include "config.h"

/**
 * Provides static functions for reading/writing integers from/to little
 * endian format.
 */
class EndianLittle
{
public:
	/**
	 * Reads a 4-byte integer from the memory pointed to by src. Src is in
	 * little endian format.
	 *
	 * @returns The integer in system byte order.
	 */
	static int readInt(void *src);

	/**
	 * Write an integer from system byte order to a block of mem in little
	 * endian format.
	 */
	static void writeInt(void *dst, int i);
};

/**
 * Provides static functions for reading/writing integers from/to big endian
 * format.
 */
class EndianBig
{
public:
	/**
	 * Read an integer from a block of memory in big endian format to an
	 * integer in the system byte order format.
	 */
	static int readInt(void *src);

	/**
	 * Write an integer to a block of memory in big endian format from an
	 * integer in the system byte order format.
	 */
	static void writeInt(void *dst, int i);
};



#endif /* _BYTE_ORDER_H */

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_AVLMEL_H
#define _AAPL_AVLMEL_H

#include "compare.h"

/**
 * \addtogroup avltree 
 * @{
 */

/**
 * \class AvlMel
 * \brief AVL tree for nodes appearing in multiple trees.
 *
 * AvlMel allows for a node to simultaneously be an element in multiple trees
 * without the two trees interferring with one another. This is achieved by
 * multiple inheritence. The element must use the same key for each tree. The
 * AvlMel class requires that you specify to it how to resolve the ambiguities
 * between the multiple AvlNode classes that the node will inherit from. This
 * is done with the BaseNode parameter.
 *
 * AvlMel does not explicitly manage memory for nodes. Nodes inserted into
 * the tree are typically allocated by the user. Since nodes can have static
 * allocation, the tree does not assume ownership of the nodes. The destructor
 * will not delete nodes. A deep copy will cause existing elements to be
 * abandoned.
 *
 * \include ex_avlmel.cpp
 */

/*@}*/

#define BASENODE(name) BaseNode::name
#define BASEKEY(name) name
#define BASECOMPARE(name) Node::name
#define AVLMEL_TEMPDEF class Node, class Key, class BaseNode
#define AVLMEL_TEMPUSE Node, Key, BaseNode
#define AvlTree AvlMel

#include "avlcommon.h"

#undef BASENODE
#undef BASEKEY
#undef BASECOMPARE
#undef AVLMEL_TEMPDEF
#undef AVLMEL_TEMPUSE
#undef AvlTree

#endif /* _AAPL_AVLMEL_H */

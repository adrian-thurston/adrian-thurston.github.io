/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_SHRSTR_H
#define _AAPL_SHRSTR_H

#include <new>
#include <malloc.h>

namespace Aapl {

struct StringHead
{
	int refCount;
	int length;
};

template<class T> class StringTmpl
{
public:
	/**
	 * \brief Create a null string.
	 */
	StringTmpl() : data(0) { }

	/* Clean up the string. */
	~StringTmpl();

	/**
	 * \brief Construct a string from a c-style string.
	 */
	StringTmpl( const char *str );

	/**
	 * \brief Construct a string from another StringTmpl.
	 */
	StringTmpl( const StringTmpl &str );

	/* Set the string from a c-style string. */
	StringTmpl &operator=( const char *str );

	/* Set the string from another StringTmpl. */
	StringTmpl &operator=( const StringTmpl &str );

	/* Append a c string to the end of this string. */
	StringTmpl &operator+=( const char *str );

	/* Append an StringTmpl to the end of this string. */
	StringTmpl &operator+=( const StringTmpl &str );

	/**
	 * \brief Cast to a char star.
	 *
	 * \returns the string data.
	 */
	operator char*() const { return data; }

	int getLen() const { return (((StringHead*)data)-1)->length; }

	/**
	 * \brief Pointer to the data.
	 */
	char *data;

protected:
	/* Append a string of length len (not counting null) to this string. */
	void append( const char *str, int len );

 	template<class FT> friend StringTmpl<FT> operator+( 
			const StringTmpl<FT> &str1, const char *str2 );
	template<class FT> friend StringTmpl<FT> operator+( 
			const char *str1, const StringTmpl<FT> &str2 );
	template<class FT> friend StringTmpl<FT> operator+( 
			const StringTmpl<FT> &str1, const StringTmpl<FT> &str2 );

private:
	/* A dummy struct solely to make a constructor that will never be ambiguous
	 * with the public constructors. */
	struct DisAmbig { int dummy; };
	StringTmpl( char *data, const DisAmbig &) : data(data) { }
};

/**
 * \brief Free all mem used by the string.
 */
template<class T> StringTmpl<T>::~StringTmpl()
{
	if ( data != 0 ) {
		/* If we are the only ones referencing the string, then delete it. */
		StringHead *head = ((StringHead*) data) - 1;
		head->refCount -= 1;
		if ( head->refCount == 0 )
			free( head );
	}
}

/* Create from a c-style string. */
template<class T> StringTmpl<T>::StringTmpl( const char *str )
{
	if ( str == 0 )
		data = 0;
	else {
		/* Find the length and allocate the space for the shared string. */
		int length = strlen( str );
		StringHead *head = (StringHead*) malloc( 
				sizeof(StringHead) + length+1 );
		if ( head == 0 )
			throw std::bad_alloc();

		/* Init the header. */
		head->refCount = 1;
		head->length = length;

		/* Copy in the data and save the pointer to it. */
		data = (char*) (head+1);
		memcpy( data, str, length+1 );
	}
}


/* Create from another string class. */
template<class T> StringTmpl<T>::StringTmpl( const StringTmpl &str )
{
	if ( str.data == 0 )
		data = 0;
	else {
		/* Take a reference to the string. */
		StringHead *strHead = ((StringHead*)str.data) - 1;
		strHead->refCount += 1;
		data = (char*) (strHead+1);
	}
}

/**
 * \brief Set the string.
 *
 * Set this string to be the c string exactly. The old string is discarded.
 *
 * \returns a reference to this.
 */
template<class T> StringTmpl<T> &StringTmpl<T>::operator=( const char *str )
{
	if ( str == 0 ) {
		/* Just free the data, we are being set to null. */
		if ( data != 0 ) {
			StringHead *head = ((StringHead*)data) - 1;
			head->refCount -= 1;
			if ( head->refCount == 0 )
				free(head);
			data = 0;
		}
	}
	else {
		/* Find the length of the string we are setting. */
		int length = strlen( str );

		/* Detach from the existing string. */
		StringHead *head = ((StringHead*)data) - 1;
		if ( data != 0 && --head->refCount == 0 ) {
			/* Resuse the space. */
			head = (StringHead*) realloc( head, sizeof(StringHead) + length+1 );
		}
		else {
			/* Need to make new space, there is no usable old space. */
			head = (StringHead*) malloc( sizeof(StringHead) + length+1 );
		}
		if ( head == 0 )
			throw std::bad_alloc();

		/* Init the header. */
		head->refCount = 1;
		head->length = length;

		/* Copy in the data and save the pointer to it. */
		data = (char*) (head+1);
		memcpy( data, str, length+1 );
	}
	return *this;
}

/**
 * \brief Set the string.
 *
 * Set this string to be the StringTmpl str exactly. The old string is
 * discarded.
 *
 * \returns a reference to this.
 */
template<class T> StringTmpl<T> &StringTmpl<T>::operator=( const StringTmpl &str )
{
	/* Detach from the existing string. */
	if ( data != 0 ) {
		StringHead *head = ((StringHead*)data) - 1;
		head->refCount -= 1;
		if ( head->refCount == 0 )
			free( head );
	}

	if ( str.data != 0 ) {
		/* Take a reference to the string. */
		StringHead *strHead = ((StringHead*)str.data) - 1;
		strHead->refCount += 1;
		data = (char*)(strHead+1);
	}
	else {
		/* Setting from a null string, just null our pointer. */
		data = 0;
	}
	return *this;
}

/**
 * \brief Append a c-style string to the end of this string.
 *
 * \returns a reference to this
 */
template<class T> StringTmpl<T> &StringTmpl<T>::operator+=( const char *str )
{
	/* Find the length of the string appended. */
	if ( str != 0 ) {
		int addedLen = strlen( str );
		append( str, addedLen );
	}
	return *this;
}

/**
 * \brief Append an StringTmpl string to the end of this string.
 *
 * \returns a reference to this
 */
template<class T> StringTmpl<T> &StringTmpl<T>::operator+=( const StringTmpl &str )
{
	/* Find the length of the string appended. */
	if ( str.data != 0 ) {
		int addedLen = (((StringHead*)str.data) - 1)->length;
		append( str, addedLen );
	}
	return *this;
}


/* Append a string of length len (not counting null) to this string. */
template<class T> void StringTmpl<T>::append( const char *str, int len )
{
	/* Find the length of this and the string appended. */
	StringHead *head = (((StringHead*)data) - 1);
	int thisLen = head->length;

	if ( head->refCount == 1 ) {
		/* No other string is using the space, grow this space. */
		head = (StringHead*) realloc( head, 
				sizeof(StringHead) + thisLen + len + 1 );
		if ( head == 0 )
			throw std::bad_alloc();
		data = (char*) (head+1);

		/* Adjust the length. */
		head->length += len;
	}
	else {
		/* Another string is using this space, make new space. */
		head->refCount -= 1;
		StringHead *newHead = (StringHead*) malloc(
				sizeof(StringHead) + thisLen + len + 1 );
		if ( newHead == 0 )
			throw std::bad_alloc();
		data = (char*) (newHead+1);

		/* Set the new header and data from this. */
		newHead->refCount = 1;
		newHead->length = thisLen + len;
		memcpy( data, head+1, thisLen );
	}

	/* Copy in the data from str. */
	memcpy( data + thisLen, str, len+1 );
}

/**
 * \brief Add an StringTmpl and a c-style string.
 *
 * \returns The concatenation of the two strings in an StringTmpl.
 */
template<class T> StringTmpl<T> operator+( const StringTmpl<T> &str1, 
		const char *str2 )
{
	/* Find str2 length and alloc the space for the result. */
	int str1Len = (((StringHead*)(str1.data)) - 1)->length;
	int str2Len = strlen( str2 );

	StringHead *head = (StringHead*) malloc( sizeof(StringHead) + 
			str1Len + str2Len + 1 );
	if ( head == 0 )
		throw std::bad_alloc();

	/* Set up the header. */
	head->refCount = 1;
	head->length = str1Len + str2Len;

	/* Save the pointer to data and copy the data in. */
	char *data = (char*) (head+1);
	memcpy( data, str1.data, str1Len );
	memcpy( data + str1Len, str2, str2Len + 1 );
	return StringTmpl<T>( data, StringTmpl<T>::DisAmbig() );
}

/**
 * \brief Add a c-style string and an StringTmpl.
 *
 * \returns The concatenation of the two strings in an StringTmpl.
 */
template<class T> StringTmpl<T> operator+( const char *str1, 
		const StringTmpl<T> &str2 )
{
	/* Find str2 length and alloc the space for the result. */
	int str1Len = strlen( str1 );
	int str2Len = (((StringHead*)(str2.data)) - 1)->length;

	StringHead *head = (StringHead*) malloc( sizeof(StringHead) + 
			str1Len + str2Len + 1 );
	if ( head == 0 )
		throw std::bad_alloc();

	/* Set up the header. */
	head->refCount = 1;
	head->length = str1Len + str2Len;

	/* Save the pointer to data and copy the data in. */
	char *data = (char*) (head+1);
	memcpy( data, str1, str1Len );
	memcpy( data + str1Len, str2.data, str2Len + 1 );
	return StringTmpl<T>( data, StringTmpl<T>::DisAmbig() );
}

/**
 * \brief Add two StringTmpl strings.
 *
 * \returns The concatenation of the two strings in an StringTmpl.
 */
template<class T> StringTmpl<T> operator+( const StringTmpl<T> &str1, 
		const StringTmpl<T> &str2 )
{
	/* Find str2 length and alloc the space for the result. */
	int str1Len = (((StringHead*)(str1.data)) - 1)->length;
	int str2Len = (((StringHead*)(str2.data)) - 1)->length;
	StringHead *head = (StringHead*) malloc( sizeof(StringHead) + 
			str1Len + str2Len + 1 );
	if ( head == 0 )
		throw std::bad_alloc();

	/* Set up the header. */
	head->refCount = 1;
	head->length = str1Len + str2Len;

	/* Save the pointer to data and copy the data in. */
	char *data = (char*) (head+1);
	memcpy( data, str1.data, str1Len );
	memcpy( data + str1Len, str2.data, str2Len + 1 );
	return StringTmpl<T>( data, StringTmpl<T>::DisAmbig() );
}

typedef StringTmpl<char> String;

/* namespace Aapl */
}

#endif /* _AAPL_SHRSTR_H */

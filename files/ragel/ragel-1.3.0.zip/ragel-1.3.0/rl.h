/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLSCANNER_H
#define _RLSCANNER_H


#include <stdio.h>
#include <fstream>
#include "deque.h"
#include "avltree.h"

#define PROGNAME "ragel"

enum MinimizeLevel {
	MinimizeNone,
	MinimizeApprox,
	MinimizeStable,
	MinimizePartition1,
	MinimizePartition2
};

extern FILE *rlin;

/* Io filenames and stream. */
extern char *inputFile;
extern char *outputFile;
extern std::ofstream *outputStream;

extern int rlCurLine;


extern bool printStats;
extern bool minimizeEveryOp;
extern MinimizeLevel minimizeLevel;
extern bool dumpFinal;
extern bool machinesGiven;

void rlerror(char *error);
int rllex();
int rlparse();

/* This structure is used by the lexer to return a range of characters
 * in a regular expression to the parser. */
struct RegExpSet
{
	char lower;
	char upper;
};

/* Str dup using the new operator. */
char *strDup(const char *str);


#endif

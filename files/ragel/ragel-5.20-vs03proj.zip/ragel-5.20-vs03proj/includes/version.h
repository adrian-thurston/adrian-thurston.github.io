#define VERSION "5.20"
#define PUBDATE "April 2007\n(Built with Microsoft (R) 32-bit C/C++ Optimizing Compiler Version 13.10.6030 for 80x86)"

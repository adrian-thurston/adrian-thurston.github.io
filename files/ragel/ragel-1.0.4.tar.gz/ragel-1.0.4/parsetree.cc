/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "parsetree.h"
#include "rl.h"
#include "byteset.h"
#include "support.h"


int curFuncOrdering = 0;

/* Make a new dot fsm. */
Fsm *DotFsm()
{
	/* New Graph. */
	Fsm *retVal = new Fsm;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	retVal->StartState = start;
	for ( int i = 0; i < 256; i++ )
		retVal->AttachStates( start, end, i );

	return retVal;
}

Fsm *ByteSetFsm( ByteSet::CharSet set )
{
	ByteSet bs( set );
	/* New Graph. */
	Fsm *retVal = new Fsm;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	retVal->StartState = start;
	for ( int i = 0; i < 256; i++ ) {
		if ( bs.IsSet( i ) )
			retVal->AttachStates( start, end, i );
	}

	return retVal;
}

/******************************************
 * InitGraphDict
 *
 * Initialize the graph dict with builtin types.
 */
void InitGraphDict( GraphDict *graphDict )
{
	graphDict->Insert( "ascii", new ExpressionNode(ByteSetFsm(ByteSet::ascii)) );
	graphDict->Insert( "extend", new ExpressionNode(ByteSetFsm(ByteSet::extend)) );
	graphDict->Insert( "alnum", new ExpressionNode(ByteSetFsm(ByteSet::alnum)) );
	graphDict->Insert( "alpha", new ExpressionNode(ByteSetFsm(ByteSet::alpha)) );
	graphDict->Insert( "cntrl", new ExpressionNode(ByteSetFsm(ByteSet::cntrl)) );
	graphDict->Insert( "digit", new ExpressionNode(ByteSetFsm(ByteSet::digit)) );
	graphDict->Insert( "graph", new ExpressionNode(ByteSetFsm(ByteSet::graph)) );
	graphDict->Insert( "lower", new ExpressionNode(ByteSetFsm(ByteSet::lower)) );
	graphDict->Insert( "print", new ExpressionNode(ByteSetFsm(ByteSet::print)) );
	graphDict->Insert( "punct", new ExpressionNode(ByteSetFsm(ByteSet::punct)) );
	graphDict->Insert( "space", new ExpressionNode(ByteSetFsm(ByteSet::space)) );
	graphDict->Insert( "upper", new ExpressionNode(ByteSetFsm(ByteSet::upper)) );
	graphDict->Insert( "xdigit", new ExpressionNode(ByteSetFsm(ByteSet::xdigit)) );
}

/***********************************************************
 * AfterOpCondense
 *
 * Perform condensing after an operation according to the
 * command line args.
 */
void AfterOpCondense( Fsm *fsm )
{
	if ( condenseEveryOp ) {
		switch ( condenseLevel ) {
			case CondenseNone:
				break;
			case CondenseApprox:
				fsm->CondenseApproximate();
				break;
			case CondenseStable:
				fsm->CondenseStable();
				break;
			case CondenseOptimized1:
				fsm->CondenseOptimized1();
				break;
			case CondenseOptimized2:
				fsm->CondenseOptimized2();
				break;
		}
	}
}

/************************************************************
 * ParseData Constructor.
 */
ParseData::ParseData()
		: nextFuncNum(1), machineGiven(false)
{
	/* Initialize the dictionary of graphs.
	 * This is our symbol table. */
	InitGraphDict( &graphDict );
}

/************************************************************
 * ParseData Destructor.
 */
ParseData::~ParseData()
{
	/* Delete all the nodes in the function list. Will cause all the
	 * string data that represents the functions to be deallocated. */
	funcList.DeleteElements();
	dataList.DeleteElements();
	preFuncList.DeleteElements();
	postFuncList.DeleteElements();
	initCodeList.DeleteElements();
}

/***********************************************************
 * ExpressionNode Destructor.
 */
ExpressionNode::~ExpressionNode()
{
	switch ( type ) {
		case Or: case Intersect: case Subtract:
			delete expression;
			delete term;
			break;
		case Term:
			delete term;
			break;
		case Builtin:
			delete builtin;
			break;
	}
}

/***********************************************************
 * ExpressionNode::Walk
 */
Fsm *ExpressionNode::Walk()
{
	Fsm *rtnVal;
	switch ( type ) {
		case Or: {
			/* Evaluate the expression. */
			rtnVal = expression->Walk();
			/* Evaluate the term. */
			Fsm *rhs = term->Walk();
			/* Perform union. */
			rtnVal->Or( rhs );
			/* Condensing. */
			AfterOpCondense( rtnVal );
			break;
		}
		case Intersect: {
			/* Evaluate the expression. */
			rtnVal = expression->Walk();
			/* Evaluate the term. */
			Fsm *rhs = term->Walk();
			/* Perform intersection. */
			rtnVal->Intersect( rhs );
			/* Condensing. */
			AfterOpCondense( rtnVal );
			break;
		}
		case Subtract: {
			/* Evaluate the expression. */
			rtnVal = expression->Walk();
			/* Evaluate the term. */
			Fsm *rhs = term->Walk();
			/* Perform subtraction. */
			rtnVal->Subtract( rhs );
			/* Condensing. */
			AfterOpCondense( rtnVal );
			break;
		}
		case Term: {
			/* Return result of the term. */
			rtnVal = term->Walk();
			break;
		}
		case Builtin: {
			/* Duplicate the builtin. */
			rtnVal = new Fsm( *builtin );
			break;
		}
	}

	return rtnVal;
}

/***********************************************************
 * TermNode Destructor.
 */
TermNode::~TermNode()
{
	switch ( type ) {
		case Concat:
			delete term;
			delete factorWithAug;
			break;
		case FactorWithAug:
			delete factorWithAug;
			break;
	}
}

/***********************************************************
 * TermNode::Walk
 */
Fsm *TermNode::Walk()
{
	Fsm *rtnVal;
	switch ( type ) {
		case Concat: {
			/* Evaluate the Term. */
			rtnVal = term->Walk();
			/* Evaluate the FactorWithRep. */
			Fsm *rhs = factorWithAug->Walk();
			/* Perform concatenation. */
			rtnVal->Concat( rhs, leavingFsm );
			/* Condensing. */
			AfterOpCondense( rtnVal );
			break;
		}
		case FactorWithAug: {
			rtnVal = factorWithAug->Walk();
			break;
		}
	}
	return rtnVal;
}

/***********************************************************
 * FactorWithAugNode Destructor.
 */
FactorWithAugNode::~FactorWithAugNode()
{
	delete factorWithRep;
	/* Walk the vector of parser funcs, deleting function names. */
}

/***********************************************************
 * FactorWithAugNode::Walk
 */
Fsm *FactorWithAugNode::Walk()
{
	/* First walk the list of functions, assigning the
	 * starting function ordering. */
	ParserFunc *func = funcs.table;
	int i, nFuncs = funcs.tableLength;
	for ( i = 0; i < nFuncs; i++, func++ ) {
		if ( func->type == start )
			func->ordering = curFuncOrdering++;
	}

	/* Evaluate the factor with repetition. */
	Fsm *rtnVal = factorWithRep->Walk();

	/* Now compute the remaining function call orderings. */
	func = funcs.table;
	nFuncs = funcs.tableLength;
	for ( i = 0; i < nFuncs; i++, func++ ) {
		if ( func->type != start )
			func->ordering = curFuncOrdering++;
	}

	/* Assign functions. */
	func = funcs.table;
	nFuncs = funcs.tableLength;
	for ( i = 0; i < nFuncs; i++, func++ )  {
		if ( func->func == FUNC_NUM_CLEAR ) {
			switch ( func->type ) {
			case start:
				rtnVal->ClearStartFsmFunc( );
				/* FIXME: I'm not sure if this is required, think about it. */
				AfterOpCondense( rtnVal );
				break;
			case all:
				rtnVal->ClearAllTransFunc( );
				break;
			case fin:
				rtnVal->ClearFinFsmFunc( );
				break;
			case leave:
				rtnVal->ClearLeaveFsmFunc( );
				break;
			case clearLeave:
				ASSERTNOTREACHED();
			}
		}
		else {
			switch ( func->type ) {
			case start:
				rtnVal->StartFsmFunc( func->func, func->ordering );
				/* Start fsm funcs are a special case that may require
				 * condensing afterwards. */
				AfterOpCondense( rtnVal );
				break;
			case all:
				rtnVal->AllTransFunc( func->func, func->ordering );
				break;
			case fin:
				rtnVal->FinFsmFunc( func->func, func->ordering );
				break;
			case leave:
				rtnVal->LeaveFsmFunc( func->func, func->ordering );
				break;
			case clearLeave:
				ASSERTNOTREACHED();
			}
		}
	}

	/* Assign priorities. */
	PriorityAug *aug = priorityAugs.table;
	int nAugs = priorityAugs.tableLength;
	for ( i = 0; i < nAugs; i++, aug++ ) {
		switch ( aug->type ) {
			case start:
				rtnVal->StartFsmPrior( aug->value );
				/* Start fsm priorities are a special case that may require
				 * condensing afterwards. */
				AfterOpCondense( rtnVal );
				break;
			case all:
				rtnVal->AllTransPrior( aug->value );
				break;
			case fin:
				rtnVal->FinFsmPrior( aug->value );
				break;
			case leave:
				rtnVal->LeaveFsmPrior( aug->value );
				break;
			case clearLeave:
				rtnVal->ClearLeaveFsmPrior();
				break;
		}
	}
	
	return rtnVal;
}

/***********************************************************
 * FactorWithRepNode Destructor.
 */
FactorWithRepNode::~FactorWithRepNode()
{
	switch ( type ) {
		case Star: case Optional: case Plus: case Negate:
			delete factorWithRep;
			break;
		case Range:
			delete range;
			break;
	}
}

/***********************************************************
 * FactorWithRepNode::Walk
 */
Fsm *FactorWithRepNode::Walk()
{
	Fsm *rtnVal;
	switch ( type ) {
		case Star: {
			/* Evaluate the FactorWithRep. */
			rtnVal = factorWithRep->Walk();
			/* Perform the kleen star. */
			if ( leavingFsm ) {
				curFuncOrdering +=
						rtnVal->ShiftStartFuncOrder( curFuncOrdering );
			}
			rtnVal->Star(leavingFsm);
			/* Condensing. */
			AfterOpCondense(rtnVal);
			break;
		}
		case Optional: {
			/* Evaluate the FactorWithRep. */
			rtnVal = factorWithRep->Walk();
			/* Perform the question operator. */
			rtnVal->Or( Fsm::NullFsm() );
			/* Condensing. */
			AfterOpCondense(rtnVal);
			break;
		}
		case Plus: {
			/* Evaluate the FactorWithRep. */
			rtnVal = factorWithRep->Walk();
			/* Perform the plus operator. */
			Fsm *dup = new Fsm(*rtnVal);
			if ( leavingFsm ) {
				curFuncOrdering +=
						dup->ShiftStartFuncOrder( curFuncOrdering );
			}
			dup->Star(leavingFsm);
			/* Intermediate condensing. */
			AfterOpCondense(dup);
			rtnVal->Concat(dup, leavingFsm);
			/* Condensing. */
			AfterOpCondense(rtnVal);
			break;
		}
		case Negate: {
			/* Evaluate the FactorWithRep. */
			Fsm *toNegate = factorWithRep->Walk();
			/* Perform the Negation. */
			rtnVal = DotFsm();
			rtnVal->Star(true);
			rtnVal->CondenseStable(); // Make 1 state machine always.
			rtnVal->Subtract( toNegate );
			/* Condensing. */
			AfterOpCondense(rtnVal);
			break;
		}
		case Range: {
			/* Evaluate the Factor. Pass it up. */
			rtnVal = range->Walk();
			break;
		}
	}
	return rtnVal;
}

/***********************************************************
 * RangeNode Destructor.
 */
RangeNode::~RangeNode()
{
	switch ( type ) {
		case Range:
			break;
		case Factor:
			delete factor;
			break;
	}
}

/***********************************************************
 * RangeNode::Walk
 */
Fsm *RangeNode::Walk()
{
	Fsm *rtnVal;
	switch ( type ) {
		case Range: {
			if ( upper < lower )
				rtnVal = Fsm::NullFsm();
			else {
				int nVals = upper-lower+1;
				int *vals = new int[nVals];
				for ( int i = lower; i <= upper; i++ )
					vals[i-lower] = i;
				rtnVal = Fsm::OrFsm( vals, nVals );
				delete[] vals;
			}
			
			break;
		}
		case Factor:
			rtnVal = factor->Walk();
			break;
	}
	return rtnVal;
}

/***********************************************************
 * FactorNode Destructor.
 */
FactorNode::~FactorNode()
{
	switch ( type ) {
		case LiteralFsm:
			delete fsm;
			break;
		case LookupExpression:
			break;
		case Expression:
			delete expression;
			break;
	}
}

/***********************************************************
 * FactorNode::Walk
 */
Fsm *FactorNode::Walk()
{
	Fsm *rtnVal;
	switch ( type ) {
		case LiteralFsm:
			rtnVal = new Fsm(*fsm);
			break;
		case LookupExpression:
		case Expression:
			rtnVal = expression->Walk();
			break;
	}
	return rtnVal;
}


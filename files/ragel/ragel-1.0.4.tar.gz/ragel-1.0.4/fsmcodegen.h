/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _FSMCODEGEN_H
#define _FSMCODEGEN_H

#include <iostream>
#include <fstream>
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"

class FsmCodeGen;
typedef void (*SectionType)(FsmCodeGen *codeGen, ostream &out);

void common_FSMNAME( FsmCodeGen *codeGen, ostream &out );
void common_STRUCT_DATA( FsmCodeGen *codeGen, ostream &out );
void common_PRE_FUNC_LIST( FsmCodeGen *codeGen, ostream &out );
void common_POST_FUNC_LIST( FsmCodeGen *codeGen, ostream &out );
void common_INIT_CODE( FsmCodeGen *codeGen, ostream &out );
void common_ANY_FUNCS( FsmCodeGen *codeGen, ostream &out );
void common_ANY_INDICIES( FsmCodeGen *codeGen, ostream &out );


/***********************************************************************
 * class FsmCodeGen
 */
class FsmCodeGen
{
public:
	FsmCodeGen( char *fsmName, FsmMachine<int> *machine, ParseData *parseData );

	void WriteOutHeader( ostream &out );
	void WriteOutCode( ostream &out );

	void WriteOutScan( ostream &out, char *data );
	void SelectSection( ostream &out, char *sname );

	BstMap<char*, SectionType, StrCmp> sectionDict;
	void RegisterSection( char *secName, SectionType call );
	char *GetCodeBuiltin(int index);

	char *header;
	char *code;

	char *fsmName;
	FsmMachine<int> *machine;
	ParseData *parseData;

	static char outputHeader[];
};


#endif /* _FSMCODEGEN_H */

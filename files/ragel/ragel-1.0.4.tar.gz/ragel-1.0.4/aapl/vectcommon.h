/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

#include <new>
#include <string.h>
#include "assert.h"
#include "table.h"

#if defined( VECTOR_DEFAULT )
#	define Vector Vector
#	define EXPN_DOWN
#	define EXPN_UP
#	define DownResize ExpnDownResize
#	define UpResize ExpnUpResize
#elif defined( VECTOR_EXPN_EXPN )
#	define Vector VectorE
#	define EXPN_DOWN
#	define EXPN_UP
#	define DownResize ExpnDownResize
#	define UpResize ExpnUpResize
#elif defined( VECTOR_EXPN_LIN )
#	define Vector VectorEL
#	define EXPN_DOWN
#	define LIN_UP
#	define DownResize ExpnDownResize
#	define UpResize LinUpResize
#elif defined( VECTOR_EXPN_CONST )
#	define Vector VectorEC
#	define EXPN_DOWN
#	define CONST_UP
#	define DownResize ExpnDownResize
#	define UpResize ConstUpResize
#elif defined( VECTOR_LIN_EXPN )
#	define Vector VectorLE
#	define LIN_DOWN
#	define EXPN_UP
#	define DownResize LinDownResize
#	define UpResize ExpnUpResize
#elif defined( VECTOR_LIN_LIN )
#	define Vector VectorL
#	define LIN_DOWN
#	define LIN_UP
#	define DownResize LinDownResize
#	define UpResize LinUpResize
#elif defined( VECTOR_LIN_CONST )
#	define Vector VectorLC
#	define LIN_DOWN
#	define CONST_UP
#	define DownResize LinDownResize
#	define UpResize ConstUpResize
#elif defined( VECTOR_CONST_EXPN )
#	define Vector VectorCE
#	define CONST_DOWN
#	define EXPN_UP
#	define DownResize ConstDownResize
#	define UpResize ExpnUpResize
#elif defined( VECTOR_CONST_LIN )
#	define Vector VectorCL
#	define CONST_DOWN
#	define LIN_UP
#	define DownResize ConstDownResize
#	define UpResize LinUpResize
#elif defined( VECTOR_CONST_CONST )
#	define Vector VectorC
#	define CONST_DOWN
#	define CONST_UP
#	define DownResize ConstDownResize
#	define UpResize ConstUpResize
#elif defined( VECTOR_RT )
#	define Vector VectorR
#	define DownResize RTDownResize
#	define UpResize RTUpResize
#else
#	error "no vector table type"
#endif

#define DEFAULT_STEP 10

/****************************************
 * template Vector
 */
template <class T> class Vector : public Table<T>
{
public:
#if defined( VECTOR_RT )
	enum ResizeType {
		Expn, 
		Linear, 
		Const
	};

	ResizeType upResize;
	ResizeType downResize;
#endif

	/* Default Constructor. */
	inline Vector();

	/* Init Vector with size elements. */
	inline Vector( int size );

	/* Init Vector with size elements, init with allocLength space. */
	Vector( int size, int allocLength );

#if defined( LIN_UP ) || defined( LIN_DOWN ) || defined( VECTOR_RT )
	/* Init Vector with size elements, allocLength space allocated
	 * and specified step for linear table allocation. */
	Vector( int size, int allocLength, int step );
#endif

#if defined( VECTOR_RT )
	/* Init empty vector. */
	inline Vector( ResizeType upResize, ResizeType downResize );

	/* Init Vector with size elements. */
	inline Vector( ResizeType upResize, ResizeType downResize, int size );

	/* Init Vector with size elements, init with allocLength space. */
	Vector( ResizeType upResize, ResizeType downResize, 
			int size, int allocLength );

	/* Init Vector with size elements, allocLength space allocated
	 * and specified step for linear table allocation. */
	Vector( ResizeType upResize, ResizeType downResize, 
			int size, int allocLength, int step );
#endif

	/* Copy Constructor. */
	Vector( const Vector &v );

	/* Destructor Empties the Vector. */
	~Vector() { Empty(); }

	/* Reset the contents of the Vector to 0. */
	void Empty();

	/* Insertion routines. */
	void Insert(int pos, const T &val)   { Insert(pos, &val, 1); }
	/* Causes ambiguaties when T is int type. */
	/* void Insert(int pos, int len)     { Insert(pos, 0, len); } */
	void Insert(int pos, const T *val, int len);
	void Insert(int pos, const Vector &v);

	/* Deletion routines. */
	void Delete(int pos)                 { Delete(pos, 1); }
	void Delete(int pos, int len);

	/* Overwriting routines. */
	void Overwrite(int pos, const T &val)   { Overwrite(pos, &val, 1); }
	/* void Overwrite(int pos, int len)     { Overwrite(pos, 0, len); } */
	void Overwrite(int pos, const T *val, int len);
	void Overwrite(int pos, const Vector &v);

	/* Routines for setting the contents. */
	void SetAs(const T &val)             { SetAs(&val, 1); }
	/* void SetAs(int len)               { SetAs(0, len); } */
	void SetAs(const T *val, int len);
	void SetAs(const Vector &v);

	/* Appending routines. */
	void Append(const T &val)            { Overwrite(tableLength, &val, 1); }
	/* void Append(int len)              { Overwrite(tableLength, 0, len); } */
	void Append(const T *val, int len)   { Overwrite(tableLength, val, len); }
	void Append(const Vector &v)          
			{ ASSERT(&v != this); Overwrite(tableLength, v.table, v.tableLength); }

#if defined( LIN_UP ) || defined( LIN_DOWN ) || defined( VECTOR_RT )
	int step;
#endif

protected:
 	int MakeRawSpaceFor(int pos, int len);

private:
	void UpResize(int len);
	void DownResize();
#if defined( VECTOR_RT )
	void ExpnUpResize(int len);
	void ExpnDownResize();
	void LinUpResize(int len);
	void LinDownResize();
	void ConstUpResize(int len);
	void ConstDownResize();
#endif
};

/*************************************************************
 * Default Constructor
 */
template<class T> inline Vector<T>::Vector()
{
#if defined( LIN_UP ) || defined( LIN_DOWN ) || defined( VECTOR_RT )
	/* Set the step to the default before any autotmatic resizing
	 * is done. */
	this->step = DEFAULT_STEP;
#endif
#if defined( VECTOR_RT )
	this->upResize = Expn;
	this->downResize = Expn;
#endif
}

/*************************************************************
 * Init Vector with size elements.
 */
template<class T> inline Vector<T>::Vector( int size )
{
#if defined( LIN_UP ) || defined( LIN_DOWN ) || defined( VECTOR_RT )
	/* Set the step to the default before any autotmatic resizing
	 * is done. */
	this->step = DEFAULT_STEP;
#endif
#if defined( VECTOR_RT )
	this->upResize = Expn;
	this->downResize = Expn;
#endif

	SetAs( 0, size );
}

/*************************************************************
 * Init Vector with size elements, allocLength space allocated.
 */
template<class T> Vector<T>::Vector( int size, int allocLength )
{
#if defined( LIN_UP ) || defined( LIN_DOWN ) || defined( VECTOR_RT )
	/* Set the step to the default before any autotmatic resizing
	 * is done. */
	this->step = DEFAULT_STEP;
#endif
#if defined( VECTOR_RT )
	this->upResize = Expn;
	this->downResize = Expn;
#endif

	/* Allocate the space if we are given a positive allocLength. */
	this->allocLength = allocLength;
	if ( allocLength > 0 ) {
		table = (T*) new char [sizeof(T) * allocLength];
		ASSERT( table != 0 );
	}

	/* Grow to the size specified. If we did not have enough space
	 * allocated that is ok. Table will be grown to right size. */
	SetAs( 0, size );
}

#if defined( LIN_UP ) || defined( LIN_DOWN ) || defined( VECTOR_RT )
/****************************************************************
 * Init Vector with size elements, allocLength space allocated
 * and specified step for linear table allocation.
 */
template<class T> Vector<T>::Vector( int size, int allocLength, int step )
{
	/* Before we do any automatic resizing, init the step. */
	this->step = step;
#if defined( VECTOR_RT )
	this->upResize = Expn;
	this->downResize = Expn;
#endif

	/* Allocate the space if we are given a positive allocLength. */
	this->allocLength = allocLength;
	if ( allocLength > 0 ) {
		table = (T*) new char [sizeof(T) * allocLength];
		ASSERT( table != 0 );
	}

	/* Grow to the size specified. If we did not have enough space
	 * allocated that is ok. Table will be grown to right size. */
	SetAs( 0, size );
}
#endif 

#if defined( VECTOR_RT )

/*****************************************************************
 * Init empty vector.
 */
template<class T> inline Vector<T>::Vector( ResizeType upResize, 
		ResizeType downResize )
{
	this->step = DEFAULT_STEP;
	this->upResize = Expn;
	this->downResize = Expn;
}

/*****************************************************************
 * Init Vector with size elements.
 */
template<class T> inline Vector<T>::Vector( ResizeType upResize,
		ResizeType downResize, int size )
{
	/* Set the step to the default before any autotmatic resizing
	 * is done. */
	this->step = DEFAULT_STEP;
	this->upResize = Expn;
	this->downResize = Expn;

	SetAs( 0, size );
}

/****************************************************************
 * Init Vector with size elements, allocLength space allocated.
 */
template<class T> Vector<T>::Vector( ResizeType upResize,
		ResizeType downResize, int size, int allocLength )
{
	/* Set the step to the default before any autotmatic resizing
	 * is done. */
	this->step = DEFAULT_STEP;
	this->upResize = Expn;
	this->downResize = Expn;

	/* Allocate the space if we are given a positive allocLength. */
	this->allocLength = allocLength;
	if ( allocLength > 0 ) {
		table = (T*) new char [sizeof(T) * allocLength];
		ASSERT( table != 0 );
	}

	/* Grow to the size specified. If we did not have enough space
	 * allocated that is ok. Table will be grown to right size. */
	SetAs( 0, size );
}

/****************************************************************
 * Init Vector with size elements, allocLength space allocated
 * and specified step for linear table allocation.
 */
template<class T> Vector<T>::Vector( ResizeType upResize,
		ResizeType downResize, int size, int allocLength, int step )
{
	/* Before we do any automatic resizing, init the step. */
	this->step = step;
	this->upResize = Expn;
	this->downResize = Expn;

	/* Allocate the space if we are given a positive allocLength. */
	this->allocLength = allocLength;
	if ( allocLength > 0 ) {
		table = (T*) new char [sizeof(T) * allocLength];
		ASSERT( table != 0 );
	}

	/* Grow to the size specified. If we did not have enough space
	 * allocated that is ok. Table will be grown to right size. */
	SetAs( 0, size );
}
#endif 

/****************************************
 * The copy constructor copies the contents of the the given
 * vector into this vector. Copy Constructors are in turn called on
 * all the items in the vector.
 */
template<class T> Vector<T>::
		Vector(const Vector<T> &v)
{
#if defined( LIN_UP ) || defined( LIN_DOWN ) || defined( VECTOR_RT )
	/* Set the step to the default before any autotmatic resizing
	 * is done. */
	step = v.step;
#endif
#if defined( VECTOR_RT )
	upResize = v.upResize;
	downResize = v.downResize;
#endif

	tableLength = v.tableLength;
	allocLength = v.allocLength;
	if ( allocLength > 0 )
	{
		table = (T*) new char[sizeof(T) * allocLength];
		T *dst = table, *src = v.table;
		for (int pos = 0; pos < tableLength;
				pos += 1, dst += 1, src += 1 )
			new(dst) T(*src);
	}
	else
		table = 0;
}

/****************************************
 * Calls the destructor on every item in the Vector, frees the
 * memory used and resets the contents to nil.
 */
template<class T> void Vector<T>::Empty()
{
	if (table) {
		/* Call All destructors. */
		T *pos = table;
		for ( int i = 0; i < tableLength; pos++, i++ )
			pos->~T();

		/* Free the table space. */
		delete[] (char*) table;
		table = 0;
		tableLength = allocLength = 0;
	}
}

/****************************************
 * Sets the contents of the vector to the contents of another vector.
 * that the ther vector does not equal this.
 */
template<class T> void Vector<T>::
		SetAs(const Vector<T> &v)
{
	ASSERT( &v != this );
	SetAs(v.table, v.tableLength);
}

/****************************************
 * Sets the contents of the vector to exactly what the parameters are.
 * If data is NIL, then default constructors are called on every item.
 */
template<class T> void Vector<T>::
		SetAs(const T *data, int len)
{
	/* Call All destructors. */
	T *pos = table;
	for ( int i = 0; i < tableLength; pos++, i++ )
		pos->~T();

	/* We are shrinking the buffer. */
	if ( len < tableLength ) {
		tableLength = len;	
		DownResize();
	}
	/* We are growing the buffer. */
	else if ( len > tableLength ) {
		UpResize(len);
		tableLength = len;
	}
	
	/* Copy data if it was supplied. */
	T *dst = table;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}
}

/****************************************
 * Overwrite a vector with another vector. Requires that the source
 * vector does not = this.
 */
template<class T> void Vector<T>::
		Overwrite(int pos, const Vector<T> &v)
{
	ASSERT(&v != this);
	Overwrite( pos, v.table, v.tableLength );
}

/****************************************
 * Overwrites with items in data at posion pos. Any items that are overwritten
 * have thier destructors called. If pos is off the end of the buffer then
 * new items are constructed.
 */
template<class T> void Vector<T>::
		Overwrite(int pos, const T *data, int len)
{
	int endPos, i;
	T *item;

	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the right end of
	 * the vector. */
	if (pos < 0)
		pos = tableLength + pos;

	/* The end is the one past the last item that we want
	 * to write to. */
	endPos = pos + len;

	/* Make sure we have enough space. */
	if ( endPos > tableLength )
		UpResize(endPos);

	/* Delete any objects we need to delete. */
	item = table + pos;
	for ( i = pos; i < tableLength && i < endPos; i += 1, item += 1 )
		item->~T();
		
	/* Init any default constructors we need to. */
	item = table + tableLength;
	for ( i = tableLength; i < pos; i += 1, item += 1 )
		new(item) T();

	/* Set the new tableLength. */
	tableLength = endPos;
	
	/* Copy data if it was supplied. */
	T *dst = table + pos;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}
}


/****************************************
 * Deletes len items at position pos. All items that are deleted have their
 * destructors called.
 */
template<class T> void Vector<T>::
		Delete(int pos, int len)
{
	int newLen, lenToSlideOver, endPos;
	T *dst, *item;

	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the right end of
	 * the vector. */
	if (pos < 0)
		pos = tableLength + pos;

	/* The first position after the last item deleted. */
	endPos = pos + len;

	/* The New table length. */
	newLen = tableLength - len;

	/* The place in the table we are deleting at. */
	dst = table + pos;

	/* Call Destructors. */
	item = dst;
	for ( int i = 0; i < len; i += 1, item += 1 )
		item->~T();
	
	/* Shift data over if necessary. */
	lenToSlideOver = tableLength - endPos;	
	if ( len > 0 && lenToSlideOver > 0 )
		memmove(dst, dst + len, sizeof(T)*lenToSlideOver);

	/* Set the new table length. */
	tableLength = newLen;

	/* Shrink the table if necessary. */
	DownResize( );
}

/****************************************
 * Insert another vector into this vector at pos pos.
 * Requires that we don't try to insert a vector into itself.
 */
template<class T> void Vector<T>::
		Insert(int pos, const Vector<T> &v)
{
	ASSERT(&v != this);
	Insert(pos, v.table, v.tableLength);
}

/****************************************
 * Insert len items into the buffer at position pos. If pos is off the end
 * new items are constructed. No items are destroyed. Any Data to the
 * right of pos is shifted over.
 */
template<class T> void Vector<T>::
		Insert(int pos, const T *data, int len)
{
	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the right end of
	 * the vector. */
	if (pos < 0)
		pos = tableLength + pos;
	
	int newLen = MakeRawSpaceFor(pos, len);

	/* Copy data if it was supplied. */
	T *dst = table + pos;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}

	/* Set the new tableLength. */
	tableLength = newLen;
}

/****************************************
 * Makes space for len items, Does not init the items in any way.
 * If pos is off the end then default constructors are called for
 * any any items that are included in the growth of the vector but
 * not in the subvector specified by pos, len.
 *
 * Returns the new tableLength but does NOT update it, This is
 * up to the caller!
 */
template<class T> int Vector<T>::
		MakeRawSpaceFor(int pos, int len)
{
	/* Ensure there is space in the buffer. */
	int newLen;
	if (pos >= tableLength)
		newLen = pos + len;
	else
		newLen = tableLength + len;
	UpResize( newLen );

	/* Init any default constructors we need to. */
	T *item = table + tableLength;
	for ( int i = tableLength; i < pos; i += 1, item += 1 )
		new(item) T();

	/* Shift Over Data at insert spot if needed. */
	if ( len > 0 && pos < tableLength ) {
		memmove(table + pos + len, table + pos,
			sizeof(T)*(tableLength-pos));
	}

	return newLen;
}

#if defined( EXPN_UP ) || defined( VECTOR_RT )
/************************************************************
 * Upresize for the exponential table. If there is not enough
 * space then allocates twice the needed amount.
 */
template<class T> void Vector<T>::ExpnUpResize(int len)
{
	/* If the Table is not big enough to fit len then upsize it. */
	if ( len > allocLength ) {
		/* Double the size n requested. */
		allocLength = len<<1;
		if ( table != 0 ) {
			/* Create the new table and copy the contents. */
			T *newTable = (T*) new char[sizeof(T)*allocLength];
			ASSERT( newTable != 0 );
			memcpy(newTable, table, sizeof(T)*tableLength);

			/* Delete the old table and make the new table the cur table. */
			delete[] (char*) table;
			table = newTable;
		}
		else {
			/* Create the table. */
			table = (T*) new char[sizeof(T)*allocLength];
			ASSERT( table != 0 );
		}
	}
}
#endif /* EXPN_UP */


#if defined( EXPN_DOWN ) || defined( VECTOR_RT )
/**********************************************************************
 * Shrinking for exponential table. When there is more than 4 times the
 * needed space the vector is shrunk to twice the needed space. The
 * 2 times on the up and 4 times on the down ensures that successive
 * inserts and removes of a small amount of elements will not cause
 * successive reallocations.
 */
template<class T> void Vector<T>::ExpnDownResize()
{
	/* Down resize if we are using less than a quarter
	 * of the space allocated. */
	if ( tableLength < (allocLength>>2) ) {
		if ( tableLength == 0 ) {
			/* Empty the table. */
			allocLength = 0;
			delete[] (char*) table;
			table = 0;
		}
		else {
			/* The new allocated length is twice that wanted. */
			allocLength = tableLength<<1;

			/* Create a new table. */
			T *newTable = (T*) new char[sizeof(T)*allocLength];
			ASSERT( newTable != 0 );
			memcpy(newTable, table, sizeof(T)*tableLength);

			/* Delete the old table and make the new table the cur table. */
			delete[] (char*) table;
			table = newTable;
		}
	}
}
#endif /* EXPN_DOWN */

#if defined( LIN_UP ) || defined( VECTOR_RT )
/****************************************************************
 * Growning for linear table.
 */
template<class T> void Vector<T>::LinUpResize(int len)
{
	/* If the table is not big enough to fit len, then resize. */
	if ( len > allocLength ) {
		/* The new allocated length is len plus the step. */
		allocLength = len + step;
		if ( table != 0 ) {
			/* Create the new table and copy the contents. */
			T *newTable = (T*) new char[sizeof(T)*allocLength];
			ASSERT( newTable != 0 );
			memcpy(newTable, table, sizeof(T)*tableLength);

			/* Delete the old table and make the new table the cur table. */
			delete[] (char*) table;
			table = newTable;
		}
		else {
			/* Create the table. */
			table = (T*) new char[sizeof(T)*allocLength];
			ASSERT( table != 0 );
		}
	}
}
#endif /* LIN_UP */


#if defined( LIN_DOWN ) || defined( VECTOR_RT )
/****************************************************************
 * Shrinking for linear table.
 */
template<class T> void Vector<T>::LinDownResize()
{
	if ( tableLength < allocLength-(step<<1) ) {
		if ( tableLength == 0 ) {
			/* The new allocated length. */
			allocLength = 0;
			/* Just delete the table. */
			delete[] (char*) table;
			table = 0;
		}
		else {
			/* The new allocated length is what we need plus step. */
			allocLength = tableLength + step;
	
			/* Create the new table and copy the contents. */
			T *newTable = (T*) new char[sizeof(T)*allocLength];
			ASSERT( newTable != 0 );
			memcpy(newTable, table, sizeof(T)*tableLength);
		
			/* Delete the old table and make the new table the cur table. */
			delete[] (char*) table;
			table = newTable;
		}
	}
}
#endif /* LIN_DOWN */


#if defined( CONST_UP ) || defined( VECTOR_RT )
/****************************************************************
 * Growing for constant table. Const table is allocated once
 * in its constructor and never grown again so there is nothing
 * to do.
 */
template<class T> void Vector<T>::ConstUpResize(int len) 
{
	ASSERT( len <= allocLength );
}
#endif /* CONST_UP */

#if defined( CONST_DOWN ) || defined( VECTOR_RT )
/****************************************************************
 * Shrinking for constant table. Const table is allocated once
 * in its constructor and never shrunk again so there is nothing
 * to do.
 */
template<class T> void Vector<T>::ConstDownResize()
{
	ASSERT( tableLength <= allocLength );
}
#endif

#if defined( VECTOR_RT )
/****************************************************************
 * Runtime Growing. Switch on the current scheme.
 */
template<class T> void Vector<T>::RTUpResize(int len)
{
	switch ( upResize ) {
		case Expn:
			ExpnUpResize(len);
			break;
		case Linear:
			LinUpResize(len);
			break;
		case Const:
			ConstUpResize(len);
			break;
	}
}

/****************************************************************
 * Runtime Shrinking. Switch on the current scheme.
 */
template<class T> void Vector<T>::RTDownResize()
{
	switch ( downResize ) {
		case Expn:
			ExpnDownResize();
			break;
		case Linear:
			LinDownResize();
			break;
		case Const:
			ConstDownResize();
			break;
	}
}
#endif

#undef Vector
#undef EXPN_UP
#undef EXPN_DOWN
#undef LIN_UP
#undef LIN_DOWN
#undef CONST_UP
#undef CONST_DOWN
#undef UpResize
#undef DownResize
#undef DEFAULT_STEP

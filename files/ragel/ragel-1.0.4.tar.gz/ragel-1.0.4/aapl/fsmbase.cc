/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMBASE_CC
#define _AAPL_FSMBASE_CC

#include <string.h>

#if defined( AAPL_NOBASEREF )
#	define BASEREF(name) name
#else
#	define BASEREF(name) ListEl::name
#endif


/****************************************
 * MarkIndexTmpl Constructor
 */
template < class State > MarkIndexTmpl<State>::
		MarkIndexTmpl( int states ) : numStates(states)
{
	/* Total pairs is states^2. Actually only use half of these. */
	int total = states * states;

	/* New up chars so that individual DListEl constructors are
	 * not called. Zero out the mem manually. */
	array = (StatePair*) new char[sizeof(StatePair) * total];
	memset( array, 0, sizeof(StatePair) * total );
}

/****************************************
 * MarkIndexTmpl Destructor
 */
template < class State >MarkIndexTmpl<State>::~MarkIndexTmpl()
{
	delete[] (char*) array;
}

/****************************************
 * MarkIndexTmpl::MarkPair
 */
template < class State > void MarkIndexTmpl<State>::
		MarkPair(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	ASSERT( ! array[pos].isMarked );
	array[pos].isMarked = true;
	markedList.AddEnd( unmarkedList.DetachElement( &array[pos] ) );
}

/****************************************
 * MarkIndexTmpl::IsPairMarked
 */
template < class State > bool MarkIndexTmpl<State>::
		IsPairMarked(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	return array[pos].isMarked;
}

/****************************************
 * MarkIndexTmpl::GetPair
 */
template < class State > MarkIndexTmpl<State>::StatePair *MarkIndexTmpl<State>::
		GetPair(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	return array + pos;
}


/****************************************
 * FsmState Constructor
 */
template< class State, class TransFunc, class Transition >
		FsmState<State, TransFunc, Transition>::FsmState() :
		outList(), inList(),
		outTransFuncTable()
{
	/* General State data. */
	num = 0;
	stateMap = 0;

	/* No out priority by default. */
	isOutPriorSet = false;
	outPriority = 0;

	/* Fsm State data. */
	isFinState = false;
	isMarked = false;
	stateBits = 0;
	stateDictNode = 0;
}

/****************************************
 * FsmState Copy Constructor 
 */
template< class State, class TransFunc, class Transition >
		FsmState<State, TransFunc, Transition>::
		FsmState(FsmState &other) :
		outList(other.outList), inList(other.inList),
		outTransFuncTable(other.outTransFuncTable)
		
{
	/* This Copy Constructor relies on the FsmGraph copy constructor. */

	/* General State data. */
	num = other.num;
	stateMap = 0;

	/* Get the out priority stuff. */
	isOutPriorSet = other.isOutPriorSet;
	outPriority = other.outPriority;

	/* Fsm State data. */
	isFinState = other.isFinState;
	isMarked = other.isMarked;
	stateBits = other.stateBits;
	stateDictNode = other.stateDictNode;

	/* Zero out the in transition list. */
	TransEl *tel = inList.table;
	int ntel = inList.tableLength;
	for ( int i = 0; i < ntel; i++, tel++ )
		tel->value = 0;
}

/****************************************
 * FsmState Destructor
 */
template< class State, class TransFunc, class Transition >
		FsmState<State, TransFunc, Transition>::
		~FsmState()
{
	if ( stateDictNode != 0 )
		delete stateDictNode;
}

/**************************************************************************
 * FsmState::CompareOutTrans
 */
template< class State, class TransFunc, class Transition >
		int FsmState<State, TransFunc, Transition>::
		CompareOutTrans( const FsmState &state1, const FsmState &state2 )
{
	/* If only one out priority is set then differ. */
	if ( state1.isOutPriorSet && !state2.isOutPriorSet )
		return -1;
	else if ( !state1.isOutPriorSet && state2.isOutPriorSet )
		return 1;
	else if ( state1.isOutPriorSet && state2.isOutPriorSet ) {
		/* Both priorities set, compare the priorites. */
		int outPriorCmp = OrdCmp<int>::Compare(
				state1.outPriority, state2.outPriority );
		if ( outPriorCmp != 0 )
			return outPriorCmp;
	}

	/* Test outTransFuncTable. */
	int outTransCmp = Transition::CompareFuncs(
			state1.outTransFuncTable, state2.outTransFuncTable);
	if ( outTransCmp != 0 )
		return outTransCmp;

	return 0;
}

/**************************************************************************
 * FsmState::Compare
 *
 * Compare two pointers to states (actually compares the states they point to).
 * Compare States according to:
 *  Final state status
 *  OutTransitions
 *  Length of lists.
 *    Do any onChar values differ
 *    Do any of the targeted states differ.
 *    Do any of the transitions differ.
 */
template< class State, class TransFunc, class Transition >
		int FsmState<State, TransFunc, Transition>::
		Compare( const PState state1 , const PState state2 )
{
	/* Test final state status. */
	if ( state1->isFinState != state2->isFinState ) {
		if (state1->isFinState)
			return -1;
		else
			return 1;
	}
	
	/* Compare the out transitions. */
	int outTransCmp = CompareOutTrans( *state1, *state2 );
	if ( outTransCmp )
		return outTransCmp;

	/* Test transition table length. */
	if ( state1->outList.tableLength != state2->outList.tableLength ) {
		if ( state1->outList.tableLength < state2->outList.tableLength )
			return -1;
		else
			return 1;
	}

	/* Walk the lists, testing onChars, targets, and transitions. */
	TransEl *el1 = state1->outList.table;
	TransEl *el2 = state2->outList.table;
	int nel = state1->outList.tableLength;
	for ( int i = 0; i < nel; i++, el1++, el2++ ) {
		/* Test onChar. */
		if ( el1->key != el2->key ) {
			if ( el1->key < el2->key )
				return -1;
			else
				return 1;
		}

		/* Get transitions. */
		Transition *trans1 = el1->value;
		Transition *trans2 = el2->value;

		/* Test targets. */
		if ( trans1->toState != trans2->toState ) {
			if ( trans1->toState < trans2->toState )
				return -1;
			else
				return 1;
		}

		/* Test transitions. */
		int funcCmp = Transition::Compare( *trans1, *trans2 );
		if ( funcCmp != 0 )
			return funcCmp;
	}

	/* Got through the entire state comparison, deem them equal. */
	return 0;
}

template< class State, class TransFunc, class Transition >
		void FsmState<State, TransFunc, Transition>::
		SetOutFunctions( TransFuncTable &funcTable )
{
	TransFuncEl *tfel = funcTable.table;
	int ntfel = funcTable.tableLength;
	for ( int i = 0; i < ntfel; i++, tfel++ )
		outTransFuncTable.InsertMulti( tfel->key, tfel->value );
}

/****************************************
 * FsmGraph Copy Constructor
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>::
		FsmGraph(FsmGraph &graph) :
		StartState(0), FinStateSet()
{
	/* Create the states and record their map in the original state. */
	State *origState = graph.head;
	while ( origState != 0 ) {
		/* Make the new state. */
		State *newState = new State(*origState);

		/* Add the state to the  */
		StateList::AddEnd( newState );

		/* Set the mapsTo item of the old state. */
		origState->stateMap = newState;

		/* next state. */
		origState = origState->BASEREF(next);
	}
	
	/* Derefernce all the state maps. */
	State *state = head;
	while ( state != 0 ) {
		/* Walk the list of out transitions setting and attch transitions
		 * to their corresponding new states. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++ ) {
			/* Get the trans and the to state. */
			Transition *trans = tel->value;
			State *to = trans->toState->stateMap;

			/* Make a copy of the transition. */
			trans = new Transition(*trans);
			tel->value = trans;

			/* This is to simulate a real attaching. */
			trans->fromState = 0;
			trans->toState = 0;
			AttachStates( state, to, trans, tel->key );
		}
		state = state->BASEREF(next);
	}

	/* Fix the start state. */
	StartState = graph.StartState->stateMap;
	
	/* Build the final state set. */
	State **st = graph.FinStateSet.table;
	int nst = graph.FinStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ )
		FinStateSet.Set((*st)->stateMap);
}

/****************************************
 * FsmGraph Destructor
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>::
		~FsmGraph()
{
	/* Delete all the transitions. */
	State *state = head;
	while ( state != NULL ) {
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for ( int i = 0; i < ntel; i++, tel++ )
			delete tel->value;
		state = state->BASEREF(next);
	}

	/* Delete all the states. */
	StateList::DeleteElements();
}

template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		AttachStates( State *from, State *to, int onChar )
{
	/* Make the transition if it is not there. */
	typename State::TransEl *lastFound;
	if ( from->outList.Insert( onChar, &lastFound ) )
		lastFound->value = new Transition();

	/* Get the transition. Maybe we just made one, maybe it was already there. 
	 * If it was already there we will fail on an assert in AttachStates. */
	Transition *trans = lastFound->value;

	AttachStates( from, to, trans, onChar );
	return trans;
};


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AttachStates( State *from, State *to, Transition *trans, int onChar )
{
	/* Get the transition and ensure it is unused. */
	ASSERT( trans->toState == NULL );
	ASSERT( trans->fromState == NULL );

	/* Create a new in trans pointer if it is not there. */
	TransEl *lastFound;
	to->inList.Insert( onChar, 0, &lastFound );

	/* Get the pointer on the in transition side. */
	Transition *&inTransPtr = lastFound->value;

	/* Set the data of the transtion. */
	trans->fromState = from;
	trans->toState = to;

	trans->next = inTransPtr;
	trans->prev = 0;

	/* If in trans list is not empty, set the head->prev to trans. */
	if ( inTransPtr )
		inTransPtr->prev = trans;

	/* Now insert ourselves at the front of the list. */
	inTransPtr = trans;
};

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		DetachStates(State *from, State *to, Transition *trans, int onChar)
{
	/* Ensure they are hooked up. */
	ASSERT( trans->toState == to );

	/* Get a reference to the head pointer of the inList list for onChar. */
	TransEl *tel = to->inList.Find( onChar );
	ASSERT( tel != NULL );
	Transition *&inTransPtr = tel->value;

	/* Detach in the inTransList. */
	if (trans->prev == 0) 
		inTransPtr = trans->next; 
	else
		trans->prev->next = trans->next; 

	if (trans->next != 0) 
		trans->next->prev = trans->prev; 
	
	trans->fromState = 0;
	trans->toState = 0;
}

template < class State, class TransFunc, class Transition >
		State *FsmGraph<State, TransFunc, Transition>::
		DetachState( State *state )
{
	/* Detach the in Transitions. */
	TransEl *tel = state->inList.table;
	int i, ntel = state->inList.tableLength;
	for ( i = 0; i < ntel; i++, tel++ ) {
		while ( tel->value ) {
			/* Get pointers to the trans and the stae. */
			Transition *trans = tel->value;
			State *fromState = trans->fromState;
			/* Detach. */
			DetachStates( fromState, state, trans, tel->key );
			/* Delete the allocation of the transition in from->outList. */
			fromState->outList.Remove( tel->key );
			delete trans;
		}
	}

	/* Detach the out transitions. */
	tel = state->outList.table;
	ntel = state->outList.tableLength;
	for ( i = 0; i < ntel; i++, tel++ ) {
		DetachStates( state, tel->value->toState, tel->value, tel->key );
		delete tel->value;
	}

	/* Delete all of the out transition elements. */
	state->outList.Empty();

	/* Unset final stateness before detaching from graph. */
	if ( state->isFinState )
		FinStateSet.UnSet( state );

	DetachElement( state );
	return state;
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		SetFinState(State *state)
{
	/* Is it already a fin state. */
	if (state->isFinState)
		return;
	
	state->isFinState = true;
	FinStateSet.Set( state );
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		UnsetFinState(State *state)
{
	/* Is it already a fin state. */
	if (! state->isFinState)
		return;

	state->isFinState = false;
	FinStateSet.UnSet( state );
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AllTransPrior( int prior )
{
	State *state = head;
	while ( state != NULL ) {
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++)
			tel->value->priority = prior;

		state = state->BASEREF(next);
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FinFsmPrior( int prior )
{
	State **st = FinStateSet.table;
	int nst = FinStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		State *targ = *st;
		TransEl *tel = targ->inList.table;
		int ntel = targ->inList.tableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->value;
			while ( trans != 0 ) {
				trans->priority = prior;
				trans = trans->next;
			}
		}
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		LeaveFsmPrior( int prior )
{
	State **st = FinStateSet.table;
	int nst = FinStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = true;
		(*st)->outPriority = prior;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearLeaveFsmPrior( )
{
	State **st = FinStateSet.table;
	int nst = FinStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = false;
		(*st)->outPriority = 0;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		BaseStartFsmPrior( int prior )
{
	State *state = StartState;
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;
	for (int i = 0; i < ntel; i++, tel++)
		tel->value->priority = prior;

	state = state->BASEREF(next);
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AllTransFunc( TransFunc func, int transOrder )
{
	State *state = head;
	while ( state != NULL ) {
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++)
			tel->value->SetFunction( func, transOrder );

		state = state->BASEREF(next);
	}
}

/*******************************************************************
 * NullFunctionKeys
 *
 * Zeros out the function ordering keys. This may be called before condensing
 * when it is known that no more fsm operations are going to be done.
 * This will achieve greater condensing as states will not be separated
 * the the basis of function ordering.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		NullFunctionKeys( )
{
	State *state = head;
	while ( state != NULL ) {
		/* Walk the transitions for the state. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for ( int i = 0; i < ntel; i++, tel++ ) {
			/* Walk the function table for the transition. */
			typename Transition::TransFuncEl *tfel =
					tel->value->transFuncTable.table;
			int ntfel = tel->value->transFuncTable.tableLength;
			for ( int j = 0; j < ntfel; j++, tfel++ )
				tfel->key = 0;
		}
		state = state->BASEREF(next);
	}
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FinFsmFunc( TransFunc func, int transOrder )
{
	State **st = FinStateSet.table;
	int nst = FinStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		State *targ = *st;
		/* FIXME: if the start state is final then it gets a fin func. */
		TransEl *tel = targ->inList.table;
		int ntel = targ->inList.tableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->value;
			while ( trans != 0 ) {
				trans->SetFunction( func, transOrder );
				trans = trans->next;
			}
		}
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		LeaveFsmFunc( TransFunc func, int transOrder )
{
	State **st = FinStateSet.table;
	int nst = FinStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		(*st)->outTransFuncTable.InsertMulti( transOrder, func );
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		BaseStartFsmFunc( TransFunc func, int transOrder )
{
	State *state = StartState;
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;
	for (int i = 0; i < ntel; i++, tel++)
		tel->value->SetFunction( func, transOrder );

	state = state->BASEREF(next);
}

template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		ShiftStartFuncOrder( int fromOrder )
{
	int maxUsed = 0;
	/* Walk the transition list of the start state. */
	TransEl *tel = StartState->outList.table;
	int ntel = StartState->outList.tableLength;
	for ( int i = 0; i < ntel; i++, tel++ ) {
		/* Walk the function table for the transition. */
		typename Transition::TransFuncEl *tfel =
				tel->value->transFuncTable.table;

		/* Set the keys to increasing values starting at fromOrder */
		int ntfel = tel->value->transFuncTable.tableLength;
		int curFromOrder = fromOrder;
		for ( int j = 0; j < ntfel; j++, tfel++ )
			tfel->key = curFromOrder++;
	
		/* Keep track of the max number of orders used so 
		 * we can return the max. */
		if ( curFromOrder - fromOrder > maxUsed )
			maxUsed = curFromOrder - fromOrder;
	}
	return maxUsed;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::StripAllTransData()
{
	State *state = head;
	while ( state ) {
		state->outTransFuncTable.Empty();
		state->isOutPriorSet = false;
		state->outPriority = 0;

		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++) {
			tel->value->transFuncTable.Empty();
			tel->value->priority = 0;
		}

		state = state->BASEREF(next);
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearAllTransFunc()
{
	State *state = head;
	while ( state != NULL ) {
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++)
			tel->value->transFuncTable.Empty();

		state = state->BASEREF(next);
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearFinFsmFunc()
{
	State **st = FinStateSet.table;
	int nst = FinStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		State *targ = *st;
		/* FIXME: if the start state is final then it gets a fin func. */
		TransEl *tel = targ->inList.table;
		int ntel = targ->inList.tableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->value;
			while ( trans != 0 ) {
				trans->transFuncTable.Empty();
				trans = trans->next;
			}
		}
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearLeaveFsmFunc()
{
	State **st = FinStateSet.table;
	int nst = FinStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		(*st)->outTransFuncTable.Empty();
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearStartFsmFunc()
{
	/* FIXME: Implement. */
}

/****************************************************************************
 * FsmAttachStates
 *
 * Attach states according to the rules of an fsm. Requires that srcTrans is
 * not a transition in State from.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FsmAttachStates( MergeData &md, State *from, State *to, 
			int onChar, Transition *srcTrans, bool leavingFsm )
{
	int newTransPrior = srcTrans->priority;
	if ( leavingFsm && from->isOutPriorSet )
		newTransPrior = from->outPriority;

	/* Possibly make a new transition. */
	TransEl *lastFound;
	if ( from->outList.Insert( onChar, &lastFound ) ) {
		/* Make a new transition. */
		lastFound->value = new Transition();
		Transition *trans = lastFound->value;

		/* We can attach the transition, one does not exist. */
		AttachStates( from, to, trans, onChar );
		
		/* Flag the targ as getting a new in transition. */
		to->stateBits |= SB_NEWINTRANS;

		/* Copy the transition data from the source transition. */
		trans->priority = newTransPrior;
		trans->transFuncTable.SetAs( srcTrans->transFuncTable );

		/* Call user routine for merging transitions. */
		trans->MergeTransition(srcTrans);

		/* Now that the transition has been properly set up, we can add any out
		 * transition data if necessary. */
		if ( leavingFsm ) {
			/* Get the data from the outTransFuncTable. */
			trans->SetFunctions( from->outTransFuncTable );
		}
	}
	else {
		/* There is a trans already. Get it. */
		Transition *trans = lastFound->value;

		if ( trans->priority > newTransPrior ) {
			/* The existing trans has a higher priority. We do nothing. No new transition
			 * is made. Nothing is done. */
		}
		else if ( trans->priority < newTransPrior ) {
			/* Toast the existing transition. */
			DetachStates( from, trans->toState, trans, onChar );

			/* Delete the existing transition, it is being replaced and 
			 * make a brand new one to replace it. This is for completeness 
			 * of concept. */
			delete trans;
			lastFound->value = trans = new Transition();

			/* We can attach the transition, one does not exist. */
			AttachStates( from, to, trans, onChar );

			/* Flag the targ as getting a new in transition. */
			to->stateBits |= SB_NEWINTRANS;

			/* Copy the transition data from the source transition. */
			trans->priority = newTransPrior;
			trans->transFuncTable.SetAs( srcTrans->transFuncTable );

			/* Trans is a merge with srcTrans. */
			trans->MergeTransition(srcTrans);

			/* Now that the transition has been properly set up, we can add any out
			 * transition data if necessary. */
			if ( leavingFsm ) {
				/* Get the data from the outTransFuncTable. */
				trans->SetFunctions( from->outTransFuncTable );
			}
		}
		else {
			/* The priorities are equal. We must merge the transitions.
			 * Does the existing trans go to the trans we are to attach to?
			 * ie, are we to simply double up the transition? */
			State *existingState = trans->toState;
		
			if ( existingState == to ) {
				/* Copy the transition data from the source transition. */
				if ( trans == srcTrans ) {
					typename Transition::TransFuncTable
								srcTable( srcTrans->transFuncTable );
					trans->SetFunctions( srcTable );
				}
				else
					trans->SetFunctions( srcTrans->transFuncTable );

				/* Call user routine for merging transitions. */
				trans->MergeTransition(srcTrans);
			}
			else {
				/* The trans is not a double up. trans cannot be the same as srcTrans
				 * Set up the state set. */
				StateSet stateSet;
				/* We go to all the states the existing trans goes to, plus... */
				if ( existingState->stateDictNode == NULL )
					stateSet.Set( existingState );
				else
					stateSet.Set( existingState->stateDictNode->stateSet );
				/* ... all the states that we have been told to go to. */
				if ( to->stateDictNode == NULL )
					stateSet.Set( to );
				else
					stateSet.Set( to->stateDictNode->stateSet );

				/* Look for the state. If it is not there already, make it. */
				FsmSDNode<State> *lastFound;
				if ( md.stateDict.Insert( stateSet, &lastFound ) ) {
					/* Make a new State, but it doesn't get added to the list. 
					 * Instead, add it to the stfil list. This means that we
					 * need to fill in it's transitions sometime in the future.
					 * We don't do that now (ie, do not recurse). */
					State *newState = new State();

					/* Link up the dict node and the state. */
					lastFound->targState = newState;
					newState->stateDictNode = lastFound;

					/* Add to the stfil list. */
					md.stfil.AddEnd( newState );
				}

				/* Get the state insertted/deleted. */
				State *targ = lastFound->targState;

				/* Detach the state from existing state. */
				DetachStates( from, existingState, trans, onChar );

				/* Reattach to the new target. */
				AttachStates( from, targ, trans, onChar );

				/* Flag the targ as getting a new in transition. */
				targ->stateBits |= SB_NEWINTRANS;

				/* Copy the transition data from the source transition. */
				trans->SetFunctions( srcTrans->transFuncTable );

				/* Call user routine for merging transitions. */
				trans->MergeTransition(srcTrans);
			}

			/* Now that the transition has been properly set up, we can add any out
			 * transition data if necessary. */
			if ( leavingFsm ) {
				/* Get the data from the outTransFuncTable. */
				trans->SetFunctions( from->outTransFuncTable );
			}
		}
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		OutTransCopy( MergeData &md, State *dest, State *src, bool leavingFsm )
{
	/* If src == dest we will be modifying a out trans list we are reading
	 * from. Make a copy first. */
	if ( src == dest ) {
		TransListType listCopy(src->outList);
		OutTransCopy( md, dest, listCopy, leavingFsm);
	}
	else {
		OutTransCopy( md, dest, src->outList, leavingFsm );
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		OutTransCopy( MergeData &md, State *dest, TransListType &srcList, 
				bool leavingFsm )
{
	/* Iterate over the trans, copying them. */
	TransEl *tel = srcList.table;
	int ntel = srcList.tableLength;
	for (int i = 0; i < ntel; i++, tel++) {
		Transition *trans = tel->value;
		FsmAttachStates( md, dest, trans->toState, tel->key, trans, leavingFsm );
	}
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		InTransMove(State *dest, State *src)
{
	/* Do not try to move in trans to and from the same state. */
	ASSERT( dest != src );

	TransEl *tel = src->inList.table;
	int ntel = src->inList.tableLength;
	for ( int i = 0; i < ntel; i++, tel++ ) {
		while ( tel->value != NULL ) {
			Transition *trans = tel->value;
			State *fromState = trans->fromState;
			DetachStates( fromState, src, trans, tel->key );
			AttachStates( fromState, dest, trans, tel->key );
		}
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkPairsOnIn( MarkIndex &markIndex, State *r, State *s )
{
	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->inList.table;
	TransEl *rEndTransEl = rTransEl + r->inList.tableLength;
	TransEl *sTransEl = s->inList.table;
	TransEl *sEndTransEl = sTransEl + s->inList.tableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( rTransEl != rEndTransEl && sTransEl != sEndTransEl ) {
		/* Both rPos and sPos are good. Get the characters of the
		 * transitions. */
		rItem = rTransEl->key;
		sItem = sTransEl->key;
		if ( rItem < sItem ) {
			/* transitions don't match up. Move ahead in rTransEl. */
			rTransEl++;
		}
		else if ( sItem < rItem ) {
			/* Transitions don't match up. Move ahead in sTransEl. */
			sTransEl++;
		}
		else {
			/* This will stop us from unneccessary looping if r has lots of trans on
			 * this char and s has none. */
			if ( rTransEl->value != NULL && sTransEl->value != NULL ) {
				/* Loop over r's transitions on this char. */
				Transition *rTrans = rTransEl->value;
				while ( rTrans != NULL ) {
					State *p = rTrans->fromState;

					/* Loop over s's transitions on this char. */
					Transition *sTrans = sTransEl->value;
					while ( sTrans != NULL ) {
						State *q = sTrans->fromState;

						/* If the states are different and not already marked. Then mark. */
						if ( p != q && ! markIndex.IsPairMarked(p->num, q->num) )
							markIndex.MarkPair(p->num, q->num);
				
						sTrans = sTrans->next;
					}
					rTrans = rTrans->next;
				}
			}
			rTransEl++;
			sTransEl++; 
		}
	}
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		ShouldMarkPair(MarkIndex &markIndex, State *r, State *s)
{
	bool shouldMarkPair = false;

	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->outList.table;
	TransEl *rEndTransEl = rTransEl + r->outList.tableLength;
	TransEl *sTransEl = s->outList.table;
	TransEl *sEndTransEl = sTransEl + s->outList.tableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( !shouldMarkPair ) {
		/* Are we at the end of r's transitions? */
		if ( rTransEl == rEndTransEl ) {
			/* We are at the end of r's transitions. If we are not at the
			 * end of s's transitions as well then mark. */
			if  ( sTransEl != sEndTransEl )
				shouldMarkPair = true;
			break;
		}
		/* Are we at the end of s's transitions? */
		else if ( sTransEl == sEndTransEl ) {
			/* We are not at the end of r's but at the end of
			 * s's transitions. */
			shouldMarkPair = true;
		}
		else {
			/* Both rPos and sPos are good. Get the characters of the
			 * transitions. */
			rItem = rTransEl->key;
			sItem = sTransEl->key;
			if ( rItem < sItem ) {
				/* Transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else if ( sItem < rItem ) {
				/* Transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else {
				if ( markIndex.IsPairMarked( rTransEl->value->toState->num,
							sTransEl->value->toState->num ) )
					shouldMarkPair = true;

				rTransEl++;
				sTransEl++; 
			}
		}
	}
	return shouldMarkPair;
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		ShouldMarkPairTransData(MarkIndex &markIndex, State *r, State *s)
{
	bool shouldMarkPair = false;

	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->outList.table;
	TransEl *rEndTransEl = rTransEl + r->outList.tableLength;
	TransEl *sTransEl = s->outList.table;
	TransEl *sEndTransEl = sTransEl + s->outList.tableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( !shouldMarkPair ) {
		/* Are we at the end of r's transitions? */
		if ( rTransEl == rEndTransEl ) {
			/* We are at the end of r's transitions. If we are not at the
			 * end of s's transitions as well then mark. */
			if ( sTransEl != sEndTransEl )
				shouldMarkPair = true;
			break;
		}
		/* Are we at the end of s's transitions? */
		else if ( sTransEl == sEndTransEl ) {
			/* We are not at the end of r's but at the end of
			 * s's transitions. */
			shouldMarkPair = true;
		}
		else {
			/* Both rPos and sPos are good. Get the characters of the
			 * transitions. */
			rItem = rTransEl->key;
			sItem = sTransEl->key;
			if ( rItem < sItem ) {
				/* transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else if ( sItem < rItem ) {
				/* Transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else {
				if ( markIndex.IsPairMarked( rTransEl->value->toState->num,
							sTransEl->value->toState->num ) )
					shouldMarkPair = true;
				else if ( Transition::Compare(*(rTransEl->value), *(sTransEl->value)) != 0 )
					shouldMarkPair = true;

				rTransEl++;
				sTransEl++; 
			}
		}
	}
	return shouldMarkPair;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkReachableFromHereReverse( State *state )
{
	/* Base case: return; */
	if (state->isMarked) return;
	
	/* Set this state as marked. */
	state->isMarked = true;

	/* Recurse on all items in outlist. */
	TransEl *tel = state->inList.table;
	int ntel = state->inList.tableLength;
	for (int i = 0; i < ntel; i++, tel++) {
		Transition *trans = tel->value;
		while ( trans ) {
			MarkReachableFromHereReverse( trans->fromState );
			trans = trans->next;
		}
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkReachableFromHere( State *state )
{
	/* Base case: return; */
	if (state->isMarked) return;
	
	/* Set this state as marked. */
	state->isMarked = true;

	/* Recurse on all items in outlist. */
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;
	for (int i = 0; i < ntel; i++, tel++)
		MarkReachableFromHere( tel->value->toState );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		UnmarkReachableFromHere( State *state )
{
	/* Base case: return; */
	if (!state->isMarked) return;
	
	/* Set this state as marked. */
	state->isMarked = false;

	/* Recurse on all items in outlist. */
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;
	for (int i = 0; i < ntel; i++, tel++)
		UnmarkReachableFromHere( tel->value->toState );
}

/*************************************************************************
 * BuildFsmMachine
 *
 * Construct a compact runnable machine from this graph. Machine is put in
 * the machine object passed in.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		BuildFsmMachine( FsmMachine<TransFunc> &machine )
{
	/* Create the machine states. */
	InitMachineStates( machine );

	/* The data we need around to make machine states from graph states.
	 * Gives us the transition map, the running offset of transition ids,
	 * the function map and the running offset of function ids. */
	MakeMachData mmd;
	mmd.curTransOffset = 0;
	mmd.curFuncOffset = 0;

	/* Make the global error transition. The rest of the fsm building code works on
	 * the assumption that the error trans is index 0. */
	FsmMachTrans<TransFunc> errTrans;
	errTrans.toState = 0;
	errTrans.funcs = TRANS_NO_FUNCS;
	mmd.transMap.Insert( errTrans, mmd.curTransOffset );
	mmd.curTransOffset++;

	State *state = head;
	while ( state != 0 ) {

		/* Get the fsm state. */
		FsmMachState<TransFunc> *machState =
				(FsmMachState<TransFunc>*) state->stateMap;

		/* Use the base class to make the machine state. This call will modify
		 * funcListMap, curFuncOffset, and transMap. */
		MakeMachineState( mmd, machState, state );

		/* Add the functions in the outFuncs for this state to the funcs map. */
		machState->outFuncs = TRANS_NO_FUNCS;
		int tlen = state->outTransFuncTable.tableLength;
		if ( tlen != 0 ) {
			/* Make a new trans func list from the trans func table (we don't
			 * care about the ordering numbers on the transitions so we make 
			 * a list without the ordering). */
			typename Transition::TransFuncList transFuncList;
			Transition::FuncTableToFuncList( transFuncList, state->outTransFuncTable );

			/* If not in the function list map then insert. */
			FuncListMapEl *lastFound;
			if ( mmd.funcListMap.Insert( transFuncList, mmd.curFuncOffset, &lastFound ) )
					mmd.curFuncOffset += ( tlen + 1 );

			/* Get the offset as what was found/inserted in the map. */
			machState->outFuncs = (TransFunc*) lastFound->value;
		}

		state = state->BASEREF(next);
	}

	/* Save the items in the transMap to trans */
	FsmMachTrans<TransFunc> *trans = 0;
	if ( mmd.transMap.tableLength > 0 ) {
		/* New up the Transition table. */
		trans = new FsmMachTrans<TransFunc>[mmd.curTransOffset];

		/* Walk the transMap and copy to the transitions. The location of the
		 * transition must be the offsets in the value field because that is
		 * what the index array uses. */
		TransMapEl *tmel = mmd.transMap.table;
		int tmlen = mmd.transMap.tableLength;
		for ( int i = 0; i < tmlen; i++, tmel++ )
			trans[tmel->value] = tmel->key;
	}

	/* Set the transitions pointer and the number of transitions. */
	machine.allTrans = trans;
	machine.numTrans = mmd.curTransOffset;

	/* Walk all transIndex arrays and replace the indicies with ptrs. */
	int i;
	FsmMachState<TransFunc> *st = machine.allStates;
	for ( i = 0; i < machine.numStates; i++, st++ ) {
		/* Replace the index for the error transition. */
		int index = (int) st->errIndex;
		st->errIndex = trans + index;

		/* Replace the index for array of indicies. */
		FsmMachTrans<TransFunc> **pIndex = st->transIndex;
		for ( int j = 0; j < st->numIndex; j++, pIndex++ ) {
			index = (int) *pIndex;
			*pIndex = trans + index;
		}
	}

	/* If there are any function lists in the function map then we need to copy
	 * them to the new machine. */
	TransFunc *transFuncs = 0;
	if ( mmd.curFuncOffset != 0 ) {
		/* There was space used. New up the funclist array and then fill it in. */
		transFuncs = new TransFunc[mmd.curFuncOffset];

		/* For each funclist in the funclist map, copy the list over. */
		FuncListMapEl *flel = mmd.funcListMap.table;
		int nflel = mmd.funcListMap.tableLength;
		for ( int i = 0; i < nflel; i++, flel++ ) {
			/* Get a ref to the trans func list and it's offset. */
			typename Transition::TransFuncList *tfl = &flel->key;
			int offset = flel->value;

			/* Copy the transFuncs at the offset Maybe trans funcs should be
			 * vector and vector. Overwrite should be used. This will do for now. But
			 * then again we require that it is nullable and if we need constructors we like
			 * can't assign 0 to it. Though c++ could do if if you had to. Overkill? */
			memcpy(transFuncs + offset, tfl->table,
					tfl->tableLength * sizeof(TransFunc));

			/* TransFunc must be set to something we can nullify in order to
			 * signal the end of a transition function list. */
			transFuncs[offset + tfl->tableLength] = 0;
		}
	}

	/* Set the transition funcs ptr and the number of trans funcs. */
	machine.allTransFuncs = transFuncs;
	machine.numTransFuncs = mmd.curFuncOffset;

	/* Walk all transitions and replace the function indicies with ptrs. */
	FsmMachTrans<TransFunc> *curTrans = machine.allTrans;
	for ( i = 0; i < machine.numTrans; i++, curTrans++ ) {
		if ( curTrans->funcs != TRANS_NO_FUNCS ) {
			int index = (int) curTrans->funcs;
			curTrans->funcs = transFuncs + index;
		}
		else
			curTrans->funcs = 0;
	}

	/* Walk all states and replace the out function indicies with ptrs. */
	st = machine.allStates;
	for ( i = 0; i < machine.numStates; i++, st++ ) {
		if ( st->outFuncs != TRANS_NO_FUNCS ) {
			int index = (int) st->outFuncs;
			st->outFuncs = transFuncs + index;
		}
		else
			st->outFuncs = 0;
	}
}

/* Creates machine states and assignes each state to a its corresponding
 * state in the fsm graph from which it will be built.
 * Also takes the opprotunity to compute gblLowIndex and gblHighIndex.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		InitMachineStates( FsmMachine<TransFunc> &newMachine )
{
	/* Make the array of states. */
	int numStates = listLength;
	FsmMachState<TransFunc> *machStates = 
		new FsmMachState<TransFunc>[numStates];

	/* Make all the states first and set the mapto values. */
	State *state = head;
	FsmMachState<TransFunc> *curState = machStates;
	for ( int i = 0; i < numStates; i++, curState++ ) {
		/* Init the state. */
		curState->transIndex = 0;
		curState->errIndex = ERR_TRANS_INDEX;
		curState->numIndex = 0;
		curState->lowIndex = MAX_INT;
		curState->highIndex = MIN_INT;
		curState->outFuncs = TRANS_NO_FUNCS;

		/* If the original state is a final state, set the new state final. */
		curState->isFinState = state->isFinState;

		/* Compute gblLowIndex and gblHighIndex. */
		if ( state->outList.tableLength > 0 ) {
			int lowKey = state->outList.table[0].key;
			if ( lowKey < newMachine.gblLowIndex )
				newMachine.gblLowIndex = lowKey;

			int highKey = state->outList.table[
					state->outList.tableLength-1].key + 1;
			if ( highKey > newMachine.gblHighIndex )
				newMachine.gblHighIndex = highKey;
		}

		/* Set the mapto value and go to next state. */
		state->stateMap = (State*) (machStates + i);
		state = state->BASEREF(next);
	}

	/* Get the start state. */
	newMachine.numStates = numStates;
	newMachine.allStates = machStates;
	newMachine.startState = (FsmMachState<TransFunc>*) StartState->stateMap;
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MakeMachineState( MakeMachData &mmd, 
				FsmMachState<TransFunc> *machState, State *state )
{
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;

	int lowIndex = MAX_INT;
	int highIndex = MIN_INT;
	int len = 0;

	if ( ntel > 0 ) {
		lowIndex = tel[0].key;
		/* highIndex is defined to be one past the last valid transition
		 * so high - low == len */
		highIndex = tel[ntel-1].key + 1;
		len = highIndex - lowIndex;
	}

	if ( len > 0 ) {
		machState->lowIndex = lowIndex;
		machState->highIndex = highIndex;
		machState->transIndex = new FsmMachTrans<TransFunc>*[len];
		machState->numIndex = len;
	}

	/* For each transition add the functions to the global function map and
	 * add then transition to the transition map for this state. */
	for ( int i = 0, curIndex = lowIndex; i < ntel; i++, tel++, curIndex++ ) {
		/* While the current index is less than the the next transition to
		 * to add, fill in with an error transition. */
		while ( curIndex < tel->key ) {
			/* Set the index for this character to the error trans. */
			machState->transIndex[curIndex - lowIndex] = ERR_TRANS_INDEX;
			curIndex++;
		}

		/* Get the state */
		Transition *trans = tel->value;
		FsmMachState<TransFunc> *state =
				(FsmMachState<TransFunc>*) trans->toState->stateMap;

		/* Init func offset to no function. */
		int newFuncOffset = -1;

		/* If there are any functions then add them to the map if they
		 * are not already there. */
		int tlen = trans->transFuncTable.tableLength;
		if ( tlen != 0 ) {
			/* Make a new trans func list from the trans func table (we don't care
			 * about the ordering numbers on the transitions so we make a list 
			 * without the ordering). */
			typename Transition::TransFuncList transFuncList;
			Transition::FuncTableToFuncList( transFuncList, trans->transFuncTable );

			/* If not in the function list map then insert. */
			FuncListMapEl *lastFound;
			if ( mmd.funcListMap.Insert( transFuncList, mmd.curFuncOffset, &lastFound ) )
				mmd.curFuncOffset += ( tlen + 1 );

			/* Get the offset as what was found/inserted in the map. */
			newFuncOffset = lastFound->value;
		}
			
		/* We now have the transition for looking up in the transMap. */
		FsmMachTrans<TransFunc> machineTrans;
		machineTrans.toState = state;
		machineTrans.funcs = (TransFunc*) newFuncOffset;

		/* If not in the transition map, insert it. */
		TransMapEl *lastFound;
		if ( mmd.transMap.Insert( machineTrans, mmd.curTransOffset, &lastFound ) )
			mmd.curTransOffset++;

		/* Get the offset as what was found/inserted in the map. */
		int newTransOffset = lastFound->value;
			
		/* Set the index for this character. */
		machState->transIndex[curIndex - lowIndex] = 
				(FsmMachTrans<TransFunc>*) newTransOffset;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		VerifyIntegrity()
{
	State *state = head;
	while ( state != NULL ) {
		TransEl *tel = state->outList.table;
		int i, ntel = state->outList.tableLength;
	 	for ( i = 0; i < ntel; i++, tel++ ) {
			/* Assert the fromState is correct. */
			ASSERT( tel->value->fromState == state );
		}

		tel = state->inList.table;
		ntel = state->inList.tableLength;
		for ( i = 0; i < ntel; i++, tel++ ) {
			Transition *last = 0;
			Transition *trans = tel->value;
			while ( trans != 0 ) {
				/* Assert the toState is correct. */
				ASSERT( trans->toState == state );
				/* Assert the prev ptr is correct. */
				ASSERT( trans->prev == last );

				last = trans;
				trans = trans->next;
			}
		}
		state = state->BASEREF(next);
	}
}

/* This is no longer needed. */
#undef BASEREF

#endif /* _AAPL_FSMBASE_CC */

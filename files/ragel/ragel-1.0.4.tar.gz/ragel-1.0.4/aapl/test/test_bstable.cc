/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <stdio.h>
#include "bstablel.h"
#include "bstablec.h"
#include "bstable.h"

#include "bstmapl.h"
#include "bstmap.h"
#include "bstmapc.h"

struct MyElement  : public OrdCmp<int>
{
	MyElement() {}
	MyElement(int key) : key(key) { }
	const int &GetKey() { return key; }
	int key;

};

template class BsTable<MyElement, int>;
template class BsTableL<MyElement, int>;
template class BsTableC<MyElement, int>;

template class BstMap< char *, int, StrCmp >;
template class BstMapL< int***, int, OrdCmp<int***> >;
template class BstMapC< unsigned long, int, OrdCmp<unsigned long> >;


BsTableC<MyElement, int> constTable(300);
BstMapC< unsigned long, int, OrdCmp<unsigned long> > constTable2(10);

void testBSTable1()
{
	BstMap<int, int, OrdCmp<int> > table;

	table.Insert(1, 3);
	table.Insert(3, 1);
	table.Insert(5, 0);
	table.Insert(7, 1);
	table.Insert(4, 8);
	table.Insert(2, 0);
	table.Insert(6, 1);

	table.Remove(2);
	table.Remove(3);
	table.Remove(6);
	table.Remove(4);
	table.Remove(5);
	table.Remove(7);

	BstMapEl<int, int> *tab = table.table;
	int len = table.tableLength;
	for (int i = 0; i < len; i++, tab++)
		printf("(%i) maps to %i\n", tab->key, tab->value);
}

struct CompoundKey
{
	int Key1;
	int Key2;
};

struct CompoundKeyCompare
{
	inline static int Compare(const CompoundKey &key1, const CompoundKey &key2)
	{
		if ( key1.Key1 < key2.Key1 )
			return -1;
		else if ( key1.Key1 > key2.Key1 )
			return 1;
		else
		{
			if ( key1.Key2 < key2.Key2 )
				return -1;
			else if ( key1.Key2 > key2.Key2 )
				return 1;
			else
				return 0;
		}
	}
};

void testBSTable2()
{
	BstMap<CompoundKey, int, CompoundKeyCompare > table;

	CompoundKey k;

	k.Key1 = 1; k.Key2 = 2;
	table.Insert(k, 10);

	k.Key1 = 1; k.Key2 = 3;
	table.Insert(k, 10);

	k.Key1 = 2; k.Key2 = 2;
	table.Insert(k, 10);

	k.Key1 = 0; k.Key2 = 2;
	table.Insert(k, 10);

	k.Key1 = 2; k.Key2 = -10;
	table.Insert(k, 10);

	BstMapEl<CompoundKey, int> *tab = table.table;
	int len = table.tableLength;
	for (int i = 0; i < len; i++, tab++)
		printf("(%i, %i) maps to %i\n", tab->key.Key1, tab->key.Key2, tab->value);
}

struct KeyStruct
{
	KeyStruct() : key(0) { }
	KeyStruct(int i) : key(i)
		{ cout << "KeyStruct(" << key << ")" << endl; }
	KeyStruct(const KeyStruct &o) : key(o.key)
		{ cout << "KeyStruct(KeyStruct &)" << endl; }
	~KeyStruct() { cout << "~KeyStruct = {" << key << "}" << endl; }
	int key;
};

struct KeyStructCompare
{
	static int Compare(const KeyStruct &k1, const KeyStruct &k2)
	{
		if ( k1.key < k2.key )
			return -1;
		else if ( k1.key > k2.key )
			return 1;
		else
			return 0;
	}
};

int testBSTable3()
{
	BstMapL<KeyStruct, int, KeyStructCompare > tbl;
	KeyStruct k1(1);
	tbl.Insert(k1, 1);
	return 0;
}

int testBSTable4()
{
	BstMap<int, int, OrdCmp<int> > tbl;

	tbl.InsertMulti(1, 1);
	tbl.InsertMulti(4, 1);
	tbl.InsertMulti(2, 1);
	tbl.InsertMulti(1, 1);
	tbl.InsertMulti(1, 1);
	tbl.InsertMulti(1, 3);
	tbl.InsertMulti(3, 1);
	tbl.InsertMulti(1, 0);
	tbl.InsertMulti(7, 1);
	tbl.InsertMulti(4, 8);
	tbl.InsertMulti(1, 0);
	tbl.InsertMulti(6, 1);

	BstMapEl<int, int> *low, *high;

	tbl.FindMulti( 1, low, high );
	cout << high - low + 1 << endl;

	cout << tbl.RemoveMulti( 1 ) << endl;
	cout << tbl.FindMulti( 1, low, high ) << endl;
	return 0;
}

int main()
{
	testBSTable1();
	testBSTable2();
	testBSTable3();
	return 0;
}

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMGRAPH_H
#define _AAPL_FSMGRAPH_H

#include "fsmmachine.h"
#include "vector.h"
#include "vectset.h"
#include "compare.h"
#include "avltree.h"
#include "assert.h"
#include "dlist.h"
#include "dlistmel.h"
#include "bstmap.h"

/* Flags that control merging. */
#define SB_KILLOTHERS 0x01
#define SB_WANTOTHER1 0x02
#define SB_WANTOTHER2 0x04
#define SB_WANTOTHER  0x06
#define SB_GRAPH1     0x08
#define SB_GRAPH2     0x10
#define SB_GRAPHBOTH  0x18
#define SB_MERGED     0x20
#define SB_NEWINTRANS 0x40

/*************************************************************
 * This is the marked index for a state pair. Used in condensing.
 * It keeps track of whether or not the state pair is marked.
 */
template <class State> struct MarkIndexTmpl
{
	struct StatePair : public DListEl<StatePair>
	{
		bool isMarked;
		State *p, *q;
	};

	MarkIndexTmpl(int states);
	~MarkIndexTmpl();
	void MarkPair(int state1, int state2);
	bool IsPairMarked(int state1, int state2);
	StatePair *GetPair(int state1, int state2);

	DList<StatePair> markedList, unmarkedList;

private:
	int numStates;
	StatePair *array;
};

/********************************************************************
 * Compare of a whole Func table element (key & value).
 */
template <class TransFunc, class TransFuncCmp> struct TransFuncElCmp
{
	static int Compare( const BstMapEl<int, TransFunc> &func1, 
			const BstMapEl<int, TransFunc> &func2 )
	{
		int res = OrdCmp<int>::Compare( func1.key, func2.key );
		if ( res != 0 )
			return res;
		else
			return TransFuncCmp::Compare( func1.value, func2.value );
	}
};

/*************************************************************
 * A single transition for a fsm.
 */
template < class State, class Transition, class TransFunc,
		class TransFuncCmp > struct FsmTrans
{
	FsmTrans( ) : fromState(0), toState(0), priority(0) {}

	Transition *next, *prev;
	State *fromState;
	State *toState;

	/* Transistion Func Element and the table. */
	typedef BstMapEl< int, TransFunc > TransFuncEl;
	typedef BstMap< int, TransFunc, OrdCmp<int> > TransFuncTable;

	/* Compare of a TransFuncTable. */
	typedef TableCmp< TransFuncEl, TransFuncElCmp<TransFunc, TransFuncCmp> > 
			TransFuncTableCompare;
	
	/* Plain Func list that imposes no ordering. */
	typedef Vector<TransFunc> TransFuncList;

	/* Make a func list from a func table. Simly copies the value data over. */
	static void FuncTableToFuncList( TransFuncList &funcList,
			TransFuncTable &funcTable);

	/* Comparison for TransFuncList. */
	typedef TableCmp<TransFunc, TransFuncCmp> 
			TransFuncListCompare;

	/* The function table and priority for the transition. */
	TransFuncTable transFuncTable;
	int priority;

	/* Compare for transitions. */
	static inline int Compare( const FsmTrans &trans1, 
			const FsmTrans &trans2 );
	static inline int CompareFuncs( const TransFuncTable &funcs1,
			const TransFuncTable &funcs2 );

	/* Set functions on the transition. */
	void SetFunction( TransFunc func, int transOrder );
	void SetFunctions( TransFuncTable &funcTable );

	/* For the user. */
	void MergeTransition( FsmTrans *otherTrans ) { }
};

/**************************************************
 * FsmSDNode
 */
template<class State> struct FsmSDNode :
		public AvlNode< FsmSDNode<State> >,
		public TableCmp< State*, OrdCmp<State*> >
{
	typedef VectSet< State*, OrdCmp<State*> > StateSet;

	FsmSDNode(const StateSet &stateSet) : stateSet(stateSet) { }

	const StateSet &GetKey() { return stateSet; }
	StateSet stateSet;
	State *targState;
};

/******************************************************************
 * Data needed for any merge operation.
 */
template < class State > struct FsmMergeData
{
	typedef VectSet< State*, OrdCmp<State*> > StateSet;
	typedef AvlTree<FsmSDNode<State>, StateSet> StateDict;
	typedef DList< State > StateList;

	StateDict stateDict;
	StateList stfil;
};


/****************************************
 * template FsmState
 */
template < class State, class TransFunc, class Transition > 
		struct FsmState : public DListEl<State>
{
	FsmState();
	FsmState(FsmState &other);
	~FsmState();

	typedef BstMap< int, Transition*, OrdCmp<int> > TransListType;
	typedef BstMapEl< int, Transition* > TransEl;

	/* Transistion Func Element and the table. */
	typedef BstMapEl< int, TransFunc > TransFuncEl;
	typedef BstMap< int, TransFunc, OrdCmp<int> > TransFuncTable;

	TransListType outList;
	TransListType inList;

	int num;

	/* When duplicating the fsm we need a map of state to new state. */
	State *stateMap;

	/* Is the state a final state. */
	bool isFinState;

	/* Is the state Marked during the MarkReachableFromHere process. */
	bool isMarked;

	/* Bits controlling the behaviour of the state during collapsing to dfa. */
	int stateBits;

	/* Transition data to add to any transition leaving a fsm via this state. */
	int outPriority;
	bool isOutPriorSet;
	TransFuncTable outTransFuncTable;

	/****************************************
	 * StateSet, FsmSDNode
	 */
	typedef VectSet< State*, OrdCmp<State*> > StateSet;
	typedef AvlTree<FsmSDNode<State>, StateSet> StateDict;

	/* A pointer to a dict node that contains the set of states
	 * this state represents. */
	FsmSDNode<State> *stateDictNode;

	/* User routines. */
	void FuseState( State *otherState ) { }
	void MergeState( State *otherState ) { }

	/* Pointer to state comparison. Used by condens round. */
	typedef State* PState;
	static int Compare( const PState s1, const PState s2 );

	static int CompareOutTrans( const FsmState &state1, 
			const FsmState &state2 );
	void SetOutFunctions( TransFuncTable &funcTable );
};

/**************************************************************
 * Contains the data necessary for making the fsm machine.
 */
template < class Transition, class TransFunc > class FsmMakeMach
{
public:
	typedef BstMap<typename Transition::TransFuncList, int,
			typename Transition::TransFuncListCompare> FuncListMap;

	/* A map between transitions and lists of characters that go on those
	 * transitions. Used in condensing the outlist of a state. */
	typedef BstMap<FsmMachTrans<TransFunc>, int,
			FsmMachTrans<TransFunc>::FsmMachTransCompare> TransMap;

	FuncListMap funcListMap;
	TransMap transMap;
	int curFuncOffset;
	int curTransOffset;
};

/****************************************
 * template FsmGraph
 */
template < class State, class TransFunc, class Transition >
		struct FsmGraph : public DList< State >
{
public:
	/* Constructor/Destructor. */
	FsmGraph() {}
	FsmGraph(FsmGraph &graph);
	~FsmGraph();

	/* Transistion Func Element and the table. */
	typedef BstMapEl< int, TransFunc > TransFuncEl;
	typedef BstMap< int, TransFunc, OrdCmp<int> > TransFuncTable;
	
	/****************************************
	 * StateSet, StateDict
	 */
	typedef VectSet< State*, OrdCmp<State*> > StateSet;
	typedef AvlTree< FsmSDNode<State>, StateSet > StateDict;

	/* The list of states. */
	typedef DListEl< State > ListEl;
	typedef DList< State > StateList;
	typedef BstMap< int, Transition*, OrdCmp<int> > TransListType;
	typedef BstMapEl< int, Transition* > TransEl;

	/* Data required on a merge. */
	typedef FsmMergeData<State> MergeData;

	/* Mark index for condenseing. */
	typedef MarkIndexTmpl< State > MarkIndex;

	/* Start state and final state list. */
	State *StartState;
	StateSet FinStateSet;

	/* Attach/Detach states. */
	Transition *AttachStates(State *from, State *to, int onChar);
	void AttachStates(State *from, State *to, Transition *trans, int onChar);
	void DetachStates(State *from, State *to, Transition *trans, int onChar);

	/* Detach a state from the graph. */
	State *DetachState( State *state );

	/* Set and Unset a state as final. */
	void SetFinState(State *state);
	void UnsetFinState(State *state);

	/* Adjust priority on all transitions. */
	void AllTransPrior( int prior );

	/* Adjust priority on entering final states. */
	void FinFsmPrior( int prior );

	/* Adjust priority on leaving the fsm. */
	void LeaveFsmPrior( int prior );

	/* Clear the leave fsm priority settings from the fsm. */
	void ClearLeaveFsmPrior();

	/* Adjust priority on starting the fsm. */
	void BaseStartFsmPrior( int prior );
	void StartFsmPrior( int prior );

	/* Set function to execute on all transitions. */
	void AllTransFunc( TransFunc func, int transOrder );

	/* Set function to execute on entering final states. */
	void FinFsmFunc( TransFunc func, int transOrder );

	/* Set function to execute on leaving the fsm. */
	void LeaveFsmFunc( TransFunc func, int transOrder );

	/* Set function to execute on starting the fsm. */
	void BaseStartFsmFunc( TransFunc func, int transOrder );
	void StartFsmFunc( TransFunc func, int transOrder );

	/* Shift the function ordering of the start transitions to start
	 * at fromOrder and increase in units of 1. Useful before staring.
	 * Returns the ordering number of order numbers used. */
	int ShiftStartFuncOrder( int fromOrder );

	/* Remove all transition functions from the machine. */
	void StripAllTransData();

	/* Function clearing routines. */
	void ClearAllTransFunc();
	void ClearFinFsmFunc();
	void ClearLeaveFsmFunc();
	void ClearStartFsmFunc();

	/* Attach States using Fsm methods. */
	void FsmAttachStates( MergeData &md, State *from, State *to, int onChar, 
			Transition *srcTrans, bool leavingFsm );

	/* Copy the in trans from src to dest. */
	void OutTransCopy( MergeData &md, State *dest, TransListType &srcList, 
			bool leavingFsm );
	void OutTransCopy( MergeData &md, State *dest, State *src, 
			bool leavingFsm );

	/* Move the in trans into src into dest. */
	void InTransMove(State *dest, State *src);

	/* Mark state pairs that go into this pair. */
	void MarkPairsOnIn( MarkIndex &markIndex, State *r, State *s );

	/* Decide if the pair should be marked. Considers whether or not pairs of 
	 * transitions go to marked states. Does not consider transition data. */
	bool ShouldMarkPair(MarkIndex &markIndex, State *r, State *s);

	/* Decide if the pair should be marked. Considers whether or not pairs of 
	 * transitions go to marked states and if the transition data differs. */
	bool ShouldMarkPairTransData(MarkIndex &markIndex, State *r, State *s);

	/* Mark all states reachable from state. */
	void MarkReachableFromHereReverse( State *state );

	/* Mark all states reachable from state. */
	void MarkReachableFromHere( State *state );

	/* Mark all states reachable from state. */
	void UnmarkReachableFromHere( State *state );

	/* A map between list of functions and pointers to the list. Used
	 * Creating the final fsm. Allows to reuse duplicate function lists
	 * and greately compress the fsm. */
	typedef BstMap<typename Transition::TransFuncList, int,
			typename Transition::TransFuncListCompare> FuncListMap;

	/* Elements in the function list map. */
	typedef BstMapEl<typename Transition::TransFuncList, int> FuncListMapEl;

	/* A map between transitions and lists of characters that go on those
	 * transitions. Used in condensing the outlist of a state. */
	typedef BstMap<FsmMachTrans<TransFunc>, int,
			FsmMachTrans<TransFunc>::FsmMachTransCompare> TransMap;

	/* Elements in the transition map. */
	typedef BstMapEl<FsmMachTrans<TransFunc>, int> TransMapEl;

	/* Build a runnable, compressed machine from this graph. */
	void BuildFsmMachine( FsmMachine<TransFunc> &machine );

	/* Make the states for a new machine. */
	void InitMachineStates( FsmMachine<TransFunc> &newMachine );

	typedef FsmMakeMach<Transition, TransFunc> MakeMachData;

	/* Make a machine state from a graph state. */
	void MakeMachineState( MakeMachData &mmd,
			FsmMachState<TransFunc> *machState, State *state );

	/* Run a sanity check on the machine. */
	void VerifyIntegrity();

	/* New up a state and add it to the graph. */
	State *NewState(bool isFinState = false);

	/* Build basic fsms. */
	static FsmGraph *ConcatFsm( char *set );
	static FsmGraph *ConcatFsm( int *set, int len );
	/* The oring routines reqire that the characters in
	 * set be uniq otherwise they will assertion fail. */
	static FsmGraph *OrFsm( char *set );
	static FsmGraph *OrFsm( int *set, int len );
	static FsmGraph *NullFsm( );

	/* Fsm Operators. */
	void Star(bool leavingFsm);
	void Concat(FsmGraph *other, bool leavingFsm);
	void Or(FsmGraph *other);
	void Intersect(FsmGraph *other);
	void Subtract(FsmGraph *other);

	/* Underlying worker behind Or, Intersect and Subtract. */
	void DoOr(FsmGraph *other);

	/* Set State numbers starting at 0. */
	void SetStateNumbers();

	/* Unset all final states. */
	void UnsetAllFinStates();

	/* Set the priority of all transitions into final states. */
	void SetFinBits( int allStateBits, int finStateBits );

	/* Merge a set of states into newState. */
	void MergeStates( MergeData &md, State *newState, StateSet &stateSet, 
			bool leavingFsm );

	/* Make all states that are combinations of other states and that
	 * have not yet had their out transitions filled in. This will 
	 * empty out stateDict and stFil. */
	void FillInStates( MergeData &md );

	/* Zero out all the function keys. This is useful just before
	 * condensing and building a machine. If the function keys are 
	 * all identical then states will not be separated because of 
	 * the specified ordering. After this call, no operations can 
	 * be done on the fsm. */
	void NullFunctionKeys();

	/*** Condensing ***/

	/* Condense the final state Machine. The result is the most condense 
	 * fsm possible. Slow but stable, correct condensing. Uses n^2 space
	 * (lookout) and average n^2 time. Worst case n^3 time, but a that 
	 * is a very rare case. */
	void CondenseStable();

	/* Condense the final state machine. Does not find the most condense 
	 * fsm possible. But a pretty good approximation. Does not use any 
	 * extra space. Average n^2 time. Worst case n^3 time, but a that 
	 * is a very rare case. */
	void CondenseApproximate();


	/* Condense the final state Machine. The result is the most condense
	 * fsm possible. Considers all state pairs and is thus O(n^2)
	 * Warning: Unverified, maybe buggy, maybe incorrect. */
	void CondenseOptimized1();

	/* Condense the final state Machine. The result is the most condense
	 * fsm possible. Does not consider all state pairs. If this is called
	 * it must be called after every fsm operation that can created states.
	 * (or,and,star,intersect,subtract,startprior,startfunc). Is at worst
	 * O( n^2 / 4 ) when operating on two machines of equal size. And at
	 * best O(n) when operating on one small machine and one large machine.
	 * Warning: Unverified, maybe buggy, maybe incorrect. */
	void CondenseOptimized2();

	/* This is the worker for the condense approximate solution. It merges
	 * states that have identical out transitions. */
	bool CondenseRound( );

	/* Mark pairs where out final stateness differs, out trans data differs,
	 * trans pairs go to a marked pair or trans data differs. Should get 
	 * alot of pairs. */
	void InitialMarkRound( MarkIndex &markIndex );

	/* One marking round on all state pairs. Considers if trans pairs go
	 * to a marked state only. Returns whether or not a pair was marked. */
	bool MarkRound( MarkIndex &markIndex );

	/* Mark pairs that have in trans to pairs that can cause marking. */
	void ExhaustAll( MarkIndex &markIndex );

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void RemoveDeadEndStates();

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void RemoveObliviousStates();

	/* Mark and Unmark all states. */
	void MarkAllStates();
	void UnmarkAllStates();

	/* Remove all out funcs and out priorites on non final states. */
	void StripNonFinalStates();

	/* Assert that there are no out funcs/priorities on non final states. */
	void VerifyOutFuncs();
	
	/* Merge state p into state q. */
	void MergePIntoQ(State *p, State *q);

	/* Find any states that didn't get marked by the marking algorithm and
	 * merge them into the primary states of their equivalence class. */
	void MergeUnmarkedPairs( MarkIndex &markIndex );
};

#endif /* _AAPL_FSMGRAPH_H */

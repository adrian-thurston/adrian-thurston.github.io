/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>

#ifdef _WIN
#	define size_t int
#	include <winsock.h>
#else
#	include <unistd.h>
#	include <sys/types.h>
#	include <sys/socket.h>
#	include <netinet/in.h>
#	include <netinet/in.h>
#	include <arpa/inet.h>
#	include <netdb.h>
#endif

#include "config.h"
#include "connection.h"
#include "selector.h"

/* #define CONNECT_MSGS */
#define BUFFER_LEN 1000

Connection::Connection(Selector &sel) : 
	readFd(-1), writeFd(-1),
	readRegistered(false), writeRegistered(false),
	connectionOpen(false), deleteOnClose(true),
	sel(sel) { }

void Connection::SuccessfullOpen()
{
	/* Set connection now open. */
	connectionOpen = true;

	/* Add the connection to the list of 
	 * open connections. Connections are added to the
	 * front so if the selector is destroyed, the connections
	 * are closed and deleted in reverse order that they
	 * were created.
	 */
	sel.connList.AddFront(this);
}

void Connection::Close()
{
	/* Don't try to close the connection if it
	 * is already closed. */
	if ( ! connectionOpen )
		return;

	/* Close the fds if they have been * assigned. */
	if (readFd != 0 && readFd != -1)
		close( readFd );
	if (writeFd != 1 && writeFd != -1 && writeFd != readFd)
		close( writeFd );

	/* UnRegister any reading or writing. */
	UnRegisterRead();
	UnRegisterWrite();

	/* Flag the connection as closed */
	connectionOpen = false;

	/* Remove from the list of connections. */
	sel.connList.DetachElement(this);

	/* Call the virtual function that handles closing
	 * of the super class */
	ConnectionClosed();
}

void Connection::RegisterRead()
{
	if ( connectionOpen && ! readRegistered )
	{
		FD_SET(readFd, &sel.readFdSet);
		sel.readFdList.AddEnd(this);

		readRegistered = true;
	}
}

void Connection::RegisterWrite()
{
	if ( connectionOpen && ! writeRegistered )
	{
		FD_SET(writeFd, &sel.writeFdSet);
		sel.writeFdList.AddEnd(this);

		writeRegistered = true;
	}
}

void Connection::UnRegisterRead()
{
	if ( connectionOpen && readRegistered )
	{
		FD_CLR(readFd, &sel.readFdSet);
		sel.readFdList.DetachElement(this);

		readRegistered = false;
	}
}

void Connection::UnRegisterWrite()
{
	if ( connectionOpen && writeRegistered )
	{
		FD_CLR(writeFd, &sel.writeFdSet);
		sel.writeFdList.DetachElement(this);

		writeRegistered = false;
	}
}

int Listener::ServiceRead()
{
	/* Request for a new connection. */
	int newConnect;
	struct sockaddr_in clientname;
#if defined(ACCEPT_ARG_SIZE_T)
	size_t size = sizeof(clientname);
#elif defined(ACCEPT_ARG_INT)
	int size = sizeof(clientname);
#elif defined(ACCEPT_ARG_UNSIGNED)
	unsigned size = sizeof(clientname);
#endif

	newConnect = accept (readFd, (struct sockaddr *) &clientname, &size);
	if (newConnect < 0)
	{
		perror ("accept");
		return -1;
	}

	CreateConnection( newConnect );
	return 0;
}

void Listener::CreateConnection(int sock) {
	close(sock);
}


int INSListener::Open(unsigned short int port)
{
	int optionVal;

	/* Create the socket. */
	readFd = socket(PF_INET, SOCK_STREAM, 0);
	if (readFd < 0) {
		perror ("socket");
		readFd = -1;
		return -1;
	}

	/* Set it's address to reusable. */
	optionVal = 1;
	setsockopt(readFd, SOL_SOCKET, SO_REUSEADDR,
			(char *)&optionVal, sizeof(int));

	/* Give the socket a name. */
	sockName.sin_family = AF_INET;
	sockName.sin_port = htons (port);
	sockName.sin_addr.s_addr = htonl (INADDR_ANY);
	if (bind (readFd, (struct sockaddr *) &sockName, sizeof (sockName)) < 0) {
		perror ("bind");
		goto fail;
	}
	
	/* Set the socket to listen. */
	if (listen (readFd, 1) < 0) {
		perror ("listen");
		goto fail;
	}

#ifdef CONNECT_MSGS
	printf("inet_listener: connection opened\n");
#endif

	SuccessfullOpen();
	return 0;

fail:
	close(readFd);
	readFd = -1;
	return -1;
}

void INSListener::ConnectionClosed()
{
#ifdef CONNECT_MSGS
	printf("inet_listener: connection closed.\n");
#endif
}

int FNSListener::Open(char *filename)
{
	/* Create the socket. */
	readFd = socket(PF_INET, SOCK_STREAM, 0);
	if (readFd < 0) {
		perror ("socket");
		readFd = -1;
		return -1;
	}

	/* Is the filename too long? */
	if ( strlen(filename) + 1 > sizeof(sockName.sun_path) )
		goto fail;

	/* Give the socket a name. */
	sockName.sun_family = AF_UNIX;
	strcpy(sockName.sun_path, filename);
	sockName.sun_path[sizeof(sockName.sun_path) - 1] = 0;
	if (bind (readFd, (struct sockaddr *) &sockName,
			strlen(filename) + sizeof(sockName.sun_family)) < 0) {
		perror ("bind");
		goto fail;
	}
	
	/* Set the socket to listen. */
	if (listen (readFd, 1) < 0) {
		perror ("listen");
		goto fail;
	}

#ifdef CONNECT_MSGS
	printf("fns_listener: connection opened.\n");
#endif

	SuccessfullOpen();
	return 0;

fail:
	close(readFd);
	readFd = -1;
	return -1;
}

void FNSListener::ConnectionClosed()
{
	unlink(sockName.sun_path);
#ifdef CONNECT_MSGS
	printf("fns_listener: connection closed\n");
#endif
}


int ReaderWriter::Open(int rfd, int wfd)
{
	readFd = rfd;
	writeFd = wfd;

#ifdef CONNECT_MSGS
	printf("reader_writer: connection opened\n");
#endif

	SuccessfullOpen();
	return 0;
}

int ReaderWriter::Open(char *hostname, unsigned short int port)
{
	struct sockaddr_in servername;
	struct hostent *hostinfo;

	/* Create the socket. */
	readFd = writeFd = socket(PF_INET, SOCK_STREAM, 0);
	if (readFd < 0) {
		perror ("socket(client)");
		readFd = writeFd = -1;
		return -1;
	}

	/* Lookup the host. */
	servername.sin_family = AF_INET;
	servername.sin_port = htons (port);
	hostinfo = gethostbyname (hostname);
	if (hostinfo == NULL) {
		fprintf (stderr, "Unknown host %s.\n", hostname);
		goto fail;
	}
	servername.sin_addr = *(struct in_addr *) hostinfo->h_addr;

	/* Connect to the server. */
	if (0 > connect(readFd, (struct sockaddr *) &servername,
			sizeof (servername)))
	{
		perror ("connect(client)");
		goto fail;
	}

#ifdef CONNECT_MSGS
	printf("reader_writer: connection opened\n");
#endif

	SuccessfullOpen();
	return 0;

fail:
	close(readFd);
	readFd = writeFd = -1;
	return -1;
}

void ReaderWriter::ConnectionClosed()
{
#ifdef CONNECT_MSGS
	printf("reader_writer: connection closed\n");
#endif
}

void ReaderWriter::WriteData(byte *data, int len)
{
	writeDq.AppendRight(data, len);
	RegisterWrite();
}

void ReaderWriter::Eof()
{
	if ( writeDq.dequeLength > 0 )
		closeOnEmptyWriteDq = true;
	else
		Close();
}

int ReaderWriter::ServiceWrite()
{
	/* Get the data avail in the left chunk. */
	int len = writeDq.SizeLeftChunk();

	/* If Data is there then try to write it. */
	if ( len > 0 )
	{
		/* Try to write some data.. */
		len = write( writeFd, (char*) writeDq.PtrLeftChunk(), len );
		
		/* Kill the data written. */
		writeDq.KillLeft( len );
	}

	/* If there is no more data to be written, turn off writing. */
	if ( writeDq.dequeLength == 0 )
	{
		UnRegisterWrite();
		if ( closeOnEmptyWriteDq )
		{
			closeOnEmptyWriteDq = false;
			return -1;
		}
	}
	
	return 0;
}

int ReaderWriter::ServiceRead()
{
	int nbytes;
	const int bufferLen = BUFFER_LEN;
	byte buffer[bufferLen];


	nbytes = read(readFd, (char*) buffer, bufferLen);

	if (nbytes < 0)
	{
		/* Read error. */
		perror ("read");
		return -1;
	}
	else if (nbytes == 0)
	{
		/* End-of-file. */
		return -1;
	}

	return ReadReady(buffer, nbytes);
}

int ReaderWriterPipe::ReadReady(byte *data, int len)
{
	if ( ! otherRW.IsOpen() )
		return -1;

	otherRW.writeDq.AppendRight(data, len);
	otherRW.RegisterWrite();
	return 0;
}
     
void ReaderWriterPipe::ConnectionClosed()
{
#ifdef CONNECT_MSGS
	printf("reader_writer_pipe: connection closed\n");
#endif
}


Messenger::Messenger(Selector &sel) : Connection(sel)
{
	state = Empty;
}


int Messenger::Open(int rfd, int wfd)
{
	readFd = rfd;
	writeFd = wfd;

#ifdef CONNECT_MSGS
	printf("messenger: connection opened\n");
#endif
	return 0;
}

int Messenger::Open(char *hostname, unsigned short int port)
{
	struct sockaddr_in servername;
	struct hostent *hostinfo;

	/* Create the socket. */
	readFd = writeFd = socket(PF_INET, SOCK_STREAM, 0);
	if (readFd < 0)
	{
		perror ("socket(client)");
		goto fail;
	}

	/* Lookup the host. */
	servername.sin_family = AF_INET;
	servername.sin_port = htons (port);
	hostinfo = gethostbyname (hostname);
	if (hostinfo == NULL)
	{
		fprintf (stderr, "Unknown host %s.\n", hostname);
		goto fail;
	}
	servername.sin_addr = *(struct in_addr *) hostinfo->h_addr;

	/* Connect to the server. */
	if (0 > connect(readFd, (struct sockaddr *) &servername,
			sizeof (servername)))
	{
		perror ("connect(client)");
		goto fail;
	}

#ifdef CONNECT_MSGS
	printf("messenger: connection opened\n");
#endif

	SuccessfullOpen();
	return 0;

fail:
	close(readFd);
	readFd = writeFd = -1;
	return -1;
}

void Messenger::ConnectionClosed()
{
#ifdef CONNECT_MSGS
	printf("messenger: connection closed\n");
#endif
}


void Messenger::SendMessageHeader(int msgid, int msglen)
{
	char headerBuf[19];
	sprintf(headerBuf, "%.8x %.8x\n", msgid, msglen);
	writeDq.AppendRight(headerBuf, 18);

	RegisterWrite();
}

int Messenger::ScanBasicMessage(char *msg, int *i1, int *i2)
{
	char c;
	int digitsRead;
	uint digitVal;

	enum {
		start, hex1, whitesp, hex2
	} state = start;

	enum {
		digit, sp, newline
	} charType;

	uint ret1 = 0;
	uint ret2 = 0;

	while ( true )
	{
		/* Get the character to consider. */
		c = *msg;

		/* Determine the character type. */
		switch ( c ) {
			case '0': case '1': case '2': case '3':
			case '4': case '5': case '6': case '7':
			case '8': case '9':
				charType = digit;
				digitVal = c - '0'; 
				break;
			case 'a': case 'b': case 'c': case 'd':
			case 'e': case 'f':
				charType = digit;
				digitVal = 0xa + c - 'a'; 
				break;
			case ' ':
				charType = sp;
				break;
			case '\n':
				charType = newline;
				break;
			default:
				return false;
		}

		/* Switch over the states. */
		switch ( state ){
		case start: {
			switch ( charType ) {
			case digit:
				/* Move to hex1 state. */
				state = hex1;

				/* We have read one digit. */
				digitsRead = 1;

				/* Ret1 is the value of this digit. */
				ret1 = digitVal;
				break;
			default:
				return false;
			}
			break;
		}
		case hex1: {
			switch ( charType ) {
			case digit:
				if ( digitsRead == 8 )
					return false;
				else
				{
					/* We have read one more digit. */
					digitsRead++;

					/* Shift ret1 over by 4 and
					 * OR it with the val of this digit. */
					ret1 = ( ret1 << 4 ) | digitVal;
				}
				break;
			case sp:
				if ( digitsRead == 8 )
					state = whitesp;
				else
					return false;
				break;
			default:
				return false;
			}

			break;
		}
		case whitesp: {
			switch ( charType ) {
			case digit:
				/* Move to hex2 state. */
				state = hex2;

				/* We have read one digit. */
				digitsRead = 1;

				/* Ret2 is the value of this digit. */
				ret2 = digitVal;
				break;
			default:
				return false;
			}
			break;
		}
		case hex2: {
			switch ( charType ) {
			case digit:
				if ( digitsRead == 8 )
					return false;
				else
				{
					/* We have read one more digit. */
					digitsRead++;

					/* Shift ret2 over by 4 and
					 * OR it with the val of this digit. */
					ret2 = ( ret2 << 4 ) | digitVal;
				}
				break;
			case newline:
				if ( digitsRead == 8 )
				{
					/* SUCCESS! Store ret1 and ret2 and return. */
					*i1 = (int) ret1;
					*i2 = (int) ret2;
					return true;
				}
				else
					return false;
				break;
			default:
				return false;
			}
			break;
		}
		}

		/* Next character. */
		msg++;
	}
	return false;
}

/* Returns:
 * -2 A basic message was read but the length was unreasonable.
 * -1 Enough data there for a basic message but it was malformed.
 * 0  Not enough data there for a basic message.
 * 1  A basic message was read.
 */
int Messenger::GetBasicMessage()
{
	int id = 0, len = 0;
	char basicMessage[18];

	/*
	 * A basic Message consists of:
	 * xxxxxxxx xxxxxxxx\n
	 * where x are lowercase hex digits.
	 */
	
	if ( readDq.dequeLength < 18 )
		return 0;
	
	/* We have enough data for scanning. */
	readDq.PeekLeft(basicMessage, 18);

	if ( ScanBasicMessage(basicMessage, &id, &len) )
	{
		/* Is the length positive? */
		if ( len < 0 )
			return -2;
		
		msg.Id = id;
		msg.Length = len;

		/* Kill off the basic message. */
		readDq.KillLeft(18);
		return 1;
	}

	return -1;
}

int Messenger::ServiceRead()
{
	int nbytes, retVal = 0;
	const int bufferLen = BUFFER_LEN;
	byte buffer[bufferLen];

	nbytes = read(readFd, (char*) buffer, bufferLen);

	if (nbytes < 0)
	{
		/* Read error. */
		perror ("read");
		return -1;
	}
	else if (nbytes == 0)
	{
		/* End-of-file. */
		return -1;
	}

	readDq.AppendRight(buffer, nbytes);

	/* Look for the remains of a message. */
	if (state == MessageStarted)
	{
		if (readDq.dequeLength >= msg.Length)
		{
			/* The end of the message is there for us.
			 * Process the message. */
			retVal = ProcessMessage();

			/* Return to the empty state. */
			state = Empty;
		}
		else
		{
			/* The rest of the message is not there for us.
			 * We cannot do anything but wait for the rest of it.*/
			return 0;
		}
	}

	/* If processing of the last message failed, then return
	 * immediately. */

	/* ASSERT: state == empty */
		
	/* While the last mesg processed did not fail. */
	while ( retVal >= 0 )
	{
		/* Look for a basic message. */
		retVal = GetBasicMessage();
		
		/* Anything less then zero means error getting basic
		 * message. A 0 means not enough data for a basic
		 * message. 1 means got a basic message. */
		if ( retVal != 1 )
			break;

		if (msg.Length > 0 )
		{
			/* Is the rest of the message there for us? */
			if (readDq.dequeLength < msg.Length)
			{
				/* The rest of the message is not there.
				 * So we move into the message started state. */
				state = MessageStarted; 
				
				/* There is nothing more we can do until we get
				 * more input. */
				retVal = 0;
				break;
			}
		}

		/* Process the message. */
		retVal = ProcessMessage();
	}

	return retVal;
}

int Messenger::ServiceWrite()
{
	/* Get the data avail in the left chunk. */
	int len = writeDq.SizeLeftChunk();

	/* If Data is there then try to write it. */
	if ( len > 0 )
	{
		/* Try to write some data.. */
		len = write( writeFd, (char*) writeDq.PtrLeftChunk(), len );
		
		/* Kill the data written. */
		writeDq.KillLeft( len );
	}

	/* If there is no more data to be written, turn off writing. */
	if ( writeDq.dequeLength == 0 )
		UnRegisterWrite();
	
	return 0;
}

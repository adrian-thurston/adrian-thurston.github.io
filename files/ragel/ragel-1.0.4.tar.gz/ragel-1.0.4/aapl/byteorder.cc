/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "byteorder.h"

#ifdef SBO_RUN_TIME

/* If you allocate 4 bytes, then put a 1 in the lowest byte, 2 in the second lowest byte,
 * 3 in the second highest byte and 4 in highest byte and then cast the value to an unsigned
 * integer you get the following values on their respective architectures. */

# define RESULT_LITTLE_ENDIAN   0x04030201
# define RESULT_BIG_ENDIAN      0x01020304
# define RESULT_PDP_ENDIAN      0x02010403

/* Global System ByteOrder Indicator. */
ByteOrder SystemByteOrder = Unknown;

/* This will work properly on 32 bit systems but not
 * on 16 bit system.
 *
 * I don't know how it behaves on 64 bit systems (or anything
 * else about 64 bit systems for that matter).
 */
void DetermineByteOrder()
{
	int i = 0;
	unsigned char *bytes = (unsigned char*)(&i);

	bytes[0] = 0x01;
	bytes[1] = 0x02;
	bytes[2] = 0x03;
	bytes[3] = 0x04;

	switch (i) {
		case RESULT_LITTLE_ENDIAN:
			/* printf("Little Endian\n"); */
			SystemByteOrder = LittleEndian;
			break;

		case RESULT_BIG_ENDIAN:
			/* printf("Big Endian\n"); */
			SystemByteOrder = BigEndian;
			break;

		case RESULT_PDP_ENDIAN:
			/* printf("Pdp Endian\n"); */
			SystemByteOrder = PdpEndian;
			break;

		default:
			/* printf("Unknown\n"); */
			SystemByteOrder = Unknown;
			throw "Unknown byte ordering.";
	}
}
#endif /* ifdef SBO_RUN_TIME */

int ScanInt(byte *buf)
{
	int i;
	unsigned char *bytes = (unsigned char*) (&i);

#if defined(SBO_RUN_TIME)
	switch (SystemByteOrder) {
		case LittleEndian:
			bytes[0] = buf[0];
			bytes[1] = buf[1];
			bytes[2] = buf[2];
			bytes[3] = buf[3];
			break;

		case BigEndian:
			bytes[0] = buf[3];
			bytes[1] = buf[2];
			bytes[2] = buf[1];
			bytes[3] = buf[0];
			break;

		case PdpEndian:
			bytes[0] = buf[2];
			bytes[1] = buf[3];
			bytes[2] = buf[0];
			bytes[3] = buf[1];
			break;

		case Unknown:
			break;
	}
#elif defined(SBO_LITTLE_ENDIAN)
	bytes[0] = buf[0];
	bytes[1] = buf[1];
	bytes[2] = buf[2];
	bytes[3] = buf[3];
#elif defined(SBO_BIG_ENDIAN)
	bytes[0] = buf[3];
	bytes[1] = buf[2];
	bytes[2] = buf[1];
	bytes[3] = buf[0];
#elif defined(SBO_PDP_ENDIAN)
	bytes[0] = buf[2];
	bytes[1] = buf[3];
	bytes[2] = buf[0];
	bytes[3] = buf[1];
#endif
	return i;
}

void WriteInt(byte *buf, int i)
{
	unsigned char *bytes = (unsigned char*) (&i);

#if defined(SBO_RUN_TIME)
	switch (SystemByteOrder) {
		case LittleEndian:
			buf[0] = bytes[0];
			buf[1] = bytes[1];
			buf[2] = bytes[2];
			buf[3] = bytes[3];
			break;

		case BigEndian:
			buf[0] = bytes[3];
			buf[1] = bytes[2];
			buf[2] = bytes[1];
			buf[3] = bytes[0];
			break;

		case PdpEndian:
			buf[0] = bytes[2];
			buf[1] = bytes[3];
			buf[2] = bytes[0];
			buf[3] = bytes[1];
			break;

		case Unknown:
			break;
	}
#elif defined(SBO_LITTLE_ENDIAN)
	buf[0] = bytes[0];
	buf[1] = bytes[1];
	buf[2] = bytes[2];
	buf[3] = bytes[3];
#elif defined(SBO_BIG_ENDIAN)
	buf[0] = bytes[3];
	buf[1] = bytes[2];
	buf[2] = bytes[1];
	buf[3] = bytes[0];
#elif defined(SBO_PDP_ENDIAN)
	buf[0] = bytes[2];
	buf[1] = bytes[3];
	buf[2] = bytes[0];
	buf[3] = bytes[1];
#endif
}

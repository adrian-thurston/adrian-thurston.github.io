/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_BUFFER_H
#define _AAPL_BUFFER_H

#include <string.h>
#include "table.h"

/****************************************
 * template Buffer
 */
template < class T > class Buffer :
		public Table<T>
{
public:
	/* Default Constructor. */
	Buffer() {}

	/* Copy Constructor. */
	Buffer(const Buffer &v)
		{ Append( v ); }

	/* Destructor Empties the Buffer. */
	~Buffer()
		{ delete[] (char*) table; }

	void Empty()
		{ tableLength = 0; }

	/* Appending routines. */
	void Append(const T &val);
	void Append(const T *val, int len);
	void Append(const Buffer<T> &b);

protected:
	void UpResize(int len);
};

/****************************************
 * void Buffer<T, Table>::Append(const T &data)
 */
template<class T> void Buffer<T>::
		Append(const T &src)
{
	/* Make sure we have enough space. */
	UpResize(tableLength + 1);

	/* Copy data. */
	table[tableLength] = src;

	/* Increment table size. */
	tableLength += 1;
}

/****************************************
 * void Buffer<T, Table>::Append(const T *data, int len)
 */
template<class T> void Buffer<T>::
		Append(const T *src, int len)
{
	/* Make sure we have enough space. */
	UpResize(tableLength + len);

	/* Copy data. */
	memcpy(table + tableLength, src, sizeof(T)*len);

	/* Update table size. */
	tableLength += len;
}
/****************************************
 * void Buffer<T, Table>::Append(const Buffer &b)
 */
template<class T> void Buffer<T>::
		Append(const Buffer<T> &b)
{
	/* Make sure we have enough space. */
	UpResize(tableLength + b.tableLength);

	/* Copy data. */
	memcpy(table + tableLength, b.table, sizeof(T)*b.tableLength);

	/* Update table size. */
	tableLength += b.tableLength;
}

/************************************************************
 * Up resize. Uses the Exonential method used by vector.
 */
template<class T> void Buffer<T>::UpResize(int len)
{
	/* If the Table is not big enough to fit len then upsize it. */
	if ( len > allocLength ) {
		/* Double the size n requested. */
		allocLength = len<<1;
		if ( table != 0 ) {
			/* Create the new table and copy the contents. */
			T *newTable = (T*) new char[sizeof(T)*allocLength];
			ASSERT( newTable != 0 );
			memcpy(newTable, table, sizeof(T)*tableLength);

			/* Delete the old table and make the new table the cur table. */
			delete[] (char*) table;
			table = newTable;
		}
		else {
			/* Create the table. */
			table = (T*) new char[sizeof(T)*allocLength];
			ASSERT( table != 0 );
		}
	}
}

#endif /* _AAPL_BUFFER_H */

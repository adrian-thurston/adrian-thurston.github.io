/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

#if defined( BSTABLE_EXPN_TABLE )
#	include "vector.h"
#	define BASECOMPARE(name) Element::name
#	define BST_TEMPDEF class Element, class Key
#	define BST_TEMPUSE Element, Key
#	define BSTABLE
#	define BsTable BsTable
#	define Vector Vector
#elif defined( BSTABLE_LINEAR_TABLE )
#	include "vectorl.h"
#	define BASECOMPARE(name) Element::name
#	define BST_TEMPDEF class Element, class Key
#	define BST_TEMPUSE Element, Key
#	define BSTABLE
#	define BsTable BsTableL
#	define Vector VectorL
#elif defined( BSTABLE_CONST_TABLE )
#	include "vectorc.h"
#	define BASECOMPARE(name) Element::name
#	define BST_TEMPDEF class Element, class Key
#	define BST_TEMPUSE Element, Key
#	define BSTABLE
#	define BsTable BsTableC
#	define Vector VectorC
#elif defined( BSTMAP_EXPN_TABLE )
#	include "vector.h"
#	define BASECOMPARE(name) Compare::name
#	define BST_TEMPDEF class Key, class Value, class Compare
#	define BST_TEMPUSE Key, Value, Compare
#	define BSTMAP
#	define BsTable BstMap
#	define Vector Vector
#	define Element BstMapEl<Key, Value>
#elif defined( BSTMAP_LINEAR_TABLE )
#	include "vectorl.h"
#	define BASECOMPARE(name) Compare::name
#	define BST_TEMPDEF class Key, class Value, class Compare
#	define BST_TEMPUSE Key, Value, Compare
#	define BSTMAP
#	define BsTable BstMapL
#	define Vector VectorL
#	define Element BstMapEl<Key, Value>
#elif defined( BSTMAP_CONST_TABLE )
#	include "vectorc.h"
#	define BASECOMPARE(name) Compare::name
#	define BST_TEMPDEF class Key, class Value, class Compare
#	define BST_TEMPUSE Key, Value, Compare
#	define BSTMAP
#	define BsTable BstMapC
#	define Vector VectorC
#	define Element BstMapEl<Key, Value>
#else
#	error "no vector table type"
#endif


#if defined( BSTMAP )

#ifndef __AAPL_BSTELMAP__
#define __AAPL_BSTELMAP__
/********************************************************
 * Binary search table map element.
 */
template <class Key, class Value> struct BstMapEl
{
	BstMapEl() {}
	BstMapEl(const Key &key) : key(key) {}
	BstMapEl(const Key &key, const Value &val) : key(key), value(val) {}

	const Key &GetKey() { return key; }

	Key key;
	Value value;
};
#endif /* __AAPL_BSTELMAP__ */

#endif

template <BST_TEMPDEF> class BsTable :
		public Vector< Element >
{
public:
#if defined( BSTABLE_CONST_TABLE ) || defined( BSTMAP_CONST_TABLE )
	BsTable(int allocLength) : Vector< Element >(allocLength) {}
#else
	BsTable() { }
#endif

	Element *Insert(const Key &key, Element **lastFound = NULL);
	Element *InsertMulti(const Key &key);

#if defined( BSTMAP )
	Element *Insert(const Key &key, const Value &val, 
			Element **lastFound = NULL);
	Element *InsertMulti(const Key &key, const Value &val );
#endif

	Element *Find(const Key &key) const;
	bool FindMulti( const Key &key, Element *&lower,
			Element *&upper ) const;

	int Remove(const Key &key);
	int RemoveMulti(const Key &key);
	int RemoveItem( Element *item );
};

template<BST_TEMPDEF> int BsTable<BST_TEMPUSE>::
		RemoveMulti(const Key &key)
{
	Element *low, *high;
	if ( FindMulti(key, low, high) )
	{
		int num = high - low + 1;
		Vector< Element >::Delete(low - table, high - low + 1);
		return num;
	}
	else
		return 0;
}


template<BST_TEMPDEF> int BsTable<BST_TEMPUSE>::
		Remove(const Key &key)
{
	Element *el = Find(key);
	if (el)
	{
		Vector< Element >::Delete(el - table);
		return true;
	}
	else
		return false;
}

template <BST_TEMPDEF> bool BsTable<BST_TEMPUSE>::
		FindMulti(const Key &key, Element *&low, Element *&high ) const
{
	Element *lower, *mid, *upper;
	int keyRelation;

	if (! table)
	{
		return false;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array. */
			return false;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASECOMPARE(Compare(key, mid->GetKey()));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			Element *lowEnd = table - 1;
			Element *highEnd = table + tableLength;

			lower = mid - 1;
			while ( lower != lowEnd && 
					BASECOMPARE(Compare(key, lower->GetKey())) == 0 )
				lower--;

			upper = mid + 1;
			while ( upper != highEnd && 
					BASECOMPARE(Compare(key, upper->GetKey())) == 0 )
				upper++;
			
			low = lower + 1;
			high = upper - 1;
			return true;
		}
	}
}

template <BST_TEMPDEF> Element *BsTable<BST_TEMPUSE>::
		Find( const Key &key ) const
{
	Element *lower, *mid, *upper;
	int keyRelation;

	if (! table)
		return 0;

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower ) {
			/* Did not find the key. */
			return 0;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASECOMPARE(Compare(key, mid->GetKey()));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			/* Found. */
			return mid;
		}
	}
}

template <BST_TEMPDEF> int BsTable<BST_TEMPUSE>::
		RemoveItem( Element *item )
{
	if (item != NULL)
	{
		Vector< Element >::Delete(item - table);
		return true;
	}
	else
		return false;
}

template <BST_TEMPDEF> Element *BsTable<BST_TEMPUSE>::
		Insert(const Key &key, Element **lastFound)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASECOMPARE(Compare(key, mid->GetKey()));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != NULL )
				*lastFound = mid;
			return 0;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = MakeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = table + insertPos;
	return table + insertPos;
}


template <BST_TEMPDEF> Element *BsTable<BST_TEMPUSE>::
		InsertMulti(const Key &key)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASECOMPARE(Compare(key, mid->GetKey()));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			lower = mid;
			goto Insert;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = MakeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key);

	/* Return the element inserted. */
	return table + insertPos;
}


#if defined( BSTMAP )

template <BST_TEMPDEF> Element *BsTable<BST_TEMPUSE>::
		Insert(const Key &key, const Value &val, Element **lastFound)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASECOMPARE(Compare(key, mid->GetKey()));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != NULL )
				*lastFound = mid;
			return 0;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = MakeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key, val);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = table + insertPos;
	return table + insertPos;
}


template <BST_TEMPDEF> Element *BsTable<BST_TEMPUSE>::
		InsertMulti(const Key &key, const Value &val)
{
	Element *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = BASECOMPARE(Compare(key, mid->GetKey()));

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			lower = mid;
			goto Insert;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = MakeRawSpaceFor(insertPos, 1);
	new(table + insertPos) Element(key, val);

	/* Return the element inserted. */
	return table + insertPos;
}

#endif /* BSTMAP */


#undef BASECOMPARE
#undef BST_TEMPDEF
#undef BST_TEMPUSE
#undef BSTABLE
#undef BSTMAP
#undef BsTable
#undef Vector 
#undef Element

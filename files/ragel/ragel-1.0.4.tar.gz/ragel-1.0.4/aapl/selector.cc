/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <string.h>

#ifdef _WIN
#	include <winsock.h>
#else
#	include <unistd.h>
#	include <netinet/in.h>
#	include <netinet/in.h>
#	include <arpa/inet.h>
#	include <netdb.h>
#endif

#include "connection.h"
#include "selector.h"
     
Selector::Selector()
{
	FD_ZERO(&readFdSet);
	FD_ZERO(&writeFdSet);
}

Selector::~Selector()
{
	/* Walk the list of Connections and close all items. */
	Connection *curConn, *nextConn;

	curConn = connList.head;
	while ( curConn != 0 )
	{
		nextConn = curConn->ConnListEl::next;

		curConn->Close();
		if ( curConn->deleteOnClose )
			delete curConn;

		curConn = nextConn;
	}
}

void Selector::SelectLoop()
{
	fd_set wkng_rfds, wkng_wfds;   /* Local Copies of file descriptor sets. */
	Connection *curConn, *nextConn;      /* Iterating over connections. */
	StopSelect = false;

	while (! StopSelect &&
		(writeFdList.listLength > 0 ||
		readFdList.listLength > 0))
	{
		wkng_rfds = readFdSet;
		wkng_wfds = writeFdSet;

		/* Block until input arrives on one or more active sockets. */
		if (select (FD_SETSIZE, &wkng_rfds, &wkng_wfds, NULL, NULL) < 0)
		{
			perror ("select");
			return;
		}

		/* Service all the descriptors that are available for
		 * reading. */
		curConn = readFdList.head;
		while (curConn)
		{
			nextConn = curConn->ReadFdListEl::next;

			/* printf("Read Polling: %i ...", wkng_fd->Value.Fd); */
			if (FD_ISSET (curConn->readFd, &wkng_rfds))
			{
				/* printf("yes\n"); */
				if ( curConn->ServiceRead() != 0 )
				{
					curConn->Close();
					if ( curConn->deleteOnClose )
						delete curConn;
				}
			}
			/* else
				printf("no\n"); */

			curConn = nextConn;
		}

		/* Service all the output descriptors that are available for
		 * writing. */
		curConn = writeFdList.head;
		while (curConn)
		{
			nextConn = curConn->WriteFdListEl::next;

			/* printf("Write Polling: %i ...", wkng_fd->fd); */
			if (FD_ISSET (curConn->writeFd, &wkng_wfds))
			{
				/* printf("yes\n"); */
				if ( curConn->ServiceWrite() != 0 )
				{
					curConn->Close();
					if ( curConn->deleteOnClose )
						delete curConn;
				}
			}
			/* else
				printf("no\n"); */

			curConn = nextConn;
		}
	}
}

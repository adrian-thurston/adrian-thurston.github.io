/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndef becuase it is not intended to
 * be included by the user. */

#if defined( DOUBLELIST_MEL )
#	define BASEREF(name) BaseElement::name
#	define DLMEL_TEMPDEF class Element, class BaseElement
#	define DLMEL_TEMPUSE Element, BaseElement
#	define DList DListMel
#elif defined( DOUBLELIST_SINGULAR )
#	define BASEREF(name) name
#	define DLMEL_TEMPDEF class Element
#	define DLMEL_TEMPUSE Element
#	define DList DList
#else
#	error "list type not specified: this is not a user header"
#endif

#ifndef __AAPL_DOUBLE_LIST_EL
#define __AAPL_DOUBLE_LIST_EL
/*****************************************************************
 * DListEl
 */
template <class Element> struct DListEl
{
	Element *prev;
	Element *next;
};

#endif /* __AAPL_DOUBLE_LIST_EL */


/*****************************************************************
 * DList
 */
template <DLMEL_TEMPDEF> class DList
{
public:
	DList(const DList &other);
	DList() : head(0), tail(0), listLength(0) {}

	void AddFront(Element *new_el)
		{AddBefore(head, new_el);}
	void AddEnd(Element *new_el)
		{AddAfter(tail, new_el);}

	void AddFront( DList &dl )
		{AddBefore(head, dl);}
	void AddEnd( DList &dl )
		{AddAfter(tail, dl);}

	Element *DetachFront()
		{return DetachElement(head);}
	Element *DetachEnd()
		{return DetachElement(tail);}

	void DeleteElements();
	void EmptyList();
	
	void AddAfter(Element *prev_el, Element *new_el);
	void AddBefore(Element *next_el, Element *new_el);

	void AddAfter(Element *prev_el, DList &dl);
	void AddBefore(Element *next_el, DList &dl);

	Element *DetachElement(Element *el);

	Element *head, *tail;
	int listLength;
};

/*******************************************************************
 * Copy Constructor
 *
 * Copy the data from another list. New up each item.
 */
template <DLMEL_TEMPDEF> DList<DLMEL_TEMPUSE>::
		DList(const DList<DLMEL_TEMPUSE> &other) :
		head(0), tail(0), listLength(0)
{
	Element *el = other.head;
	while( el != 0 ) {
		AddEnd( new Element(*el) );
		el = el->BASEREF(next);
	}
}

/*******************************************************************
 * DList::AddAfter
 *
 * Insert an element after a given element already in the list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		AddAfter(Element *prev_el, Element *new_el)
{
	/* Set the previous pointer of new_el to prev_el. We do
	 * this regardless of the state of the list. */
	new_el->BASEREF(prev) = prev_el; 

	/* Set forward pointers. */
	if (prev_el == 0) {
		/* There was no prev_el, we are inserting at the head. */
		new_el->BASEREF(next) = head;
		head = new_el;
	} 
	else {
		/* There was a prev_el, we can access previous next. */
		new_el->BASEREF(next) = prev_el->BASEREF(next);
		prev_el->BASEREF(next) = new_el;
	} 

	/* Set reverse pointers. */
	if (new_el->BASEREF(next) == 0) {
		/* There is no next element. Set the tail pointer. */
		tail = new_el;
	}
	else {
		/* There is a next element. Set it's prev pointer. */
		new_el->BASEREF(next)->BASEREF(prev) = new_el;
	}

	/* Update list length. */
	listLength++;
}

/*******************************************************************
 * DList::AddBefore
 *
 * Insert an element before a given element already in the list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		AddBefore(Element *next_el, Element *new_el)
{
	/* Set the next pointer of the new element to next_el. We do
	 * this regardless of the state of the list. */
	new_el->BASEREF(next) = next_el; 

	/* Set reverse pointers. */
	if (next_el == 0) {
		/* There is no next elememnt. We are inserting at the tail. */
		new_el->BASEREF(prev) = tail;
		tail = new_el;
	} 
	else {
		/* There is a next element and we can access next's previous. */
		new_el->BASEREF(prev) = next_el->BASEREF(prev);
		next_el->BASEREF(prev) = new_el;
	} 

	/* Set forward pointers. */
	if (new_el->BASEREF(prev) == 0) {
		/* There is no previous element. Set the head pointer.*/
		head = new_el;
	}
	else {
		/* There is a previous element, set it's next pointer to new_el. */
		new_el->BASEREF(prev)->BASEREF(next) = new_el;
	}

	/* Update list length. */
	listLength++;
}

/*******************************************************************
 * DList::AddAfter
 *
 * Insert an entire list after another element already in the list.
 * Result is other list is emptied out.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		AddAfter( Element *prev_el, DList<DLMEL_TEMPUSE> &dl )
{
	/* Do not bother if dl has no elements. */
	if ( dl.listLength == 0 )
		return;

	/* Set the previous pointer of dl.head to prev_el. We do
	 * this regardless of the state of the list. */
	dl.head->BASEREF(prev) = prev_el; 

	/* Set forward pointers. */
	if (prev_el == 0) {
		/* There was no prev_el, we are inserting at the head. */
		dl.tail->BASEREF(next) = head;
		head = dl.head;
	} 
	else {
		/* There was a prev_el, we can access previous next. */
		dl.tail->BASEREF(next) = prev_el->BASEREF(next);
		prev_el->BASEREF(next) = dl.head;
	} 

	/* Set reverse pointers. */
	if (dl.tail->BASEREF(next) == 0) {
		/* There is no next element. Set the tail pointer. */
		tail = dl.tail;
	}
	else {
		/* There is a next element. Set it's prev pointer. */
		dl.tail->BASEREF(next)->BASEREF(prev) = dl.tail;
	}

	/* Update the list length. */
	listLength += dl.listLength;

	/* Empty out dl. */
	dl.head = dl.tail = 0;
	dl.listLength = 0;
}

/*******************************************************************
 * DList::AddBefore
 *
 * Insert an entire list before another element already in the list.
 * Result is other list is emptied out.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		AddBefore( Element *next_el, DList<DLMEL_TEMPUSE> &dl )
{
	/* Do not bother if dl has no elements. */
	if ( dl.listLength == 0 )
		return;

	/* Set the next pointer of dl.tail to next_el. We do
	 * this regardless of the state of the list. */
	dl.tail->BASEREF(next) = next_el; 

	/* Set reverse pointers. */
	if (next_el == 0) {
		/* There is no next elememnt. We are inserting at the tail. */
		dl.head->BASEREF(prev) = tail;
		tail = dl.tail;
	} 
	else {
		/* There is a next element and we can access next's previous. */
		dl.head->BASEREF(prev) = next_el->BASEREF(prev);
		next_el->BASEREF(prev) = dl.tail;
	} 

	/* Set forward pointers. */
	if (dl.head->BASEREF(prev) == 0) {
		/* There is no previous element. Set the head pointer.*/
		head = dl.head;
	}
	else {
		/* There is a previous element, set it's next pointer to new_el. */
		dl.head->BASEREF(prev)->BASEREF(next) = dl.head;
	}

	/* Update list length. */
	listLength += dl.listLength;

	/* Empty out dl. */
	dl.head = dl.tail = 0;
	dl.listLength = 0;
}


/*******************************************************************
 * DList::DetachElement
 *
 * Detaches an element from the list. Does not free any memory.
 */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::
		DetachElement(Element *el)
{
	/* Set forward pointers to skip over el. */
	if (el->BASEREF(prev) == 0) 
		head = el->BASEREF(next); 
	else {
		el->BASEREF(prev)->BASEREF(next) =
				el->BASEREF(next); 
	}

	/* Set reverse pointers to skip over el. */
	if (el->BASEREF(next) == 0) 
		tail = el->BASEREF(prev); 
	else {
		el->BASEREF(next)->BASEREF(prev) =
				el->BASEREF(prev); 
	}

	/* Update List length and return element we detached. */
	listLength--;
	return el;
}

/*******************************************************************
 * DList::DeleteElements
 *
 * Frees all the memory used by a list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		DeleteElements()
{
	Element *nextToGo = 0, *cur = head;
	
	while (cur != 0)
	{
		nextToGo = cur->BASEREF(next);
		delete cur;
		cur = nextToGo;
	}
	head = tail = 0;
	listLength = 0;
}

/*******************************************************************
 * DList::EmptyList
 *
 * Abandon all elements in the list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::EmptyList()
{
	head = tail = 0;
	listLength = 0;
}

/* Finished with these. */
#undef BASEREF
#undef DLMEL_TEMPDEF
#undef DLMEL_TEMPUSE
#undef DList


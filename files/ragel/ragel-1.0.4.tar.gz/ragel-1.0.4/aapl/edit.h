/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_EDIT_H
#define _AAPL_EDIT_H

#include "support.h"
#include "bstmap.h"
#include "dlist.h"


#define CHUNK_LEN 10
class Edit;
class EditChunk;
class Marker;

typedef BstMapEl<int, Marker*> MarkerDictEl;
typedef BstMap< int, Marker*, OrdCmp<int> > MarkerDict;

class EditChunk : public DListEl<EditChunk>
{
public:
	enum DirToGrow { Left, Right, Either };
	EditChunk(DirToGrow dir) { PrepGrow(dir); }
	void PrepGrow(DirToGrow dir);

	byte *GetData() { return data + FrontPos; }
	byte *GetEndData() { return data + EndPos; }

	int SpaceLeft() { return FrontPos; }
	int SpaceRight() { return CHUNK_LEN - EndPos; }

	void InsertLeft(EditChunk *chunk);
	void InsertRight(EditChunk *chunk);
	void InsertLeft(byte *data, int len);
	void InsertRight(byte *data, int len);

	void ShiftRight();
	void ShiftLeft();

	byte data[CHUNK_LEN];
	int EndPos, FrontPos, Length;
};

typedef DList<EditChunk> ChunkList;

class Marker : public DListEl<Marker>
{
public:
	Marker(int i, EditChunk::DirToGrow dir, Marker *on_top_of);
	~Marker();

	void NewLeftChunk();
	void NewRightChunk();

	void InsertRight(byte *data, int len);
	void InsertLeft(byte *data, int len);

	void MoveLeft(int len);

	void DumpAllLeft();
	void DumpAllRight();

	void DumpLeft(int len);
	void DumpRight(int len);
	void InsertChunkRight(EditChunk *chunk);
	void InsertShortDataRight(byte *data, int len);
	void InsertChunkLeft(EditChunk *chunk);
	void InsertShortDataLeft(byte *data, int len);

	void SpareLeft(EditChunk *chunk);
	void SpareRight(EditChunk *chunk);

	ChunkList chunkList;
	EditChunk *spareChunk;
	int filePos, id, Length;
	Marker *onTopOf;
	unsigned int IsSentinal :1;
};

typedef DList<Marker> MarkerList;

class Edit
{
public:
	Edit();

	Marker *NewMarker();
	int FindNewMarkerId();
	int RemoveMarker(int id);
	int RemoveMarker(Marker *marker);

	void EvictWhatWeCan(EditChunk *chunk);
	void Evict(EditChunk *chunk, int len);

	void MoveLeftFromOnTop(Marker *marker, int len);
	int MoveLeft(int mid, int len);
	int MoveLeft(Marker *marker, int len);

	int InsertRight(int id, byte *data, int len);
	void InsertRight(Marker *marker, byte *data, int len);

	int InsertLeft(int id, byte *data, int len);
	void InsertLeft(Marker *marker, byte *data, int len);

	void FixFilePos(Marker *marker, int amount);

	MarkerList markerList;
	MarkerList otMarkerList;

	MarkerDict markerDict;

	void DumpOut();
};




#endif /* _AAPL_EDIT_H */

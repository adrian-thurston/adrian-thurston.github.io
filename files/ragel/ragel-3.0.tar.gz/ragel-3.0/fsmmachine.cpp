/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmmachine.h"
#include "fsmap.h"
#include <iostream>

/* Free the inidicies. */
FsmMachState::~FsmMachState()
{
	if ( transIndPtr != 0 )
		delete[] transIndPtr;
	if ( transIndKey != 0 )
		delete[] transIndKey;
}

/* Free the indicies. */
FsmMachFlatState::~FsmMachFlatState()
{
	if ( transIndex != 0 )
		delete[] transIndex;
}

/* Inline compare of transistions. */
int FsmMachTransCompare::compare(const FsmMachTrans &t1,
			const FsmMachTrans &t2)
{
	if ( t1.toState < t2.toState )
		return -1;
	else if ( t1.toState > t2.toState )
		return 1;
	else {
		if ( t1.funcs < t2.funcs )
			return -1;
		else if ( t1.funcs > t2.funcs )
			return 1;
		else
			return 0;
	}
}

/* Construct an empty machine. */
FsmMachine::FsmMachine()
{
	startState = -1;
	allStates = 0;
	numStates = 0;

	/* All transitions. */
	allTrans = 0;
	numTrans = 0;

	/* All transition function arrays. */
	allTransFuncs = 0;
	numTransFuncs = 0;

	/* Function indicies. */
	transFuncIndex = 0;
	numTransFuncIndex = 0;

	isAlphSigned = true;
}

/* Delete all memory used by the machine. */
FsmMachine::~FsmMachine()
{
	if ( allStates != 0 )
		delete[] allStates;
	if ( allTrans != 0 )
		delete[] allTrans;
	if ( allTransFuncs != 0 )
		delete[] allTransFuncs;
	if ( transFuncIndex != 0 )
		delete[] transFuncIndex;
}

/* Count the number of indicies across the whole machine. */
int FsmMachine::numIndicies()
{
	int sum = 0;
	for ( int s = 0; s < numStates; s++ ) {
		FsmMachState *state = &allStates[s];
		sum += state->numIndex + state->numRange + 1;
	}
	return sum;
}

/* Make an fsm state where the transition indicies are one flat array.
 * bool allocIndicies controls whether or not the indicy array is made. */
void FsmMachine::makeFlatState( FsmMachFlatState &dest, 
		const FsmMachState &src, bool allocIndicies )
{
	/* This may not be made, so init it null. */
	dest.transIndex = 0;

	/* If there are no transitions, then our work is not hard. */
	if ( src.numIndex == 0 ) {
		dest.highIndex = 0;
		dest.lowIndex = 0;
		dest.transIndex = 0;
		dest.numIndex = 0;
		dest.dflIndex = 0;
		return;
	}

	/* Get high index and low index. */
	dest.lowIndex = src.transIndKey[0];
	dest.highIndex = src.transIndKey[src.numIndex-1] + 1;

	/* No default index, goes to error trans, which is index 0. */
	dest.dflIndex = src.dflIndex;

	/* The index array is high minus low long. */
	dest.numIndex = dest.highIndex - dest.lowIndex;

	if ( allocIndicies ) {
		dest.transIndex = new int[dest.numIndex];

		/* We can toss only a few transitions. */
		for ( int orig = 0,               /* loops src indicies */
				aInd = dest.lowIndex;     /* loops alphabet indicies. */
				orig < src.numIndex; orig++, aInd++ ) {
			/* Fill in gaps with the default transition. */
			while ( aInd < src.transIndKey[orig] ) {
				dest.transIndex[aInd - dest.lowIndex] = dest.dflIndex;
				aInd += 1;
			}
				
			/* Copy the trans index. */
			dest.transIndex[aInd - dest.lowIndex] = src.transIndPtr[orig];
		}
	}
}

/* Make an fsm state that is designed for a switch statement. Characters that
 * use the same transition are chunked together. */
void FsmMachine::makeSwitchState( FsmMachSwitchState &dest, 
		const FsmMachState &src )
{
	int *key = src.transIndKey;
	int *trans = src.transIndPtr;

	/* Build a mapping of transitions to chars on those transitions. */
	for ( int j = 0; j < src.numIndex; j++, key++, trans++) {
		/* Try to insert the pointer to the transition. We use
		 * lastfound so we don't care if it fails or not. We are
		 * just interested in the Vector<int> at the trans ptr. */
		BstMapEl< int, Vector<int> > *lastFound;
		dest.funcMap.insert( *trans, &lastFound );
			
		/* Now append the char for this transition to the vector. */
		Vector<int> &charVec = lastFound->value;
		charVec.append( *key );
	}

	/* We cannot pick a default index, the error trans is 
	 * used as the default. */
	dest.dflIndex = src.dflIndex;
}

void FsmMachine::makeIndiciesFromRange( FsmMachState *machState )
{
	/* Count the number of indicies. */
	int i, dest, numIndex = 0;
	for ( i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		numIndex += upper - lower + 1;
	}

	machState->transIndKey = new int[numIndex];
	machState->transIndPtr = new int[numIndex];
	machState->numIndex = numIndex;

	/* Set the indicies. */
	for ( dest = 0, i = 0; i < machState->numRange; i++ ) {
		int lower = machState->rangeIndKey[i*2];
		int upper = machState->rangeIndKey[i*2+1];
		for ( int ind = lower; ind <= upper; ind++ ) {
			machState->transIndKey[dest] = ind;
			machState->transIndPtr[dest] = machState->rangeIndPtr[i];
			dest += 1;
		}
	}
}
		
void FsmMachine::moveRangesIntoIndicies( FsmMachState *machState )
{
	/* Nothing to do if there are no ranges. */
	if ( machState->rangeIndPtr == 0 )
		return;

	/* If there are no indicies then simply express the ranges as indicies. */
	if ( machState->transIndKey == 0 ) {
		makeIndiciesFromRange( machState );
	}
	else {
		int *indexKey = machState->transIndKey;
		int *indexPtr = machState->transIndPtr;
		int numIndex = machState->numIndex;

		makeIndiciesFromRange( machState );

		int *rangeKey = machState->transIndKey;
		int *rangePtr = machState->transIndPtr;
		int numRange = machState->numIndex;

		/* Pass one is to count. */
		int count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				count += numRange - range;
				break;
			}
			else if ( range == numRange ) {
				count += numIndex - index;
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] )
					range += 1;
				else if ( indexKey[index] < rangeKey[range] )
					index += 1;
				else {
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}

		machState->transIndKey = new int[count];
		machState->transIndPtr = new int[count];
		machState->numIndex = count;

		/* Pass two is to build. */
		count = 0, index = 0, range = 0;
		while ( true ) {
			if ( index == numIndex ) {
				while ( range < numRange ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
					count += 1;
				}
				break;
			}
			else if ( range == numRange ) {
				while ( index < numIndex ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					count += 1;
				}
				break;
			}
			else {
				if ( rangeKey[range] < indexKey[index] ) {
					machState->transIndKey[count] = rangeKey[range];
					machState->transIndPtr[count] = rangePtr[range];
					range += 1;
				}
				else if ( indexKey[index] < rangeKey[range] ) {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
				}
				else {
					machState->transIndKey[count] = indexKey[index];
					machState->transIndPtr[count] = indexPtr[index];
					index += 1;
					range += 1;
				}
				count += 1;
			}
		}
		delete[] indexKey;
		delete[] indexPtr;
		delete[] rangeKey;
		delete[] rangePtr;
	}

	delete[] machState->rangeIndKey;
	delete[] machState->rangeIndPtr;
	machState->rangeIndKey = 0;
	machState->rangeIndPtr = 0;
	machState->numRange = 0;
}

/* Move ranges into indicies for all states. */
void FsmMachine::moveRangesIntoIndicies( )
{
	for ( int s = 0; s < numStates; s++ )
		moveRangesIntoIndicies( &allStates[s] );
}

/* Compare for finding the set of unique transitions. Compares destination
 * state and transition function. Ignores priority. */
struct TransSetCompare
{
	static inline int compare( TransAp *trans1, TransAp *trans2 )
	{
		/* Both of the transition pointers are set. Test target state,
		 * priority and funcs. */
		if ( trans1->toState < trans2->toState )
			return -1;
		else if ( trans1->toState > trans2->toState )
			return 1;
		else {
			const ActionTable &t1 = trans1->actionTable;
			const ActionTable &t2 = trans2->actionTable;
			int cmpResult = ActionTableCmp::compare(t1, t2);
			if ( cmpResult != 0 )
				return cmpResult;
		}
		return 0;
	}
};

/* Types that the builder operates on. */
typedef FsmTransList<FsmAp, TransAp, long> TransListType;
typedef FsmTransListEl<TransAp, long> TransEl;

/* Set of unique transition functions. */
typedef AvlMapEl<ActionTable, int> TransFuncSetEl;
typedef AvlMap<ActionTable, int, ActionTableCmp> TransFuncSet;

/* Set of unique transitions. */
typedef AvlMapEl<TransAp*, int> TransSetEl;
typedef AvlMap<TransAp*, int, TransSetCompare> TransSet;


/* Contains the data necessary for making the fsm machine. */
class BuildData
{
public:
	/* Construct the fsm builder. */
	BuildData( FsmMachine *machine, FsmAp *graph );	

	/* Build a runnable, compressed machine from this graph. */
	void build( );

private:
	/* The graph is the source, the machine is the destination. */
	FsmMachine *machine;
	FsmAp *graph;

	int curTransOffset;
	int numFuncs;

	/* Error transitions made to support error actions. Inidividual pointers
	 * are only filled in on demand. */
	TransAp **errorTrans;

	/* For the reduction of transitions. */
	TransFuncSet transFuncSet;
	TransSet transSet;

	/* Make the states for a new machine. */
	void initMachineStates( );

	/* Make a machine transition from a graph transition. */
	int makeMachineTrans( TransAp *trans );

	/* Make a machine state from a graph state. */
	void buildMachineState( FsmMachState *machState, StateAp *state, int snum );

	/* Add functions from a func table to the func map and return the index
	 * of the functions. If the func table is empty, the index will be -1. */
	int addFuncsToMap( ActionTable &funcTable );

	/* Finding the unique action lists and transitions. */
	void reduceActions();
	void reduceActionTable( ActionTable &funcTable, TransFuncSet &funcSet, 
			int &curOffset );
	void reduceTransitions();
	void emptyReduced();

	/* Making the arrays of functions. */
	void writeFuncSet( int *funcs, int *funcIndex, TransFuncSet &funcSet );
	void buildFunctionLists();

	/* Making the array of transitions. */
	void buildTransitionArray();
};



/* Construct the fsm builder. Inits the pointers to the graph, and machine. */
BuildData::BuildData( FsmMachine *machine, FsmAp *graph )
:
	machine(machine),
	graph(graph), 
	curTransOffset(0), 
	numFuncs(0),
	errorTrans(0)
{
}

/* Creates machine states and assignes each state state in the graph to the
 * corresponding state in the array of machine states. */
void BuildData::initMachineStates( )
{
	/* Make the array of states. */
	int numStates = graph->stateList.length()+1;
	FsmMachState *machStates = new FsmMachState[numStates];

	/* Make the array of pointers to error transitions. */
	errorTrans = new TransAp*[numStates];
	memset( errorTrans, 0, sizeof(TransAp*)*numStates );

	/* Make all the states first and set the mapto values. */
	StateAp *state = graph->stateList.head;
	FsmMachState *curState = machStates;
	for ( int i = 0; i < numStates; i++, curState++ ) {
		/* Init the state. */
		curState->transIndKey = 0;
		curState->transIndPtr = 0;
		curState->numIndex = 0;
		curState->rangeIndKey = 0;
		curState->rangeIndPtr = 0;
		curState->numRange = 0;
		curState->dflIndex = TRANS_ERR_TRANS;
		curState->outFuncs = FUNC_NO_FUNC;

		if ( i == 0 ) {
			/* The error state is not final and is not mapped to from any
			 * graph state. */
			curState->isFinState = false;
		}
		else {
			/* If the original state is a final state, set the new state final. */
			curState->isFinState = (state->stateBits & SB_ISFINAL) ? true : false;

			/* Set the mapto value and go to next state. */
			state->alg.machState = (machStates + i);
			state = state->next;
		}

		curState->labelNeeded = true;
	}

	/* Set number of states, the state array. */
	machine->numStates = numStates;
	machine->allStates = machStates;

	/* Get the start state the entry points. */
	machine->startState = graph->startState->alg.machState - machStates;
	for ( FsmAp::EntryMap::Iter en = graph->entryPoints; en.lte(); en++ ) {
		/* Get the target state. */
		int targ = en->value->alg.machState - machStates;
		machine->entryMap.insertMulti( en->key, targ );
	}
}


void BuildData::reduceActionTable( ActionTable &funcTable, 
		TransFuncSet &funcSet, int &curOffset )
{
	/* Only need to reduce if the transition function is set. */
	if ( funcTable.length() > 0 ) {
		/* Result of the insert and the last found. */
		TransFuncSetEl *result, *lastFound;

		/* Try to insert in the function map using the next func offset. */
		result = funcSet.insert( funcTable, curOffset, &lastFound );

		if ( result != 0 ) {
			/* The insert succeeded. Increment the count of functions
			 * and the offset into the function index. */
			numFuncs += funcTable.length() + 1;
			curOffset += 1;
		}
		else {
			/* The func already exists take a reference to it to
			 * reduce mem usage. */
			funcTable = lastFound->key;
		}
	}
}

void BuildData::reduceActions( )
{
	int curOffset = 0;

	/* For each state... */
	StateAp *state = graph->stateList.head;
	while ( state != 0 ) {
		/* Reduce the func table of each transition going out of the state. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt++ )
			reduceActionTable( outIt.trans->actionTable, transFuncSet, curOffset );

		/* Reduce the state's table of out actions. */
		reduceActionTable( state->outActionTable, transFuncSet, curOffset );

		/* Reduce the state's table of error actions. */
		reduceActionTable( state->errorActionTable, transFuncSet, curOffset );

		/* Next state. */
		state = state->next;
	}
}

void BuildData::reduceTransitions( )
{
	/* Loop each state, getting the regular trans out and the any error actions. */
	FsmAp::StateList::Iter state = graph->stateList;
	for ( int snum = 0; state.lte(); state++, snum++ ) {
		/* For each transition going out of the state. */
		FsmAp::OutIter outIt( state );
		for ( ; ! outIt.end(); outIt++ ) {
			/* Try to insert in the map. */
			TransSetEl *result, *lastFound;
			result = transSet.insert( outIt.trans, curTransOffset, &lastFound );

			if ( result != 0 ) {
				/* The insert succeeded. Increment the count of transitions. */
				curTransOffset += 1;
			}
			/* The func already so exists take a reference to it. */
			else if ( outIt.itState == FsmAp::OutIter::Default ) {
				/* Set from the transition stored in the set. */
				delete outIt.state->outDefault;
				outIt.state->outDefault = lastFound->key;
			}
			else {
				/* Set from the transition stored in the set. */
				delete outIt.transEl->value;
				outIt.transEl->value = lastFound->key;
			}
		}

		/* If there are error actions, then the state will need a customized
		 * error transition. */
		if ( state->errorActionTable.length() > 0 ) {
			/* Create a transition to represent the error trans. */
			errorTrans[snum] = new TransAp;
			errorTrans[snum]->toState = 0;
			errorTrans[snum]->actionTable = state->errorActionTable;

			/* Try to insert in the map. */
			TransSetEl *result, *lastFound;
			result = transSet.insert( errorTrans[snum], curTransOffset, &lastFound );

			if ( result != 0 ) {
				/* The insert succeeded. Increment the count of transitions. */
				curTransOffset += 1;
			}
			else {
				/* The insert did not succeed, the trans exists already. */
				delete errorTrans[snum];
				errorTrans[snum] = lastFound->key;
			}
		}
	}
}

void BuildData::emptyReduced()
{
	/* In the reduced form, the transition are not deleted by iterating the
	 * out list because they are shared across the whole graph. Just delete
	 * all the states. */
	graph->stateList.empty();

	/* Delete thet transitions from the transSet. */
	TransSet::Iter it = transSet;
	for ( ; it.lte(); it++ )
		delete it->key;
}

void BuildData::writeFuncSet( int *funcs, int *funcIndex, TransFuncSet &funcSet )
{	
	/* For each funclist in the funclist map, copy the list over. Also copy
	 * the indicies into the transfuncs. This is pointer plus len. */
	TransFuncSet::Iter it = funcSet;
	for( int writeTo = 0; it.lte(); it++ ) {
		/* Get a pointer to the function table. */
		ActionTable &funcTab = it->key;

		/* Set the index pointer and number of funcs for the func offset. */
		funcIndex[it->value] = writeTo;

		/* The first element is the length. */
		funcs[writeTo++] = funcTab.size();

		/* Copy the transFuncs at the writeTo offset. */
		ActionTable::Iter funcIt = funcTab;
		for ( ; funcIt.lte(); writeTo++, funcIt++ )
			funcs[writeTo] = funcIt->value;
	}
}

void BuildData::buildFunctionLists()
{
	/* Only fill in if there are any functions. */
	if ( transFuncSet.size() > 0 ) {
		/* There was space used. New up the funclist array. */
		machine->allTransFuncs = new int[numFuncs];
		machine->numTransFuncs = numFuncs;

		/* The size of funcListMap gives the number of function 
		 * indicies and lengths. */
		machine->transFuncIndex = new int[transFuncSet.size()];
		machine->numTransFuncIndex = transFuncSet.size();

		/* Fill in the trans funcs and corresponding index. */
		writeFuncSet( machine->allTransFuncs, machine->transFuncIndex, transFuncSet );
	}

#if 0
	/* Only fill in if there are any functions. */
	if ( outTransFuncSet.size() > 0 ) {
		/* There was space used. New up the funclist array. */
		machine->allOutTransFuncs = new int[numOutFuncs];
		machine->numOutTransFuncs = numOutFuncs;

		/* The size of funcListMap gives the number of function 
		 * indicies and lengths. */
		machine->outTransFuncIndex = new int[outTransFuncSet.size()];
		machine->numOutTransFuncIndex = outTransFuncSet.size();

		/* Fill in the trans funcs and corresponding index. */
		writeFuncSet( machine->allOutTransFuncs, machine->outTransFuncIndex, outTransFuncSet );
	}
#endif
}


/* Make the global array of unique transitions. */
void BuildData::buildTransitionArray()
{
	/* Save the items in the transMap to trans */
	FsmMachTrans *trans = 0;

	/* New up the transition table. */
	trans = new FsmMachTrans[curTransOffset];

	/* Walk the transMap and copy to the transitions. The location of the
	 * transition must be the offsets in the value field because that is what
	 * the index array uses. */
	for ( TransSet::Iter it = transSet; it.lte(); it++ ) {
		/* Handle the case of there being no no target state. */
		if ( it->key->toState == 0 ) {
			/* The target state is the error state. */
			trans[it->value].toState = STATE_ERR_STATE;
		}
		else {
			/* Get the machine state representing toState. */
			FsmMachState *state = it->key->toState->alg.machState;

			/* Save the target state. */
			trans[it->value].toState = state - machine->allStates;
		}

		/* Set the transitions functions in the machine trans. */
		if ( it->key->actionTable.length() == 0 ) {
			/* No functions for this transition. */
			trans[it->value].funcs = FUNC_NO_FUNC;
		}
		else {
			/* Find the function in the func map. */
			TransFuncSetEl *tfsel = transFuncSet.find( it->key->actionTable );
			trans[it->value].funcs = tfsel->value;
		}
	}

	/* Set the transitions pointer and the number of transitions. */
	machine->allTrans = trans;
	machine->numTrans = curTransOffset;
}

/* Build a machine state from a graph state. Is responsible for creating the
 * transitions of the new state. */
void BuildData::buildMachineState( FsmMachState *machState, StateAp *state, int snum )
{
	/* Get the index of the error transition. */
	int errTransOffset = TRANS_ERR_TRANS;
	if ( errorTrans[snum] != 0 ) {
		TransSetEl *tsel = transSet.find( errorTrans[snum] );
		errTransOffset = tsel->value;
	}

	/* 
	 * Build the transition list.
	 */
	int ntel = state->outList.size();
	machState->numIndex = ntel;
	if ( ntel > 0 ) {
		machState->transIndKey = new int[ntel];
		machState->transIndPtr = new int[ntel];
	}

	/* For each single transition out of the state, locate set the index key
	 * and index pointer. */
	TransListType::Iter outIt = state->outList.first();
	for ( int writeTo = 0; outIt.lte(); writeTo++, outIt++ )
	{
		/* Assume using the error transition. */
		int transOffset = errTransOffset;

		/* The transition may not be set. */
		if ( outIt->value != 0 ) {
			TransSetEl *tsel = transSet.find( outIt->value );
			transOffset = tsel->value;
		}

		/* Set the index for this character. */
		machState->transIndKey[writeTo] = outIt->key;
		machState->transIndPtr[writeTo] = transOffset;
	}

	/*
	 * Now do ranges.
	 */
	ntel = state->outRange.size();
	machState->numRange = ntel/2;
	if ( ntel > 0 ) {
		machState->rangeIndKey = new int[ntel];
		machState->rangeIndPtr = new int[ntel/2];
	}

	/* For each range transition out of the state, locate set the index key
	 * and index pointer. */
	outIt = state->outRange.first();
	for ( int wi = 0, wj = 0; outIt.lte(); 
			wi += 2, wj++, outIt++, outIt++ )
	{
		/* Get the first lower transition element. */
		TransEl *transEl = outIt;

		/* Assume using the error transition. */
		int transOffset = errTransOffset;

		/* The transition may not be set. */
		if ( outIt->value != 0 ) {
			TransSetEl *tsel = transSet.find( transEl->value );
			transOffset = tsel->value;
		}

		/* Set the index for this character. */
		machState->rangeIndKey[wi] = transEl[0].key;
		machState->rangeIndKey[wi+1] = transEl[1].key;
		machState->rangeIndPtr[wj] = transOffset;
	}

	/* Make the default transition. If not there it will remain as err. */
	if ( state->outDefault != 0 ) {
		/* There is default transition, find it. */
		TransSetEl *tsel = transSet.find( state->outDefault );
		machState->dflIndex = tsel->value;
	}
	else {
		/* No default transition. */
		machState->dflIndex  = errTransOffset;
	}
}

/* Construct a compact runnable machine from this graph. Machine is put in
 * the machine object passed in. */
void BuildData::build()
{
	/* Get the signedness of the alphabet. */
	machine->isAlphSigned = graph->isAlphSigned;

	/* Get the number of final states. */
	machine->numFinStates = graph->finStateSet.length();

	/* Create the machine states. */
	initMachineStates();

	/* Before reducing actions, all action keys should be zero so that they
	 * don't interfere with the reduction. */
	graph->nullActionKeys();

	/* Make the global error transition. The rest of the fsm building code
	 * works on the assumption that the error trans is index 0. */
	transSet.insert( new TransAp(), curTransOffset++ );

	/* Reduce the actions and then the transitions. */
	reduceActions();
	reduceTransitions();

	/* Make the array of functions from the transFuncSet. */
	buildFunctionLists();

	/* Make the global array of unique transitions. */
	buildTransitionArray();

	/* For each state build the machine state. */
	FsmAp::StateList::Iter state = graph->stateList;
	for ( int snum = 0; state.lte(); state++, snum++ ) {
		/* Get the fsm state. */
		FsmMachState *machState = state->alg.machState;

		/* Use the base class to make the machine state. */
		buildMachineState( machState, state, snum );

		/* Set the state's out functions in the state. */
		if ( state->outActionTable.length() == 0 ) {
			/* No functions for this transition. */
			machState->outFuncs = FUNC_NO_FUNC;
		}
		else {
			/* Find the function in the func map. */
			TransFuncSetEl *tfsel = transFuncSet.find( state->outActionTable );
			machState->outFuncs = tfsel->value;
		}
	}

	/* The graph needs to be cleared out by a delete that is aware that the
	 * transitions have been reduced. */
	emptyReduced();
}

/* Build a machine from a graph. */
void buildMachine( FsmMachine *machine, FsmAp *graph )
{
	/* Make a build data structure and have it build the machine. */
	BuildData buildData(machine, graph);
	buildData.build();
}

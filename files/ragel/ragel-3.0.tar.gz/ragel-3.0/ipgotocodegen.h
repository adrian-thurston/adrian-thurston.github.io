/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _IPGCODEGEN_H
#define _IPGCODEGEN_H

#include <iostream>
#include "gotocodegen.h"

/* Forwards. */
struct FsmMachine;
struct FsmMachState;
struct FsmMachTrans;
struct ParseData;

/*
 * class FGotoCodeGen
 */
class IpGotoCodeGen : public GotoCodeGen
{
public:
	IpGotoCodeGen( char *fsmName, ParseData *parseData, 
			FsmMachine *machine, std::ostream &out );

	std::ostream &GOTO( NameInst *name );
	std::ostream &TRANS_GOTO( FsmMachTrans *trans, int level );
	std::ostream &FINISH_CASES();

protected:
	/* Called from GotoCodeGen::STATE_GOTOS just before writing the gotos for
	 * each state. */
	void aboveStateGotos( int st );

	/* Set up labelNeeded flag for each state. */
	void setLabelsNeeded();
};


/*
 * class CIpGotoCodeGen
 */
class CIpGotoCodeGen : public IpGotoCodeGen
{
public:
	CIpGotoCodeGen( char *fsmName, ParseData *parseData, 
			FsmMachine *machine, std::ostream &out );

	std::ostream &CALL( NameInst *name, int targState );
	std::ostream &RET();

	virtual void writeOutHeader();
	virtual void writeOutCode();
};


/*
 * class CCIpGotoCodeGen
 */
class CCIpGotoCodeGen : public IpGotoCodeGen
{
public:
	CCIpGotoCodeGen( char *fsmName, ParseData *parseData, 
			FsmMachine *machine, std::ostream &out );

	std::ostream &CALL( NameInst *name, int targState );
	std::ostream &RET();

	virtual void writeOutHeader();
	virtual void writeOutCode();
};

#endif /* _IPGCODEGEN_H */

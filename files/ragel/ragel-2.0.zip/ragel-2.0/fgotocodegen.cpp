/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "fgotocodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"


/* Init base data. */
FGotoCodeGen::FGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
: 
	GotoCodeGen(fsmName, parseData, machine, out)
{ }

std::ostream &FGotoCodeGen::EXEC_FUNCS()
{
	/* Loop over all func indicies. */
	int *transFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "f" << i << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = transFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			/* Get the function data. */
			ActionListEl *flel = parseData->actionIndex[*funcs];

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

			/* Wrap the block in brakets. */
			out << "\t{" << flel->data << "}\n";
			funcs += 1;
		}
		out << "\tgoto again;\n";
	}

	/* Write the directive for going back into the output file. The line
	 * number is for the next line, so add one. */
	out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";

	return out;
}

std::ostream &FGotoCodeGen::FINISH_CASES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;
		if ( state->isFinState && state->outFuncs != FUNC_NO_FUNC ) {
			/* Write the case label. */
			out << "\t\tcase " << st << ": ";

			/* Jump to the func. */
			out << "goto f" << state->outFuncs << ";\n";
		}
	}

	return out;
}

/* Init base data. */
CFGotoCodeGen::CFGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, machine, out)
{ }

/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CFGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}

void CFGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( fsm->curState >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = fsm->curState;\n"
		"\n";
	
	if ( anyOutTransFuncs() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out << 
		"again:\n"
		"	if ( cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( --len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"finishInput:\n"
			"	len = 1;\n"
			"	switch( cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"	if ( cs == 0 )\n"
			"		goto out_err;\n"
			"\n";
	}

	out << 
		"out_ok:\n"
		"	fsm->curState = cs;\n"
		"	if ( cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	fsm->curState = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyOutTransFuncs() ) {
		/* Call into execute to invoke out actions. */
		out << "	return "; FSM_NAME() << "_execute( fsm, 0, -1 );\n";
	}
	else {
		out << 
			"	if ( fsm->curState == 0 )\n"
			"		return -1;\n"
			"	if ( fsm->curState >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out << 
		"}\n"
		"\n";
}

/* Init base data. */
CCFGotoCodeGen::CCFGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, machine, out)
{ }

/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCFGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCFGotoCodeGen::writeOutHeader()
{
	out << 
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Init the fsm. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( this->curState >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = this->curState;\n"
		"\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out << 
		"again:\n"
		"	if ( cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( --len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() << "\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"finishInput:\n"
			"	len = 1;\n"
			"	switch( cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"	if ( cs == 0 )\n"
			"		goto out_err;\n"
			"\n";
	}

	out <<
		"out_ok:\n"
		"	this->curState = cs;\n"
		"	if ( cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	this->curState = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";

	if ( anyOutTransFuncs() ) {
		/* May need to execute action code. Call into exectue to handle the
		 * finishing code. */
		out << "	return execute( 0, -1 );\n";
	}
	else {
		out << 
			"	if ( this->curState == 0 )\n"
			"		return -1;\n"
			"	if ( this->curState >= "; FIRST_FINAL_STATE() << " )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out <<
		"}\n"
		"\n";
}

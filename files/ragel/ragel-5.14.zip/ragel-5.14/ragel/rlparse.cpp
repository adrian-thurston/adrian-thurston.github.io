/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Using locations.  */
#define YYLSP_NEEDED 1



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TK_Section = 258,
     TK_SectionNL = 259,
     TK_UInt = 260,
     TK_Hex = 261,
     TK_Word = 262,
     TK_Literal = 263,
     TK_CiLiteral = 264,
     TK_BaseClause = 265,
     TK_DotDot = 266,
     TK_ColonGt = 267,
     TK_ColonGtGt = 268,
     TK_LtColon = 269,
     TK_Arrow = 270,
     TK_ReverseArrow = 271,
     TK_DoubleArrow = 272,
     TK_StarStar = 273,
     TK_ColonEquals = 274,
     TK_NameSep = 275,
     TK_BarStar = 276,
     TK_RepOpOpen = 277,
     TK_DashDash = 278,
     TK_StartCond = 279,
     TK_AllCond = 280,
     TK_LeavingCond = 281,
     TK_StartGblError = 282,
     TK_AllGblError = 283,
     TK_FinalGblError = 284,
     TK_NotFinalGblError = 285,
     TK_NotStartGblError = 286,
     TK_MiddleGblError = 287,
     TK_StartLocalError = 288,
     TK_AllLocalError = 289,
     TK_FinalLocalError = 290,
     TK_NotFinalLocalError = 291,
     TK_NotStartLocalError = 292,
     TK_MiddleLocalError = 293,
     TK_StartEOF = 294,
     TK_AllEOF = 295,
     TK_FinalEOF = 296,
     TK_NotFinalEOF = 297,
     TK_NotStartEOF = 298,
     TK_MiddleEOF = 299,
     TK_StartToState = 300,
     TK_AllToState = 301,
     TK_FinalToState = 302,
     TK_NotFinalToState = 303,
     TK_NotStartToState = 304,
     TK_MiddleToState = 305,
     TK_StartFromState = 306,
     TK_AllFromState = 307,
     TK_FinalFromState = 308,
     TK_NotFinalFromState = 309,
     TK_NotStartFromState = 310,
     TK_MiddleFromState = 311,
     RE_Slash = 312,
     RE_SqOpen = 313,
     RE_SqOpenNeg = 314,
     RE_SqClose = 315,
     RE_Dot = 316,
     RE_Star = 317,
     RE_Dash = 318,
     RE_Char = 319,
     IL_WhiteSpace = 320,
     IL_Comment = 321,
     IL_Literal = 322,
     IL_Symbol = 323,
     KW_Action = 324,
     KW_AlphType = 325,
     KW_Range = 326,
     KW_GetKey = 327,
     KW_Include = 328,
     KW_Write = 329,
     KW_Machine = 330,
     KW_When = 331,
     KW_Enter = 332,
     KW_All = 333,
     KW_Finish = 334,
     KW_Leave = 335,
     KW_Start = 336,
     KW_Final = 337,
     KW_Break = 338,
     KW_Exec = 339,
     KW_Pri = 340,
     KW_On = 341,
     KW_Into = 342,
     KW_From = 343,
     KW_EOF = 344,
     KW_Err = 345,
     KW_LErr = 346,
     KW_Hold = 347,
     KW_PChar = 348,
     KW_Char = 349,
     KW_Goto = 350,
     KW_Call = 351,
     KW_Ret = 352,
     KW_CurState = 353,
     KW_TargState = 354,
     KW_Entry = 355,
     KW_Next = 356,
     KW_Variable = 357,
     KW_Access = 358,
     TK_Semi = 359,
     EXPR_MINUS = 360
   };
#endif
/* Tokens.  */
#define TK_Section 258
#define TK_SectionNL 259
#define TK_UInt 260
#define TK_Hex 261
#define TK_Word 262
#define TK_Literal 263
#define TK_CiLiteral 264
#define TK_BaseClause 265
#define TK_DotDot 266
#define TK_ColonGt 267
#define TK_ColonGtGt 268
#define TK_LtColon 269
#define TK_Arrow 270
#define TK_ReverseArrow 271
#define TK_DoubleArrow 272
#define TK_StarStar 273
#define TK_ColonEquals 274
#define TK_NameSep 275
#define TK_BarStar 276
#define TK_RepOpOpen 277
#define TK_DashDash 278
#define TK_StartCond 279
#define TK_AllCond 280
#define TK_LeavingCond 281
#define TK_StartGblError 282
#define TK_AllGblError 283
#define TK_FinalGblError 284
#define TK_NotFinalGblError 285
#define TK_NotStartGblError 286
#define TK_MiddleGblError 287
#define TK_StartLocalError 288
#define TK_AllLocalError 289
#define TK_FinalLocalError 290
#define TK_NotFinalLocalError 291
#define TK_NotStartLocalError 292
#define TK_MiddleLocalError 293
#define TK_StartEOF 294
#define TK_AllEOF 295
#define TK_FinalEOF 296
#define TK_NotFinalEOF 297
#define TK_NotStartEOF 298
#define TK_MiddleEOF 299
#define TK_StartToState 300
#define TK_AllToState 301
#define TK_FinalToState 302
#define TK_NotFinalToState 303
#define TK_NotStartToState 304
#define TK_MiddleToState 305
#define TK_StartFromState 306
#define TK_AllFromState 307
#define TK_FinalFromState 308
#define TK_NotFinalFromState 309
#define TK_NotStartFromState 310
#define TK_MiddleFromState 311
#define RE_Slash 312
#define RE_SqOpen 313
#define RE_SqOpenNeg 314
#define RE_SqClose 315
#define RE_Dot 316
#define RE_Star 317
#define RE_Dash 318
#define RE_Char 319
#define IL_WhiteSpace 320
#define IL_Comment 321
#define IL_Literal 322
#define IL_Symbol 323
#define KW_Action 324
#define KW_AlphType 325
#define KW_Range 326
#define KW_GetKey 327
#define KW_Include 328
#define KW_Write 329
#define KW_Machine 330
#define KW_When 331
#define KW_Enter 332
#define KW_All 333
#define KW_Finish 334
#define KW_Leave 335
#define KW_Start 336
#define KW_Final 337
#define KW_Break 338
#define KW_Exec 339
#define KW_Pri 340
#define KW_On 341
#define KW_Into 342
#define KW_From 343
#define KW_EOF 344
#define KW_Err 345
#define KW_LErr 346
#define KW_Hold 347
#define KW_PChar 348
#define KW_Char 349
#define KW_Goto 350
#define KW_Call 351
#define KW_Ret 352
#define KW_CurState 353
#define KW_TargState 354
#define KW_Entry 355
#define KW_Next 356
#define KW_Variable 357
#define KW_Access 358
#define TK_Semi 359
#define EXPR_MINUS 360




/* Copy the first part of user declarations.  */
#line 22 "rlparse.y"


#include <iostream>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include "ragel.h"
#include "parsetree.h"
#include "rlparse.h"

using std::cerr;
using std::endl;

InputData *id = 0;
int includeDepth = 0;

SectionMap sectionMap;

extern bool inlineWhitespace;

/* These come from the scanner and point back into the parser. We will borrow
 * them for error reporting. */
extern YYSTYPE *yylval;
extern YYLTYPE *yylloc;

/* The include stack pointer from the scanner. Used to determine if we are
 * currently processing an included file. */
extern int inc_stack_ptr;

/* Try to do a definition, common to assignment and instantiation. */
void tryMachineDef( const YYLTYPE &loc, char *name, 
		JoinOrLm *joinOrLm, bool isInstance );
void beginOutsideCode();
void doInclude( const InputLoc &loc, char *sectionName, char *inputFile );
int yylex( YYSTYPE *yylval, YYLTYPE *yylloc );

bool sectionOpened;
void openSection();

#define WO_NOEND 0x01



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 67 "rlparse.y"
typedef union YYSTYPE {
	/* General data types. */
	char c;
	TokenData data;
	int integer;
	Literal *literal;

	/* Tree nodes. */
	Term *term;
	FactorWithAug *factorWithAug;
	FactorWithRep *factorWithRep;
	FactorWithNeg *factorWithNeg;
	Factor *factor;
	Expression *expression;
	Join *join;
	JoinOrLm *joinOrLm;
	LmPartList *longestMatchList;
	LongestMatchPart *longestMatchPart;

	/* Priorities and actions. */
	AugType augType;
	StateAugType stateAugType;
	Action *action;
	PriorDesc *priorDesc;

	/* Regular expression items. */
	RegExpr *regExp;
	ReItem *reItem;
	ReOrBlock *reOrBlock;
	ReOrItem *reOrItem;

	/* Inline parse tree items. */
	InlineItem *ilitem;
	InlineList *illist;
} YYSTYPE;
/* Line 196 of yacc.c.  */
#line 374 "rlparse.cpp"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 219 of yacc.c.  */
#line 398 "rlparse.cpp"

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T) && (defined (__STDC__) || defined (__cplusplus))
# include <stddef.h> /* INFRINGES ON USER NAME SPACE */
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if defined (__STDC__) || defined (__cplusplus)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     define YYINCLUDED_STDLIB_H
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2005 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM ((YYSIZE_T) -1)
#  endif
#  ifdef __cplusplus
extern "C" {
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if (! defined (malloc) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if (! defined (free) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifdef __cplusplus
}
#  endif
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYLTYPE_IS_TRIVIAL) && YYLTYPE_IS_TRIVIAL \
             && defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short int yyss;
  YYSTYPE yyvs;
    YYLTYPE yyls;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short int) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short int yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   784

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  127
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  89
/* YYNRULES -- Number of rules. */
#define YYNRULES  265
/* YYNRULES -- Number of states. */
#define YYNSTATES  408

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   360

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   108,     2,     2,   118,   117,   121,     2,
     110,   111,   105,   107,   113,   119,   122,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   115,   112,
       2,   114,   123,   106,   116,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,   109,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   125,   120,   126,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     124
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     5,     8,     9,    14,    16,    20,    21,
      23,    25,    28,    29,    31,    33,    35,    37,    39,    41,
      43,    45,    47,    49,    52,    58,    63,    67,    71,    76,
      80,    83,    86,    87,    91,    95,   100,   102,   104,   105,
     107,   108,   113,   118,   120,   122,   127,   131,   133,   137,
     141,   145,   149,   151,   154,   158,   162,   166,   170,   172,
     176,   178,   182,   184,   187,   188,   191,   193,   194,   198,
     200,   202,   204,   206,   208,   210,   212,   214,   216,   218,
     222,   228,   232,   240,   246,   254,   262,   266,   268,   270,
     272,   274,   278,   284,   288,   294,   298,   304,   308,   314,
     318,   326,   332,   340,   348,   350,   352,   354,   356,   359,
     362,   364,   366,   368,   370,   372,   374,   376,   378,   380,
     382,   384,   386,   388,   390,   393,   396,   401,   403,   405,
     408,   411,   416,   418,   420,   422,   424,   426,   428,   430,
     432,   434,   436,   438,   440,   442,   444,   446,   448,   450,
     452,   454,   456,   458,   460,   462,   464,   466,   468,   470,
     472,   474,   476,   478,   480,   482,   486,   489,   492,   495,
     498,   503,   509,   515,   522,   524,   526,   529,   532,   534,
     536,   538,   540,   542,   546,   550,   554,   558,   562,   566,
     569,   571,   573,   575,   579,   582,   584,   585,   587,   590,
     592,   595,   596,   598,   600,   602,   604,   606,   608,   610,
     612,   614,   616,   618,   620,   622,   624,   626,   628,   630,
     635,   641,   647,   654,   660,   667,   673,   680,   685,   690,
     691,   692,   695,   696,   698,   700,   702,   704,   706,   708,
     710,   717,   719,   721,   723,   725,   727,   729,   731,   733,
     735,   737,   739,   742,   743,   746,   748,   752,   756,   758,
     760,   763,   764,   766,   770,   772
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     128,     0,    -1,   129,    -1,   129,   130,    -1,    -1,   131,
     132,   134,   133,    -1,     3,    -1,    75,     7,   112,    -1,
      -1,     3,    -1,     4,    -1,   134,   135,    -1,    -1,   149,
      -1,   150,    -1,   136,    -1,   137,    -1,   138,    -1,   139,
      -1,   145,    -1,   140,    -1,   143,    -1,   144,    -1,     1,
     112,    -1,    69,     7,   125,   198,   126,    -1,    70,     7,
       7,   104,    -1,    70,     7,   104,    -1,    72,   198,   104,
      -1,    71,   197,   197,   112,    -1,   141,   142,   112,    -1,
      74,     7,    -1,   142,     7,    -1,    -1,   103,   198,   104,
      -1,   102,   198,   104,    -1,   146,   147,   148,   112,    -1,
      73,    -1,     7,    -1,    -1,     8,    -1,    -1,   151,   114,
     153,   112,    -1,   151,    19,   152,   112,    -1,     7,    -1,
     153,    -1,    21,   194,   105,   120,    -1,   153,   113,   154,
      -1,   154,    -1,   154,   120,   155,    -1,   154,   121,   155,
      -1,   154,   119,   155,    -1,   154,    23,   155,    -1,   155,
      -1,   155,   156,    -1,   155,   122,   156,    -1,   155,    12,
     156,    -1,   155,    13,   156,    -1,   155,    14,   156,    -1,
     156,    -1,     7,   115,   156,    -1,   157,    -1,   157,    15,
     158,    -1,   163,    -1,   159,   162,    -1,    -1,   161,   162,
      -1,    20,    -1,    -1,   162,    20,     7,    -1,     7,    -1,
     164,    -1,   165,    -1,   166,    -1,   168,    -1,   169,    -1,
     170,    -1,   171,    -1,   172,    -1,   190,    -1,   163,   177,
     187,    -1,   163,    16,   178,    84,   187,    -1,   163,   177,
     175,    -1,   163,   177,   110,   173,   113,   175,   111,    -1,
     163,    16,   178,    85,   175,    -1,   163,    16,   179,    86,
     173,    85,   175,    -1,   163,    16,    78,    86,   173,    85,
     175,    -1,   163,   167,   187,    -1,    24,    -1,    25,    -1,
      26,    -1,    76,    -1,   163,   185,   187,    -1,   163,    16,
     180,    87,   187,    -1,   163,   186,   187,    -1,   163,    16,
     180,    88,   187,    -1,   163,   184,   187,    -1,   163,    16,
     180,    89,   187,    -1,   163,   182,   187,    -1,   163,    16,
     180,    90,   187,    -1,   163,   183,   187,    -1,   163,   183,
     110,   174,   113,   187,   111,    -1,   163,    16,   180,    91,
     187,    -1,   163,    16,   181,    86,   174,    91,   187,    -1,
     163,    16,    78,    86,   174,    91,   187,    -1,     7,    -1,
       7,    -1,   176,    -1,     5,    -1,   107,     5,    -1,   119,
       5,    -1,   116,    -1,   117,    -1,   118,    -1,   123,    -1,
      79,    -1,    80,    -1,    78,    -1,    77,    -1,    79,    -1,
      80,    -1,    77,    -1,    81,    -1,    78,    -1,    82,    -1,
     108,    81,    -1,   108,    82,    -1,   108,    81,   108,    82,
      -1,    81,    -1,    82,    -1,   108,    81,    -1,   108,    82,
      -1,   108,    81,   108,    82,    -1,    27,    -1,    28,    -1,
      29,    -1,    31,    -1,    30,    -1,    32,    -1,    33,    -1,
      34,    -1,    35,    -1,    37,    -1,    36,    -1,    38,    -1,
      39,    -1,    40,    -1,    41,    -1,    43,    -1,    42,    -1,
      44,    -1,    45,    -1,    46,    -1,    47,    -1,    49,    -1,
      48,    -1,    50,    -1,    51,    -1,    52,    -1,    53,    -1,
      55,    -1,    54,    -1,    56,    -1,   188,    -1,   189,    -1,
       7,    -1,   125,   198,   126,    -1,   190,   105,    -1,   190,
      18,    -1,   190,   106,    -1,   190,   107,    -1,   190,    22,
     191,   126,    -1,   190,    22,   113,   191,   126,    -1,   190,
      22,   191,   113,   126,    -1,   190,    22,   191,   113,   191,
     126,    -1,   192,    -1,     5,    -1,   108,   192,    -1,   109,
     192,    -1,   193,    -1,     8,    -1,     9,    -1,   197,    -1,
       7,    -1,    58,   213,    60,    -1,    59,   213,    60,    -1,
      57,   210,    57,    -1,   215,    11,   215,    -1,   110,   153,
     111,    -1,   110,     1,   111,    -1,   194,   195,    -1,   195,
      -1,   136,    -1,   149,    -1,   153,   196,   112,    -1,    17,
     187,    -1,   189,    -1,    -1,     5,    -1,   119,     5,    -1,
       6,    -1,   198,   199,    -1,    -1,   200,    -1,   201,    -1,
     202,    -1,    65,    -1,    66,    -1,    67,    -1,    68,    -1,
       5,    -1,     6,    -1,     7,    -1,   113,    -1,   112,    -1,
     110,    -1,   111,    -1,   105,    -1,    20,    -1,   207,    -1,
      92,   203,   112,   204,    -1,    84,   203,   205,   112,   204,
      -1,    95,   203,   160,   112,   204,    -1,    95,   203,   105,
     204,   205,   112,    -1,   101,   203,   160,   112,   204,    -1,
     101,   203,   105,   204,   205,   112,    -1,    96,   203,   160,
     112,   204,    -1,    96,   203,   105,   204,   205,   112,    -1,
      97,   203,   112,   204,    -1,    83,   203,   112,   204,    -1,
      -1,    -1,   205,   206,    -1,    -1,   208,    -1,   209,    -1,
     207,    -1,    93,    -1,    94,    -1,    98,    -1,    99,    -1,
     100,   203,   110,   160,   111,   204,    -1,    65,    -1,    66,
      -1,    67,    -1,    68,    -1,     5,    -1,     6,    -1,     7,
      -1,   110,    -1,   111,    -1,   105,    -1,    20,    -1,   210,
     211,    -1,    -1,   212,    62,    -1,   212,    -1,    58,   213,
      60,    -1,    59,   213,    60,    -1,    61,    -1,    64,    -1,
     213,   214,    -1,    -1,    64,    -1,    64,    63,    64,    -1,
       8,    -1,   197,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   318,   318,   320,   320,   327,   341,   352,   373,   383,
     384,   388,   388,   393,   394,   395,   396,   397,   398,   399,
     400,   401,   402,   405,   410,   430,   439,   449,   456,   468,
     474,   489,   492,   496,   502,   512,   518,   525,   525,   526,
     526,   530,   548,   556,   574,   577,   589,   594,   602,   605,
     608,   611,   614,   619,   622,   625,   628,   631,   634,   639,
     644,   647,   652,   656,   660,   666,   670,   675,   681,   684,
     690,   691,   692,   693,   694,   695,   696,   697,   698,   703,
     709,   717,   724,   729,   736,   743,   750,   756,   757,   758,
     759,   762,   767,   774,   779,   786,   791,   798,   806,   817,
     825,   831,   840,   848,   858,   871,   885,   906,   907,   910,
     918,   919,   920,   921,   926,   927,   928,   929,   933,   934,
     935,   939,   940,   941,   942,   943,   944,   948,   949,   950,
     951,   952,   956,   957,   958,   959,   960,   961,   965,   966,
     967,   968,   969,   970,   974,   975,   976,   977,   978,   979,
     983,   984,   985,   986,   987,   988,   992,   993,   994,   995,
     996,   997,  1004,  1004,  1007,  1024,  1036,  1040,  1044,  1048,
    1052,  1056,  1060,  1064,  1068,  1073,  1090,  1093,  1096,  1104,
    1108,  1113,  1117,  1138,  1142,  1146,  1157,  1161,  1167,  1170,
    1175,  1183,  1184,  1185,  1196,  1197,  1198,  1203,  1204,  1209,
    1212,  1217,  1224,  1228,  1232,  1239,  1239,  1239,  1239,  1240,
    1240,  1240,  1244,  1245,  1246,  1247,  1248,  1249,  1253,  1257,
    1260,  1264,  1267,  1271,  1274,  1278,  1281,  1285,  1288,  1293,
    1296,  1299,  1303,  1309,  1313,  1317,  1323,  1326,  1329,  1332,
    1335,  1340,  1340,  1340,  1340,  1341,  1341,  1341,  1346,  1347,
    1348,  1349,  1354,  1373,  1380,  1384,  1391,  1394,  1397,  1400,
    1407,  1427,  1435,  1438,  1443,  1451
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TK_Section", "TK_SectionNL", "TK_UInt",
  "TK_Hex", "TK_Word", "TK_Literal", "TK_CiLiteral", "TK_BaseClause",
  "TK_DotDot", "TK_ColonGt", "TK_ColonGtGt", "TK_LtColon", "TK_Arrow",
  "TK_ReverseArrow", "TK_DoubleArrow", "TK_StarStar", "TK_ColonEquals",
  "TK_NameSep", "TK_BarStar", "TK_RepOpOpen", "TK_DashDash",
  "TK_StartCond", "TK_AllCond", "TK_LeavingCond", "TK_StartGblError",
  "TK_AllGblError", "TK_FinalGblError", "TK_NotFinalGblError",
  "TK_NotStartGblError", "TK_MiddleGblError", "TK_StartLocalError",
  "TK_AllLocalError", "TK_FinalLocalError", "TK_NotFinalLocalError",
  "TK_NotStartLocalError", "TK_MiddleLocalError", "TK_StartEOF",
  "TK_AllEOF", "TK_FinalEOF", "TK_NotFinalEOF", "TK_NotStartEOF",
  "TK_MiddleEOF", "TK_StartToState", "TK_AllToState", "TK_FinalToState",
  "TK_NotFinalToState", "TK_NotStartToState", "TK_MiddleToState",
  "TK_StartFromState", "TK_AllFromState", "TK_FinalFromState",
  "TK_NotFinalFromState", "TK_NotStartFromState", "TK_MiddleFromState",
  "RE_Slash", "RE_SqOpen", "RE_SqOpenNeg", "RE_SqClose", "RE_Dot",
  "RE_Star", "RE_Dash", "RE_Char", "IL_WhiteSpace", "IL_Comment",
  "IL_Literal", "IL_Symbol", "KW_Action", "KW_AlphType", "KW_Range",
  "KW_GetKey", "KW_Include", "KW_Write", "KW_Machine", "KW_When",
  "KW_Enter", "KW_All", "KW_Finish", "KW_Leave", "KW_Start", "KW_Final",
  "KW_Break", "KW_Exec", "KW_Pri", "KW_On", "KW_Into", "KW_From", "KW_EOF",
  "KW_Err", "KW_LErr", "KW_Hold", "KW_PChar", "KW_Char", "KW_Goto",
  "KW_Call", "KW_Ret", "KW_CurState", "KW_TargState", "KW_Entry",
  "KW_Next", "KW_Variable", "KW_Access", "TK_Semi", "'*'", "'?'", "'+'",
  "'!'", "'^'", "'('", "')'", "';'", "','", "'='", "':'", "'@'", "'%'",
  "'$'", "'-'", "'|'", "'&'", "'.'", "'>'", "EXPR_MINUS", "'{'", "'}'",
  "$accept", "input", "FsmSpecList", "FsmSpec", "StartSection",
  "SectionName", "EndSection", "StatementList", "Statement", "ActionSpec",
  "AlphSpec", "GetKeySpec", "RangeSpec", "Write", "WriteOpen",
  "WriteOptions", "Access", "Variable", "Include", "IncludeKeyword",
  "OptSection", "OptFileName", "Assignment", "Instantiation",
  "MachineName", "JoinOrLm", "Join", "Expression", "Term",
  "FactorWithLabel", "FactorWithEp", "LocalStateRef", "NoNameSep",
  "StateRef", "OptNameSep", "StateRefNames", "FactorWithAug",
  "FactorWithTransAction", "FactorWithPriority", "FactorWithCond",
  "AugTypeCond", "FactorWithToStateAction", "FactorWithFromStateAction",
  "FactorWithEOFAction", "FactorWithGblErrorAction",
  "FactorWithLocalErrorAction", "PriorityName", "LocalErrName",
  "PriorityAug", "PriorityAugNum", "AugTypeBase", "AugTypeBaseVerb",
  "AugTypeBaseVerbNoAll", "AugTypeStateVerb", "AugTypeStateVerbNoAll",
  "AugTypeGblError", "AugTypeLocalError", "AugTypeEOF", "AugTypeToState",
  "AugTypeFromState", "ActionEmbed", "ActionEmbedWord", "ActionEmbedBlock",
  "FactorWithRep", "FactorRepNum", "FactorWithNeg", "Factor", "LmPartList",
  "LongestMatchPart", "OptLmPartAction", "AlphabetNum", "InlineBlock",
  "InlineBlockItem", "InlineBlockAny", "InlineBlockSymbol",
  "InlineBlockInterpret", "SetNoWs", "SetWs", "InlineExpr",
  "InlineExprItem", "InlineExprInterpret", "InlineExprAny",
  "InlineExprSymbol", "RegularExpr", "RegularExprItem", "RegularExprChar",
  "RegularExprOrData", "RegularExprOrChar", "RangeLit", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short int yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,    42,    63,    43,    33,    94,
      40,    41,    59,    44,    61,    58,    64,    37,    36,    45,
     124,    38,    46,    62,   360,   123,   125
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   127,   128,   129,   129,   130,   131,   132,   132,   133,
     133,   134,   134,   135,   135,   135,   135,   135,   135,   135,
     135,   135,   135,   135,   136,   137,   137,   138,   139,   140,
     141,   142,   142,   143,   144,   145,   146,   147,   147,   148,
     148,   149,   150,   151,   152,   152,   153,   153,   154,   154,
     154,   154,   154,   155,   155,   155,   155,   155,   155,   156,
     156,   157,   157,   158,   159,   160,   161,   161,   162,   162,
     163,   163,   163,   163,   163,   163,   163,   163,   163,   164,
     164,   165,   165,   165,   165,   165,   166,   167,   167,   167,
     167,   168,   168,   169,   169,   170,   170,   171,   171,   172,
     172,   172,   172,   172,   173,   174,   175,   176,   176,   176,
     177,   177,   177,   177,   178,   178,   178,   178,   179,   179,
     179,   180,   180,   180,   180,   180,   180,   181,   181,   181,
     181,   181,   182,   182,   182,   182,   182,   182,   183,   183,
     183,   183,   183,   183,   184,   184,   184,   184,   184,   184,
     185,   185,   185,   185,   185,   185,   186,   186,   186,   186,
     186,   186,   187,   187,   188,   189,   190,   190,   190,   190,
     190,   190,   190,   190,   190,   191,   192,   192,   192,   193,
     193,   193,   193,   193,   193,   193,   193,   193,   193,   194,
     194,   195,   195,   195,   196,   196,   196,   197,   197,   197,
     198,   198,   199,   199,   199,   200,   200,   200,   200,   200,
     200,   200,   201,   201,   201,   201,   201,   201,   202,   202,
     202,   202,   202,   202,   202,   202,   202,   202,   202,   203,
     204,   205,   205,   206,   206,   206,   207,   207,   207,   207,
     207,   208,   208,   208,   208,   208,   208,   208,   209,   209,
     209,   209,   210,   210,   211,   211,   212,   212,   212,   212,
     213,   213,   214,   214,   215,   215
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     2,     0,     4,     1,     3,     0,     1,
       1,     2,     0,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     2,     5,     4,     3,     3,     4,     3,
       2,     2,     0,     3,     3,     4,     1,     1,     0,     1,
       0,     4,     4,     1,     1,     4,     3,     1,     3,     3,
       3,     3,     1,     2,     3,     3,     3,     3,     1,     3,
       1,     3,     1,     2,     0,     2,     1,     0,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     3,
       5,     3,     7,     5,     7,     7,     3,     1,     1,     1,
       1,     3,     5,     3,     5,     3,     5,     3,     5,     3,
       7,     5,     7,     7,     1,     1,     1,     1,     2,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     2,     4,     1,     1,     2,
       2,     4,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     2,     2,     2,     2,
       4,     5,     5,     6,     1,     1,     2,     2,     1,     1,
       1,     1,     1,     3,     3,     3,     3,     3,     3,     2,
       1,     1,     1,     3,     2,     1,     0,     1,     2,     1,
       2,     0,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     4,
       5,     5,     6,     5,     6,     5,     6,     4,     4,     0,
       0,     2,     0,     1,     1,     1,     1,     1,     1,     1,
       6,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     0,     2,     1,     3,     3,     1,     1,
       2,     0,     1,     3,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned short int yydefact[] =
{
       4,     0,     2,     1,     6,     3,     8,     0,    12,     0,
       0,     7,     0,     9,    10,    43,     0,     0,     0,   201,
      36,     0,   201,   201,     5,    11,    15,    16,    17,    18,
      20,    32,    21,    22,    19,    38,    13,    14,     0,    23,
       0,     0,   197,   199,     0,     0,     0,    30,     0,     0,
       0,    37,    40,     0,     0,   201,     0,    26,   198,     0,
     209,   210,   211,   217,   205,   206,   207,   208,   229,   229,
     229,   236,   237,   229,   229,   229,   238,   239,   229,   229,
      27,   216,   214,   215,   213,   212,   200,   202,   203,   204,
     218,    34,    33,    31,    29,    39,     0,   182,   179,   180,
       0,   253,   261,   261,     0,     0,     0,     0,    44,    47,
      52,    58,    60,    62,    70,    71,    72,    73,    74,    75,
      76,    77,    78,   174,   178,   181,     0,     0,     0,    25,
      28,     0,   232,     0,    67,    67,     0,     0,    67,    35,
       0,   182,   191,   192,     0,   196,     0,   190,     0,     0,
       0,   182,   176,   177,     0,     0,    42,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    53,    64,     0,    87,
      88,    89,   132,   133,   134,   136,   135,   137,   138,   139,
     140,   142,   141,   143,   144,   145,   146,   148,   147,   149,
     150,   151,   152,   154,   153,   155,   156,   157,   158,   160,
     159,   161,    90,   110,   111,   112,   113,     0,     0,     0,
       0,     0,     0,     0,   167,     0,   166,   168,   169,     0,
      41,    24,   230,     0,   230,    66,   230,     0,     0,   230,
       0,   230,    67,   230,     0,    59,     0,   201,   195,     0,
       0,   189,   185,   261,   261,   258,   259,   252,   255,   183,
     262,   260,   184,   188,   187,    46,    51,    50,    48,    49,
      55,    56,    57,    54,    61,     0,   117,   122,   114,   115,
     121,   123,     0,     0,     0,     0,     0,   164,    86,   162,
     163,   107,     0,     0,     0,    81,   106,    79,    97,     0,
      99,    95,    91,    93,   175,     0,     0,   264,   265,   186,
     228,   245,   246,   247,   251,   241,   242,   243,   244,   250,
     248,   249,   230,   231,   235,   233,   234,   219,   232,   230,
      69,    65,   232,   230,   227,     0,   232,   230,   194,     0,
     193,    45,     0,     0,   254,     0,    63,     0,   124,   125,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   108,
     104,     0,   109,   105,     0,     0,     0,   170,   220,     0,
     221,     0,     0,   225,   230,     0,   223,   165,   256,   257,
     263,   104,     0,     0,     0,    80,    83,     0,    92,    94,
      96,    98,   101,     0,     0,     0,   171,   172,     0,   222,
      68,   226,   240,   224,     0,     0,   126,     0,     0,     0,
       0,   173,    85,   103,    84,   102,    82,   100
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     1,     2,     5,     6,     8,    24,    10,    25,   142,
      27,    28,    29,    30,    31,    50,    32,    33,    34,    35,
      52,    96,   143,    37,   144,   107,   145,   109,   110,   111,
     112,   264,   265,   227,   228,   321,   113,   114,   115,   116,
     207,   117,   118,   119,   120,   121,   351,   354,   285,   286,
     208,   273,   274,   275,   276,   209,   210,   211,   212,   213,
     278,   279,   280,   122,   296,   123,   124,   146,   147,   239,
     125,    46,    86,    87,    88,    89,   131,   300,   223,   313,
      90,   315,   316,   148,   247,   248,   149,   251,   126
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -315
static const short int yypact[] =
{
    -315,    49,    54,  -315,  -315,  -315,    56,   127,  -315,   -37,
      96,  -315,    48,  -315,  -315,  -315,   175,   177,    40,  -315,
    -315,   190,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,   194,  -315,  -315,    13,  -315,
      77,    43,  -315,  -315,   199,    40,   377,  -315,   400,   501,
      17,  -315,   198,   292,   317,  -315,   110,  -315,  -315,   109,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,   118,   116,   221,  -315,
     309,  -315,  -315,  -315,   322,   322,    86,   121,   152,    -9,
     230,  -315,   219,   499,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,    66,  -315,  -315,   255,   271,   -71,   157,  -315,
    -315,   172,  -315,   174,    18,    45,   182,   185,    46,  -315,
     317,   -36,  -315,  -315,   188,     0,   202,  -315,   117,    26,
      38,  -315,  -315,  -315,   192,     4,  -315,   317,   317,   317,
     317,   317,   317,   317,   317,   317,  -315,  -315,   -26,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,     8,    11,     8,
      12,     8,     8,     8,  -315,    15,  -315,  -315,  -315,    29,
    -315,  -315,  -315,   553,  -315,  -315,  -315,   184,   297,  -315,
     193,  -315,   288,  -315,   197,  -315,     8,  -315,  -315,   207,
     200,  -315,  -315,  -315,  -315,  -315,  -315,  -315,   270,  -315,
     272,  -315,  -315,  -315,  -315,    -9,   230,   230,   230,   230,
    -315,  -315,  -315,  -315,  -315,   297,   247,    21,   248,   250,
     251,   256,   107,   128,   257,   129,   258,  -315,  -315,  -315,
    -315,  -315,   336,   338,   341,  -315,  -315,  -315,  -315,   340,
    -315,  -315,  -315,  -315,  -315,   343,   -66,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,   333,  -315,  -315,  -315,   243,  -315,  -315,  -315,   180,
    -315,  -315,    44,   119,  -315,   291,   333,   349,   -50,   273,
       8,     7,   338,     8,     8,     8,     8,     8,   340,  -315,
    -315,   244,  -315,  -315,   245,   234,     6,  -315,  -315,   603,
    -315,   354,   623,  -315,  -315,   672,  -315,  -315,  -315,  -315,
    -315,   274,   277,   278,   281,  -315,  -315,   279,  -315,  -315,
    -315,  -315,  -315,   280,     7,     8,  -315,  -315,   246,  -315,
    -315,  -315,  -315,  -315,     7,     8,   284,     7,     8,   262,
     266,  -315,  -315,  -315,  -315,  -315,  -315,  -315
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,   375,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -315,  -315,   376,  -315,   378,  -315,   -10,   232,    68,  -101,
    -315,  -315,  -315,  -113,  -315,   122,  -315,  -315,  -315,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -268,  -289,  -314,  -315,
    -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,  -315,
    -205,  -315,   249,  -315,  -255,    87,  -315,  -315,   252,  -315,
     -16,   -22,  -315,  -315,  -315,  -315,    -2,  -203,  -237,  -315,
    -213,  -315,  -315,  -315,  -315,  -315,   -90,  -315,   171
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -266
static const short int yytable[] =
{
      48,    49,    45,   287,   288,   290,   291,   292,   293,   166,
     314,   294,   281,   150,   158,   277,   281,   236,   277,   277,
     294,   317,   230,   318,    93,   234,   322,   376,   324,    59,
     326,   328,    53,   128,    42,    43,  -129,   297,   225,   235,
     355,   220,   157,   108,   127,    42,    43,   356,   373,     3,
      56,   266,   267,   268,   269,   270,   271,     4,   374,   383,
     357,   260,   261,   262,   263,   225,   225,   132,   133,   372,
     399,   134,   135,   136,   377,    11,   137,   138,   -43,   140,
     402,   359,   272,   404,   214,   362,   249,   154,   215,   365,
     250,    42,    43,    97,    98,    99,   155,    12,   252,    13,
      14,   388,   250,    15,   368,  -116,  -116,   337,   250,   358,
     159,   160,   161,   157,   282,   254,   360,   157,   282,   325,
     363,   283,   289,   226,   366,   237,   284,    54,   295,    94,
     284,     7,   387,   237,     9,   375,   237,   237,   378,   379,
     380,   381,   382,   101,   102,   103,   314,    57,    44,   314,
     229,   233,   314,   332,   333,   166,   166,   166,   166,    44,
      39,   392,    60,    61,    62,    16,    17,    18,    19,    20,
      21,   216,   217,   218,   242,   243,   244,    63,   245,   369,
     400,   246,    40,   250,    41,    60,    61,    62,   338,   339,
     403,   152,   153,   405,   104,   105,   106,    47,    22,    23,
      63,    51,    55,   298,    58,    44,    95,    42,    43,   141,
      98,    99,   340,   341,   129,   329,   343,   344,   345,   346,
     347,   130,    64,    65,    66,    67,   256,   257,   258,   259,
     139,   140,  -264,   156,   167,    42,    43,    97,    98,    99,
      68,    69,   162,   163,   164,    64,    65,    66,    67,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,   101,
     102,   103,    81,    68,    69,   157,  -265,    82,    83,    84,
      85,    16,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,   219,   221,   222,    81,   224,   101,   102,   103,
      82,    83,    84,    85,   231,   232,   319,    42,    43,    97,
      98,    99,    54,   253,   320,   323,   367,   240,   225,   327,
     104,   105,   106,   100,    42,    43,   141,    98,    99,   330,
     331,    44,    42,    43,    97,    98,    99,    42,    43,   151,
      98,    99,   334,  -120,  -118,   335,  -119,  -127,   104,   105,
     106,   349,  -128,   342,   348,   350,   352,   353,   294,   101,
     102,   103,   165,   361,   364,   370,   371,   384,   385,  -130,
     386,   390,   394,   396,   397,  -105,   101,   102,   103,   395,
    -131,   398,   401,   406,   101,   102,   103,   407,    16,   101,
     102,   103,    60,    61,    62,    26,    36,   336,    38,   255,
     299,     0,     0,     0,   238,     0,     0,    63,   241,     0,
     104,   105,   106,     0,     0,    60,    61,    62,     0,     0,
       0,    44,     0,     0,     0,     0,     0,   104,   105,   106,
      63,     0,     0,     0,     0,   104,   105,   106,    44,     0,
     104,   105,   106,     0,     0,     0,    44,     0,     0,     0,
       0,    44,    64,    65,    66,    67,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      68,    69,     0,     0,     0,    64,    65,    66,    67,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,     0,
       0,    80,    81,    68,    69,     0,     0,    82,    83,    84,
      85,     0,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,     0,     0,    91,    81,    60,    61,    62,     0,
      82,    83,    84,    85,     0,   168,     0,     0,     0,     0,
       0,    63,     0,   169,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
     186,   187,   188,   189,   190,   191,   192,   193,   194,   195,
     196,   197,   198,   199,   200,   201,     0,     0,   301,   302,
     303,     0,     0,     0,     0,     0,    64,    65,    66,    67,
       0,     0,     0,   304,     0,   202,     0,     0,     0,     0,
       0,     0,     0,     0,    68,    69,     0,     0,     0,     0,
       0,     0,     0,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,     0,     0,    92,    81,     0,   301,   302,
     303,    82,    83,    84,    85,   203,   204,   205,   305,   306,
     307,   308,   206,   304,     0,     0,     0,     0,   301,   302,
     303,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   304,     0,     0,    71,    72,     0,     0,
       0,    76,    77,    78,     0,     0,     0,     0,   309,     0,
       0,     0,     0,   310,   311,   312,     0,     0,   305,   306,
     307,   308,     0,     0,     0,     0,     0,   301,   302,   303,
       0,     0,     0,     0,     0,     0,     0,     0,   305,   306,
     307,   308,   304,     0,     0,     0,    71,    72,     0,     0,
       0,    76,    77,    78,     0,     0,     0,     0,   309,     0,
       0,     0,     0,   310,   311,   389,    71,    72,     0,     0,
       0,    76,    77,    78,     0,     0,     0,     0,   309,     0,
       0,     0,     0,   310,   311,   391,     0,   305,   306,   307,
     308,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    71,    72,     0,     0,     0,
      76,    77,    78,     0,     0,     0,     0,   309,     0,     0,
       0,     0,   310,   311,   393
};

static const short int yycheck[] =
{
      22,    23,    18,   208,   209,   210,   211,   212,   213,   110,
     223,     5,     5,   103,    23,     7,     5,    17,     7,     7,
       5,   224,   135,   226,     7,   138,   229,   341,   231,    45,
     233,   236,    19,    55,     5,     6,    86,     8,    20,   140,
     295,   112,   113,    53,    54,     5,     6,   113,   337,     0,
       7,    77,    78,    79,    80,    81,    82,     3,   108,   348,
     126,   162,   163,   164,   165,    20,    20,    69,    70,   337,
     384,    73,    74,    75,   342,   112,    78,    79,   114,   115,
     394,   318,   108,   397,    18,   322,    60,     1,    22,   326,
      64,     5,     6,     7,     8,     9,   106,     1,    60,     3,
       4,   356,    64,     7,    60,    84,    85,    86,    64,   312,
     119,   120,   121,   113,   107,   111,   319,   113,   107,   232,
     323,   110,   110,   105,   327,   125,   119,   114,   113,   112,
     119,    75,   126,   125,     7,   340,   125,   125,   343,   344,
     345,   346,   347,    57,    58,    59,   359,   104,   119,   362,
     105,   105,   365,   243,   244,   256,   257,   258,   259,   119,
     112,   364,     5,     6,     7,    69,    70,    71,    72,    73,
      74,   105,   106,   107,    57,    58,    59,    20,    61,    60,
     385,    64,     7,    64,     7,     5,     6,     7,    81,    82,
     395,   104,   105,   398,   108,   109,   110,     7,   102,   103,
      20,     7,   125,   219,     5,   119,     8,     5,     6,     7,
       8,     9,    84,    85,   104,   237,    87,    88,    89,    90,
      91,   112,    65,    66,    67,    68,   158,   159,   160,   161,
     112,   115,    11,   112,    15,     5,     6,     7,     8,     9,
      83,    84,    12,    13,    14,    65,    66,    67,    68,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,    57,
      58,    59,   105,    83,    84,   113,    11,   110,   111,   112,
     113,    69,    92,    93,    94,    95,    96,    97,    98,    99,
     100,   101,    11,   126,   112,   105,   112,    57,    58,    59,
     110,   111,   112,   113,   112,   110,   112,     5,     6,     7,
       8,     9,   114,   111,     7,   112,   126,   105,    20,   112,
     108,   109,   110,    21,     5,     6,     7,     8,     9,   112,
     120,   119,     5,     6,     7,     8,     9,     5,     6,     7,
       8,     9,    62,    86,    86,    63,    86,    86,   108,   109,
     110,     5,    86,    86,    86,     7,     5,     7,     5,    57,
      58,    59,   122,    20,   111,    64,     7,   113,   113,    86,
     126,     7,    85,    82,    85,    91,    57,    58,    59,    91,
      86,    91,   126,   111,    57,    58,    59,   111,    69,    57,
      58,    59,     5,     6,     7,    10,    10,   265,    10,   157,
     219,    -1,    -1,    -1,   145,    -1,    -1,    20,   146,    -1,
     108,   109,   110,    -1,    -1,     5,     6,     7,    -1,    -1,
      -1,   119,    -1,    -1,    -1,    -1,    -1,   108,   109,   110,
      20,    -1,    -1,    -1,    -1,   108,   109,   110,   119,    -1,
     108,   109,   110,    -1,    -1,    -1,   119,    -1,    -1,    -1,
      -1,   119,    65,    66,    67,    68,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      83,    84,    -1,    -1,    -1,    65,    66,    67,    68,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,    -1,
      -1,   104,   105,    83,    84,    -1,    -1,   110,   111,   112,
     113,    -1,    92,    93,    94,    95,    96,    97,    98,    99,
     100,   101,    -1,    -1,   104,   105,     5,     6,     7,    -1,
     110,   111,   112,   113,    -1,    16,    -1,    -1,    -1,    -1,
      -1,    20,    -1,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    -1,    -1,     5,     6,
       7,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,
      -1,    -1,    -1,    20,    -1,    76,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    83,    84,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    92,    93,    94,    95,    96,    97,    98,
      99,   100,   101,    -1,    -1,   104,   105,    -1,     5,     6,
       7,   110,   111,   112,   113,   116,   117,   118,    65,    66,
      67,    68,   123,    20,    -1,    -1,    -1,    -1,     5,     6,
       7,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    20,    -1,    -1,    93,    94,    -1,    -1,
      -1,    98,    99,   100,    -1,    -1,    -1,    -1,   105,    -1,
      -1,    -1,    -1,   110,   111,   112,    -1,    -1,    65,    66,
      67,    68,    -1,    -1,    -1,    -1,    -1,     5,     6,     7,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    65,    66,
      67,    68,    20,    -1,    -1,    -1,    93,    94,    -1,    -1,
      -1,    98,    99,   100,    -1,    -1,    -1,    -1,   105,    -1,
      -1,    -1,    -1,   110,   111,   112,    93,    94,    -1,    -1,
      -1,    98,    99,   100,    -1,    -1,    -1,    -1,   105,    -1,
      -1,    -1,    -1,   110,   111,   112,    -1,    65,    66,    67,
      68,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    93,    94,    -1,    -1,    -1,
      98,    99,   100,    -1,    -1,    -1,    -1,   105,    -1,    -1,
      -1,    -1,   110,   111,   112
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,   128,   129,     0,     3,   130,   131,    75,   132,     7,
     134,   112,     1,     3,     4,     7,    69,    70,    71,    72,
      73,    74,   102,   103,   133,   135,   136,   137,   138,   139,
     140,   141,   143,   144,   145,   146,   149,   150,   151,   112,
       7,     7,     5,     6,   119,   197,   198,     7,   198,   198,
     142,     7,   147,    19,   114,   125,     7,   104,     5,   197,
       5,     6,     7,    20,    65,    66,    67,    68,    83,    84,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
     104,   105,   110,   111,   112,   113,   199,   200,   201,   202,
     207,   104,   104,     7,   112,     8,   148,     7,     8,     9,
      21,    57,    58,    59,   108,   109,   110,   152,   153,   154,
     155,   156,   157,   163,   164,   165,   166,   168,   169,   170,
     171,   172,   190,   192,   193,   197,   215,   153,   198,   104,
     112,   203,   203,   203,   203,   203,   203,   203,   203,   112,
     115,     7,   136,   149,   151,   153,   194,   195,   210,   213,
     213,     7,   192,   192,     1,   153,   112,   113,    23,   119,
     120,   121,    12,    13,    14,   122,   156,    15,    16,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    76,   116,   117,   118,   123,   167,   177,   182,
     183,   184,   185,   186,    18,    22,   105,   106,   107,    11,
     112,   126,   112,   205,   112,    20,   105,   160,   161,   105,
     160,   112,   110,   105,   160,   156,    17,   125,   189,   196,
     105,   195,    57,    58,    59,    61,    64,   211,   212,    60,
      64,   214,    60,   111,   111,   154,   155,   155,   155,   155,
     156,   156,   156,   156,   158,   159,    77,    78,    79,    80,
      81,    82,   108,   178,   179,   180,   181,     7,   187,   188,
     189,     5,   107,   110,   119,   175,   176,   187,   187,   110,
     187,   187,   187,   187,     5,   113,   191,     8,   197,   215,
     204,     5,     6,     7,    20,    65,    66,    67,    68,   105,
     110,   111,   112,   206,   207,   208,   209,   204,   204,   112,
       7,   162,   204,   112,   204,   160,   204,   112,   187,   198,
     112,   120,   213,   213,    62,    63,   162,    86,    81,    82,
      84,    85,    86,    87,    88,    89,    90,    91,    86,     5,
       7,   173,     5,     7,   174,   191,   113,   126,   204,   205,
     204,    20,   205,   204,   111,   205,   204,   126,    60,    60,
      64,     7,   173,   174,   108,   187,   175,   173,   187,   187,
     187,   187,   187,   174,   113,   113,   126,   126,   191,   112,
       7,   112,   204,   112,    85,    91,    82,    85,    91,   175,
     187,   126,   175,   187,   175,   187,   111,   111
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (0)


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
              (Loc).first_line, (Loc).first_column,	\
              (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, &yylloc, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval, &yylloc)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value, Location);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short int *bottom, short int *top)
#else
static void
yy_stack_print (bottom, top)
    short int *bottom;
    short int *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname[yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");

# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */






/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()
    ;
#endif
#endif
{
  /* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;
/* Location data for the look-ahead symbol.  */
YYLTYPE yylloc;

  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short int yyssa[YYINITDEPTH];
  short int *yyss = yyssa;
  short int *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;

  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  /* The locations where the error started and ended. */
  YYLTYPE yyerror_range[2];

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;
#if YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short int *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short int *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
	YYSTACK_RELOCATE (yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a look-ahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to look-ahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
  *++yylsp = yylloc;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, yylsp - yylen, yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 5:
#line 327 "rlparse.y"
    {
		if ( includeDepth == 0 ) {
			if ( sectionOpened )
				*outStream << "</ragel_def>\n";

			if ( machineSpec == 0 && machineName == 0 ) {
				/* The end section may include a newline on the end, so
				 * we use the last line, which will count the newline. */
				*outStream << "<host line=\"" << (yyvsp[0].integer) << "\">";
			}
		}
	;}
    break;

  case 6:
#line 341 "rlparse.y"
    {
		id->sectionLoc = InputLoc((yylsp[0]));

		if ( includeDepth == 0 ) {
			if ( machineSpec == 0 && machineName == 0 )
				*outStream << "</host>\n";
			sectionOpened = false;
		}
	;}
    break;

  case 7:
#line 352 "rlparse.y"
    {
		/* By default active until found not active. */
		id->active = true;
		id->sectionName = (yyvsp[-1].data).data;

		if ( id->includeSpec != 0 ) {
			if ( strcmp( id->sectionName, id->includeSpec ) == 0 )
				id->sectionName = id->includeTo;
			else
				id->active = false;
		}

		/* Lookup the parse data, if it is not there then create it. */
		SectionMapEl *sectionMapEl = sectionMap.find( id->sectionName );
		if ( sectionMapEl == 0 ) {
			ParseData *newPd = new ParseData( id->fileName, id->sectionName, 
					id->sectionLoc );
			sectionMapEl = sectionMap.insert( id->sectionName, newPd );
		}
		id->pd = sectionMapEl->value;
	;}
    break;

  case 8:
#line 373 "rlparse.y"
    {
		/* No machine name. Just use the previous section setup. Report an
		 * error if there is no previous section */
		if ( id->pd == 0 ) {
			error(id->sectionLoc) << "the first ragel section does not have a name" << endl;
			id->pd = new ParseData( id->fileName, "<DUMMY>", id->sectionLoc );
		}
	;}
    break;

  case 9:
#line 383 "rlparse.y"
    { (yyval.integer) = (yylsp[0]).last_line; ;}
    break;

  case 10:
#line 384 "rlparse.y"
    { (yyval.integer) = (yylsp[0]).last_line + 1; ;}
    break;

  case 23:
#line 405 "rlparse.y"
    { yyerrok; ;}
    break;

  case 24:
#line 410 "rlparse.y"
    {
		if ( id->active ) {
			if ( id->pd->actionDict.find( (yyvsp[-3].data).data ) ) {
				/* Recover by just ignoring the duplicate. */
				error((yylsp[-3])) << "action \"" << (yyvsp[-3].data).data << "\" already defined" << endl;
			}
			else {
				/* Add the action to the list of actions. */
				Action *newAction = new Action( InputLoc((yylsp[-2])), (yyvsp[-3].data).data, (yyvsp[-1].illist), id->nameRefList );

				/* Insert to list and dict. */
				id->pd->actionList.append( newAction );
				id->pd->actionDict.insert( newAction );
			}
		}
	;}
    break;

  case 25:
#line 430 "rlparse.y"
    {
		if ( id->active ) {
			if ( ! id->pd->setAlphType( (yyvsp[-2].data).data, (yyvsp[-1].data).data ) ) {
				// Recover by ignoring the alphtype statement.
				error((yylsp[-2])) << "\"" << (yyvsp[-2].data).data << 
					" " << (yyvsp[-1].data).data << "\" is not a valid alphabet type" << endl;
			}
		}
	;}
    break;

  case 26:
#line 439 "rlparse.y"
    {
		if ( id->active ) {
			if ( ! id->pd->setAlphType( (yyvsp[-1].data).data ) ) {
				// Recover by ignoring the alphtype statement.
				error((yylsp[-1])) << "\"" << (yyvsp[-1].data).data << "\" is not a valid alphabet type" << endl;
			}
		}
	;}
    break;

  case 27:
#line 449 "rlparse.y"
    {
		if ( id->active )
			id->pd->getKeyExpr = (yyvsp[-1].illist);
	;}
    break;

  case 28:
#line 456 "rlparse.y"
    {
		if ( id->active ) {
			// Save the upper and lower ends of the range and emit the line number.
			id->pd->lowerNum = (yyvsp[-2].data).data;
			id->pd->upperNum = (yyvsp[-1].data).data;
			id->pd->rangeLowLoc = InputLoc((yylsp[-2]));
			id->pd->rangeHighLoc = InputLoc((yylsp[-1]));
		}
	;}
    break;

  case 29:
#line 468 "rlparse.y"
    {
		if ( id->active )
			*outStream << "</write>\n";
	;}
    break;

  case 30:
#line 474 "rlparse.y"
    {
		if ( id->active ) {
			openSection();
			if ( strcmp( (yyvsp[0].data).data, "data" ) != 0 &&
					strcmp( (yyvsp[0].data).data, "init" ) != 0 &&
					strcmp( (yyvsp[0].data).data, "exec" ) != 0 &&
					strcmp( (yyvsp[0].data).data, "eof" ) != 0 )
			{
				error( (yylsp[0]) ) << "unknown write command" << endl;
			}
			*outStream << "  <write what=\"" << (yyvsp[0].data).data << "\">";
		}
	;}
    break;

  case 31:
#line 489 "rlparse.y"
    {
		if ( id->active )
			*outStream << "<option>" << (yyvsp[0].data).data << "</option>";
	;}
    break;

  case 33:
#line 496 "rlparse.y"
    {
		if ( id->active )
			id->pd->accessExpr = (yyvsp[-1].illist);
	;}
    break;

  case 34:
#line 502 "rlparse.y"
    {
		if ( id->active ) {
			if ( strcmp( (yyvsp[-2].data).data, "curstate" ) == 0 ) {
				id->pd->curStateExpr = (yyvsp[-1].illist);
			}
		}
	;}
    break;

  case 35:
#line 512 "rlparse.y"
    {
		if ( id->active )
			doInclude( (yylsp[-3]), (yyvsp[-2].data).data, (yyvsp[-1].data).data );
	;}
    break;

  case 36:
#line 518 "rlparse.y"
    {
		/* Do this immediately so that the scanner has a correct sense of the
		 * value in id->active when it reaches the end of the statement before
		 * the above action executes. */
		//getParseData( @1 );
	;}
    break;

  case 37:
#line 525 "rlparse.y"
    { (yyval.data) = (yyvsp[0].data); ;}
    break;

  case 38:
#line 525 "rlparse.y"
    { (yyval.data).data = 0; (yyval.data).length = 0; ;}
    break;

  case 39:
#line 526 "rlparse.y"
    { (yyval.data) = (yyvsp[0].data); ;}
    break;

  case 40:
#line 526 "rlparse.y"
    { (yyval.data).data = 0; (yyval.data).length = 0; ;}
    break;

  case 41:
#line 530 "rlparse.y"
    {
		if ( id->active ) {
			/* Main machine must be an instance. */
			bool isInstance = false;
			if ( strcmp((yyvsp[-3].data).data, machineMain) == 0 ) {
				warning((yylsp[-3])) << "main machine will be implicitly instantiated" << endl;
				isInstance = true;
			}

			/* Generic creation of machine for instantiation and assignment. */
			JoinOrLm *joinOrLm = new JoinOrLm( (yyvsp[-1].join) );
			tryMachineDef( (yylsp[-3]), (yyvsp[-3].data).data, joinOrLm, isInstance );
		}
	;}
    break;

  case 42:
#line 548 "rlparse.y"
    {
		/* Generic creation of machine for instantiation and assignment. */
		if ( id->active )
			tryMachineDef( (yylsp[-3]), (yyvsp[-3].data).data, (yyvsp[-1].joinOrLm), true );
	;}
    break;

  case 43:
#line 556 "rlparse.y"
    {
		if ( id->active ) {
			/* Make/get the priority key. The name may have already been referenced
			 * and therefore exist. */
			PriorDictEl *priorDictEl;
			if ( id->pd->priorDict.insert( (yyvsp[0].data).data, id->pd->nextPriorKey, &priorDictEl ) )
				id->pd->nextPriorKey += 1;
			id->pd->curDefPriorKey = priorDictEl->value;

			/* Make/get the local error key. */
			LocalErrDictEl *localErrDictEl;
			if ( id->pd->localErrDict.insert( (yyvsp[0].data).data, id->pd->nextLocalErrKey, &localErrDictEl ) )
				id->pd->nextLocalErrKey += 1;
			id->pd->curDefLocalErrKey = localErrDictEl->value;
		}
	;}
    break;

  case 44:
#line 574 "rlparse.y"
    {
		(yyval.joinOrLm) = new JoinOrLm( (yyvsp[0].join) );
	;}
    break;

  case 45:
#line 577 "rlparse.y"
    {
		/* Create a new factor going to a longest match structure. Record
		 * in the parse data that we have a longest match. */
		LongestMatch *lm = new LongestMatch( (yylsp[-3]), (yyvsp[-2].longestMatchList) );
		if ( id->active )
			id->pd->lmList.append( lm );
		for ( LmPartList::Iter lmp = *((yyvsp[-2].longestMatchList)); lmp.lte(); lmp++ )
			lmp->longestMatch = lm;
		(yyval.joinOrLm) = new JoinOrLm( lm );
	;}
    break;

  case 46:
#line 589 "rlparse.y"
    {
		/* Append the expression to the list and return it. */
		(yyvsp[-2].join)->exprList.append( (yyvsp[0].expression) );
		(yyval.join) = (yyvsp[-2].join);
	;}
    break;

  case 47:
#line 594 "rlparse.y"
    {
		/* Create the expression list with the intial expression. */
		(yyval.join) = new Join( InputLoc((yylsp[0])), (yyvsp[0].expression) );
	;}
    break;

  case 48:
#line 602 "rlparse.y"
    {
		(yyval.expression) = new Expression( (yyvsp[-2].expression), (yyvsp[0].term), Expression::OrType );
	;}
    break;

  case 49:
#line 605 "rlparse.y"
    {
		(yyval.expression) = new Expression( (yyvsp[-2].expression), (yyvsp[0].term), Expression::IntersectType );
	;}
    break;

  case 50:
#line 608 "rlparse.y"
    {
		(yyval.expression) = new Expression( (yyvsp[-2].expression), (yyvsp[0].term), Expression::SubtractType );
	;}
    break;

  case 51:
#line 611 "rlparse.y"
    {
		(yyval.expression) = new Expression( (yyvsp[-2].expression), (yyvsp[0].term), Expression::StrongSubtractType );
	;}
    break;

  case 52:
#line 614 "rlparse.y"
    {
		(yyval.expression) = new Expression( (yyvsp[0].term) );
	;}
    break;

  case 53:
#line 619 "rlparse.y"
    {
		(yyval.term) = new Term( (yyvsp[-1].term), (yyvsp[0].factorWithAug) );
	;}
    break;

  case 54:
#line 622 "rlparse.y"
    {
		(yyval.term) = new Term( (yyvsp[-2].term), (yyvsp[0].factorWithAug) );
	;}
    break;

  case 55:
#line 625 "rlparse.y"
    {
		(yyval.term) = new Term( (yyvsp[-2].term), (yyvsp[0].factorWithAug), Term::RightStartType );
	;}
    break;

  case 56:
#line 628 "rlparse.y"
    {
		(yyval.term) = new Term( (yyvsp[-2].term), (yyvsp[0].factorWithAug), Term::RightFinishType );
	;}
    break;

  case 57:
#line 631 "rlparse.y"
    {
		(yyval.term) = new Term( (yyvsp[-2].term), (yyvsp[0].factorWithAug), Term::LeftType );
	;}
    break;

  case 58:
#line 634 "rlparse.y"
    {
		(yyval.term) = new Term( (yyvsp[0].factorWithAug) );
	;}
    break;

  case 59:
#line 639 "rlparse.y"
    { 
		/* Add the label to the list and pass the factor up. */
		(yyvsp[0].factorWithAug)->labels.prepend( Label((yylsp[-2]), (yyvsp[-2].data).data) );
		(yyval.factorWithAug) = (yyvsp[0].factorWithAug); 
	;}
    break;

  case 61:
#line 647 "rlparse.y"
    { 
		/* Add the target to the list and return the factor object. */
		(yyvsp[-2].factorWithAug)->epsilonLinks.append( EpsilonLink( InputLoc((yylsp[-1])), id->nameRef ) );
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug); 
	;}
    break;

  case 64:
#line 660 "rlparse.y"
    {
		id->nameRef.empty();
	;}
    break;

  case 66:
#line 670 "rlparse.y"
    {
		/* Insert an inition null pointer val to indicate the existence of the
		 * initial name seperator. */
		id->nameRef.setAs( 0 );
	;}
    break;

  case 67:
#line 675 "rlparse.y"
    {
		id->nameRef.empty();
	;}
    break;

  case 68:
#line 681 "rlparse.y"
    {
		id->nameRef.append( (yyvsp[0].data).data );
	;}
    break;

  case 69:
#line 684 "rlparse.y"
    {
		id->nameRef.append( (yyvsp[0].data).data );
	;}
    break;

  case 78:
#line 698 "rlparse.y"
    {
		(yyval.factorWithAug) = new FactorWithAug( (yyvsp[0].factorWithRep) );
	;}
    break;

  case 79:
#line 703 "rlparse.y"
    {
		/* Append the action to the factorWithAug, record the refernce from 
		 * factorWithAug to the action and pass up the factorWithAug. */
		(yyvsp[-2].factorWithAug)->actions.append( ParserAction( (yylsp[-1]), (yyvsp[-1].augType), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 80:
#line 709 "rlparse.y"
    {
		/* Append the action to the factorWithAug, record the refernce from 
		 * factorWithAug to the action and pass up the factorWithAug. */
		(yyvsp[-4].factorWithAug)->actions.append( ParserAction( (yylsp[-3]), (yyvsp[-2].augType), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-4].factorWithAug);
	;}
    break;

  case 81:
#line 717 "rlparse.y"
    {
		if ( id->active ) {
			/* Append the named priority to the factorWithAug and pass it up. */
			(yyvsp[-2].factorWithAug)->priorityAugs.append( PriorityAug( (yyvsp[-1].augType), id->pd->curDefPriorKey, (yyvsp[0].integer) ) );
		}
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 82:
#line 724 "rlparse.y"
    {
		/* Append the priority using a default name. */
		(yyvsp[-6].factorWithAug)->priorityAugs.append( PriorityAug( (yyvsp[-5].augType), (yyvsp[-3].integer), (yyvsp[-1].integer) ) );
		(yyval.factorWithAug) = (yyvsp[-6].factorWithAug);
	;}
    break;

  case 83:
#line 729 "rlparse.y"
    {
		if ( id->active ) {
			/* Append the named priority to the factorWithAug and pass it up. */
			(yyvsp[-4].factorWithAug)->priorityAugs.append( PriorityAug( (yyvsp[-2].augType), id->pd->curDefPriorKey, (yyvsp[0].integer) ) );
		}
		(yyval.factorWithAug) = (yyvsp[-4].factorWithAug);
	;}
    break;

  case 84:
#line 738 "rlparse.y"
    {
		/* Append the priority using a default name. */
		(yyvsp[-6].factorWithAug)->priorityAugs.append( PriorityAug( (yyvsp[-4].augType), (yyvsp[-2].integer), (yyvsp[0].integer) ) );
		(yyval.factorWithAug) = (yyvsp[-6].factorWithAug);
	;}
    break;

  case 85:
#line 743 "rlparse.y"
    {
		/* Append the priority using a default name. */
		(yyvsp[-6].factorWithAug)->priorityAugs.append( PriorityAug( at_all, (yyvsp[-2].integer), (yyvsp[0].integer) ) );
		(yyval.factorWithAug) = (yyvsp[-6].factorWithAug);
	;}
    break;

  case 86:
#line 750 "rlparse.y"
    {
		(yyval.factorWithAug)->conditions.append( ParserAction( (yylsp[-1]), (yyvsp[-1].augType), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 87:
#line 756 "rlparse.y"
    { (yyval.augType) = at_start; ;}
    break;

  case 88:
#line 757 "rlparse.y"
    { (yyval.augType) = at_all; ;}
    break;

  case 89:
#line 758 "rlparse.y"
    { (yyval.augType) = at_leave; ;}
    break;

  case 90:
#line 759 "rlparse.y"
    { (yyval.augType) = at_all; ;}
    break;

  case 91:
#line 762 "rlparse.y"
    {
		/* Append the action, pass it up. */
		(yyvsp[-2].factorWithAug)->actions.append( ParserAction( (yylsp[-1]), (yyvsp[-1].augType), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 92:
#line 767 "rlparse.y"
    {
		/* Append the action, pass it up. */
		(yyvsp[-4].factorWithAug)->actions.append( ParserAction( (yylsp[-3]), (AugType)(at_start_to_state + (yyvsp[-2].stateAugType)), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-4].factorWithAug);
	;}
    break;

  case 93:
#line 774 "rlparse.y"
    {
		/* Append the action, pass it up. */
		(yyvsp[-2].factorWithAug)->actions.append( ParserAction( (yylsp[-1]), (yyvsp[-1].augType), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 94:
#line 779 "rlparse.y"
    {
		/* Append the action, pass it up. */
		(yyvsp[-4].factorWithAug)->actions.append( ParserAction( (yylsp[-3]), (AugType)(at_start_from_state + (yyvsp[-2].stateAugType)), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-4].factorWithAug);
	;}
    break;

  case 95:
#line 786 "rlparse.y"
    {
		/* Append the action, pass it up. */
		(yyvsp[-2].factorWithAug)->actions.append( ParserAction( (yylsp[-1]), (yyvsp[-1].augType), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 96:
#line 791 "rlparse.y"
    {
		/* Append the action, pass it up. */
		(yyvsp[-4].factorWithAug)->actions.append( ParserAction( (yylsp[-3]), (AugType)(at_start_eof + (yyvsp[-2].stateAugType)), 0, (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-4].factorWithAug);
	;}
    break;

  case 97:
#line 798 "rlparse.y"
    {
		if ( id->active ) {
			/* Append the action to the factorWithAug, record the refernce from 
			 * factorWithAug to the action and pass up the factorWithAug. */
			(yyvsp[-2].factorWithAug)->actions.append( ParserAction( (yylsp[-1]), (yyvsp[-1].augType), id->pd->curDefLocalErrKey, (yyvsp[0].action) ) );
		}
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 98:
#line 806 "rlparse.y"
    {
		if ( id->active ) {
			/* Append the action to the factorWithAug, record the refernce from 
			 * factorWithAug to the action and pass up the factorWithAug. */
			(yyvsp[-4].factorWithAug)->actions.append( ParserAction( (yylsp[-3]), (AugType)(at_start_gbl_error + (yyvsp[-2].stateAugType)),
					id->pd->curDefLocalErrKey, (yyvsp[0].action) ) );
		}
		(yyval.factorWithAug) = (yyvsp[-4].factorWithAug);
	;}
    break;

  case 99:
#line 817 "rlparse.y"
    {
		if ( id->active ) {
			/* Append the action to the factorWithAug, record the refernce from 
			 * factorWithAug to the action and pass up the factorWithAug. */
			(yyvsp[-2].factorWithAug)->actions.append( ParserAction( (yylsp[-1]), (yyvsp[-1].augType), id->pd->curDefLocalErrKey, (yyvsp[0].action) ) );
		}
		(yyval.factorWithAug) = (yyvsp[-2].factorWithAug);
	;}
    break;

  case 100:
#line 825 "rlparse.y"
    {
		/* Append the action to the factorWithAug, record the refernce from
		 * factorWithAug to the action and pass up the factorWithAug. */
		(yyvsp[-6].factorWithAug)->actions.append( ParserAction( (yylsp[-5]), (yyvsp[-5].augType), (yyvsp[-3].integer), (yyvsp[-1].action) ) );
		(yyval.factorWithAug) = (yyvsp[-6].factorWithAug);
	;}
    break;

  case 101:
#line 831 "rlparse.y"
    {
		if ( id->active ) {
			/* Append the action to the factorWithAug, record the refernce from 
			 * factorWithAug to the action and pass up the factorWithAug. */
			(yyvsp[-4].factorWithAug)->actions.append( ParserAction( (yylsp[-3]), (AugType)(at_start_local_error + (yyvsp[-2].stateAugType)),
					id->pd->curDefLocalErrKey, (yyvsp[0].action) ) );
		}
		(yyval.factorWithAug) = (yyvsp[-4].factorWithAug);
	;}
    break;

  case 102:
#line 842 "rlparse.y"
    {
		/* Append the action to the factorWithAug, record the refernce from 
		 * factorWithAug to the action and pass up the factorWithAug. */
		(yyvsp[-6].factorWithAug)->actions.append( ParserAction( (yylsp[-5]), (AugType)(at_start_local_error + (yyvsp[-4].stateAugType)), (yyvsp[-2].integer), (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-6].factorWithAug);
	;}
    break;

  case 103:
#line 848 "rlparse.y"
    {
		/* Append the action to the factorWithAug, record the refernce from 
		 * factorWithAug to the action and pass up the factorWithAug. */
		(yyvsp[-6].factorWithAug)->actions.append( ParserAction( (yylsp[-5]), at_all_local_error, (yyvsp[-2].integer), (yyvsp[0].action) ) );
		(yyval.factorWithAug) = (yyvsp[-6].factorWithAug);
	;}
    break;

  case 104:
#line 858 "rlparse.y"
    {
		if ( id->active ) {
			// Lookup/create the priority key.
			PriorDictEl *priorDictEl;
			if ( id->pd->priorDict.insert( (yyvsp[0].data).data, id->pd->nextPriorKey, &priorDictEl ) )
				id->pd->nextPriorKey += 1;

			// Use the inserted/found priority key.
			(yyval.integer) = priorDictEl->value;
		}
	;}
    break;

  case 105:
#line 871 "rlparse.y"
    {
		if ( id->active ) {
			/* Lookup/create the priority key. */
			LocalErrDictEl *localErrDictEl;
			if ( id->pd->localErrDict.insert( (yyvsp[0].data).data, id->pd->nextLocalErrKey, &localErrDictEl ) )
				id->pd->nextLocalErrKey += 1;

			/* Use the inserted/found priority key. */
			(yyval.integer) = localErrDictEl->value;
		}
	;}
    break;

  case 106:
#line 885 "rlparse.y"
    {
		// Convert the priority number to a long. Check for overflow.
		errno = 0;
		int aug = strtol( (yyvsp[0].data).data, 0, 10 );
		if ( errno == ERANGE && aug == LONG_MAX ) {
			// Priority number too large. Recover by setting the priority to 0.
			error((yylsp[0])) << "priority number " << (yyvsp[0].data).data << " overflows" << endl;
			(yyval.integer) = 0;
		}
		else if ( errno == ERANGE && aug == LONG_MIN ) {
			// Priority number too large in the neg. Recover by using 0.
			error((yylsp[0])) << "priority number " << (yyvsp[0].data).data << " underflows" << endl;
			(yyval.integer) = 0;
		}
		else {
			// No overflow or underflow.
			(yyval.integer) = aug;
 		}
	;}
    break;

  case 108:
#line 907 "rlparse.y"
    {
		(yyval.data) = (yyvsp[0].data);
	;}
    break;

  case 109:
#line 910 "rlparse.y"
    {
		(yyval.data).data = "-";
		(yyval.data).length = 1;
		(yyval.data).append( (yyvsp[0].data) );
	;}
    break;

  case 110:
#line 918 "rlparse.y"
    { (yyval.augType) = at_finish; ;}
    break;

  case 111:
#line 919 "rlparse.y"
    { (yyval.augType) = at_leave; ;}
    break;

  case 112:
#line 920 "rlparse.y"
    { (yyval.augType) = at_all; ;}
    break;

  case 113:
#line 921 "rlparse.y"
    { (yyval.augType) = at_start; ;}
    break;

  case 114:
#line 926 "rlparse.y"
    { (yyval.augType) = at_finish; ;}
    break;

  case 115:
#line 927 "rlparse.y"
    { (yyval.augType) = at_leave; ;}
    break;

  case 116:
#line 928 "rlparse.y"
    { (yyval.augType) = at_all; ;}
    break;

  case 117:
#line 929 "rlparse.y"
    { (yyval.augType) = at_start; ;}
    break;

  case 118:
#line 933 "rlparse.y"
    { (yyval.augType) = at_finish; ;}
    break;

  case 119:
#line 934 "rlparse.y"
    { (yyval.augType) = at_leave; ;}
    break;

  case 120:
#line 935 "rlparse.y"
    { (yyval.augType) = at_start; ;}
    break;

  case 121:
#line 939 "rlparse.y"
    { (yyval.stateAugType) = sat_start; ;}
    break;

  case 122:
#line 940 "rlparse.y"
    { (yyval.stateAugType) = sat_all; ;}
    break;

  case 123:
#line 941 "rlparse.y"
    { (yyval.stateAugType) = sat_final; ;}
    break;

  case 124:
#line 942 "rlparse.y"
    { (yyval.stateAugType) = sat_not_start; ;}
    break;

  case 125:
#line 943 "rlparse.y"
    { (yyval.stateAugType) = sat_not_final; ;}
    break;

  case 126:
#line 944 "rlparse.y"
    { (yyval.stateAugType) = sat_middle; ;}
    break;

  case 127:
#line 948 "rlparse.y"
    { (yyval.stateAugType) = sat_start; ;}
    break;

  case 128:
#line 949 "rlparse.y"
    { (yyval.stateAugType) = sat_final; ;}
    break;

  case 129:
#line 950 "rlparse.y"
    { (yyval.stateAugType) = sat_not_start; ;}
    break;

  case 130:
#line 951 "rlparse.y"
    { (yyval.stateAugType) = sat_not_final; ;}
    break;

  case 131:
#line 952 "rlparse.y"
    { (yyval.stateAugType) = sat_middle; ;}
    break;

  case 132:
#line 956 "rlparse.y"
    { (yyval.augType) = at_start_gbl_error; ;}
    break;

  case 133:
#line 957 "rlparse.y"
    { (yyval.augType) = at_all_gbl_error; ;}
    break;

  case 134:
#line 958 "rlparse.y"
    { (yyval.augType) = at_final_gbl_error; ;}
    break;

  case 135:
#line 959 "rlparse.y"
    { (yyval.augType) = at_not_start_gbl_error; ;}
    break;

  case 136:
#line 960 "rlparse.y"
    { (yyval.augType) = at_not_final_gbl_error; ;}
    break;

  case 137:
#line 961 "rlparse.y"
    { (yyval.augType) = at_middle_gbl_error; ;}
    break;

  case 138:
#line 965 "rlparse.y"
    { (yyval.augType) = at_start_local_error; ;}
    break;

  case 139:
#line 966 "rlparse.y"
    { (yyval.augType) = at_all_local_error; ;}
    break;

  case 140:
#line 967 "rlparse.y"
    { (yyval.augType) = at_final_local_error; ;}
    break;

  case 141:
#line 968 "rlparse.y"
    { (yyval.augType) = at_not_start_local_error; ;}
    break;

  case 142:
#line 969 "rlparse.y"
    { (yyval.augType) = at_not_final_local_error; ;}
    break;

  case 143:
#line 970 "rlparse.y"
    { (yyval.augType) = at_middle_local_error; ;}
    break;

  case 144:
#line 974 "rlparse.y"
    { (yyval.augType) = at_start_eof; ;}
    break;

  case 145:
#line 975 "rlparse.y"
    { (yyval.augType) = at_all_eof; ;}
    break;

  case 146:
#line 976 "rlparse.y"
    { (yyval.augType) = at_final_eof; ;}
    break;

  case 147:
#line 977 "rlparse.y"
    { (yyval.augType) = at_not_start_eof; ;}
    break;

  case 148:
#line 978 "rlparse.y"
    { (yyval.augType) = at_not_final_eof; ;}
    break;

  case 149:
#line 979 "rlparse.y"
    { (yyval.augType) = at_middle_eof; ;}
    break;

  case 150:
#line 983 "rlparse.y"
    { (yyval.augType) = at_start_to_state; ;}
    break;

  case 151:
#line 984 "rlparse.y"
    { (yyval.augType) = at_all_to_state; ;}
    break;

  case 152:
#line 985 "rlparse.y"
    { (yyval.augType) = at_final_to_state; ;}
    break;

  case 153:
#line 986 "rlparse.y"
    { (yyval.augType) = at_not_start_to_state; ;}
    break;

  case 154:
#line 987 "rlparse.y"
    { (yyval.augType) = at_not_final_to_state; ;}
    break;

  case 155:
#line 988 "rlparse.y"
    { (yyval.augType) = at_middle_to_state; ;}
    break;

  case 156:
#line 992 "rlparse.y"
    { (yyval.augType) = at_start_from_state; ;}
    break;

  case 157:
#line 993 "rlparse.y"
    { (yyval.augType) = at_all_from_state; ;}
    break;

  case 158:
#line 994 "rlparse.y"
    { (yyval.augType) = at_final_from_state; ;}
    break;

  case 159:
#line 995 "rlparse.y"
    { (yyval.augType) = at_not_start_from_state; ;}
    break;

  case 160:
#line 996 "rlparse.y"
    { (yyval.augType) = at_not_final_from_state; ;}
    break;

  case 161:
#line 997 "rlparse.y"
    { (yyval.augType) = at_middle_from_state; ;}
    break;

  case 164:
#line 1007 "rlparse.y"
    {
		if ( id->active ) {
			/* Set the name in the actionDict. */
			Action *action = id->pd->actionDict.find( (yyvsp[0].data).data );
			if ( action != 0 ) {
				/* Pass up the action element */
				(yyval.action) = action;
			}
			else {
				/* Will recover by returning null as the action. */
				error((yylsp[0])) << "action lookup of \"" << (yyvsp[0].data).data << "\" failed" << endl;
				(yyval.action) = 0;
			}
		}
	;}
    break;

  case 165:
#line 1024 "rlparse.y"
    {
		if ( id->active ) {
			/* Create the action, add it to the list and pass up. */
			Action *newAction = new Action( InputLoc((yylsp[-2])), 0, (yyvsp[-1].illist), id->nameRefList );
			id->pd->actionList.append( newAction );
			(yyval.action) = newAction;
		}
	;}
    break;

  case 166:
#line 1036 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[0])), (yyvsp[-1].factorWithRep), 0, 0,
				FactorWithRep::StarType );
	;}
    break;

  case 167:
#line 1040 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[0])), (yyvsp[-1].factorWithRep), 0, 0,
				FactorWithRep::StarStarType );
	;}
    break;

  case 168:
#line 1044 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[0])), (yyvsp[-1].factorWithRep), 0, 0,
				FactorWithRep::OptionalType );
	;}
    break;

  case 169:
#line 1048 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[0])), (yyvsp[-1].factorWithRep), 0, 0,
				FactorWithRep::PlusType );
	;}
    break;

  case 170:
#line 1052 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[-2])), (yyvsp[-3].factorWithRep), (yyvsp[-1].integer), 0,
				FactorWithRep::ExactType );
	;}
    break;

  case 171:
#line 1056 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[-3])), (yyvsp[-4].factorWithRep), 0, (yyvsp[-1].integer),
				FactorWithRep::MaxType );
	;}
    break;

  case 172:
#line 1060 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[-3])), (yyvsp[-4].factorWithRep), (yyvsp[-2].integer), 0,
				FactorWithRep::MinType );
	;}
    break;

  case 173:
#line 1064 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[-4])), (yyvsp[-5].factorWithRep), (yyvsp[-3].integer), (yyvsp[-1].integer),
				FactorWithRep::RangeType );
	;}
    break;

  case 174:
#line 1068 "rlparse.y"
    {
		(yyval.factorWithRep) = new FactorWithRep( InputLoc((yylsp[0])), (yyvsp[0].factorWithNeg) );
	;}
    break;

  case 175:
#line 1073 "rlparse.y"
    {
		// Convert the priority number to a long. Check for overflow.
		errno = 0;
		int rep = strtol( (yyvsp[0].data).data, 0, 10 );
		if ( errno == ERANGE && rep == LONG_MAX ) {
			// Repetition too large. Recover by returing repetition 1. */
			error((yylsp[0])) << "repetition number " << (yyvsp[0].data).data << " overflows" << endl;
			(yyval.integer) = 1;
		}
		else {
			// Cannot be negative, so no overflow.
			(yyval.integer) = rep;
 		}
	;}
    break;

  case 176:
#line 1090 "rlparse.y"
    {
		(yyval.factorWithNeg) = new FactorWithNeg( InputLoc((yylsp[-1])), (yyvsp[0].factorWithNeg), FactorWithNeg::NegateType );
	;}
    break;

  case 177:
#line 1093 "rlparse.y"
    {
		(yyval.factorWithNeg) = new FactorWithNeg( InputLoc((yylsp[-1])), (yyvsp[0].factorWithNeg), FactorWithNeg::CharNegateType );
	;}
    break;

  case 178:
#line 1096 "rlparse.y"
    {
		(yyval.factorWithNeg) = new FactorWithNeg( InputLoc((yylsp[0])), (yyvsp[0].factor) );
	;}
    break;

  case 179:
#line 1104 "rlparse.y"
    {
		// Create a new factor node going to a concat literal. */
		(yyval.factor) = new Factor( new Literal( InputLoc((yylsp[0])), (yyvsp[0].data), Literal::LitString ) );
	;}
    break;

  case 180:
#line 1108 "rlparse.y"
    {
		// Create a new factor node going to a concat literal. */
		(yyval.factor) = new Factor( new Literal( InputLoc((yylsp[0])), (yyvsp[0].data), Literal::LitString ) );
		(yyval.factor)->literal->caseInsensitive = true;
	;}
    break;

  case 181:
#line 1113 "rlparse.y"
    {
		// Create a new factor node going to a literal number. */
		(yyval.factor) = new Factor( new Literal( InputLoc((yylsp[0])), (yyvsp[0].data), Literal::Number ) );
	;}
    break;

  case 182:
#line 1117 "rlparse.y"
    {
		if ( id->active ) {
			// Find the named graph.
			GraphDictEl *gdNode = id->pd->graphDict.find( (yyvsp[0].data).data );
			if ( gdNode == 0 ) {
				// Recover by returning null as the factor node.
				error((yylsp[0])) << "graph lookup of \"" << (yyvsp[0].data).data << "\" failed" << endl;
				(yyval.factor) = 0;
			}
			else if ( gdNode->isInstance ) {
				// Recover by retuning null as the factor node.
				error((yylsp[0])) << "references to graph instantiations not allowed "
						"in expressions" << endl;
				(yyval.factor) = 0;
			}
			else {
				// Create a factor node that is a lookup of an expression.
				(yyval.factor) = new Factor( InputLoc((yylsp[0])), gdNode->value );
			}
		}
	;}
    break;

  case 183:
#line 1138 "rlparse.y"
    {
		// Create a new factor node going to an OR expression. */
		(yyval.factor) = new Factor( new ReItem( InputLoc((yylsp[-2])), (yyvsp[-1].reOrBlock), ReItem::OrBlock ) );
	;}
    break;

  case 184:
#line 1142 "rlparse.y"
    {
		// Create a new factor node going to a negated OR expression. */
		(yyval.factor) = new Factor( new ReItem( InputLoc((yylsp[-2])), (yyvsp[-1].reOrBlock), ReItem::NegOrBlock ) );
	;}
    break;

  case 185:
#line 1146 "rlparse.y"
    {
		if ( (yyvsp[0].data).length > 1 ) {
			for ( char *p = (yyvsp[0].data).data; *p != 0; p++ ) {
				if ( *p == 'i' )
					(yyvsp[-1].regExp)->caseInsensitive = true;
			}
		}

		// Create a new factor node going to a regular exp.
		(yyval.factor) = new Factor( (yyvsp[-1].regExp) );
	;}
    break;

  case 186:
#line 1157 "rlparse.y"
    {
		// Create a new factor node going to a range. */
		(yyval.factor) = new Factor( new Range( (yyvsp[-2].literal), (yyvsp[0].literal) ) );
	;}
    break;

  case 187:
#line 1161 "rlparse.y"
    {
		/* Create a new factor going to a parenthesized join. */
		(yyval.factor) = new Factor( (yyvsp[-1].join) );
	;}
    break;

  case 188:
#line 1167 "rlparse.y"
    { (yyval.factor) = 0; yyerrok; ;}
    break;

  case 189:
#line 1170 "rlparse.y"
    {
		if ( (yyvsp[0].longestMatchPart) != 0 ) 
			(yyvsp[-1].longestMatchList)->append( (yyvsp[0].longestMatchPart) );
		(yyval.longestMatchList) = (yyvsp[-1].longestMatchList);
	;}
    break;

  case 190:
#line 1175 "rlparse.y"
    {
		/* Create a new list with the part. */
		(yyval.longestMatchList) = new LmPartList;
		if ( (yyvsp[0].longestMatchPart) != 0 )
			(yyval.longestMatchList)->append( (yyvsp[0].longestMatchPart) );
	;}
    break;

  case 191:
#line 1183 "rlparse.y"
    { (yyval.longestMatchPart) = 0; ;}
    break;

  case 192:
#line 1184 "rlparse.y"
    { (yyval.longestMatchPart) = 0; ;}
    break;

  case 193:
#line 1185 "rlparse.y"
    {
		(yyval.longestMatchPart) = 0;
		if ( id->active ) {
			Action *action = (yyvsp[-1].action);
			if ( action != 0 )
				action->isLmAction = true;
			(yyval.longestMatchPart) = new LongestMatchPart( (yyvsp[-2].join), action, id->pd->nextLongestMatchId++ );
		}
	;}
    break;

  case 194:
#line 1196 "rlparse.y"
    { (yyval.action) = (yyvsp[0].action); ;}
    break;

  case 195:
#line 1197 "rlparse.y"
    { (yyval.action) = (yyvsp[0].action); ;}
    break;

  case 196:
#line 1198 "rlparse.y"
    { (yyval.action) = 0; ;}
    break;

  case 198:
#line 1204 "rlparse.y"
    { 
		(yyval.data).data = "-";
		(yyval.data).length = 1;
		(yyval.data).append( (yyvsp[0].data) );
	;}
    break;

  case 200:
#line 1212 "rlparse.y"
    {
		/* Append the item to the list, return the list. */
		(yyvsp[-1].illist)->append( (yyvsp[0].ilitem) );
		(yyval.illist) = (yyvsp[-1].illist);
	;}
    break;

  case 201:
#line 1217 "rlparse.y"
    {
		/* Start with empty list. */
		(yyval.illist) = new InlineList;
	;}
    break;

  case 202:
#line 1224 "rlparse.y"
    {
		/* Add a text segment. */
		(yyval.ilitem) = new InlineItem( (yylsp[0]), (yyvsp[0].data).data, InlineItem::Text );
	;}
    break;

  case 203:
#line 1228 "rlparse.y"
    {
		/* Add a text segment, need string on heap. */
		(yyval.ilitem) = new InlineItem( (yylsp[0]), strdup((yyvsp[0].data).data), InlineItem::Text );
	;}
    break;

  case 204:
#line 1232 "rlparse.y"
    {
		/* Pass the inline item up. */
		(yyval.ilitem) = (yyvsp[0].ilitem);
	;}
    break;

  case 212:
#line 1244 "rlparse.y"
    { (yyval.data).data = ","; (yyval.data).length = 1; ;}
    break;

  case 213:
#line 1245 "rlparse.y"
    { (yyval.data).data = ";"; (yyval.data).length = 1; ;}
    break;

  case 214:
#line 1246 "rlparse.y"
    { (yyval.data).data = "("; (yyval.data).length = 1; ;}
    break;

  case 215:
#line 1247 "rlparse.y"
    { (yyval.data).data = ")"; (yyval.data).length = 1; ;}
    break;

  case 216:
#line 1248 "rlparse.y"
    { (yyval.data).data = "*"; (yyval.data).length = 1; ;}
    break;

  case 217:
#line 1249 "rlparse.y"
    { (yyval.data).data = "::"; (yyval.data).length = 2; ;}
    break;

  case 218:
#line 1253 "rlparse.y"
    {
		/* Pass up interpreted items of inline expressions. */
		(yyval.ilitem) = (yyvsp[0].ilitem);
	;}
    break;

  case 219:
#line 1257 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-3]), InlineItem::Hold );
	;}
    break;

  case 220:
#line 1260 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-4]), InlineItem::Exec );
		(yyval.ilitem)->children = (yyvsp[-2].illist);
	;}
    break;

  case 221:
#line 1264 "rlparse.y"
    { 
		(yyval.ilitem) = new InlineItem( (yylsp[-4]), new NameRef(id->nameRef), InlineItem::Goto );
	;}
    break;

  case 222:
#line 1267 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-5]), InlineItem::GotoExpr );
		(yyval.ilitem)->children = (yyvsp[-1].illist);
	;}
    break;

  case 223:
#line 1271 "rlparse.y"
    { 
		(yyval.ilitem) = new InlineItem( (yylsp[-4]), new NameRef(id->nameRef), InlineItem::Next );
	;}
    break;

  case 224:
#line 1274 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-5]), InlineItem::NextExpr );
		(yyval.ilitem)->children = (yyvsp[-1].illist);
	;}
    break;

  case 225:
#line 1278 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-4]), new NameRef(id->nameRef), InlineItem::Call );
	;}
    break;

  case 226:
#line 1281 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-5]), InlineItem::CallExpr );
		(yyval.ilitem)->children = (yyvsp[-1].illist);
	;}
    break;

  case 227:
#line 1285 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-3]), InlineItem::Ret );
	;}
    break;

  case 228:
#line 1288 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-3]), InlineItem::Break );
	;}
    break;

  case 229:
#line 1293 "rlparse.y"
    { inlineWhitespace = false; ;}
    break;

  case 230:
#line 1296 "rlparse.y"
    { inlineWhitespace = true; ;}
    break;

  case 231:
#line 1299 "rlparse.y"
    {
		(yyvsp[-1].illist)->append( (yyvsp[0].ilitem) );
		(yyval.illist) = (yyvsp[-1].illist);
	;}
    break;

  case 232:
#line 1303 "rlparse.y"
    {
		/* Init the list used for this expr. */
		(yyval.illist) = new InlineList;
	;}
    break;

  case 233:
#line 1309 "rlparse.y"
    {
		/* Return a text segment. */
		(yyval.ilitem) = new InlineItem( (yylsp[0]), (yyvsp[0].data).data, InlineItem::Text );
	;}
    break;

  case 234:
#line 1313 "rlparse.y"
    {
		/* Return a text segment, must heap alloc the text. */
		(yyval.ilitem) = new InlineItem( (yylsp[0]), strdup((yyvsp[0].data).data), InlineItem::Text );
	;}
    break;

  case 235:
#line 1317 "rlparse.y"
    {
		/* Pass the inline item up. */
		(yyval.ilitem) = (yyvsp[0].ilitem);
	;}
    break;

  case 236:
#line 1323 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[0]), InlineItem::PChar );
	;}
    break;

  case 237:
#line 1326 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[0]), InlineItem::Char );
	;}
    break;

  case 238:
#line 1329 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[0]), InlineItem::Curs );
	;}
    break;

  case 239:
#line 1332 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[0]), InlineItem::Targs );
	;}
    break;

  case 240:
#line 1335 "rlparse.y"
    {
		(yyval.ilitem) = new InlineItem( (yylsp[-5]), new NameRef(id->nameRef), InlineItem::Entry );
	;}
    break;

  case 248:
#line 1346 "rlparse.y"
    { (yyval.data).data = "("; (yyval.data).length = 1; ;}
    break;

  case 249:
#line 1347 "rlparse.y"
    { (yyval.data).data = ")"; (yyval.data).length = 1; ;}
    break;

  case 250:
#line 1348 "rlparse.y"
    { (yyval.data).data = "*"; (yyval.data).length = 1; ;}
    break;

  case 251:
#line 1349 "rlparse.y"
    { (yyval.data).data = "::"; (yyval.data).length = 1; ;}
    break;

  case 252:
#line 1354 "rlparse.y"
    {
		// An optimization to lessen the tree size. If a non-starred char is directly
		// under the left side on the right and the right side is another non-starred
		// char then paste them together and return the left side. Otherwise
		// just put the two under a new reg exp node.
		if ( (yyvsp[0].reItem)->type == ReItem::Data && !(yyvsp[0].reItem)->star &&
			(yyvsp[-1].regExp)->type == RegExpr::RecurseItem &&
			(yyvsp[-1].regExp)->item->type == ReItem::Data && !(yyvsp[-1].regExp)->item->star )
		{
			// Append the right side to the right side of the left and toss 
			// the right side.
			(yyvsp[-1].regExp)->item->data.append( (yyvsp[0].reItem)->data );
			delete (yyvsp[0].reItem);
			(yyval.regExp) = (yyvsp[-1].regExp);
		}
		else {
			(yyval.regExp) = new RegExpr( (yyvsp[-1].regExp), (yyvsp[0].reItem) );
		}
	;}
    break;

  case 253:
#line 1373 "rlparse.y"
    {
		// Can't optimize the tree.
		(yyval.regExp) = new RegExpr();
	;}
    break;

  case 254:
#line 1380 "rlparse.y"
    {
		(yyvsp[-1].reItem)->star = true;
		(yyval.reItem) = (yyvsp[-1].reItem);
	;}
    break;

  case 255:
#line 1384 "rlparse.y"
    {
		(yyval.reItem) = (yyvsp[0].reItem);
	;}
    break;

  case 256:
#line 1391 "rlparse.y"
    {
		(yyval.reItem) = new ReItem( InputLoc((yylsp[-2])), (yyvsp[-1].reOrBlock), ReItem::OrBlock );
	;}
    break;

  case 257:
#line 1394 "rlparse.y"
    {
		(yyval.reItem) = new ReItem( InputLoc((yylsp[-2])), (yyvsp[-1].reOrBlock), ReItem::NegOrBlock );
	;}
    break;

  case 258:
#line 1397 "rlparse.y"
    {
		(yyval.reItem) = new ReItem( InputLoc((yylsp[0])), ReItem::Dot );
	;}
    break;

  case 259:
#line 1400 "rlparse.y"
    {
		(yyval.reItem) = new ReItem( InputLoc((yylsp[0])), (yyvsp[0].data).data[0] );
	;}
    break;

  case 260:
#line 1407 "rlparse.y"
    {
		// An optimization to lessen the tree size. If an or char is directly
		// under the left side on the right and the right side is another or
		// char then paste them together and return the left side. Otherwise
		// just put the two under a new or data node.
		if ( (yyvsp[0].reOrItem)->type == ReOrItem::Data &&
				(yyvsp[-1].reOrBlock)->type == ReOrBlock::RecurseItem &&
				(yyvsp[-1].reOrBlock)->item->type == ReOrItem::Data )
		{
			// Append the right side to right side of the left and toss
			// the right side.
			(yyvsp[-1].reOrBlock)->item->data.append( (yyvsp[0].reOrItem)->data );
			delete (yyvsp[0].reOrItem);
			(yyval.reOrBlock) = (yyvsp[-1].reOrBlock);
		}
		else {
			// Can't optimize, put the left and right under a new node.
			(yyval.reOrBlock) = new ReOrBlock( (yyvsp[-1].reOrBlock), (yyvsp[0].reOrItem) );
		}
	;}
    break;

  case 261:
#line 1427 "rlparse.y"
    {
		(yyval.reOrBlock) = new ReOrBlock();
	;}
    break;

  case 262:
#line 1435 "rlparse.y"
    {
		(yyval.reOrItem) = new ReOrItem( InputLoc((yylsp[0])), (yyvsp[0].data).data[0] );
	;}
    break;

  case 263:
#line 1438 "rlparse.y"
    {
		(yyval.reOrItem) = new ReOrItem( InputLoc((yylsp[-1])), (yyvsp[-2].data).data[0], (yyvsp[0].data).data[0] );
	;}
    break;

  case 264:
#line 1443 "rlparse.y"
    {
		// Range literas must have only one char.
		if ( strlen((yyvsp[0].data).data) != 1 ) {
			// Recover by using the literal anyways.
			error((yylsp[0])) << "literal used in range must be of length 1" << endl;
		}
		(yyval.literal) = new Literal( InputLoc((yylsp[0])), (yyvsp[0].data), Literal::LitString );
	;}
    break;

  case 265:
#line 1451 "rlparse.y"
    {
		// Create a new literal number.
		(yyval.literal) = new Literal( InputLoc((yylsp[0])), (yyvsp[0].data), Literal::Number );
	;}
    break;


      default: break;
    }

/* Line 1126 of yacc.c.  */
#line 3663 "rlparse.cpp"

  yyvsp -= yylen;
  yyssp -= yylen;
  yylsp -= yylen;

  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  int yytype = YYTRANSLATE (yychar);
	  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
	  YYSIZE_T yysize = yysize0;
	  YYSIZE_T yysize1;
	  int yysize_overflow = 0;
	  char *yymsg = 0;
#	  define YYERROR_VERBOSE_ARGS_MAXIMUM 5
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;

#if 0
	  /* This is so xgettext sees the translatable formats that are
	     constructed on the fly.  */
	  YY_("syntax error, unexpected %s");
	  YY_("syntax error, unexpected %s, expecting %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
#endif
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytname[yytype];
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytname[yyx];
		yysize1 = yysize + yytnamerr (0, yytname[yyx]);
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + yystrlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow && yysize <= YYSTACK_ALLOC_MAXIMUM)
	    yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg)
	    {
	      /* Avoid sprintf, as that infringes on the user's name space.
		 Don't have undefined behavior even if the translation
		 produced a string with the wrong number of "%s"s.  */
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      goto yyexhaustedlab;
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
    }

  yyerror_range[0] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
        }
      else
	{
	  yydestruct ("Error: discarding", yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (0)
     goto yyerrorlab;

  yyerror_range[0] = yylsp[1-yylen];
  yylsp -= yylen;
  yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[0] = *yylsp;
      yydestruct ("Error: popping", yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;

  yyerror_range[1] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the look-ahead.  YYLOC is available though. */
  YYLLOC_DEFAULT (yyloc, yyerror_range - 1, 2);
  *++yylsp = yyloc;

  /* Shift the error token. */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval, &yylloc);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK;
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 1456 "rlparse.y"


/* Try to do a definition, common to assignment and instantiation. Warns about 
 * instances other than main not being implemented yet. */
void tryMachineDef( const YYLTYPE &loc, char *name, JoinOrLm *joinOrLm, bool isInstance )
{
	GraphDictEl *newEl = id->pd->graphDict.insert( name );
	if ( newEl != 0 ) {
		/* New element in the dict, all good. */
		newEl->value = new VarDef( name, joinOrLm );
		newEl->isInstance = isInstance;
		newEl->loc = loc;

		/* It it is an instance, put on the instance list. */
		if ( isInstance )
			id->pd->instanceList.append( newEl );
	}
	else {
		// Recover by ignoring the duplicate.
		error(loc) << "fsm \"" << name << "\" previously defined" << endl;
	}
}

void doInclude( const InputLoc &loc, char *sectionName, char *inputFile )
{
	/* Bail if we hit the max include depth. */
	if ( includeDepth == INCLUDE_STACK_SIZE ) {
		error(loc) << "hit maximum include depth of " << INCLUDE_STACK_SIZE << endl;
	}
	else {
		char *includeTo = id->pd->fsmName;

		/* Implement defaults for the input file and section name. */
		if ( inputFile == 0 ) 
			inputFile = id->fileName;
		if ( sectionName == 0 )
			sectionName = id->pd->fsmName;

		/* Parse the included file. */
		InputData *oldId = id;
		id = new InputData( inputFile, sectionName, includeTo );
		includeDepth += 1;
		yyparse();
		includeDepth -= 1;
		delete id;
		id = oldId;
	}
}

void openSection()
{
	if ( ! sectionOpened ) {
		sectionOpened = true;
		*outStream << "<ragel_def name=\"" << id->pd->fsmName << "\">\n";
	}
}

void yyerror( char *err )
{
	/* Bison won't give us the location, but in the last call to the scanner we
	 * saved a pointer to the location variable. Use that. instead. */
	error(::yylloc->first_line, ::yylloc->first_column) << err << endl;
}


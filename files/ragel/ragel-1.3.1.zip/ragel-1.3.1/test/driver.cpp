/*
 * A generic driver for c++ fsms.
 */
#include <stdio.h>
#define BUFSIZE 2048

Fsm fsm;
char buf[BUFSIZE];

int main()
{
	fsm.Init();
	while ( 1 ) {
		int len = fread( buf, 1, BUFSIZE, stdin );
		fsm.Execute( buf, len );
		if ( len != BUFSIZE )
			break;
	}
	fsm.Finish();
	if ( fsm.Accept() )
		printf("ACCEPT\n");
	else
		printf("FAIL\n");
	return 0;
}


/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMBASE_CPP
#define _RLFSM_FSMBASE_CPP

#include <string.h>
#include <assert.h>

/**
 * Copy all graph data including transitions.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>::FsmGraph(const FsmGraph &graph)
:
	startState(0),
	finStateSet()
{
	/* Create the states and record their map in the original state. */
	State *origState = graph.stateList.head;
	while ( origState != 0 ) {
		/* Make the new state. */
		State *newState = new State(*origState);

		/* Add the state to the list.  */
		stateList.append( newState );

		/* Set the mapsTo item of the old state. */
		origState->alg.stateMap = newState;

		/* next state. */
		origState = origState->next;
	}
	
	/* Derefernce all the state maps. */
	State *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the list of out transitions and attach new transitions to their
		 * corresponding new states. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int ot = 0; ot < ntel; ot++, tel++ ) {
			/* Is the transition set? */
			if ( tel->value != NULL ) {
				/* Get the trans and the to state. */
				Transition *trans = tel->value;
				State *to = trans->toState->alg.stateMap;

				/* Make a copy of the transition. */
				trans = new Transition(*trans);
				tel->value = trans;

				/* Simulate a real attaching. */
				trans->fromState = 0;
				trans->toState = 0;
				AttachStates( state, to, trans, KeyTypeSingle, tel->key );
			}
		}

		/* Walk the list of out ranges and attach new transitions to their
		 * corresponding new states. */
		tel = state->outRange.table;
		ntel = state->outRange.tableLength;
		for ( int outr = 0; outr < ntel; outr+=2, tel+=2 ) {
			if ( tel->value != NULL ) {
				/* Get the trans and the to state. */
				Transition *trans = tel->value;
				State *to = trans->toState->alg.stateMap;

				/* Make a copy of the transition. */
				trans = new Transition(*trans);
				tel[0].value = trans;
				tel[1].value = trans;

				/* Simulate a real attaching. */
				trans->fromState = 0;
				trans->toState = 0;
				AttachStates( state, to, trans, KeyTypeRange, tel->key );
			}
		}

		/* Copy the default transition if it is there. */
		if ( state->defOutTrans != NULL ) {
			/* Get the trans and the to state. */
			Transition *trans = state->defOutTrans;
			State *to = trans->toState->alg.stateMap;

			/* Copy the transition. */
			trans = new Transition(*trans);
			state->defOutTrans = trans;

			/* Simulate a real attaching. */
			trans->fromState = 0;
			trans->toState = 0;
			AttachStates( state, to, trans, KeyTypeDefault, 0 );
		}

		state = state->next;
	}

	/* Fix the start state. */
	startState = graph.startState->alg.stateMap;
	
	/* Build the final state set. */
	State **st = graph.finStateSet.table;
	int nst = graph.finStateSet.tableLength;
	for ( int fs = 0; fs < nst; fs++, st++ )
		finStateSet.set((*st)->alg.stateMap);
}

/**
 * Deletes all transition data then deletes each state.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>::~FsmGraph()
{
	/* Delete all the transitions. */
	State *state = stateList.head;
	while ( state != NULL ) {
		/* Iterate the out transitions, deleting them. */
		FsmOutIterator<State, Transition> outIt(state);
		for ( ; ! outIt.atEnd(); outIt++ )
			delete outIt.trans;

		state = state->next;
	}

	/* Delete all the states. */
	stateList.empty();
}


/**
 * Set a state final. The state has its isFinState set to true and the state is
 * added to the finStateSet.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		SetFinState(State *state)
{
	/* Is it already a fin state. */
	if (state->isFinState)
		return;
	
	state->isFinState = true;
	finStateSet.set( state );
}

/**
 * Set a state non-final. The has its isFinState flag set false and the state
 * is removed from the final state set.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		UnsetFinState(State *state)
{
	/* Is it already a fin state. */
	if (! state->isFinState)
		return;

	state->isFinState = false;
	finStateSet.unSet( state );
}

/**
 * Set the priority of starting transitions. Isolates the start state so it has
 * no other entry points, then sets the priorities of all the transitions out
 * of the start state. If the start state is final, then the outPrior of the
 * start state is also set. The idea is that a machine that accepts the null
 * string can still specify the starting trans prior for when it accepts the
 * null word.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		StartFsmPrior( int prior )
{
	/* Make sure the start state has no other entry points. */
	IsolateStartState();

	/* Walk all transitions out of the start state. */
	FsmOutIterator<State, Transition> outIt( startState );
	for ( ; ! outIt.atEnd(); outIt++ )
		outIt.trans->priority = prior;

	/* If the new start state is final then set the out priority. This follows
	 * the same convention as setting start funcs in the out funcs of a final
	 * start state. */
	if ( startState->isFinState ) {
		startState->isOutPriorSet = true;
		startState->outPriority = prior;
	}
}

/**
 * Set the priority of all transitions in a graph. Walks all transition lists
 * and all def transitions. 
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AllTransPrior( int prior )
{
	/* Walk the out list of all states. */
	State *state = stateList.head;
	while ( state != NULL ) {
		/* Walk the out list of the state. */
		FsmOutIterator<State, Transition> outIt( state );
		for ( ; ! outIt.atEnd() ; outIt++ ) 
			outIt.trans->priority = prior;

		state = state->next;
	}
}

/**
 * Set the priority of all transitions that go into a final state. Note that if
 * any entry states are final, we will not be setting the priority of any
 * transitions that may go into those states in the future. The graph does not
 * support pending in transitions in the same way pending out transitios are
 * supported.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FinFsmPrior( int prior )
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		/* Walk all in transitions of the final state. */
		FsmInIterator<State, Transition> inIt( *st );
		for ( ; ! inIt.atEnd(); inIt++ )
			inIt.trans->priority = prior;
	}
}

/**
 * Set the priority of any future out transitions that may be made going out of
 * this state machine.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		LeaveFsmPrior( int prior )
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = true;
		(*st)->outPriority = prior;
	}
}


/**
 * Set functions to execute on starting transitions. Isolates the start state
 * so it has no other entry points, then adds to the transition functions
 * of all the transitions out of the start state. If the start state is final,
 * then the func is also added to the start state's out func list. The idea is
 * that a machine that accepts the null string can execute a start func when it
 * matches the null word, which can only be done when leaving the start/final
 * state.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		StartFsmFunc( TransFunc func, int transOrder )
{
	/* Make sure the start state has no other entry points. */
	IsolateStartState();

	/* Walk the start state's transitions, setting functions. */
	FsmOutIterator<State, Transition> outIt( startState );
	for ( ; ! outIt.atEnd(); outIt++ ) 
		outIt.trans->SetFunction( func, transOrder );

	/* If start state is final then insert on the out func. This means that you
	 * can have start and leaving funcs on a machine that recognizes the null
	 * word. */
	if ( startState->isFinState )
		startState->outTransFuncTable.insertMulti( transOrder, func );
}

/**
 * Set functions to execute on all transitions. Walks the out lists of all states.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AllTransFunc( TransFunc func, int transOrder )
{
	/* Walk all states. */
	State *state = stateList.head;
	while ( state != NULL ) {
		/* Walk the out list of the state. */
		FsmOutIterator<State, Transition> outIt( state );
		for ( ; ! outIt.atEnd(); outIt++ )
			outIt.trans->SetFunction( func, transOrder );

		state = state->next;
	}
}

/**
 * Specify functions to execute upon entering final states. If the start state
 * is final we can't really specify a function to execute upon entering that
 * final state the first time. So function really means whenever entering a
 * final state from within the same fsm.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FinFsmFunc( TransFunc func, int transOrder )
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		/* Walk the final state's in list. */
		FsmInIterator<State, Transition> inIt( *st );
		for ( ; ! inIt.atEnd(); inIt++ )
			inIt.trans->SetFunction( func, transOrder );
	}
}

/**
 * Add functions to any future out transitions that may be made going out of
 * this state machine.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		LeaveFsmFunc( TransFunc func, int transOrder )
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++)
		(*st)->outTransFuncTable.insertMulti( transOrder, func );
}

/**
 * Shift the function ordering of the start transitions to start
 * at fromOrder and increase in units of 1. Useful before staring.
 * Returns the maximum number of order numbers used.
 */
template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		ShiftStartFuncOrder( int fromOrder )
{
	int maxUsed = 0;

	/* Walk the start state's transitions, shifting function ordering. */
	FsmOutIterator<State, Transition> outIt( startState );
	for ( ; ! outIt.atEnd(); outIt++ ) {
		Transition *trans = outIt.trans;

		/* Walk the function table for the transition. */
		typename Transition::TransFuncEl *tfel =
				trans->transFuncTable.table;

		/* Set the keys to increasing values starting at fromOrder */
		int ntfel = trans->transFuncTable.tableLength;
		int curFromOrder = fromOrder;
		for ( int j = 0; j < ntfel; j++, tfel++ )
			tfel->key = curFromOrder++;
	
		/* Keep track of the max number of orders used. */
		if ( curFromOrder - fromOrder > maxUsed )
			maxUsed = curFromOrder - fromOrder;
	}
	
	return maxUsed;
}

/**
 * Clear all functions tables out of the start state. First makes sure that
 * the start state has no other entry points other than its start stateness.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearStartFsmFunc()
{
	/* Make sure the start state has no other entry points. */
	IsolateStartState();

	/* Walk the start state's transitions, clearing functions. */
	FsmOutIterator<State, Transition> outIt( startState );
	for ( ; ! outIt.atEnd(); outIt++ )
		outIt.trans->transFuncTable.empty();

	/* If start state is final then clear on the out func. Leaving the start state
	 * via an out transition is considered starting the fsm. */
	if ( startState->isFinState )
		startState->outTransFuncTable.empty();
}

/**
 * Empty all transition functions tables. Does not empty state outFunc tables.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearAllTransFunc()
{
	/* Walk all states. */
	State *state = stateList.head;
	while ( state != NULL ) {
		/* Walk the state's outList. */
		FsmOutIterator<State, Transition> outIt( state );
		for ( ; ! outIt.atEnd(); outIt++ )
			outIt.trans->transFuncTable.empty();

		state = state->next;
	}
}

/**
 * Empty all transition functions going into a final state.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearFinFsmFunc()
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		/* Walk the final state's in list. */
		FsmInIterator<State, Transition> inIt( *st );
		for ( ; ! inIt.atEnd(); inIt++ )
			inIt.trans->transFuncTable.empty();
	}
}

/**
 * Clear pending out functions from the outFunc lists of final states.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearLeaveFsmFunc()
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++)
		(*st)->outTransFuncTable.empty();
}

/**
 * Clear pending out priorities from final states.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearLeaveFsmPrior( )
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = false;
		(*st)->outPriority = 0;
	}
}

/**
 * Remove all transition data. Remove funcs and outfuncs, zero priorities and
 * remove out priorities.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearAllTransData()
{
	State *state = stateList.head;
	while ( state ) {
		/* Clear out data. */
		state->outTransFuncTable.empty();
		state->isOutPriorSet = false;
		state->outPriority = 0;

		/* Clear transition data from the out transitions. */
		FsmOutIterator<State, Transition> outIt( state );
		for ( ; ! outIt.atEnd(); outIt++ ) {
			outIt.trans->transFuncTable.empty();
			outIt.trans->priority = 0;
		}

		state = state->next;
	}
}


/**
 * Zeros out the function ordering keys. This may be called before minimization
 * when it is known that no more fsm operations are going to be done.  This
 * will achieve greater reduction as states will not be separated on the basis
 * of function ordering.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		NullFunctionKeys( )
{
	/* For each state... */
	State *state = stateList.head;
	while ( state != NULL ) {
		/* Walk the transitions for the state. */
		FsmOutIterator<State, Transition> outIt( state );
		for ( ; ! outIt.atEnd(); outIt ++ ) {
			/* Walk the function table for the transition. */
			typename Transition::TransFuncEl *tfel = outIt.trans->transFuncTable.table;
			int ntfel = outIt.trans->transFuncTable.tableLength;
			for ( int j = 0; j < ntfel; j++, tfel++ )
				tfel->key = 0;
		}

		/* Null the function keys of the out transtions. */
		typename Transition::TransFuncEl *tfel = state->outTransFuncTable.table;
		int ntfel = state->outTransFuncTable.tableLength;
		for ( int j = 0; j < ntfel; j++, tfel++ )
			tfel->key = 0;

		state = state->next;
	}
}

/**
 * Mark all states reachable from state. Traverses transitions forward. Used
 * for removing states that have no path into them.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkReachableFromHere( State *state )
{
	/* Base case: return; */
	if ( state->isMarked )
		return;
	
	/* Set this state as marked. */
	state->isMarked = true;

	/* Recurse on all out transitions. */
	FsmOutIterator<State, Transition> outIt( state );
	for ( ; ! outIt.atEnd(); outIt++ )
		MarkReachableFromHere( outIt.trans->toState );
}

/**
 * Mark all states reachable from state. Traverse transitions backwards. Used
 * for removing dead end paths in graphs.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkReachableFromHereReverse( State *state )
{
	/* Base case: return; */
	if ( state->isMarked )
		return;
	
	/* Set this state as marked. */
	state->isMarked = true;

	/* Recurse on all items in transitions. */
	FsmInIterator<State, Transition> inIt( state );
	for ( ; ! inIt.atEnd(); inIt++ )
		MarkReachableFromHereReverse( inIt.trans->fromState );
}


/**
 * Tests the integrity of the transition lists and the fromStates.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		VerifyIntegrity()
{
	State *state = stateList.head;
	while ( state != NULL ) {
		/* Walk the out transitions and assert fromState is correct. */
		FsmOutIterator<State, Transition> outIt( state );
		for ( ; ! outIt.atEnd(); outIt++ )
			assert( outIt.trans->fromState == state );

		/* Walk the inlist and assert toState is correct. */
		FsmInIterator<State, Transition> inIt( state );
		for ( ; ! inIt.atEnd(); inIt++ )
			assert( inIt.trans->toState == state );

		state = state->next;
	}
}

#endif /* _RLFSM_FSMBASE_CPP */

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include "graph.h"
#include "graph.cpp"

struct MyState : public GraphState<MyState, int, int>
{
	int ThisIsStateData;

};

int testGraph1()
{
	MyState st0;
	MyState st1;
	MyState st2;
	MyState st3;

	Graph<MyState, int, int> graph, *g1, *g2, *g3;

	graph.AddToGraph( &st0 );
	graph.AddToGraph( &st1 );
	graph.AddToGraph( &st2 );
	graph.AddToGraph( &st3 );

	g1 = new Graph<MyState, int, int>(graph);

	graph.AttachStates( &st0, &st0, 0 );
	graph.AttachStates( &st0, &st0, 1 );
	graph.AttachStates( &st0, &st0, 3 );
	graph.AttachStates( &st0, &st0, 2 );
	graph.AttachStates( &st0, &st0, 0 );
	graph.AttachStates( &st3, &st0, 0 );
	graph.AttachStates( &st3, &st0, 0 );

	g2 = new Graph<MyState, int, int>(graph);

	graph.Dump( stdout );
	printf( "\n" );

	graph.DetachStates( &st0, &st0, 0 );

	graph.Dump( stdout );

	g3 = new Graph<MyState, int, int>(graph);

	graph.DetachState(&st0);
	graph.DetachState(&st1);
	graph.DetachState(&st2);
	graph.DetachState(&st3);

	delete g1;
	delete g2;
	delete g3;

	return 0;
}

int testGraph2()
{
	MyState st0;
	MyState st1;
	MyState st2;
	MyState st3;
	MyState st4;
	MyState st5;

	Graph<MyState, int, int> graph;

	graph.AddToGraph( &st0 );
	graph.AddToGraph( &st1 );
	graph.AddToGraph( &st2 );
	graph.AddToGraph( &st3 );
	graph.AddToGraph( &st4 );
	graph.AddToGraph( &st5 );

	graph.AttachStates( &st0, &st4, 0 );
	graph.AttachStates( &st1, &st4, 0 );
	graph.AttachStates( &st4, &st2, 0 );
	graph.AttachStates( &st4, &st3, 0 );

	graph.Dump( stdout );


	graph.DetachState(&st0);
	graph.DetachState(&st1);
	graph.DetachState(&st2);
	graph.DetachState(&st3);
	graph.DetachState(&st4);
	graph.DetachState(&st5);

	return 0;
}

void testGraph3()
{
	Graph<MyState, int, int> *graph = new Graph<MyState, int, int>;
	MyState *st1 = new MyState;
	MyState *st2 = new MyState;

	graph->AddToGraph(st1);
	graph->AddToGraph(st2);

	graph->AttachStates(st1, st2, 0);
	graph->SetLastTrans(new int);

	graph->AttachStates(st1, st2, 0);
	/*int *i = */graph->GetLastTrans();

	delete graph;
}

int main()
{
	testGraph3();
	return 0;
}

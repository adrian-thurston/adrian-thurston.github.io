/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Autil.
 *
 *  Autil is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Autil is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Autil; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "byteset.h"

void ByteSet::Empty()
{
	data[0] = data[1] = data[2] = data[3] = 0;
	data[4] = data[5] = data[6] = data[7] = 0;
}

void ByteSet::SetCharSet(CharSet cs)
{
	switch (cs) {
	case ascii:
		data[0] = 0xffffffff;
		data[1] = 0xffffffff;
		data[2] = 0xffffffff;
		data[3] = 0xffffffff;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case extend:
		data[0] = 0xffffffff;
		data[1] = 0xffffffff;
		data[2] = 0xffffffff;
		data[3] = 0xffffffff;
		data[4] = 0xffffffff;
		data[5] = 0xffffffff;
		data[6] = 0xffffffff;
		data[7] = 0xffffffff;
		break;
	case alnum:
		data[0] = 0x00000000;
		data[1] = 0x0000ffc0;
		data[2] = 0x7fffffe0;
		data[3] = 0x7fffffe0;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case alpha:
		data[0] = 0x00000000;
		data[1] = 0x00000000;
		data[2] = 0x7fffffe0;
		data[3] = 0x7fffffe0;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case cntrl:
		data[0] = 0xffdfffff;
		data[1] = 0x00000000;
		data[2] = 0x00000000;
		data[3] = 0x00000001;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case digit:
		data[0] = 0x00000000;
		data[1] = 0x0000ffc0;
		data[2] = 0x00000000;
		data[3] = 0x00000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case graph:
		data[0] = 0x00000000;
		data[1] = 0x7fffffff;
		data[2] = 0xffffffff;
		data[3] = 0xfffffffe;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case lower:
		data[0] = 0x00000000;
		data[1] = 0x00000000;
		data[2] = 0x00000000;
		data[3] = 0x7fffffe0;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case print:
		data[0] = 0x00000000;
		data[1] = 0xffffffff;
		data[2] = 0xffffffff;
		data[3] = 0xfffffffe;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case punct:
		data[0] = 0x00000000;
		data[1] = 0x7fff003f;
		data[2] = 0x8000001f;
		data[3] = 0x8000001e;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case space:
		data[0] = 0x005c0000;
		data[1] = 0x80000000;
		data[2] = 0x00000000;
		data[3] = 0x00000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case upper:
		data[0] = 0x00000000;
		data[1] = 0x00000000;
		data[2] = 0x7fffffe0;
		data[3] = 0x00000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case xdigit:
		data[0] = 0x00000000;
		data[1] = 0x0000ffc0;
		data[2] = 0x7e000000;
		data[3] = 0x7e000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	}
}

void ByteSet::UnsetCharSet(CharSet cs)
{
	switch (cs) {
	case ascii:
		data[0] &= ~0xffffffff;
		data[1] &= ~0xffffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xffffffff;
		break;
	case extend:
		data[0] &= ~0xffffffff;
		data[1] &= ~0xffffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xffffffff;
		data[4] &= ~0xffffffff;
		data[5] &= ~0xffffffff;
		data[6] &= ~0xffffffff;
		data[7] &= ~0xffffffff;
		break;
	case alnum:
		data[0] &= ~0x00000000;
		data[1] &= ~0x0000ffc0;
		data[2] &= ~0x7fffffe0;
		data[3] &= ~0x7fffffe0;
		break;
	case alpha:
		data[0] &= ~0x00000000;
		data[1] &= ~0x00000000;
		data[2] &= ~0x7fffffe0;
		data[3] &= ~0x7fffffe0;
		break;
	case cntrl:
		data[0] &= ~0xffdfffff;
		data[1] &= ~0x00000000;
		data[2] &= ~0x00000000;
		data[3] &= ~0x00000001;
		break;
	case digit:
		data[0] &= ~0x00000000;
		data[1] &= ~0x0000ffc0;
		data[2] &= ~0x00000000;
		data[3] &= ~0x00000000;
		break;
	case graph:
		data[0] &= ~0x00000000;
		data[1] &= ~0x7fffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xfffffffe;
		break;
	case lower:
		data[0] &= ~0x00000000;
		data[1] &= ~0x00000000;
		data[2] &= ~0x00000000;
		data[3] &= ~0x7fffffe0;
		break;
	case print:
		data[0] &= ~0x00000000;
		data[1] &= ~0xffffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xfffffffe;
		break;
	case punct:
		data[0] &= ~0x00000000;
		data[1] &= ~0x7fff003f;
		data[2] &= ~0x8000001f;
		data[3] &= ~0x8000001e;
		break;
	case space:
		data[0] &= ~0x005c0000;
		data[1] &= ~0x80000000;
		data[2] &= ~0x00000000;
		data[3] &= ~0x00000000;
		break;
	case upper:
		data[0] &= ~0x00000000;
		data[1] &= ~0x00000000;
		data[2] &= ~0x7fffffe0;
		data[3] &= ~0x00000000;
		break;
	case xdigit:
		data[0] &= ~0x00000000;
		data[1] &= ~0x0000ffc0;
		data[2] &= ~0x7e000000;
		data[3] &= ~0x7e000000;
		break;
	}
}

void ByteSet::ToggleCharSet(CharSet cs)
{
	switch (cs) {
	case ascii:
		data[0] ^= 0xffffffff;
		data[1] ^= 0xffffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xffffffff;
		break;
	case extend:
		data[0] ^= 0xffffffff;
		data[1] ^= 0xffffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xffffffff;
		data[4] ^= 0xffffffff;
		data[5] ^= 0xffffffff;
		data[6] ^= 0xffffffff;
		data[7] ^= 0xffffffff;
		break;
	case alnum:
		data[0] ^= 0x00000000;
		data[1] ^= 0x0000ffc0;
		data[2] ^= 0x7fffffe0;
		data[3] ^= 0x7fffffe0;
		break;
	case alpha:
		data[0] ^= 0x00000000;
		data[1] ^= 0x00000000;
		data[2] ^= 0x7fffffe0;
		data[3] ^= 0x7fffffe0;
		break;
	case cntrl:
		data[0] ^= 0xffdfffff;
		data[1] ^= 0x00000000;
		data[2] ^= 0x00000000;
		data[3] ^= 0x00000001;
		break;
	case digit:
		data[0] ^= 0x00000000;
		data[1] ^= 0x0000ffc0;
		data[2] ^= 0x00000000;
		data[3] ^= 0x00000000;
		break;
	case graph:
		data[0] ^= 0x00000000;
		data[1] ^= 0x7fffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xfffffffe;
		break;
	case lower:
		data[0] ^= 0x00000000;
		data[1] ^= 0x00000000;
		data[2] ^= 0x00000000;
		data[3] ^= 0x7fffffe0;
		break;
	case print:
		data[0] ^= 0x00000000;
		data[1] ^= 0xffffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xfffffffe;
		break;
	case punct:
		data[0] ^= 0x00000000;
		data[1] ^= 0x7fff003f;
		data[2] ^= 0x8000001f;
		data[3] ^= 0x8000001e;
		break;
	case space:
		data[0] ^= 0x005c0000;
		data[1] ^= 0x80000000;
		data[2] ^= 0x00000000;
		data[3] ^= 0x00000000;
		break;
	case upper:
		data[0] ^= 0x00000000;
		data[1] ^= 0x00000000;
		data[2] ^= 0x7fffffe0;
		data[3] ^= 0x00000000;
		break;
	case xdigit:
		data[0] ^= 0x00000000;
		data[1] ^= 0x0000ffc0;
		data[2] ^= 0x7e000000;
		data[3] ^= 0x7e000000;
		break;
	}
}

void ByteSet::SetBytes(unsigned char *set, int len)
{
	/* Skip the open bracket */
	for (int i = 0; i < len; i++, set++)
		SetByte(*set);
}

void ByteSet::UnsetBytes(unsigned char *set, int len)
{
	/* Skip the open bracket */
	for (int i = 0; i < len; i++, set++)
		UnsetByte(*set);
}

void ByteSet::ToggleBytes(unsigned char *set, int len)
{
	/* Skip the open bracket */
	for (int i = 0; i < len; i++, set++)
		ToggleByte(*set);
}

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Autil.
 *
 *  Autil is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Autil is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Autil; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AUTIL_BYTESET_H
#define _AUTIL_BYTESET_H

/**
 * Encapsulate set of bytes. Uses an array of integers to encode the step.
 * Byteset 
 */
class ByteSet
{
public:
	enum CharSet {
		ascii,
		extend,
		alnum,
		alpha,
		cntrl,
		digit,
		graph,
		lower,
		print,
		punct,
		space,
		upper,
		xdigit
	};

	ByteSet()
		{ Empty(); }

	ByteSet(unsigned char *set, int len)
		{ Empty(); SetBytes(set, len); }

	ByteSet(CharSet cs)
		{ Empty(); SetCharSet(cs); }

	void Empty();

	void SetByte(unsigned int c)
		{ data[c >> 5] |= 0x80000000 >> (c & 0x1f); }
	void SetBytes(unsigned char *set, int len);
	void SetCharSet(CharSet cs);

	void UnsetByte(unsigned int c)
		{ data[c >> 5] &= ~ (0x80000000 >> (c & 0x1f)); }
	void UnsetBytes(unsigned char *set, int len);
	void UnsetCharSet(CharSet cs);

	void ToggleByte(unsigned int c)
		{ data[c >> 5] ^= 0x80000000 >> (c & 0x1f); }
	void ToggleBytes(unsigned char *set, int len);
	void ToggleCharSet(CharSet cs);

	void operator = (ByteSet &set)
	{
		data[0] = set.data[0]; data[1] = set.data[1];
		data[2] = set.data[2]; data[3] = set.data[3];
		data[4] = set.data[4]; data[5] = set.data[5];
		data[6] = set.data[6]; data[7] = set.data[7];
	}

	int IsSet(unsigned int c)
		{ return data[c >> 5] & ( 0x80000000 >> (c & 0x1f) ); }

	void PrintThoseSet();
	
	unsigned int data[8];
};


#endif /* _AUTIL_BYTESET_H */

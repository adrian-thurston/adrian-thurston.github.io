/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "gotocodegen.h"
#include "bstmap.h"

using std::endl;

/* Init base data. */
GotoCodeGen::GotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
	FsmCodeGen(fsmName, machine, parseData, out),
	needErrorLabel(false)
{
}

/* Emit the goto to take for a given transition. */
void GotoCodeGen::emitTransGoto( int curState, FsmMachTrans *trans )
{
	if ( trans->funcs != FUNC_NO_FUNC )
		out << "goto tr" << trans - machine->allTrans << ";\n";
	else {
		/* Get the index of the state we go to. */
		if ( trans->toState != STATE_NO_STATE )
			out << "goto st" << trans->toState << ";\n";
		else {
			out << "goto err;\n";
			needErrorLabel = true;
		}
	}
}


/* Write the switch of functions a la tabcodegen. */
std::ostream &GotoCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	StringListEl *flel = parseData->funcList.head;
	int fnum = 0;
	while ( flel != NULL ) {
		out << "\tcase " << fnum << ": {\n";
		out << flel->data;
		out << "break;}" << endl;
		fnum += 1;
		flel = flel->next;
	}
	return out;
}


/* Emit the switch statement for jumping into the machine. Our current state
 * is represented by an integer and we need to use it to get into the correct
 * place in the machine. */
std::ostream &GotoCodeGen::JUMP_IN_SWITCH()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "\t\tcase " << st << ": goto st" << st << ";\n";
	}
	out << "\t\tdefault: return;\n";
	return out;
};

std::ostream &GotoCodeGen::STATE_GOTOS()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Emit any transitions that have functions and that go to 
		 * this state. */
		FsmMachTrans *trans = machine->allTrans;
		for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
			if ( trans->toState == st && trans->funcs != FUNC_NO_FUNC ) {
				/* Write the label for the transition so it can be jumped to. */
				out << "tr" << tr << ":\n";

				/* Write out the specific machine's representation of 
				 * executing the funcs. */
				transFunc( trans );

				out << "\tgoto st" << st << ";\n";
			}
		}

		out << "st" << st << ":\n";
		out << "\tif ( --len == 0 )\n";
		out << "\t\tgoto out" << st << ";\n";
		out << "\tswitch( (alph) *++p ) {\n";

		/* Get the fsm machine state. */
		FsmMachState *state = machine->allStates+st;

		/* Make the switch oriented state. */
		FsmMachSwitchState swState;
		machine->makeSwitchState( swState, *state );

		/* Write out the switch cases. */
		for ( int j = 0; j < swState.funcMap.size(); j++ ) {
			out << "\t\t";
			/* Write out all the characters that follow this transition. */
			Vector<int> &charVec = swState.funcMap[j].value;
			for ( int k = 0; k < charVec.size(); k++ ) {
				out << "case " << charVec[k] << ": ";
				if ( k % 4 == 3 )
					out << "\n\t\t";
			}
			/* Emit the transition. */
			FsmMachTrans *trans = machine->allTrans + 
					swState.funcMap.table[j].key;
			emitTransGoto( st, trans );
		}

		/* Get the default index and write it. Default will always be used. */
		trans = machine->allTrans + swState.dflIndex;
		out << "\t\tdefault: ";
		emitTransGoto( st, trans );

		/* Close off the transition switch. */
		out << "\t}\n";
	}
	return out;
}

std::ostream &GotoCodeGen::EXIT_STATES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		out << "out" << st << ":\n\t";
		FSM_PREFIX() << "curState = " << st << ";\n" << "\treturn;\n";
	}
	return out;
}

std::ostream &GotoCodeGen::FINISH_SWITCH()
{
	out << "\tswitch( cs ) {" << endl;
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		out << "\t\tcase " << st << ": ";
		if ( state->isFinState )
			out << "accept = 1; ";

		/* If there are out functions, write them. */
		if ( state->outFuncs != FUNC_NO_FUNC ) {
			int *funcs = machine->allTransFuncs + 
					machine->transFuncIndex[state->outFuncs];

			/* The first number is the length. */
			int flen = *funcs++;
			while ( flen-- > 0 ) {
				out << "{" << getCodeBuiltin(*funcs) << "}";
				funcs += 1;
			}
		}
		out << "break;" << endl;
	}
	out << "\t}\n";
	return out;
}

std::ostream &GotoCodeGen::ERROR_LABEL()
{
	if ( needErrorLabel ) {
		out << "err:\n\t"; 
		FSM_PREFIX() << "curState = -1;\n";
	}
	return out;
}

/* Init base data. */
CGotoCodeGen::CGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		GotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\t";
	FSM_NAME();
	out << "ExecFuncs( fsm, f+" << machine->transFuncIndex[state->outFuncs]
			<< ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit them the call the execute them. */
	out << "\t";
	FSM_NAME();
	out << "ExecFuncs( fsm, f+" << machine->transFuncIndex[trans->funcs]
			<< ", p );\n";
}


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}


void CGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"#define f "; FSM_NAME() << "_f\n"
		"#define alph unsigned char\n"
		"\n"
		"/* The array of functions. */\n"
		"#if "; ANY_FUNCS() << "\n"
		"static int "; FSM_NAME() << "_f[] = {\n";
		FUNCTIONS() << "\n"
		"};\n"
		"#endif\n"
		"\n"
		"/****************************************\n"
		" * "; FSM_NAME() << "Init\n"
		" */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/***************************************************************************\n"
		" * Function exection. We do not inline this as in tab\n"
		" * code gen because if we did, we might as well just expand \n"
		" * the function as in the faster goto code generator.\n"
		" */\n"
		"static void "; FSM_NAME() << "ExecFuncs( "; FSM_NAME() << " *fsm, int *funcs, char *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() <<
		"		}\n"
		"	}\n"
		"}\n"
		"\n"
		"/**********************************************************************\n"
		" * Execute the fsm on some chunk of data. \n"
		" */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	register char *p = data - 1;\n"
		"	register int len = dlen + 1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( "; FSM_PREFIX() << "curState ) {\n";
		JUMP_IN_SWITCH() <<
		"	}\n"
		"\n";
		STATE_GOTOS() <<
		"\n";
		EXIT_STATES() <<
		"\n";
		ERROR_LABEL() <<
		"}\n"
		"\n"
		"/**********************************************************************\n"
		" * Indicate to the fsm that the input is done. Does cleanup tasks.\n"
		" */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int cs = fsm->curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() <<
		"	fsm->accept = accept;\n"
		"}\n"
		"\n"
		"/*******************************************************\n"
		" * Did the machine accept?\n"
		" */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n"
		"#undef f\n"
		"#undef alph\n"
		"\n";
}

/* Init base data. */
CCGotoCodeGen::CCGotoCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
	GotoCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out funcs for the state, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCGotoCodeGen::stateOutFunc(FsmMachState *state)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( f+" << machine->transFuncIndex[state->outFuncs]
			<< ", p );\n";
}

/* Write out the funcs for the transition, we do not need to worry about
 * the funcs being FUNC_NO_FUNC. */
void CCGotoCodeGen::transFunc(FsmMachTrans *trans)
{
	/* There are out funcs, emit the call to execute them. */
	out << "\tExecFuncs( f+" << machine->transFuncIndex[trans->funcs] 
			<< ", p );\n";
}

/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( char *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n"
		"	/* The start state. */\n"
		"	static int startState;\n"
		"\n"
		"	/* Function exection. We do not inline this as in tab code gen\n"
		"	 * because if we did, we might as well just expand the function \n"
		"	 * as in the faster goto code generator. */\n"
		"	void ExecFuncs( int *funcs, char * );\n"
		"\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"\n";
}

void CCGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* some defines to lessen the code size. */\n"
		"#define f "; FSM_NAME() << "_f\n"
		"#define alph unsigned char\n"
		"\n"
		"/* The array of functions. */\n"
		"#if "; ANY_FUNCS() << "\n"
		"static int "; FSM_NAME() << "_f[] = {\n";
		FUNCTIONS() << "\n"
		"};\n"
		"#endif\n"
		"\n"
		"\n"
		"/****************************************\n"
		" * Make sure the fsm is initted.\n"
		" */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/****************************************\n"
		" * Initialize the fsm.\n"
		" */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = startState;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/***************************************************************************\n"
		" * Execute functions pointed to by funcs until the null function is found. \n"
		" */\n"
		"void "; FSM_NAME() << "::ExecFuncs( int *funcs, char *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() <<
		"		}\n"
		"	}\n"
		"}\n"
		"\n"
		"\n"
		"/**********************************************************************\n"
		" * Execute the fsm on some chunk of data. \n"
		" */\n"
		"void "; FSM_NAME() << "::Execute( char *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	register char *p = data - 1;\n"
		"	register int len = dlen + 1;\n"
		"\n"
		"	/* Switch statment to enter the machine. */\n"
		"	switch ( curState ) {\n";
		JUMP_IN_SWITCH() << "\n"
		"	}\n"
		"\n";
		STATE_GOTOS() <<
		"\n";
		EXIT_STATES() <<
		"\n";
		ERROR_LABEL() <<
		"}\n"
		"\n"
		"/**********************************************************************\n"
		" * "; FSM_NAME() << "::Finish\n"
		" *\n"
		" * Indicate to the fsm that the input is done. Does cleanup tasks.\n"
		" */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int cs = curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	this->accept = accept;\n"
		"}\n"
		"\n"
		"/*******************************************************\n"
		" * "; FSM_NAME() << "::Accept\n"
		" *\n"
		" * Did the machine accept?\n"
		" */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n"
		"#undef f\n"
		"#undef alph\n";
}

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fstream>

#include "rl.h"
#include "parsetree.h"
#include "paramcheck.h"
#include "fsm.h"
#include "fsmbuild.h"
#include "selcodegen.h"
#include "tabcodegen.h"
#include "ftabcodegen.h"
#include "gotocodegen.h"
#include "fgotocodegen.h"
#include "ipgcodegen.h"
#include "vector.h"
#include "version.h"

using std::ofstream;
using std::cout;
using std::cerr;
using std::endl;

#ifdef WIN32
#define strcasecmp stricmp
#endif

#define MSG_NO_INPUT         "no input file (-h will show usage information)"
#define MSG_EGIVEN_NOC       "warning: -e given but minimization is not enabled"
#define MSG_NO_MAIN_GRAPH    "main graph not defined"
#define MSG_ZERO_LEN_IN      "zero length output file name given"
#define MSG_OUT_ALREADY      "output file already given"
#define MSG_INVALID_PARAM    "invalid param specified (-h will show usage information)"


/* Io globals. */
ofstream *outputStream = 0;
char *inputFile = 0;
char *outputFile = 0;

/* Print stats? Dump the final fsm? */
bool printStats = false;
bool dumpFinal = false;

/* Controls minimization. */
MinimizeLevel minimizeLevel = MinimizeNone;
bool minimizeEveryOp = false;

enum CodeGenerationEnum {
	C_Code,
	CC_Code
} codeGeneration = C_Code;
char *defExtension = ".c";

enum CodeStyleEnum {
	GenTables,
	GenSwitch,
	GenFTables,
	GenGoto,
	GenFGoto,
	GenIpGoto
} codeStyle = GenTables;
	

/* Print a summary of the options. */
void usage()
{
	cout <<
"usage: ragel [options] file\n"
"general:\n"
"   -h, -H, -?   Print this usage and exit.\n"
"   -v           Print version information and exit.\n"
"   -o <file>    Write output to <file>.\n"
"   -s           Print stats on the compiled fsm.\n"
"   -f           Print the final fsm.\n"
"fsm minimization:\n"
"   -n           No minimization (default).\n"
"   -m           Find the minimal fsm accepting the language.\n"
"generated code language:\n"
"   -c           Generate c code (default).\n"
"   -C           Generate c++ code.\n"
"generated code style:\n"
"   -T0          Generate a table driven fsm (default).\n"
"   -T1          Generate a faster table driven fsm.\n"
"   -S0          Generate a switch driven fsm.\n"
"   -G0          Generate a goto driven fsm.\n"
"   -G1          Generate a faster goto driven fsm.\n"
"   -G2          Generate a really fast goto driven fsm.\n"
	;	
}

/* Print version information. */
void version()
{
	cout << "ragel v" VERSION << endl <<
			"Copyright 2002 Adrian Thurston" << endl;
}

/* c++ equivalent to strdup. */
char *strDup(const char *src)
{
	if (src != 0)
	{
		char *retVal = new char[strlen(src)+1];
		strcpy(retVal, src);
		return retVal;
	}
	else 
		return 0;
}

/* Scans a string looking for the file extension. If there is a file
 * extension then pointer returned points to inside the the string
 * passed in. Otherwise returns null. */
char *FindFileExtension( char *stemFile )
{
	char *ppos = stemFile + strlen(stemFile) - 1;
	/* Scan backwards from the end looking for the first dot.
	 * If we encounter a '/' before the first dot, then stop the scan. */
	while ( 1 ) {
		/* If we found a dot or got to the beginning of the string then
		 * we are done. */
		if ( ppos == stemFile || *ppos == '.' )
			break;

		/* If we hit a / then there is no extension. Done. */
		if ( *ppos == '/' ) {
			ppos = stemFile;
			break;
		}
		ppos--;
	} 

	/* If we got to the front of the string then bail we 
	 * did not find an extension  */
	if ( ppos == stemFile )
		ppos = 0;

	return ppos;
}

/* Make a file name from a stem. Removes the old filename suffix and
 * replaces it with a new one. Returns a newed up string. */
char *FileNameFromStem( char *stemFile, char *suffix )
{
	int len = strlen( stemFile );
	assert( len > 0 );

	/* Get the extension. */
	char *ppos = FindFileExtension( stemFile );

	/* If an extension was found, then shorten what we think the len is. */
	if ( ppos != 0 )
		len = ppos - stemFile;

	/* Make the return string from the stem and the suffix. */
	char *retVal = new char[ len + strlen( suffix ) + 1 ];
	strncpy( retVal, stemFile, len );
	strcpy( retVal + len, suffix );

	return retVal;
}


/* Count the transitions in the fsm by walking the state list. */
int countTransitions( Fsm *fsm )
{
	int numTrans = 0;
	State *state = fsm->stateList.head;
	while ( state != NULL ) {
		numTrans += state->outList.tableLength;
		numTrans += state->outRange.tableLength / 2;
		if ( state->outDefault != 0 )
			numTrans += 1;
		state = state->next;
	}
	return numTrans;
}

/* Count the indicies in a fsm machine by walking array of states. */
int countIndicies( FsmMachine<int> &machine )
{
	int sum = 0;
	for ( int state = 0; state < machine.numStates; state++ )
		sum += machine.allStates[state].numIndex;
	return sum;
}

/* Generate the code for a fsm. Assumes parseData is set up
 * properly. Called by parser code. */
void GenerateFsm( char *fsmName, ParseData *parseData )
{
	/* The machine that will take the compressed fsm. */
	FsmMachine<int> fsmMachine;

	/* Make a code generator that will output the header/code. */
	FsmCodeGen *codeGen = 0;
	switch ( codeGeneration ) {
	case C_Code:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CTabCodeGen( fsmName, &fsmMachine, 
					parseData, *outputStream );
			break;
		case GenSwitch:
			codeGen = new CSelCodeGen( fsmName, &fsmMachine, 
					parseData, *outputStream);
			break;
		case GenFTables:
			codeGen = new CFTabCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		case GenGoto:
			codeGen = new CGotoCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		case GenFGoto:
			codeGen = new CFGotoCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		case GenIpGoto:
			codeGen = new CIpGotoCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		}
		break;
	case CC_Code:
		switch ( codeStyle ) {
		case GenTables:
			codeGen = new CCTabCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		case GenSwitch:
			codeGen = new CCSelCodeGen( fsmName, &fsmMachine, 
					parseData, *outputStream );
			break;
		case GenFTables:
			codeGen = new CCFTabCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		case GenGoto:
			codeGen = new CCGotoCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		case GenFGoto:
			codeGen = new CCFGotoCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		case GenIpGoto:
			codeGen = new CCIpGotoCodeGen( fsmName, &fsmMachine,
					parseData, *outputStream );
			break;
		}
		break;
	}

	/* If the struct element was used then output the header portion. */
	if ( parseData->dataList.listLength > 0 ) {
		codeGen->writeOutHeader( );
	}

	/* If the graph dict is given, then output the code portion. */
	if ( parseData->machineGiven ) {
		/* Get the main line from the graph dict. */
		GraphDictNode *gdNode = parseData->graphDict.find("main");
		if ( gdNode == NULL ) {
			cerr << PROGNAME ": " MSG_NO_MAIN_GRAPH << endl;
			exit(1);
		}

		/* Build the graph from a walk of the parse tree. */
		Fsm *graph = gdNode->value->Walk();

		/* Do final removal of unreachable states. There should be no dead end
		 * There should be no dead end states however. The subtract
		 * intersection operators are the only places where they may be
		 * created and those operators clean them up. */
		graph->removeUnreachableStates();

		/* If minimizing we can optimize the graph somewhat. */
		if ( minimizeLevel != MinimizeNone ) {
			/* No more fsm operations are to be done. Function ordering numbers are
			 * no longer of use and will just hinder minimization. Clear them. */
			graph->nullFunctionKeys();

			/* Transition priorities are no longer of use We can clear them and will
			 * just kinder minimization as well. Clear them. */
			graph->allTransPrior( 0 );			
			graph->clearLeaveFsmPrior();
		}

		/* Minimize here even if we minimized at every op. Now that function
		 * keys have been cleared we may get a more minimal fsm. */
		switch ( minimizeLevel ) {
			case MinimizeNone:
				break;
			case MinimizeApprox:
				graph->minimizeApproximate();
				break;
			case MinimizeStable:
				graph->minimizeStable();
				break;
			case MinimizePartition1:
				graph->minimizePartition1();
				break;
			case MinimizePartition2:
				graph->minimizePartition2();
				break;
		}

		if ( dumpFinal )
			dumpGraph( cout, graph );

		if ( printStats ) {
			cout << "graph states:      " << graph->stateList.listLength << endl;
			cout << "graph transitions: " << countTransitions( graph ) << endl;
		}

		/* Build the machine from the graph and output it. */
		FsmBuild<State, int, Trans> fsmBuild( *graph, fsmMachine );
		fsmBuild.build();

		if ( printStats ) {
			cout << "machine states:    " << fsmMachine.numStates << endl;
			cout << "machine functions: " << fsmMachine.numTransFuncIndex << endl;
			cout << "function array:    " << fsmMachine.numTransFuncs << endl;
		}

		codeGen->writeOutCode( );
	}
}

/* Main, process args and call rlparse to start scanning input. */
int main(int argc, char **argv)
{
	/* Paramater specification. */
	ParameterCheck pc("T:S:G:Cco:senmabjkfvhH?-:", argc, argv);
	char *ext;

	while ( pc.Check() ) {
		switch ( pc.state ) {
		case ParameterCheck::match:
			switch ( pc.parameter ) {
			case 'o':
				if ( *pc.parameterArg == 0 ) {
					/* Complain, someone used -o "" */
					cerr << PROGNAME ": " MSG_ZERO_LEN_IN << endl;
					exit(1);
				}
				else if ( outputFile != 0 ) {
					/* Complain, two output files given. */
					cerr << PROGNAME ": " MSG_OUT_ALREADY << endl;
					exit(1);
				}
				else {
					/* Ok, remember the output file name. */
					outputFile = pc.parameterArg;
				}
				break;
			case 's':
				printStats = true;
				break;
			case 'e':
				minimizeEveryOp = true;
				break;
			case 'n':
				minimizeLevel = MinimizeNone;
				break;
			case 'm':
				minimizeLevel = MinimizePartition2;
				break;
			case 'a':
				minimizeLevel = MinimizeApprox;
				break;
			case 'b':
				minimizeLevel = MinimizeStable;
				break;
			case 'j':
				minimizeLevel = MinimizePartition1;
				break;
			case 'k':
				minimizeLevel = MinimizePartition2;
				break;
			case 'f':
				dumpFinal = true;
				break;
			case 'c':
				codeGeneration = C_Code;
				defExtension = ".c";
				break;
			case 'C':
				codeGeneration = CC_Code;
				defExtension = ".cc";
				break;
			case 'T':
				if ( pc.parameterArg[0] == '0' )
					codeStyle = GenTables;
				else if ( pc.parameterArg[0] == '1' )
					codeStyle = GenFTables;
				else {
					cerr << PROGNAME ": " MSG_INVALID_PARAM << endl;
					exit(1);
				}
				break;
			case 'S':
				if ( pc.parameterArg[0] == '0' )
					codeStyle = GenSwitch;
				else {
					cerr << PROGNAME ": " MSG_INVALID_PARAM << endl;
					exit(1);
				}
				break;
			case 'G':
				if ( pc.parameterArg[0] == '0' )
					codeStyle = GenGoto;
				else if ( pc.parameterArg[0] == '1' )
					codeStyle = GenFGoto;
				else if ( pc.parameterArg[0] == '2' )
					codeStyle = GenIpGoto;
				else {
					cerr << PROGNAME ": " MSG_INVALID_PARAM << endl;
					exit(1);
				}
				break;
			case 'v':
				version();
				exit(0);
			case 'H': case 'h': case '?':
				usage();
				exit(0);
			case '-':
				if ( strcasecmp(pc.parameterArg, "help") == 0 ) {
					usage();
					exit(0);
				}
				else if ( strcasecmp(pc.parameterArg, "version") == 0 ) {
					version();
					exit(0);
				}
				else {
					cerr << PROGNAME ": " MSG_INVALID_PARAM << endl;
					exit(1);
				}
			}
			break;

		case ParameterCheck::invalid:
			cerr << PROGNAME ": " MSG_INVALID_PARAM << endl;
			exit(1);

		case ParameterCheck::noparam:
			/* It is interpreted as an input file. */
			if ( *pc.curArg == 0 ) {
				cerr << PROGNAME ": zero length input file name given" << endl;
				exit(1);
			}
			if ( inputFile != 0 ) {
				cerr << PROGNAME ": input file already given" << endl;
				exit(1);
			}
			/* Remember the filename. */
			inputFile = pc.curArg;
			break;
		}
	}

	/* If the user wants minimization at every op, but no minimization level 
	 * is given, then print a warning. */
	if ( minimizeEveryOp && minimizeLevel == MinimizeNone )
		cerr << PROGNAME ": " MSG_EGIVEN_NOC << endl;

	/* Look for no input file specified. */
	if ( inputFile == 0 ) {
		cerr << PROGNAME ": " MSG_NO_INPUT << endl;
		exit(1);
	}

	/* If no output file name is given, then we must make one. */
	if ( outputFile == NULL ) {
		ext = FindFileExtension( inputFile );
		if ( ext != NULL && strcmp( ext, ".rh" ) == 0 )
			outputFile = FileNameFromStem( inputFile, ".h" );
		else 
			outputFile = FileNameFromStem( inputFile, defExtension );
	}

	/* Make sure we are not writing to the same file as the input file. */
	if ( strcmp( inputFile, outputFile  ) == 0 ) {
		cerr << PROGNAME ": output file \"" << outputFile  << 
				"\" is the same as the input file \"" << inputFile << "\"" << endl;
		exit(1);
	}

	/* Open the input file for reading. */
	rlin = fopen( inputFile, "rt" );
	if ( rlin == NULL ) {
		cerr << PROGNAME ": could not open " << inputFile << " for reading" << endl;
		exit(1);
	}

	/* Open the output file stream now. Use c++ style streams
	 * as that is what the FsmCodeWriteOut code uses. */
	outputStream = new ofstream( outputFile );
	if ( outputStream->bad() ) {
		cerr << PROGNAME ": error opening " << outputFile << " for writing" << endl;
		exit(1);
	}

	/* Put a header on the output to indicate that the file was machine generated. */
	*outputStream <<
		"/* Automatically generated by Ragel from \"" << inputFile << "\".\n"
		" *\n"
		" * Parts of this file are copied from Ragel source covered by the GNU\n"
		" * GPL. As a special exception, you may use the parts of this file copied\n"
		" * from Ragel source without restriction. The remainder is derived from\n"
		" * \"" << inputFile << "\" and inherits the copyright status of that file.\n"
		" */\n\n";

	/* Parse the input! */
	rlparse();

	/* Delete the ostream, causing it to flush. */
	delete outputStream;

	/* Finished. */
	return 0;
}

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _SELCODEGEN_H
#define _SELCODEGEN_H

#include <iostream>
#include <fstream>
#include "fsmmachine.h"
#include "parsetree.h"
#include "fsmcodegen.h"

/*
 * Swittch driven fsms.
 */
class SelCodeGen : public FsmCodeGen
{
public:
	SelCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );

protected:

	std::ostream &STATE_SWITCH();
	std::ostream &FINISH_SWITCH();

	void emitTransistion( int curState, FsmMachTrans *trans );

};

/*
 * class CSelCodeGen
 */
class CSelCodeGen : public SelCodeGen
{
public:
	CSelCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream & );

	virtual void writeOutHeader();
	virtual void writeOutCode();
};

/*
 * CCSelCodeGen
 */
class CCSelCodeGen : public SelCodeGen
{
public:
	CCSelCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );

	virtual void writeOutHeader();
	virtual void writeOutCode();
};


#endif /* _SELCODEGEN_H */

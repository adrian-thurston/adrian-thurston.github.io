/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "ftabcodegen.h"

/* Init base data. */
FTabCodeGen::FTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
	TabCodeGen(fsmName, machine, parseData, out)
{
}

/* Write out the out-func for a state. */
void FTabCodeGen::stateOutFunc(FsmMachState *state)
{
	if ( state->outFuncs == FUNC_NO_FUNC )
		out << "0";
	else {
		/* There are out funcs. Write out the pointer into the array
		 * of funcs and the number of funcs. */
		out << state->outFuncs+1;
	}
}

/* Write out the function for a transition. */
void FTabCodeGen::transFunc(FsmMachTrans *trans)
{
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else {
		out << trans->funcs+1;
	}
}

/* Write out the function switch. This switch is keyed on the 
 * values of the func index. */
std::ostream &FTabCodeGen::FUNC_SWITCH()
{
	/* Loop over all func indicies. */
	int *allTransFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "\tcase " << i+1 << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = allTransFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			out << "\t{" << getCodeBuiltin( *funcs ) << "}\n";
			funcs += 1;
		}
		out << "\tbreak;\n";
	}
	return out;
}

/* Init base class. */
CFTabCodeGen::CFTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
		FTabCodeGen(fsmName, machine, parseData, out)
{
}

void CFTabCodeGen::writeOutHeader()
{
	out <<
		"/* Forward dec state for the transition structure. */\n"
		"struct "; FSM_NAME() << "StateStruct;\n"
		"\n"
		"/* A single transition. */\n"
		"struct "; FSM_NAME() << "TransStruct\n"
		"{\n"
		"	struct "; FSM_NAME() << "StateStruct *toState;\n"
		"	int funcs;\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "TransStruct "; FSM_NAME() << "Trans;\n"
		"\n"
		"/* A single state. */\n"
		"struct "; FSM_NAME() << "StateStruct\n"
		"{\n"
		"	int lowIndex;\n"
		"	int highIndex;\n"
		"	void *transIndex;\n"
		"	int dflIndex;\n"
		"	int outFuncs;\n"
		"	int isFinState;\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "StateStruct "; FSM_NAME() << "State;\n"
		"\n"
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	"; FSM_NAME() << "State *curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFTabCodeGen::writeOutCode()
{
	out <<
		"#define s "; FSM_NAME() << "_s\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"/* The array of indicies into the transition array. */\n"
		"#if "; ANY_INDICIES() << "\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"#endif\n"
		"\n"
		"/* The aray of states. */\n"
		"static "; FSM_NAME() << "State "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS() << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static "; FSM_NAME() << "State *"; FSM_NAME() << "_startState = s+"; 
				START_STATE_OFFSET() << ";\n"
		"\n"
		"#undef f\n"
		"#undef s\n"
		"#undef i\n"
		"#undef t\n"
		"\n"
		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"inline static void "; FSM_NAME() << "ExecFuncs( "; FSM_NAME() << 
				" *fsm, int funcs, char *p )\n"
		"{\n"
		"	switch ( funcs ) {\n";
		FUNC_SWITCH() << "\n"
		"	}\n"
		"}\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen )\n"
		"{\n"
		"	char *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	"; FSM_NAME() << "State *cs = fsm->curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int c = (unsigned char)*p;\n"
		"		"; FSM_NAME() << "Trans *trans;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n"
		"		/* If the character is within the index bounds then get the\n"
		"		 * transition for it. If it is out of the transition bounds\n"
		"		 * we will use the default transition. */\n"
		"		if ( cs->lowIndex <= c && c < cs->highIndex ) {\n"
		"			/* Use the index to look into the transition array. */\n"
		"			trans = "; FSM_NAME() << "_t + \n"
		"				(("; INDEX_TYPE() << "*)cs->transIndex)[c - cs->lowIndex];\n"
		"		}\n"
		"		else {\n"
		"			/* Use the default index as the char is out of range. */\n"
		"			trans = "; FSM_NAME() << "_t + cs->dflIndex;\n"
		"		}\n"
		"\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( trans->funcs >= 0 )\n"
		"			"; FSM_NAME() << "ExecFuncs( fsm, trans->funcs, p );\n"
		"\n"
		"		/* Move to the new state. */\n"
		"		cs = trans->toState;\n"
		"	}\n"
		"finished:\n"
		"	fsm->curState = cs;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	"; FSM_NAME() << "State *cs = fsm->curState;\n"
		"	if ( cs != 0 && cs->isFinState ) {\n"
		"		/* If finishing in a final state then execute the\n"
		"		 * out functions for it. (if any). */\n"
		"		if ( cs->outFuncs != 0 )\n"
		"			"; FSM_NAME() << "ExecFuncs( fsm, cs->outFuncs, 0 );\n"
		"		fsm->accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		fsm->curState = 0;\n"
		"	}\n"
		"}\n";
}


/* Init base data. */
CCFTabCodeGen::CCFTabCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData, ostream &out ) : 
	FTabCodeGen(fsmName, machine, parseData, out)
{
}

void CCFTabCodeGen::writeOutHeader()
{
	out <<
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Function and index type. */\n"
		"	typedef int Func;\n"
		"\n"
		"	/* Forward dec state for the transition structure. */\n"
		"	struct State;\n"
		"\n"
		"	/* A single transition. */\n"
		"	struct Trans\n"
		"	{\n"
		"		State *toState;\n"
		"		int funcs;\n"
		"	};\n"
		"\n"
		"	/* A single state. */\n"
		"	struct State\n"
		"	{\n"
		"		int lowIndex;\n"
		"		int highIndex;\n"
		"		void *transIndex;\n"
		"		int dflIndex;\n"
		"		int outFuncs;\n"
		"		int isFinState;\n"
		"	};\n"
		"\n"
		"	/* Constructor. */\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( char *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	State *curState;\n"
		"	int accept;\n"
		"\n"
		"	inline void ExecFuncs( int funcs, char *p );\n"
		"\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"\n";
}

void CCFTabCodeGen::writeOutCode()
{
	out <<
		"#define s "; FSM_NAME() << "_s\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"/* The array of indicies into the transition array. */\n"
		"#if "; ANY_INDICIES() << "\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"#endif\n"
		"\n"
		"/* The aray of states. */\n"
		"static "; FSM_NAME() << "::State "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "::Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS() << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static "; FSM_NAME() << "::State *"; FSM_NAME() 
				<< "_startState = s+"; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"inline void "; FSM_NAME() << "::ExecFuncs( int funcs, char *p )\n"
		"{\n"
		"	switch ( funcs ) {\n";
		FUNC_SWITCH() << "\n"
		"	}\n"
		"}\n"
		"\n"
		"/* Make sure the machine is initialized. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = "; FSM_NAME() << "_startState;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( char *data, int dlen )\n"
		"{\n"
		"	char *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	State *cs = curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int c = (unsigned char)*p;\n"
		"		Trans *trans;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n"
		"		/* If the character is within the index bounds then get the\n"
		"		 * transition for it. If it is out of the transition bounds\n"
		"		 * we will use the default transition. */\n"
		"		if ( cs->lowIndex <= c && c < cs->highIndex ) {\n"
		"			/* Use the index to look into the transition array. */\n"
		"			trans = "; FSM_NAME() << "_t + \n"
		"				(("; INDEX_TYPE() << "*)cs->transIndex)[c - cs->lowIndex];\n"
		"		}\n"
		"		else {\n"
		"			/* Use the default index as the char is out of range. */\n"
		"			trans = "; FSM_NAME() << "_t + cs->dflIndex;\n"
		"		}\n"
		"\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( trans->funcs != 0 )\n"
		"			ExecFuncs( trans->funcs, p );\n"
		"\n"
		"		/* Move to the new state. */\n"
		"		cs = trans->toState;\n"
		"	}\n"
		"finished:\n"
		"	curState = cs;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	State *cs = curState;\n"
		"	if ( cs != 0 && cs->isFinState ) {\n"
		"		/* If finishing in a final state then execute the\n"
		"		 * out functions for it. (if any). */\n"
		"		if ( cs->outFuncs != 0 )\n"
		"			ExecFuncs( cs->outFuncs, 0 );\n"
		"		accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		curState = 0;\n"
		"	}\n"
		"}\n";
}

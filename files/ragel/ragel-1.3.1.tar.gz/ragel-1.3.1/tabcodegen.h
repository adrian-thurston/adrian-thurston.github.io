/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _TABCODEGEN_H
#define _TABCODEGEN_H

#include <iostream>
#include <fstream>
#include "fsmmachine.h"
#include "parsetree.h"
#include "fsmcodegen.h"

/** TabCodeGen */
class TabCodeGen : public FsmCodeGen
{
public:
	TabCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );
	virtual ~TabCodeGen() { }

protected:
	std::ostream &FUNC_SWITCH();
	std::ostream &INDEX_TYPE();
	std::ostream &INDICIES();
	std::ostream &STATES();
	std::ostream &TRANSITIONS();

	virtual void stateOutFunc(FsmMachState *state);
	virtual void transFunc(FsmMachTrans *trans);
};

/** CTabCodeGen */
class CTabCodeGen : public TabCodeGen
{
public:
	CTabCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );

	virtual void writeOutHeader();
	virtual void writeOutCode();
};

/** CCTabCodeGen */
class CCTabCodeGen : public TabCodeGen
{
public:
	CCTabCodeGen( char *fsmName, FsmMachine<int> *machine,
			ParseData *parseData, ostream &out );

	virtual void writeOutHeader();
	virtual void writeOutCode();
};


#endif /* _TABCODEGEN_H */

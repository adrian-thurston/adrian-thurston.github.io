/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_BSTMAP_H
#define _AAPL_BSTMAP_H

#include "compare.h"
#include "vector.h"

#ifdef AAPL_NAMESPACE
namespace Aapl {
#endif

/**
 * \brief Element for BstMap.
 *
 * Stores the key and value pair. 
 */
template <class Key, class Value> struct BstMapEl
{
	BstMapEl() {}
	BstMapEl(const Key &key) : key(key) {}
	BstMapEl(const Key &key, const Value &val) : key(key), value(val) {}

	const Key &getKey() { return key; }

	/** \brief The key */
	Key key;

	/** \brief The value. */
	Value value;
};

#ifdef AAPL_NAMESPACE
}
#endif

/**
 * \addtogroup bst 
 * @{
 */

/** 
 * \class BstMap
 * \brief Binary search table for key and value pairs.
 *
 * BstMap stores each element as a key and value pair. The key and value can
 * be any type. A compare class for the key must be supplied.
 */

/*@}*/

#define BASE_COMPARE(name) Compare::name
#define BST_TEMPL_DECLARE class Key, class Value, \
		class Compare, class Resize = ResizeExpn
#define BST_TEMPL_DEF class Key, class Value, class Compare, class Resize
#define BST_TEMPL_USE Key, Value, Compare, Resize
#define GET_KEY(el) (el->getKey())
#define BsTable BstMap
#define Element BstMapEl<Key, Value>
#define BSTMAP

#include "bstcommon.h"

#undef BASE_COMPARE
#undef BST_TEMPL_DECLARE
#undef BST_TEMPL_DEF
#undef BST_TEMPL_USE
#undef GET_KEY
#undef BsTable
#undef Element
#undef BSTMAP

#ifdef AAPL_NAMESPACE
namespace Aapl {
#endif

/**
 * \fn BstMap::insert(const Key &key, BstMapEl<Key, Value> **lastFound)
 * \brief Insert the given key.
 *
 * If the given key does not already exist in the table then a new element
 * having key is inserted. They key copy constructor and value default
 * constructor are used to place the pair in the table. If lastFound is given,
 * it is set to the new entry created. If the insert fails then lastFound is
 * set to the existing pair of the same key.
 *
 * \returns The new element created upon success, null upon failure.
 */

/**
 * \fn BstMap::insertMulti(const Key &key)
 * \brief Insert the given key even if it exists already.
 *
 * If the key exists already then a new element having key is placed next
 * to some other pair of the same key. InsertMulti cannot fail. The key copy
 * constrcutor and the value default constructor are used to place the pair in
 * the table.
 *
 * \returns The new element created.
 */


/**
 * \brief Insert the given key-value pair.
 *
 * If the given key does not already exist in the table then the key-value
 * pair is inserted. Copy constructors are used to place the pair in the
 * table. If lastFound is given, it is set to the new entry created. If the
 * insert fails then lastFound is set to the existing pair of the same key.
 *
 * \returns The new element created upon success, null upon failure.
 */
template <class Key, class Value, class Compare, class Resize> 
		BstMapEl<Key, Value> *BstMap<Key, Value, Compare, Resize>::
		insert(const Key &key, const Value &val, BstMapEl<Key, Value> **lastFound)
{
	BstMapEl<Key, Value> *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->getKey());

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != NULL )
				*lastFound = mid;
			return 0;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = makeRawSpaceFor(insertPos, 1);
	new(table + insertPos) BstMapEl<Key, Value>(key, val);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = table + insertPos;
	return table + insertPos;
}


/**
 * \brief Insert the given key-value pair even if the key exists already.
 *
 * If the key exists already then the key-value pair is placed next to some
 * other pair of the same key. InsertMulti cannot fail. Copy constrcutors are
 * used to place the pair in the table.
 *
 * \returns The new element created.
 */
template <class Key, class Value, class Compare, class Resize> 
		BstMapEl<Key, Value> *BstMap<Key, Value, Compare, Resize>::
		insertMulti(const Key &key, const Value &val)
{
	BstMapEl<Key, Value> *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (tableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = table;
		goto Insert;
	}

	lower = table;
	upper = table + tableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->getKey());

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			lower = mid;
			goto Insert;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - table;

	/* Do the insert. */
	tableLength = makeRawSpaceFor(insertPos, 1);
	new(table + insertPos) BstMapEl<Key, Value>(key, val);

	/* Return the element inserted. */
	return table + insertPos;
}

#ifdef AAPL_NAMESPACE
}
#endif

#endif /* _AAPL_BSTMAP_H */

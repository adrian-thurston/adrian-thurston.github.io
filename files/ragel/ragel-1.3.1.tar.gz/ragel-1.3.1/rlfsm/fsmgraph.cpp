/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMGRAPH_CPP
#define _RLFSM_FSMGRAPH_CPP

#include <assert.h>

#include "fsmgraph.h"
#include "mergesort.h"
#include "fsmstate.cpp"
#include "fsmbase.cpp"
#include "fsmattach.cpp"

/**
 * Make a new state. The new state will be put on the graph's
 * list of state. The new state can be created final or non final.
 */
template < class State, class TransFunc, class Transition >
		State *FsmGraph<State, TransFunc, Transition>::
		NewState(bool isFinState)
{
	/* Create the new state. */
	stateList.append( new State() );

	/* Do we want to create this state as a final state. */
	if (isFinState)
		SetFinState( stateList.tail );

	/* Return the new state. */
	return stateList.tail;
}

/**
 * Create an fsm that is a concatenation of the characters in the given string.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::ConcatFsm( char *str, int len )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state and set it as the start state. */
	State *last = retVal->NewState();
	retVal->startState = last;

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *newState = retVal->NewState();
		retVal->AttachStates( last, newState, KeyTypeSingle, str[i], 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->SetFinState(last);
	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		ConcatFsm( int *str, int len )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state and set it as the start state. */
	State *last = retVal->NewState();
	retVal->startState = last;

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *newState = retVal->NewState();
		retVal->AttachStates( last, newState, KeyTypeSingle, str[i], 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->SetFinState(last);
	return retVal;
}


template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		ConcatFsm( int chr )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	retVal->startState = start;
	State *end = retVal->NewState(true);

	/* Attach on the character. */
	retVal->AttachStates( start, end, KeyTypeSingle, chr, 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		OrFsm( char *set, int len )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	/* Set the first as the start state and attach on all the chars in the given
	 * string of characters. */
	retVal->startState = start;
	for ( int i = 0; i < len; i++ )
		retVal->AttachStates( start, end, KeyTypeSingle, set[i], 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		OrFsm( int *set, int len )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	/* Set the first as the start state and attach on all the integers in the
	 * given string of ints. */
	retVal->startState = start;
	for ( int i = 0; i < len; i++ )
		retVal->AttachStates( start, end, KeyTypeSingle, set[i], 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::NullFsm()
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Give it one state with no transitions making it
	 * the start state and final state. */
	retVal->startState = retVal->NewState(true);

	/* Return new Graph. */
	return retVal;
}

/**
 * Make a graph with two states and the default transition between them.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::DotFsm()
{
	/* New graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	/* Set the start state and attach. */
	retVal->startState = start;
	retVal->AttachStates( start, end, KeyTypeDefault, 0, 0 );

	return retVal;
}

/**
 * Make a graph with one state (which is final) and a default transition back
 * to itself.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::DotStarFsm()
{
	/* New graph. */
	FsmGraph *retVal = new FsmGraph;

	/* One state which is final and is the start state. */
	State *start = retVal->NewState(true);
	retVal->startState = start;

	/* Attach start to start on default. */
	retVal->AttachStates( start, start, KeyTypeDefault, 0, 0 );

	return retVal;
}

/**
 * Make a graph with one two states and a range of transitions between them.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		RangeFsm(int low, int high)
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	/* Attach using the range of characters. */
	retVal->AttachStates( start, end, KeyTypeRange, low, high );
	retVal->startState = start;

	return retVal;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Star(bool leavingFsm)
{
	/* Reset the final bits for a regular merge. */
	SetFinBits( 0 );

	/* Build a state set consisting of our start state. */
	StateSet startStateSet;
	startStateSet.set( startState );

	/* For the merging process. */
	MergeData md;

	/* Get a copy of the final state set before creating the new
	 * start state. It may get set final and we don't want the start
	 * state to be included in the final state set. If it is included
	 * in the final state set then all the final states after it get
	 * the transitions of the start state doubled up. That's incorrect.*/
	StateSet finStateSetCopy(finStateSet);

	/* This will be the new start state. It gets set as final and the
	 * existing start state is merged with it. */
	State *newState = NewState(false);
	MergeStates( md, newState, startStateSet, false );
	
	/* Set it as the start state. */
	startState = newState;
	startStateSet.setAs( newState );

	/* For all the final states, merge with the new start state. */
	State **st = finStateSetCopy.table;
	int nst = finStateSetCopy.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		MergeStates( md, *st, startStateSet, leavingFsm );
	}

	/* Now it is safe to merge the start state with itself (provided it
	 * is set final). */
	if ( startState->isFinState )
		MergeStates( md, startState, startStateSet, leavingFsm );

	/* Now ensure the new start state is a final state. */
	SetFinState(startState);

	/* Fill in any states that were newed up as combinations of others. */
	FillInStates( md );

	/* Remove states that have no path into them. */
	RemoveUnreachableStates();

	/* There is nothing in the Star routine to cause states to loose
	 * thier final stateness. So assert the fact that there should be
	 * no non-final states with out functions/priorites. */
	VerifyOutFuncs();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Concat(FsmGraph *other, bool leavingFsm)
{
	/* Reset the final bits for a regular merge. */
	SetFinBits( 0 );
	other->SetFinBits( 0 );

	/* Build a state set consisting of other's start state. */
	StateSet startStateSet;
	startStateSet.set( other->startState );

	/* For the merging process. */
	MergeData md;

	/* Get a copy of our final state set. We need to iterate over it
	 * while it may change. */
	StateSet finStateSetCopy(finStateSet);

	/* Unset all of our final states. */
	UnsetAllFinStates();

	/* Merge the lists. Get the final states from other. */
	stateList.append( other->stateList );
	finStateSet.set( other->finStateSet );
	
	/* Since other's list is emtpy, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our (former) final states with the start state of other. */
	State **st = finStateSetCopy.table;
	int nst = finStateSetCopy.tableLength;
	for (int i = 0; i < nst; i++, st++)
		MergeStates( md, *st, startStateSet, leavingFsm );

	/* Fill in any new states made from merging. */
	FillInStates( md );

	/* Remove any states that have no path into them. */
	RemoveUnreachableStates();

	/* Strip out functions/priorities from non final states. */
	StripNonFinalStates();
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		DoOr(FsmGraph *other)
{
	/* Build a state set consisting of both start states */
	StateSet startStateSet;
	startStateSet.set( startState );
	startStateSet.set( other->startState );

	/* For the merging process. */
	MergeData md;

	/* Merge the lists. This will move all the states from otherj
	 * into this. No states will be deleted. */
	stateList.append( other->stateList );

	/* Move the final set data from other into this. */
	finStateSet.set(other->finStateSet);
	other->finStateSet.empty();

	/* Since other's list is emtpy, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Create a new start state. */
	State *newStartState = NewState();
	startState = newStartState;

	/* Merge the start states. */
	MergeStates( md, newStartState, startStateSet, false );

	/* Fill in any new states made from merging. */
	FillInStates( md );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Or(FsmGraph *other)
{
	/* Reset the final bits for a regular merge. */
	SetFinBits( 0 );
	other->SetFinBits( 0 );

	/* Call Worker routine. */
	DoOr( other );

	/* Remove states which have no path into them. */
	RemoveUnreachableStates();

	/* Veryify that there are no out functions on non final states.
	 * This should be true as no states should have their final stateness removed. */
	VerifyOutFuncs();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Intersect(FsmGraph *other)
{
	/* Set the fin bits on this and other to want each other. */
	SetFinBits( SB_WANTOTHER1 );
	other->SetFinBits( SB_WANTOTHER2 );

	/* Unset final states in both. */
	UnsetAllFinStates();
	other->UnsetAllFinStates();

	/* Call worker Or routine. */
	DoOr( other );

	/* Remove states that have no path into them. */
	RemoveUnreachableStates();

	/* Remove states that have no path to a final state. */
	RemoveDeadEndStates();

	/* Strip the out function data from states that are no longer final. */
	StripNonFinalStates();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Subtract(FsmGraph *other)
{
	/* Set the fin bits of other to be killers. */
	SetFinBits( 0 );
	other->SetFinBits( SB_KILLOTHERS );

	/* Unset all final states and remove all transition data from other. */
	other->UnsetAllFinStates();
	other->ClearAllTransData();

	/* Call worker Or routine. */
	DoOr( other );

	/* Remove states that have no path into them. */
	RemoveUnreachableStates();

	/* Remove states that have no path to a final state. */
	RemoveDeadEndStates();

	/* Strip the out function data from states that are no longer final. */
	StripNonFinalStates();
}

/**
 * Ensure that the start state is free of entry points (aside from the fact
 * that it is the start state). If the start state has entry points then Make a
 * new start state by merging with the old one. Useful before modifying start
 * transitions. If the existing start state has any entry points other than the
 * start state entry then modifying its transitions changes more than the start
 * transitions. So isolate the start state by separating it out such that it
 * only has start stateness as it's entry point.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::IsolateStartState( )
{
	/* TODO: Need to be able to determine if the start state has any in
	 * transitions.  This cannot be accurately done by checking if inList is
	 * empty because inList may contain null pointers. For now, simply dup the
	 * start state unconditionally. */

	/* Reset the final bits for a regular merge. */
	SetFinBits( 0 );

	/* Build a state set consisting of our start state. */
	StateSet startStateSet;
	startStateSet.set( startState );

	/* For the merging process. */
	MergeData md;

	/* This will be the new start state. It the existing start
	 * state is merged with it. */
	State *newState = NewState(false);
	MergeStates( md, newState, startStateSet, false );
	
	/* Set it as the start state. */
	startState = newState;
	startStateSet.setAs( newState );

	/* Stfil and stateDict will be empty because the merging of the old start
	 * state into the new one will not have any conflicting transitions. */
	assert( md.stateDict.nodeCount == 0 );
	assert( md.stfil.listLength == 0 );

	/* The old start state may be unreachable. */
	RemoveUnreachableStates();
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		SetStateNumbers()
{
	int curNum = 0;
	State *state = stateList.head;
	while (state != 0) {
		state->num = curNum;
		curNum++;
		state = state->next;
	}
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		UnsetAllFinStates()
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ ) {
		(*st)->isFinState = false;
	}
	finStateSet.empty();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		SetFinBits( int finStateBits )
{
	State *state = stateList.head;
	while ( state != 0 ) {
		if ( state->isFinState )
			state->stateBits = finStateBits;
		else
			state->stateBits = 0;

		state = state->next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MergeStates( MergeData &md, State *newState, StateSet &stateSet, 
				bool leavingFsm )
{
	int bits = newState->stateBits;
	bool finState = newState->isFinState;

	State **stp = stateSet.table;
	int nst = stateSet.tableLength;
	for ( int i = 0; i < nst; i++, stp++ ) {
		State *src = *stp;

		/* Get the out transitions. */
		OutTransCopy2( md, newState, src, leavingFsm );

		/* Get its and final state status. */
		bits |= src->stateBits;
		if ( src->isFinState )
			finState = true;

		/* Merge the outTransFuncTable. */
		if ( src == newState ) {
			/* Duplicate the list. */
			typename Transition::TransFuncTable
					srcTransTable( src->outTransFuncTable );
			newState->SetOutFunctions( srcTransTable );
		}
		else {
			/* Get the out functions. */
			newState->SetOutFunctions( src->outTransFuncTable );
		}

		if ( src->isOutPriorSet ) {
			newState->isOutPriorSet = true;
			newState->outPriority = src->outPriority;
		}

		/* Call user routine. */
		newState->MergeState( src );
	}

	if ( bits&SB_KILLOTHERS ) {
		/* One final state is a killer, don't set final. */
		finState = false;

		/* Kill the out transitions. Reset the priority. */
		newState->outTransFuncTable.empty();
		newState->isOutPriorSet = false;
		newState->outPriority = 0;
	}

	if ( (bits&SB_WANTOTHER) == SB_WANTOTHER ) {
		/* There are companions in this state, we can make it final. */
		finState = true;
	}
	else if ( bits&SB_WANTOTHER ) {
		/* One state wants the other but it is not there. */
		finState = false;

		/* Kill the out transitions. Reset the priority. */
		newState->outTransFuncTable.empty();
		newState->isOutPriorSet = false;
		newState->outPriority = 0;
	}

	newState->stateBits = bits;
	if ( finState )
		SetFinState( newState );
	else
		UnsetFinState( newState );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FillInStates( MergeData &md )
{
	/* Merge any states that are awaiting mergin. This will likey cause
	 * other states to be added to the stfil list. */
	State *state = md.stfil.head;
	while ( state != 0 ) {
		MergeStates( md, state, state->stateDictNode->stateSet, false );
		state = state->next;
	}

	/* For all the states that are on the stfil list. Delete their stateSets
	 * and move them back to the main list. */
	while ( md.stfil.listLength > 0 ) {
		/* Delete and reset the state set. */
		State *state = md.stfil.head;
		delete state->stateDictNode;
		state->stateDictNode = 0;

		/* Move the list from the stfil list to the graph's list. */
		md.stfil.detach( state );
		stateList.append( state );
	}

	/* Stfil will now be empty. We do not need to delete its elements. 
	 * stateDict will still have it's ptrs/size set but all of it's nodes
	 * will be deleted so we don't need to clean it up. */
}

template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		PartitionRound( State **statePtrs, MinPartition<State> *parts, int numParts )
{
	/* For each partition. */
	for ( int p = 0; p < numParts; p++ ) {
		/* Fill the pointer array with the states in the partition. */
		int s, numStates = parts[p].list.listLength;
		State *state = parts[p].list.head;
		for ( s = 0; state != 0; s++, state = state->next )
			statePtrs[s] = state;

		/* Sort the states using the partitioning compare. */
		MergeSort< State*, PartitionCompare<State, Transition> >::sort( 
				statePtrs, numStates );

		/* Assign the states into partitions based on the results of the sort. */
		int destPart = p, firstNewPart = numParts;
		for ( s = 1; s < numStates; s++ ) {
			/* If this state differs from the last then move to the next partition. */
			if ( PartitionCompare<State, Transition>::Compare( 
					statePtrs[s-1], statePtrs[s] ) < 0 )
			{
				/* The new partition is the next avail spot. */
				destPart = numParts;
				numParts += 1;
			}

			/* If the state is not staying in the first partition, then
			 * transfer it to its destination partition. */
			if ( destPart != p ) {
				State *state = parts[p].list.detach( statePtrs[s] );
				parts[destPart].list.append( state );
			}
		}

		/* Fix the partition pointer for all the states that got moved to a new
		 * partition. This must be done after the states are transfered so the
		 * result of the sort is not altered. */
		for ( int newPart = firstNewPart; newPart < numParts; newPart++ ) {
			State *state = parts[newPart].list.head;
			while ( state != 0 ) {
				state->alg.partition = &parts[newPart];
				state = state->next;
			}
		}
	}

	return numParts;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MinimizePartition1()
{
	/* Nothing to do if there are no states. */
	if (stateList.listLength == 0)
		return;

	/* 
	 * First thing is to partition the states by final state status and
	 * transition functions. This gives us an initial partitioning to work
	 * with.
	 */

	/* Fill up an array of pointers to the states for easy sorting. */
	int s, numStates = stateList.listLength;
	State** statePtrs = new State*[numStates];
	State *state = stateList.head;
	for ( s = 0; s < numStates; s++ ) {
		statePtrs[s] = state;
		state = state->next;
	}
		
	/* Sort the states using the array of states. */
	MergeSort< State*, InitPartitionCompare<State, Transition> >::sort( 
			statePtrs, numStates );

	/* An array of lists of states is used to partition the states. */
	MinPartition<State> *parts = new MinPartition<State>[numStates];

	/* Assign the states into partitions. */
	int destPart = 0;
	for ( s = 0; s < numStates; s++ ) {
		/* If this state differs from the last then move to the next partition. */
		if ( s > 0 && InitPartitionCompare<State, Transition>::Compare( 
				statePtrs[s-1], statePtrs[s] ) < 0 )
		{
			/* Move to the next partition. */
			destPart += 1;
		}

		/* Put the state into its partition. */
		statePtrs[s]->alg.partition = &parts[destPart];
		parts[destPart].list.append( statePtrs[s] );
	}

	/* We just moved all the states from the main list into partitions without
	 * taking them off the main list. So clean up the main list now. */
	stateList.abandon();

	/* Split partitions. */
	int numParts = destPart + 1;
	while ( true ) {
		/* Test all partitions for splitting. */
		int newNum = PartitionRound( statePtrs, parts, numParts );

		/* When no partitions can be split, stop. */
		if ( newNum == numParts )
			break;

		numParts = newNum;
	}

	/* Fuse states in the same partition. The states will end up back on the
	 * main list. */
	FusePartitions( parts, numParts );

	/* Cleanup. */
	delete[] statePtrs;
	delete[] parts;
}

template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		SplitCandidates( State **statePtrs, MinPartition<State> *parts, int numParts )
{
	/* The lists of unsplitable (partList) and splitable partitions. 
	 * Only partitions in the splitable list are check for needing splitting. */
	DList< MinPartition<State> > partList, splittable;

	/* Initially, all partitions are born from a split (the initial
	 * partitioning) and can cause other partitions to be split. So any
	 * partition with a state with a transition out to another partition is a
	 * candidate for splitting. This will make every partition except possibly
	 * partitions of final states split candidates. */
	for ( int p = 0; p < numParts; p++ ) {
		/* Assume not active. */
		parts[p].active = false;

		/* Look for a trans out of any state in the partition. */
		State *state = parts[p].list.head;
		while ( state != 0 ) {
			/* If there is at least one transition out to another state then 
			 * the partition becomes splittable. */
			FsmOutIterator<State, Transition> outIt( state );
			if ( ! outIt.atEnd() ) {
				parts[p].active = true;
				break;
			}
			state = state->next;
		}

		/* If it was found active then it goes on the splittable list. */
		if ( parts[p].active )
			splittable.append( &parts[p] );
		else
			partList.append( &parts[p] );
	}

	/* While there are partitions that are splittable, pull one off and try
	 * to split it. If it splits, determine which partitions may now be split
	 * as a result of the newly split partition. */
	while ( splittable.listLength > 0 ) {
		MinPartition<State> *partition = splittable.detachFirst();

		/* Fill the pointer array with the states in the partition. */
		int s, numStates = partition->list.listLength;
		State *state = partition->list.head;
		for ( s = 0; state != 0; s++, state = state->next )
			statePtrs[s] = state;

		/* Sort the states using the partitioning compare. */
		MergeSort< State*, PartitionCompare<State, Transition> >::sort( 
				statePtrs, numStates );

		/* Assign the states into partitions based on the results of the sort. */
		MinPartition<State> *destPart = partition;
		int firstNewPart = numParts;
		for ( s = 1; s < numStates; s++ ) {
			/* If this state differs from the last then move to the next partition. */
			if ( PartitionCompare<State, Transition>::Compare(
					statePtrs[s-1], statePtrs[s] ) < 0 )
			{
				/* The new partition is the next avail spot. */
				destPart = &parts[numParts];
				numParts += 1;
			}

			/* If the state is not staying in the first partition, then
			 * transfer it to its destination partition. */
			if ( destPart != partition ) {
				State *state = partition->list.detach( statePtrs[s] );
				destPart->list.append( state );
			}
		}

		/* Fix the partition pointer for all the states that got moved to a new
		 * partition. This must be done after the states are transfered so the
		 * result of the sort is not altered. */
		int newPart;
		for ( newPart = firstNewPart; newPart < numParts; newPart++ ) {
			State *state = parts[newPart].list.head;
			while ( state != 0 ) {
				state->alg.partition = &parts[newPart];
				state = state->next;
			}
		}

		/* Put the partition we just split and any new partitions that came out
		 * of the split onto the inactive list. */
		partition->active = false;
		partList.append( partition );
		for ( newPart = firstNewPart; newPart < numParts; newPart++ ) {
			parts[newPart].active = false;
			partList.append( &parts[newPart] );
		}

		if ( destPart == partition )
			continue;

		/* Now determine which partitions are splittable as a result of
		 * splitting partition by walking the in lists of the states in
		 * partitions that got split. Partition is the faked first item in the
		 * loop. */
		MinPartition<State> *causalPart = partition;
		newPart = firstNewPart - 1;
		while ( newPart < numParts ) {
			State *state = causalPart->list.head;
			while ( state != 0 ) {
				FsmInIterator<State, Transition> inIt( state );
				for ( ; !inIt.atEnd(); inIt++ ) {
					MinPartition<State> *fromPart = 
							inIt.trans->fromState->alg.partition;
					if ( ! fromPart->active ) {
						fromPart->active = true;
						partList.detach( fromPart );
						splittable.append( fromPart );
					}
				}
				state = state->next;
			}

			newPart += 1;
			causalPart = &parts[newPart];
		}
	}
	return numParts;
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MinimizePartition2()
{
	/* Nothing to do if there are no states. */
	if (stateList.listLength == 0)
		return;

	/* 
	 * First thing is to partition the states by final state status and
	 * transition functions. This gives us an initial partitioning to work
	 * with.
	 */

	/* Fill up an array of pointers to the states for easy sorting. */
	int s, numStates = stateList.listLength;
	State** statePtrs = new State*[numStates];
	State *state = stateList.head;
	for ( s = 0; s < numStates; s++ ) {
		statePtrs[s] = state;
		state = state->next;
	}
		
	/* Sort the states using the array of states. */
	MergeSort< State*, InitPartitionCompare<State, Transition> >::sort( 
			statePtrs, numStates );

	/* An array of lists of states is used to partition the states. */
	MinPartition<State> *parts = new MinPartition<State>[numStates];

	/* Assign the states into partitions. */
	int destPart = 0;
	for ( s = 0; s < numStates; s++ ) {
		/* If this state differs from the last then move to the next partition. */
		if ( s > 0 && InitPartitionCompare<State, Transition>::Compare( 
				statePtrs[s-1], statePtrs[s] ) < 0 )
		{
			/* Move to the next partition. */
			destPart += 1;
		}

		/* Put the state into its partition. */
		statePtrs[s]->alg.partition = &parts[destPart];
		parts[destPart].list.append( statePtrs[s] );
	}

	/* We just moved all the states from the main list into partitions without
	 * taking them off the main list. So clean up the main list now. */
	stateList.abandon();

	/* Split partitions. */
	int numParts = SplitCandidates( statePtrs, parts, destPart+1 );

	/* Fuse states in the same partition. The states will end up back on the
	 * main list. */
	FusePartitions( parts, numParts );

	/* Cleanup. */
	delete[] statePtrs;
	delete[] parts;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		InitialMarkRound( MarkIndex<State> &markIndex )
{
	State *p = stateList.head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = stateList.head;
		while ( q != p ) {
			/* If the states differ on final state status, out transitions or
			 * any transition data then they should be separated on the initial
			 * round. */
			if ( InitPartitionCompare<State, Transition>::Compare( p, q ) != 0 )
				markIndex.markPair(p->num, q->num);

			q = q->next;
		}
		p = p->next;
	}
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		MarkRound( MarkIndex<State> &markIndex )
{
	bool pairWasMarked = false;
	State *p = stateList.head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = stateList.head;
		while ( q != p ) {
			/* Should we mark the pair? */
			if ( !markIndex.isPairMarked( p->num, q->num ) ) {
				if ( MarkCompare<State, Transition>::ShouldMark( markIndex, p, q ) ) {
					markIndex.markPair(p->num, q->num);
					pairWasMarked = true;
				}
			}
			q = q->next;
		}
		p = p->next;
	}

	return pairWasMarked;
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MinimizeStable()
{
	/* Set the state numbers. */
	SetStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex<State> markIndex(stateList.listLength);

	/* Mark pairs where final stateness, out trans, or trans data differ. */
	InitialMarkRound( markIndex );

	/* While the last round of marking succeeded in marking a state
	 * continue to do another round. */
	int modified = MarkRound( markIndex );
	while (modified)
		modified = MarkRound( markIndex );

	/* Merge pairs that are unmarked. */
	FuseUnmarkedPairs( markIndex );
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		MinimizeRound()
{
	/* Nothing to do if there are no states. */
	if (stateList.listLength == 0)
		return false;

	/* Fill up an array of pointers to the states. */
	State **statePtrs = new State*[stateList.listLength];
	State *state = stateList.head;
	State **dst = statePtrs;
	while ( state != 0 ) {
		*dst = state;
		dst += 1;
		state = state->next;
	}

	bool modified = false;

	/* Sort The list. */
	MergeSort< State*, ApproxCompare<State, Transition> >::sort( 
			statePtrs, stateList.listLength );

	/* Walk the list looking for duplicates next to each other, 
	 * merge in any duplicates. */
	State **pLast = statePtrs;
	State **pState = statePtrs + 1;
	for ( int i = 1; i < stateList.listLength; i++, pState++ ) {
		if ( ApproxCompare<State, Transition>::Compare( *pLast, *pState ) == 0 ) {
			/* Last and pState are the same, so fuse together. Move forward
			 * with pState but not with pLast. If any more are identical, we
			 * must */
			FuseEquivStates( *pLast, *pState );
			modified = true;
		}
		else {
			/* Last and this are different, do not set to merge them. Move
			 * pLast to the current (it may be way behind from merging many
			 * states) and pState forward one to consider the next pair. */
			pLast = pState;
		}
	}
	delete[] statePtrs;
	return modified;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MinimizeApproximate()
{
	/* While the last minimization round succeeded in compacting states,
	 * continue to try to compact states. */
	while ( true ) {
		bool modified = MinimizeRound();
		if ( ! modified )
			break;
	}
}


/**
 * Remove states that have no path to them from the start state. Recursively
 * traverses the graph marking states that have paths into them. Then removes
 * all states that did not get marked.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		RemoveUnreachableStates()
{
	State *state, *next;

	/* Mark all the states that can be reached
	 * thought the existing transition set. */
	MarkReachableFromHere(startState);

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = stateList.head;
	while (state) {
		next = state->next;

		if (state->isMarked)
			state->isMarked = false;
		else
			delete DetachState(state);
		

		state = next;
	}
}

/**
 * Remove states that that do not lead to a final states. Works recursivly traversing
 * the graph in reverse (starting from all final states) and marking seen states. Then
 * removes states that did not get marked.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		RemoveDeadEndStates()
{
	State *state, *next;

	/* Start State gets honorary marking. We don't want it to accidentially
	 * go away. */
	startState->isMarked = true;

	/* Mark all states that have paths to the final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ )
		MarkReachableFromHereReverse( *st );

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = stateList.head;
	while (state) {
		next = state->next;

		if (state->isMarked)
			state->isMarked = false;
		else
			delete DetachState(state);
		
		state = next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		StripNonFinalStates()
{
	State *state = stateList.head;
	while ( state != NULL ) {
		if ( ! state->isFinState ) {
			state->outTransFuncTable.empty();
			state->isOutPriorSet = false;
			state->outPriority = 0;
		}
		state = state->next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		VerifyOutFuncs()
{
	State *state = stateList.head;
	while ( state != NULL ) {
		if ( ! state->isFinState ) {
			assert( state->outTransFuncTable.tableLength == 0 );
			assert( !state->isOutPriorSet );
			assert( state->outPriority == 0 );
		}
		state = state->next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FuseEquivStates(State *dest, State *src)
{
	/* Cur is a duplicate. We can merge it with trail. */
	InTransMove( dest, src );

	if ( src == startState )
		startState = dest;

	/* Call user routine. */
	dest->FuseState( src );

	delete DetachState( src );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FuseUnmarkedPairs( MarkIndex<State> &markIndex )
{
	State *p = stateList.head, *nextP, *q;

	/* Definition: The primary state of an equivalence class is the first state
	 * encounterd that belongs to the equivalence class. All equivalence
	 * classes have primary state including equivalence classes with one state
	 * in it. */

	/* For each unmarked pair merge p into q and delete p. q is always the
	 * primary state of it's equivalence class. We wouldn't have landed on it
	 * here if it were not, because it would have been deleted.
	 *
	 * Proof that q is the primaray state of it's equivalence class: Assume q
	 * is not the primary state of it's equivalence class, then it would be
	 * merged into some state that came before it and thus p would be
	 * equivalent to that state. But q is the first state that p is equivalent
	 * to so we have a contradiction. */

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		nextP = p->next;

		q = stateList.head;
		while ( q != p ) {
			/* If one of p or q is a final state then mark. */
			if ( ! markIndex.isPairMarked(p->num, q->num) ) {
				FuseEquivStates( q, p );
				break;
			}
			q = q->next;
		}
		p = nextP;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FusePartitions( MinPartition<State> *parts, int numParts )
{
	/* For each partition, fuse state 2, 3, ... into state 1. */
	for ( int p = 0; p < numParts; p++ ) {
		/* Assume that there will always be at least one state. */
		State *first = parts[p].list.head, *toFuse = first->next;

		/* Put the first state back onto the main state list. Don't bother
		 * removing it from the partition list first. */
		stateList.append( first );

		/* Fuse the rest of the state into the first. */
		while ( toFuse != 0 ) {
			State *next = toFuse->next;

			/* Cur is a duplicate. We can merge it with trail. */
			InTransMove( first, toFuse );

			if ( toFuse == startState )
				startState = first;

			/* Call user routine. */
			first->FuseState( toFuse );

			/* Put the state back onto the main list and detach the state from
			 * the graph. The state needs to be on the main list for the detach
			 * to work.  Don't bother removing the state from the partition
			 * list first. */
			stateList.append( toFuse );
			delete DetachState( toFuse );

			toFuse = next;
		}

		/* We transfered the states from the partition list into the main list without
		 * removing the states from the partition list first. Clean it up. */
		parts[p].list.abandon();
	}
}

#endif /* _RLFSM_FSMGRAPH_CPP */

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "tabcodegen.h"

using std::endl;

/* Pass init data to base class. */
TabCodeGen::TabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
:
	FsmCodeGen(fsmName, machine, parseData, out)
{
}

void TabCodeGen::stateOutFunc(FsmMachState *state)
{
	/* If there are any out funcs, emit them. Function indicies are indexes
	 * into transFuncIndex and should be dereferenced to get the index
	 * into the array of all transitions. */
	if ( state->outFuncs == FUNC_NO_FUNC )
		out << "0";
	else {
		/* There are out funcs. Write out the pointer into the array
		 * of funcs and the number of funcs. */
		out << "f+" << machine->transFuncIndex[state->outFuncs];
	}
}

void TabCodeGen::transFunc(FsmMachTrans *trans)
{
	/* If there are any out funcs, emit them. Function indicies are indexes
	 * into transFuncIndex and should be dereferenced to get the index
	 * into the array of all transitions. */
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else {
		out << "f+" << machine->transFuncIndex[trans->funcs];
	}
}

std::ostream &TabCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	StringListEl *flel = parseData->funcList.head;
	for ( int fnum = 0; flel != NULL; fnum++, flel = flel->next ) {
		out << "\tcase " << fnum << ": {";
		out << flel->data;
		out << "break;}" << endl;
	}
	return out;
}

std::ostream &TabCodeGen::STATES()
{
	int curIndex = 0;
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Make a flat fsm state from the state. Do not allocate the indicies. */
		FsmMachFlatState flatState;
		machine->makeFlatState( flatState, *state, false );
		
		/* Emit, low and high index. */
		out << "\t{ " << flatState.lowIndex << ", ";
		out << flatState.highIndex << ", ";

		/* If there are any indicies, emit the pointer to where they
		 * will start for this state. */
		if ( flatState.numIndex > 0 )
			out << "i+" << curIndex << ", ";
		else
			out << "0, ";

		/* Emit the default index. If there is no default index, then this will
		 * be 0, pointing to the err transition. */
		out << flatState.dflIndex << ", ";

		/* Out functions for the state. */
		stateOutFunc( state );

		out << ", " << state->isFinState << " }";
		if ( i < machine->numStates-1 )
			out << ",\n";

		curIndex += flatState.numIndex;
	}
	return out;
}

std::ostream &TabCodeGen::INDICIES()
{
	out << '\t';
	int totalTrans = 0;
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Make a flat fsm state from the state. Allocate the indicies. */
		FsmMachFlatState flatState;
		machine->makeFlatState( flatState, *state, true );

		/* Walk the indicies, writing them out. */
		int *ind = flatState.transIndex;
		for ( int j = 0; j < flatState.numIndex; j++, ind++) {
			out << *ind;
			if ( *ind > 256 )
				out << " ";


			/* If we are not in the last index, then write out a comma and possibly
			 * a line break. */
			if ( i < machine->numStates-1 || j < flatState.numIndex-1 ) {
				out << ", ";

				/* Put in a line break every 8 */
				if ( totalTrans % 8 == 7 )
					out << "\n\t";
			} 

			/* update the number of trans output. */
			totalTrans += 1;
		}
	}
	return out;
}

std::ostream &TabCodeGen::INDEX_TYPE()
{
	if ( machine->numTrans <= 256 )
		out << "unsigned char";
	else if ( machine->numTrans <= 256*256 )
		out << "unsigned short";
	else 
		out << "unsigned int";
	return out;
}


std::ostream &TabCodeGen::TRANSITIONS()
{
	out << '\t';
	FsmMachTrans *trans = machine->allTrans;
	for ( int i = 0; i < machine->numTrans; i++, trans++ ) {
		if ( trans->toState == STATE_ERR_STATE )
			out << "{0, ";
		else
			out << "{s+" << trans->toState << ", ";

		/* Write the function for the state. Close transition. */
		transFunc( trans );
		out << "}";

		/* If not on the last transition, output a command 
		 * and possibly a line break. */
		if ( i < machine->numTrans-1 ) {
			out << ", ";

			/* Put in a break every 4, but only if not the last. */
			if ( i % 4 == 3 )
				out << "\n\t";
		}
	}
	return out;
}

/* Pass init data to base. */
CTabCodeGen::CTabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
:
	TabCodeGen(fsmName, machine, parseData, out)
{
}


/* Generate the header portion. */
void CTabCodeGen::writeOutHeader()
{
	out << 
		"/* Forward dec state for the transition structure. */\n"
		"struct "; FSM_NAME() << "StateStruct;\n"
		"\n"
		"/* A single transition. */\n"
		"struct "; FSM_NAME() << "TransStruct\n"
		"{\n"
		"	struct "; FSM_NAME() << "StateStruct *toState;\n"
		"	int *funcs;\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "TransStruct "; FSM_NAME() << "Trans;\n"
		"\n"
		"/* A single state. */\n"
		"struct "; FSM_NAME() << "StateStruct\n"
		"{\n"
		"	int lowIndex;\n"
		"	int highIndex;\n"
		"	void *transIndex;\n"
		"	unsigned int dflIndex;\n"
		"	int *outFuncs;\n"
		"	int isFinState;\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "StateStruct "; FSM_NAME() << "State;\n"
		"\n"
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	"; FSM_NAME() << "State *curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n";
}

void CTabCodeGen::writeOutCode()
{
	/* State machine data. */
	out << 
		"#define f "; FSM_NAME() << "_f\n"
		"#define s "; FSM_NAME() << "_s\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	if ( anyIndicies() ) {
		out << 
			"/* The array of indicies into the transition array. */\n"
			"static ";
			INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
			INDICIES() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* The aray of states. */\n"
		"static "; FSM_NAME() << "State "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of transitions. */\n"
		"static "; FSM_NAME() << "Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS() << "\n"
		"};\n"
		"/* The start state. */\n"
		"static "; FSM_NAME() << "State *"; FSM_NAME()
				<< "_startState = s+"; START_STATE_OFFSET() << ";\n"
		"\n"
		"#undef f\n"
		"#undef s\n"
		"#undef i\n"
		"#undef t\n"
		"\n";

	/* State machine function execution. */
	out <<
 		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"inline static void "; FSM_NAME() << "ExecFuncs( "; FSM_NAME() 
				<< " *fsm, int *funcs, char *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() << "\n"
		"		}\n"
		"	}\n"
		"}\n"
		"\n";

	/* Init and accept routines. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen )\n"
		"{\n"
		"	char *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	"; FSM_NAME() << "State *cs = fsm->curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int c = (unsigned char) *p;\n"
		"		"; FSM_NAME() << "Trans *trans;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n"
		"		/* If the character is within the index bounds then get the\n"
		"		 * transition for it. If it is out of the transition bounds\n"
		"		 * we will use the default transition. */\n"
		"		if ( cs->lowIndex <= c && c < cs->highIndex ) {\n"
		"			/* Use the index to look into the transition array. */\n"
		"			trans = "; FSM_NAME() << "_t + \n"
		"				(("; INDEX_TYPE() << "*)cs->transIndex)[c - cs->lowIndex];\n"
		"		}\n"
		"		else {\n"
		"			/* Use the default index as the char is out of range. */\n"
		"			trans = "; FSM_NAME() << "_t + cs->dflIndex;\n"
		"		}\n"
		"\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( trans->funcs != 0 )\n"
		"			"; FSM_NAME() << "ExecFuncs( fsm, trans->funcs, p );\n"
		"\n"
		"		/* Move to the new state. */\n"
		"		cs = trans->toState;\n"
		"	}\n"
		"finished:\n"
		"	fsm->curState = cs;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	"; FSM_NAME() << "State *cs = fsm->curState;\n"
		"	if ( cs != 0 && cs->isFinState ) {\n"
		"		/* If finishing in a final state then execute the\n"
		"		 * out functions for it. (if any). */\n"
		"		if ( cs->outFuncs != 0 )\n"
		"			"; FSM_NAME() << "ExecFuncs( fsm, cs->outFuncs, 0 );\n"
		"		fsm->accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		fsm->curState = 0;\n"
		"	}\n"
		"}\n";
}

/* Init base class. */
CCTabCodeGen::CCTabCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out ) :
		TabCodeGen(fsmName, machine, parseData, out)
{
}

void CCTabCodeGen::writeOutHeader()
{
	out <<
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Forward dec state for the transition structure. */\n"
		"	struct State;\n"
		"\n"
		"	/* A single transition. */\n"
		"	struct Trans\n"
		"	{\n"
		"		State *toState;\n"
		"		int *funcs;\n"
		"	};\n"
		"\n"
		"	/* A single state. */\n"
		"	struct State\n"
		"	{\n"
		"		int lowIndex;\n"
		"		int highIndex;\n"
		"		void *transIndex;\n"
		"		unsigned int dflIndex;\n"
		"		int *outFuncs;\n"
		"		int isFinState;\n"
		"	};\n"
		"\n"
		"	/* Constructor. */\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( char *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	State *curState;\n"
		"	int accept;\n"
		"\n"
		"	inline void ExecFuncs( int *funcs, char *p );\n"
		"\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n";
}

void CCTabCodeGen::writeOutCode()
{
	/* State machine data. */
	out << 
		"#define f "; FSM_NAME() << "_f\n"
		"#define s "; FSM_NAME() << "_s\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	if ( anyIndicies() ) {
		out << 
			"/* The array of indicies into the transition array. */\n"
			"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
			INDICIES() << "\n"
			"};\n"
			"\n";
	}

	out <<
		"/* The aray of states. */\n"
		"static "; FSM_NAME() << "::State "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "::Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS() << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static "; FSM_NAME() << "::State *"; FSM_NAME() << 
				"_startState = s+"; START_STATE_OFFSET() << ";\n"
		"\n"
		"#undef f\n"
		"#undef s\n"
		"#undef i\n"
		"#undef t\n\n";

	/* Function execution. */
	out <<
		"/* Execute functions pointed to by funcs until the null function is found. */\n"
		"inline void "; FSM_NAME() << "::ExecFuncs( int *funcs, char *p )\n"
		"{\n"
		"	int len = *funcs++;\n"
		"	while ( len-- > 0 ) {\n"
		"		switch ( *funcs++ ) {\n";
		FUNC_SWITCH() << "\n"
		"		}\n"
		"	}\n"
		"}\n"
		"\n\n";

	/* Constructor. */
	out << 
		"/* Make sure the machine is initted. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "()\n"
		"{\n"
		"	Init();\n"
		"}\n\n";

	/* Init and accept. */
	out <<
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = "; FSM_NAME() << "_startState;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"/* Did the fsm accept? */ \n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n\n";

	/* Execution. */
	out <<
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( char *data, int dlen )\n"
		"{\n"
		"	char *p = data;\n"
		"	int len = dlen;\n"
		"\n"
		"	State *cs = curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		int c = (unsigned char)*p;\n"
		"		Trans *trans;\n"
		"\n"
		"		if ( cs == 0 )\n"
		"			goto finished;\n"
		"\n"
		"		/* If the character is within the index bounds then get the\n"
		"		 * transition for it. If it is out of the transition bounds\n"
		"		 * we will use the default transition. */\n"
		"		if ( cs->lowIndex <= c && c < cs->highIndex ) {\n"
		"			/* Use the index to look into the transition array. */\n"
		"			trans = "; FSM_NAME() << "_t + \n"
		"				(("; INDEX_TYPE() << "*)cs->transIndex)[c - cs->lowIndex];\n"
		"		}\n"
		"		else {\n"
		"			/* Use the default index as the char is out of range. */\n"
		"			trans = "; FSM_NAME() << "_t + cs->dflIndex;\n"
		"		}\n"
		"\n"
		"		/* If there are functions for this transition then execute them. */\n"
		"		if ( trans->funcs != 0 )\n"
		"			ExecFuncs( trans->funcs, p );\n"
		"\n"
		"		/* Move to the new state. */\n"
		"		cs = trans->toState;\n"
		"	}\n"
		"finished:\n"
		"	curState = cs;\n"
		"}\n\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	State *cs = curState;\n"
		"	if ( cs != 0 && cs->isFinState ) {\n"
		"		/* If finishing in a final state then execute the\n"
		"		 * out functions for it. (if any). */\n"
		"		if ( cs->outFuncs != 0 )\n"
		"			ExecFuncs( cs->outFuncs, 0 );\n"
		"		accept = 1;\n"
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		curState = 0;\n"
		"	}\n"
		"}\n\n";
}

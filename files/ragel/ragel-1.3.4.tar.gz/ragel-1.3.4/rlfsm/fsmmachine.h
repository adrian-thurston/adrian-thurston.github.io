/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMMACH_H
#define _RLFSM_FSMMACH_H

#include <assert.h>
#include "vector.h"
#include "compare.h"
#include "bstmap.h"

#define TRANS_ERR_TRANS   0
#define STATE_ERR_STATE   0
#define FUNC_NO_FUNC     -1

struct FsmMachState;

/* Machine Transition. */
struct FsmMachTrans
{
	/* State the transition goes to. */
	int toState;

	/* Functions on this transition. */
	int funcs;
};

/* Compare for machine transitions. */
struct FsmMachTransCompare
{
	static int compare(const FsmMachTrans &t1,
			const FsmMachTrans &t2);
};

/* Machine State. */
struct FsmMachState
{
	~FsmMachState();

	/* Indicies into the transitions for this state. */
	int *transIndKey;
	int *transIndPtr;
	int numIndex;

	/* Indicies into the ranges for this state. */
	int *rangeIndKey;
	int *rangeIndPtr;
	int numRange;

	/* Default index if a key is not in transIndex. */
	int dflIndex;

	/* Out functions for this state. */
	int outFuncs;

	/* Is the state final. */
	bool isFinState;
};

/* A machine state for flat index arrays. */
struct FsmMachFlatState
{
	~FsmMachFlatState();

	/* Indexs into the transitions for this state. */
	int *transIndex;
	int numIndex;

	/* Bounds of the indicies. */
	int lowIndex;
	int highIndex;

	/* The default index to use if out of the lowIndex, highIndex. */
	int dflIndex;
};

/* Machine state for switches. */
struct FsmMachSwitchState
{
	/* Map transition indicies to a vector of chars that go 
	 * on that trans. */
	BstMap< int, Vector<int>, CmpOrd<int> > funcMap;

	/* The default index to use if out of the lowIndex, highIndex. */
	int dflIndex;
};

/* A fsm machine class. */
class FsmMachine
{
public:
	FsmMachine();
	~FsmMachine();

	/* Start state. */
	int startState;

	/* Array of all states. */
	FsmMachState *allStates;
	int numStates;

	/* Array of all transitions. */
	FsmMachTrans *allTrans;
	int numTrans;

	/* Array of all transition functions. */
	int *allTransFuncs;
	int numTransFuncs;

	/* Indicies and lengths into the transitions 
	 * funcs giving groups of funcs to execute. */
	int *transFuncIndex;
	int numTransFuncIndex;

	/* Count the number of indicies across the whole machine. */
	int numIndicies();

	/* Make an fsm state where the transition indicies are one flat
	 * array. */
	void makeFlatState( FsmMachFlatState &dest, const FsmMachState &src, 
			bool allocIndicies );

	/* Make an fsm state that is designed for a switch statement. Characters that
	 * use the same transition are chunked together. */
	void makeSwitchState( FsmMachSwitchState &dest, const FsmMachState &src );
};


#endif /* _RLFSM_FSMMACH_H */

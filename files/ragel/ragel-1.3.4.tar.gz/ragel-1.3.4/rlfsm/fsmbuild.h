/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMBUILD_H
#define _RLFSM_FSMBUILD_H

#include "fsmap.h"
#include "fsmmachine.h"

/* Compare for finding the set of unique transitions. Compares destination
 * state and transition function. Ignores priority. */
struct TransSetCompare
{
	typedef SBstMapEl< int, int > TransFuncEl;
	typedef SBstMap< int, int, CmpOrd<int> > TransFuncTable;
	typedef CmpSTable< TransFuncEl, TransFuncElCmp > TransFuncTableCompare;

	static inline int compare( TransAp *trans1, TransAp *trans2 )
	{
		/* Both of the transition pointers are set. Test target state,
		 * priority and funcs. */
		if ( trans1->toState < trans2->toState )
			return -1;
		else if ( trans1->toState > trans2->toState )
			return 1;
		else {
			int cmpResult = TransFuncTableCompare::
					compare(trans1->transFuncTable, trans2->transFuncTable);
			if ( cmpResult != 0 )
				return cmpResult;
		}
		return 0;
	}
};

/* Contains the data necessary for making the fsm machine. */
class FsmBuild
{
public:
	/* Construct the fsm builder. */
	FsmBuild( FsmAp &graph, FsmMachine &machine );	

	/* Build a runnable, compressed machine from this graph. */
	void build( );

private:
	/* Types that the builder operates on. */
	typedef FsmTransList<TransAp> TransListType;
	typedef BstMapEl< int, TransAp* > TransEl;
	typedef SBstMap< int, int, CmpOrd<int> > TransFuncTable;

	/* Set of unique transition functions. */
	typedef AvlMapNode<TransFuncTable, int> TransFuncSetEl;
	typedef AvlMap<TransFuncTable, int, 
			TransAp::TransFuncTableCompare> TransFuncSet;

	/* Set of unique transitions. */
	typedef AvlMapNode<TransAp*, int> TransSetEl;
	typedef AvlMap<TransAp*, int, TransSetCompare> TransSet;

	/* The graph is the source, the machine is the destination. */
	FsmAp &graph;
	FsmMachine &machine;

	int curFuncOffset;
	int curTransOffset;
	int numFuncs;

	/* For the reduction of transitions. */
	TransFuncSet transFuncSet;
	TransSet transSet;

	/* Make the states for a new machine. */
	void initMachineStates( );

	/* Make a machine transition from a graph transition. */
	int makeMachineTrans( TransAp *trans );

	/* Make a machine state from a graph state. */
	void buildMachineState( FsmMachState *machState, StateAp *state );

	/* Expand the ranges into the indicies. */
	void moveRangesIntoIndicies( FsmMachState *machState );

	void makeIndiciesFromRange( FsmMachState *machState );

	/* Add functions from a func table to the func map and return the index
	 * of the functions. If the func table is empty, the index will be -1. */
	int addFuncsToMap( TransFuncTable &funcTable );

	void reduceFunctions();
	void reduceFuncTable( TransFuncTable &funcTable );

	void reduceTransitions();
	void emptyReduced();
	void buildFunctionList();
	void buildTransitionArray();
};


#endif /* _RLFSM_FSMBUILD_H */

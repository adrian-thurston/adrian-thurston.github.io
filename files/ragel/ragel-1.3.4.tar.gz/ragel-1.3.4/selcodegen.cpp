/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "rl.h"
#include "selcodegen.h"
#include "bstmap.h"

using std::endl;


/* Init base data. */
SelCodeGen::SelCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out )
: 
	FsmCodeGen(fsmName, machine, parseData, out )
{
}

void SelCodeGen::emitTransistion( int curState, FsmMachTrans *trans )
{
	if ( trans->toState == STATE_ERR_STATE )
		out << "cs = -1; ";
	else
		out << "cs = " << trans->toState << "; ";

	if ( trans->funcs != FUNC_NO_FUNC ) {
		int *funcs = machine->allTransFuncs + 
				machine->transFuncIndex[trans->funcs];

		/* The first number is the length. */
		int flen = *funcs++;
		while ( flen-- > 0 ) {
			out << "{" << getCodeBuiltin( *funcs ) << "}";
			funcs += 1;
		}
	}
	out << "break;";
}

std::ostream &SelCodeGen::STATE_SWITCH()
{
	out << "\t\tswitch( cs ) {" << endl;
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the state. */
		FsmMachState *state = machine->allStates+st;

		/* Make the switch oriented state. */
		FsmMachSwitchState swState;
		machine->makeSwitchState( swState, *state );

		out << "\t\tcase " << st << ": {\n";
		out << "\t\t\tswitch ( c ) {\n\t\t\t";
		for ( int j = 0; j < swState.funcMap.length; j++ ) {
			/* Write out all the characters that follow the trans. */
			Vector<int> &charVec = swState.funcMap[j].value;
			for ( int k = 0; k < charVec.length; k++ ) {
				out << "case " << charVec.data[k] << ": ";
				if ( k % 4 == 3 )
					out << "\n\t\t\t";
			}
			/* Get the transition to go to and write it. */
			FsmMachTrans *trans = machine->allTrans + 
					swState.funcMap.data[j].key;
			emitTransistion( st, trans );
			out << "\n\t\t\t";
		}

		/* Get the default index and emit it. Default will always be used. */
		FsmMachTrans *trans = machine->allTrans + swState.dflIndex;
		out << "default: ";
		emitTransistion( st, trans );
		/* Close off the transition switch. */
		out << "\n\t\t\t}\n";

		/* Close off the state */
		out << "\t\t\tbreak;\n";
		out << "\t\t}\n";
	}
	out << "\t\t}" << endl;
	return out;
}

std::ostream &SelCodeGen::FINISH_SWITCH()
{
	out << "\tswitch( cs ) {" << endl;
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		out << "\t\tcase " << st << ": ";
		if ( state->isFinState )
			out << "accept = 1; ";

		/* If there are out functions, write them. */
		if ( state->outFuncs != FUNC_NO_FUNC ) {
			int *funcs = machine->allTransFuncs + 
					machine->transFuncIndex[state->outFuncs];

			/* The first number is the length. */
			int flen = *funcs++;
			while ( flen-- > 0 ) {
				out << "{" << getCodeBuiltin( *funcs ) << "}";
				funcs += 1;
			}
		}
		out << "break;" << endl;
	}
	out << "}" << endl;
	return out;
}

/* Init base data. */
CSelCodeGen::CSelCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out ) : 
	SelCodeGen(fsmName, machine, parseData, out)
{
}

void CSelCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CSelCodeGen::writeOutCode()
{
	out <<
		"\n"
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, char *data, int dlen )\n"
		"{\n"
		"	char *p = data;\n"
		"	int len = dlen;\n"
		"	int cs = fsm->curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		unsigned char c = (unsigned char)*p;\n";
		STATE_SWITCH() << "\n"
		"	}\n"
		"	fsm->curState = cs;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int cs = fsm->curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	fsm->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n";
}

/* Init base data. */
CCSelCodeGen::CCSelCodeGen( char *fsmName, FsmMachine *machine, 
		ParseData *parseData, ostream &out ) : 
	SelCodeGen(fsmName, machine, parseData, out)
{
}

void CCSelCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( char *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n"
		"	"; STRUCT_DATA() << "\n"
		"\n"
		"	/* The start state. */\n"
		"	static int startState;\n"
		"};\n";
}

void CCSelCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Make sure the machine is initted. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	curState = startState;\n"
		"	accept = 0;\n"
		"	"; INIT_CODE() << "\n"
		"}\n"
		"\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( char *data, int dlen )\n"
		"{\n"
		"	char *p = data;\n"
		"	int len = dlen;\n"
		"	int cs = curState;\n"
		"	for ( ; len > 0; p++, len-- ) {\n"
		"		unsigned char c = (unsigned char)*p;\n";
		STATE_SWITCH() << "\n"
		"	}\n"
		"	curState = cs;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int cs = curState;\n"
		"	int accept = 0;\n";
		FINISH_SWITCH() << "\n"
		"	this->accept = accept;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n";
}

/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  Aapl is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 *  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 *  more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Aapl; if not, write to the Free Software Foundation, Inc., 59
 *  Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _RLFSM_FSMGRAPH_CPP
#define _RLFSM_FSMGRAPH_CPP

#include <assert.h>

#include "fsmgraph.h"
#include "mergesort.h"

/* Other graph code files. */
#include "fsmstate.cpp"
#include "fsmbase.cpp"
#include "fsmattach.cpp"
#include "fsmmin.cpp"

/* Make a new state. The new state will be put on the graph's
 * list of state. The new state can be created final or non final. */
template < class State, class Transition, class Key, class KeyOps >
		State *FsmGraph<State, Transition, Key, KeyOps>::
		newState()
{
	/* Make the new state to return. */
	State *state = new State();

	if ( misfitAccounting ) {
		/* Create the new state on the misfit list. All states are created
		 * with no foreign in transitions. */
		misfitList.append( state );
	}
	else {
		/* Create the new state. */
		stateList.append( state );
	}

	/* Return the new state. */
	return state;
}

/**
 * \brief Construct an FSM that is the concatenation of an array of
 * characters.
 *
 * A new machine will be made that has len+1 states with one transition
 * between each state for each integer in str. IsSigned determines if the
 * integers are to be considered as signed or unsigned ints.
 *
 * \returns The new FSM.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		concatFsm( const Key *str, int len )
{
	/* Make the first state and set it as the start state. */
	State *last = newState();
	setEntry( 0, last );

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *ns = newState();
		attachNewTrans( last, ns, KeyTypeSingle, str[i], Key() );
		last = ns;
	}

	/* Make the last state the final state. */
	setFinState( last );
}

/**
 * \brief Construct a machine that matches one character.
 *
 * A new machine will be made that has two states with a single transition
 * between the states. IsSigned determines if the integers are to be
 * considered as signed or unsigned ints.
 *
 * \returns The new FSM.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		concatFsm( const Key &chr )
{
	/* Two states first start, second final. */
	State *start = newState();
	setEntry( 0, start );

	State *end = newState();
	setFinState( end );

	/* Attach on the character. */
	attachNewTrans( start, end, KeyTypeSingle, chr, Key() );
}

/**
 * \brief Construct a machine that matches any character in set.
 *
 * A new machine will be made that has two states and len transitions between
 * the them. If set contains any duplicate values then undefined behaviour
 * results. IsSigned determines if the intergers are to be considered as
 * signed or unsigned ints.
 *
 * \returns The new FSM.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		orFsm( const Key *set, int len )
{
	/* Two states first start, second final. */
	State *start = newState();
	setEntry( 0, start );

	State *end = newState();
	setFinState( end );

	/* Attach on all the integers in the given string of ints. */
	for ( int i = 0; i < len; i++ )
		attachNewTrans( start, end, KeyTypeSingle, set[i], Key() );
}

/**
 * \brief Construct a machine that matches the empty word.
 *
 * A new machine will be made with only one state. The new state will be both
 * a start and final state. IsSigned determines if the machine has a signed or
 * unsigned alphabet. Fsm operations must be done on machines with the same
 * alphabet signedness.
 *
 * \returns The new FSM.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		nullFsm( )
{
	/* Give it one state with no transitions making it
	 * the start state and final state. */
	State *startState = newState();
	setEntry( 0, startState );
	setFinState( startState );
}

/**
 * \brief Construct a machine that matches any character.
 *
 * A new machine will be made with two states and a default transition between
 * them. IsSigned determines if the machine has a signed or unsigned alphabet.
 * Fsm operations must be done on machines with the same alphabet signedness.
 *
 * \returns The new FSM.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		dotFsm( )
{
	/* Two states first start, second final. */
	State *start = newState();
	setEntry( 0, start );

	State *end = newState();
	setFinState( end );

	/* Attach on the any char. */
	attachNewTrans( start, end, KeyTypeDefault, Key(), Key() );
}

/**
 * \brief Construct a machine that matches any string of characters.
 *
 * A new machine will be made with a single state that is both start and final
 * and that has default transition back to itself. IsSigned determines if the
 * machine has a signed or unsiged alphabet. Fsm operations must be done on
 * machines with the same signednesss.
 *
 * \returns The new FSM.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		dotStarFsm( )
{
	/* One state which is final and is the start state. */
	State *start = newState();
	setEntry( 0, start );
	setFinState( start );

	/* Attach start to start on default. */
	attachNewTrans( start, start, KeyTypeDefault, Key(), Key() );
}

/**
 * \brief Construct a machine that matches a range of characters.
 *
 * A new machine will be made with two states and a range transition between
 * them. The range will match any characters from low to high inclusive. Low
 * should be less than or equal to high otherwise undefined behaviour results.
 * IsSigned determines if the integers are to be considered as signed or
 * unsigned ints.
 *
 * \returns The new FSM.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		rangeFsm( const Key &low, const Key &high )
{
	/* Two states first start, second final. */
	State *start = newState();
	setEntry( 0, start );

	State *end = newState();
	setFinState( end );

	/* Attach using the range of characters. */
	attachNewTrans( start, end, KeyTypeRange, low, high );
}

/**
 * \brief Kleene star operator.
 *
 * Makes this machine the kleene star of itself. If leavingFsm is true then
 * any transitions made going out of the machine and back into itself will be
 * notified that they are leaving transitions by having the leavingFromState
 * callback invoked.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		starOp( bool leavingFsm )
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of the original start state. */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );

	/* Get a copy of the final state set before creating the new
	 * start state. It may get set final and we don't want the start
	 * state to be included in the final state set. If it is included
	 * in the final state set then all the final states after it get
	 * the transitions of the start state doubled up. That's incorrect.*/
	StateSet finStateSetCopy( finStateSet );

	/* This will be the new start state. It will be set final after the
	 * merging of the final states with the start state is complete. */
	State *newStart = newState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* From here on we need the new start state as start state set. */
	startStateSet.setAs( newStart );

	/* For all the final states, merge with the new start state. */
	State **st = finStateSetCopy.data;
	int nst = finStateSetCopy.length();
	for (int i = 0; i < nst; i++, st++)
		mergeStates( md, *st, startStateSet, leavingFsm );

	/* Now it is safe to merge the start state with itself (provided it
	 * is set final). */
	if ( newStart->stateBits & SB_ISFINAL )
		mergeStates( md, newStart, startStateSet, leavingFsm );

	/* Now ensure the new start state is a final state. */
	setFinState( newStart );

	/* Fill in any states that were newed up as combinations of others. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/**
 * \brief Concatenation operator.
 *
 * Concatenates other to the end of this machine. Other is deleted. If
 * leavingFsm is true then any transitions made leaving this machine and
 * entering into other are notified that they are leaving transitions by
 * having the leavingFromState callback invoked.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		concatOp( FsmGraph *other, bool leavingFsm )
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Build a state set consisting of other's start state. */
	StateSet startStateSet;
	startStateSet.insert( other->findEntry(0) );

	/* Unset other's start state before bringing in the entry points. */
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Bring in other's states into our state lists. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Get a copy of our final state set before we clobber it. We need to
	 * iterate over it while it may change due to the merging process. */
	StateSet finStateSetCopy( finStateSet );

	/* Unset all of our final states and get the final states from other. */
	unsetAllFinStates();
	finStateSet.insert( other->finStateSet );
	
	/* Since other's lists are empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our former final states with the start state of other. */
	State **st = finStateSetCopy.data;
	int nst = finStateSetCopy.length();
	for (int i = 0; i < nst; i++, st++) {
		State *state = *st;

		/* Merge the former final state with other's start state. */
		mergeStates( md, state, startStateSet, leavingFsm );

		/* If the former final state was not reset final then we must clear
		 * the state's out trans data. If it got reset final then it gets to
		 * keep its out trans data. This must be done before fillInStates gets
		 * called to prevent the data from being sourced. */
		if ( ! (state->stateBits & SB_ISFINAL) )
			state->relinquishFinal();
	}

	/* Fill in any new states made from merging. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}


template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		doOr( FsmGraph *other )
{
	/* For the merging process. */
	MergeData md;

	/* Build a state set consisting of both start states */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );
	startStateSet.insert( other->findEntry(0) );

	/* Both of the original start states loose their start state status. */
	unsetEntry( 0 );
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Merge the lists. This will move all the states from other
	 * into this. No states will be deleted. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Move the final set data from other into this. */
	finStateSet.insert(other->finStateSet);
	other->finStateSet.empty();

	/* Since other's list is empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Create a new start state. */
	State *newStart = newState();
	setEntry( 0, newStart );

	/* Merge the start states. */
	mergeStates( md, newStart, startStateSet, false );

	/* Fill in any new states made from merging. */
	fillInStates( md );
}

/**
 * \brief Union operator.
 *
 * Unions other with this machine. Other is deleted.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		unionOp( FsmGraph *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Call Worker routine. */
	doOr( other );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/**
 * \brief Intersection operator.
 *
 * Intersects other with this machine. Other is deleted.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		intersectOp( FsmGraph *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits on this and other to want each other. */
	setFinBits( SB_WANTOTHER1 );
	other->setFinBits( SB_WANTOTHER2 );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetIncompleteFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}

/**
 * \brief Subtraction operator.
 *
 * Set subtracts other machine from this machine. Other is deleted.
 */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		subtractOp( FsmGraph *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits of other to be killers. */
	other->setFinBits( SB_KILLOTHERS );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetIncompleteFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}

template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		epsilonOp( State **fromStates, int nStates, FsmGraph *other )
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting of both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Build a state set consisting just other start state. */
	StateSet startStateSet;
	startStateSet.insert( other->findEntry(0) );

	/* Other looses its start state, which gets glued to the from states. */
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Merge the lists. This will move all the states from other
	 * into this. No states will be deleted. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Move the final set data from other into this. */
	finStateSet.insert( other->finStateSet );
	other->finStateSet.empty();

	/* Since other's list is empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge others start state with each state in the list of from states. */
	for ( int i = 0; i < nStates; i++ )
		mergeStates( md, fromStates[i], startStateSet, false );

	/* Fill in any new states made from merging. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/* Unset any final states that are no longer to be final due to final bits. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		unsetIncompleteFinals()
{
	/* Duplicate the final state set before we begin modifying it. */
	StateSet fin( finStateSet );

	for ( int s = 0; s < fin.length(); s++ ) {
		State *state = fin.data[s];

		if ( state->stateBits & SB_KILLOTHERS ) {
			/* One final state is a killer, don't set final. */
			unsetFinState( state );
		}

		if ( state->stateBits & SB_WANTOTHER && 
				(state->stateBits & SB_WANTOTHER) != SB_WANTOTHER )
		{
			/* One state wants the other but it is not there. */
			unsetFinState( state );
		}

		/* All states should have their killing and wanting state bits
		 * cleared. Non final states should never have had those state bits
		 * set in the first place. */
		state->stateBits &= ~ (SB_WANTOTHER | SB_KILLOTHERS);
	}
}

/* Ensure that the start state is free of entry points (aside from the fact
 * that it is the start state). If the start state has entry points then Make a
 * new start state by merging with the old one. Useful before modifying start
 * transitions. If the existing start state has any entry points other than the
 * start state entry then modifying its transitions changes more than the start
 * transitions. So isolate the start state by separating it out such that it
 * only has start stateness as it's entry point. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		isolateStartState( )
{
	/* For the merging process. */
	MergeData md;

	/* Bail out if the start state is already isolated. */
	if ( isStartStateIsolated() )
		return;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of only the start state. */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );

	/* This will be the new start state. The existing start
	 * state is merged with it. */
	State *newStart = newState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* Stfil and stateDict will be empty because the merging of the old start
	 * state into the new one will not have any conflicting transitions. */
	assert( md.stateDict.treeSize == 0 );
	assert( md.stfillHead == 0 );

	/* The old start state may be unreachable. Remove the misfits and turn off
	 * misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		mergeStates( MergeData &md, State *destState, StateSet &stateSet, 
				bool leavingFsm )
{
	/* If a merge is to make transitions that leave an fsm then the state set
	 * should have only one element in it. This is to protect against writing
	 * and reading of out trans data as determined by the order of state in
	 * state set. */
	assert( ! ( leavingFsm && stateSet.size() > 1 ));

	State **stp = stateSet.data;
	int nst = stateSet.length();
	for ( int i = 0; i < nst; i++, stp++ ) {
		State *src = *stp;

		/* Get the out transitions. */
		outTransCopy( md, destState, src, leavingFsm );

		/* Get its bits and final state status. */
		destState->stateBits |= ( src->stateBits & ~SB_ISFINAL );
		if ( src->stateBits & SB_ISFINAL )
			setFinState( destState );

		/* Call user routine. */
		destState->addInState( src );
	}
}

template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		fillInStates( MergeData &md )
{
	/* Merge any states that are awaiting merging. This will likey cause
	 * other states to be added to the stfil list. */
	State *state = md.stfillHead;
	while ( state != 0 ) {
		mergeStates( md, state, state->stateDictEl->stateSet, false );
		state = state->alg.next;
	}

	/* Delete the state sets of all states that are on the fill list. */
	state = md.stfillHead;
	while ( state != 0 ) {
		/* Delete and reset the state set. */
		delete state->stateDictEl;
		state->stateDictEl = 0;

		/* Next state in the stfill list. */
		state = state->alg.next;
	}

	/* StateDict will still have it's ptrs/size set but all of it's element
	 * will be deleted so we don't need to clean it up. */
}


#endif /* _RLFSM_FSMGRAPH_CPP */

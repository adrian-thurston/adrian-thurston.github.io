/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


#include "ragel.h"
#include "gvdotgen.h"
#include "parsetree.h"
#include "fsmap.h"

using namespace std;

GraphvizDotGen::GraphvizDotGen( char *fsmName, ParseData *parseData, 
		FsmAp *graph, ostream &out )
:
	fsmName(fsmName),
	parseData(parseData),
	graph(graph),
	out(out)
{
}

std::ostream &GraphvizDotGen::KEY( long key )
{
	if ( parseData->isAlphSigned() )
		out << key;
	else
		out << (unsigned long) key;
	return out;
}

/* Write the label for a transition. */
std::ostream &GraphvizDotGen::LABEL( LabelType type, long lowerKey, 
		long upperKey, TransAp::TransFuncTable *funcTable )
{
	out << "\"";

	if ( type == Numbered ) {
		/* Output the key. Possibly a range. */
		KEY( lowerKey );
		if ( upperKey != lowerKey ) {
			out << "..";
			KEY( upperKey );
		}
	}
	else if ( type == Default ) {
		/* This is the default transition. */
		out << "def";
	}

	/* The func. */
	if ( funcTable != 0 && funcTable->length() > 0 ) {
		out << "/";
		TransAp::TransFuncTable::Iter funcIt = funcTable->first();
		for ( ; funcIt.lte(); funcIt++ ) {
			FuncListEl *func = parseData->funcIndex[funcIt->value];
			if ( func->name != 0 )
				out << func->name;
			else
				out << func->loc.line << ":" << func->loc.col;
			if ( !funcIt.last() )
				out << ",";
		}
	}
	out << "\"";
	return out;
}

void GraphvizDotGen::writeDotFile( )
{
	/* Need state numbers. */
	graph->setStateNumbers();

	out << 
		"digraph " << fsmName << " {\n"
		"	rankdir=LR;\n";
	
	/* Define the psuedo start state and out states. Transitions will be done
	 * after the states have been defined as either final or not final. */
	out << "	node [ shape = point ];\n";
	out << "	ENTRY;\n";
	for ( FsmAp::StateSet::Iter pst = graph->finStateSet; pst.lte(); pst++ ) {
		if ( (*pst)->outTransFuncTable.length() > 0 )
			out << "	out_" << (*pst)->alg.stateNum << ";\n";
	}

	/* Attributes common to all nodes, plus double circle for final states. */
	out << "	node [ fixedsize = true, height = 0.65, shape = doublecircle ];\n";

	/* List Final states. */
	for ( FsmAp::StateSet::Iter fin = graph->finStateSet; fin.lte(); fin++ )
		out << "	" << (*fin)->alg.stateNum << ";\n";

	/* List transitions. */
	out << "	node [ shape = circle ];\n";

	/* Walk the states. */
	for ( StateAp *state = graph->stateList.head; state != 0; state = state->next ) {
		FsmUniOutIter<StateAp, TransAp, long, FaKeyOps> outIt( state, graph );
		for ( ; outIt.lte(); outIt++ ) {
			out << "\t" << state->alg.stateNum  << " -> ";
			if ( outIt.trans == 0 )
				out << "ERR";
			else
				out << "" << outIt.trans->toState->alg.stateNum;

			/* Label. */
			out << " [ label = "; 
			LABEL( Numbered, outIt.lowerKey, outIt.upperKey, 
					outIt.trans ? &outIt.trans->transFuncTable : 0 ) << " ];\n";
		}

		/* Default transition? */
		if ( state->outDefault != 0 ) {
			out << "\t" << state->alg.stateNum  << " -> " << 
					state->outDefault->toState->alg.stateNum << 
					" [ label = "; 
			LABEL( Default, 0, 0, state->outDefault ? 
					&state->outDefault->transFuncTable : 0 ) << " ];\n";
		}
	}

	/* Entry into the pseudo start state. */
	out << "	ENTRY -> " << graph->findEntry(0)->alg.stateNum << ";\n";

	/* Exit out to the pseuto final states. */
	for ( FsmAp::StateSet::Iter pst = graph->finStateSet; pst.lte(); pst++ ) {
		if ( (*pst)->outTransFuncTable.length() > 0 ) {
			out << "	" << (*pst)->alg.stateNum << " -> out_" << 
					(*pst)->alg.stateNum << " [ label = "; 
			LABEL( Out, 0, 0, &(*pst)->outTransFuncTable ) << " ];\n";
		}
	}

	out <<
		"}\n";
}

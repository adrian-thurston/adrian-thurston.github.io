/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _IPGCODEGEN_H
#define _IPGCODEGEN_H

#include <iostream>
#include "gotocodegen.h"

/* Forwards. */
struct ParseData;

/*
 * class FGotoCodeGen
 */
class IpGotoCodeGen : public GotoCodeGen
{
public:
	IpGotoCodeGen( char *fsmName, ParseData *parseData, 
			RedFsmAp *redFsm, std::ostream &out );

	std::ostream &EXIT_STATES();
	std::ostream &TRANS_GOTO( RedTransAp *trans, int level );
	std::ostream &FINISH_CASES();
	std::ostream &CURS( bool inFinish );
	std::ostream &TARGS( bool inFinish, int targState );

protected:
	/* Called from GotoCodeGen::STATE_GOTOS just before writing the gotos for
	 * each state. */
	std::ostream &GOTO_HEADER( RedStateAp *state );

	/* Set up labelNeeded flag for each state. */
	void setLabelsNeeded();
};


/*
 * class CIpGotoCodeGen
 */
class CIpGotoCodeGen : public IpGotoCodeGen
{
public:
	CIpGotoCodeGen( char *fsmName, ParseData *parseData, 
			RedFsmAp *redFsm, std::ostream &out );

	std::ostream &GOTO( NameInst *name, bool inFinish );
	std::ostream &CALL( NameInst *name, int targState, bool inFinish );
	std::ostream &RET( bool inFinish );
	std::ostream &CALLE( char *stateExpr, int targState, bool inFinish );
	std::ostream &GOTOE( char *stateExpr, bool inFinish );
	std::ostream &NEXT( NameInst *name, bool inFinish );
	std::ostream &NEXTE( char *stateExpr, bool inFinish );

	virtual void writeOutHeader() { C_HEADER(); }
	virtual void writeOutCode();
};


/*
 * class CCIpGotoCodeGen
 */
class CCIpGotoCodeGen : public IpGotoCodeGen
{
public:
	CCIpGotoCodeGen( char *fsmName, ParseData *parseData, 
			RedFsmAp *redFsm, std::ostream &out );

	std::ostream &GOTO( NameInst *name, bool inFinish );
	std::ostream &CALL( NameInst *name, int targState, bool inFinish );
	std::ostream &RET( bool inFinish );
	std::ostream &CALLE( char *stateExpr, int targState, bool inFinish );
	std::ostream &GOTOE( char *stateExpr, bool inFinish );
	std::ostream &NEXT( NameInst *name, bool inFinish );
	std::ostream &NEXTE( char *stateExpr, bool inFinish );

	virtual void writeOutHeader() { CXX_HEADER(); }
	virtual void writeOutCode();
};

#endif /* _IPGCODEGEN_H */

/*
 *  Copyright 2001-2005 Adrian Thurston <thurston@cs.queensu.ca>
 *            2004 Eric Ocean <eric.ocean@ampede.com>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "ipgotocodegen.h"
#include "redfsm.h"
#include "parsetree.h"
#include "bstmap.h"

std::ostream &IpGotoCodeGen::GOTO( NameInst *name, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	if ( !inFinish )
		out << "{goto st" << targ->value->id << ";}";
	else {
		out << "{_cs = " << targ->value->id << "; ";
		if ( anyEofActionHold() )
			out << "goto again;}";
		else 
			out << "goto out;}";
	}
	return out;
}

std::ostream &IpGotoCodeGen::CALL( NameInst *name, int targState, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	out << "{"; SELF() << "->stack["; SELF() << "->top++] = " << targState << "; ";
	if ( !inFinish )
		out << "goto st" << targ->value->id << ";}";
	else {
		out << "_cs = " << targ->value->id << "; ";
		if ( anyEofActionHold() )
			out << "goto again;}";
		else 
			out << "goto out;}";
	}
	return out;
}

std::ostream &IpGotoCodeGen::RET( bool inFinish )
{
	out << "{_cs = "; SELF() << "->stack[--"; SELF() << "->top]; ";
	if ( !inFinish || anyEofActionHold() )
		out << "goto again;}";
	else 
		out << "goto out;}";
	return out;
}

std::ostream &IpGotoCodeGen::GOTOE( InlineItem *ilItem, bool inFinish )
{
	out << "{_cs = (";
	INLINE_LIST( ilItem->children, 0, inFinish );
	out << "); ";
	if ( !inFinish || anyEofActionHold() )
		out << "goto again;}";
	else 
		out << "goto out;}";
	return out;
}

std::ostream &IpGotoCodeGen::CALLE( InlineItem *ilItem, int targState, bool inFinish )
{
	out << "{"; SELF() << "->stack["; SELF() << "->top++] = " << targState << "; _cs = (";
	INLINE_LIST( ilItem->children, 0, inFinish );
	out << "); ";
	if ( !inFinish || anyEofActionHold() )
		out << "goto again;}";
	else 
		out << "goto out;}";
	return out;
}

std::ostream &IpGotoCodeGen::NEXT( NameInst *name, bool inFinish )
{
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	out << "_cs = " << targ->value->id << ";";
	return out;
}

std::ostream &IpGotoCodeGen::NEXTE( InlineItem *ilItem, bool inFinish )
{
	out << "_cs = (";
	INLINE_LIST( ilItem->children, 0, inFinish );
	out << ");";
	return out;
}

/* Called from GotoCodeGen::STATE_GOTOS just before writing the gotos for each
 * state. */
std::ostream &IpGotoCodeGen::GOTO_HEADER( RedStateAp *state )
{
	bool anyWritten = false;

	/* Emit any transitions that have actions and that go to 
	 * this state. */
	for ( TransApSet::Iter trans = redFsm->transSet; trans.lte(); trans ++ ) {
		if ( trans->targ == state && trans->action != 0 ) {
			/* Remember that we wrote an action so we know to write the
			 * line directive for going back to the output. */
			anyWritten = true;

			/* Write the label for the transition so it can be jumped to. */
			out << "tr" << trans->id << ":\n";

			/* If the action contains a next, then we must preload the current
			 * state since the action may or may not set it. */
			if ( trans->action->anyNextStmt() )
				out << "	_cs = " << trans->targ->id << ";\n";

			/* Write each action in the list. */
			for ( ActionTable::Iter item = trans->action->key; item.lte(); item++ )
				ACTION( item->value, trans->targ->id, false );

			/* If the action contains a next then we need to reload, otherwise
			 * jump directly to the target state. */
			if ( trans->action->anyNextStmt() )
				out << "\tgoto again;\n";
			else
				out << "\tgoto st" << trans->targ->id << ";\n";
		}
	}

	if ( state->labelNeeded ) 
		out << "st" << state->id << ":\n";

	if ( state->toStateAction != 0 ) {
		/* Remember that we wrote an action. Write every action in the list. */
		anyWritten = true;
		for ( ActionTable::Iter item = state->toStateAction->key; item.lte(); item++ )
			ACTION( item->value, state->id, false );
	}

	/* Advance and test buffer pos. */
	if ( state->labelNeeded ) {
		out <<
			"	if ( ++_p == _pe )\n"
			"		goto out" << state->id << ";\n";
	}

	/* Give the state a switch case. */
	out << "case " << state->id << ":\n";

	if ( state->fromStateAction != 0 ) {
		/* Remember that we wrote an action. Write every action in the list. */
		anyWritten = true;
		for ( ActionTable::Iter item = state->fromStateAction->key; item.lte(); item++ )
			ACTION( item->value, state->id, false );
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "#line " << outFilter->line + 1 << " \""; LDIR_PATH(outputFile) << "\"\n";
	}


	/* Record the prev state if necessary. */
	if ( state->anyRegCurStateRef() )
		out << "	_ps = " << state->id << ";\n";
	return out;
}

/* Emit the goto to take for a given transition. */
std::ostream &IpGotoCodeGen::TRANS_GOTO( RedTransAp *trans, int level )
{
	if ( trans->action != 0 ) {
		/* Go to the transition which will go to the state. */
		TABS(level) << "goto tr" << trans->id << ";";
	}
	else {
		/* Go directly to the target state. */
		TABS(level) << "goto st" << trans->targ->id << ";";
	}
	return out;
}

std::ostream &IpGotoCodeGen::EXIT_STATES()
{
	for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ ) {
       if ( st->labelNeeded ) {
			out << 
				"	out" << st->id << ": _cs = " << st->id << "; goto out;\n";
		}
	}
	return out;
}

std::ostream &IpGotoCodeGen::AGAIN_CASES()
{
	for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ ) {
		out << 
			"		case " << st->id << ": goto st" << st->id << ";\n";
	}
	return out;
}

std::ostream &IpGotoCodeGen::FINISH_CASES()
{
	bool anyWritten = false;

	for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ ) {
		/* Cased needed if there are out actions. */
		if ( st->eofAction != 0 ) {
			out << "\tcase " << st->id << ": ";

			/* If there are out functions, write them. */
			/* Remember that we wrote a trans so we know to write the
			 * line directive for going back to the output. */
			anyWritten = true;

			out << "\n";
			/* Write each action in the eof action list. */
			for ( ActionTable::Iter item = st->eofAction->key; item.lte(); item++ )
				ACTION( item->value, STATE_ERR_STATE, true );
			out << "\tbreak;\n";
		}
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "#line " << outFilter->line + 1 << " \""; LDIR_PATH(outputFile) << "\"\n";
	}
	return out;
}

void IpGotoCodeGen::setLabelsNeeded( InlineList *inlineList )
{
	for ( InlineList::Iter item = *inlineList; item.lte(); item++ ) {
		if ( item->type == InlineItem::Goto || item->type == InlineItem::Call ) {
			/* Get the target and mark it as needing a label. */
			RedEntryMapEl *targ = redFsm->entryMap.find( item->nameTarg->id );
			targ->value->labelNeeded = true;
		}

		if ( item->children != 0 )
			setLabelsNeeded( item->children );
	}
}

/* Set up labelNeeded flag for each state. */
void IpGotoCodeGen::setLabelsNeeded()
{
	/* If we use the again label, then we the again switch, which uses all
	 * labels. */
	if ( useAgainLabel() ) {
		for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ )
			st->labelNeeded = true;
	}
	else {
		/* Do not use all labels by defaul, init all labelNeeded vars to false. */
		for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ )
			st->labelNeeded = false;

		/* Walk all transitions and set only those that have targs. */
		for ( TransApSet::Iter trans = redFsm->transSet; trans.lte(); trans++ ) {
			/* If there is no action with a next statement, then the label will be
			 * needed. */
			if ( trans->action == 0 || !trans->action->anyNextStmt() )
				trans->targ->labelNeeded = true;

			/* Need labels for states that have goto or calls in action code
			 * invoked on characters (ie, not from out action code). */
			if ( trans->action != 0 ) {
				/* Loop the actions. */
				for ( ActionTable::Iter act = trans->action->key; act.lte(); act++ ) {
					/* Get the action and walk it's tree. */
					setLabelsNeeded( act->value->inlineList );
				}
			}
		}
	}
}

std::ostream &IpGotoCodeGen::CURS( bool inFinish )
{
	out << "(_ps)";
	return out;
}

std::ostream &IpGotoCodeGen::TARGS( bool inFinish, int targState )
{
	out << targState;
	return out;
}

/* Init base data. */
CIpGotoCodeGen::CIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	FsmCodeGen(fsmName, parseData, redFsm, out)
{ }


void CIpGotoCodeGen::writeOutCode()
{
	out <<
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n";
	
	INIT_ROUTINE();

	out <<
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; EL_TYPE() << 
				" *_data, int _len )\n"
		"{\n"
		"	"; EL_TYPE() << " *_p = _data-1;\n"
		"	"; EL_TYPE() << " *_pe = _data+_len;\n"
		"	int _cs = fsm->curs";

	if ( anyRegCurStateRef() )
		out << ", _ps";

	out << 
		";\n"
		"	fsm->curs = -1;\n"
		"\n";

	EXECUTE_BEGIN();

	if ( useAgainLabel() ) {
		out << 
			"	goto resume;\n"
			"\n"
			"again:\n"
			"	switch ( _cs ) {\n";
			AGAIN_CASES() <<
			"	}\n"
			"\n"
			"resume:\n";
	}

	out <<
		"	if ( ++_p == _pe )\n"
		"		goto out;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS() << 
		"	}\n";
		EXIT_STATES() << 
		"\n";
	
	out <<
		"out:\n"
		"	fsm->curs = _cs;\n";

	if ( redFsm->errState != 0 ) {
		out <<
			"	if ( _cs == "; ERROR_STATE() << " )\n"
			"		return -1;\n";
	}

	out <<
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	out <<
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyEofActions() ) {
		if ( anyEofActionCharRef() ) {
			out << "	"; 
			if ( ! anyEofActionHold() ) {
				EL_TYPE() << " *_p = 0;\n";
			}
			else {
				EL_TYPE() << " *_p = (("; EL_TYPE() << "*)0)-1" << 
						", *_pe = (("; EL_TYPE() << "*)0)+1;\n";
			}
		}

		out << 
			"	int _cs = fsm->curs;\n"
			"	fsm->curs = -1;\n";

		if ( anyEofActionHold() ) {
			out <<
				"again:\n"
				"	if ( ++_p == _pe )\n"
				"		goto out;\n";
		}

		out <<
			"	switch ( _cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"\n";

		if ( anyEofActionHold() )
			out << "	goto again;\n";
		
		if ( anyEofActionControl() || anyEofActionHold() )
			out << "	out:\n";

		out << "	fsm->curs = _cs;\n";
	}

	if ( redFsm->errState != 0 ) {
		out <<
			"	if ( fsm->curs == "; ERROR_STATE() << " )\n"
			"		return -1;\n";
	}

	out <<
		"	if ( fsm->curs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	for ( ContextMap::Iter ctx = parseData->contextMap; ctx.lte(); ctx++ ) {
		/* Write out the vect. */
		out << "unsigned char _"; FSM_NAME() << "_ctxdata_" << ctx->key << "[] = {\n\t";
		CONTEXT( ctx->value->id );
		out << "};\n\n";
	}
}


/* Init base data. */
CppIpGotoCodeGen::CppIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	FsmCodeGen(fsmName, parseData, redFsm, out)
{ }

void CppIpGotoCodeGen::writeOutCode()
{
	out <<
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n";
	
	INIT_ROUTINE();
	
	out <<
		"int "; FSM_NAME() << "::execute( "; EL_TYPE() << " *_data, int _len )\n"
		"{\n"
		"	"; EL_TYPE() << " *_p = _data-1;\n"
		"	"; EL_TYPE() << " *_pe = _data+_len;\n"
		"	int _cs = this->curs";

	if ( anyRegCurStateRef() )
		out << ", _ps";

	out << 
		";\n"
		"	this->curs = -1;\n"
		"\n";

	EXECUTE_BEGIN();

	if ( useAgainLabel() ) {
		out << 
			"	goto resume;\n"
			"\n"
			"again:\n"
			"	switch ( _cs ) {\n";
			AGAIN_CASES() <<
			"	}\n"
			"resume:\n";
	}

	out <<
		"	if ( ++_p == _pe )\n"
		"		goto out;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS() <<
		"	}\n";
		EXIT_STATES() << 
		"\n";

	out <<
		"out:\n"
		"	this->curs = _cs;\n";

	if ( redFsm->errState != 0 ) {
		out <<
			"	if ( _cs == "; ERROR_STATE() << " )\n"
			"		return -1;\n";
	}

	out <<
		"	if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";
	
	out <<
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";
	
	if ( anyEofActions() ) {
		if ( anyEofActionCharRef() ) {
			out << "	"; 
			if ( ! anyEofActionHold() ) {
				EL_TYPE() << " *_p = 0;\n";
			}
			else {
				EL_TYPE() << " *_p = (("; EL_TYPE() << "*)0)-1" << 
						", *_pe = (("; EL_TYPE() << "*)0)+1;\n";
			}
		}

		out << 
			"	int _cs = this->curs;\n"
			"	this->curs = -1;\n";

		if ( anyEofActionHold() ) {
			out <<
				"again:\n"
				"	if ( ++_p == _pe )\n"
				"		goto out;\n";
		}

		out <<
			"	switch ( _cs ) {\n";
			FINISH_CASES() <<
			"	}\n"
			"\n";

		if ( anyEofActionHold() )
			out << "	goto again;\n";
		
		if ( anyEofActionControl() || anyEofActionHold() )
			out << "	out:\n";

		out << "	this->curs = _cs;\n";
	}

	if ( redFsm->errState != 0 ) {
		out <<
			"	if ( this->curs == "; ERROR_STATE() << " )\n"
			"		return -1;\n";
	}

	out <<
		"	if ( this->curs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	for ( ContextMap::Iter ctx = parseData->contextMap; ctx.lte(); ctx++ ) {
		out << "unsigned char "; FSM_NAME() << "::_ctxdata_" << ctx->key << "[] = {\n\t";
		CONTEXT( ctx->value->id );
		out << "};\n\n";
	}
}


/* Init base data. */
ObjCIpGotoCodeGen::ObjCIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	FsmCodeGen(fsmName, parseData, redFsm, out)
{ }

void ObjCIpGotoCodeGen::writeOutCode()
{
	out <<
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n";
	
	INIT_ROUTINE();
		
	out <<
		"- (int) executeWithData:("; EL_TYPE() << " *)_data len:(int)_len;\n"
		"{\n"
		"\t"; EL_TYPE() << " *_p = _data - 1;\n"
		"\t"; EL_TYPE() << " *_pe = _data + _len;\n"
		"\tint _cs = self->curs";

	if ( anyRegCurStateRef() )
		out << ", _ps";

	out << ";\n";
		
	out <<
		"\tself->curs = -1;\n"
		"\n";

	EXECUTE_BEGIN();

	if ( useAgainLabel() ) {
		out << 
			"	goto resume;\n"
			"\n"
			"again:\n"
			"	switch ( _cs ) {\n";
			AGAIN_CASES() <<
			"	}\n"
			"resume:\n";
	}

	out <<
		"	if ( ++_p == _pe )\n"
		"		goto out;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS() <<
		"	}\n";
		EXIT_STATES() << 
		"\n";

	out <<
		"out:\n"
			"\tself->curs = _cs;\n";

	if ( redFsm->errState != 0 ) {
		out <<
			"\tif ( _cs == "; ERROR_STATE() << " ) return -1;\n";
	}

	out <<
			"\treturn ( self->curs >= "; FIRST_FINAL_STATE() << " ) ? 1 : 0;\n"
		"}\n"
		"\n";
	
	out <<
		"- (int) finish;\n"
		"{\n";
	
	if ( anyEofActions() ) {
		if ( anyEofActionCharRef() ) {
			out << "	"; 
			if ( ! anyEofActionHold() ) {
				EL_TYPE() << " *_p = 0;\n";
			}
			else {
				EL_TYPE() << " *_p = (("; EL_TYPE() << "*)0)-1" << 
						", *_pe = (("; EL_TYPE() << "*)0)+1;\n";
			}
		}

		out << 
			"\tint _cs = self->curs;\n"
			"\tself->curs = -1;\n";

		if ( anyEofActionHold() ) {
			out <<
			"again:\n"
				"\tif ( ++_p == _pe )\n"
					"\t\tgoto out;\n";
		}

		out <<
				"\tswitch ( _cs ) {\n";
			FINISH_CASES() <<
				"\t}\n"
			"\n";

		if ( anyEofActionHold() ) {
			out << "\tgoto again;\n";
		}
		
		if ( anyEofActionControl() || anyEofActionHold() )
			out << "out:\n";

		out << "\tself->curs = _cs;\n";
	}

	if ( redFsm->errState != 0 ) {
		out <<
			"\tif ( self->curs == "; ERROR_STATE() << " ) return -1;\n";
	}

	out <<
		"\treturn ( self->curs >= "; FIRST_FINAL_STATE() << " ) ? 1 : 0;\n";

	out <<
		"}\n"
		"\n";

	for ( ContextMap::Iter ctx = parseData->contextMap; ctx.lte(); ctx++ ) {
		/* Write out the vect. */
		out << "unsigned char _"; FSM_NAME() << "_ctxdata_" << ctx->key << "[] = {\n\t";
		CONTEXT( ctx->value->id );
		out << "};\n\n";
	}
}

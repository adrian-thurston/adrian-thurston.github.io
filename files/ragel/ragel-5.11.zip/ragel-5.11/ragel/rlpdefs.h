/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TK_Section = 258,
     TK_SectionNL = 259,
     TK_UInt = 260,
     TK_Hex = 261,
     TK_Word = 262,
     TK_Literal = 263,
     TK_CiLiteral = 264,
     TK_BaseClause = 265,
     TK_DotDot = 266,
     TK_ColonGt = 267,
     TK_ColonGtGt = 268,
     TK_LtColon = 269,
     TK_Arrow = 270,
     TK_ReverseArrow = 271,
     TK_DoubleArrow = 272,
     TK_StarStar = 273,
     TK_ColonEquals = 274,
     TK_NameSep = 275,
     TK_BarStar = 276,
     TK_RepOpOpen = 277,
     TK_DashDash = 278,
     TK_StartCond = 279,
     TK_AllCond = 280,
     TK_LeavingCond = 281,
     TK_StartGblError = 282,
     TK_AllGblError = 283,
     TK_FinalGblError = 284,
     TK_NotFinalGblError = 285,
     TK_NotStartGblError = 286,
     TK_MiddleGblError = 287,
     TK_StartLocalError = 288,
     TK_AllLocalError = 289,
     TK_FinalLocalError = 290,
     TK_NotFinalLocalError = 291,
     TK_NotStartLocalError = 292,
     TK_MiddleLocalError = 293,
     TK_StartEOF = 294,
     TK_AllEOF = 295,
     TK_FinalEOF = 296,
     TK_NotFinalEOF = 297,
     TK_NotStartEOF = 298,
     TK_MiddleEOF = 299,
     TK_StartToState = 300,
     TK_AllToState = 301,
     TK_FinalToState = 302,
     TK_NotFinalToState = 303,
     TK_NotStartToState = 304,
     TK_MiddleToState = 305,
     TK_StartFromState = 306,
     TK_AllFromState = 307,
     TK_FinalFromState = 308,
     TK_NotFinalFromState = 309,
     TK_NotStartFromState = 310,
     TK_MiddleFromState = 311,
     RE_Slash = 312,
     RE_SqOpen = 313,
     RE_SqOpenNeg = 314,
     RE_SqClose = 315,
     RE_Dot = 316,
     RE_Star = 317,
     RE_Dash = 318,
     RE_Char = 319,
     IL_WhiteSpace = 320,
     IL_Comment = 321,
     IL_Literal = 322,
     IL_Symbol = 323,
     KW_Action = 324,
     KW_AlphType = 325,
     KW_Range = 326,
     KW_GetKey = 327,
     KW_Include = 328,
     KW_Write = 329,
     KW_Machine = 330,
     KW_When = 331,
     KW_Enter = 332,
     KW_All = 333,
     KW_Finish = 334,
     KW_Leave = 335,
     KW_Start = 336,
     KW_Final = 337,
     KW_Break = 338,
     KW_Exec = 339,
     KW_Pri = 340,
     KW_On = 341,
     KW_Into = 342,
     KW_From = 343,
     KW_EOF = 344,
     KW_Err = 345,
     KW_LErr = 346,
     KW_Hold = 347,
     KW_PChar = 348,
     KW_Char = 349,
     KW_Goto = 350,
     KW_Call = 351,
     KW_Ret = 352,
     KW_CurState = 353,
     KW_TargState = 354,
     KW_Entry = 355,
     KW_Next = 356,
     KW_Variable = 357,
     KW_Access = 358,
     TK_Semi = 359,
     EXPR_MINUS = 360
   };
#endif
/* Tokens.  */
#define TK_Section 258
#define TK_SectionNL 259
#define TK_UInt 260
#define TK_Hex 261
#define TK_Word 262
#define TK_Literal 263
#define TK_CiLiteral 264
#define TK_BaseClause 265
#define TK_DotDot 266
#define TK_ColonGt 267
#define TK_ColonGtGt 268
#define TK_LtColon 269
#define TK_Arrow 270
#define TK_ReverseArrow 271
#define TK_DoubleArrow 272
#define TK_StarStar 273
#define TK_ColonEquals 274
#define TK_NameSep 275
#define TK_BarStar 276
#define TK_RepOpOpen 277
#define TK_DashDash 278
#define TK_StartCond 279
#define TK_AllCond 280
#define TK_LeavingCond 281
#define TK_StartGblError 282
#define TK_AllGblError 283
#define TK_FinalGblError 284
#define TK_NotFinalGblError 285
#define TK_NotStartGblError 286
#define TK_MiddleGblError 287
#define TK_StartLocalError 288
#define TK_AllLocalError 289
#define TK_FinalLocalError 290
#define TK_NotFinalLocalError 291
#define TK_NotStartLocalError 292
#define TK_MiddleLocalError 293
#define TK_StartEOF 294
#define TK_AllEOF 295
#define TK_FinalEOF 296
#define TK_NotFinalEOF 297
#define TK_NotStartEOF 298
#define TK_MiddleEOF 299
#define TK_StartToState 300
#define TK_AllToState 301
#define TK_FinalToState 302
#define TK_NotFinalToState 303
#define TK_NotStartToState 304
#define TK_MiddleToState 305
#define TK_StartFromState 306
#define TK_AllFromState 307
#define TK_FinalFromState 308
#define TK_NotFinalFromState 309
#define TK_NotStartFromState 310
#define TK_MiddleFromState 311
#define RE_Slash 312
#define RE_SqOpen 313
#define RE_SqOpenNeg 314
#define RE_SqClose 315
#define RE_Dot 316
#define RE_Star 317
#define RE_Dash 318
#define RE_Char 319
#define IL_WhiteSpace 320
#define IL_Comment 321
#define IL_Literal 322
#define IL_Symbol 323
#define KW_Action 324
#define KW_AlphType 325
#define KW_Range 326
#define KW_GetKey 327
#define KW_Include 328
#define KW_Write 329
#define KW_Machine 330
#define KW_When 331
#define KW_Enter 332
#define KW_All 333
#define KW_Finish 334
#define KW_Leave 335
#define KW_Start 336
#define KW_Final 337
#define KW_Break 338
#define KW_Exec 339
#define KW_Pri 340
#define KW_On 341
#define KW_Into 342
#define KW_From 343
#define KW_EOF 344
#define KW_Err 345
#define KW_LErr 346
#define KW_Hold 347
#define KW_PChar 348
#define KW_Char 349
#define KW_Goto 350
#define KW_Call 351
#define KW_Ret 352
#define KW_CurState 353
#define KW_TargState 354
#define KW_Entry 355
#define KW_Next 356
#define KW_Variable 357
#define KW_Access 358
#define TK_Semi 359
#define EXPR_MINUS 360




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 67 "rlparse.y"
typedef union YYSTYPE {
	/* General data types. */
	char c;
	TokenData data;
	int integer;
	Literal *literal;

	/* Tree nodes. */
	Term *term;
	FactorWithAug *factorWithAug;
	FactorWithRep *factorWithRep;
	FactorWithNeg *factorWithNeg;
	Factor *factor;
	Expression *expression;
	Join *join;
	JoinOrLm *joinOrLm;
	LmPartList *longestMatchList;
	LongestMatchPart *longestMatchPart;

	/* Priorities and actions. */
	AugType augType;
	StateAugType stateAugType;
	Action *action;
	PriorDesc *priorDesc;

	/* Regular expression items. */
	RegExpr *regExp;
	ReItem *reItem;
	ReOrBlock *reOrBlock;
	ReOrItem *reOrItem;

	/* Inline parse tree items. */
	InlineItem *ilitem;
	InlineList *illist;
} YYSTYPE;
/* Line 1447 of yacc.c.  */
#line 284 "rlpdefs.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif





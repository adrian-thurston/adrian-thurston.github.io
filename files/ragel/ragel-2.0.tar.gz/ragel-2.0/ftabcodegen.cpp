/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "ftabcodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"

/* Integer array line length. */
#define IALL 8

/* Transition array line length. */
#define TALL 4

/* Init base data. */
FTabCodeGen::FTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	TabCodeGen(fsmName, parseData, machine, out)
{ }

/* Write out the out-func for a state. */
std::ostream &FTabCodeGen::STATE_OUT_FUNC(FsmMachState *state)
{
	/* This function is only called if there are any out functions, so need
	 * not guard against there being none. */
	out << state->outFuncs+1;
	return out;
}

/* Write out the function for a transition. */
std::ostream &FTabCodeGen::TRANS_FUNC(FsmMachTrans *trans)
{
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else
		out << trans->funcs+1;
	return out;
}

/* Write out the function switch. This switch is keyed on the values
 * of the func index. */
std::ostream &FTabCodeGen::FUNC_SWITCH()
{
	/* Loop over all func indicies. */
	int *transFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "\tcase " << i+1 << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = transFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			/* Get the function data. */
			ActionListEl *flel = parseData->actionIndex[*funcs];

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

			/* Wrap the block in brakets. */
			out << "\t{" << flel->data << "}\n";
			funcs += 1;
		}
		out << "\tbreak;\n";
	}

	/* Write the directive for going back into the output file. The line
	 * number is for the next line, so add one. */
	out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	return out;
}

std::ostream &FTabCodeGen::TRANSITIONS( int *statePos )
{
	/* Initial indentation. */
	out << '\t';
	FsmMachTrans *trans = machine->allTrans;
	for ( int i = 0; i < machine->numTrans; i++, trans++ ) {
		/* Write target state. */
		out << "{s+" << statePos[trans->toState] << ", ";

		/* Write the function for the state. Close transition. */
		if ( trans->funcs == FUNC_NO_FUNC )
			out << "0";
		else
			out << trans->funcs+1;
		out << "}";

		/* If not on the last transition, output a command 
		 * and possibly a line break. */
		if ( i < machine->numTrans-1 ) {
			out << ", ";

			/* Put in a break every 4, but only if not the last. */
			if ( i % TALL == TALL-1 )
				out << "\n\t";
		}
	}
	return out;
}

std::ostream &FTabCodeGen::LOCATE_TRANS()
{
	out <<
		"	/* Get required data. */\n"
		"	specs = *cs++;\n"
		"	keys = k + *cs++;\n"
		"	inds = i + *cs++;\n"
		"\n"
		"	/* Try flat index. */\n"
		"	if ( specs & SPEC_ANY_FLAT ) {\n"
		"		int indsLen = *cs++;\n"
		"		keys += 2;\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try binary search single. */\n"
		"	if ( specs & SPEC_ANY_SINGLE ) {\n"
		"		/* Try to find the key. */\n"
		"		int indsLen = *cs++;\n"
		"		"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
					"_bsearch( *p, keys, indsLen );\n"
		"\n"
		"		if ( match != 0 ) {\n"
		"			trans = t + inds[match - keys];\n"
		"			goto match;\n"
		"		}\n"
		"\n"
		"		/* Advance over the keys and indicies. */\n"
		"		keys += indsLen;\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try binary search range. */\n"
		"	if ( specs & SPEC_ANY_RANGE ) {\n"
		"		/* Try to find the key. */\n"
		"		int indsLen = *cs++;\n"
		"		"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
					"_range_bsearch( *p, keys, (indsLen<<1) );\n"
		"\n"
		"		if ( match != 0 ) {\n"
		"			trans = t + inds[(match - keys)>>1];\n"
		"			goto match;\n"
		"		}\n"
		"\n"
		"		/* Advance over the keys and indicies. */\n"
		"		keys += (indsLen<<1);\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try the default transition. */\n"
		"	if ( specs & SPEC_ANY_DEF ) {\n"
		"		trans = t + *inds;\n"
		"		goto match;\n"
		"	}\n";

	return out;
}



/* Init base class. */
CFTabCodeGen::CFTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FTabCodeGen(fsmName, parseData, machine, out)
{ }

void CFTabCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int *curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Init the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* Struct for a single transition. */\n"
		"struct "; FSM_NAME() << "_trans\n"
		"{\n"
		"	int *toState;\n"
		"	int funcs;\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static struct "; FSM_NAME() << "_trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( *fsm->curState & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"	int *cs = fsm->curState;\n"
		"	int specs";

	if ( anyTransFuncs() ) 
		out << ", funcs";

	out <<
		";\n"
		"	"; ALPH_TYPE() << " *keys;\n"
		"	"; INDEX_TYPE() << " *inds;\n"
		"	struct "; FSM_NAME() << "_trans *trans;\n"
		"\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out <<
		"again:\n"
		"	if ( cs == s )\n"
		"		goto out_err;\n"
		"\n"
		"	if ( len == 0 )\n"
		"		goto out_ok;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"	/* No match. */\n"
		"	goto out_err;\n"
		"\n"
		"match:\n"
		"	/* Move to the new state. */\n"
		"	cs = trans->toState;\n"
		"\n";

	if ( anyTransFuncs() ) {
		out << 
			"	/* Check for functions. */\n"
			"	if ( (funcs=trans->funcs) == 0 )\n"
			"		goto noFuncs;\n"
			"\n";

		/* Only used if there are out funcs. */
		if ( anyOutTransFuncs() )
			out << "execFuncs:\n";

		out <<
			"	switch ( funcs ) {\n";
			FUNC_SWITCH() <<
			"	}\n"
			"\n"
			"noFuncs:\n";
	}

	out <<
		"	p++, len--;\n"
		"	goto again;\n"
		"\n";

	/* If there are any functions, then jump to the func execution. */
	if ( anyOutTransFuncs() ) {
		out <<
			"finishInput:\n"
			"	/* Execute any out funcs for the final state. */\n"
			"	if ( *cs & SPEC_OUT_FUNC ) {\n"
			"		funcs = *(cs + (*cs>>8)-1);\n"
			"		len = 1;\n"
			"		goto execFuncs;\n"
			"	}\n"
			"	else if ( cs == s )\n"
			"		goto out_err;\n"
			"\n";
	}

	out << 
		"out_ok:\n"
		"	fsm->curState = cs;\n"
		"	if ( *cs & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	fsm->curState = s;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyOutTransFuncs() ) {
		/* May need to execute code in the action loop. Must use special
		 * params to execute func. */
		out << "	return "; FSM_NAME() << "_execute( fsm, 0, -1 );\n";
	}
	else {
		out << 
			"	if ( fsm->curState == s )\n"
			"		return -1;\n"
			"	else if ( *fsm->curState & SPEC_IS_FINAL )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out <<
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}


/* Init base data. */
CCFTabCodeGen::CCFTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FTabCodeGen(fsmName, parseData, machine, out) 
{ }

void CCFTabCodeGen::writeOutHeader()
{
	out <<
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Initialize the machine for execution. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int *curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCFTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* A single transition. */\n"
		"struct "; FSM_NAME() << "_trans\n"
		"{\n"
		"	int *toState;\n"
		"	int funcs;\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "_trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( *this->curState & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"	int *cs = this->curState;\n"
		"	int specs";
	
	if ( anyTransFuncs() ) 
		out << ", funcs";

	out <<
		";\n"
		"	"; ALPH_TYPE() << " *keys;\n"
		"	"; INDEX_TYPE() << " *inds;\n"
		"	"; FSM_NAME() << "_trans *trans;\n"
		"\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out <<
		"again:\n"
		"	if ( cs == s )\n"
		"		goto out_err;\n"
		"\n"
		"	if ( len == 0 )\n"
		"		goto out_ok;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"	/* No match. */\n"
		"	goto out_err;\n"
		"\n"
		"match:\n"
		"	/* Move to the new state. */\n"
		"	cs = trans->toState;\n"
		"\n";

	if ( anyTransFuncs() ) {
		out << 
			"	/* Check for functions. */\n"
			"	if ( (funcs=trans->funcs) == 0 )\n"
			"		goto noFuncs;\n"
			"\n";

		if ( anyOutTransFuncs() )
			out << "execFuncs:\n";

		out << 
			"	switch ( funcs ) {\n";
			FUNC_SWITCH() <<
			"	}\n"
			"\n"
			"noFuncs:\n";
	}

	out <<
		"	p++, len--;\n"
		"	goto again;\n"
		"\n";

	/* If there are any functions, then jump to the func execution. */
	if ( anyOutTransFuncs() ) {
		out <<
			"finishInput:\n"
			"	if ( *cs & SPEC_OUT_FUNC ) {\n"
			"		funcs = *(cs + (*cs>>8)-1);\n"
			"		len = 1;\n"
			"		goto execFuncs;\n"
			"	}\n"
			"	else if ( cs == s )\n"
			"		goto out_err;\n"
			"\n";
	}

	out <<
		"out_ok:\n"
		"	this->curState = cs;\n"
		"	if ( *cs & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	this->curState = s;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";

	if ( anyOutTransFuncs() ) {
		/* May need to execute code in the action loop. Must use special
		 * params to execute func. */
		out << "	return execute( 0, -1 );\n";
	}
	else {
		out << 
			"	if ( this->curState == s )\n"
			"		return -1;\n"
			"	else if ( *this->curState & SPEC_IS_FINAL )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out <<
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}

/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _PARSETREE_H
#define _PARSETREE_H

#include "ptreetypes.h"
#include "astring.h"
#include "avlmap.h"
#include "bstmap.h"
#include "astring.h"
#include "vectsimp.h"

/* Forwards. */
struct FsmMachine;
struct FsmCodeGen;
struct FsmAp;

/* Types of builtin machines. */
enum BuiltinType
{
	BT_Any,
	BT_Ascii,
	BT_Extend,
	BT_Alpha,
	BT_Digit,
	BT_Alnum,
	BT_Lower,
	BT_Upper,
	BT_Cntrl,
	BT_Graph,
	BT_Print,
	BT_Punct,
	BT_Space,
	BT_Xdigit
};

/* Location in an input file. */
struct InputLoc
{
	InputLoc( ) 
		: line(0), col(0) { }
	InputLoc( const BISON_YYLTYPE &loc );

	int line;
	int col;
};

/* Element in a generic list of strings. */
struct StringListEl : public DListEl<StringListEl>
{
public:
	StringListEl( const InputLoc &loc, char *data ) 
			: loc(loc), data(data) { }
	~StringListEl() { delete[] data; }

	InputLoc loc;
	char *data;
};

/* List of string elements. Used for actions and data to go into the fsm
 * struct. */
typedef DList<StringListEl> StringList;

/* Element in list of actions. Contains the string for the code to exectute. */
struct ActionListEl : public DListEl<ActionListEl>
{
public:
	ActionListEl( const InputLoc &loc, char *name, char *data, int actionId );
	~ActionListEl();

	/* Data collected during parse. */
	InputLoc loc;
	char *name;
	char *data;
	int actionId;

	/* For splitting actions by regular and out actions. */
	bool isRegAction;
	bool isOutAction;
	int regActionId;
	int outActionId;
};

/* A list of actions. */
typedef DList<ActionListEl> ActionList;

/* Structure for reverse action mapping. */
struct RevActionMapEl
{
	char *name;
	InputLoc location;
};

/* Store the value and type of a priority augmentation. */
struct PriorityAug
{
	PriorityAug( AugType type, int priorKey, int priorValue ) :
		type(type), priorKey(priorKey), priorValue(priorValue) { }

	AugType type;
	int priorKey;
	int priorValue;
};

/* Structrue represents an action assigned to some FactorWithAug node. The
 * factor with aug will keep an array of these. */
struct ParserAction
{
	ParserAction( int actionId, int ordering, AugType type ) :
		actionId(actionId), type(type) { }

	int actionId;
	AugType type;
};

struct ExpressionNode;
struct TermNode;
struct FactorWithAugNode;
struct FactorWithRepNode;
struct FactorWithNegNode;
struct FactorNode;
struct Literal;
struct Range;
struct RegExp;
struct ReItem;
struct ReOrBlock;
struct ReOrItem;
struct ExplicitMachine;

/* Graph dictionary. */
struct GraphDictEl 
	: public AvlTreeEl<GraphDictEl>
{
	GraphDictEl( char *k ) 
		: key(k), value(0), isInstance(false), line(0), col(0) { }
	GraphDictEl( char *k, ExpressionNode *value ) 
		: key(k), value(value), isInstance(false), line(0), col(0) { }

	char *key;
	ExpressionNode *value;
	bool isInstance;

	/* Location info of graph definition. Points to variable name of assignment. */
	int line;
	int col;

	const char *getKey() { return key; }
};
typedef AvlTree<GraphDictEl, char*, CmpStr> GraphDict;

/* Priority name dictionary. */
typedef AvlMapEl<char*, int> PriorDictEl;
typedef AvlMap<char*, int, CmpStr> PriorDict;

/* Action dictionary. */
typedef AvlMapEl<char*, int> ActionDictEl;
typedef AvlMap<char*, int, CmpStr> ActionDict;

enum AlphType
{
	AT_Char,
	AT_UnsignedChar,
	AT_Short,
	AT_UnsignedShort,
	AT_Int,
	AT_UnsignedInt
};

enum ExpKeyType {
	SingleCharLit,
	Number
};

/* Single transition in an explicit state machine. */
struct ExpTrans
{
	ExpTrans( ExpressionNode *expression, char *targState )
			: expression(expression), targState(targState) {}

	ExpressionNode *expression;
	char *targState;
};

/* List of explicit machine transitions. */
typedef VectSimp<int> ExpOutActions;
typedef Vector<ExpTrans> ExpTransList;

#define ESM_START 0x1
#define ESM_FINAL 0x2

/* State in an explicit state machine. */
struct ExpState
{
	ExpState( const InputLoc &loc, bool isStart, bool isFinState, char *name, 
			const ExpOutActions &outActions, bool isOutPriorSet, int outPriority, 
			const ExpTransList &transList )
	:
		loc(loc),
		isStart(isStart),
		isFinState(isFinState),
		name(name),
		outActions(outActions),
		isOutPriorSet(isOutPriorSet),
		outPriority(outPriority),
		transList(transList)
	{ }

	/* Line info. */
	InputLoc loc;

	/* State attributes. */
	bool isStart, isFinState;

	/* Name of state. */
	char *name;

	/* List of out actions if the state is final. */
	ExpOutActions outActions;

	/* Out priority if the state is final. */
	bool isOutPriorSet;
	int outPriority;

	/* Transition list for the state. */
	ExpTransList transList;

	/* Pointers for the double list of explicit machine states. */
	ExpState *prev, *next;
};

/* List of explicit machine states. */
typedef DList<ExpState> ExpStateList;

/* Class to collect information about the machine during the 
 * parse of input. */
class ParseData
{
public:
	/* Create a new parse data object. This is done at the beginning of every
	 * fsm specification. */
	ParseData( const String &fileName );
	~ParseData();

	/*
	 * Setting up the graph dict.
	 */

	/* Initialize a graph dict with the basic fsms. */
	void initGraphDict( );

	/* Make an index of pointers to the action blocks. */
	void fillActionIndex();

	/* Determine where actions are used. */
	void setActionsWhereUsed( FsmAp *graph );

	/* Make actions indicies for regular and out actions. */
	void fillSpecificActionIndicies();

	/* Rewrite all transitions to the specific action indicies. */
	void rewriteActionIndicies( FsmAp *graph );

	/* Set the alphabet type. If type types are not valid returns false. */
	bool setAlphType( String s1, String s2 );
	bool setAlphType( String s1 );

	/* Checks to make sure that mainline is an instance, if not issues a
	 * warning. */
	void checkMainInstance( char *name, GraphDictEl *main );

	/* Make the graph from a graph dict node. Does minimization. */
	FsmAp *makeGraph( GraphDictEl *gdNode );

	/* Find the graph possibly using the machine path. */
	GraphDictEl *findGraphMaybePath();

	/* Dumping and printing. */
	void dumpFsm();
	void printFsm();

	/* Generate graphviz code. */
	void generateGraphviz();

	/* Generate and write out the fsm. */
	void generateCode( );
	void doGenerateCode( GraphDictEl *gdNode );
	FsmCodeGen *makeCodeGen( FsmMachine *machine );

	/* Set the lower and upper range from the lower and upper number keys. */
	void setLowerUpperRange( );

	/*
	 * Querying the parse data
	 */

	/* Is the alphabet a signed type? */
	bool isAlphSigned();
	
	/*
	 * Data collected during the parse.
	 */

	/* Dictionary of graphs. When done we will lookup "main" */
	GraphDict graphDict;

	/* Dictionary of actions. Lets actions be defined and then referenced. */
	ActionDict actionDict;

	/* Dictionary of named priorities. */
	PriorDict priorDict;

	/* List of actions. Will be pasted into a switch statement. */
	ActionList actionList;
	ActionListEl **actionIndex;
	int numActionIndex;
	ActionListEl **regActionIndex;
	int numRegActionIndex;
	ActionListEl **outActionIndex;
	int numOutActionIndex;

	/* List of sections of data to add to the fsm struct. */
	StringList dataList;

	/* Collecting explicit machines. */
	ExpOutActions expOutActions;
	bool expIsOutPriorSet;
	int expOutPriority;
	ExpTransList expTransList;
	ExpStateList expStateList;

	/* The id of the next action and priority name. */
	int nextActionId, nextPriorKey;

	/* The default priority number key for a machine. This is active during
	 * the parse of the rhs of a machine assignment. */
	int curDefPriorKey;

	/* If a machine is given this is set. */
	bool machineGiven;

	/* Code sections put in the fsms init routine. */
	StringList initCodeList;

	/* Alphabet type. */
	AlphType alphType;

	/* The alphabet range. */
	String lowerNum, upperNum;
	long lowerKey, upperKey;
	InputLoc rangeLowLoc, rangeHighLoc;

	/* The name and location of the fsm. */
	String fsmName;
	InputLoc fsmStartSecLoc;
	InputLoc fsmEndSecLoc;

	/* The name of the file the fsm is from. */
	String fileName;

	/* Number of errors encountered parsing the fsm spec. */
	int errorCount;

	/* Counting the action and priority ordering. */
	int curActionOrd;
	int curPriorOrd;
};

/*
 * ExpressionNode
 */
struct ExpressionNode
{
	enum ExpressionNodeType { Or, Intersect, Subtract, Term, Builtin };

	/* Construct with an expression on the left and a term on the right. */
	ExpressionNode( ExpressionNode *expression, TermNode *term, 
		ExpressionNodeType type) : expression(expression), 
		term(term), builtin(builtin), type(type) { }

	/* Construct with only a term. */
	ExpressionNode( TermNode *term ) :
		expression(0), term(term), builtin(builtin), type(Term) { }
	
	/* Construct with a builtin type. */
	ExpressionNode( BuiltinType builtin ) :
		expression(0), term(0), builtin(builtin), type(Builtin) { }

	~ExpressionNode();

	/* Evaluate the expression. */
	FsmAp *walk( ParseData *pd );

	/* Data stored by the node. */
	ExpressionNode *expression;
	TermNode *term;
	BuiltinType builtin;
	ExpressionNodeType type;
};

/*
 * TermNode
 */
struct TermNode 
{
	enum TermNodeType { Concat, FactorWithAug };

	TermNode( TermNode *term, FactorWithAugNode *factorWithAug ) :
		term(term), factorWithAug(factorWithAug), type(Concat) { }

	TermNode( FactorWithAugNode *factorWithAug ) :
		term(0), factorWithAug(factorWithAug), type(FactorWithAug) { }
	
	~TermNode();

	FsmAp *walk( ParseData *pd );

	TermNode *term;
	FactorWithAugNode *factorWithAug;
	TermNodeType type;
};

/* Third level of precedence. Augmenting nodes with actions and priorities. */
struct FactorWithAugNode
{
	FactorWithAugNode( FactorWithRepNode *factorWithRep ) :
		priorDescs(0), factorWithRep(factorWithRep) { }
	~FactorWithAugNode();

	FsmAp *walk( ParseData *pd );

	/* Actions and priorities assigned to the factor node. */
	Vector<ParserAction> actions;
	Vector<PriorityAug> priorityAugs;
	PriorDesc *priorDescs;

	FactorWithRepNode *factorWithRep;
};

/* Fourth level of precedence. Trailing unary operators. Provide kleen star,
 * optional and plus. */
struct FactorWithRepNode
{
	enum FactorWithRepType { 
		Star, Optional, Plus, 
		Exact, Max, Min, Range,
		FactorWithNeg
	};

	FactorWithRepNode( const InputLoc &loc, FactorWithRepNode *factorWithRep, 
			int lowerRep, int upperRep, FactorWithRepType type ) :
		loc(loc), factorWithRep(factorWithRep), 
		factorWithNeg(0), lowerRep(lowerRep), 
		upperRep(upperRep), type(type) { }
	
	FactorWithRepNode( const InputLoc &loc, FactorWithNegNode *factorWithNeg )
		: loc(loc), factorWithNeg(factorWithNeg), type(FactorWithNeg) { }

	~FactorWithRepNode();

	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	FactorWithRepNode *factorWithRep;
	FactorWithNegNode *factorWithNeg;
	int lowerRep, upperRep;
	FactorWithRepType type;
};

/* Fifth level of precedence. Provides Negation. */
struct FactorWithNegNode
{
	enum FactorWithNegType
		{ Negate, Factor };

	FactorWithNegNode( const InputLoc &loc, FactorWithNegNode *factorWithNeg ) :
		loc(loc), factorWithNeg(factorWithNeg), factor(0), type(Negate) { }

	FactorWithNegNode( const InputLoc &loc, FactorNode *factor ) :
		loc(loc), factorWithNeg(0), factor(factor), type(Factor) { }

	~FactorWithNegNode();

	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	FactorWithNegNode *factorWithNeg;
	FactorNode *factor;
	FactorWithNegType type;
};

/*
 * FactorNode
 */
struct FactorNode 
{
	/* Language elements a factor node can be. */
	enum FactorType {
		LiteralFsm, 
		RangeFsm, 
		OrExpression,
		RegularExpression, 
		Explicit,
		Expression,
		LookupExpression
	}; 

	/* Construct with a literal fsm. */
	FactorNode( Literal *literal ) :
		literal(literal), type(LiteralFsm) { }

	/* Construct with a range. */
	FactorNode( Range *range ) : 
		range(range), type(RangeFsm) { }
	
	/* Construct with the or part of a regular expression. */
	FactorNode( ReItem *reItem ) :
		reItem(reItem), type(OrExpression) { }

	/* Construct with a regular expression. */
	FactorNode( RegExp *regExp ) :
		regExp(regExp), type(RegularExpression) { }

	/* Construct with an explicit machine. */
	FactorNode( ExplicitMachine *explicitMach ) :
		explicitMach(explicitMach), type(Explicit) { }

	/* Construct with an expression. */
	FactorNode( ExpressionNode *expression, FactorType type ) :
		expression(expression), type(type) {}

	/* Cleanup. */
	~FactorNode();

	/* Evaluation. */
	FsmAp *walk( ParseData *pd );

	Literal *literal;
	Range *range;
	ReItem *reItem;
	RegExp *regExp;
	ExplicitMachine *explicitMach;
	ExpressionNode *expression;
	int lower, upper;
	FactorType type;
};

/* A range machine. Only ever composed of two literals. */
struct Range
{
	Range( Literal *lowerLit, Literal *upperLit ) 
		: lowerLit(lowerLit), upperLit(upperLit) { }

	~Range();
	FsmAp *walk( ParseData *pd );

	Literal *lowerLit;
	Literal *upperLit;
};

/* Some literal machine. Can be a number or literal string. */
struct Literal
{
	enum LiteralType { Number, LitString, OrLitString };

	Literal( const InputLoc &loc, String str, LiteralType type )
		: loc(loc), str(str), type(type) { }

	long makeRangeEndPoint( ParseData *pd );
	FsmAp *walk( ParseData *pd );
	
	InputLoc loc;
	String str;
	LiteralType type;
};

/* Regular expression. */
struct RegExp
{
	enum RegExpType { RecurseItem, Empty };

	/* Constructors. */
	RegExp() 
		: type(Empty) { }
	RegExp(RegExp *regExp, ReItem *item) 
		: regExp(regExp), item(item), type(RecurseItem) { }

	~RegExp();
	FsmAp *walk( ParseData *pd );

	RegExp *regExp;
	ReItem *item;
	RegExpType type;
};

/* An item in a regular expression. */
struct ReItem
{
	enum ReItemType { Data, Dot, OrBlock, NegOrBlock };
	
	ReItem( const InputLoc &loc, char c ) 
		: loc(loc), str(&c, 1), star(false), type(Data) { }
	ReItem( const InputLoc &loc, ReItemType type )
		: loc(loc), star(false), type(type) { }
	ReItem( const InputLoc &loc, ReOrBlock *orBlock, ReItemType type )
		: loc(loc), orBlock(orBlock), star(false), type(type) { }

	~ReItem();
	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	String str;
	ReOrBlock *orBlock;
	bool star;
	ReItemType type;
};

/* An or block item. */
struct ReOrBlock
{
	enum ReOrBlockType { RecurseItem, Empty };

	/* Constructors. */
	ReOrBlock()
		: type(Empty) { }
	ReOrBlock(ReOrBlock *orBlock, ReOrItem *item)
		: orBlock(orBlock), item(item), type(RecurseItem) { }

	~ReOrBlock();
	FsmAp *walk( ParseData *pd );
	
	ReOrBlock *orBlock;
	ReOrItem *item;
	ReOrBlockType type;
};

/* An item in an or block. */
struct ReOrItem
{
	enum ReOrItemType { Data, Range };

	ReOrItem( char c ) 
		: str(&c, 1), type(Data) { }
	ReOrItem( char lower, char upper )
		: lower(lower), upper(upper), type(Range) { }

	FsmAp *walk( ParseData *pd );

	String str;
	char lower;
	char upper;
	ReOrItemType type;
};

/* An explicit machine. */
struct ExplicitMachine
{
	ExplicitMachine( const InputLoc &loc, const ExpStateList &stateList );

	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	ExpStateList stateList;
};


#endif /* _PARSETREE_H */

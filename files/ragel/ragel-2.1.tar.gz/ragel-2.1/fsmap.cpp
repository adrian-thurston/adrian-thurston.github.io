/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmap.h"
#include "fsmgraph.cpp"

/* Instantiate the base fsmgraph. */
template struct FsmGraph< FsmAp, StateAp, TransAp, long >;

/* The builder and graph dumping need these. */
template struct FsmOutIter< StateAp, TransAp, long >;
template struct FsmUniOutIter< FsmAp, StateAp, TransAp, long >;

/* Insert a function into a function table. */
void ActionTable::setAction( int action, int ordering )
{
	/* Multi-insert in case specific instances of an action appear in a
	 * transition more than once. */
	insertMulti( ordering, action );
}

/* Set all the functions from a funcTable in this table. */
void ActionTable::setActions( const ActionTable &other )
{
	for ( ActionTable::Iter action = other; action.lte(); action++ )
		insertMulti( action->key, action->value );
}

/* Insert a priority into this priority table. Looks out for priorities on
 * duplicate keys. */
void PriorTable::setPrior( PriorDesc *desc, int ordering )
{
	PriorEl *lastHit = 0;
	PriorEl *insed = insert( PriorEl(desc, ordering), &lastHit );
	if ( insed == 0 ) {
		/* This already has a priority on the same key as desc. Overwrite the
		 * priority if the ordering is larger (later in time). */
		if ( ordering >= lastHit->ordering )
			*lastHit = PriorEl( desc, ordering );
	}
}

/* Set alll the priorities from a priorTable in this table. */
void PriorTable::setPriors( const PriorTable &other )
{
	/* Loop src priorities once to overwrite duplicates. */
	PriorTable::Iter priorIt = other;
	for ( ; priorIt.lte(); priorIt++ )
		setPrior( priorIt->desc, priorIt->ordering );
}

/* Create a new fsm state. State has not out transitions or in transitions, not
 * out out transition data and not number. */
StateAp::StateAp()
:
	/* No out actions or priorities by default. */
	outActionTable(),
	outPriorTable()
{
}

/* Copy everything except actual the transitions. That is left up to the
 * FsmGraph copy constructor. */
StateAp::StateAp(const StateAp &other)
:
	/* Call the base copy constructor. */
	FsmState<FsmAp, StateAp, TransAp, long>( other ),

	/* Fsm state data. */
	outActionTable(other.outActionTable),
	outPriorTable(other.outPriorTable)
{
}

/* Init the signedness. */
FsmAp::FsmAp(bool isAlphSigned)
{
	/* Set the key signedness in the key compare inherited by FsmGraph. */
	FaKeyOps::isAlphSigned = isAlphSigned;
}

/* Sort states by final state status. Puts all non final in the first half
 * and all final in the second half. */
void FsmAp::sortStatesByFinal()
{
	/* Transfer final to a sorted list. Preserves ordering. */
	StateList secondHalf;
	for ( StateList::Iter state = stateList; state.lte(); ) {
		StateList::Iter next = state.next();

		/* If it is final, plunk it off the final state. list. */
		if ( state->isFinState() ) {
			stateList.detach( state );
			secondHalf.append( state );
		}

		state = next;
	}

	/* Append the second half back to the list. */
	stateList.append( secondHalf );
}

/* Set the priority of starting transitions. Isolates the start state so it has
 * no other entry points, then sets the priorities of all the transitions out
 * of the start state. If the start state is final, then the outPrior of the
 * start state is also set. The idea is that a machine that accepts the null
 * string can still specify the starting trans prior for when it accepts the
 * null word. */
void FsmAp::startFsmPrior( PriorDesc *prior, int ordering )
{
	/* Make sure the start state has no other entry points. */
	isolateStartState();

	/* Get the start state. */
	StateAp *startState = findEntry( 0 );

	/* Walk all transitions out of the start state. */
	FsmOutIter<StateAp, TransAp, long> outIt( startState );
	for ( ; ! outIt.end(); outIt++ )
		outIt.trans->priorTable.setPrior( prior, ordering );

	/* If the new start state is final then set the out priority. This follows
	 * the same convention as setting start funcs in the out funcs of a final
	 * start state. */
	if ( startState->stateBits & SB_ISFINAL )
		startState->outPriorTable.setPrior( prior, ordering );
}

/* Set the priority of all transitions in a graph. Walks all transition lists
 * and all def transitions. */
void FsmAp::allTransPrior( PriorDesc *prior, int ordering )
{
	/* Walk the out list of all states. */
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the out list of the state. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end() ; outIt++ ) 
			outIt.trans->priorTable.setPrior( prior, ordering );

		state = state->next;
	}
}

/* Set the priority of all transitions that go into a final state. Note that if
 * any entry states are final, we will not be setting the priority of any
 * transitions that may go into those states in the future. The graph does not
 * support pending in transitions in the same way pending out transitios are
 * supported. */
void FsmAp::finFsmPrior( PriorDesc *prior, int ordering )
{
	/* Walk all final states. */
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++) {
		/* Walk all in transitions of the final state. */
		FsmInIter<StateAp, TransAp, long> inIt( *st );
		for ( ; ! inIt.end(); inIt++ )
			inIt.trans->priorTable.setPrior( prior, ordering );
	}
}

/* Set the priority of any future out transitions that may be made going out of
 * this state machine. */
void FsmAp::leaveFsmPrior( PriorDesc *prior, int ordering )
{
	/* Walk all final states. */
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++) {
		StateAp *state = *st;
		state->outPriorTable.setPrior( prior, ordering );
	}
}



/* Set actions to execute on starting transitions. Isolates the start state
 * so it has no other entry points, then adds to the transition functions
 * of all the transitions out of the start state. If the start state is final,
 * then the func is also added to the start state's out func list. The idea is
 * that a machine that accepts the null string can execute a start func when it
 * matches the null word, which can only be done when leaving the start/final
 * state. */
void FsmAp::startFsmAction( int action, int ordering )
{
	/* Make sure the start state has no other entry points. */
	isolateStartState();

	/* Get the start state. */
	StateAp *startState = findEntry( 0 );

	/* Walk the start state's transitions, setting functions. */
	FsmOutIter<StateAp, TransAp, long> outIt( startState );
	for ( ; ! outIt.end(); outIt++ ) 
		outIt.trans->actionTable.setAction( action, ordering );

	/* If start state is final then insert on the out func. This means that you
	 * can have start and leaving funcs on a machine that recognizes the null
	 * word. */
	if ( startState->stateBits & SB_ISFINAL )
		startState->outActionTable.setAction( action, ordering );
}

/* Set functions to execute on all transitions. Walks the out lists of all
 * states. */
void FsmAp::allTransAction( int action, int ordering )
{
	/* Walk all states. */
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the out list of the state. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt++ )
			outIt.trans->actionTable.setAction( action, ordering );

		state = state->next;
	}
}

/* Specify functions to execute upon entering final states. If the start state
 * is final we can't really specify a function to execute upon entering that
 * final state the first time. So function really means whenever entering a
 * final state from within the same fsm. */
void FsmAp::finFsmAction( int action, int ordering )
{
	/* Walk all final states. */
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++) {
		/* Walk the final state's in list. */
		FsmInIter<StateAp, TransAp, long> inIt( *st );
		for ( ; ! inIt.end(); inIt++ )
			inIt.trans->actionTable.setAction( action, ordering );
	}
}

/* Add functions to any future out transitions that may be made going out of
 * this state machine. */
void FsmAp::leaveFsmAction( int action, int ordering )
{
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++) {
		StateAp *state = *st;
		state->outActionTable.setAction( action, ordering );
	}
}

/* Shift the function ordering of the start transitions to start
 * at fromOrder and increase in units of 1. Useful before staring.
 * Returns the maximum number of order numbers used. */
int FsmAp::shiftStartActionOrder( int fromOrder )
{
	int maxUsed = 0;

	/* Walk the start state's transitions, shifting function ordering. */
	FsmOutIter<StateAp, TransAp, long> outIt( findEntry(0) );
	for ( ; ! outIt.end(); outIt++ ) {
		TransAp *trans = outIt.trans;

		/* Walk the function data for the transition and set the keys to
		 * increasing values starting at fromOrder. */
		int curFromOrder = fromOrder;
		ActionTable::Iter action = trans->actionTable;
		for ( ; action.lte(); action++ ) 
			action->key = curFromOrder++;
	
		/* Keep track of the max number of orders used. */
		if ( curFromOrder - fromOrder > maxUsed )
			maxUsed = curFromOrder - fromOrder;
	}
	
	return maxUsed;
}

/* Remove all priorities. */
void FsmAp::clearAllPriorities()
{
	StateAp *state = stateList.head;
	while ( state ) {
		/* Clear out priority data. */
		state->outPriorTable.empty();

		/* Clear transition data from the out transitions. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt++ )
			outIt.trans->priorTable.empty();

		state = state->next;
	}
}

/* Zeros out the function ordering keys. This may be called before minimization
 * when it is known that no more fsm operations are going to be done.  This
 * will achieve greater reduction as states will not be separated on the basis
 * of function ordering. */
void FsmAp::nullFunctionKeys( )
{
	/* For each state... */
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the transitions for the state. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt ++ ) {
			/* Walk the action table for the transition. */
			for ( ActionTable::Iter action = outIt.trans->actionTable;
					action.lte(); action++ )
				action->key = 0;
		}

		/* Null the function keys of the out transtions. */
		for ( ActionTable::Iter action = state->outActionTable;
				action.lte(); action++ )
			action->key = 0;

		state = state->next;
	}
}

/* Walk the list of states and verify that non final states do not have out
 * data, that all stateBits are cleared, and that there are no states with
 * zero foreign in transitions. */
void FsmAp::verifyStates()
{
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		if ( ! (state->stateBits & SB_ISFINAL) ) {
			assert( state->outActionTable.length() == 0 );
			assert( state->outPriorTable.length() == 0 );
		}

		assert( (state->stateBits & (SB_KILLOTHERS | SB_WANTOTHER)) == 0 );
		assert( state->foreignInTrans > 0 );

		state = state->next;
	}
}

/*
 * Operation wrappers to assert each graph is of the same signedness.
 */

/* Wrap concatenation with sign assert. */
void FsmAp::concatOp( FsmAp *other )
{
	/* Assert same signedness and return graph concatenation op. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<FsmAp, StateAp, TransAp, long>::concatOp( other );
}

/* Wrap union with sign assert. */
void FsmAp::unionOp( FsmAp *other )
{
	/* Assert same signedness and return graph union op. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<FsmAp, StateAp, TransAp, long>::unionOp( other );
}

/* Wrap intersection with sign assert. */
void FsmAp::intersectOp( FsmAp *other )
{
	/* Assert same signedness and return graph intersection op. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<FsmAp, StateAp, TransAp, long>::intersectOp( other );
}

/* Wrap subtraction with sign assert. */
void FsmAp::subtractOp( FsmAp *other )
{
	/* Both this and the other graph should have the same signedness. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<FsmAp, StateAp, TransAp, long>::subtractOp( other );
}

/*
 * Callbacks.
 */

/* Compare two transitions according to their relative priority. */
int FsmAp::comparePrior( TransAp *trans1, TransAp *trans2 )
{
	/* Looking for differing priorities on same keys. Need to concurrently
	 * scan the priority lists. */
	PriorTable::Iter pd1 = trans1->priorTable;
	PriorTable::Iter pd2 = trans2->priorTable;

	while ( pd1.lte() && pd2.lte() ) {
		/* Check keys. */
		if ( pd1->desc->key < pd2->desc->key )
			pd1.increment();
		else if ( pd1->desc->key > pd2->desc->key )
			pd2.increment();
		/* Keys are the same, check priorities. */
		else if ( pd1->desc->priority < pd2->desc->priority )
			return -1;
		else if ( pd1->desc->priority > pd2->desc->priority )
			return 1;
		else {
			/* Keys and priorities are equal, advance both. */
			pd1.increment();
			pd2.increment();
		}
	}

	/* No differing priorities on the same key. */
	return 0;
}

/* Compares two transitions according to priority and functions. Pointers
 * should not be null. Does not consider to state or from state.  */
int FsmAp::compareTransData( TransAp *trans1, TransAp *trans2 )
{
	/* Compare the prior table. */
	int cmpRes = PriorTableDataCmp::
				compare( trans1->priorTable, trans2->priorTable );
	if ( cmpRes != 0 )
		return cmpRes;
	
	/* Priority tables the same. Compare function tables. */
	return ActionTableCmp::
			compare(trans1->actionTable, trans2->actionTable);
}



/* Compare the out transition data of two states. Compares out priorities and
 * out transitions. */
int FsmAp::compareStateData( const StateAp *state1, const StateAp *state2 )
{
	/* Compare the out prior table. */
	int cmpRes = PriorTableDataCmp::
				compare( state1->outPriorTable, state2->outPriorTable );
	if ( cmpRes != 0 )
		return cmpRes;

	/* Test outTransFuncTable. */
	return ActionTableCmp::compare(
			state1->outActionTable, state2->outActionTable);
}


/* Callback invoked when another trans (or possibly this) is added into this
 * transition during the merging process. */
void FsmAp::addInTrans( TransAp *destTrans, TransAp *srcTrans )
{
	/* Protect against adding in from ourselves. */
	if ( srcTrans == destTrans ) {
		/* Adding in ourselves, need to make a copy of the source transitions.
		 * The priorities are not copied in as that would have no effect. */
		destTrans->actionTable.setActions( ActionTable(srcTrans->actionTable) );
	}
	else {
		/* Not a copy of ourself, get the functions and priorities. */
		destTrans->actionTable.setActions( srcTrans->actionTable );
		destTrans->priorTable.setPriors( srcTrans->priorTable );
	}
}

void FsmAp::leavingFromState( TransAp *destTrans, StateAp *srcState )
{
	/* Get the actions data from the outActionTable. */
	destTrans->actionTable.setActions( srcState->outActionTable );

	/* Get the priorities from the outPriorTable. */
	destTrans->priorTable.setPriors( srcState->outPriorTable );
}


/* Callback invoked when otherState is added into this state during the
 * merging process. */
void FsmAp::addInState( StateAp *destState, StateAp *srcState )
{
	/* Merge the outTransFuncTable. */
	if ( srcState == destState ) {
		/* Duplicate the list to protect against write to source. The
		 * priorities are not copied in as that would have no effect. */
		destState->outActionTable.setActions( ActionTable( srcState->outActionTable ) );
	}
	else {
		/* Get the out functions and priorities. */
		destState->outActionTable.setActions( srcState->outActionTable );
		destState->outPriorTable.setPriors( srcState->outPriorTable );
	}
}

/* Callback invoked when a state looses its final state status. This is where
 * properties of final states get unset. At the point of invocation, it is
 * unspecified whether or not isFinState is set. */
void FsmAp::relinquishFinal( StateAp *state )
{
	/* Kill the out actions and priorities. */
	state->outActionTable.empty();
	state->outPriorTable.empty();
}


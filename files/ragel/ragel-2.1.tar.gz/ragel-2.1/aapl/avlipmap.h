/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  Aapl is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 *  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 *  more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Aapl; if not, write to the Free Software Foundation, Inc., 59
 *  Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _AAPL_AVLIPMAP_H
#define _AAPL_AVLIPMAP_H

/**
 * \addtogroup avltree 
 * @{
 */

/**
 * \class AvliPmap
 * \brief Linked key and value oriented AVL tree for void* size key and value.
 *
 * AvliPmap is an instantiation of AvliMap with void* types. It has a small
 * inline interface on top of AvliMap that performs casting of types.
 * AvliPmap is useful when a large number of maps are needed but code bloat
 * caused by multiple instantiations of templates in not acceptable.
 *
 * AvliPmap stores key and value pairs in element managed by the tree.  It is
 * intendend to be similar to standard map templates. AvliPmap requires that a
 * Key type and a Value type be given. A compare class need not be specified.
 * The key and value must be castable to a void* type.  Items can be inserted
 * with just a key or with a key and value pair.
 *
 * AvliPmap implicitly connects element with linked list pointers, allowing the
 * element to be walked in order using next and previous pointers.
 *
 * AvliPmap assumes all elements in the tree are allocated on the heap and
 * are to be managed by the tree. This means that the class destructor will
 * delete the contents of the tree. A deep copy will cause existing elements
 * to be deleted first.
 */

/*@}*/

#include "compare.h"
#include "avlimap.h"

typedef AvliMapEl< void*, void* > AvliPmapEl;

/* Common AvlTree Class */
template < class Key, class Value > class AvliPmap
		: public AvliMap< void*, void* >
{
public:
	typedef AvliMap< void*, void* > BaseTree;

	/* Insert a element into the tree. */
	AvliPmapEl *insert(const Key &key, AvliPmapEl **lastFound = 0 )
		{ return BaseTree::insert( (void *)key, lastFound ); }
	AvliPmapEl *insert(const Key &key, const Value &val, AvliPmapEl **lastFound = 0 )
		{ return BaseTree::insert( (void *)key, (void *)val, lastFound ); }

	/* Find a element in the tree. Returns the element if 
	 * key exists, false otherwise. */
	AvliPmapEl *find(const Key &key) const
		{ return BaseTree::find( (void *)key ); }

	/* Remove a element in the tree. */
	AvliPmapEl *detach(const Key &key)
		{ return BaseTree::detach( (void *)key ); }

	static Key key( AvliPmapEl *element )
		{ return (Key) element->key; }
	static Value value( AvliPmapEl *element )
		{ return (Value) element->value; }
};


#endif /* _AAPL_AVLIPMAP_H */

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMAP_H
#define _RLFSM_FSMAP_H

#include "fsmgraph.h"
#include "sbstmap.h"
#include "sbstset.h"
#include "avlmap.h"

struct TransAp;
struct StateAp;
struct FsmAp;

/* An abstraction of the key operators to enforce the possibility that the key
 * may be signed or unsigned. */
struct FaKeyOps
{
	/* Default to signed alphabet. */
	FaKeyOps() :isAlphSigned(true) {}

	/* Less than. */
	bool lt( long key1, long key2 ) {
		return isAlphSigned ?  key1 < key2 : 
			(unsigned long)key1 < (unsigned long)key2;
	}

	/* Greater than. */
	bool gt( long key1, long key2 ) {
		return isAlphSigned ? key1 > key2 : 
			(unsigned long)key1 > (unsigned long)key2;
	}

	/* Equality. */
	bool eq( long key1, long key2 ) {
		return key1 == key2;
	}

	/* Decrement. Needed only for ranges. */
	void dec( long &key ) {
		key = isAlphSigned ? key - 1 : ((unsigned long)key)-1;
	}

	/* Increment. Needed only for ranges. */
	void inc( long &key ) {
		key = isAlphSigned ? key+1 : ((unsigned long)key)+1;
	}

	bool isAlphSigned;
};

/* Transistion Action Element. */
typedef SBstMapEl< int, int > ActionTableEl;

/* Transition Action Table.  */
struct ActionTable 
	: public SBstMap< int, int, CmpOrd<int> >
{
	void setAction( int action, int odering );
	void setActions( const ActionTable &other );
};

/* Compare of a whole action table element (key & value). */
struct ActionTableElCmp
{
	static int compare( const ActionTableEl &action1, 
			const ActionTableEl &action2 )
	{
		int compareRes = CmpOrd<int>::compare( action1.key, action2.key );
		if ( compareRes != 0 )
			return compareRes;
		return CmpOrd<int>::compare( action1.value, action2.value );
	}
};


/* Compare for ActionTable. */
typedef CmpSTable< ActionTableEl, ActionTableElCmp > ActionTableCmp;

/* Descibe a priority, shared among PriorEls. 
 * Has key and whether or not used. */
struct PriorDesc
{
	int key;
	int priority;
	bool used;
};

/* Element in the arrays of priorities for transitions and arrays. Ordering is
 * unique among instantiations of machines, desc is shared. */
struct PriorEl
{
	PriorEl( PriorDesc *desc, int ordering ) 
		: desc(desc), ordering(ordering) { }

	PriorDesc *desc;
	int ordering;
};

/* Compare priority elements, which are ordered by the priority descriptor
 * key. */
struct PriorElCmp
{
	static inline int compare( const PriorEl &pel1, const PriorEl &pel2 ) 
	{
		if ( pel1.desc->key < pel2.desc->key )
			return -1;
		else if ( pel1.desc->key > pel2.desc->key )
			return 1;
		else
			return 0;
	}
};


/* Priority Table. */
struct PriorTable 
	: public SBstSet< PriorEl, PriorElCmp >
{
	void setPrior( PriorDesc *desc, int ordering );
	void setPriors( const PriorTable &other );
};

/* Compare of prior table elements for distinguising state data. */
struct PriorElDataCmp
{
	static inline int compare( const PriorEl &pel1, const PriorEl &pel2 )
	{
		if ( pel1.desc < pel2.desc )
			return -1;
		else if ( pel1.desc > pel2.desc )
			return 1;
		else if ( pel1.ordering < pel2.ordering )
			return -1;
		else if ( pel1.ordering > pel2.ordering )
			return 1;
		return 0;
	}
};

/* Compare of PriorTable distinguising state data. Using a compare of the
 * pointers is a little more strict than it needs be. It requires that
 * prioritiy tables have the exact same set of priority assignment operators
 * (from the input lang) to be considered equal. 
 *
 * Really only key-value pairs need be tested and ordering be merged. However
 * this would require that in the fuseing of states, priority descriptors be
 * chosen for the new fused state based on priority. Since the out transition
 * lists and ranges aren't necessarily going to line up, this is more work for
 * little gain. Final compression resets all priorities first, so this would
 * only be useful for compression at every operator, which is only an
 * undocumented test feature.
 */
typedef CmpSTable< PriorEl, PriorElDataCmp > PriorTableDataCmp;


/* Transition class that implements actions and priorities. */
struct TransAp 
:
	public FsmTrans< FsmAp, StateAp, TransAp, long >
{
	/* Plain action list that imposes no ordering. */
	typedef Vector<int> TransFuncList;

	/* Comparison for TransFuncList. */
	typedef CmpTable< int, CmpOrd<int> > TransFuncListCompare;

	/* The function table and priority for the transition. */
	ActionTable actionTable;
	PriorTable priorTable;

	/* Compare of PriorTable. */
	typedef CmpSTable< PriorDesc*, CmpOrd<PriorDesc*> > PriorTableCompare;
};


/* State class that implements actions and priorities. */
struct StateAp 
:
	public FsmState< FsmAp, StateAp, TransAp, long >
{
	StateAp();
	StateAp(const StateAp &other);

	/* 
	 * State Data
	 */

	/* Transition data to add to any transition leaving an fsm via this state. */
	ActionTable outActionTable;

	/* Out priorities transfered to out transitions. */
	PriorTable outPriorTable;
};


/* Graph class that implements actions and priorities. */
struct FsmAp 
:
	public FsmGraph< FsmAp, StateAp, TransAp, long >,
	public FaKeyOps
{
	/* Init the signedness. */
	FsmAp(bool isAlphSigned);

	/* The iterator types. */
	typedef FsmOutIter<StateAp, TransAp, long> OutIter;
	typedef FsmInIter<StateAp, TransAp, long> InIter;

	/* Sort states by final state status. Puts all non final in the first half
	 * and all final in the second half. */
	void sortStatesByFinal();

	/*
	 * Transition actions and priorities.
	 */

	/* Set priorities on transtions. */
	void startFsmPrior( PriorDesc *prior, int ordering );
	void allTransPrior( PriorDesc *prior, int ordering );
	void finFsmPrior( PriorDesc *prior, int ordering );
	void leaveFsmPrior( PriorDesc *prior, int ordering );

	/* Set actions to execute. */
	void startFsmAction( int action, int transOrder );
	void allTransAction( int action, int transOrder );
	void finFsmAction( int action, int transOrder );
	void leaveFsmAction( int action, int transOrder );

	/* Shift the action ordering of the start transitions to start at
	 * fromOrder and increase in units of 1. Useful before kleene star
	 * operation.  */
	int shiftStartActionOrder( int fromOrder );

	/* Clear all priorities from the fsm to so they won't affcet minimization
	 * of the final fsm. */
	void clearAllPriorities();

	/* Zero out all the function keys. */
	void nullFunctionKeys();

	/* Walk the list of states and verify state properties. */
	void verifyStates();

	/* Fsm Operators. */
	void concatOp( FsmAp *other );
	void unionOp( FsmAp *other );
	void intersectOp( FsmAp *other );
	void subtractOp( FsmAp *other );

	/*
	 * Callback implementations
	 */

	/* Compare transitions on relative priority. */
	static int comparePrior( TransAp *trans1, TransAp *trans2 );

	/* Compare priority and function table of transitions. */
	static int compareTransData( TransAp *trans1, TransAp *trans2 );

	/* Compare states on data stored in the states. */
	static int compareStateData( const StateAp *state1, const StateAp *state2 );

	/* Add in the properties of srcTrans into this. */
	void addInTrans( TransAp *destTrans, TransAp *srcTrans );

	/* This trans is going to be made a leaving-graph-trans from srcState. */
	void leavingFromState( TransAp *destTrans, StateAp *srcState );

	/* Invoked when two states are made into one by the minimization process. */
	void fuseInState( StateAp *destState, StateAp *srcState ) { }

	/* Invoked when otherState is added into this state during the merging process. */
	void addInState( StateAp *destState, StateAp *srcState );

	/* Invoked when a state looses its final state status. */
	void relinquishFinal( StateAp *state );
};

#endif /* _RLFSM_FSMAP_H */

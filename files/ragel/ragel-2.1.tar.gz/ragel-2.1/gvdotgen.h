/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _GVDOTGEN_H
#define _GVDOTGEN_H

#include <iostream>
#include "fsmap.h"

/* Forwards. */
struct TransAp;
struct StateAp;
struct FsmAp;
struct ParseData;

class GraphvizDotGen
{
public:
	GraphvizDotGen( char *fsmName, ParseData *parseData, FsmAp *graph, std::ostream &out );

	/* Print an fsm to out stream. */
	void writeDotFile( );

	/* Write the label for a transition. */
	std::ostream &LABEL( long lowerKey, long upperKey, bool defTrans, TransAp *trans );

private:
	enum LabelType { Numbered, Default, Out };

	/* Write the label for a transition. */
	std::ostream &LABEL( LabelType type, long lowerKey, long upperKey, 
			ActionTable *actionTable );
	std::ostream &KEY( long key );

	char *fsmName;
	ParseData *parseData;
	FsmAp *graph;
	std::ostream &out;
};


#endif /* _GVDOTGEN_H */

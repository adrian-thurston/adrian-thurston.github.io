/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  Aapl is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 *  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 *  more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Aapl; if not, write to the Free Software Foundation, Inc., 59
 *  Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _RLFSM_FSMGRAPH_H
#define _RLFSM_FSMGRAPH_H

#include <assert.h>
#include "vector.h"
#include "bstset.h"
#include "compare.h"
#include "avltree.h"
#include "dlistmel.h"
#include "bstmap.h"

/* Flags that control merging. */
#define SB_KILLOTHERS 0x01
#define SB_WANTOTHER1 0x02
#define SB_WANTOTHER2 0x04
#define SB_WANTOTHER  0x06
#define SB_ISFINAL    0x08
#define SB_ISMARKED   0x10

struct FsmMachState;

/* Differnt types of keys that transitions can be attached on. */
enum FsmKeyType
{
	KeyTypeSingle,
	KeyTypeRange,
	KeyTypeDefault
};

/* State list element for unambiguous access to list element. */
template <class State> struct FsmListEl { State *prev, *next; };

/* This is the marked index for a state pair. Used in minimization. It keeps
 * track of whether or not the state pair is marked. */
template <class State> struct MarkIndex
{
	MarkIndex(int states);
	~MarkIndex();

	void markPair(int state1, int state2);
	bool isPairMarked(int state1, int state2);

private:
	int numStates;
	bool *array;
};

/* Key operations for ordinal types such as int, char, void* */
template <class T> struct KeyOpsOrd
{
	/* Less than. */
	bool lt( const T key1, const T key2) {
		return key1 < key2;
	}

	/* Greater than. */
	bool gt( const T key1, const T key2 ) {
		return key1 > key2;
	}

	/* Equality. */
	bool eq( const T key1, const T key2 ) {
		return key1 == key2;
	}

	/* Decrement. Needed only for ranges. */
	void dec( T &key ) {
		key = key - 1;
	}

	/* Increment. Needed only for ranges. */
	void inc( T &key ) {
		key = key + 1;
	}
};


/**
 * \addtogroup fsmgraph 
 * @{
 */

/**
 * \class FsmTrans
 * \brief Base FSM graph transition.
 */

/*@}*/

/* Fsm graph transition. */
template < class State, class Transition, class Key, class KeyOps > struct FsmTrans
{
	FsmTrans( ) : fromState(0), toState(0) {}

	Transition *next, *prev;
	Key lowerKey;
	State *fromState;
	State *toState;

	/* Compare transition data. Either of the pointers may be null. */
	static inline int compareDataPtr( Transition *trans1, Transition *trans2 );

	/* Compare target state and transition data. Either pointer may be null. */
	static inline int compareFullPtr( Transition *trans1, Transition *trans2 );

	/* Compare target partitions. Either pointer may be null. */
	static inline int comparePartPtr( Transition *trans1, Transition *trans2 );

	/* Check marked status of target states. Either pointer may be null. */
	static inline bool shouldMarkPtr( MarkIndex<State> &markIndex, 
			FsmTrans *trans1, FsmTrans *trans2 );

	/*
	 * Callbacks
	 */

	/* Compare transitions on relative priority. */
	static inline int comparePrior( Transition *trans1, Transition *trans2 );

	/* Compare priority and function table of transitions. */
	static inline int compareTransData( Transition *trans1, Transition *trans2 );

	/* Add in the properties of srcTrans into this. */
	void addInTrans( Transition *srcTrans );

	/* This trans is going to be made a leaving-graph-trans from srcState. */
	void leavingFromState( State *srcState );
};

/* A element in a state dict. */
template<class State> struct StateDictEl :
		public AvlTreeEl< StateDictEl<State> >
{
	typedef BstSet< State* > StateSet;

	StateDictEl(const StateSet &stateSet) : stateSet(stateSet) { }

	const StateSet &getKey() { return stateSet; }
	StateSet stateSet;
	State *targState;
};

/* Data needed for a merge operation. */
template < class State > struct FsmMergeData
{
	FsmMergeData() 
		: stfillHead(0), stfillTail(0) { }

	typedef BstSet< State* > StateSet;
	typedef AvlTree< StateDictEl<State>, StateSet, CmpTable<State*> > StateDict;
	typedef DListMel< State, FsmListEl<State> > StateList;

	StateDict stateDict;

	State *stfillHead;
	State *stfillTail;

	void fillListAppend( State *state );
};

/* Element for the binary search table that will map alphabet characters to
 * transitions. */
template < class Transition, class Key > struct FsmTransListEl
{
	/* Constructors. */
	FsmTransListEl() { }
	FsmTransListEl( const Key &key ) 
		: key(key) { }
	FsmTransListEl( const Key &key, Transition *value ) 
		: key(key), value(value) { }

	Key key;
	Transition *value;
};

/* Extend binary search map with functions useful for ranges. */
template < class Transition, class Key, class KeyOps > 
		struct FsmTransList : Vector< FsmTransListEl<Transition, Key> >
{
	typedef FsmTransListEl<Transition, Key> TransEl;

	/* Given a transition key, find the range the key is in. */
	TransEl *findSingle( const Key &onChar, KeyOps *keyOps ) const;
	TransEl *findRange( const Key &onChar, KeyOps *keyOps ) const;
	TransEl *findLower( const Key &onChar, KeyOps *keyOps ) const;
	TransEl *insertSingle( const Key &onChar, KeyOps *keyOps );
	bool removeSingle( const Key &onChar, KeyOps *keyOps );	
};

template < class State > struct MinPartition 
		: public FsmListEl< MinPartition<State> >
{
	MinPartition() : active(false) { }

	DListMel< State, FsmListEl<State> > list;
	bool active;
};

/**
 * \addtogroup fsmgraph 
 * @{
 */

/**
 * \class FsmState
 * \brief Base FSM graph state.
 */

/*@}*/

/* Fsm Graph State. */
template < class State, class Transition, class Key, class KeyOps > 
		struct FsmState : public FsmListEl<State>
{
	FsmState();
	FsmState(const FsmState &other);
	~FsmState();

	/* Transition lists element and the table. */
	typedef FsmTransList<Transition, Key, KeyOps> TransList;
	typedef FsmTransListEl<Transition, Key> TransEl;

	/* Set of entry ids that go into this state. */
	typedef BstSet< int > EntryIdEl;
	typedef BstSet< int > EntryIdSet;

	/* Out transition lists and the pointer for the default out trans. */
	TransList outList;
	TransList outRange;
	Transition *outDefault;

	/* Pointers for the lists of in transitions. */
	Transition *inListHead, *inRangeHead, *inDefHead;

	/* What entry points in this state? */
	EntryIdSet entryIds;

	/* Number of in transitions from states other than ourselves. */
	int foreignInTrans;

	/* Temporary data for various algorithms. */
	union {
		/* When duplicating the fsm we need to map each 
		 * state to the new state representing it. */
		State *stateMap;

		/* When building the runnable machine, this maps graph states to
		 * machine states representing it. */
		FsmMachState *machState;

		/* When minimizing machines by partitioning, this maps to the group
		 * the state is in. */
		MinPartition<State> *partition;

		/* When merging states (state machine operations) this next pointer is
		 * used for the list of states that need to be filled in. */
		State *next;

		/* Identification for printing and stable minimization. */
		int stateNum;
	} alg;

	/* A pointer to a dict element that contains the set of states this state
	 * represents. This cannot go into alg, because alg.next is used during
	 * the merging process. */
	StateDictEl<State> *stateDictEl;

	/* Bits controlling the behaviour of the state during collapsing to dfa. */
	int stateBits;

	/* StateSet, StateDictEl */
	typedef BstSet< State* > StateSet;
	typedef AvlTree< StateDictEl<State>, StateSet, CmpTable<State*> > StateDict;

	/* Is the state final? */
	bool isFinState() { return stateBits & SB_ISFINAL; }

	/*
	 * Callbacks.
	 */

	/* Compare states on data stored in the states. */
	static int compareStateData( const State *state1, const State *state2 );

	/* Invoked when two states are made into one by the minimization process. */
	void fuseInState( State *otherState );

	/* Invoked when otherState is added into this state during the merging process. */
	void addInState( State *otherState );

	/* Invoked when a state looses its final state status. */
	void relinquishFinal( );
};

/* Iterator for a state's out transitions.  Objects being iterated over come
 * from 3 sources: out transitions, out ranges and the default transitions.
 * Skips over unset transition elements. */
template < class State, class Transition, class Key > struct FsmOutIter
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IterState {
		Begin,
		Trans,
		Range,
		Default,
		End
	};

	FsmOutIter( State *state );

	/* Query iterator. */
	bool lte() { return itState != End; }
	bool end() { return itState == End; }
	Transition *operator++(int);
	Transition *operator++();

	/* Transistion list element. */
	typedef FsmTransListEl<Transition, Key> TransEl;

	/* The trans pointer available outside this class. */
	Transition *trans;

	/* Loop variables. */
	TransEl *transEl;
	int nTransEl, i;

	/* Iterator state. */
	State *state;
	IterState itState;

private:
	void findNext();
};

/* Iterator for a state's single out transitions. Stops on all key-value pairs. */
template < class State, class Transition, class Key > struct FsmSingleIter
{
	FsmSingleIter( State *state );

	/* Transition list element. */
	typedef FsmTransListEl<Transition, Key> TransEl;

	/* Movement. */
	TransEl *operator++(int) { return transEl++; }
	TransEl *operator++() { return ++transEl; }

	/* Done, not done. */
	bool lte() { return transEl != endEl; }
	bool end() { return transEl == endEl; }

	/* Casting to trans element type. */
	operator TransEl*() const   { return transEl; }
	TransEl *operator->() const { return transEl; }

	/* Loop variables. */
	TransEl *transEl, *endEl;

private:
	void findNext();
};

/* Iterator for a state's range out transitions. Stops on all key-value pairs. */
template < class State, class Transition, class Key > struct FsmRangeIter
{
	FsmRangeIter( State *state );

	/* Transistion list element. */
	typedef FsmTransListEl<Transition, Key> TransEl;

	/* Movement. */
	TransEl *operator++(int) { return transEl++; }
	TransEl *operator++() { return ++transEl; }

	/* Done, not done. */
	bool lte() { return transEl != endEl; }
	bool end() { return transEl == endEl; }

	/* Casting to trans element type. */
	operator TransEl*() const   { return transEl; }
	TransEl *operator->() const { return transEl; }

	/* Loop variables. */
	TransEl *transEl, *endEl;

private:
	void findNext();
};

template < class State, class Transition, class Key, class KeyOps > 
		struct FsmUniOutIter
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IterState {
		Begin,
		SingleLeft,
		RangeLeft,
		BothLeft,
		End
	};

	FsmUniOutIter( State *state, KeyOps *keyOps );

	/* Query iterator. */
	bool lte() { return itState != End; }
	bool end() { return itState == End; }
	Transition *operator++(int);
	Transition *operator++();

	/* Transistion list element. */
	typedef FsmTransListEl<Transition, Key> TransEl;

	/* Loop variables. */
	TransEl *transEl, *rangeEl;
	TransEl *endTransEl, *endRangeEl;
	TransEl *srcRangeEl, headRange[2];

	Key lowerKey, upperKey;
	Transition *trans;

	/* Iterator state. */
	State *state;
	IterState itState;

	KeyOps *keyOps;

private:
	void findNext();
};


/* Iterator for a state's in transitions. This iterator does not adhere to
 * Aapl's standard iterator interface due to the exceptional requirements.
 * Objects being iterated over come from 3 sources: in transitions, in
 * ranges and the default transitions. These points are lists of transitions. */
template < class State, class Transition, class Key > struct FsmInIter
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IterState {
		Begin,
		Trans,
		Range,
		Default,
		End
	};

	FsmInIter( State *state );

	/* Query iterator. */
	bool lte() { return itState != End; }
	bool end() { return itState == End; }
	Transition *operator++(int);
	Transition *operator++();

	/* Transistion list element. */
	typedef FsmTransListEl<Transition, Key> TransEl;

	/* The trans pointer available outside this class. */
	Transition *trans;

	/* Iterator state. */
	State *state;
	IterState itState;

private:
	void findNext();
};

template < class State, class Transition, class Key, class KeyOps >
		struct FsmPairIter
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IterState {
		Begin,
		ConsumeS1Trans, ConsumeS2Trans,
		OnlyInS1Trans,  OnlyInS2Trans,
		InBothTrans,
		ConsumeS1Range, ConsumeS2Range,
		OnlyInS1Range,  OnlyInS2Range,
		S1SticksOut,    S1SticksOutBreak,
		S2SticksOut,    S2SticksOutBreak,
		S1DragsBehind,  S1DragsBehindBreak,
		S2DragsBehind,  S2DragsBehindBreak,
		ExactOverlap,   End
	};

	/** Encodes the different states that are meaningful to the user. */
	enum UserState {
		TransInS1,  TransInS2,
		TransOverlap,
		RangeInS1,  RangeInS2,
		RangeOverlap,
		BreakS1,    BreakS2
	};

	FsmPairIter( const State *state1, const State *state2, 
			KeyOps *keyOps, bool wantBreaks );

	/* Query iterator. */
	bool lte() { return itState != End; }
	bool end() { return itState == End; }
	void operator++(int) { findNext(); }
	void operator++()    { findNext(); }

	typedef FsmTransListEl<Transition, Key> TransEl;

	/* Iterator state. */
	const State *state1;
	const State *state2;
	IterState itState;
	UserState userState;


	TransEl *s1Tel, *s1EndTel;
	TransEl *s2Tel, *s2EndTel;
	TransEl *s1Range, *s2Range;
	int savedKey;
	Transition *savedTrans;
	TransEl s1HeadTel[2], s2HeadTel[2];
	TransEl s1NextTel[2], s2NextTel[2];
	Transition *defTrans;

	KeyOps *keyOps;
	bool wantBreaks;

private:
	void findNext();
};

/* Compare class for the Approximate minimization. */
template < class State, class Transition, class Key, class KeyOps > 
		class ApproxCompare
{
	/* Iterator Type */
	typedef FsmPairIter<State, Transition, Key, KeyOps> PairIter;

public:
	ApproxCompare() : keyOps(0) { }
	int compare( const State *pState1, const State *pState2 );

	/* Signed alphabet, used in comparison of out transitions. */
	KeyOps *keyOps;
};

/* Compare class for the initial partitioning of a partition minimization. */
template < class State, class Transition, class Key, class KeyOps >
		class InitPartitionCompare
{
	/* Iterator Type */
	typedef FsmPairIter<State, Transition, Key, KeyOps> PairIter;

public:
	InitPartitionCompare() : keyOps(0) { }
	int compare( const State *pState1, const State *pState2 );

	/* Signed alphabet, used in comparison of out transitions. */
	KeyOps *keyOps;
};

/* Compare class for the regular partitioning of a partition minimization. */
template < class State, class Transition, class Key, class KeyOps > 
		class PartitionCompare
{
	/* Iterator Type */
	typedef FsmPairIter<State, Transition, Key, KeyOps> PairIter;

public:
	PartitionCompare() : keyOps(0) { }
	int compare( const State *pState1, const State *pState2 );

	/* Signed alphabet, used in comparison of out transitions. */
	KeyOps *keyOps;
};

/* Compare class for a minimization that marks pairs. Provides the shouldMark
 * routine. */
template < class State, class Transition, class Key, class KeyOps > class MarkCompare
{
	/* Iterator Type */
	typedef FsmPairIter<State, Transition, Key, KeyOps> PairIter;

public:
	MarkCompare() : keyOps(0) { }
	bool shouldMark( MarkIndex<State> &markIndex, const State *pState1, 
			const State *pState2 );

	/* Signed alphabet, used in comparison of out transitions. */
	KeyOps *keyOps;
};

/**
 * \addtogroup fsmgraph 
 * @{
 */

/**
 * \class FsmGraph
 * \brief Base FSM graph functionality
 */

/*@}*/

/* Fsm graph structure. */
template < class State, class Transition, class Key, class KeyOps > 
		struct FsmGraph : public KeyOps
{
public:
	/* Constructor/Destructor. */
	FsmGraph();
	FsmGraph(const FsmGraph &graph);
	~FsmGraph();

	/* StateSet, StateDict */
	typedef BstSet< State* > StateSet;
	typedef AvlTree< StateDictEl<State>, StateSet, CmpTable<State*> > StateDict;

	/* The list of states. */
	typedef FsmListEl< State > StateListEl;
	typedef DListMel< State, FsmListEl<State> > StateList;

	/* List of partitions. */
	typedef DListMel< MinPartition<State>, FsmListEl< MinPartition<State> > > PartitionList;

	/* List of transtions out of a state. */
	typedef FsmTransList<Transition, Key, KeyOps> TransList;
	typedef FsmTransListEl<Transition, Key> TransEl;
	typedef Vector< TransEl > TransListVect;

	/* Entry point map used for keeping track of entry points in a machine. */
	typedef BstMapEl< int, State* > EntryEl;
	typedef BstMap< int, State* > EntryMap;

	/* Data required on a merge. */
	typedef FsmMergeData<State> MergeData;

	/* Iterator Type */
	typedef FsmPairIter<State, Transition, Key, KeyOps> PairIter;

	/* The list of states. */
	StateList stateList;
	StateList misfitList;

	/* The map of entry points. */
	EntryMap entryPoints;

	/* The set of final states. */
	StateSet finStateSet;

	/* Misfit Accounting. Are misfits put on a separate list. */
	bool misfitAccounting;
	void setMisfitAccounting( bool val ) 
		{ misfitAccounting = val; }

	/* Set and Unset a state as final. */
	void setFinState( State *state );
	void unsetFinState( State *state );

	/* Set and unset a state as an entry point. */
	void setEntry( int id, State *state );
	void unsetEntry( int id );
	void changeEntry( int id, State *state );
	State *findEntry( int id ) const;

	/* Determine if there are any entry points into a start state other than
	 * the start state. */
	bool isStartStateIsolated();

	/* Make a new start state that has no entry points. Will not change the
	 * identity of the fsm. */
	void isolateStartState( );

	/*
	 * Basic attaching and detaching.
	 */

	/* Common to attaching/detaching list and default. */
	void attachTrans(State *from, State *to, Transition *&head, Transition *trans);
	void detachTrans(State *from, State *to, Transition *&head, Transition *trans);

	/* Attach with a new transition. */
	Transition *attachNewTrans( State *from, State *to, FsmKeyType keyType, 
			const Key &onChar1, const Key &onChar2 );

	/* Attach with an existing transition that already in an out list. */
	void attachExisting( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, const Key &onChar );

	/* Detach a transition from a target state. */
	void detachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, const Key &onChar );

	/* When a range is split the lower key changes, this fixes it. */
	void changeRangeLowerKey( Transition *trans, const Key &oldKey, const Key &newKey );

	/* Detach a state from the graph. */
	void detachState( State *state );

	/*
	 * NFA to DFA conversion routines.
	 */

	/* Duplicate a transition that will dropin to a free spot. */
	Transition *dupTrans( State *from, FsmKeyType keyType, const Key &onChar,
			Transition *srcTrans, bool leavingFsm );

	/* In crossing, src trans overwrites the existing one because it has a
	 * higher priority. */
	Transition *overwriteTrans( MergeData &md, State *from, FsmKeyType keyType, 
			const Key &onChar, Transition *destTrans, Transition *srcTrans, bool leavingFsm );

	/* In crossing, src trans and dest trans are merged. */
	Transition *fsmAttachStates( MergeData &md, State *from, FsmKeyType keyType,
			const Key &onChar, Transition *destTrans, Transition *srcTrans, bool leavingFsm );

	/* Cross a src transition with one that is already occupying a spot. */
	Transition *crossTransitions( MergeData &md, State *from, FsmKeyType keyType, 
			const Key &onChar, Transition *destTrans, Transition *srcTrans,
			bool leavingFsm );

	/* Common to copying transition lists and ranges. */
	Transition *keyInDestEl( MergeData &md, State *dest, State *src, TransEl *destTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm );
	Transition *keyInSrcEl( MergeData &md, State *dest, State *src, TransEl *srcTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm );
	Transition *keyInBothEl( MergeData &md, State *dest, State *src, TransEl *destTel,
			TransEl *srcTel, FsmKeyType keyType, bool leavingFsm );

	/* Copy the default transition. */
	void copyDefTrans( MergeData &md, State *dest, State *src, bool leavingFsm );

	/* Copy the out transitions from src to dest. */
	void outTransCopy( MergeData &md, State *dest, State *src, bool leavingFsm );

	/* Merge a set of states into newState. */
	void mergeStates( MergeData &md, State *newState, StateSet &stateSet, 
			bool leavingFsm );

	/* Make all states that are combinations of other states and that
	 * have not yet had their out transitions filled in. This will 
	 * empty out stateDict and stFil. */
	void fillInStates( MergeData &md );

	/*
	 * Various.
	 */

	/* New up a state and add it to the graph. */
	State *newState();

	/* Build basic fsms. */
	void concatFsm( const Key &c );
	void concatFsm( const Key *str, int len );
	void orFsm( const Key *set, int len );
	void nullFsm( );
	void dotFsm( );
	void dotStarFsm( );
	void rangeFsm( const Key &low, const Key &high );

	/* Fsm Operators. */
	void starOp( bool leavingFsm );
	void concatOp( FsmGraph *other, bool leavingFsm );
	void unionOp( FsmGraph *other );
	void intersectOp( FsmGraph *other );
	void subtractOp( FsmGraph *other );
	void epsilonOp( State **fromStates, int nstates, FsmGraph *other );

	/* Underlying worker behind Or, Intersect and Subtract. */
	void doOr( FsmGraph *other );

	/* Unset any final states that are no longer to be final 
	 * due to final bits. */
	void unsetIncompleteFinals();

	/* Bring in other's entry points. Assumes others states are going to be
	 * copied into this machine. */
	void copyInEntryPoints( FsmGraph *other );

	/* Set State numbers starting at 0. */
	void setStateNumbers();

	/* Unset all final states. */
	void unsetAllFinStates();

	/* Set the bits of final states and clear the bits of non final states. */
	void setFinBits( int finStateBits );

	/* Assert that there are no out funcs/priorities on non final states. */
	void verifyStates();

	/* Run a sanity check on the machine. */
	void verifyIntegrity();

	/*
	 * Path pruning
	 */

	/* Mark all states reachable from state. */
	void markReachableFromHereReverse( State *state );

	/* Mark all states reachable from state. */
	void markReachableFromHere( State *state );

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void removeDeadEndStates();

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void removeUnreachableStates();

	/* Remove states that are on the misfit list. */
	void removeMisfits();

	/*
	 * FSM Minimization
	 */

	/* Minimization by partitioning. */
	void minimizePartition1();
	void minimizePartition2();

	/* Minimize the final state Machine. The result is the minimal fsm. Slow
	 * but stable, correct minimization. Uses n^2 space (lookout) and average
	 * n^2 time. Worst case n^3 time, but a that is a very rare case. */
	void minimizeStable();

	/* Minimize the final state machine. Does not find the minimal fsm, but a
	 * pretty good approximation. Does not use any extra space. Average n^2
	 * time. Worst case n^3 time, but a that is a very rare case. */
	void minimizeApproximate();

	/* This is the worker for the minimize approximate solution. It merges
	 * states that have identical out transitions. */
	bool minimizeRound( );

	/* Given an intial partioning of states, split partitions that have out trans
	 * to differing partitions. */
	int partitionRound( State **statePtrs, MinPartition<State> *parts, int numParts );

	/* Split partitions that have a transition to a previously split partition, until
	 * there are no more partitions to split. */
	int splitCandidates( State **statePtrs, MinPartition<State> *parts, int numParts );

	/* Fuse together states in the same partition. */
	void fusePartitions( MinPartition<State> *parts, int numParts );

	/* Mark pairs where out final stateness differs, out trans data differs,
	 * trans pairs go to a marked pair or trans data differs. Should get 
	 * alot of pairs. */
	void initialMarkRound( MarkIndex<State> &markIndex );

	/* One marking round on all state pairs. Considers if trans pairs go
	 * to a marked state only. Returns whether or not a pair was marked. */
	bool markRound( MarkIndex<State> &markIndex );

	/* Move the in trans into src into dest. */
	void inTransMove(State *dest, State *src);
	
	/* Make state src and dest the same state. */
	void fuseEquivStates(State *dest, State *src);

	/* Find any states that didn't get marked by the marking algorithm and
	 * merge them into the primary states of their equivalence class. */
	void fuseUnmarkedPairs( MarkIndex<State> &markIndex );
};

#endif /* _RLFSM_FSMGRAPH_H */

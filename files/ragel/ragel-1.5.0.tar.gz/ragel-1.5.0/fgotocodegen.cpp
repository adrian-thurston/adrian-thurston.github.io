/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "fgotocodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"


/* Init base data. */
FGotoCodeGen::FGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
: 
	GotoCodeGen(fsmName, parseData, machine, out)
{ }

std::ostream &FGotoCodeGen::EXEC_FUNCS()
{
	/* Loop over all func indicies. */
	int *transFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "f" << i << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = transFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			/* Get the function data. */
			FuncListEl *flel = parseData->funcIndex[*funcs];

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

			/* Wrap the block in brakets. */
			out << "\t{" << flel->data << "}\n";
			funcs += 1;
		}
		out << "\tgoto again;\n";
	}

	/* Write the directive for going back into the output file. The line
	 * number is for the next line, so add one. */
	out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";

	return out;
}

std::ostream &FGotoCodeGen::FINISH_CASES()
{
	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;
		if ( state->isFinState ) {
			out << "\t\tcase " << st << ": ";

			if ( state->outFuncs != FUNC_NO_FUNC ) {
				/* There are funcs, specify the func and break to them. */
				out << "acpt = 1; goto f" << state->outFuncs << ";\n";
			}
			else {
				/* No funcs, just return. */
				out << "goto accept;\n";
			}
		}
	}

	return out;
}

/* Init base data. */
CFGotoCodeGen::CFGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, machine, out)
{ }

/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CFGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}

void CFGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n";
		STRUCT_DATA() <<
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = fsm->curState, acpt = 0;\n"
		"\n"
		"	if ( data == 0 )\n"
		"		goto finishInput;\n"
		"\n";

	if ( anyTransFuncs() )
		out << "again:\n";

	out <<
		"	if ( --len == 0 )\n"
		"		goto out;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() << 
		"\n"
		"finishInput:\n"
		"	len = 1;\n"
		"	switch( cs ) {\n";
		FINISH_CASES() <<
		"		default: goto error;\n"
		"	}\n"
		"\n";

	if ( anyFinWithNoOutFuncs() ) {
		out <<
			"accept:\n"
			"	acpt = 1;\n"
			"	goto out;\n"
			"\n";
	}

	out << 
		"error:\n"
		"	cs = 0;\n"
		"\n"
		"out:\n"
		"	fsm->curState = cs;\n"
		"	fsm->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	"; FSM_NAME() << "Execute( fsm, 0, 0 );\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n";
}

/* Init base data. */
CCFGotoCodeGen::CCFGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FGotoCodeGen(fsmName, parseData, machine, out)
{ }

/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCFGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCFGotoCodeGen::writeOutHeader()
{
	out << 
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n"
		"\n"
		"	/* The start state. */\n"
		"	static int startState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCFGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* The constructor initializes the fsm. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the fsm. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	this->curState = startState;\n"
		"	this->accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = this->curState, acpt = 0;\n"
		"\n"
		"	if ( data == 0 )\n"
		"		goto finishInput;\n"
		"\n";

	if ( anyTransFuncs() )
		out << "again:\n";

	out <<
		"	if ( --len == 0 )\n"
		"		goto out;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n"
		"\n";
		TRANSITIONS() <<
		"\n";

	if ( anyTransFuncs() )
		EXEC_FUNCS() << "\n";

	EXIT_STATES() << 
		"\n"
		"finishInput:\n"
		"	len = 1;\n"
		"	switch( cs ) {\n";
		FINISH_CASES() <<
		"		default: goto error;\n"
		"	}\n"
		"\n";

	if ( anyFinWithNoOutFuncs() ) {
		out <<
			"accept:\n"
			"	acpt = 1;\n"
			"	goto out;\n"
			"\n";
	}

	out << 
		"error:\n"
		"	cs = 0;\n"
		"\n"
		"out:\n"
		"	this->curState = cs;\n"
		"	this->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	Execute( 0, 0 );\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return this->accept;\n"
		"}\n"
		"\n";
}

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_AVLITREE_H
#define _AAPL_AVLITREE_H

#include "compare.h"
#include "dlistmel.h"

/**
 * \addtogroup avltree
 * @{
 */

/**
 * \class AvliTree
 * \brief Linked AVL tree.
 *
 * AvliTree is the standard by-structure AVL tree. A node class and a key type
 * must be given. Nodes can be inserted by specifying a key only or by
 * explicitly creating the node and then inserting it. The node type must have
 * the appropriate AVL node pointers. This can be achieved by inheriting from
 * the AvlNode class.
 *
 * AvliTree implicitly connects nodes with linked list pointers, allowing the
 * nodes to be walked in order using next and previous pointers.
 *
 * AvliTree does not explicitly manage memory for nodes. Nodes inserted into
 * the tree can be allocated by the user or can be allocated by the tree. In
 * any case, the tree does not assume ownership of the nodes. The destructor
 * will not delete nodes. A deep copy will cause existing elements to be
 * abandoned.
 *
 * \include ex_avlitree.cpp
 */

/*@}*/

#define BASENODE(name) name
#define BASEKEY(name) name
#define BASECOMPARE(name) Node::name
#define BASELIST DListMel< Node, AvliNode<Node> >
#define AVLMEL_TEMPDEF class Node, class Key 
#define AVLMEL_TEMPUSE Node, Key
#define AvlTree AvliTree
#define WALKABLE

#include "avlcommon.h"

#undef BASENODE
#undef BASEKEY
#undef BASECOMPARE
#undef BASELIST
#undef AVLMEL_TEMPDEF
#undef AVLMEL_TEMPUSE
#undef AvlTree
#undef WALKABLE

#endif /* _AAPL_AVLITREE_H */

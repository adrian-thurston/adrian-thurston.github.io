/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_DEQUE_H
#define _AAPL_DEQUE_H

#include "dlist.h"

namespace Aapl {

/**
 * \brief A chunk of data in a queue
 */
template <class T> struct DequeChunk : public DListEl< DequeChunk<T> >
{
	DequeChunk(int len);
	~DequeChunk();

	T *data;
};

template <class T> DequeChunk<T>::DequeChunk(int len)
{
	/* Allocate storage for the chunk. */
	data = (T*) malloc( sizeof(T) * len );
}

template <class T> DequeChunk<T>::~DequeChunk()
{
	/* Free the chunk storage. */
	free( data );
}

/**
 * \defgroup deque Double Ended Queue
 * \brief Containers storing data in non-continuous blocks.
 * 
 * @{
 */

/**
 * \class Deque
 * \brief Container storing data in non-continuous blocks.
 *
 * This is a double ended queue which accepts unstructured variable length
 * binary data. Deque is a template class, however it does not yet support
 * classes with non-trivial initialization. Deques are useful for storing
 * large numbers of small elements efficiently. Documentation here is not yet
 * complete.
 */

/*@}*/

/* Deque. */
template <class T> class Deque : public DList< DequeChunk<T> > 
{
public:
	Deque(int chunkLength = 1024);
	~Deque();
	
	void Empty();
	
	/* Appends data to one end of the deque. */
	void append(T *data, int len);
	void prepend(T *data, int len);

	int removeFront(T *buffer, int len);
	int removeEnd(T *buffer, int len);

	int removeFront(int len);
	int removeEnd(int len);

	/* Copies len bytes from the front of the fifo. Does
	 * not remove and data. Returns the amount of data copied. */
	int peekFront(T *buffer, int len);
	int peekEnd(T *buffer, int len);

	int SizeLeftChunk();
	int SizeRightChunk();
	T *PtrLeftChunk();
	T *PtrRightChunk();

	DequeChunk<T> *NewChunk();
	void SpareAChunk( DequeChunk<T> * chunk );


	int dequeLength;      /* Length of the data in the deque. */
	int chunkLength;      /* The size of allocated chunks. */
	int frontPos, endPos; /* Markers to the front and end of data. */

	DequeChunk<T> *spareChunk;
};

/**
 * Create a Deque, specifying the chunkLength.
 */
template <class T> Deque<T>::Deque(int chunkLength)
{
	chunkLength = chunkLength;
	endPos = frontPos = dequeLength = 0;
	spareChunk = 0;
}

/**
 * Delete the deque and free all memory used for it's contents.
 */
template <class T> Deque<T>::~Deque()
{
	/* FIXME: the dlist element need to be deleted. */
	if ( spareChunk )
		delete spareChunk;
	spareChunk = 0;
}

template <class T> void Deque<T>::Empty()
{
	/* if there is no spare chunk then try to keep one. */
	if ( spareChunk == 0 && listLength > 0 )
		spareChunk = DList< DequeChunk<T> >::detachFirst();

	DList< DequeChunk<T> >::empty();
	endPos = frontPos = dequeLength = 0;
}

template <class T> DequeChunk<T> *Deque<T>::NewChunk()
{
	DequeChunk<T> *newChunk;

	if ( spareChunk == 0 )
		newChunk = new DequeChunk<T>( chunkLength );
	else
	{
		newChunk = spareChunk;
		spareChunk = 0;
	}

	return newChunk;
}

template <class T> void Deque<T>::SpareAChunk( DequeChunk<T> *chunk )
{
	if ( spareChunk == 0 )
		spareChunk = chunk;
	else
		delete chunk;
}

template <class T> int Deque<T>::SizeLeftChunk()
{
	int retVal;
	switch ( listLength ) {
	case 0:
		retVal = 0;
		break;

	case 1:
		retVal = endPos - frontPos;
		break;

	default:
		retVal = chunkLength - frontPos;
		break;
	}
	return retVal;
}

template <class T> int Deque<T>::SizeRightChunk()
{
	int retVal;
	switch ( listLength ) {
	case 0:
		retVal = 0;
		break;

	case 1:
		retVal = endPos - frontPos;
		break;

	default:
		retVal = endPos;
		break;
	}
	return retVal;
}

template <class T> T *Deque<T>::PtrLeftChunk()
{
	if ( listLength == 0 )
		return 0;
	else
		return head->data + frontPos;
}

template <class T> T *Deque<T>::PtrRightChunk()
{
	if ( listLength == 0 )
		return 0;
	else
		return tail->data;
}

template <class T> void Deque<T>::prepend(T *data, int len)
{
	int lenAvail;

	/* Ensure we are trying to prepend something. */
	if ( len <= 0 || data == 0)
		return;

	/* We will never fail on this function (assuming we can
	 * allocate space for another chunk). */
	dequeLength += len;

	/* The source data. */
	T *src = (T*) data + len;

	/* What can we fit in the end chunk? */
	if ( listLength == 0 )
	{
		lenAvail = 0;

		/* endPos and frontPos are currently Undefined. Set
		 * them here. */
		frontPos = endPos = chunkLength;
	}
	else
		lenAvail = frontPos;
	
	if (len <= lenAvail)
	{
		/* We can fit the rest of the source into the 
		 * current chunk. */
		memcpy(head->data + frontPos - len, src - len, len);
		frontPos -= len;
	}
	else
	{
		/* We need to stuff the source into more than one chunk.
		 * Max out the current chunk. */
		if (lenAvail > 0)
		{
			/* Fill the cur chunk. */
			memcpy( head->data, src - lenAvail, lenAvail );
			src -= lenAvail;
			len -= lenAvail;
		}
		
		/* Create a new chunk. */
		DList< DequeChunk<T> >::prepend( NewChunk() );

		/* While we need all the space in this chunk and more. */
		while (len > chunkLength)
		{
			/* Fill the cur chunk. */
			memcpy( head->data, src - chunkLength, chunkLength );
			src -= chunkLength;
			len -= chunkLength;
	
			/* Create a new chunk. */
			DList< DequeChunk<T> >::prepend( NewChunk() );
		}

		/* We won't overflow this chunk. */
		memcpy(head->data + chunkLength - len, src - len, len);
		frontPos = chunkLength - len;
	}

	return;
}

template <class T> void Deque<T>::append(T *data, int len)
{
	int lenAvail;

	/* Ensure we are trying to append something. */
	if ( len <= 0 || data == 0)
		return;

	/* We will never fail on this function (assuming we can
	 * allocate space for another chunk). */
	dequeLength += len;

	/* The source data. */
	T *src = (T*) data;

	/* What can we fit in the end chunk? */
	if ( listLength == 0 )
	{
		lenAvail = 0;

		/* endPos and frontPos are currently Undefined. Set
		 * them here. */
		frontPos = endPos = 0;
	}
	else
		lenAvail = chunkLength - endPos;
	
	if (len <= lenAvail)
	{
		/* We can fit the rest of the source into the 
		 * current chunk. */
		memcpy(tail->data + endPos, src, len);
		endPos += len;
	}
	else
	{
		/* We need to stuff the source into more than one chunk.
		 * Max out the current chunk. */
		if (lenAvail > 0)
		{
			/* Fill the cur chunk. */
			memcpy(tail->data + endPos, src, lenAvail);
			len -= lenAvail;
			src += lenAvail;
		}
		
		/* Create a new chunk. */
		DList< DequeChunk<T> >::append( NewChunk() );

		/* While we need all the space in this chunk and more. */
		while (len > chunkLength)
		{
			/* Fill the cur chunk. */
			memcpy(tail->data, src, chunkLength);
			len -= chunkLength;
			src += chunkLength;
	
			/* Create a new chunk. */
			DList< DequeChunk<T> >::append( NewChunk() );
		}

		/* We won't overflow this chunk. */
		memcpy(tail->data, src, len);
		endPos = len;
	}

	return;
}

template <class T> int Deque<T>::peekFront(T *buffer, int len)
{
	DequeChunk<T> *chunk;
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	T *dst;             /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > dequeLength)
		len = dequeLength;

	/* Ensure we are trying to peek something. */
	if (len <= 0)
		return 0;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the first chunk.
	 * We assert that this value is always >= 1. */
	if ( listLength == 1 )
		len_in_chunk = endPos - frontPos;
	else
		len_in_chunk = chunkLength - frontPos;

	/* If we only need data from the first chunk get it and return. */
	if (len <= len_in_chunk)
		memcpy(buffer, head->data + frontPos, len);
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		chunk = head;
		dst = (T*) buffer;
		
		/* Copy what we can get from the first chunk. */
		memcpy(dst, chunk->data + frontPos, len_in_chunk);
		chunk = chunk->next;
		dst += len_in_chunk;
		len -= len_in_chunk;

		/* While we want all the data and more from the head chunk. */
		while (len > chunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst, chunk->data, chunkLength);
			chunk = chunk->next;
			dst += chunkLength;
			len -= chunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst, chunk->data, len);
	}

	return retVal;
}

template <class T> int Deque<T>::peekEnd(T *buffer, int len)
{
	DequeChunk<T> *chunk;
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	T *dst;             /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > dequeLength)
		len = dequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the last chunk.
	 * We assert that this value is always >= 1. */
	if ( listLength == 1 )
		len_in_chunk = endPos - frontPos;
	else
		len_in_chunk = endPos;

	/* If we only need data from the last chunk get it and return. */
	if (len <= len_in_chunk)
		memcpy(buffer, tail->data + endPos - len, len);
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		chunk = tail;
		dst = (T*) buffer + len;
		
		/* Copy what we can get from the last chunk and toast it. */
		memcpy(dst - len_in_chunk, chunk->data, len_in_chunk);
		chunk = chunk->prev;
		dst -= len_in_chunk;
		len -= len_in_chunk;
		
		/* While we want all the data and more from the head chunk. */
		while (len > chunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst - chunkLength, chunk->data, chunkLength);
			chunk = chunk->prev;
			dst -= chunkLength;
			len -= chunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst - len, chunk->data + chunkLength - len, len);
	}

	return retVal;
}


template <class T> int Deque<T>::removeFront(int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */

	/* Restrict the len to the length of the fifo. */
	if (len > dequeLength)
		len = dequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	dequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the first chunk.
	 * We assert that this value is always >= 1. */
	if ( listLength == 1 )
		len_in_chunk = endPos - frontPos;
	else
		len_in_chunk = chunkLength - frontPos;

	/* If we only need data from the first chunk get it and return. */
	if (len <= len_in_chunk)
		frontPos += len;
	else 
	{
		/* We need to traverse at least two chunks.
		 */

		/* Kill what we can get from the first chunk and toast it. */
		len -= len_in_chunk;
		SpareAChunk( detach(head) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > chunkLength )
		{
			/* Get the whole chunk. */
			len -= chunkLength;
			SpareAChunk( detach(head) );
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		frontPos = len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( dequeLength == 0 )
		SpareAChunk( detach(head) );
	/* If the fifo len not zero and there is no data in
	 * the front chunk then move to the next chunk. */
	else if ( frontPos == chunkLength )
	{
		SpareAChunk( detach(head) );
		frontPos = 0;
	}

	return retVal;
}

template <class T> int Deque<T>::removeEnd(int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */

	/* Restrict the len to the length of the fifo. */
	if (len > dequeLength)
		len = dequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	dequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the last chunk.
	 * We assert that this value is always >= 1. */
	if ( listLength == 1 )
		len_in_chunk = endPos - frontPos;
	else
		len_in_chunk = endPos;

	/* If we only need data from the last chunk get it and return. */
	if (len <= len_in_chunk)
		endPos -= len;
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		
		/* Copy what we can get from the last chunk and toast it. */
		len -= len_in_chunk;
		SpareAChunk( detach(tail) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > chunkLength )
		{
			/* Get the whole chunk. */
			len -= chunkLength;
			SpareAChunk( detach(tail) );
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		endPos = chunkLength - len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( dequeLength == 0 )
		SpareAChunk( detach(tail) );
	/* If the fifo len not zero and there is no data in
	 * the end chunk then move to the previous chunk. */
	else if ( endPos == 0 )
	{
		SpareAChunk( detach(tail) );
		endPos = chunkLength;
	}

	return retVal;
}

template <class T> int Deque<T>::removeFront(T *buffer, int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	T *dst;             /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > dequeLength)
		len = dequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	dequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the first chunk.
	 * We assert that this value is always >= 1. */
	if ( listLength == 1 )
		len_in_chunk = endPos - frontPos;
	else
		len_in_chunk = chunkLength - frontPos;

	/* If we only need data from the first chunk get it and return. */
	if (len <= len_in_chunk)
	{
		memcpy(buffer, head->data + frontPos, len);
		frontPos += len;
	}
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		dst = (T*) buffer;
		
		/* Copy what we can get from the first chunk and toast it. */
		memcpy(dst, head->data + frontPos, len_in_chunk);
		dst += len_in_chunk;
		len -= len_in_chunk;
		SpareAChunk( detach(head) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > chunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst, head->data, chunkLength);
			SpareAChunk( detach(head) );
			dst += chunkLength;
			len -= chunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst, head->data, len);
		frontPos = len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( dequeLength == 0 )
		SpareAChunk( detach(head) );
	/* If the fifo len not zero and there is no data in
	 * the front chunk then move to the next chunk. */
	else if ( frontPos == chunkLength )
	{
		SpareAChunk( detach(head) );
		frontPos = 0;
	}

	return retVal;
}

template <class T> int Deque<T>::removeEnd(T *buffer, int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	T *dst;             /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > dequeLength)
		len = dequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	dequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the last chunk.
	 * We assert that this value is always >= 1. */
	if ( listLength == 1 )
		len_in_chunk = endPos - frontPos;
	else
		len_in_chunk = endPos;

	/* If we only need data from the last chunk get it and return. */
	if (len <= len_in_chunk)
	{
		memcpy(buffer, tail->data + endPos - len, len);
		endPos -= len;
	}
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		dst = (T*) buffer + len;
		
		/* Copy what we can get from the last chunk and toast it. */
		memcpy(dst - len_in_chunk, tail->data, len_in_chunk);
		dst -= len_in_chunk;
		len -= len_in_chunk;
		SpareAChunk( detach(tail) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > chunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst - chunkLength, tail->data, chunkLength);
			SpareAChunk( detach(tail) );
			dst -= chunkLength;
			len -= chunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst - len, tail->data + chunkLength - len, len);
		endPos = chunkLength - len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( dequeLength == 0 )
		SpareAChunk( detach(tail) );
	/* If the fifo len not zero and there is no data in
	 * the end chunk then move to the previous chunk. */
	else if ( endPos == 0 )
	{
		SpareAChunk( detach(tail) );
		endPos = chunkLength;
	}

	return retVal;
}

/* namespace Aapl */
}

#endif /* _AAPL_DEQUE_H */


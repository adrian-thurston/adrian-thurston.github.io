/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMMACH_H
#define _RLFSM_FSMMACH_H

#include <assert.h>
#include "vector.h"
#include "compare.h"
#include "bstmap.h"

using namespace Aapl;

#define STATE_NO_STATE  -1
#define FUNC_NO_FUNC    -1
#define TRANS_ERR_TRANS  0

struct FsmMachState;

/***********************************************************************
 * class FsmMachTrans
 */
struct FsmMachTrans
{
	/* State the transition goes to. */
	int toState;

	/* Functions on this transition. */
	int funcs;
};

/**********************************************************
 * Compare for machine transitions.
 */
struct FsmMachTransCompare
{
	static inline int Compare(const FsmMachTrans &t1,
			const FsmMachTrans &t2);
};

/***********************************************************************
 * class FsmMachState
 */
struct FsmMachState
{
	~FsmMachState();

	/* Indexes into the transitions for this state. */
	int *transIndKey;
	int *transIndPtr;
	int numIndex;

	/* Default index if a key is not in transIndex. */
	int dflIndex;

	/* Out functions for this state. */
	int outFuncs;

	/* Is the state final. */
	bool isFinState;
};

/***********************************************************************
 * class FsmMachFlatState
 */
struct FsmMachFlatState
{
	~FsmMachFlatState();

	/* Indexs into the transitions for this state. */
	int *transIndex;
	int numIndex;

	/* Bounds of the indicies. */
	int lowIndex;
	int highIndex;

	/* The default index to use if out of the lowIndex, highIndex. */
	int dflIndex;
};

/***********************************************************************
 * class FsmMachFlatState
 */
struct FsmMachSwitchState
{
	/* Map transition indicies to a vector of chars that go 
	 * on that trans. */
	BstMap< int, Vector<int>, CmpOrd<int> > funcMap;

	/* The default index to use if out of the lowIndex, highIndex. */
	int dflIndex;
};

/***********************************************************************
 * class FsmMachine
 */
template <class TransFunc> class FsmMachine
{
public:
	FsmMachine();
	~FsmMachine();

	/* Start state. */
	int startState;

	/* Array of all states. */
	FsmMachState *allStates;
	int numStates;

	/* Array of all transitions. */
	FsmMachTrans *allTrans;
	int numTrans;

	/* Array of all transition functions. */
	TransFunc *allTransFuncs;
	int numTransFuncs;

	/* Indicies and lengths into the transitions 
	 * funcs giving groups of funcs to execute. */
	int *transFuncIndex;
	int numTransFuncIndex;

	/* Count the number of indicies across the whole machine. */
	int numIndicies();

	/* Make an fsm state where the transition indicies are one flat
	 * array. */
	void makeFlatState( FsmMachFlatState &dest, const FsmMachState &src, 
			bool allocIndicies );

	/* Make an fsm state that is designed for a switch statement. Characters that
	 * use the same transition are chunked together. */
	void makeSwitchState( FsmMachSwitchState &dest, const FsmMachState &src );
};

/* Free inidicies. */
inline FsmMachState::~FsmMachState()
{
	if ( transIndPtr != NULL )
		delete[] transIndPtr;
	if ( transIndKey != NULL )
		delete[] transIndKey;
}

/* Free indicies. */
inline FsmMachFlatState::~FsmMachFlatState()
{
	if ( transIndex != NULL )
		delete[] transIndex;
}

/* Inline compare of transistions. */
inline int FsmMachTransCompare::Compare(const FsmMachTrans &t1,
			const FsmMachTrans &t2)
{
	if ( t1.toState < t2.toState )
		return -1;
	else if ( t1.toState > t2.toState )
		return 1;
	else {
		if ( t1.funcs < t2.funcs )
			return -1;
		else if ( t1.funcs > t2.funcs )
			return 1;
		else
			return 0;
	}
}

/* Construct an empty machine. */
template <class TransFunc> FsmMachine<TransFunc>::FsmMachine()
{
	startState = -1;
	allStates = NULL;
	numStates = 0;
	allTrans = NULL;
	numTrans = 0;

	allTransFuncs = NULL;
	numTransFuncs = 0;

	transFuncIndex = NULL;
	numTransFuncIndex = 0;
}

/* Delete all memory used by the machine. */
template <class TransFunc> FsmMachine<TransFunc>::
		~FsmMachine()
{
	if ( allStates != NULL )
		delete[] allStates;
	if ( allTrans != NULL )
		delete[] allTrans;
	if ( allTransFuncs != NULL )
		delete[] allTransFuncs;
	if ( transFuncIndex != NULL )
		delete[] transFuncIndex;
}

/* Count the number of indicies across the whole machine. */
template <class TransFunc> int FsmMachine<TransFunc>::numIndicies()
{
	int sum = 0;
	for ( int state = 0; state < numStates; state++ )
		sum += allStates[state].numIndex;
	return sum;
}

/**
 * Make an fsm state where the transition indicies are one flat array.
 * bool allocIndicies controls whether or not the indicy array is made.
 */
template <class TransFunc> void FsmMachine<TransFunc>::
		makeFlatState( FsmMachFlatState &dest, const FsmMachState &src,
			bool allocIndicies )
{
	/* This may not be made, so init it null. */
	dest.transIndex = NULL;

	/* If there are no transitions, then our work is not hard. */
	if ( src.numIndex == 0 ) {
		dest.highIndex = 0;
		dest.lowIndex = 0;
		dest.transIndex = NULL;
		dest.numIndex = 0;
		dest.dflIndex = 0;
		return;
	}

	/* Get high index and low index. */
	dest.lowIndex = src.transIndKey[0];
	dest.highIndex = src.transIndKey[src.numIndex-1] + 1;

	/* No default index, goes to error trans, which is index 0. */
	dest.dflIndex = src.dflIndex;

	/* The index array is high minus low long. */
	dest.numIndex = dest.highIndex - dest.lowIndex;

	if ( allocIndicies ) {
		dest.transIndex = new int[dest.numIndex];

		/* We can toss only a few transitions. */
		for ( int orig = 0,               /* loops src indicies */
				aInd = dest.lowIndex;     /* loops alphabet indicies. */
				orig < src.numIndex; orig++, aInd++ ) {
			/* Fill in gaps with the default transition. */
			while ( aInd < src.transIndKey[orig] ) {
				dest.transIndex[aInd - dest.lowIndex] = dest.dflIndex;
				aInd += 1;
			}
				
			/* Copy the trans index. */
			dest.transIndex[aInd - dest.lowIndex] = src.transIndPtr[orig];
		}
	}
}

/**
 * Make an fsm state that is designed for a switch statement. Characters that
 * use the same transition are chunked together.
 */
template < class TransFunc > void FsmMachine<TransFunc>::
		makeSwitchState( FsmMachSwitchState &dest, const FsmMachState &src )
{
	int *key = src.transIndKey;
	int *trans = src.transIndPtr;

	/* Build a mapping of transitions to chars on those transitions. */
	for ( int j = 0; j < src.numIndex; j++, key++, trans++) {
		/* Try to insert the pointer to the transition. We use
		 * lastfound so we don't care if it fails or not. We are
		 * just interested in the Vector<int> at the trans ptr. */
		BstMapEl< int, Vector<int> > *lastFound;
		dest.funcMap.insert( *trans, &lastFound );
			
		/* Now append the char for this transition to the vector. */
		Vector<int> &charVec = lastFound->value;
		charVec.append( *key );
	}

	/* We cannot pick a default index, the error trans is 
	 * used as the default. */
	dest.dflIndex = src.dflIndex;
}


#endif /* _RLFSM_FSMMACH_H */

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMATTACH_CPP
#define _RLFSM_FSMATTACH_CPP

#include <string.h>
#include <assert.h>

/**
 * Insert a transition into an inlist. The head must be supplied. Also sets
 * fromState and toState.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AttachTrans( State *from, State *to, Transition *&head, Transition *trans )
{
	/* Set the data of the transtion. */
	trans->fromState = from;
	trans->toState = to;

	trans->next = head;
	trans->prev = 0;

	/* If in trans list is not empty, set the head->prev to trans. */
	if ( head )
		head->prev = trans;

	/* Now insert ourselves at the front of the list. */
	head = trans;
};

/**
 * Detach a transition from an inlist. The head of the inlist must be supplied.
 * Also reset the transitions's fromState and toState pointers.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		DetachTrans(State *from, State *to, Transition *&head, Transition *trans)
{
	/* Detach in the inTransList. */
	if (trans->prev == 0) 
		head = trans->next; 
	else
		trans->prev->next = trans->next; 

	if (trans->next != 0) 
		trans->next->prev = trans->prev; 
	
	trans->fromState = 0;
	trans->toState = 0;
}

/**
 * Attach states on the default transition, range list or on out/in list key.
 * Type of attaching and the onChar used is controlled by keyType. First makes
 * a new transition. If there is already a transition out from fromState on the
 * default, then will assertion fail.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		AttachStates( State *from, State *to, FsmKeyType keyType, 
			int onChar1, int onChar2 )
{
	/* Make the new transition. */
	Transition *retVal = new Transition();

	switch ( keyType ) {
	case KeyTypeSingle: {
		TransEl *outTel, *inTel;

		/* Make a ptr for the new transition. If one is there already, then
		 * assertion fail. */
		outTel = from->outList.insert( onChar1 );
		assert( outTel != NULL );

		/* Attach using the new transition. Create a new in trans pointer if it
		 * is not there already. */
		outTel->value = retVal;
		to->inList.insert( onChar1, 0, &inTel );

		/* Attach using the inList pointer as the head pointer. */
		AttachTrans( from, to, inTel->value, retVal );
		break;
	}
	case KeyTypeRange: {
		TransEl *outTel1, *outTel2, *inTel;

		/* Make the out ptrs for the new transition. If either are there
		 * already or outTel1 is not immediately before outTel2 then assertion
		 * fail on the grounds of overlap. */
		outTel1 = from->outRange.insert( onChar1 );
		outTel2 = from->outRange.insert( onChar2 );
		assert( outTel1 != NULL && outTel2 != NULL );
		assert( outTel1+1 == outTel2 );

		/* Attach using the new transition. Both low and high get the same ptr. */
		outTel1->value = retVal;
		outTel2->value = retVal;

		/* Create a new in trans pointer if it is not there already. Note that
		 * we use the lower onChar as the key. */
		to->inRange.insert( onChar1, 0, &inTel );

		/* Attach using the inRange pointer as the head pointer. */
		AttachTrans( from, to, inTel->value, retVal );
		break;
	}
	case KeyTypeDefault: {
		/* If there is already a default, then assertion fail. */
		assert( from->defOutTrans == NULL );

		/* Attach using the new transition and defInTrans as the head. */
		from->defOutTrans = retVal;
		AttachTrans( from, to, to->defInTrans, retVal );
		break;
	}}

	return retVal;
}

/**
 * Attach for out/in lists, range lists or for default transition. Type of
 * attaching is controlled by the keyType parameter.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AttachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, int onChar )
{
 	/* Ensure the transition is unused. */
	assert( trans->toState == NULL );
	assert( trans->fromState == NULL );

	switch ( keyType ) {
	case KeyTypeSingle: {
		/* Create a new in trans pointer if it is not there. */
		TransEl *inTransEl;
		to->inList.insert( onChar, 0, &inTransEl );

		/* Attach using the inList pointer as the head pointer. */
		AttachTrans( from, to, inTransEl->value, trans );
		break;
	}
	case KeyTypeRange: {
		/* Create a new in trans pointer if it is not there already. Note that
		 * onChar is interpreted as the lower. */
		TransEl *inTel;
		to->inRange.insert( onChar, 0, &inTel );

		/* Attach using the inRange pointer as the head pointer. */
		AttachTrans( from, to, inTel->value, trans );
		break;
	}
	case KeyTypeDefault: {
		/* Attach using to->defInTrans as the head. */
		AttachTrans( from, to, to->defInTrans, trans );
		break;
	}}
}

/**
 * Detach for out/in lists or for default transition. The type of detaching is
 * controlled by the keyType parameter.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		DetachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, int onChar )
{
	/* Ensure they are hooked up. */
	assert( trans->toState == to );
	assert( trans->fromState == from );

	switch ( keyType ) {
	case KeyTypeSingle: {
		/* Get a reference to the head pointer in the inList for onChar. */
		TransEl *inTel = to->inList.find( onChar );
		assert( inTel != NULL );

		/* Detach using to's in list pointer as the head. */
		DetachTrans( from, to, inTel->value, trans );
		break;
	}
	case KeyTypeRange: {
		/* Get a reference to the head pointer in the inRange for onChar. Note
		 * onChar is interpreted as the lower onChar of the range. */
		TransEl *inTel = to->inRange.find( onChar );
		assert( inTel != NULL );

		/* Detach using to's in range pointer as the head. */
		DetachTrans( from, to, inTel->value, trans );
		break;
	}
	case KeyTypeDefault: {
		/* Detach using the to->defInTrans pointer as the head. */
		DetachTrans( from, to, to->defInTrans, trans );
		break;
	}}
}


/**
 * Detach a state from the graph. Detaches and deletes transitions in and out
 * of the state. Empties inList and outList. Removes the state from the final
 * state set. A detached state becomes useless and should be deleted.
 */
template < class State, class TransFunc, class Transition >
		State *FsmGraph<State, TransFunc, Transition>::
		DetachState( State *state )
{
	/* Detach the in transitions from the inList. */
	TransEl *tel = state->inList.table;
	int i, ntel = state->inList.tableLength;
	for ( i = 0; i < ntel; i++, tel++ ) {
		while ( tel->value ) {
			/* Get pointers to the trans and the state. */
			Transition *trans = tel->value;
			State *fromState = trans->fromState;

			/* Detach. */
			DetachStates( fromState, state, trans, KeyTypeSingle, tel->key );

			/* Search for a range in from list that this key is in. */
			TransEl *rangeEl = fromState->outRange.findRange( tel->key );

			/* If the key is in a range of from or if from has a default
			 * transition we cannont delete the key-value pair from it's out
			 * list because that effectively adds the key to the set of keys
			 * following the range or the default trans. Instead null out the
			 * transition pointer. */
			if ( rangeEl != NULL || fromState->defOutTrans != NULL ) {
				/* From has a default transition, we must null out the trans ptr. */
				TransEl *fromTel = fromState->outList.find( tel->key );
				fromTel->value = NULL;
			}
			else {
				/* There is no default trans, safe to remove the key-value pair. */
				fromState->outList.remove( tel->key );
			}

			/* Finished with the transition. */
			delete trans;
		}
	}

	/* Delete all of the in transition pointers. */
	state->inList.empty();

	/* Detach the in transitions from the inRange. */
	tel = state->inRange.table;
	ntel = state->inRange.tableLength;
	for ( i = 0; i < ntel; i++, tel++ ) {
		while ( tel->value ) {
			/* Get pointers to the trans and the state. */
			Transition *trans = tel->value;
			State *fromState = trans->fromState;

			/* Detach. */
			DetachStates( fromState, state, trans, KeyTypeRange, tel->key );

			/* If from has a default transition we cannot delete the key-value
			 * pair from it's out range because that effectively adds the keys to
			 * the set of keys following the default trans.  Instead null out
			 * the transition pointer. */
			if ( fromState->defOutTrans != NULL ) {
				/* From has a default transition, we must null out the trans ptr. */
				TransEl *fromTel = fromState->outRange.find( tel->key );
				fromTel[0].value = NULL;
				fromTel[1].value = NULL;
			}
			else {
				/* There is no default trans, safe to remove the range. */
				TransEl *fromTel = fromState->outRange.find( tel->key );
				assert( fromTel != NULL );

				/* Remove two items at pos fromTel. Uses Vector::remove. */
				int pos = fromTel - fromState->outRange.table;
				fromState->outRange.TransListVect::remove( pos, 2 );
			}

			/* Finished with the transition. */
			delete trans;
		}
	}

	/* Delete all of the in range pointers. */
	state->inRange.empty();

	/* Detach default in transitions. */
	while ( state->defInTrans ) {
		/* Get pointers to the trans and the state. */
		Transition *trans = state->defInTrans;
		State *fromState = trans->fromState;

		/* Detach. */
		DetachStates( fromState, state, trans, KeyTypeDefault, 0 );

		/* From state no longer has a default trans, null it out. */
		fromState->defOutTrans = NULL;

		/* Finsished with the trans. */
		delete trans;
	}

	/* Detach the out transitions. */
	tel = state->outList.table;
	ntel = state->outList.tableLength;
	for ( i = 0; i < ntel; i++, tel++ ) {
		if ( tel->value != NULL ) {
			DetachStates( state, tel->value->toState, tel->value, 
					KeyTypeSingle, tel->key );
			delete tel->value;
		}
	}

	/* Delete all of the out transition pointers. */
	state->outList.empty();

	/* Detach out range transitions. */
	tel = state->outRange.table;
	ntel = state->outRange.tableLength;
	for ( i = 0; i < ntel; i+=2, tel+=2 ) {
		if ( tel->value != NULL ) {
			DetachStates( state, tel->value->toState, tel->value,
					KeyTypeRange, tel->key );
			delete tel->value;
		}
	}

	/* Delete all of the out transition pointers. */
	state->outRange.empty();

	/* Detach the default out transition. */
	if ( state->defOutTrans != NULL ) {
		DetachStates( state, state->defOutTrans->toState, state->defOutTrans, 
				KeyTypeDefault, 0 );
		delete state->defOutTrans;
	}

	/* Unset final stateness before detaching from graph. */
	if ( state->isFinState )
		finStateSet.unSet( state );

	stateList.detach( state );
	return state;
}


/**
 * Duplicate a transition. Makes a new transition that is attached to the same
 * dest as srcTrans. The new transition has functions and priority taken from
 * srcTrans. If leavingFsm is set, then outPrior and outFuncs are taken from
 * the from state. Used for merging a transition in to a free spot. The trans
 * can just be dropped in. It does not conflict with an existing trans and need
 * not be crossed. Returns the new transition.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		DupTrans( State *from, FsmKeyType keyType, int onChar,
			Transition *srcTrans, bool leavingFsm )
{
	/* Compute the new transtions's priority. It default's to the srcTrans'
	 * priority. But if from has its outPriority set then use that instead. */
	int newTransPrior = srcTrans->priority;
	if ( leavingFsm && from->isOutPriorSet )
		newTransPrior = from->outPriority;

	/* Make a new transition. */
	Transition *newTrans = new Transition();

	/* We can attach the transition, one does not exist. */
	AttachStates( from, srcTrans->toState, newTrans, keyType, onChar );
		
	/* Copy the transition data from the source transition. */
	newTrans->priority = newTransPrior;
	newTrans->transFuncTable.setAs( srcTrans->transFuncTable );

	/* Call user routine for merging transitions. */
	newTrans->MergeTransition(srcTrans);

	/* Now that the transition has been properly set up, we can add any out
	 * transition data if necessary. */
	if ( leavingFsm ) {
		/* Get the data from the outTransFuncTable. */
		newTrans->SetFunctions( from->outTransFuncTable );
	}

	return newTrans;
}


/**
 * In crossing, src trans overwrites the existing one because it has a
 * higher priority. The existing destTrans is deleted and replaced with
 * a copy of srcTrans.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		OverwriteTrans( MergeData &md, State *from, FsmKeyType keyType, int onChar,
			Transition *destTrans, Transition *srcTrans,
			int newTransPrior, bool leavingFsm )
{
	/* Toast the existing transition. */
	DetachStates( from, destTrans->toState, destTrans, keyType, onChar );

	/* Delete the existing transition, it is being replaced and 
	 * make a brand new one to replace it. This is for completeness 
	 * of concept. */
	delete destTrans;
	Transition *newTrans = new Transition();

	/* We can attach the transition, one does not exist. */
	AttachStates( from, srcTrans->toState, newTrans, keyType, onChar );

	/* Copy the transition data from the source transition. */
	newTrans->priority = newTransPrior;
	newTrans->transFuncTable.setAs( srcTrans->transFuncTable );

	/* Trans is a merge with srcTrans. */
	newTrans->MergeTransition(srcTrans);

	/* Now that the transition has been properly set up, we can add any out
	 * transition data if necessary. */
	if ( leavingFsm ) {
		/* Get the data from the outTransFuncTable. */
		newTrans->SetFunctions( from->outTransFuncTable );
	}

	return newTrans;
}

/** 
 * In crossing, src trans and dest trans go to two different states. Make one
 * state from the sets of states that src and dest trans go to.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		FsmAttachStates( MergeData &md, State *from, FsmKeyType keyType, int onChar,
			Transition *destTrans, Transition *srcTrans, int newTransPrior, 
			bool leavingFsm )
{
	/* The priorities are equal. We must merge the transitions.
	 * Does the existing trans go to the state we are to attach to?
	 * ie, are we to simply double up the transition? */
	State *toState = srcTrans->toState;
	State *existingState = destTrans->toState;

	if ( existingState == toState ) {
		/* The transition is a double up to the same state. Copy the transition
		 * data from the source transition. */
		if ( destTrans == srcTrans ) {
			typename Transition::TransFuncTable
						srcTable( srcTrans->transFuncTable );
			destTrans->SetFunctions( srcTable );
		}
		else
			destTrans->SetFunctions( srcTrans->transFuncTable );

		/* Call user routine for merging transitions. */
		destTrans->MergeTransition(srcTrans);
	}
	else {
		/* The trans is not a double up. Dest trans cannot be the same as src
		 * trans. Set up the state set. */
		StateSet stateSet;

		/* We go to all the states the existing trans goes to, plus... */
		if ( existingState->stateDictNode == NULL )
			stateSet.set( existingState );
		else
			stateSet.set( existingState->stateDictNode->stateSet );
		/* ... all the states that we have been told to go to. */
		if ( toState->stateDictNode == NULL )
			stateSet.set( toState );
		else
			stateSet.set( toState->stateDictNode->stateSet );

		/* Look for the state. If it is not there already, make it. */
		FsmSDNode<State> *lastFound;
		if ( md.stateDict.insert( stateSet, &lastFound ) ) {
			/* Make a new State, but it doesn't get added to the list. 
			 * Instead, add it to the stfil list. This means that we
			 * need to fill in it's transitions sometime in the future.
			 * We don't do that now (ie, do not recurse). */
			State *newState = new State();

			/* Link up the dict node and the state. */
			lastFound->targState = newState;
			newState->stateDictNode = lastFound;

			/* Add to the stfil list. */
			md.stfil.append( newState );
		}

		/* Get the state insertted/deleted. */
		State *targ = lastFound->targState;

		/* Detach the state from existing state. */
		DetachStates( from, existingState, destTrans, keyType, onChar );

		/* Re-attach to the new target. */
		AttachStates( from, targ, destTrans, keyType, onChar );

		/* Copy the transition data from the source transition. */
		destTrans->SetFunctions( srcTrans->transFuncTable );

		/* Call user routine for merging transitions. */
		destTrans->MergeTransition(srcTrans);
	}

	/* Now that the transition has been properly set up, we can add any out
	 * transition data if necessary. */
	if ( leavingFsm ) {
		/* Get the data from the outTransFuncTable. */
		destTrans->SetFunctions( from->outTransFuncTable );
	}

	return destTrans;
}

/**
 * Find the trans with the higher priority. If src is lower priority then dest then
 * src is ignored. If src is higher priority than dest, then src overwrites dest. If
 * the priorities are equal, then they are merged.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		CrossTransitions( MergeData &md, State *from, FsmKeyType keyType, int onChar,
			Transition *destTrans, Transition *srcTrans, bool leavingFsm )
{
	Transition *retTrans;

	/* Compute the new transtions's priority. It default's to the srcTrans'
	 * priority. But if from has its outPriority set then use that instead. */
	int newTransPrior = srcTrans->priority;
	if ( leavingFsm && from->isOutPriorSet )
		newTransPrior = from->outPriority;

	if ( destTrans->priority > newTransPrior ) {
		/* The existing trans has a higher priority. We do nothing. No new transition
		 * is made. Return destTrans. */
		retTrans = destTrans;
	}
	else if ( destTrans->priority < newTransPrior ) {
		/* Src trans has a higher priority than dest, src overwrites dest. */
		retTrans = OverwriteTrans( md, from, keyType, onChar, destTrans, 
				srcTrans, newTransPrior, leavingFsm );
	}
	else {
		/* Src trans and dest trans have the same priority, they must be merged. */
		retTrans = FsmAttachStates( md, from, keyType, onChar, destTrans, 
				srcTrans, newTransPrior, leavingFsm );
	}
	return destTrans;
}

/**
 * When copying out transitions, a transition exists only in the dest out list.
 * Since the key is not in src, we must consider a default transition.  Dest
 * may get crossed with it.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		KeyInDestEl( MergeData &md, State *dest, State *src, TransEl *destTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm )
{
	Transition *retTrans = NULL;

	/* Is there a default transition? */
	if ( defTrans != NULL ) {
		/* There is a default, is destTel set? */
		if ( destTel->value != NULL ) {
			/* Cross dest trans with the default from src. */
			retTrans = CrossTransitions( md, dest, keyType, destTel->key, 
					destTel->value, defTrans, leavingFsm );
		}
		else {
			/* Dest trans el is not set, copy the default from src in. */
			retTrans = DupTrans( dest, keyType, destTel->key, defTrans, leavingFsm );
		}
	}
	else {
		/* No default transition from src. Just use what was in dest already. */
		retTrans = destTel->value;		
	}
	return retTrans;
}

/**
 * When copying out transitions, a transition exists only in the src out list.
 * Since the key is not in dest, we must consider a default transition. Src may
 * get crossed with one of those.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		KeyInSrcEl( MergeData &md, State *dest, State *src, TransEl *srcTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm )
{
	Transition *retTrans = NULL;

	if ( defTrans != NULL ) {
		/* Dest has default trans. Src's trans may be crossed with it. */
		if ( srcTel->value != NULL ) {
			/* Cross src trans with the default. First get a copy of the default
			 * to pretend as if it was already in dest on the key. */
			Transition *newTrans = DupTrans( dest, keyType, srcTel->key,
					defTrans, false );
			retTrans = CrossTransitions( md, dest, keyType, srcTel->key,
					newTrans, srcTel->value, leavingFsm );
		}
		else {
			/* Dup dest's default into retTrans. */
			retTrans = DupTrans( dest, keyType, srcTel->key, defTrans, false );
		}
	}
	else {
		/* Dest has no default transition. */
		if ( srcTel->value != NULL ) {
			/* Dup src's trans into the new transition element. */
			retTrans = DupTrans( dest, keyType, srcTel->key, 
					srcTel->value, leavingFsm );
		}
		else {
			/* Src is explicitly off. New transition element must also be off
			 * explicitly. */
			retTrans = NULL;
		}
	}
	return retTrans;
}

/**
 * When copying out transitions, a transition exists (on the same key) in both
 * src and dest. We need to determine if the transitions are explicitly unset.
 * No crossing with any default transition or with range transitions will
 * happen. Note that the default or range are assumed only when there is no key.
 */
template < class State, class TransFunc, class Transition >
		Transition *FsmGraph<State, TransFunc, Transition>::
		KeyInBothEl( MergeData &md, State *dest, State *src, TransEl *destTel,
			TransEl *srcTel, FsmKeyType keyType, bool leavingFsm )
{
	Transition *retTrans = NULL;

	if ( destTel->value != NULL && srcTel->value != NULL ) {
		/* Transitions are set in both, must cross them. */
		retTrans = CrossTransitions( md, dest, keyType, destTel->key,
				destTel->value, srcTel->value, leavingFsm );
	}
	else if ( destTel->value != NULL ) {
		/* Transition is set only in destTel. Continue using destTel. */
		retTrans = destTel->value;
	}
	else if ( srcTel->value != NULL ) {
		/* Transition is set only in srcTel. Dup it. */
		retTrans = DupTrans( dest, keyType, srcTel->key, srcTel->value, leavingFsm );
	}
	else {
		/* Transition is unset in both. Stays unset.  */
		retTrans = NULL;
	}

	return retTrans;
}

/**
 * When copying out ranges, a range exists only in the dest range list. There
 * is no overlap with src. Since the key is not in src's range, we must
 * consider src's default transition. Dest may be crossed with it.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		KeyInDestRangeEl( MergeData &md, State *dest, State *src, 
				TransEl *destTel, bool leavingFsm )
{
	TransEl newTel;

	/* Ranges may get crossed with src's default transition. */
	newTel.value = KeyInDestEl( md, dest, src, destTel, KeyTypeRange, 
			src->defOutTrans, leavingFsm );

	/* Add the new range to the new out range. */
	newTel.key = destTel[0].key;
	dest->outRange.append(newTel);
	newTel.key = destTel[1].key;
	dest->outRange.append(newTel);
}

/**
 * When copying out ranges, a range exists only in the src out range. There is
 * no overlap with dest. Since the key is not in dest, we must consider dest's
 * default transition. Src may get crossed with it. 
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		KeyInSrcRangeEl( MergeData &md, State *dest, State *src, 
				TransEl *srcTel, bool leavingFsm )
{
	TransEl newTel;

	/* Ranges may get crossed with dests's default transition. */
	newTel.value = KeyInSrcEl( md, dest, src, srcTel, KeyTypeRange,
			dest->defOutTrans, leavingFsm );

	/* Add newTel to the new out range. Get the keys from srcTel, easy. */
	newTel.key = srcTel[0].key;
	dest->outRange.append(newTel);
	newTel.key = srcTel[1].key;
	dest->outRange.append(newTel);
}

/**
 * When copying out ranges, two ranges overlap such that endpoints match up
 * exactly.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		KeyRangeExactOverlap( MergeData &md, State *dest, State *src, 
				TransEl *destTel, TransEl *srcTel, bool leavingFsm )
{
	TransEl newTel;

	/* Call worker for transitions in both using range type. */
	newTel.value = KeyInBothEl( md, dest, src, destTel, srcTel, 
			KeyTypeRange, leavingFsm );

	/* Add newTel to the new out range. Get the keys from destTel. Keys could
	 * come from either dest or src. */
	newTel.key = destTel[0].key;
	dest->outRange.append(newTel);
	newTel.key = destTel[1].key;
	dest->outRange.append(newTel);
}


/**
 * When copying out ranges, two ranges overlap in some way. Break the ranges
 * into sub ranges that are either entirely in src, entirely in dest or that
 * overlap with ends matching up.
 *
 * Note that destTel and srcTel are refernce variables because they may need to
 * be modified by this routine.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		KeyRangeOverlap( MergeData &md, State *dest, State *src, 
				TransEl *&destTel, TransEl *&srcTel, bool leavingFsm )
{
	TransEl range[2];

	while ( true ) {
		if ( destTel[0].key < srcTel[0].key ) {
			/* Get a copy of the dest range. */
			range[0] = destTel[0];
			range[1] = destTel[1];

			/* DestTel sticks out front. Break the dest range into non-overlaping 
			 * and overlaping segments. */
			range[1].key = srcTel[0].key - 1;
			destTel[0].key = srcTel[0].key;

			/* The dest trans needs to be copied. The first half of the
			 * broken range gets the original transition. */
			destTel[0].value = destTel[1].value = 
					DupTrans( dest, KeyTypeRange, destTel[0].key, range->value, false );

			/* We have broken the dest segment so that there is a section only in dest. */
			KeyInDestRangeEl( md, dest, src, range, leavingFsm );
		}
		else if ( srcTel[0].key < destTel[0].key ) {
			/* Get a copy of the src range. */
			range[0] = srcTel[0];
			range[1] = srcTel[1];

			/* Src sticks out front. Break the src range into non-overlaping
			 * and overlaping segments. */
			range[1].key = destTel[0].key - 1;
			srcTel[0].key = destTel[0].key;

			/* The temp range can use the same transition as srcTrans. The
			 * segment is now broken so that there is a section only in src. */
			KeyInSrcRangeEl( md, dest, src, range, leavingFsm );
		}
		else {
			/* Low ends are even. Are the high ends even? */
			if ( destTel[1].key < srcTel[1].key ) {
				/* Get a copy of the src range. */
				range[0] = srcTel[0];
				range[1] = srcTel[1];

				/* Dest finishes first, break the src range to get an exact overlap. */
				range[1].key = destTel[1].key;
				srcTel[0].key = destTel[1].key + 1;

				/* The temp range can use the same trans as srcTrans. Process
				 * the faked exact overlap. */
				KeyRangeExactOverlap( md, dest, src, destTel, range, leavingFsm );

				/* Skip over the entire destTel segment, we processed it all. */
				destTel += 2;
			}
			else if ( srcTel[1].key < destTel[1].key ) {
				/* Get a copy of the dest range. */
				range[0] = destTel[0];
				range[1] = destTel[1];

				/* Src finishes first, break the range to get an exact overlap. */
				range[1].key = srcTel[1].key;
				destTel[0].key = srcTel[1].key + 1;

				/* The dest trans needs to be copied. The first half of the
				 * broken range gets the original transition. */
				destTel[0].value = destTel[1].value = 
						DupTrans( dest, KeyTypeRange, destTel[0].key, range->value, false );

				/* Process the faked exact overlap. */
				KeyRangeExactOverlap( md, dest, src, range, srcTel, leavingFsm );

				/* Skip over the entire srcTel segment, we processed it all. */
				srcTel += 2;
			}
			else {
				/* There is an exact overlap. */
				KeyRangeExactOverlap( md, dest, src, destTel, srcTel, leavingFsm );
				destTel += 2;
				srcTel += 2;
			}

			/* Since we have consumed at least one range we must break in case
			 * there are no more ranges in dest or src. */
			break;
		}
	}
}

/**
 * When copying out transitions, a transition exists only in the dest out list.
 * Since the key is not in src, we must consider src's default or range
 * transitions. Dest may get crossed with it.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		KeyInDestTransEl( MergeData &md, State *dest, State *src, 
				TransEl *destTel, bool leavingFsm )
{
	TransEl newTel, *rangeTel;
	Transition *defTrans;

	/* Find a transition to serve as the default. If dest key is in a range in
	 * src, use that range (which may be null), otherwise use src->def. */
	rangeTel = src->outRange.findRange( destTel->key );
	if ( rangeTel != NULL )
		defTrans = rangeTel->value;
	else
		defTrans = src->defOutTrans;

	/* Call worker using above computed default and single key type. */
	newTel.value = KeyInDestEl( md, dest, src, destTel, KeyTypeSingle, 
			defTrans, leavingFsm );

	/* Add newTel to the new out list, get the key from destTel, easy. */
	newTel.key = destTel->key;
	dest->outList.append(newTel);
}

/**
 * When copying out transitions, a transition exists only in the src out list.
 * Since the key is not in dest, we must consider dest's default and range
 * transition. Src may get crossed with one of those.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		KeyInSrcTransEl( MergeData &md, State *dest, State *src, 
				TransEl *srcTel, bool leavingFsm )
{
	TransEl newTel, *rangeTel;
	Transition *defTrans;

	/* Find a transition to serve as the default. If src key is in a range in
	 * dest, use that range (which may be null), otherwise use dest->def. */
	rangeTel = dest->outRange.findRange( srcTel->key );
	if ( rangeTel != NULL )
		defTrans = rangeTel->value;
	else
		defTrans = dest->defOutTrans;

	/* Call worker using above computed default and single key type. */
	newTel.value = KeyInSrcEl( md, dest, src, srcTel, KeyTypeSingle, 
			defTrans, leavingFsm );

	/* Add newTel to the new out list. Get the key from srcTel, easy. */
	newTel.key = srcTel->key;
	dest->outList.append(newTel);
}

/**
 * When copying out transitions, a transition exists (on the same key) in both
 * src and dest.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		KeyInBothTransEl( MergeData &md, State *dest, State *src, 
				TransEl *destTel, TransEl *srcTel, bool leavingFsm )
{
	TransEl newTel;

	/* Call worker for transitions in both using single key type. */
	newTel.value = KeyInBothEl( md, dest, src, destTel, srcTel, 
			KeyTypeSingle, leavingFsm );

	/* Add it to the new out list. Get the key from destTel (could be either). */
	newTel.key = destTel->key;
	dest->outList.append(newTel);
}

/* Copying the default transition. */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		CopyDefTrans( MergeData &md, State *dest, State *src, bool leavingFsm )
{
	if ( dest->defOutTrans != NULL && src->defOutTrans != NULL ) {
		/* Must cross the default out transitions. */
		dest->defOutTrans = CrossTransitions( md, dest, KeyTypeDefault, 0,
					dest->defOutTrans, src->defOutTrans, leavingFsm );
	}
	else if ( src->defOutTrans != NULL ) {
		/* A default trans only in src, copy it to dest. */
		dest->defOutTrans = DupTrans( dest, KeyTypeDefault, 0,
				src->defOutTrans, leavingFsm );
	}
	else {
		/* Leave dest->defOutTrans as is. */
	}
}

/**
 * Copy the transitions src's outRange into dest's out range.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		OutRangeCopy( MergeData &md, State *dest, State *src, bool leavingFsm )
{
	/* Copy dest's list, we need to modify it as we read from it. Dest list
	 * will rebuilt as we scan both src and dest out lists. */
	TransListType destRange(dest->outRange);
	TransListType srcRange(src->outRange);
	dest->outRange.empty();

	/* Pointers used to walk through dest and src concurrently. */
	TransEl *destTel = destRange.table;
	TransEl *destEndTel = destTel + destRange.tableLength;
	TransEl *srcTel = srcRange.table;
	TransEl *srcEndTel = srcTel + srcRange.tableLength;

	/* Concurrently scan both out ranges. */
	while ( true ) {
		if ( destTel == destEndTel ) {
			/* We are at the end of dest's ranges. Process the rest of
			 * src's ranges. */
			while ( srcTel != srcEndTel ) {
				KeyInSrcRangeEl( md, dest, src, srcTel, leavingFsm );
				srcTel+=2;
			}
			break;
		}
		else if ( srcTel == srcEndTel ) {
			/* We are at the end of src's ranges. Process the rest of
			 * dest's ranges. */
			while ( destTel != destEndTel ) {
				KeyInDestRangeEl( md, dest, src, destTel, leavingFsm );
				destTel+=2;
			}
			break;
		}
		else {
			/* The signiture of no overlap is a back key being in front of a
			 * front key. */
			if ( destTel[1].key < srcTel[0].key ) {
				/* A range exists in dest that does not overlap with src. */
				KeyInDestRangeEl( md, dest, src, destTel, leavingFsm );
				destTel+=2;
			}
			else if ( srcTel[1].key < destTel[0].key ) {
				/* A trans exists in src on srcKey but not in dest on srcKey. */
				KeyInSrcRangeEl( md, dest, src, srcTel, leavingFsm );
				srcTel+=2;
			}
			else {
				/* There is overlap, must mix src and dest ranges. */
				KeyRangeOverlap( md, dest, src, destTel, srcTel, leavingFsm );
			}
		}
	}
}

/**
 * Copy the transitions in srcList to the outlist of dest. If srcList comes from
 * a final state and out transitions should be copied in then leavingFsm can be
 * set true. SrcList should not be the outList of dest, otherwise you would
 * be copying the contents of srcList into itself as it's iterated: bad news.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		OutTransCopy2( MergeData &md, State *dest, State *src, bool leavingFsm )
{
	/* For making ing destination lists. */
	TransEl newTel;

	/* The destination lists. */
	TransListType destList, destRange;

	FsmPairIterator<State, Transition> outPair(dest, src, true);
	while ( ! outPair.atEnd() ) {
		switch ( outPair.userState ) {

		case PairIterator::TransInS1:
			/* Call worker using above computed default and single key type. */
			newTel.value = KeyInDestEl( md, dest, src, outPair.s1Tel, 
					KeyTypeSingle, outPair.defTrans, leavingFsm );

			/* Add newTel to the new out list, get the key from s1Tel. */
			newTel.key = outPair.s1Tel->key;
			destList.append( newTel );
			break;

		case PairIterator::TransInS2:
			/* Call worker using above computed default and single key type. */
			newTel.value = KeyInSrcEl( md, dest, src, outPair.s2Tel, 
					KeyTypeSingle, outPair.defTrans, leavingFsm );

			/* Add newTel to the new out list. Get the key from srcTel, easy. */
			newTel.key = outPair.s2Tel->key;
			destList.append( newTel );
			break;

		case PairIterator::TransOverlap:
			/* Call worker for transitions in both using single key type. */
			newTel.value = KeyInBothEl( md, dest, src, outPair.s1Tel, 
					outPair.s2Tel, KeyTypeSingle, leavingFsm );

			/* Add it to the new out list. Get the key from destTel 
			 * (could be either). */
			newTel.key = outPair.s1Tel->key;
			destList.append( newTel );
			break;

		case PairIterator::RangeInS1:
			/* Ranges may get crossed with src's default transition. */
			newTel.value = KeyInDestEl( md, dest, src, outPair.s1Tel,
					KeyTypeRange, outPair.defTrans, leavingFsm );

			/* Add the new range to the new out range. */
			newTel.key = outPair.s1Tel[0].key;
			destRange.append( newTel );
			newTel.key = outPair.s1Tel[1].key;
			destRange.append( newTel );
			break;

		case PairIterator::RangeInS2:
			/* Ranges may get crossed with dests's default transition. */
			newTel.value = KeyInSrcEl( md, dest, src, outPair.s2Tel, 
					KeyTypeRange, outPair.defTrans, leavingFsm );

			/* Add newTel to the new out range. Get the keys from srcTel, easy. */
			newTel.key = outPair.s2Tel[0].key;
			destRange.append( newTel );
			newTel.key = outPair.s2Tel[1].key;
			destRange.append( newTel );
			break;

		case PairIterator::RangeOverlap:
			/* Call worker for transitions in both using range type. */
			newTel.value = KeyInBothEl( md, dest, src, outPair.s1Tel, 
					outPair.s2Tel, KeyTypeRange, leavingFsm );

			/* Add newTel to the new out range. Get the keys from destTel. Keys could
			 * come from either dest or src. */
			newTel.key = outPair.s1Tel[0].key;
			destRange.append( newTel );
			newTel.key = outPair.s1Tel[1].key;
			destRange.append( newTel );
			break;

		case PairIterator::BreakS1:
			/* The dest trans needs to be copied. The copy goes into the first have
			 * of the break because that is the only value we have access to. */
			outPair.s1Tel[0].value = outPair.s1Tel[1].value = 
					DupTrans( dest, KeyTypeRange, outPair.s1Tel[0].key, 
					outPair.s1Tel[0].value, false );
			break;

		case PairIterator::BreakS2:
			/* We do not care about duplicating transitions from src. They are 
			 * merely sourced so do not need to be duplicated to protected 
			 * against writing twice. */
			break;
		}
		outPair++;
	}

	/* Last thing to do is copy default transitions. */
	CopyDefTrans( md, dest, src, leavingFsm );

	/* Transfer destList into dest->outList. */
	dest->outList.empty();
	dest->outList.shallowCopy( destList );
	destList.abandon();

	/* Transfer destRange into dest->outRange. */
	dest->outRange.empty();
	dest->outRange.shallowCopy( destRange );
	destRange.abandon();
}


/**
 * Copy the transitions in srcList to the outlist of dest. If srcList comes from
 * a final state and out transitions should be copied in then leavingFsm can be
 * set true. SrcList should not be the outList of dest, otherwise you would
 * be copying the contents of srcList into itself as it's iterated: bad news.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		OutTransCopy( MergeData &md, State *dest, State *src, bool leavingFsm )
{
	/* Copy dest's list, we need to modify it as we read from it. Dest list
	 * will rebuilt as we scan both src and dest out lists. */
	TransListType destList(dest->outList);
	dest->outList.empty();

	/* Pointers used to walk through dest and src concurrently. */
	TransEl *destTel = destList.table;
	TransEl *destEndTel = destTel + destList.tableLength;
	TransEl *srcTel = src->outList.table;
	TransEl *srcEndTel = srcTel + src->outList.tableLength;

	/* Concurrently scan both out lists. */
	while ( true ) {
		if ( destTel == destEndTel ) {
			/* We are at the end of dest's transitions. Process the rest of
			 * src's transitions. */
			while ( srcTel != srcEndTel ) {
				KeyInSrcTransEl( md, dest, src, srcTel, leavingFsm );
				srcTel++;
			}
			break;
		}
		else if ( srcTel == srcEndTel ) {
			/* We are at the end of src's transitions. Process the rest of
			 * dest's transitions. */
			while ( destTel != destEndTel ) {
				KeyInDestTransEl( md, dest, src, destTel, leavingFsm );
				destTel++;
			}
			break;
		}
		else {
			/* Both dest and src tels are good. Get the characters of the trans. */
			int destKey = destTel->key;
			int srcKey = srcTel->key;
			if ( destKey < srcKey ) {
				/* A trans exists in dest on destKey but not in src on destKey. */
				KeyInDestTransEl( md, dest, src, destTel, leavingFsm );
				destTel++;
			}
			else if ( destKey > srcKey ) {
				/* A trans exists in src on srcKey but not in dest on srcKey. */
				KeyInSrcTransEl( md, dest, src, srcTel, leavingFsm );
				srcTel++;
			}
			else {
				/* Keys match up. Trans on the same char. */
				KeyInBothTransEl( md, dest, src, destTel, srcTel, leavingFsm );
				destTel++;
				srcTel++; 
			}
		}
	}

	/* Copy the out ranges. */
	OutRangeCopy( md, dest, src, leavingFsm );

	/* Last thing to do is copy default transitions. */
	CopyDefTrans( md, dest, src, leavingFsm );
}

/**
 * Move all the transitions that go into src so that they go into dest.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		InTransMove(State *dest, State *src)
{
	/* Do not try to move in trans to and from the same state. */
	assert( dest != src );

	/* Move the transitions in inList. */
	TransEl *tel = src->inList.table;
	int ntel = src->inList.tableLength;
	for ( int i = 0; i < ntel; i++, tel++ ) {
		while ( tel->value != NULL ) {
			/* Get trans and from state. */
			Transition *trans = tel->value;
			State *fromState = trans->fromState;

			/* Detach from src, reattach to dest. */
			DetachStates( fromState, src, trans, KeyTypeSingle, tel->key );
			AttachStates( fromState, dest, trans, KeyTypeSingle, tel->key );
		}
	}

	/* Move the default transitions. */
	while ( src->defInTrans != NULL ) {
		/* Get trans and from state. */
		Transition *trans = src->defInTrans;
		State *fromState = trans->fromState;

		/* Detach from src, reattach to dest. */
		DetachStates( fromState, src, trans, KeyTypeDefault, 0 );
		AttachStates( fromState, dest, trans, KeyTypeDefault, 0 );
	}
}

#endif /* _RLFSM_FSMATTACH_CPP */

/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


#include "fsmdump.h"

using std::ostream;
using std::endl;

FsmDump::FsmDump( char *fsmName, ParseData *parseData, FsmAp *graph, std::ostream &out )
:
	fsmName(fsmName),
	parseData(parseData),
	graph(graph),
	out(out)
{
}

/* Write out a key of a transition. Considers the signedness of the key. */
void FsmDump::dumpFsmKey( int onChar )
{
	if ( graph->isAlphSigned )
		out << onChar;
	else
		out << (unsigned int) onChar;
}

/* Dump the target state, priority, and functions of a transition. */
void FsmDump::dumpTransData( TransAp *trans )
{
	out << trans->toState->alg.stateNum << " [" << trans->priority << "](";

	/* Print the functions, adding in commas in between. */
	TransAp::TransFuncEl *tfel = trans->transFuncTable.data;
	int nfunc = trans->transFuncTable.length();
	for ( int i = 0; i < nfunc-1; i++, tfel++ )
		out << tfel->value << ",";

	/* Print the last function without the comma. */
	if ( nfunc > 0 )
		out << tfel->value;
		
	out << ")";
}

/* Dump a transition. TransAp should not be null. */
void FsmDump::dumpTrans( int onChar, TransAp *trans )
{
	out << " ";
	dumpFsmKey( onChar );
	out << " ";
	if ( trans != NULL )
		dumpTransData( trans );
	else
		out << "xx []()";
	out << " |";
}

/* Dump a range transition. */
void FsmDump::dumpRangePair( int onChar1, int onChar2, TransAp *trans )
{
	out << " ";
	dumpFsmKey( onChar1 );
	out << "..";
	dumpFsmKey( onChar2 );
	out << " ";
	if ( trans != NULL )
		dumpTransData( trans );
	else
		out << "xx []()";
	out << " |";
}

/* Dump a default transition. */
void FsmDump::dumpDefTrans( TransAp *trans )
{
	out << " df ";
	dumpTransData( trans );
	out << " |";
}

/* Walk a list of transitions and dump the individual transitions. */
void FsmDump::dumpTransList( StateAp::TransList *list )
{
	StateAp::TransEl *tel = list->data;
	int ntel = list->length();
	for ( int i = 0; i < ntel; i++, tel++ )
		dumpTrans( tel->key, tel->value );
}

/* Walk a list of range transitions and dump the individual transitions. */
void FsmDump::dumpTransRange( StateAp::TransList *list )
{
	StateAp::TransEl *tel = list->data;
	for ( int i = 0; i < list->length(); i+=2, tel+=2 )
		dumpRangePair( tel[0].key, tel[1].key, tel[0].value );
}


/* Write out a state. */
void FsmDump::dumpState( StateAp *state )
{
	out << state->alg.stateNum << " [";
	if ( state->isOutPriorSet )
		out << state->outPriority;
	out << "](";

	/* Print the functions, adding in commas in between. */
	TransAp::TransFuncEl *tfel = state->outTransFuncTable.data;
	int nfunc = state->outTransFuncTable.length();
	for ( int i = 0; i < nfunc-1; i++, tfel++ )
		out << tfel->value << ",";

	/* Print the last function without the comma. */
	if ( nfunc > 0 )
		out << tfel->value;

	out << ")\n->";

	/* If there is a default trans, dump it. */
	if ( state->outDefault != NULL )
		dumpDefTrans( state->outDefault );

	/* Dump the range transitions. */
	dumpTransRange( &state->outRange );

	/* Dump the single transitions. */
	dumpTransList( &state->outList );

	out << endl;
}

/* Write out a graph. */
void FsmDump::dumpGraph( )
{
	/* Set the state numbers so we print something nice! */
	graph->setStateNumbers();

	/* Some header info. */
	out << "DUMP of " << fsmName << endl;
	out << "StartState: " << graph->findEntry(0)->alg.stateNum << " ";
	out << "Final States:";

	/* Dump Final states. */
	StateAp **st = graph->finStateSet.data;
	int nst = graph->finStateSet.length();
	for ( int i = 0; i < nst; i++, st++ )
		out << " " << (*st)->alg.stateNum << " |";
	out << endl;

	/* Walk the list of states, printing. */
	StateAp *state = graph->stateList.head;
	while (state) {
		dumpState( state );
		state = state->next;
	}
}

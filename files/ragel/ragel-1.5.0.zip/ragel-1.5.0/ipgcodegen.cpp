/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "ipgcodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"

/* Inits the code and data pointers. There are no code generation 
 * functions to register. */
IpGotoCodeGen::IpGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	GotoCodeGen(fsmName, parseData, machine, out)
{ }

/* Called from GotoCodeGen::STATE_GOTOS just before writing the gotos for each
 * state. */
void IpGotoCodeGen::aboveStateGotos( int st )
{
	bool anyWritten = false;

	/* Emit any transitions that have functions and that go to 
	 * this state. */
	FsmMachTrans *trans = machine->allTrans;
	for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
		if ( trans->toState == st && trans->funcs != FUNC_NO_FUNC ) {
			/* Remember that we wrote a trans so we know to write the
			 * line directive for going back to the output. */
			anyWritten = true;

			/* Write the label for the transition so it can be jumped to. */
			out << "tr" << tr << ":\n";

			/* Get the funcs. */
			int *funcs = machine->allTransFuncs + 
					machine->transFuncIndex[trans->funcs];

			/* The first number is the length. */
			int flen = *funcs++;
			while ( flen-- > 0 ) {
				/* Get the function data. */
				FuncListEl *flel = parseData->funcIndex[*funcs];

				/* Write the preprocessor line info for going into the 
				 * source file. */
				out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

				/* Wrap the block in brakets. */
				out << "\t{" << flel->data << "}\n";
				funcs += 1;
			}

			/* Goto the target state. */
			if ( trans->toState != STATE_ERR_STATE )
				out << "\tgoto st" << trans->toState << ";\n";
			else
				out << "\tgoto err;\n";
		}
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	}
}


std::ostream &IpGotoCodeGen::FINISH_CASES()
{
	bool anyWritten = false;

	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		if ( state->isFinState ) {
			out << "\tcase " << st << ": ";
			out << "acpt = 1; ";

			/* If there are out functions, write them. */
			if ( state->outFuncs != FUNC_NO_FUNC ) {
				/* Remember that we wrote a trans so we know to write the
				 * line directive for going back to the output. */
				anyWritten = true;

				out << "\n";
				int *funcs = machine->allTransFuncs + 
						machine->transFuncIndex[state->outFuncs];

				/* The first number is the length. */
				int flen = *funcs++;
				while ( flen-- > 0 ) {
					/* Get the function data. */
					FuncListEl *flel = parseData->funcIndex[*funcs];

					/* Write the preprocessor line info for going into the 
					 * source file. */
					out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

					/* Wrap the block in brakets. */
					out << "\t{" << flel->data << "}\n";
					funcs += 1;
				}
			}
			out << "\tbreak;\n";
		}
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	}
	return out;
}

/* Set up labelNeeded flag for each state. */
void IpGotoCodeGen::setLabelsNeeded()
{
	for ( int st = 0; st < machine->numStates; st++ )
		machine->allStates[st].labelNeeded = false;
	
	FsmMachTrans *trans = machine->allTrans;
	for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
		if ( trans->toState != STATE_ERR_STATE )
			machine->allStates[trans->toState].labelNeeded = true;
	}
}


/* Init base data. */
CIpGotoCodeGen::CIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	IpGotoCodeGen(fsmName, parseData, machine, out)
{ }


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CIpGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}

void CIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int curState;\n"
		"	int accept;\n";
		STRUCT_DATA() <<
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_startState;\n"
		"	fsm->accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = fsm->curState, acpt = 0;\n"
		"\n"
		"	if ( --len == 0 )\n"
		"		goto out;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() << 
		"	}\n";
		EXIT_STATES() << 
		"\n"
		"error:\n"
		"	cs = 0;\n"
		"\n"
		"out:\n"
		"	fsm->curState = cs;\n"
		"	fsm->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	int acpt = 0;\n"
		"	switch ( fsm->curState ) {\n";
		FINISH_CASES() <<
		"	}\n"
		"	fsm->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n";
}

/* Init base data. */
CCIpGotoCodeGen::CCIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	IpGotoCodeGen(fsmName, parseData, machine, out)
{ }


/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCIpGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	/* Init the fsm. */\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int curState;\n"
		"	int accept;\n";
		STRUCT_DATA() <<
		"\n"
		"	/* The start state. */\n"
		"	static int startState;\n"
		"};\n"
		"\n";
}

void CCIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"int "; FSM_NAME() << "::startState = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Make sure the machine is initialized. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "( )\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n"
		"/* Initialize the machine. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	this->curState = startState;\n"
		"	accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = this->curState, acpt = 0;\n"
		"\n"
		"	if ( --len == 0 )\n"
		"		goto out;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n";
		EXIT_STATES() << 
		"\n"
		"error:\n"
		"	cs = 0;\n"
		"\n"
		"out:\n"
		"	this->curState = cs;\n"
		"	this->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	int acpt = 0;\n"
		"	switch( this->curState ) {\n";
		FINISH_CASES() <<
		"	}\n"
		"	this->accept = acpt;\n"
		"}\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return accept;\n"
		"}\n"
		"\n";
}

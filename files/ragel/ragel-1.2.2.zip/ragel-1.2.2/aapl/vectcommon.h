/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndefs because it is
 * not intended to be included by users directly. */

#include <new>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "table.h"

/**
 * Vector
 */
template < class T, class Resize = ResizeExpn > class Vector
	: public Table<T>, public Resize
{
public:
	/* Table constructor will init data members. */
	Vector() { }

	/* Init Vector with size elements. */
	inline Vector( int size ) { setAs( 0, size ); }

	/* Init Vector with size elements, init with allocLength space. */
	Vector( int size, int allocLength );

	/* Copy Constructor. */
	Vector( const Vector &v );

	/* Destructor, empties the Vector. */
	~Vector() { empty(); }

	/* Reset the contents of the Vector to 0. Deletes all items. */
	void empty();

	/* Insertion routines. */
	void insert(int pos, const T &val)   { insert(pos, &val, 1); }
	/* Causes ambiguaties when T is int type. */
	/* void insert(int pos, int len)     { insert(pos, 0, len); } */
	void insert(int pos, const T *val, int len);
	void insert(int pos, const Vector &v);

	/* Deletion routines. */
	void remove(int pos)                 { remove(pos, 1); }
	void remove(int pos, int len);

	/* Overwriting routines. */
	void replace(int pos, const T &val)  { replace(pos, &val, 1); }
	/* void replace(int pos, int len)    { replace(pos, 0, len); } */
	void replace(int pos, const T *val, int len);
	void replace(int pos, const Vector &v);

	/* Routines for setting the contents. */
	void setAs(const T &val)             { setAs(&val, 1); }
	/* void setAs(int len)               { setAs(0, len); } */
	void setAs(const T *val, int len);
	void setAs(const Vector &v);

	/* Appending routines. */
	void append(const T &val)            { replace(tableLength, &val, 1); }
	/* void append(int len)              { replace(tableLength, 0, len); } */
	void append(const T *val, int len)   { replace(tableLength, val, len); }
	void append(const Vector &v);
	
	/* Prepending routines. */
	void prepend(const T &val)           { insert(0, &val, 1); }
	/* void prepend(int len)             { insert(0, 0, len); } */
	void prepend(const T *val, int len)  { insert(0, val, len); }
	void prepend(const Vector &v);

	/* Convenience access. */
	T &operator[](int i) const { return table[i]; }
	operator T *() const       { return table; }
	int size() const           { return tableLength; }

	/* first, last. */
	T *first() const  { return table; }
	T *last() const   { return table+tableLength-1; }

	/* Sentinals. */
	T *sfirst() const { return table-1; }
	T *slast() const  { return table+tableLength; }

	/* Vector Iterator. */
	struct Iterator
	{
		/* Construct, assign. */
		Iterator() : ptr(0) { }
		Iterator(T *ptr) : ptr(ptr) { }
		Iterator(const Vector &v) : ptr(v.table) { }

		T *operator=(T *ptr)              { return this->ptr = ptr; }
		T *operator=(const Vector &v)     { return ptr = v.table; }
		T *operator=(const Iterator &it)  { return ptr = it.ptr; }

		/* Cast, dereference, arrow ops. */
		operator T*() const   { return ptr; }
		T &operator *() const { return *ptr; }
		T *operator->() const { return ptr; }
		T &value() const      { return *ptr; }

		/* Arithmetic. */
		T *operator++()       { return ++ptr; }
		T *operator--()       { return --ptr; }
		T *operator++(int)    { return ptr++; }
		T *operator--(int)    { return ptr--; }
		T *operator+=(int n)  { return ptr+=n; }
		T *operator-=(int n)  { return ptr-=n; }

		/* List-like. */
		T *getNext() const  { return ptr+1; }
		T *getPrev() const  { return ptr-1; }
		T *next()           { return ++ptr; }
		T *prev()           { return --ptr; }

		/* The iterator is simply a pointer. */
		T *ptr;
	};

protected:
#ifdef VECT_COMPLEX
 	int makeRawSpaceFor(int pos, int len);
#endif

	void upResize(int len);
	void downResize(int len);
};

/**
 * Init Vector with size elements, allocLength space allocated.
 */
template<class T, class Resize> Vector<T, Resize>::
		Vector( int size, int allocLength )
{
	/* Allocate the space if we are given a positive allocLength. */
	this->allocLength = allocLength;
	if ( allocLength > 0 ) {
		table = (T*) malloc(sizeof(T) * allocLength);
		if ( table == NULL )
			throw std::bad_alloc();
	}

	/* Grow to the size specified. If we did not have enough space
	 * allocated that is ok. Table will be grown to right size. */
	setAs( 0, size );
}

/**
 * Appends the contents of another vector to the end of the vector. Requires
 * that the other vector does not equal this.
 */
template<class T, class Resize> void Vector<T, Resize>::
		append(const Vector<T, Resize> &v)
{
	assert(&v != this);
	replace(tableLength, v.table, v.tableLength);
}

/**
 * Prepends the contents of another vector to the beginning of the vector.
 * Requires that the other vector does not equal this.
 */
template<class T, class Resize> void Vector<T, Resize>::
		prepend(const Vector<T, Resize> &v)
{
	assert(&v != this);
	insert(0, v.table, v.tableLength);
}

/**
 * Sets the contents of the vector to the contents of another vector. Requires
 * that the other vector does not equal this.
 */
template<class T, class Resize> void Vector<T, Resize>::
		setAs(const Vector<T, Resize> &v)
{
	assert( &v != this );
	setAs(v.table, v.tableLength);
}

/**
 * Overwrite a vector with another vector. Requires that the source vector does
 * not = this.
 */
template<class T, class Resize> void Vector<T, Resize>::
		replace(int pos, const Vector<T, Resize> &v)
{
	assert(&v != this);
	replace( pos, v.table, v.tableLength );
}

/**
 * Insert another vector into this vector at pos pos.  Requires that we don't
 * try to insert a vector into itself.
 */
template<class T, class Resize> void Vector<T, Resize>::
		insert(int pos, const Vector<T, Resize> &v)
{
	assert(&v != this);
	insert(pos, v.table, v.tableLength);
}

/**
 * Up resize the table for len elements using Resize::upResize to tell us the
 * new length. Reads and writes allocLength. Does not read or write tableLength.
 */
template<class T, class Resize> void Vector<T, Resize>::
		upResize(int len)
{
	/* Ask the resizer what the new length will be. */
	int newLen = Resize::upResize(allocLength, len);

	/* Did the table grow? */
	if ( newLen > allocLength ) {
		allocLength = newLen;
		if ( table != NULL ) {
			/* Table exists already, resize it up. */
			table = (T*) realloc( table, sizeof(T) * newLen );
			if ( table == NULL )
				throw std::bad_alloc();
		}
		else {
			/* Create the table. */
			table = (T*) malloc( sizeof(T) * newLen );
			if ( table == NULL )
				throw std::bad_alloc();
		}
	}
}

/**
 * Down resize the table for len elements using Resize::downResize to determine
 * the new length. Reads and writes allocLength. Does not read or write tableLength.
 */
template<class T, class Resize> void Vector<T, Resize>::
		downResize(int len)
{
	/* Ask the resizer what the new length will be. */
	int newLen = Resize::downResize( allocLength, len );

	/* Did the table shrink? */
	if ( newLen < allocLength ) {
		allocLength = newLen;
		if ( newLen == 0 ) {
			/* Simply free the table. */
			free( table );
			table = NULL;
		}
		else {
			/* Not shrinking to size zero, realloc it to the smaller size. */
			table = (T*) realloc( table, sizeof(T) * newLen );
			if ( table == NULL )
				throw std::bad_alloc();
		}
	}
}


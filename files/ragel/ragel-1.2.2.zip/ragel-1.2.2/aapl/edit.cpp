/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include "edit.h"

/*******************************************************************************
 * class EditChunk
 */
void EditChunk::PrepGrow(DirToGrow dir)
{
	Length = 0;
	switch (dir) {
		case Left:
			FrontPos = EndPos = CHUNK_LEN;
			break;
		case Right:
			FrontPos = EndPos = 0;
			break;
		case Either:
			FrontPos = EndPos = CHUNK_LEN / 2;
			break;
	}
}

void EditChunk::ShiftLeft()
{
	if (Length == 0)
		EndPos = FrontPos = 0;
	else if (FrontPos > 0)
	{
		int dist = FrontPos;
		memmove(data, data + FrontPos, Length);
		FrontPos -= dist;
		EndPos -= dist;
	}
}

void EditChunk::ShiftRight()
{
	if (Length == 0)
		EndPos = FrontPos = CHUNK_LEN;
	else if (EndPos < CHUNK_LEN)
	{
		int dist = CHUNK_LEN - EndPos;
		memmove(data + FrontPos + dist,
				data + FrontPos, Length);
		FrontPos += dist;
		EndPos += dist;
	}
}

void EditChunk::InsertRight(EditChunk *chunk)
{
	if ( chunk == 0 )
		throw "EditChunk::InsertRight(EditChunk*) - invalid param";

	if ( chunk->Length > SpaceRight() )
		throw "EditChunk::InsertRight(EditChunk*) - overflow";
	
	/* Merge the supplied chunk into this chunk. */
	ShiftLeft();
	memcpy(data + EndPos, chunk->GetData(), chunk->Length);
	EndPos += chunk->Length;
	Length += chunk->Length;
}

void EditChunk::InsertLeft(EditChunk *chunk)
{
	if ( chunk == 0 )
		throw "EditChunk::InsertLeft(EditChunk*) - invalid param";

	if ( chunk->Length > SpaceLeft() )
		throw "EditChunk::InsertLeft(EditChunk*) - overflow";

	/* Merge the supplied chunk into this chunk. */
	ShiftRight();
	memcpy(data + FrontPos - chunk->Length, chunk->GetData(), chunk->Length);
	FrontPos -= chunk->Length;
	Length += chunk->Length;
}

void EditChunk::InsertRight(byte *data, int len)
{
	if ( data == 0 || len <= 0 )
		throw "EditChunk::InsertRight(byte*,int) - invalid param";
	
	if ( len > SpaceRight() )
		throw "EditChunk::InsertRight(byte*,int) - overflow";
		
	/* Insert the data into this chunk. */
	memcpy(data + EndPos, data, len);
	EndPos += len;
	Length += len;
}

void EditChunk::InsertLeft(byte *data, int len)
{
	if ( data == 0 || len <= 0 )
		throw "EditChunk::InsertLeft(byte*,int) - invalid param";
	
	if ( len > SpaceLeft() )
		throw "EditChunk::InsertLeft(byte*,int) - overflow";

	memcpy(data + FrontPos - len, data - len, len);
	FrontPos -= len;
	Length += len;
}

/*******************************************************************************
 * class Marker
 */
Marker::Marker(int i, EditChunk::DirToGrow dir, Marker *on_top_of)
{
	spareChunk = 0;
	IsSentinal = 0;
	Length = 0;
	id = i;
	onTopOf = on_top_of;

	if ( on_top_of )
		filePos = onTopOf->filePos;
}

Marker::~Marker()
{
	if (spareChunk)
		delete spareChunk;
}

void Marker::InsertRight(byte *data, int len)
{
	int lenAvailable;

	/* Throw an exception if we are passed bad args. */
	if (data == 0 || len <= 0)
		throw "Marker::InsertRight(byte*,int) - invalid param";

	/* If we are on top of another marker. Use it to insert. */
	if (onTopOf)
		return onTopOf->InsertRight(data, len);

	/* Keep the length of the marker updated. */
	Length += len;

	/* Find the len available in the tail chunk. */
	if ( chunkList.tail != 0 )
		lenAvailable = chunkList.tail->SpaceRight();
	else
		lenAvailable = 0;

	/* If we can fit all the data into the end chunk, do so. */
	if (len <= lenAvailable)
		chunkList.tail->InsertRight(data, len);
	else
	{
		/* Else, we must span the data over more than one chunk. */

		/* Max out the rightmost chunk. */
		if (lenAvailable > 0)
		{
			chunkList.tail->InsertRight(data, lenAvailable);
			data += lenAvailable;
			len -= lenAvailable;
		}

		NewRightChunk();

		while (len > CHUNK_LEN)
		{
			chunkList.tail->InsertRight(data, CHUNK_LEN);
		
			data += CHUNK_LEN;
			len -= CHUNK_LEN;

			NewRightChunk();
		}

		chunkList.tail->InsertRight(data, len);
	}
}

void Marker::InsertLeft(byte *data, int len)
{
	int lenAvailable;

	/* Throw an exception if we are passed bad args. */
	if (data == 0 || len <= 0)
		throw "Marker::InsertLeft(byte*,int) - invalid param";

	/* If we are on top of another marker. Use it to insert. */
	if (onTopOf)
		return onTopOf->InsertLeft(data, len);

	/* Keep the length of the marker updated. */
	Length += len;

	/* Find the len available in the tail chunk. */
	if ( chunkList.head != 0 )
		lenAvailable = chunkList.head->SpaceLeft();
	else
		lenAvailable = 0;

	/* If we can fit all the data into the head chunk, do so. */
	if (len <= lenAvailable)
		chunkList.head->InsertLeft(data, len);
	else
	{
		/* Else, we must span the data over more than one chunk. */

		/* Max out the rightmost chunk. */
		if (lenAvailable > 0)
		{
			chunkList.tail->InsertLeft(data, lenAvailable);
			data -= lenAvailable;
			len -= lenAvailable;
		}

		NewLeftChunk();

		while (len > CHUNK_LEN)
		{
			chunkList.head->InsertLeft(data, CHUNK_LEN);
		
			data -= CHUNK_LEN;
			len -= CHUNK_LEN;

			NewLeftChunk();
		}

		chunkList.head->InsertLeft(data, len);
	}
}

void Marker::NewLeftChunk()
{
	if ( prev && prev->spareChunk)
	{
		prev->spareChunk->PrepGrow(EditChunk::Left);
		chunkList.prepend(prev->spareChunk);
		prev->spareChunk = 0;
	}
	else
		chunkList.prepend(new EditChunk(EditChunk::Left));
}

void Marker::NewRightChunk()
{
	if (spareChunk)
	{
		spareChunk->PrepGrow(EditChunk::Right);
		chunkList.append(spareChunk);
		spareChunk = 0;
	}
	else
		chunkList.append(new EditChunk(EditChunk::Right));
}

void Marker::SpareLeft(EditChunk *chunk)
{
	if (prev && !prev->spareChunk)
		prev->spareChunk = chunk;
	else
		delete chunk;
}

void Marker::SpareRight(EditChunk *chunk)
{
	if (!spareChunk)
		spareChunk = chunk;
	else
		delete chunk;
}

void Marker::DumpAllLeft()
/* Purpose: Dump all data in this marker to the previous marker.
 * Pre:
 */
{
	if ( prev == 0 )
		throw "Marker::DumpAllLeft() - no prev marker";

	Length = 0;

	while (chunkList.head != 0)
		prev->InsertChunkRight(chunkList.detach(chunkList.head));
}

void Marker::DumpLeft(int len)
/* Purpose: Dump data from the left end of the marker to the previous marker.
 * Pre: len < the length of the marker
 *      this->prev != NULL
 */
{
	/* Throw an exception if we are a passed bad arg. */
	if ( len <= 0 || len > Length )
		throw "Marker::DumpLeft(int) - invalid param";

	if ( prev == 0 )
		throw "Marker::DumpLeft(int) - no prev marker";

	/* Adjust the length. */
	Length -= len;

	while (len >= chunkList.head->Length)
	{
		len -= chunkList.head->Length;
		prev->InsertChunkRight(chunkList.detach(chunkList.head));
	}

	if (len)
	{
		prev->InsertShortDataRight(chunkList.head->GetData(), len);
		chunkList.head->FrontPos += len;
		chunkList.head->Length -= len;
	}
}

void Marker::DumpAllRight()
/* Purpose: Dump all data in this marker to the next marker.
 * Pre:
 */
{
	if ( next == 0 )
		throw "Marker::DumpAllRight() - no next marker";

	Length = 0;

	while (chunkList.tail != 0)
		next->InsertChunkLeft(chunkList.detach(chunkList.tail));
}

void Marker::DumpRight(int len)
/* Purpose: Dump data from the right end of the marker to the next marker.
 * Pre: len < the length of the marker
 *      this->next != NULL
 */
{
	/* Throw an exception if we are a passed bad arg. */
	if ( len <= 0 || len > Length )
		throw "Marker::DumpLeft(int) - invalid param";

	if ( prev == 0 )
		throw "Marker::DumpLeft(int) - no prev marker";

	/* Adjust the lengths. */
	Length -= len;

	while (len >= chunkList.tail->Length)
	{
		len -= chunkList.tail->Length;
		next->InsertChunkLeft(chunkList.detach(chunkList.tail));
	}

	if (len)
	{
		next->InsertShortDataLeft( chunkList.tail->GetEndData(), len);
		chunkList.tail->EndPos -= len;
		chunkList.tail->Length -= len;
	}
}

void Marker::InsertChunkRight(EditChunk *chunk)
{
	if ( chunk == 0 )
	/* Adjust the length. */
	Length += chunk->Length;

	if ( chunk->Length <= chunkList.tail->SpaceRight() )
	{
		/* Merge the chunks. */
		chunkList.tail->InsertRight(chunk);

		/* Put chunk up as a spare. */
		SpareRight(chunk);
	}
	else
	{
		/* Simply align them next to each other. */
		chunkList.append(chunk);
	}
}

void Marker::InsertShortDataRight(byte *data, int len)
{
	/* Adjust the length. */
	Length += len;

	int lenAvailable = chunkList.tail->SpaceRight();

	if (len <= lenAvailable)
		chunkList.tail->InsertRight(data, len);
	else
	{
		/* We need to span the data over two chunks. */
		if (lenAvailable > 0)
		{
			chunkList.tail->InsertRight(data, lenAvailable);
			len -= lenAvailable;
			data += lenAvailable;
		}

		NewRightChunk();

		chunkList.tail->InsertRight(data, len);
	}
}

void Marker::InsertChunkLeft(EditChunk *chunk)
{
	/* Adjust the length. */
	Length += chunk->Length;

	if (chunkList.head->Length + chunk->Length <= CHUNK_LEN)
	{
		/* Merge the chunks. */
		chunkList.head->InsertLeft(chunk);

		/* Put the chunk up as a spare. */
		SpareLeft(chunk);
	}
	else
	{
		/* Simply align them next to each other. */
		chunkList.prepend(chunk);
	}
}

void Marker::InsertShortDataLeft(byte *data, int len)
{
	/* Adjust the length. */
	Length += len;

	int lenAvailable = chunkList.head->SpaceLeft();
	if (len <= lenAvailable)
		chunkList.head->InsertLeft(data, len);
	else
	{
		/* We need to span the data over two chunks. */
		if (lenAvailable > 0)
		{
			chunkList.head->InsertLeft(data + len - lenAvailable, lenAvailable);
			len -= lenAvailable;
		}

		NewLeftChunk();

		chunkList.head->InsertLeft(data, len);
	}
}

/*******************************************************************************
 * class Edit
 */
Edit::Edit()
{
	int i = 1;
	markerList.append(new Marker(1, EditChunk::Right, 0));
	markerList.tail->IsSentinal = 1;
	markerDict.insert(i, markerList.head);
}

int Edit::InsertRight(int mid, byte *data, int len)
{
	MarkerDictEl *dictEl = markerDict.find(mid);
	if ( dictEl != NULL ) {
		Marker *marker = dictEl->value;
		marker->InsertRight(data, len);
		FixFilePos(marker, len);
		return 1;
	}
	else
		return 0;
}

void Edit::InsertRight(Marker *marker, byte *data, int len)
{
	marker->InsertRight(data, len);
	FixFilePos(marker, len);
}

void Edit::FixFilePos(Marker *marker, int amount)
{
	while (marker)
	{
		marker->filePos += amount;
		marker = marker->next;
	}
}

int Edit::MoveLeft(int mid, int len)
{
	MarkerDictEl *dictEl = markerDict.find(mid);
	if ( dictEl != NULL ) {
		Marker *marker = dictEl->value;
		if ( ! marker->IsSentinal ) 
		{
			MoveLeft(marker, len);
			return 1;
		}
	}
	return 0;
}


void Edit::MoveLeftFromOnTop(Marker *marker, int len)
/* Moves a marker left from on top of another marker.
 * The length of the underlying marker must be < len. */
{
	/* Remove the marker from the on top of list. */
	Marker *underlyingMarker = marker->onTopOf;
	otMarkerList.detach(marker);

	/* Add the marker to the standard marker list. */
	markerList.addBefore(underlyingMarker, marker);

	/* This marker is no longer on top of another marker. */
	marker->onTopOf = 0;

	/* Shift the left portion of the underlying marker over. */
	underlyingMarker->DumpLeft(underlyingMarker->Length - len);
}


int Edit::MoveLeft(Marker *marker, int len)
{
	/* We cannot move the end marker. It is there
	 * as a sentinal. */
	if (marker->IsSentinal)
		return 0;

	/* Do not go past the front of the editor. */
	if (len > marker->filePos)
		len = marker->filePos;

	/* If we are trying to move left 0 spaces, return. */
	if (len == 0)
		return 1;
	
	/* If we are not on top of any marker, move left until we are
	 * on top of a marker, or until we have moved left enough. */
	if (!marker->onTopOf)
	{
		if (len < marker->Length)
		{
			/* Dump to it's neighbour. */
			marker->DumpRight(len);

			return 1;
		}
		else if ( len == marker->Length )
		{
			/* Dump all to its neighbour. */
				
			/* if we are the first marker, dump all to right
			 * else put on top of the previous marker. */
			
			return 1;
		}
		else
		{
			/* Dump all to its neighbour. */
			
			/* if we are the first marker, create a new one. return error.
			 * else continue on. */
		}
	}

	/* assert, we are on top of a marker. */

	while (len >= marker->onTopOf->Length)
	{
		/* if we are the first marker, create a new one.
		 * else put on top of the previous marker. */
	}

	if (len > 0)
		MoveLeftFromOnTop(marker, len);
		

	return 1;
}


void Edit::DumpOut()
{
	Marker *marker = markerList.head;
	while (marker)
	{
		EditChunk *chunk = marker->chunkList.head;
		while (chunk)
		{
			fwrite(chunk->data + chunk->FrontPos, 1,
					chunk->Length, stdout);
			chunk = chunk->next;
		}
		marker = marker->next;
	}
}

int Edit::FindNewMarkerId()
{
	MarkerDictEl *curMarker = markerDict.table;
	int tableSize = markerDict.tableLength;
	int curNum = 1;
	while (tableSize-- && curNum == curMarker->value->id)
	{
		curNum++;
		curMarker++;
	}
	return curNum;
}

Marker *Edit::NewMarker()
{
	/* Get a new id for the marker. */
	int newId = FindNewMarkerId();

	/* Create the new marker on top of the Sentinal. */
	Marker *newMarker = new Marker(newId, EditChunk::Either, markerList.tail);

	/* Insert the marker into the marker dictionary. */
	markerDict.insert(newId, newMarker);

	/* Add it to the front of the On Top marker list. */
	otMarkerList.prepend(newMarker);

	return newMarker;
}

#if 0
int Edit::RemoveMarker(int id)
{
	MarkerDictEl *dictEl = markerDict.Find(id);
	if ( dictEl != NULL ) {
		Marker *marker = dictEl->value;
		delete marker;
		markerDict.RemoveItem( dictEl );
		return 1;
	}
	else
		return 0;
}

int Edit::RemoveMarker(Marker *marker)
{
	MarkerDictEl *dictEl = markerDict.Find(marker->id);

	Marker *foundMarker =;
	if ( dictEl != NULL && dictEl->value == marker ) {
		delete marker;
		markerDict.RemoveItem( dictEl );
		return 1;
	}
	else
		return 0;
}
#endif
	
		


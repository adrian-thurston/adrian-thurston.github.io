#include "vector.h"
#include "vectsimp.h"

/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_TABLE_H
#define _AAPL_TABLE_H

/**
 * Base class for all table types.
 */
template<class T> class Table
{
public:
	/* Default Constructor. */
	inline Table();

	/**
	 * Pointer to the continuous array of data
	 */
	T *table;

	/**
	 * The number of items of type T in the table.
	 */
	int tableLength;

	/**
	 * The number of items of type T that that the current allocation can
	 * store.
	 */
	int allocLength;
};

/**
 * Initialize table data to empty.
 */
template< class T > inline Table<T>::Table()
:
	table(NULL),
	tableLength(0),
	allocLength(0)
{
}

/* If needed is greater than existing, give twice needed. */
#define EXPN_UP( existing, needed ) \
		needed > existing ? (needed<<1) : existing
	
/* If needed is less than 1 quarter existing, give twice needed. */
#define EXPN_DOWN( existing, needed ) \
		needed < (existing>>2) ? (needed<<1) : existing

/**
 * Exponential table resizer. This is used as the default resizer. Resizes up
 * and down exponentially.
 */
class ResizeExpn
{
protected:
	/**
	 * If the existing space is insufficient for the needed space, allocate
	 * twice the needed space (in units of sizeof(T)).
	 */
	static inline int upResize( int existing, int needed )
		{ return EXPN_UP( existing, needed ); }

	/**
	 * If the needed space is less than one quarter of the existing space then
	 * allocate twice the needed space (in units of sizeof(T)).
	 */
	static inline int downResize( int existing, int needed )
		{ return EXPN_DOWN( existing, needed ); }
};

#undef EXPN_UP
#undef EXPN_DOWN

#endif /* _AAPL_TABLE_H */

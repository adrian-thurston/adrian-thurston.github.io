/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_EVENT_H
#define _AAPL_EVENT_H

#ifdef _WIN
#	include <winsock.h>
#else
#	include <netinet/in.h>
#	include <sys/un.h>
#endif

#include "dlistmel.h"

class EventHandler;
class Selector;

struct ReadFdListEl : public DListEl<EventHandler> {};
struct WriteFdListEl : public DListEl<EventHandler> {};
struct ExceptFdListEl : public DListEl<EventHandler> {};
struct SigRegListEl : public DListEl<EventHandler> {};

/**
 * Abstract connection class.
 */
class EventHandler :
		public ReadFdListEl, 
		public WriteFdListEl, 
		public ExceptFdListEl,
		public SigRegListEl
{
	friend class Selector;
public:
	/* Can only be constructed with a selector given. */
	EventHandler();
	virtual ~EventHandler();

	void registerRead();
	void registerWrite();
	void registerExcept();
	void registerSignal(int sig);
	void unregisterRead();
	void unregisterWrite();
	void unregisterExcept();
	void unregisterSignal(int sig);
	void unregisterAllSignals();

	int openFds(int rfd, int wfd, int efd);
	int openInet(char *host, unsigned short int port);
	int openUnix(char *filename);

	int listenInet(unsigned short int port);
	int listenUnix(char *filename);

protected:
	virtual int readReady();
	virtual int writeReady();
	virtual int exceptReady();
	virtual int signalReady(int sig);

	int readFd;
	int writeFd;
	int exceptFd;

	unsigned int readRegistered :1;
	unsigned int writeRegistered :1;
	unsigned int exceptRegistered :1;
	sigset_t regSignals;
	int eventSigRegCount;
};

typedef DListMel< EventHandler, ReadFdListEl > ReadFdList;
typedef DListMel< EventHandler, WriteFdListEl > WriteFdList;
typedef DListMel< EventHandler, ExceptFdListEl > ExceptFdList;
typedef DListMel< EventHandler, SigRegListEl > SigRegList;

/**
 * Selector class wraps the select loop.
 */
class Selector
{
public:
	static int loop();

	/* Exception class used to break out of 
	 * the select loop. */
	struct Exit
	{
		Exit(int retVal) : retVal(retVal) { }
		int retVal;
	};

private:
	static int doSelectLoop();
	static void serviceReadyFds();
	static void serviceSignals(sigset_t *sigSet);
};

int selectLoop();

#endif /* _AAPL_EVENT_H */

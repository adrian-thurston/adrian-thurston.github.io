/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_COMPARE_H
#define _AAPL_COMPARE_H

#include <string.h>
#include "table.h"

/**
 * Compare two c-style strings
 */
struct CmpStr
{
	static inline int Compare(const char *k1, const char *k2)
		{ return strcmp(k1, k2); }
};

/**
 * Compare ordinal values. Can be used to compare any types that implement the
 * "<" and ">" operators.
 */
template<class T> struct CmpOrd
{
	static inline int Compare(const T k1, const T k2)
	{
		if (k1 < k2)
			return -1;
		else if (k1 > k2)
			return 1;
		else
			return 0;
	}
};

/**
 * Compare two tables of type T
 */
template<class T, class CompareT> struct CmpTable
{
	static inline int Compare(const Table<T> &t1, const Table<T> &t2)
	{
		if ( t1.tableLength < t2.tableLength )
			return -1;
		else if ( t1.tableLength > t2.tableLength )
			return 1;
		else
		{
			T *i1 = t1.table, *i2 = t2.table;
			int len = t1.tableLength, cmpResult;
			for ( int pos = 0; pos < len;
					pos += 1, i1 += 1, i2 += 1 )
			{
				cmpResult = CompareT::Compare(*i1, *i2);
				if ( cmpResult != 0 )
					return cmpResult;
			}
			return 0;
		}
	}
};

#endif /* _AAPL_COMPARE_H */

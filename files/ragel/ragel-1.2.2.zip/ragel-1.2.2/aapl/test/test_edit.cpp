/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "edit.h"

void testEdit1()
{
	char buf[200];
	int nbytes_wanted, nbytes;
	Edit e;

	srandom(time(0));

	while (1)
	{
		/* Read in some random amount. */
		nbytes_wanted = (random()%30) + 1;
		nbytes = fread(buf, 1, nbytes_wanted, stdin);

		if (nbytes == 0)
			break;
		else if ( nbytes != nbytes_wanted)
		{
			e.InsertRight(1, (byte*)buf, nbytes);
			break;
		}

		e.InsertRight(1, (byte*)buf, nbytes);
	}
	e.DumpOut();
}

void testEdit2()
{
	Edit e;

	Marker *m = e.NewMarker();
	e.InsertRight(m, (byte*) "Hello friend\n", 13);
	e.MoveLeft(m, 8);
	e.InsertRight(m, (byte*) " my smart", 9);

	e.DumpOut();
}

int main() {
	testEdit1();
	return 0;
}

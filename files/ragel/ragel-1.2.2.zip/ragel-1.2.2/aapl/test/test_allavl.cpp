/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>

#include "avltree.h"
#include "avlmel.h"
#include "avlmelkey.h"
#include "avlmap.h"
#include "avlset.h"

#include "avlitree.h"
#include "avlimel.h"
#include "avlimelkey.h"
#include "avlimap.h"
#include "avliset.h"

/*
 * AvlTree
 */

struct TreeNode1 : public AvlNode<TreeNode1>,
		public CmpOrd<int>
{
	TreeNode1() : inTree(false) { }
	TreeNode1(const int key) : key(key), inTree(false) { }

	const int getKey() { return key; }
	int key;
	bool inTree;
};

/* Instantiate the entire tree. */
template class AvlTree< TreeNode1, int >;

struct TreeNode2;
struct BaseNode2a : public AvlNode< TreeNode2 > { };
struct BaseNode2b : public AvlNode< TreeNode2 > { };

/*
 * AvlMel
 */
struct TreeNode2 : public BaseNode2a, public BaseNode2b,
		public CmpOrd<int>
{
	TreeNode2() : inTree1(false), inTree2(false) { }
	TreeNode2(const int key) : key(key), inTree1(false), inTree2(false) { }

	const int &getKey() { return key; }

	int key;
	bool inTree1;
	bool inTree2;
};

template class AvlMel< TreeNode2, int, BaseNode2a >;
template class AvlMel< TreeNode2, int, BaseNode2b >;

/*
 * AvlMelKey
 */
struct TreeNode3;
struct BaseNode3a :
		public AvlNode< TreeNode3 >,
		public CmpOrd<int>
{
	int getKey() { return key; }
	int key;
};
struct BaseNode3b :
		public AvlNode< TreeNode3 >,
		public CmpStr
{
	char strKey[20];
	char *getKey() { return strKey; }
};

struct TreeNode3 :
		public BaseNode3a, 
		public BaseNode3b
{
	TreeNode3() : inTree1(false), inTree2(false) { }
	/* One for each tree. */
	TreeNode3(const int key) : inTree1(false), inTree2(false) { }
	TreeNode3(const char* key) : inTree1(false), inTree2(false) { }

	bool inTree1;
	bool inTree2;
};

template class AvlMelKey< TreeNode3, int, BaseNode3a, BaseNode3a >;
template class AvlMelKey< TreeNode3, char*, BaseNode3b, BaseNode3b >;

/*
 * AvlMap
 */
/* Instantiate the entire tree. */
template class AvlMap< int, int, CmpOrd<int> >;

/*
 * AvlSet
 */
/* Instantiate the entire tree. */
template class AvlSet< int, CmpOrd<int> >;

/*
 * AvliTree
 */

struct TreeNode6 : public AvliNode<TreeNode6>,
		public CmpOrd<int>
{
	TreeNode6() : inTree(false) { }
	TreeNode6(const int key) : key(key), inTree(false) { }

	const int getKey() { return key; }
	int key;
	bool inTree;
};

/* Instantiate the entire tree. */
template class AvliTree< TreeNode6, int >;

struct TreeNode7;
struct BaseNode7a : public AvliNode< TreeNode7 > { };
struct BaseNode7b : public AvliNode< TreeNode7 > { };

/*
 * AvliMel
 */
struct TreeNode7 : public BaseNode7a, public BaseNode7b,
		public CmpOrd<int>
{
	TreeNode7() : inTree1(false), inTree2(false) { }
	TreeNode7(const int key) : key(key), inTree1(false), inTree2(false) { }

	const int &getKey() { return key; }

	int key;
	bool inTree1;
	bool inTree2;
};

template class AvliMel< TreeNode7, int, BaseNode7a >;
template class AvliMel< TreeNode7, int, BaseNode7b >;

/*
 * AvliMelKey
 */
struct TreeNode8;
struct BaseNode8a :
		public AvliNode< TreeNode8 >,
		public CmpOrd<int>
{
	int getKey() { return key; }
	int key;
};
struct BaseNode8b :
		public AvliNode< TreeNode8 >,
		public CmpStr
{
	char strKey[20];
	char *getKey() { return strKey; }
};

struct TreeNode8 :
		public BaseNode8a, 
		public BaseNode8b
{
	TreeNode8() : inTree1(false), inTree2(false) { }
	/* One for each tree. */
	TreeNode8(const int key) : inTree1(false), inTree2(false) { }
	TreeNode8(const char* key) : inTree1(false), inTree2(false) { }

	bool inTree1;
	bool inTree2;
};

template class AvliMelKey< TreeNode8, int, BaseNode8a, BaseNode8a >;
template class AvliMelKey< TreeNode8, char*, BaseNode8b, BaseNode8b >;

/*
 * AvliMap
 */
/* Instantiate the entire tree. */
template class AvliMap< int, int, CmpOrd<int> >;

/*
 * AvliSet
 */
/* Instantiate the entire tree. */
template class AvliSet< int, CmpOrd<int> >;


int main()
{
	return 0;
}

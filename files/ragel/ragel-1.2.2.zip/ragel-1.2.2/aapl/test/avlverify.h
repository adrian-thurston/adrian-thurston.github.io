/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#if defined( AVLTREE_MEL )
#	define BASENODE(name) BaseNode::name
#	define BASEKEY(name) name
#	define BASECOMPARE(name) Node::name
#	define AVLMEL_TEMPDEF class Node, class Key, class BaseNode
#	define AVLMEL_TEMPUSE Node, Key, BaseNode
#	if defined( WALKABLE )
#		define AvlTreeVer AvliMelVer
#		define AvlTree AvliMel
#	else
#		define AvlTreeVer AvlMelVer
#		define AvlTree AvlMel
#	endif
#elif defined( AVLTREE_MELKEY )
#	define BASENODE(name) BaseNode::name
#	define BASEKEY(name) BaseKey::name
#	define BASECOMPARE(name) BaseKey::name
#	define AVLMEL_TEMPDEF class Node, class Key, class BaseNode, class BaseKey
#	define AVLMEL_TEMPUSE Node, Key, BaseNode, BaseKey
#	if defined( WALKABLE )
#		define AvlTreeVer AvliMelKeyVer
#		define AvlTree AvliMelKey
#	else
#		define AvlTreeVer AvlMelKeyVer
#		define AvlTree AvlMelKey
#	endif
#elif defined( AVLTREE_SINGULAR )
#	define BASENODE(name) name
#	define BASEKEY(name) name
#	define BASECOMPARE(name) Node::name
#	define AVLMEL_TEMPDEF class Node, class Key 
#	define AVLMEL_TEMPUSE Node, Key
#	if defined( WALKABLE )
#		define AvlTreeVer AvliTreeVer
#		define AvlTree AvliTree
#	else
#		define AvlTreeVer AvlTreeVer
#		define AvlTree AvlTree
#	endif
#elif defined( AVLTREE_MAP )
#	define BASENODE(name) name
#	define BASEKEY(name) name
#	define BASECOMPARE(name) Compare::name
#	define AVLMEL_TEMPDEF class Key, class Value, class Compare
#	define AVLMEL_TEMPUSE Key, Value, Compare
#	if defined( WALKABLE )
#		define AvlTreeVer AvliMapVer
#		define AvlTree AvliMap
#		define Node AvliMapNode<Key,Value>
#	else
#		define AvlTreeVer AvlMapVer
#		define AvlTree AvlMap
#		define Node AvlMapNode<Key,Value>
#	endif
#elif defined( AVLTREE_SET )
#	define BASENODE(name) name
#	define BASEKEY(name) name
#	define BASECOMPARE(name) Compare::name
#	define AVLMEL_TEMPDEF class Key, class Compare
#	define AVLMEL_TEMPUSE Key, Compare
#	if defined( WALKABLE )
#		define AvlTreeVer AvliSetVer
#		define AvlTree AvliSet
#		define Node AvliSetNode<Key>
#	else
#		define AvlTreeVer AvlSetVer
#		define AvlTree AvlSet
#		define Node AvlSetNode<Key>
#	endif
#else
#	error "tree type not specified: this is not a user header"
#endif


/**********************************************************
 * AvlTree
 */
template <AVLMEL_TEMPDEF> class AvlTreeVer : public AvlTree<AVLMEL_TEMPUSE>
{
public:
	/* For debugging/testing. Verify the tree properties. */
	void VerifyIntegrity() const;

	/* For debugging/testing. Verify the tree properties. */
	void VerifyIntegrity(Node *node, Node *parent) const;
};

/********************************************************************
 * For debugging/testing. Verify the tree properties.
 */
template <AVLMEL_TEMPDEF> void AvlTreeVer<AVLMEL_TEMPUSE>::
		VerifyIntegrity() const
{
	VerifyIntegrity(root, 0);
#ifdef WALKABLE
	assert( listLength == nodeCount );
	/* Walk the list of nodes, assert the ordering. */
	if ( nodeCount > 0 ) {
		Node *prev = head, *cur = head->BASENODE(next);
		while ( cur != 0 ) {
			assert( BASECOMPARE(Compare( prev->BASEKEY(getKey()), 
				cur->BASEKEY(getKey()) )) < 0 );
			prev = cur;
			cur = cur->BASENODE(next);
		}
	}
#endif
}

/********************************************************************
 * AvlTree::VerifyIntegrity
 *
 * Verify the balance property of the avl tree
 * Verify binary tree propery as well as parent/child pointers are correct.
 */
template <AVLMEL_TEMPDEF> void AvlTreeVer<AVLMEL_TEMPUSE>::
		VerifyIntegrity(Node *node, Node *parent) const
{
	int lheight, rheight, balanceProp;
	if ( node == 0 )
		return;

	lheight = node->BASENODE(left) ? 
			node->BASENODE(left)->BASENODE(height) : 0;
	rheight = node->BASENODE(right) ? 
			node->BASENODE(right)->BASENODE(height) : 0;

	balanceProp = lheight - rheight;

	assert( -1 <= balanceProp && balanceProp <= 1 );
	assert( node->BASENODE(parent) == parent);

	if ( node->BASENODE(left) ) {
		assert( BASECOMPARE(Compare( node->BASEKEY(getKey()), 
				node->BASENODE(left)->BASEKEY(getKey()) )) > 0 );
	}

	if ( node->BASENODE(right) ) {
		assert( BASECOMPARE(Compare( node->BASEKEY(getKey()),
				node->BASENODE(right)->BASEKEY(getKey()) )) < 0 );
	}

	VerifyIntegrity(node->BASENODE(left), node);
	VerifyIntegrity(node->BASENODE(right), node);
	return;
}


/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMBASE_CC
#define _AAPL_FSMBASE_CC

#include <string.h>
#include <assert.h>

/**
 * Copy all graph data including transitions.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>::FsmGraph(const FsmGraph &graph)
:
	startState(0),
	finStateSet()
{
	/* Create the states and record their map in the original state. */
	State *origState = graph.head;
	while ( origState != 0 ) {
		/* Make the new state. */
		State *newState = new State(*origState);

		/* Add the state to the list.  */
		StateList::append( newState );

		/* Set the mapsTo item of the old state. */
		origState->stateMap = newState;

		/* next state. */
		origState = origState->next;
	}
	
	/* Derefernce all the state maps. */
	State *state = head;
	while ( state != 0 ) {
		/* Walk the list of out transitions and attach new transitions to their
		 * corresponding new states. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int ot = 0; ot < ntel; ot++, tel++ ) {
			/* Is the transition set? */
			if ( tel->value != NULL ) {
				/* Get the trans and the to state. */
				Transition *trans = tel->value;
				State *to = trans->toState->stateMap;

				/* Make a copy of the transition. */
				trans = new Transition(*trans);
				tel->value = trans;

				/* Simulate a real attaching. */
				trans->fromState = 0;
				trans->toState = 0;
				AttachStates( state, to, trans, KeyTypeSingle, tel->key );
			}
		}

		/* Walk the list of out ranges and attach new transitions to their
		 * corresponding new states. */
		tel = state->outRange.table;
		ntel = state->outRange.tableLength;
		for ( int outr = 0; outr < ntel; outr+=2, tel+=2 ) {
			if ( tel->value != NULL ) {
				/* Get the trans and the to state. */
				Transition *trans = tel->value;
				State *to = trans->toState->stateMap;

				/* Make a copy of the transition. */
				trans = new Transition(*trans);
				tel[0].value = trans;
				tel[1].value = trans;

				/* Simulate a real attaching. */
				trans->fromState = 0;
				trans->toState = 0;
				AttachStates( state, to, trans, KeyTypeRange, tel->key );
			}
		}

		/* Copy the default transition if it is there. */
		if ( state->defOutTrans != NULL ) {
			/* Get the trans and the to state. */
			Transition *trans = state->defOutTrans;
			State *to = trans->toState->stateMap;

			/* Copy the transition. */
			trans = new Transition(*trans);
			state->defOutTrans = trans;

			/* Simulate a real attaching. */
			trans->fromState = 0;
			trans->toState = 0;
			AttachStates( state, to, trans, KeyTypeDefault, 0 );
		}

		state = state->next;
	}

	/* Fix the start state. */
	startState = graph.startState->stateMap;
	
	/* Build the final state set. */
	State **st = graph.finStateSet.table;
	int nst = graph.finStateSet.tableLength;
	for ( int fs = 0; fs < nst; fs++, st++ )
		finStateSet.set((*st)->stateMap);
}

/**
 * Deletes all transition data then deletes each state.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>::~FsmGraph()
{
	/* Delete all the transitions. */
	State *state = head;
	while ( state != NULL ) {
		/* Delete out transitions. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for ( int ot = 0; ot < ntel; ot++, tel++ ) {
			if ( tel->value != NULL )
				delete tel->value;
		}

		/* Delete out range transitions. */
		tel = state->outRange.table;
		ntel = state->outRange.tableLength;
		for ( int outr = 0; outr < ntel; outr+=2, tel+=2 ) {
			if ( tel->value != NULL )
				delete tel->value;
		}

		/* Delete the default trans if there. */
		if ( state->defOutTrans != NULL )
			delete state->defOutTrans;

		state = state->next;
	}

	/* Delete all the states. */
	StateList::empty();
}


/**
 * Set a state final. The state has its isFinState set to true and the state is
 * added to the finStateSet.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		SetFinState(State *state)
{
	/* Is it already a fin state. */
	if (state->isFinState)
		return;
	
	state->isFinState = true;
	finStateSet.set( state );
}

/**
 * Set a state non-final. The has its isFinState flag set false and the state
 * is removed from the final state set.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		UnsetFinState(State *state)
{
	/* Is it already a fin state. */
	if (! state->isFinState)
		return;

	state->isFinState = false;
	finStateSet.unSet( state );
}

/**
 * Set the priority of starting transitions. Isolates the start state so it has
 * no other entry points, then sets the priorities of all the transitions out
 * of the start state. If the start state is final, then the outPrior of the
 * start state is also set. The idea is that a machine that accepts the null
 * string can still specify the starting trans prior for when it accepts the
 * null word.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		StartFsmPrior( int prior )
{
	/* Make sure the start state has no other entry points. */
	IsolateStartState();

	/* Walk all transitions out of the start state. */
	TransEl *tel = startState->outList.table;
	int ntel = startState->outList.tableLength;
	for (int i = 0; i < ntel; i++, tel++) {
		if ( tel->value != NULL )
			tel->value->priority = prior;
	}

	/* Default transition out of the start state? */
	if ( startState->defOutTrans != NULL )
		startState->defOutTrans->priority = prior;

	/* If the new start state is final then set the out priority. This follows
	 * the same convention as setting start funcs in the out funcs of a final
	 * start state. */
	if ( startState->isFinState ) {
		startState->isOutPriorSet = true;
		startState->outPriority = prior;
	}
}

/**
 * Set the priority of all transitions in a graph. Walks all transition lists
 * and all def transitions. 
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AllTransPrior( int prior )
{
	State *state = head;
	while ( state != NULL ) {
		/* Walk all the out list. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++) {
			if ( tel->value != NULL )
				tel->value->priority = prior;
		}

		/* If a default transition exists, then set priority on it too. */
		if ( state->defOutTrans != NULL )
			state->defOutTrans->priority = prior;

		state = state->next;
	}
}

/**
 * Set the priority of all transitions that go into a final state. Note that if
 * any entry states are final, we will not be setting the priority of any
 * transitions that may go into those states in the future. The graph does not
 * support pending in transitions in the same way pending out transitios are
 * supported.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FinFsmPrior( int prior )
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		/* Get the final state. */
		State *targ = *st;

		/* Walk all in transitions of the final state. */
		TransEl *tel = targ->inList.table;
		int ntel = targ->inList.tableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->value;
			while ( trans != NULL ) {
				trans->priority = prior;
				trans = trans->next;
			}
		}

		/* Walk all default in transitions of the final state. */
		Transition *trans = targ->defInTrans;
		while ( trans != NULL ) {
			trans->priority = prior;
			trans = trans->next;
		}
	}
}

/**
 * Set the priority of any future out transitions that may be made going out of
 * this state machine.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		LeaveFsmPrior( int prior )
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = true;
		(*st)->outPriority = prior;
	}
}


/**
 * Set functions to execute on starting transitions. Isolates the start state
 * so it has no other entry points, then adds to the transition functions
 * of all the transitions out of the start state. If the start state is final,
 * then the func is also added to the start state's out func list. The idea is
 * that a machine that accepts the null string can execute a start func when it
 * matches the null word, which can only be done when leaving the start/final
 * state.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		StartFsmFunc( TransFunc func, int transOrder )
{
	/* Make sure the start state has no other entry points. */
	IsolateStartState();

	/* Walk the start state's transitions, setting functions. */
	State *state = startState;
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;
	for (int i = 0; i < ntel; i++, tel++) {
		if ( tel->value != NULL )
			tel->value->SetFunction( func, transOrder );
	}

	/* Default transition out of the start state? */
	if ( startState->defOutTrans != NULL )
		startState->defOutTrans->SetFunction( func, transOrder );

	/* If start state is final then insert on the out func. This means that you
	 * can have start and leaving funcs on a machine that recognizes the null
	 * word. */
	if ( startState->isFinState )
		startState->outTransFuncTable.insertMulti( transOrder, func );
}

/**
 * Set functions to execute on all transitions. Walks the out lists of all states.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		AllTransFunc( TransFunc func, int transOrder )
{
	/* Walk all states. */
	State *state = head;
	while ( state != NULL ) {
		/* Walk the out list of the state. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++) {
			if ( tel->value != NULL )
				tel->value->SetFunction( func, transOrder );
		}

		/* If there is a default transition, then set funcs on it too. */
		if ( state->defOutTrans != NULL )
			state->defOutTrans->SetFunction( func, transOrder );

		state = state->next;
	}
}

/**
 * Specify functions to execute upon entering final states. If the start state
 * is final we can't really specify a function to execute upon entering that
 * final state the first time. So function really means whenever entering a
 * final state from within the same fsm.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FinFsmFunc( TransFunc func, int transOrder )
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		/* Get the final state. */
		State *targ = *st;

		/* Walk the final state's in list. */
		TransEl *tel = targ->inList.table;
		int ntel = targ->inList.tableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->value;
			while ( trans != 0 ) {
				trans->SetFunction( func, transOrder );
				trans = trans->next;
			}
		}

		/* Walk the final state's default in list. */
		Transition *trans = targ->defInTrans;
		while ( trans != NULL ) {
			trans->SetFunction( func, transOrder );
			trans = trans->next;
		}
	}
}

/**
 * Add functions to any future out transitions that may be made going out of
 * this state machine.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		LeaveFsmFunc( TransFunc func, int transOrder )
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++)
		(*st)->outTransFuncTable.insertMulti( transOrder, func );
}

/**
 * Shift the function ordering of the specified transition to start at
 * fromOrder and increase in units of 1. The current max used must be supplied
 * and the new max is returned.
 */
template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		ShiftFuncOrder( Transition *trans, int fromOrder, int maxUsed )
{
	/* Walk the function table for the transition. */
	typename Transition::TransFuncEl *tfel =
			trans->transFuncTable.table;

	/* Set the keys to increasing values starting at fromOrder */
	int ntfel = trans->transFuncTable.tableLength;
	int curFromOrder = fromOrder;
	for ( int j = 0; j < ntfel; j++, tfel++ )
		tfel->key = curFromOrder++;
	
	/* Keep track of the max number of orders used. */
	if ( curFromOrder - fromOrder > maxUsed )
		maxUsed = curFromOrder - fromOrder;

	return maxUsed;
}

/**
 * Shift the function ordering of the start transitions to start
 * at fromOrder and increase in units of 1. Useful before staring.
 * Returns the maximum number of order numbers used.
 */
template < class State, class TransFunc, class Transition >
		int FsmGraph<State, TransFunc, Transition>::
		ShiftStartFuncOrder( int fromOrder )
{
	int maxUsed = 0;
	/* Walk the transition list of the start state. */
	TransEl *tel = startState->outList.table;
	int ntel = startState->outList.tableLength;
	for ( int i = 0; i < ntel; i++, tel++ ) {
		/* If the trans is set, shift it over. */
		if ( tel->value != NULL )
			maxUsed = ShiftFuncOrder( tel->value, fromOrder, maxUsed );
	}

	/* Now do shift func priorities for the default trans, if there. */
	if ( startState->defOutTrans )
		maxUsed = ShiftFuncOrder( startState->defOutTrans, fromOrder, maxUsed );

	return maxUsed;
}

/**
 * Clear all functions tables out of the start state. First makes sure that
 * the start state has no other entry points other than its start stateness.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearStartFsmFunc()
{
	/* Make sure the start state has no other entry points. */
	IsolateStartState();

	/* Walk the start state's transitions, clearing functions. */
	State *state = startState;
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;
	for (int i = 0; i < ntel; i++, tel++) {
		if ( tel->value != NULL )
			tel->value->transFuncTable.empty();
	}

	/* Default transition out of the start state? */
	if ( startState->defOutTrans != NULL )
		startState->defOutTrans->transFuncTable.empty();

	/* If start state is final then clear on the out func. Leaving the start state
	 * via an out transition is considered starting the fsm. */
	if ( startState->isFinState )
		startState->outTransFuncTable.empty();
}

/**
 * Empty all transition functions tables. Does not empty state outFunc tables.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearAllTransFunc()
{
	/* Walk all states. */
	State *state = head;
	while ( state != NULL ) {
		/* Walk the state's outList. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++) {
			if ( tel->value != NULL )
				tel->value->transFuncTable.empty();
		}

		/* If there is a default transition, then clear it's funcs too. */
		if ( state->defOutTrans != NULL )
			state->defOutTrans->transFuncTable.empty();

		state = state->next;
	}
}

/*
 * Empty all transition functions going into a final state.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearFinFsmFunc()
{
	/* Walk all final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		/* Get the state. */
		State *targ = *st;

		/* Walk the final state's in list. */
		TransEl *tel = targ->inList.table;
		int ntel = targ->inList.tableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->value;
			while ( trans != 0 ) {
				trans->transFuncTable.empty();
				trans = trans->next;
			}
		}

		/* Walk the final state's default in list. */
		Transition *trans = targ->defInTrans;
		while ( trans != NULL ) {
			trans->transFuncTable.empty();
			trans = trans->next;
		}
	}
}

/**
 * Clear pending out functions from the outFunc lists of final states.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearLeaveFsmFunc()
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for (int i = 0; i < nst; i++, st++)
		(*st)->outTransFuncTable.empty();
}

/**
 * Clear pending out priorities from final states.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearLeaveFsmPrior( )
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = false;
		(*st)->outPriority = 0;
	}
}

/**
 * Remove all transition data. Remove funcs and outfuncs, zero priorities and
 * remove out priorities.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ClearAllTransData()
{
	State *state = head;
	while ( state ) {
		/* Clear out data. */
		state->outTransFuncTable.empty();
		state->isOutPriorSet = false;
		state->outPriority = 0;

		/* Clear transition data from the outList. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for (int i = 0; i < ntel; i++, tel++) {
			if ( tel->value != NULL ) {
				tel->value->transFuncTable.empty();
				tel->value->priority = 0;
			}
		}

		/* Clear transition data from default transitions. */
		if ( state->defOutTrans != NULL ) {
			state->defOutTrans->transFuncTable.empty();
			state->defOutTrans->priority = 0;
		}

		state = state->next;
	}
}


/**
 * Zeros out the function ordering keys. This may be called before condensing
 * when it is known that no more fsm operations are going to be done.
 * This will achieve greater condensing as states will not be separated
 * on the basis of function ordering.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		NullFunctionKeys( )
{
	State *state = head;
	while ( state != NULL ) {
		/* Walk the transitions for the state. */
		TransEl *tel = state->outList.table;
		int ntel = state->outList.tableLength;
		for ( int i = 0; i < ntel; i++, tel++ ) {
			if ( tel->value != NULL ) {
				/* Walk the function table for the transition. */
				typename Transition::TransFuncEl *tfel =
						tel->value->transFuncTable.table;
				int ntfel = tel->value->transFuncTable.tableLength;
				for ( int j = 0; j < ntfel; j++, tfel++ )
					tfel->key = 0;
			}
		}

		/* Is there a default transition? */
		if ( state->defOutTrans != NULL ) {
			/* Walk the function table for the transition. */
			typename Transition::TransFuncEl *tfel =
					state->defOutTrans->transFuncTable.table;
			int ntfel = state->defOutTrans->transFuncTable.tableLength;
			for ( int j = 0; j < ntfel; j++, tfel++ )
				tfel->key = 0;
		}
		state = state->next;
	}
}

/**
 * Marks pairs based on in transitions. This is the approach used by
 * CondenseOptimized1 and CondenseOptimized2. This is experimental code and
 * does not work yet.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkPairsOnIn( MarkIndex &markIndex, State *r, State *s )
{
	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->inList.table;
	TransEl *rEndTransEl = rTransEl + r->inList.tableLength;
	TransEl *sTransEl = s->inList.table;
	TransEl *sEndTransEl = sTransEl + s->inList.tableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( rTransEl != rEndTransEl && sTransEl != sEndTransEl ) {
		/* Both rPos and sPos are good. Get the characters of the
		 * transitions. */
		rItem = rTransEl->key;
		sItem = sTransEl->key;
		if ( rItem < sItem ) {
			/* transitions don't match up. Move ahead in rTransEl. */
			rTransEl++;
		}
		else if ( sItem < rItem ) {
			/* Transitions don't match up. Move ahead in sTransEl. */
			sTransEl++;
		}
		else {
			/* This will stop us from unneccessary looping if r has lots of trans on
			 * this char and s has none. */
			if ( sTransEl->value != NULL ) {
				/* Loop over r's transitions on this char. */
				Transition *rTrans = rTransEl->value;
				while ( rTrans != NULL ) {
					State *p = rTrans->fromState;

					/* Loop over s's transitions on this char. */
					Transition *sTrans = sTransEl->value;
					while ( sTrans != NULL ) {
						State *q = sTrans->fromState;

						/* If the states are different and not already marked. Then mark. */
						if ( p != q && ! markIndex.IsPairMarked(p->num, q->num) )
							markIndex.MarkPair(p->num, q->num);
				
						sTrans = sTrans->next;
					}
					rTrans = rTrans->next;
				}
			}
			rTransEl++;
			sTransEl++; 
		}
	}
}

/**
 * When testing if two states should be marked (from ShouldMarkPair) do the
 * test on two transition pointers from R and S. Need to consider if the
 * transition pointers are set. This is used on outTrans lists and default
 * transitions.
 */
template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		ShouldMarkPtrs( MarkIndex &markIndex, Transition *rTrans, Transition *sTrans, 
			bool cmpTd )
{
	bool shouldMark = false;

	if ( rTrans != NULL && sTrans != NULL ) {
		/* Both rTrans and sTrans are set. */
		if ( markIndex.IsPairMarked( rTrans->toState->num, sTrans->toState->num ) )
			shouldMark = true;
		else if ( cmpTd && Transition::CompareTransData( rTrans, sTrans) != 0 )
			shouldMark = true;
	}
	else if ( rTrans != NULL ) {
		/* Only rTel is set. Mark. */
		shouldMark = true;
	}
	else if ( sTrans != NULL ) {
		/* Only sTel is set. Mark. */
		shouldMark = true;
	}

	return shouldMark;
}

/**
 * Decide if the pair should be marked. Considers whether or not pairs of
 * transitions go to marked states and if the transition data differs.
 * CmpTransData specifies whether or not to consider transition data.  Used by
 * stable condensing and by experimental optimized condensing.
 */
template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		ShouldMarkPair( MarkIndex &markIndex, State *r, State *s, bool cmpTd )
{
	bool shouldMark = false;

	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->outList.table;
	TransEl *rEndTransEl = rTransEl + r->outList.tableLength;
	TransEl *sTransEl = s->outList.table;
	TransEl *sEndTransEl = sTransEl + s->outList.tableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( !shouldMark ) {
		if ( rTransEl == rEndTransEl ) {
			/* We are at the end of r's transitions. While not at the end of 
			 * of s's transEl, test for marking. */
			while ( !shouldMark && sTransEl != sEndTransEl ) {
				shouldMark = ShouldMarkPtrs( markIndex, r->defOutTrans, sTransEl->value, cmpTd );
				sTransEl++;
			}
			break;
		}
		else if ( sTransEl == sEndTransEl ) {
			/* We are at the end of s's transitions. While not at the end of
			 * r's, test for marking.  */
			while ( !shouldMark && rTransEl != rEndTransEl ) {
				shouldMark = ShouldMarkPtrs( markIndex, rTransEl->value, s->defOutTrans, cmpTd );
				rTransEl++;
			}
		}
		else {
			/* Both rPos and sPos are good. Get the characters of the
			 * transitions. */
			rItem = rTransEl->key;
			sItem = sTransEl->key;
			if ( rItem < sItem ) {
				/* Keys don't match up. Only in rTransEl. */
				shouldMark = ShouldMarkPtrs( markIndex, rTransEl->value, s->defOutTrans, cmpTd );
				rTransEl++;
			}
			else if ( rItem > sItem ) {
				/* Keys don't match up. Only in sTransEl. */
				shouldMark = ShouldMarkPtrs( markIndex, r->defOutTrans, sTransEl->value, cmpTd );
				sTransEl++;
			}
			else {
				/* Keys match up. Trans on the same char. */
				shouldMark = ShouldMarkPtrs( markIndex, rTransEl->value, sTransEl->value, cmpTd );
				rTransEl++;
				sTransEl++; 
			}
		}
	}

	/* Last thing to do is check the def trans for marking. */
	if ( !shouldMark )
		shouldMark = ShouldMarkPtrs( markIndex, r->defOutTrans, s->defOutTrans, cmpTd );

	return shouldMark;
}

/**
 * Mark all states reachable from state. Traverses transitions forward. Used
 * for removing states that have no path into them.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkReachableFromHere( State *state )
{
	/* Base case: return; */
	if (state->isMarked)
		return;
	
	/* Set this state as marked. */
	state->isMarked = true;

	/* Recurse on all items in outList. */
	TransEl *tel = state->outList.table;
	int ntel = state->outList.tableLength;
	for (int ot = 0; ot < ntel; ot++, tel++) {
		if ( tel->value != NULL )
			MarkReachableFromHere( tel->value->toState );
	}

	/* Recurse on all items in outRange. */
	tel = state->outRange.table;
	ntel = state->outRange.tableLength;
	for ( int outr = 0; outr < ntel; outr+=2, tel+=2 ) {
		if ( tel->value != NULL )
			MarkReachableFromHere( tel->value->toState );
	}
	
	/* Recurse on default transition. */
	if ( state->defOutTrans != NULL )
		MarkReachableFromHere( state->defOutTrans->toState );
}

/**
 * Mark all states reachable from state. Traverse transitions backwards. Used
 * for removing dead end paths in graphs.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MarkReachableFromHereReverse( State *state )
{
	/* Base case: return; */
	if (state->isMarked)
		return;
	
	/* Set this state as marked. */
	state->isMarked = true;

	/* Recurse on all items in inList. */
	TransEl *tel = state->inList.table;
	int ntel = state->inList.tableLength;
	for (int it = 0; it < ntel; it++, tel++) {
		Transition *trans = tel->value;
		while ( trans ) {
			MarkReachableFromHereReverse( trans->fromState );
			trans = trans->next;
		}
	}

	/* Recurse on all items in inRange. */
	tel = state->inRange.table;
	ntel = state->inRange.tableLength;
	for (int ir = 0; ir < ntel; ir++, tel++) {
		Transition *trans = tel->value;
		while ( trans ) {
			MarkReachableFromHereReverse( trans->fromState );
			trans = trans->next;
		}
	}

	/* Recurse the default transition. */
	Transition *trans = state->defInTrans;
	while ( trans ) {
		MarkReachableFromHereReverse( trans->fromState );
		trans = trans->next;
	}
}


/**
 * Tests the integrity of the transition lists and the fromStates.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		VerifyIntegrity()
{
	State *state = head;
	while ( state != NULL ) {
		/* Walk the out list. */
		TransEl *tel = state->outList.table;
		int i, ntel = state->outList.tableLength;
	 	for ( i = 0; i < ntel; i++, tel++ ) {
			/* Assert the fromState is correct. */
			if ( tel->value != NULL ) {
				assert( tel->value->fromState == state );
			}
		}

		/* Assert the default transition's fromState is correct. */
		if ( state->defOutTrans != NULL ) {
			assert( state->defOutTrans->fromState == state );
		}

		/* Walk the inlist and assert toState is correct. */
		tel = state->inList.table;
		ntel = state->inList.tableLength;
		for ( i = 0; i < ntel; i++, tel++ ) {
			Transition *last = NULL;
			Transition *trans = tel->value;
			while ( trans != NULL ) {
				/* Assert the toState is correct. */
				assert( trans->toState == state );
				/* Assert the prev ptr is correct. */
				assert( trans->prev == last );

				/* Go to next trans. */
				last = trans;
				trans = trans->next;
			}
		}

		/* Walk the default transition inList and assert toState is correct. */
		Transition *last = NULL;
		Transition *trans = state->defInTrans;
		while ( trans != NULL ) {
			/* Assert the toState is correct. */
			assert( trans->toState == state );
			/* Assert the prev ptr is correct. */
			assert( trans->prev == last );

			/* Go to next trans. */
			last = trans;
			trans = trans->next;
		}
		state = state->next;
	}
}

#endif /* _AAPL_FSMBASE_CC */

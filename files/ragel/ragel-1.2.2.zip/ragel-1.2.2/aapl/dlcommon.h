/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

/* This header is not wrapped in ifndef becuase it is not intended to
 * be included by the user. */

#if defined( DOUBLELIST_VALUE )
/**
 * Double list element used class for value lists. It stores the type T of the
 * list directly. 
 */
template <class T> struct DListValEl
{
	/**
	 * The only constructor available initializes the value element. This
	 * enforces that DListVal elements are never created without having their
	 * value intialzed by the user. T's copy constructor is used to copy the
	 * value in.
	 */
	DListValEl( const T &val ) : value(val) { }

	T value;
	DListValEl<T> *prev;
	DListValEl<T> *next;
};
#else

#ifndef __AAPL_DOUBLE_LIST_EL
#define __AAPL_DOUBLE_LIST_EL
/**
 * This is the double list element class that needs to be inherited by classes
 * that intend to be double list elements. It provides the double list element
 * capabilities.
 */
template <class Element> struct DListEl
{
	/**
	 * Points to the previous item in the list. If this is the first item in
	 * the list, then prev is NULL. If this element is not in a list then
	 * prev is undefined.
	 */
	Element *prev;

	/**
	 * Points to the next item in the list. If this is the list item in the
	 * list, then next is NULL. If this element is not in a list then next is
	 * undefined.
	 */
	Element *next;
};
#endif /* __AAPL_DOUBLE_LIST_EL */

#endif

/**
 * Doubly linked list.
 */
template <DLMEL_TEMPDEF> class DList
{
public:
	DList(const DList &other);
	DList() : head(0), tail(0), listLength(0) {}

	void prepend(Element *new_el) { addBefore(head, new_el); }
	void append(Element *new_el)  { addAfter(tail, new_el); }

	void prepend(DList &dl)       { addBefore(head, dl); }
	void append(DList &dl)        { addAfter(tail, dl); }

	Element *detachFirst()        { return detach(head); }
	Element *detachLast()         { return detach(tail); }

	void empty();
	void abandon();
	
	void addAfter(Element *prev_el, Element *new_el);
	void addBefore(Element *next_el, Element *new_el);

	void addAfter(Element *prev_el, DList &dl);
	void addBefore(Element *next_el, DList &dl);

#if defined ( DOUBLELIST_VALUE )
	void addAfter(Element *prev_el, const T &item)
		{ addAfter(prev_el, new Element(item)); }
	void addBefore(Element *next_el, const T &item)
		{ addBefore(next_el, new Element(item)); }

	void prepend(const T &item)
		{ addBefore(head, new Element(item)); }
	void append(const T &item)
		{ addAfter(tail, new Element(item)); }
#endif

	Element *detach(Element *el);

	Element *head, *tail;
	int listLength;

	/* Convenience access. */
	operator Element *() const { return head; }
	int size() const           { return listLength; }

	/* first, last. */
	Element *first() const { return head; }
	Element *last() const  { return tail; }

	/* Sentinals. */
	Element *sfirst() const { return 0; }
	Element *slast() const  { return 0; }

	/* Vector Iterator. */
	struct Iterator
	{
		/* Construct, assign. */
		Iterator() : ptr(0) { }
		Iterator(Element *ptr) : ptr(ptr) { }
		Iterator(const DList &dl) : ptr(dl.head) { }

		Element *operator=(Element *ptr)        { return this->ptr = ptr; }
		Element *operator=(const DList &dl)     { return ptr = dl.head; }
		Element *operator=(const Iterator &it)  { return ptr = it.ptr; }

#if defined ( DOUBLELIST_VALUE )
		/* Cast, dereference, arrow ops. */
		operator Element*() const   { return ptr; }
		operator T*() const         { return &ptr->value; }
		T &operator *() const       { return ptr->value; }
		T *operator->() const       { return &ptr->value; }
		T &value() const            { return ptr->value; }
#else
		/* Cast, dereference, arrow ops. */
		operator Element*() const   { return ptr; }
		Element &operator *() const { return *ptr; }
		Element *operator->() const { return ptr; }
#endif

		/* Arithmetic. */
		inline Element *operator++();
		inline Element *operator--();
		inline Element *operator++(int);
		inline Element *operator--(int);
		Element *operator+=(int n);
		Element *operator-=(int n);
		Element *operator+(int);
		Element *operator-(int);

		/* List like. */
		Element *getNext() const { return ptr->BASEREF(next); }
		Element *getPrev() const { return ptr->BASEREF(prev); }
		inline Element *next();
		inline Element *prev();

		/* The iterator is simply a pointer. */
		Element *ptr;
	};
};

/**
 * Copy the data from another list. New up each item.
 */
template <DLMEL_TEMPDEF> DList<DLMEL_TEMPUSE>::
		DList(const DList<DLMEL_TEMPUSE> &other) :
			head(0), tail(0), listLength(0)
{
	Element *el = other.head;
	while( el != 0 ) {
		append( new Element(*el) );
		el = el->BASEREF(next);
	}
}

/*
 * Iterator operators.
 */

/* Prefix ++ */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator++()       
{
	ptr = ptr->BASEREF(next);
	return ptr;
}

/* Prefix -- */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator--()       
{
	ptr = ptr->BASEREF(prev);
	return ptr;
}

/* Postfix ++ */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator++(int)       
{
	Element *rtn = ptr; 
	ptr = ptr->BASEREF(next);
	return rtn;
}

/* Postfix -- */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator--(int)       
{
	Element *rtn = ptr;
	ptr = ptr->BASEREF(prev);
	return rtn;
}

/* Plus equals */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator+=(int n)
{
	while (n > 0) {
		ptr = ptr->BASEREF(next);
		n--;
	}
	while(n < 0) {
		ptr = ptr->BASEREF(prev);
		n++;
	}
	return ptr;
}

/* Minus equals */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator-=(int n)
{
	while (n > 0) {
		ptr = ptr->BASEREF(prev);
		n--;
	}
	while(n < 0) {
		ptr = ptr->BASEREF(next);
		n++;
	}
	return ptr;
}

/* Plus */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator+(int n)
{
	Element *rtn = ptr;
	while (n > 0) {
		rtn = rtn->BASEREF(next);
		n--;
	}
	while(n < 0) {
		rtn = rtn->BASEREF(prev);
		n++;
	}
	return rtn;
}

/* Minus */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::
		operator-(int n)
{
	Element *rtn = ptr;
	while (n > 0) {
		rtn = rtn->BASEREF(prev);
		n--;
	}
	while(n < 0) {
		rtn = rtn->BASEREF(next);
		n++;
	}
	return rtn;
}

/* next */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::next()
{
	ptr = ptr->BASEREF(next);
	return ptr;
}

/* prev */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::Iterator::prev()
{
	ptr = ptr->BASEREF(prev);
	return ptr;
}

/**
 * Insert an element after a given element already in the list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		addAfter(Element *prev_el, Element *new_el)
{
	/* Set the previous pointer of new_el to prev_el. We do
	 * this regardless of the state of the list. */
	new_el->BASEREF(prev) = prev_el; 

	/* Set forward pointers. */
	if (prev_el == 0) {
		/* There was no prev_el, we are inserting at the head. */
		new_el->BASEREF(next) = head;
		head = new_el;
	} 
	else {
		/* There was a prev_el, we can access previous next. */
		new_el->BASEREF(next) = prev_el->BASEREF(next);
		prev_el->BASEREF(next) = new_el;
	} 

	/* Set reverse pointers. */
	if (new_el->BASEREF(next) == 0) {
		/* There is no next element. Set the tail pointer. */
		tail = new_el;
	}
	else {
		/* There is a next element. Set it's prev pointer. */
		new_el->BASEREF(next)->BASEREF(prev) = new_el;
	}

	/* Update list length. */
	listLength++;
}

/**
 * Insert an element before a given element already in the list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		addBefore(Element *next_el, Element *new_el)
{
	/* Set the next pointer of the new element to next_el. We do
	 * this regardless of the state of the list. */
	new_el->BASEREF(next) = next_el; 

	/* Set reverse pointers. */
	if (next_el == 0) {
		/* There is no next elememnt. We are inserting at the tail. */
		new_el->BASEREF(prev) = tail;
		tail = new_el;
	} 
	else {
		/* There is a next element and we can access next's previous. */
		new_el->BASEREF(prev) = next_el->BASEREF(prev);
		next_el->BASEREF(prev) = new_el;
	} 

	/* Set forward pointers. */
	if (new_el->BASEREF(prev) == 0) {
		/* There is no previous element. Set the head pointer.*/
		head = new_el;
	}
	else {
		/* There is a previous element, set it's next pointer to new_el. */
		new_el->BASEREF(prev)->BASEREF(next) = new_el;
	}

	/* Update list length. */
	listLength++;
}

/**
 * Insert an entire list after another element already in the list.
 * Result is other list is emptied out.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		addAfter( Element *prev_el, DList<DLMEL_TEMPUSE> &dl )
{
	/* Do not bother if dl has no elements. */
	if ( dl.listLength == 0 )
		return;

	/* Set the previous pointer of dl.head to prev_el. We do
	 * this regardless of the state of the list. */
	dl.head->BASEREF(prev) = prev_el; 

	/* Set forward pointers. */
	if (prev_el == 0) {
		/* There was no prev_el, we are inserting at the head. */
		dl.tail->BASEREF(next) = head;
		head = dl.head;
	} 
	else {
		/* There was a prev_el, we can access previous next. */
		dl.tail->BASEREF(next) = prev_el->BASEREF(next);
		prev_el->BASEREF(next) = dl.head;
	} 

	/* Set reverse pointers. */
	if (dl.tail->BASEREF(next) == 0) {
		/* There is no next element. Set the tail pointer. */
		tail = dl.tail;
	}
	else {
		/* There is a next element. Set it's prev pointer. */
		dl.tail->BASEREF(next)->BASEREF(prev) = dl.tail;
	}

	/* Update the list length. */
	listLength += dl.listLength;

	/* Empty out dl. */
	dl.head = dl.tail = 0;
	dl.listLength = 0;
}

/**
 * Insert an entire list before another element already in the list.
 * Result is other list is emptied out.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::
		addBefore( Element *next_el, DList<DLMEL_TEMPUSE> &dl )
{
	/* Do not bother if dl has no elements. */
	if ( dl.listLength == 0 )
		return;

	/* Set the next pointer of dl.tail to next_el. We do
	 * this regardless of the state of the list. */
	dl.tail->BASEREF(next) = next_el; 

	/* Set reverse pointers. */
	if (next_el == 0) {
		/* There is no next elememnt. We are inserting at the tail. */
		dl.head->BASEREF(prev) = tail;
		tail = dl.tail;
	} 
	else {
		/* There is a next element and we can access next's previous. */
		dl.head->BASEREF(prev) = next_el->BASEREF(prev);
		next_el->BASEREF(prev) = dl.tail;
	} 

	/* Set forward pointers. */
	if (dl.head->BASEREF(prev) == 0) {
		/* There is no previous element. Set the head pointer.*/
		head = dl.head;
	}
	else {
		/* There is a previous element, set it's next pointer to new_el. */
		dl.head->BASEREF(prev)->BASEREF(next) = dl.head;
	}

	/* Update list length. */
	listLength += dl.listLength;

	/* Empty out dl. */
	dl.head = dl.tail = 0;
	dl.listLength = 0;
}


/**
 * Detaches an element from the list. Does not free any memory.
 */
template <DLMEL_TEMPDEF> Element *DList<DLMEL_TEMPUSE>::
		detach(Element *el)
{
	/* Set forward pointers to skip over el. */
	if (el->BASEREF(prev) == 0) 
		head = el->BASEREF(next); 
	else {
		el->BASEREF(prev)->BASEREF(next) =
				el->BASEREF(next); 
	}

	/* Set reverse pointers to skip over el. */
	if (el->BASEREF(next) == 0) 
		tail = el->BASEREF(prev); 
	else {
		el->BASEREF(next)->BASEREF(prev) =
				el->BASEREF(prev); 
	}

	/* Update List length and return element we detached. */
	listLength--;
	return el;
}

/**
 * Frees all the memory used by a list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::empty()
{
	Element *nextToGo = 0, *cur = head;
	
	while (cur != 0)
	{
		nextToGo = cur->BASEREF(next);
		delete cur;
		cur = nextToGo;
	}
	head = tail = 0;
	listLength = 0;
}

/**
 * Abandon all elements in the list.
 */
template <DLMEL_TEMPDEF> void DList<DLMEL_TEMPUSE>::abandon()
{
	head = tail = 0;
	listLength = 0;
}

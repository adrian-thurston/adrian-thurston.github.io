/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include <string.h>
#include "byteset.h"

void ByteSet::Empty()
{
	data[0] = data[1] = data[2] = data[3] = 0;
	data[4] = data[5] = data[6] = data[7] = 0;
}

void ByteSet::SetCharSet(CharSet cs)
{
	switch (cs) {
	case ascii:
		data[0] = 0xffffffff;
		data[1] = 0xffffffff;
		data[2] = 0xffffffff;
		data[3] = 0xffffffff;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case extend:
		data[0] = 0xffffffff;
		data[1] = 0xffffffff;
		data[2] = 0xffffffff;
		data[3] = 0xffffffff;
		data[4] = 0xffffffff;
		data[5] = 0xffffffff;
		data[6] = 0xffffffff;
		data[7] = 0xffffffff;
		break;
	case alnum:
		data[0] = 0x00000000;
		data[1] = 0x0000ffc0;
		data[2] = 0x7fffffe0;
		data[3] = 0x7fffffe0;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case alpha:
		data[0] = 0x00000000;
		data[1] = 0x00000000;
		data[2] = 0x7fffffe0;
		data[3] = 0x7fffffe0;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case cntrl:
		data[0] = 0xffdfffff;
		data[1] = 0x00000000;
		data[2] = 0x00000000;
		data[3] = 0x00000001;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case digit:
		data[0] = 0x00000000;
		data[1] = 0x0000ffc0;
		data[2] = 0x00000000;
		data[3] = 0x00000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case graph:
		data[0] = 0x00000000;
		data[1] = 0x7fffffff;
		data[2] = 0xffffffff;
		data[3] = 0xfffffffe;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case lower:
		data[0] = 0x00000000;
		data[1] = 0x00000000;
		data[2] = 0x00000000;
		data[3] = 0x7fffffe0;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case print:
		data[0] = 0x00000000;
		data[1] = 0xffffffff;
		data[2] = 0xffffffff;
		data[3] = 0xfffffffe;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case punct:
		data[0] = 0x00000000;
		data[1] = 0x7fff003f;
		data[2] = 0x8000001f;
		data[3] = 0x8000001e;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case space:
		data[0] = 0x005c0000;
		data[1] = 0x80000000;
		data[2] = 0x00000000;
		data[3] = 0x00000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case upper:
		data[0] = 0x00000000;
		data[1] = 0x00000000;
		data[2] = 0x7fffffe0;
		data[3] = 0x00000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	case xdigit:
		data[0] = 0x00000000;
		data[1] = 0x0000ffc0;
		data[2] = 0x7e000000;
		data[3] = 0x7e000000;
		data[4] = 0x00000000;
		data[5] = 0x00000000;
		data[6] = 0x00000000;
		data[7] = 0x00000000;
		break;
	}
}

void ByteSet::UnsetCharSet(CharSet cs)
{
	switch (cs) {
	case ascii:
		data[0] &= ~0xffffffff;
		data[1] &= ~0xffffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xffffffff;
		break;
	case extend:
		data[0] &= ~0xffffffff;
		data[1] &= ~0xffffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xffffffff;
		data[4] &= ~0xffffffff;
		data[5] &= ~0xffffffff;
		data[6] &= ~0xffffffff;
		data[7] &= ~0xffffffff;
		break;
	case alnum:
		data[0] &= ~0x00000000;
		data[1] &= ~0x0000ffc0;
		data[2] &= ~0x7fffffe0;
		data[3] &= ~0x7fffffe0;
		break;
	case alpha:
		data[0] &= ~0x00000000;
		data[1] &= ~0x00000000;
		data[2] &= ~0x7fffffe0;
		data[3] &= ~0x7fffffe0;
		break;
	case cntrl:
		data[0] &= ~0xffdfffff;
		data[1] &= ~0x00000000;
		data[2] &= ~0x00000000;
		data[3] &= ~0x00000001;
		break;
	case digit:
		data[0] &= ~0x00000000;
		data[1] &= ~0x0000ffc0;
		data[2] &= ~0x00000000;
		data[3] &= ~0x00000000;
		break;
	case graph:
		data[0] &= ~0x00000000;
		data[1] &= ~0x7fffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xfffffffe;
		break;
	case lower:
		data[0] &= ~0x00000000;
		data[1] &= ~0x00000000;
		data[2] &= ~0x00000000;
		data[3] &= ~0x7fffffe0;
		break;
	case print:
		data[0] &= ~0x00000000;
		data[1] &= ~0xffffffff;
		data[2] &= ~0xffffffff;
		data[3] &= ~0xfffffffe;
		break;
	case punct:
		data[0] &= ~0x00000000;
		data[1] &= ~0x7fff003f;
		data[2] &= ~0x8000001f;
		data[3] &= ~0x8000001e;
		break;
	case space:
		data[0] &= ~0x005c0000;
		data[1] &= ~0x80000000;
		data[2] &= ~0x00000000;
		data[3] &= ~0x00000000;
		break;
	case upper:
		data[0] &= ~0x00000000;
		data[1] &= ~0x00000000;
		data[2] &= ~0x7fffffe0;
		data[3] &= ~0x00000000;
		break;
	case xdigit:
		data[0] &= ~0x00000000;
		data[1] &= ~0x0000ffc0;
		data[2] &= ~0x7e000000;
		data[3] &= ~0x7e000000;
		break;
	}
}

void ByteSet::ToggleCharSet(CharSet cs)
{
	switch (cs) {
	case ascii:
		data[0] ^= 0xffffffff;
		data[1] ^= 0xffffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xffffffff;
		break;
	case extend:
		data[0] ^= 0xffffffff;
		data[1] ^= 0xffffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xffffffff;
		data[4] ^= 0xffffffff;
		data[5] ^= 0xffffffff;
		data[6] ^= 0xffffffff;
		data[7] ^= 0xffffffff;
		break;
	case alnum:
		data[0] ^= 0x00000000;
		data[1] ^= 0x0000ffc0;
		data[2] ^= 0x7fffffe0;
		data[3] ^= 0x7fffffe0;
		break;
	case alpha:
		data[0] ^= 0x00000000;
		data[1] ^= 0x00000000;
		data[2] ^= 0x7fffffe0;
		data[3] ^= 0x7fffffe0;
		break;
	case cntrl:
		data[0] ^= 0xffdfffff;
		data[1] ^= 0x00000000;
		data[2] ^= 0x00000000;
		data[3] ^= 0x00000001;
		break;
	case digit:
		data[0] ^= 0x00000000;
		data[1] ^= 0x0000ffc0;
		data[2] ^= 0x00000000;
		data[3] ^= 0x00000000;
		break;
	case graph:
		data[0] ^= 0x00000000;
		data[1] ^= 0x7fffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xfffffffe;
		break;
	case lower:
		data[0] ^= 0x00000000;
		data[1] ^= 0x00000000;
		data[2] ^= 0x00000000;
		data[3] ^= 0x7fffffe0;
		break;
	case print:
		data[0] ^= 0x00000000;
		data[1] ^= 0xffffffff;
		data[2] ^= 0xffffffff;
		data[3] ^= 0xfffffffe;
		break;
	case punct:
		data[0] ^= 0x00000000;
		data[1] ^= 0x7fff003f;
		data[2] ^= 0x8000001f;
		data[3] ^= 0x8000001e;
		break;
	case space:
		data[0] ^= 0x005c0000;
		data[1] ^= 0x80000000;
		data[2] ^= 0x00000000;
		data[3] ^= 0x00000000;
		break;
	case upper:
		data[0] ^= 0x00000000;
		data[1] ^= 0x00000000;
		data[2] ^= 0x7fffffe0;
		data[3] ^= 0x00000000;
		break;
	case xdigit:
		data[0] ^= 0x00000000;
		data[1] ^= 0x0000ffc0;
		data[2] ^= 0x7e000000;
		data[3] ^= 0x7e000000;
		break;
	}
}

void ByteSet::SetBytes(byte *set, int len)
{
	/* Skip the open bracket */
	for (int i = 0; i < len; i++, set++)
		SetByte(*set);
}

void ByteSet::UnsetBytes(byte *set, int len)
{
	/* Skip the open bracket */
	for (int i = 0; i < len; i++, set++)
		UnsetByte(*set);
}

void ByteSet::ToggleBytes(byte *set, int len)
{
	/* Skip the open bracket */
	for (int i = 0; i < len; i++, set++)
		ToggleByte(*set);
}


void ByteSet::PrintThoseSet()
{
	for(uint i = 0; i < 256; i++)
	{
		if ( data[i >> 5] & (0x80000000 >> (i & 0x1f)) )
			printf("%i ", i);
	}
	printf(": %x %x %x %x %x %x %x %x\n", data[0], data[1],
	       data[2], data[3], data[4], data[5], data[6], data[7]);
}

#if 0
// Scan set that looks like "{lkadj\}\00}"
	/* Skip the open bracket */
	byte *pc = (byte*) (set+1);
	while ( *pc != '}' )
	{
		if (*pc == '\\')
		{
			pc++;
			switch (*pc) {
				case '}':  SetByte('}'); pc++; break;
				case '\\': SetByte('\\'); pc++; break;
				case 'a':  SetByte('\a'); pc++; break;
				case 'b':  SetByte('\b'); pc++; break;
				case 't':  SetByte('\t'); pc++; break;
				case 'n':  SetByte('\n'); pc++; break;
				case 'v':  SetByte('\v'); pc++; break;
				case 'f':  SetByte('\f'); pc++; break;
				case 'r':  SetByte('\r'); pc++; break;
				case '\n': pc++; break;

				/* Default is an octal num. */
				default:
				{
					/* Set a 4 byte string as the octal number. */
			 		char stringOct[4] = { pc[0], pc[1], pc[2], 0 };

					/* Scan it. */
					uint oct;
					sscanf(stringOct, "%o", &oct);

					/* Set the octal char. */
					SetByte(oct);
					pc += 3;
				}
				break;
			}
		}
		else
		{
			SetByte(*pc);
			pc++;
		}
	}
}

void ByteSet::UnsetSet(byte *set)
{
	/* Skip the open bracket */
	byte *pc = (byte*) (set+1);
	while ( *pc != '}' )
	{
		if (*pc == '\\')
		{
			pc++;
			switch (*pc) {
				case '}':  UnsetByte('}'); pc++; break;
				case '\\': UnsetByte('\\'); pc++; break;
				case 'a':  UnsetByte('\a'); pc++; break;
				case 'b':  UnsetByte('\b'); pc++; break;
				case 't':  UnsetByte('\t'); pc++; break;
				case 'n':  UnsetByte('\n'); pc++; break;
				case 'v':  UnsetByte('\v'); pc++; break;
				case 'f':  UnsetByte('\f'); pc++; break;
				case 'r':  UnsetByte('\r'); pc++; break;
				case '\n': pc++; break;

				/* Default is an octal num. */
				default:
				{
					/* Set a 4 byte string as the octal number. */
			 		char stringOct[4] = { pc[0], pc[1], pc[2], 0 };

					/* Scan it. */
					uint oct;
					sscanf(stringOct, "%o", &oct);

					/* Set the octal char. */
					SetByte(oct);
					pc += 3;
				}
				break;
			}
		}
		else
		{
			UnsetByte(*pc);
			pc++;
		}
	}
}
#endif


/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_DEQUE_H
#define _AAPL_DEQUE_H

#include "support.h"
#include "dlist.h"

/**
 * A chunk of data in a queue
 */
struct DequeChunk : public DListEl<DequeChunk>
{
	DequeChunk(int len)
		{ data = new byte[len]; }

	~DequeChunk()
		{ delete[] data; }

	byte *data;
};

/**
 * Double ended queue for binary unstructrued data. 
 */
class Deque : public DList<DequeChunk>
{
public:
	Deque(int chunkLength = 1024);
	~Deque();
	
	void Empty();
	
	/* Appends data to one end of the deque. */
	void AppendRight(void *data, int len);
	void AppendRight(char *data);
	void AppendLeft(void *data, int len);
	void AppendLeft(char *data);

	int RemoveLeft(void *buffer, int len);
	int RemoveRight(void *buffer, int len);

	int RemoveLeft(int n);
	int RemoveRight(int n);

	/* Copies len bytes from the front of the fifo. Does
	 * not remove and data. Returns the amount of data copied. */
	int PeekLeft(void *buffer, int len);
	int PeekRight(void *buffer, int len);

	int KillLeft(int len);
	int KillRight(int len);

	int SizeLeftChunk();
	int SizeRightChunk();
	byte *PtrLeftChunk();
	byte *PtrRightChunk();

	DequeChunk *NewChunk();
	void SpareAChunk( DequeChunk * chunk );


	int dequeLength;      /* Length of the data in the deque. */
	int chunkLength;      /* The size of allocated chunks. */
	int frontPos, endPos; /* Markers to the front and end of data. */

	DequeChunk *spareChunk;
};

#endif /* _AAPL_DEQUE_H */


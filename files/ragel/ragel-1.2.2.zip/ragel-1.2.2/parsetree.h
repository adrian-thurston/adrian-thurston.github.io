/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _PARSETREE_H
#define _PARSETREE_H

#include "rl.h"
#include "fsm.h"
#include "avlmap.h"
#include "bstmap.h"

#define FUNC_NUM_CLEAR -1

/*********************************************************
 * StringListEl
 *
 * Element in list of actions. Contains the string for the 
 * code to exectute.
 */
struct StringListEl : public DListEl<StringListEl>
{
public:
	StringListEl( char *data ) : data(data) { }
	~StringListEl() { delete[] data; }

	char *data;
};

/************************************************
 * StringList
 *
 * List of string elements. Used for functions and data to go
 * into the fsm struct.
 */
typedef DList<StringListEl> StringList;

extern int curFuncOrdering;

enum AugType {
	start,
	fin,
	all,
	leave,
	clearLeave
};

struct PriorityAug
{
	PriorityAug( ) :
		value(0), type(start) { }
	PriorityAug( int val, AugType type ) :
		value(val), type(type) { }

	int value;
	AugType type;
};


/*******************************************************
 * ParserFunc
 *
 * Structrue represents a function assigned to some FactorWithAug
 * node. The factor with aug will keep an array of these. */
struct ParserFunc
{
	ParserFunc( ) :
		func(0), ordering(0), type(start) { }
	ParserFunc( int func, int ordering, AugType type ) :
		func(func), ordering(0), type(type) { }

	int func;
	int ordering;
	AugType type;
};

/*********************************
 * WalkResult
 */
union WalkResult
{
	WalkResult() {}
	WalkResult(Fsm *fsm) : fsm(fsm) {}
	WalkResult(char *data) : data(data) {}

	Fsm *fsm;
	char *data;
};

struct ExpressionNode;
struct TermNode;
struct FactorWithAugNode;
struct FactorWithRepNode;
struct FactorNode;
struct RangeNode;

typedef AvlMapNode<char*, ExpressionNode*> GraphDictNode;
typedef AvlMap<char*, ExpressionNode*, CmpStr> GraphDict;

/*****************************************************************
 * FuncDict
 */
typedef BstMapEl<char*, int> FuncDictEl;
typedef BstMap<char*, int, CmpStr> FuncDict;

/*****************************************************
 * ParseData
 *
 * Class to wrap up all the items used by a parse of a regular lang.
 */
class ParseData
{
public:
	/* Dictionary of graphs. When done we will lookup "main" */
	GraphDict graphDict;

	/* Dictionary of functions. Lets functions be defined and then 'called'.
	 * They are not really called though, just used. */
	FuncDict funcDict;

	/* List of functions. Will be pasted into a switch statement. */
	StringList funcList;

	/* List of sections of data to add to the fsm struct. */
	StringList dataList;

	/* The func id of the next function. */
	int nextFuncNum;

	/* If a machine is given this is set. */
	bool machineGiven;

	/* Code sections to put before and after the function execute section. */
	StringList initCodeList;

	ParseData();
	~ParseData();
};

/* Initialize a graph dict with the basic fsms. */
void InitGraphDict( GraphDict *graphDict );

/***********************************************************
 * ExpressionNode
 */
struct ExpressionNode
{
	enum ExpressionNodeType { Or, Intersect, Subtract, Term, Builtin };

	ExpressionNode( ExpressionNode *expression, TermNode *term, 
		ExpressionNodeType type) : expression(expression), 
		term(term), builtin(builtin), type(type) { }

	ExpressionNode( TermNode *term ) :
		expression(0), term(term), builtin(builtin), type(Term) { }
	
	ExpressionNode( Fsm *builtin ) :
		expression(0), term(0), builtin(builtin), type(Builtin) { }

	~ExpressionNode();

	Fsm *Walk();

	ExpressionNode *expression;
	TermNode *term;
	Fsm *builtin;
	ExpressionNodeType type;
};

/***************************************************************88
 * TermNode
 */
struct TermNode 
{
	enum TermNodeType { Concat, FactorWithAug };

	TermNode( bool leavingFsm, TermNode *term, FactorWithAugNode *factorWithAug ) :
		leavingFsm(leavingFsm), term(term), 
		factorWithAug(factorWithAug), type(Concat) { }

	TermNode( FactorWithAugNode *factorWithAug ) :
		leavingFsm(true), term(0), 
		factorWithAug(factorWithAug), type(FactorWithAug) { }
	
	~TermNode();

	Fsm *Walk();

	bool leavingFsm;
	TermNode *term;
	FactorWithAugNode *factorWithAug;
	TermNodeType type;
};

/*****************************************************************
 * FactorWithAugNode
 */
struct FactorWithAugNode
{
	FactorWithAugNode(FactorWithRepNode *factorWithRep ) :
		funcs(), priorityAugs(), factorWithRep(factorWithRep) { }

	~FactorWithAugNode();

	Fsm *Walk();

	Vector<ParserFunc> funcs;
	Vector<PriorityAug> priorityAugs;

	FactorWithRepNode *factorWithRep;
	FactorWithAugNode *factorWithAug;
};

/**********************************************************
 * FactorWithRepNode
 */
struct FactorWithRepNode
{
	enum FactorWithRepType
		{ Star, Optional, Plus, Negate, Range };

	FactorWithRepNode( bool leavingFsm, FactorWithRepNode *factorWithRep,
			FactorWithRepType type ) :
		leavingFsm(leavingFsm), factorWithRep(factorWithRep), 
		range(0), type(type) { }

	FactorWithRepNode( RangeNode *range ) :
		leavingFsm(true), factorWithRep(0), range(range), type(Range) { }

	~FactorWithRepNode();

	Fsm *Walk();

	bool leavingFsm;
	FactorWithRepNode *factorWithRep;
	RangeNode *range;
	FactorWithRepType type;
};

/**********************************************************
 * RangeNode
 */
struct RangeNode 
{
	enum RangeType { Factor, Range };

	RangeNode( FactorNode *factor ) : 
		factor(factor), type(Factor) { }

	RangeNode( int lower, int upper ) : 
		lower(lower), upper(upper), type(Range) { }
	
	~RangeNode();

	Fsm *Walk();

	FactorNode *factor;
	int lower, upper;
	RangeType type;
};


/**********************************************************
 * FactorNode
 */
struct FactorNode 
{
	enum FactorType { LiteralFsm, Expression, LookupExpression };

	FactorNode( Fsm *fsm ) :
		fsm(fsm), expression(0), type(LiteralFsm) { }

	FactorNode( ExpressionNode *expression, FactorType type ) :
		fsm(0), expression(expression), type(type) {}

	~FactorNode();

	Fsm *Walk();

	Fsm *fsm;
	ExpressionNode *expression;
	FactorType type;
};


#endif /* _PARSETREE_H */

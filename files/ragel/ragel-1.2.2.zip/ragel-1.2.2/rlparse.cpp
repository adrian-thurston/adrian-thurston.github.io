/* A Bison parser, made from rlparse.y
   by GNU bison 1.35.  */

#define YYBISON 1  /* Identify Bison output.  */

#define yyparse rlparse
#define yylex rllex
#define yyerror rlerror
#define yylval rllval
#define yychar rlchar
#define yydebug rldebug
#define yynerrs rlnerrs
# define	PP_Literal	257
# define	PP_Integer	258
# define	PP_Word	259
# define	PP_Comment	260
# define	PP_Character	261
# define	PP_Whitespace	262
# define	PP_Section	263
# define	RL_Integer	264
# define	RL_Hex	265
# define	RL_Word	266
# define	RL_Literal	267
# define	RL_DoubleDot	268
# define	RL_ReLiteralSlash	269
# define	RL_ReLiteralChar	270
# define	RL_ReLiteralOpen	271
# define	RL_ReLiteralOpenNeg	272
# define	RL_ReLiteralClose	273
# define	RL_ReLiteralDot	274
# define	RL_ReLiteralStar	275
# define	RL_ReLiteralSet	276
# define	RL_OrLiteral	277
# define	RL_Builtin	278
# define	RL_Data	279
# define	RL_Func	280
# define	RL_Init	281
# define	RL_Clear	282

#line 22 "rlparse.y"


#include <stdlib.h>
//#include <unistd.h>
#include "rl.h"
#include "fsm.h"
#include "parsetree.h"

/* Generate a fsm from a graph dict. In main.cc. */
void GenerateFsm( char *fsmName, ParseData *parseData );

/* Ids to use for builtin functions. */
int builtinNextId = 1;

/* The parse data. The parser collects the things that it parses in
 * the data structures in here. */
ParseData *parseData;

/* Condensing after an operator. */
void AfterOpCondense(Fsm *fsm);


#line 45 "rlparse.y"
#ifndef YYSTYPE
typedef union {
	char *data;
	char chr;
	int integer;
	TermNode *term;
	FactorWithRepNode *factorWithRep;
	FactorWithAugNode *factorWithAug;
	FactorNode *factor;
	RangeNode *range;
	ExpressionNode *expression;
	int pAug;
	int funcId;
	AugType augType;
	Fsm *fsm;
	RegExpSet regExpSet;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
#ifndef YYDEBUG
# define YYDEBUG 0
#endif



#define	YYFINAL		111
#define	YYFLAG		-32768
#define	YYNTBASE	46

/* YYTRANSLATE(YYLEX) -- Bison token number corresponding to YYLEX. */
#define YYTRANSLATE(x) ((unsigned)(x) <= 282 ? yytranslate[x] : 73)

/* YYTRANSLATE[YYLEX] -- Bison token number corresponding to YYLEX. */
static const char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    32,     2,     2,    39,    38,    42,     2,
      33,    34,    29,    31,     2,    40,    43,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    37,    35,
       2,    36,    44,    30,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,    45,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,    41,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28
};

#if YYDEBUG
static const short yyprhs[] =
{
       0,     0,     2,     5,     6,     8,    10,    12,    14,    16,
      18,    20,    22,    27,    29,    32,    34,    36,    38,    40,
      42,    45,    49,    53,    58,    62,    66,    70,    72,    75,
      79,    84,    86,    90,    94,    98,   100,   103,   106,   108,
     110,   112,   114,   116,   118,   120,   122,   125,   129,   132,
     135,   139,   142,   144,   148,   150,   152,   154,   156,   158,
     160,   164,   166,   168,   170,   174,   177,   178,   181,   183,
     187,   191,   193,   195,   198,   199,   201
};
static const short yyrhs[] =
{
      47,     0,    47,    48,     0,     0,    49,     0,    50,     0,
       3,     0,     4,     0,     5,     0,     6,     0,     7,     0,
       8,     0,     9,    51,    52,     9,     0,    12,     0,    52,
      53,     0,    53,     0,    57,     0,    55,     0,    56,     0,
      54,     0,    27,    24,     0,    25,    24,    35,     0,    26,
      12,    24,     0,    12,    36,    58,    35,     0,    58,    41,
      59,     0,    58,    42,    59,     0,    58,    40,    59,     0,
      59,     0,    59,    60,     0,    59,    43,    60,     0,    59,
      43,    45,    60,     0,    60,     0,    60,    62,    63,     0,
      60,    62,    61,     0,    60,    38,    32,     0,    64,     0,
      40,    10,     0,    31,    10,     0,    10,     0,    37,     0,
      38,     0,    39,     0,    44,     0,    12,     0,    24,     0,
      28,     0,    29,    64,     0,    29,    45,    64,     0,    30,
      64,     0,    31,    64,     0,    31,    45,    64,     0,    32,
      64,     0,    65,     0,    66,    14,    66,     0,    67,     0,
      13,     0,    10,     0,    11,     0,    13,     0,    23,     0,
      15,    68,    15,     0,    10,     0,    11,     0,    12,     0,
      33,    58,    34,     0,    68,    69,     0,     0,    70,    21,
       0,    70,     0,    17,    71,    19,     0,    18,    71,    19,
       0,    20,     0,    16,     0,    71,    72,     0,     0,    16,
       0,    22,     0
};

#endif

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined. */
static const short yyrline[] =
{
       0,   116,   117,   118,   125,   129,   135,   135,   136,   137,
     138,   139,   147,   157,   168,   169,   174,   175,   176,   177,
     181,   188,   197,   214,   226,   229,   232,   235,   245,   248,
     251,   254,   262,   266,   270,   274,   281,   284,   287,   295,
     296,   297,   298,   305,   322,   330,   340,   344,   348,   352,
     356,   360,   364,   370,   377,   383,   391,   401,   417,   423,
     444,   448,   458,   468,   481,   490,   500,   507,   511,   519,
     523,   529,   532,   541,   550,   559,   563
};
#endif


#if (YYDEBUG) || defined YYERROR_VERBOSE

/* YYTNAME[TOKEN_NUM] -- String name of the token TOKEN_NUM. */
static const char *const yytname[] =
{
  "$", "error", "$undefined.", "PP_Literal", "PP_Integer", "PP_Word", 
  "PP_Comment", "PP_Character", "PP_Whitespace", "PP_Section", 
  "RL_Integer", "RL_Hex", "RL_Word", "RL_Literal", "RL_DoubleDot", 
  "RL_ReLiteralSlash", "RL_ReLiteralChar", "RL_ReLiteralOpen", 
  "RL_ReLiteralOpenNeg", "RL_ReLiteralClose", "RL_ReLiteralDot", 
  "RL_ReLiteralStar", "RL_ReLiteralSet", "RL_OrLiteral", "RL_Builtin", 
  "RL_Data", "RL_Func", "RL_Init", "RL_Clear", "'*'", "'?'", "'+'", "'!'", 
  "'('", "')'", "';'", "'='", "':'", "'%'", "'$'", "'-'", "'|'", "'&'", 
  "'.'", "'>'", "'^'", "input", "Sections", "SectionItem", "NonFsmAny", 
  "FsmSpec", "FsmName", "StatementList", "Statement", "InitSpec", 
  "DataSpec", "FuncSpec", "RLAssignment", "Expression", "Term", 
  "FactorWithAug", "PriorityAug", "AugType", "FunctionCall", 
  "FactorWithRep", "Range", "RangeLit", "Factor", "RegularExpr", 
  "RegularExprItem", "RegularExprChar", "RegularExprOrData", 
  "RegularExprOrChar", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives. */
static const short yyr1[] =
{
       0,    46,    47,    47,    48,    48,    49,    49,    49,    49,
      49,    49,    50,    51,    52,    52,    53,    53,    53,    53,
      54,    55,    56,    57,    58,    58,    58,    58,    59,    59,
      59,    59,    60,    60,    60,    60,    61,    61,    61,    62,
      62,    62,    62,    63,    63,    63,    64,    64,    64,    64,
      64,    64,    64,    65,    65,    66,    66,    66,    67,    67,
      67,    67,    67,    67,    67,    68,    68,    69,    69,    70,
      70,    70,    70,    71,    71,    72,    72
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN. */
static const short yyr2[] =
{
       0,     1,     2,     0,     1,     1,     1,     1,     1,     1,
       1,     1,     4,     1,     2,     1,     1,     1,     1,     1,
       2,     3,     3,     4,     3,     3,     3,     1,     2,     3,
       4,     1,     3,     3,     3,     1,     2,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     3,     2,     2,
       3,     2,     1,     3,     1,     1,     1,     1,     1,     1,
       3,     1,     1,     1,     3,     2,     0,     2,     1,     3,
       3,     1,     1,     2,     0,     1,     1
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error. */
static const short yydefact[] =
{
       3,     1,     6,     7,     8,     9,    10,    11,     0,     2,
       4,     5,    13,     0,     0,     0,     0,     0,     0,    15,
      19,    17,    18,    16,     0,     0,     0,    20,    12,    14,
      61,    62,    63,    58,    66,    59,     0,     0,     0,     0,
       0,     0,    27,    31,    35,    52,     0,    54,    21,    22,
       0,     0,    46,    48,     0,    49,    51,     0,    23,     0,
       0,     0,     0,    28,    39,    40,    41,    42,     0,     0,
      60,    72,    74,    74,    71,    65,    68,    47,    50,    64,
      26,    24,    25,     0,    29,    34,    38,    43,    44,    45,
       0,     0,    33,    32,    56,    57,    55,    53,     0,     0,
      67,    30,    37,    36,    75,    69,    76,    73,    70,     0,
       0,     0
};

static const short yydefgoto[] =
{
     109,     1,     9,    10,    11,    13,    18,    19,    20,    21,
      22,    23,    41,    42,    43,    92,    68,    93,    44,    45,
      46,    47,    50,    75,    76,    98,   107
};

static const short yypact[] =
{
  -32768,   132,-32768,-32768,-32768,-32768,-32768,-32768,   -11,-32768,
  -32768,-32768,-32768,    58,   -28,     9,     2,    11,     1,-32768,
  -32768,-32768,-32768,-32768,   101,   -19,    12,-32768,-32768,-32768,
      29,    47,-32768,    53,-32768,-32768,    -8,   101,    19,   101,
     101,    51,    67,    65,-32768,-32768,    54,-32768,-32768,-32768,
     103,   101,-32768,-32768,   101,-32768,-32768,   -23,-32768,   101,
     101,   101,    43,    65,-32768,    33,-32768,-32768,    77,   115,
  -32768,-32768,-32768,-32768,-32768,-32768,    48,-32768,-32768,-32768,
      67,    67,    67,   101,    65,-32768,-32768,-32768,-32768,-32768,
      61,    71,-32768,-32768,-32768,-32768,-32768,-32768,   -10,    41,
  -32768,    65,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    94,
      95,-32768
};

static const short yypgoto[] =
{
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,    88,-32768,-32768,
  -32768,-32768,    75,    83,   -42,-32768,-32768,-32768,     8,-32768,
      38,-32768,-32768,-32768,-32768,    49,-32768
};


#define	YYLAST		144


static const short yytable[] =
{
      63,    12,    30,    31,    32,    33,   104,    34,    24,   105,
      28,    79,   106,    14,    26,    35,    48,    59,    60,    61,
      84,    36,    37,    38,    39,    40,    15,    16,    17,    30,
      31,    32,    33,    25,    34,    27,    49,    51,    63,    63,
      63,   101,    35,   -56,    52,    53,    55,    56,    36,    37,
      38,    39,    40,    30,    31,    32,    33,   104,    34,    77,
     108,   -57,    78,   106,    54,    85,    35,   -55,    69,   100,
      14,   102,    36,    37,    38,    39,    40,    30,    31,    32,
      33,   103,    34,    15,    16,    17,    58,    86,    83,    87,
      35,    59,    60,    61,   110,   111,    36,    37,    38,    39,
      40,    88,    64,    65,    66,    89,    29,    97,    90,    67,
      62,    30,    31,    32,    33,    57,    34,    91,    70,    71,
      72,    73,    99,    74,    35,    94,    95,     0,    96,     0,
      36,    37,    38,    39,    40,     2,     3,     4,     5,     6,
       7,     8,    80,    81,    82
};

static const short yycheck[] =
{
      42,    12,    10,    11,    12,    13,    16,    15,    36,    19,
       9,    34,    22,    12,    12,    23,    35,    40,    41,    42,
      62,    29,    30,    31,    32,    33,    25,    26,    27,    10,
      11,    12,    13,    24,    15,    24,    24,    45,    80,    81,
      82,    83,    23,    14,    36,    37,    38,    39,    29,    30,
      31,    32,    33,    10,    11,    12,    13,    16,    15,    51,
      19,    14,    54,    22,    45,    32,    23,    14,    14,    21,
      12,    10,    29,    30,    31,    32,    33,    10,    11,    12,
      13,    10,    15,    25,    26,    27,    35,    10,    45,    12,
      23,    40,    41,    42,     0,     0,    29,    30,    31,    32,
      33,    24,    37,    38,    39,    28,    18,    69,    31,    44,
      43,    10,    11,    12,    13,    40,    15,    40,    15,    16,
      17,    18,    73,    20,    23,    10,    11,    -1,    13,    -1,
      29,    30,    31,    32,    33,     3,     4,     5,     6,     7,
       8,     9,    59,    60,    61
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/bison/bison.simple"

/* Skeleton output parser for bison,

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software
   Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser when
   the %semantic_parser declaration is not specified in the grammar.
   It was written by Richard Stallman by simplifying the hairy parser
   used when %semantic_parser is specified.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

#if ! defined (yyoverflow) || defined (YYERROR_VERBOSE)

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || defined (YYERROR_VERBOSE) */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
# if YYLSP_NEEDED
  YYLTYPE yyls;
# endif
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# if YYLSP_NEEDED
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAX)
# else
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)
# endif

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif


#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).

   When YYLLOC_DEFAULT is run, CURRENT is set the location of the
   first token.  By default, to implement support for ranges, extend
   its range to the last symbol.  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)       	\
   Current.last_line   = Rhs[N].last_line;	\
   Current.last_column = Rhs[N].last_column;
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#if YYPURE
# if YYLSP_NEEDED
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, &yylloc, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval, &yylloc)
#  endif
# else /* !YYLSP_NEEDED */
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval)
#  endif
# endif /* !YYLSP_NEEDED */
#else /* !YYPURE */
# define YYLEX			yylex ()
#endif /* !YYPURE */


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

#ifdef YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif
#endif

#line 315 "/usr/share/bison/bison.simple"


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif

/* YY_DECL_VARIABLES -- depending whether we use a pure parser,
   variables are global, or local to YYPARSE.  */

#define YY_DECL_NON_LSP_VARIABLES			\
/* The lookahead symbol.  */				\
int yychar;						\
							\
/* The semantic value of the lookahead symbol. */	\
YYSTYPE yylval;						\
							\
/* Number of parse errors so far.  */			\
int yynerrs;

#if YYLSP_NEEDED
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES			\
						\
/* Location data for the lookahead symbol.  */	\
YYLTYPE yylloc;
#else
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES
#endif


/* If nonreentrant, generate the variables here. */

#if !YYPURE
YY_DECL_VARIABLES
#endif  /* !YYPURE */

int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  /* If reentrant, generate the variables here. */
#if YYPURE
  YY_DECL_VARIABLES
#endif  /* !YYPURE */

  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack. */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;

#if YYLSP_NEEDED
  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
#endif

#if YYLSP_NEEDED
# define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
# define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  YYSIZE_T yystacksize = YYINITDEPTH;


  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
#if YYLSP_NEEDED
  YYLTYPE yyloc;
#endif

  /* When reducing, the number of symbols on the RHS of the reduced
     rule. */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
#if YYLSP_NEEDED
  yylsp = yyls;
#endif
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  */
# if YYLSP_NEEDED
	YYLTYPE *yyls1 = yyls;
	/* This used to be a conditional around just the two extra args,
	   but that might be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
# else
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);
# endif
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
# if YYLSP_NEEDED
	YYSTACK_RELOCATE (yyls);
# endif
# undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
#if YYLSP_NEEDED
      yylsp = yyls + yysize - 1;
#endif

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

#if YYDEBUG
     /* We have to keep this `#if YYDEBUG', since we use variables
	which are defined only if `YYDEBUG' is set.  */
      if (yydebug)
	{
	  YYFPRINTF (stderr, "Next token is %d (%s",
		     yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise
	     meaning of a token, for further debugging info.  */
# ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
# endif
	  YYFPRINTF (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to the semantic value of
     the lookahead token.  This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

#if YYLSP_NEEDED
  /* Similarly for the default location.  Let the user run additional
     commands if for instance locations are ranges.  */
  yyloc = yylsp[1-yylen];
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
#endif

#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] > 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  switch (yyn) {

case 2:
#line 118 "rlparse.y"
{ ;
    break;}
case 3:
#line 119 "rlparse.y"
{ ;
    break;}
case 4:
#line 126 "rlparse.y"
{
		// Write the data out to the header. */
		*outputStream << yyvsp[0].data;
	;
    break;}
case 12:
#line 148 "rlparse.y"
{
		// Process the fsm.
		GenerateFsm( yyvsp[-2].data, parseData );
		delete parseData;
	;
    break;}
case 13:
#line 158 "rlparse.y"
{
		// Take this opportunity to new up everything
		// necessary to process the fsm
		parseData = new ParseData();
		yyval.data = yyvsp[0].data;
	;
    break;}
case 20:
#line 182 "rlparse.y"
{
	// Put the code on the init code list. 
		parseData->initCodeList.append( new StringListEl( yyvsp[0].data ) );
	;
    break;}
case 21:
#line 189 "rlparse.y"
{
		// Put the spec for the data on the list. Note that we use
		// a func list el but it is data.
		parseData->dataList.append( new StringListEl( yyvsp[-1].data ) );
	;
    break;}
case 22:
#line 198 "rlparse.y"
{
		if ( parseData->funcDict.insert( yyvsp[-1].data,
						parseData->nextFuncNum ) ) {
			// Add the function to the list of functions.
			parseData->funcList.append( new StringListEl( yyvsp[0].data ) );

			// Used up a function number.
			parseData->nextFuncNum += 1;
		}
		else {
			fprintf( stderr, "%s:%i: warning: func \"%s\" "
				"already defined\n", inputFile, rlCurLine, yyvsp[-1].data);
		}
	;
    break;}
case 23:
#line 215 "rlparse.y"
{
		if ( ! parseData->graphDict.insert(yyvsp[-3].data, yyvsp[-1].expression) ) {
			fprintf( stderr, "%s:%i: warning: variable \"%s\" "
   		         "already defined\n", inputFile, rlCurLine, yyvsp[-3].data);
		}
		parseData->machineGiven = true;
	;
    break;}
case 24:
#line 227 "rlparse.y"
{
		yyval.expression = new ExpressionNode( yyvsp[-2].expression, yyvsp[0].term, ExpressionNode::Or );
	;
    break;}
case 25:
#line 230 "rlparse.y"
{
		yyval.expression = new ExpressionNode( yyvsp[-2].expression, yyvsp[0].term, ExpressionNode::Intersect );
	;
    break;}
case 26:
#line 233 "rlparse.y"
{
		yyval.expression = new ExpressionNode( yyvsp[-2].expression, yyvsp[0].term, ExpressionNode::Subtract );
	;
    break;}
case 27:
#line 236 "rlparse.y"
{
		yyval.expression = new ExpressionNode( yyvsp[0].term );
	;
    break;}
case 28:
#line 246 "rlparse.y"
{
		yyval.term = new TermNode( true, yyvsp[-1].term, yyvsp[0].factorWithAug );
	;
    break;}
case 29:
#line 249 "rlparse.y"
{
		yyval.term = new TermNode( true, yyvsp[-2].term, yyvsp[0].factorWithAug );
	;
    break;}
case 30:
#line 252 "rlparse.y"
{
		yyval.term = new TermNode( false, yyvsp[-3].term, yyvsp[0].factorWithAug );
	;
    break;}
case 31:
#line 255 "rlparse.y"
{
		yyval.term = new TermNode( yyvsp[0].factorWithAug );
	;
    break;}
case 32:
#line 263 "rlparse.y"
{
		yyval.factorWithAug = yyvsp[-2].factorWithAug;
		yyval.factorWithAug->funcs.append( ParserFunc( yyvsp[0].funcId, 0, yyvsp[-1].augType ) );
	;
    break;}
case 33:
#line 267 "rlparse.y"
{
		yyval.factorWithAug = yyvsp[-2].factorWithAug;
		yyval.factorWithAug->priorityAugs.append( PriorityAug( yyvsp[0].pAug, yyvsp[-1].augType ) );
	;
    break;}
case 34:
#line 271 "rlparse.y"
{
		yyval.factorWithAug = yyvsp[-2].factorWithAug;
		yyval.factorWithAug->priorityAugs.append( PriorityAug( 0, clearLeave ) );
	;
    break;}
case 35:
#line 275 "rlparse.y"
{
		yyval.factorWithAug = new FactorWithAugNode( yyvsp[0].factorWithRep );
	;
    break;}
case 36:
#line 282 "rlparse.y"
{
		yyval.pAug = -1 * atoi( yyvsp[0].data );
	;
    break;}
case 37:
#line 285 "rlparse.y"
{
		yyval.pAug = atoi( yyvsp[0].data );
	;
    break;}
case 38:
#line 288 "rlparse.y"
{
		yyval.pAug = atoi( yyvsp[0].data );
	;
    break;}
case 39:
#line 296 "rlparse.y"
{ yyval.augType = fin; ;
    break;}
case 40:
#line 297 "rlparse.y"
{ yyval.augType = leave; ;
    break;}
case 41:
#line 298 "rlparse.y"
{ yyval.augType = all; ;
    break;}
case 42:
#line 299 "rlparse.y"
{ yyval.augType = start; ;
    break;}
case 43:
#line 306 "rlparse.y"
{
		// Set the name in the funcDict.
		char *funcName = yyvsp[0].data;
		int func;
		FuncDictEl *fdel = parseData->funcDict.find( funcName );
		if ( fdel != 0 ) {
			func = fdel->value;
		}
		else {
			fprintf( stderr, "%s:%i: warning: action lookup"
				"of \"%s\" failed. using null action\n",
				inputFile, rlCurLine, yyvsp[0].data );
			func = 0;
		}
		// Pass up the function name;
		yyval.funcId = func;
	;
    break;}
case 44:
#line 323 "rlparse.y"
{
		// Add the function to the list of functions.
		parseData->funcList.append( new StringListEl( yyvsp[0].data ) );

		// Pass up the builtin name.
		yyval.funcId = parseData->nextFuncNum;
		parseData->nextFuncNum += 1;
	;
    break;}
case 45:
#line 331 "rlparse.y"
{
		// This is a clear action, Don't set the action, clear
		// the actions instead.
		yyval.funcId = FUNC_NUM_CLEAR;
	;
    break;}
case 46:
#line 341 "rlparse.y"
{
		yyval.factorWithRep = new FactorWithRepNode( 
					true, yyvsp[0].factorWithRep, FactorWithRepNode::Star );
	;
    break;}
case 47:
#line 345 "rlparse.y"
{
		yyval.factorWithRep = new FactorWithRepNode( 
					false, yyvsp[0].factorWithRep, FactorWithRepNode::Star );
	;
    break;}
case 48:
#line 349 "rlparse.y"
{
		yyval.factorWithRep = new FactorWithRepNode( 
					true, yyvsp[0].factorWithRep, FactorWithRepNode::Optional );
	;
    break;}
case 49:
#line 353 "rlparse.y"
{
		yyval.factorWithRep = new FactorWithRepNode( 
					true, yyvsp[0].factorWithRep, FactorWithRepNode::Plus );
	;
    break;}
case 50:
#line 357 "rlparse.y"
{
		yyval.factorWithRep = new FactorWithRepNode( 
					false, yyvsp[0].factorWithRep, FactorWithRepNode::Plus );
	;
    break;}
case 51:
#line 361 "rlparse.y"
{
		yyval.factorWithRep = new FactorWithRepNode(
					true, yyvsp[0].factorWithRep, FactorWithRepNode::Negate );
	;
    break;}
case 52:
#line 365 "rlparse.y"
{
		yyval.factorWithRep = new FactorWithRepNode( yyvsp[0].range );
	;
    break;}
case 53:
#line 371 "rlparse.y"
{
		if ( yyvsp[-2].integer > yyvsp[0].integer ) {
			fprintf( stderr, "%s:%i: warning: range gives null fsm\n",
					inputFile, rlCurLine );
		}
		yyval.range = new RangeNode( yyvsp[-2].integer, yyvsp[0].integer );
	;
    break;}
case 54:
#line 378 "rlparse.y"
{
		yyval.range = new RangeNode( yyvsp[0].factor );
	;
    break;}
case 55:
#line 384 "rlparse.y"
{
		if ( strlen(yyvsp[0].data) != 1 ) {
			fprintf( stderr, "%s:%i: warning: literal used in range is not "
					"of length 1, using 0x%x\n", inputFile, rlCurLine,
					(unsigned char) *(yyvsp[0].data) );
		}
		yyval.integer = (unsigned char) *(yyvsp[0].data);
	;
    break;}
case 56:
#line 393 "rlparse.y"
{
		int intFsm = atoi( yyvsp[0].data );
		// Restrict to byte size, cannot not be negative.
		if ( intFsm >= 256 ) {
			fprintf( stderr, "%s:%i: warning: overflow in byte constant\n",
				inputFile, rlCurLine );
		}
		yyval.integer = intFsm;
	;
    break;}
case 57:
#line 403 "rlparse.y"
{
		int hexFsm = strtoul( yyvsp[0].data, 0, 16 );
		// Restrict to byte size, cannot not be negative.
		if ( hexFsm >= 256 ) {
			fprintf( stderr, "%s:%i: warning: overflow in byte constant\n",
				inputFile, rlCurLine );
		}
		yyval.integer = hexFsm;
	;
    break;}
case 58:
#line 418 "rlparse.y"
{
		if ( *(yyvsp[0].data) == 0 )
			yyval.factor = new FactorNode( Fsm::NullFsm() );
		else
			yyval.factor = new FactorNode( Fsm::ConcatFsm( yyvsp[0].data ) );
	;
    break;}
case 59:
#line 425 "rlparse.y"
{
		if ( *(yyvsp[0].data) == 0 )
			yyval.factor = new FactorNode( Fsm::NullFsm() );
		else {
			char seen[256];
			memset(seen, 0, 256);
			for ( char *p = yyvsp[0].data; *p != 0; ) {
				if ( seen[(unsigned char)*p] ) {
					// Shift over and toast *p.
					memmove(p, p+1, strlen(p+1)+1);
				}
				else {
					// next p, *p is good.
					seen[(unsigned char)*p] = 1;
					p += 1;
				}
			}
			yyval.factor = new FactorNode( Fsm::OrFsm( yyvsp[0].data ) );
		}
	;
    break;}
case 60:
#line 446 "rlparse.y"
{
		yyval.factor = new FactorNode( yyvsp[-1].fsm );
	;
    break;}
case 61:
#line 450 "rlparse.y"
{
		int intFsm = atoi( yyvsp[0].data );
		// Restrict to byte size, cannot not be negative.
		if ( intFsm >= 256 ) {
			fprintf( stderr, "%s:%i: warning: overflow in byte constant\n",
				inputFile, rlCurLine );
		}
		yyval.factor = new FactorNode( Fsm::ConcatFsm( &intFsm, 1 ) );
	;
    break;}
case 62:
#line 460 "rlparse.y"
{
		int hexFsm = strtoul( yyvsp[0].data, 0, 16 );
		// Restrict to byte size, cannot not be negative.
		if ( hexFsm >= 256 ) {
			fprintf( stderr, "%s:%i: warning: overflow in byte constant\n",
				inputFile, rlCurLine );
		}
		yyval.factor = new FactorNode( Fsm::ConcatFsm( &hexFsm, 1 ) );
	;
    break;}
case 63:
#line 470 "rlparse.y"
{
		GraphDictNode *gdNode = parseData->graphDict.find( yyvsp[0].data );
		if ( gdNode != NULL ) {
			yyval.factor = new FactorNode( gdNode->value, FactorNode::LookupExpression );
		}
		else {
			fprintf( stderr, "%s:%i: warning: graph lookup"
				"of \"%s\" failed, using null fsm\n",
				inputFile, rlCurLine, yyvsp[0].data );
			yyval.factor = new FactorNode( Fsm::NullFsm() );
		}
	;
    break;}
case 64:
#line 483 "rlparse.y"
{
		yyval.factor = new FactorNode( yyvsp[-1].expression, FactorNode::Expression );
	;
    break;}
case 65:
#line 491 "rlparse.y"
{
		// concat together, return.
		if ( yyvsp[-1].fsm == 0 ) {
			yyval.fsm = yyvsp[0].fsm;
		}
		else {
			yyvsp[-1].fsm->Concat( yyvsp[0].fsm, false );
			yyval.fsm = yyvsp[-1].fsm;
		}
	;
    break;}
case 66:
#line 501 "rlparse.y"
{
		yyval.fsm = 0;
	;
    break;}
case 67:
#line 508 "rlparse.y"
{
		yyval.fsm = yyvsp[-1].fsm;
		yyval.fsm->Star(false);
	;
    break;}
case 68:
#line 512 "rlparse.y"
{
		yyval.fsm = yyvsp[0].fsm;
	;
    break;}
case 69:
#line 520 "rlparse.y"
{
		yyval.fsm = yyvsp[-1].fsm;
		yyval.fsm->CondenseApproximate();
	;
    break;}
case 70:
#line 524 "rlparse.y"
{
		yyval.fsm = Fsm::DotFsm();
		yyvsp[-1].fsm->CondenseApproximate();
		yyval.fsm->Subtract( yyvsp[-1].fsm );
		yyval.fsm->CondenseApproximate();
	;
    break;}
case 71:
#line 530 "rlparse.y"
{
		yyval.fsm = Fsm::DotFsm();
	;
    break;}
case 72:
#line 533 "rlparse.y"
{
		char str[2] = { yyvsp[0].chr, 0 };
		yyval.fsm = Fsm::ConcatFsm( str );
	;
    break;}
case 73:
#line 542 "rlparse.y"
{
		if ( yyvsp[-1].fsm == 0 ) {
			yyval.fsm = yyvsp[0].fsm;
		}
		else {
			yyvsp[-1].fsm->Or( yyvsp[0].fsm );
			yyval.fsm = yyvsp[-1].fsm;
		}
	;
    break;}
case 74:
#line 551 "rlparse.y"
{
		yyval.fsm = 0;
	;
    break;}
case 75:
#line 560 "rlparse.y"
{
		char str[2] = { yyvsp[0].chr, 0 };
		yyval.fsm = Fsm::ConcatFsm( str );
	;
    break;}
case 76:
#line 564 "rlparse.y"
{
		char buf[256];
		int lower = (unsigned char) yyvsp[0].regExpSet.lower;
		int upper = (unsigned char) yyvsp[0].regExpSet.upper;
		int pos = 0;
		for ( ; lower <= upper; pos += 1, lower += 1 )
			buf[pos] = lower;
		buf[pos] = 0;
		yyval.fsm = Fsm::OrFsm( buf );
	;
    break;}
}

#line 705 "/usr/share/bison/bison.simple"


  yyvsp -= yylen;
  yyssp -= yylen;
#if YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;
#if YYLSP_NEEDED
  *++yylsp = yyloc;
#endif

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[YYTRANSLATE (yychar)]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[YYTRANSLATE (yychar)]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* defined (YYERROR_VERBOSE) */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*--------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action |
`--------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;
      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;


/*-------------------------------------------------------------------.
| yyerrdefault -- current state does not do anything special for the |
| error token.                                                       |
`-------------------------------------------------------------------*/
yyerrdefault:
#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */

  /* If its default is to accept any token, ok.  Otherwise pop it.  */
  yyn = yydefact[yystate];
  if (yyn)
    goto yydefault;
#endif


/*---------------------------------------------------------------.
| yyerrpop -- pop the current state because it cannot handle the |
| error token                                                    |
`---------------------------------------------------------------*/
yyerrpop:
  if (yyssp == yyss)
    YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#if YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "Error: state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

/*--------------.
| yyerrhandle.  |
`--------------*/
yyerrhandle:
  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

/*---------------------------------------------.
| yyoverflowab -- parser overflow comes here.  |
`---------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}
#line 576 "rlparse.y"


void rlerror(char *err)
{
	fprintf(stderr, "%s:%i: %s\n", inputFile, rlCurLine, err);
	unlink(outputFile);
	exit(1);
}

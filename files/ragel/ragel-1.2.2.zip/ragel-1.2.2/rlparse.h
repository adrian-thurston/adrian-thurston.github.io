#ifndef BISON_RLPARSE_HPP
# define BISON_RLPARSE_HPP

#ifndef YYSTYPE
typedef union {
	char *data;
	char chr;
	int integer;
	TermNode *term;
	FactorWithRepNode *factorWithRep;
	FactorWithAugNode *factorWithAug;
	FactorNode *factor;
	RangeNode *range;
	ExpressionNode *expression;
	int pAug;
	int funcId;
	AugType augType;
	Fsm *fsm;
	RegExpSet regExpSet;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	PP_Literal	257
# define	PP_Integer	258
# define	PP_Word	259
# define	PP_Comment	260
# define	PP_Character	261
# define	PP_Whitespace	262
# define	PP_Section	263
# define	RL_Integer	264
# define	RL_Hex	265
# define	RL_Word	266
# define	RL_Literal	267
# define	RL_DoubleDot	268
# define	RL_ReLiteralSlash	269
# define	RL_ReLiteralChar	270
# define	RL_ReLiteralOpen	271
# define	RL_ReLiteralOpenNeg	272
# define	RL_ReLiteralClose	273
# define	RL_ReLiteralDot	274
# define	RL_ReLiteralStar	275
# define	RL_ReLiteralSet	276
# define	RL_OrLiteral	277
# define	RL_Builtin	278
# define	RL_Data	279
# define	RL_Func	280
# define	RL_Init	281
# define	RL_Clear	282


extern YYSTYPE rllval;

#endif /* not BISON_RLPARSE_HPP */

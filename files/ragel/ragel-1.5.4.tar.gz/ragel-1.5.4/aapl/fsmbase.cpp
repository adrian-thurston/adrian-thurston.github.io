/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  Aapl is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 *  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 *  more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Aapl; if not, write to the Free Software Foundation, Inc., 59
 *  Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _RLFSM_FSMBASE_CPP
#define _RLFSM_FSMBASE_CPP

#include <string.h>
#include <assert.h>

/* Simple singly linked list append routine for the fill list. The new state
 * goes to the end of the list. */
template < class State > void FsmMergeData<State>::
		fillListAppend( State *state )
{
	state->alg.next = 0;

	if ( stfillHead == 0 ) {
		/* List is empty, state becomes head and tail. */
		stfillHead = state;
		stfillTail = state;
	}
	else {
		/* List is not empty, state goes after last element. */
		stfillTail->alg.next = state;
		stfillTail = state;
	}
}

/* Default graph constructor. */
template < class State, class Transition, class Key, class KeyOps >
		FsmGraph<State, Transition, Key, KeyOps>::FsmGraph() 
:
	/* Misfit accounting is a switch, turned on only at specific times. It
	 * controls what happens when states have no way in from the outside
	 * world.. */
	misfitAccounting(false)
{
}

/* Copy all graph data including transitions. */
template < class State, class Transition, class Key, class KeyOps >
		FsmGraph<State, Transition, Key, KeyOps>::
		FsmGraph(const FsmGraph &graph)
:
	/* Copy the compare base class. */
	KeyOps(graph),

	/* Lists start empty. Will be filled by copy. */
	stateList(),
	misfitList(),

	/* Copy in the entry points. */
	entryPoints(graph.entryPoints),

	/* Will be filled by copy. */
	finStateSet(),
	
	/* Misfit accounting is only on during merging. */
	misfitAccounting(false)
{
	/* Create the states and record their map in the original state. */
	typename StateList::Iter origState = graph.stateList;
	for ( ; origState.lte(); origState++ ) {
		/* Make the new state. */
		State *newState = new State(*origState);

		/* Add the state to the list.  */
		stateList.append( newState );

		/* Set the mapsTo item of the old state. */
		origState->alg.stateMap = newState;
	}
	
	/* Derefernce all the state maps. */
	typename StateList::Iter state = stateList;
	for ( ; state.lte(); state++ ) {
		/* Walk the list of out transitions and attach new transitions to their
		 * corresponding new states. */
		TransEl *tel = state->outList.data;
		int ntel = state->outList.length();
		for (int ot = 0; ot < ntel; ot++, tel++ ) {
			/* Is the transition set? */
			if ( tel->value != NULL ) {
				/* Get the trans and the to state. */
				Transition *trans = tel->value;
				State *to = trans->toState->alg.stateMap;

				/* Make a copy of the transition. */
				trans = new Transition(*trans);
				tel->value = trans;

				/* Simulate a real attaching. */
				trans->fromState = 0;
				trans->toState = 0;
				attachExisting( state, to, trans, KeyTypeSingle, tel->key );
			}
		}

		/* Walk the list of out ranges and attach new transitions to their
		 * corresponding new states. */
		tel = state->outRange.data;
		ntel = state->outRange.length();
		for ( int outr = 0; outr < ntel; outr+=2, tel+=2 ) {
			if ( tel->value != NULL ) {
				/* Get the trans and the to state. */
				Transition *trans = tel->value;
				State *to = trans->toState->alg.stateMap;

				/* Make a copy of the transition. */
				trans = new Transition(*trans);
				tel[0].value = trans;
				tel[1].value = trans;

				/* Simulate a real attaching. */
				trans->fromState = 0;
				trans->toState = 0;
				attachExisting( state, to, trans, KeyTypeRange, tel->key );
			}
		}

		/* Copy the default transition if it is there. */
		if ( state->outDefault != NULL ) {
			/* Get the trans and the to state. */
			Transition *trans = state->outDefault;
			State *to = trans->toState->alg.stateMap;

			/* Copy the transition. */
			trans = new Transition(*trans);
			state->outDefault = trans;

			/* Simulate a real attaching. */
			trans->fromState = 0;
			trans->toState = 0;
			attachExisting( state, to, trans, KeyTypeDefault, Key() );
		}
	}

	/* Fix the state pointers in the entry points array. */
	EntryEl *eel = entryPoints.data;
	for ( int e = 0; e < entryPoints.length(); e++, eel++ ) {
		/* Get the duplicate of the state. */
		eel->value = eel->value->alg.stateMap;

		/* Foreign in transitions must be built up when duping machines so
		 * icrement it here. */
		eel->value->foreignInTrans += 1;
	}

	/* Build the final state set. */
	State **st = graph.finStateSet.data;
	int nst = graph.finStateSet.length();
	for ( int fs = 0; fs < nst; fs++, st++ )
		finStateSet.insert((*st)->alg.stateMap);
}

/* Deletes all transition data then deletes each state. */
template < class State, class Transition, class Key, class KeyOps >
		FsmGraph<State, Transition, Key, KeyOps>::~FsmGraph()
{
	/* Delete all the transitions. */
	typename StateList::Iter state = stateList;
	for ( ; state.lte(); state++ ) {
		/* Iterate the out transitions, deleting them. */
		FsmOutIter<State, Transition, Key> outIt(state);
		for ( ; ! outIt.end(); outIt++ )
			delete outIt.trans;
	}

	/* Delete all the states. */
	stateList.empty();
}

/* Set a state final. The state has its isFinState set to true and the state
 * is added to the finStateSet. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		setFinState( State *state )
{
	/* Is it already a fin state. */
	if ( state->stateBits & SB_ISFINAL )
		return;
	
	state->stateBits |= SB_ISFINAL;
	finStateSet.insert( state );
}

/* Set a state non-final. The has its isFinState flag set false and the state
 * is removed from the final state set. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		unsetFinState( State *state )
{
	/* Is it already a non-final state? */
	if ( ! (state->stateBits & SB_ISFINAL) )
		return;

	/* When a state looses its final state status it must relinquish all the
	 * properties that are allowed only for final states. */
	state->relinquishFinal();

	state->stateBits &= ~ SB_ISFINAL;
	finStateSet.remove( state );
}

/* Associate an id with a state. Makes the state a named entry point. The id
 * must not be in use and the state must not already be an entry point. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		setEntry( int id, State *state )
{
	/* Insert the entry and assert that it succeeds. */
	EntryEl *entryEl = entryPoints.insert( id, state );
	assert( entryEl != 0 );

	/* Remember the entry point in the state. */
	int *setEl = state->entryIds.insert( id );
	assert( setEl != 0 );

	if ( misfitAccounting ) {
		/* If the number of foreign in transitions is about to go up to 1 then
		 * take it off the misfit list and put it on the head list. */
		if ( state->foreignInTrans == 0 )
			stateList.append( misfitList.detach( state ) );
	}

	/* Up the foreign in transitions to the state. */
	state->foreignInTrans += 1;
}

/* Remove the association of an id with a state. The state looses it's entry
 * point status. If id is not in use then will assertion fail. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		unsetEntry( int id )
{
	/* Find the state and assert that it is an entry point. */
	EntryEl *entryEl = entryPoints.find( id );
	assert( entryEl != 0 );

	/* Remove the id from the state's entry id set. */
	bool removeRes = entryEl->value->entryIds.remove( id );
	assert( removeRes );

	/* Decrement the entry's count of foreign entries. */
	entryEl->value->foreignInTrans -= 1;

	if ( misfitAccounting ) {
		/* If the number of foreign in transitions just went down to 0 then take
		 * it off the main list and put it on the misfit list. */
		if ( entryEl->value->foreignInTrans == 0 )
			misfitList.append( stateList.detach( entryEl->value ) );
	}

	/* Remove the record from the map. */
	removeRes = entryPoints.remove( entryEl );
	assert( removeRes );
}

/* Change an entry point to a new state. The entry point must be previously
 * set. The new state the entry is assigned to must not be an entry. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		changeEntry( int id, State *state )
{
	/* Find the state and assert that it is an entry point. */
	EntryEl *entryEl = entryPoints.find( id );
	assert( entryEl != 0 );

	/* Remove the id from the old state's entry id set */
	bool res = entryEl->value->entryIds.remove( id );
	assert( res );

	/* Decrement the old state's count of foreign entries. */
	entryEl->value->foreignInTrans -= 1;

	if ( misfitAccounting ) {
		/* If the number of foreign in transitions just went down to 0 then
		 * take it off the main list and put it on the misfit list. */
		if ( entryEl->value->foreignInTrans == 0 )
			misfitList.append( stateList.detach( entryEl->value ) );
	}

	/* Set the id in the new state's entry id set. */
	int *setEl = state->entryIds.insert( id );
	assert( setEl != 0 );

	if ( misfitAccounting ) {
		/* If the number of foreign in transitions is about to go up to 1 then
		 * take it off the misfit list and put it on the head list. */
		if ( state->foreignInTrans == 0 )
			stateList.append( misfitList.detach( state ) );
	}

	/* Up the foreign in transitions of the new state. */
	state->foreignInTrans += 1;

	/* Set the new state in the entry point array. */
	entryEl->value = state;
}


/* Find a state by an entry id. If the id does not represent and entry point
 * then returns null. */
template < class State, class Transition, class Key, class KeyOps >
		State *FsmGraph<State, Transition, Key, KeyOps>::
		findEntry( int id ) const
{
	State *retVal = 0;

	EntryEl *entry = entryPoints.find( id );
	if ( entry != 0 )
		retVal = entry->value;

	return retVal;
}

/* Mark all states reachable from state. Traverses transitions forward. Used
 * for removing states that have no path into them. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		markReachableFromHere( State *state )
{
	/* Base case: return; */
	if ( state->stateBits & SB_ISMARKED )
		return;
	
	/* Set this state as processed. We are going to visit all states that this
	 * state has a transition to. */
	state->stateBits |= SB_ISMARKED;

	/* Recurse on all out transitions. */
	FsmOutIter<State, Transition, Key> outIt( state );
	for ( ; ! outIt.end(); outIt++ )
		markReachableFromHere( outIt.trans->toState );
}

/* Mark all states reachable from state. Traverse transitions backwards. Used
 * for removing dead end paths in graphs. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		markReachableFromHereReverse( State *state )
{
	/* Base case: return; */
	if ( state->stateBits & SB_ISMARKED )
		return;
	
	/* Set this state as processed. We are going to visit all states with
	 * transitions into this state. */
	state->stateBits |= SB_ISMARKED;

	/* Recurse on all items in transitions. */
	FsmInIter<State, Transition, Key> inIt( state );
	for ( ; ! inIt.end(); inIt++ )
		markReachableFromHereReverse( inIt.trans->fromState );
}

/* Determine if there are any entry points into a start state other than the
 * start state. Setting starting transitions requires that the start state be
 * isolated. In most cases a start state will already be isolated. */
template < class State, class Transition, class Key, class KeyOps >
		bool FsmGraph<State, Transition, Key, KeyOps>::
		isStartStateIsolated()
{
	/* Get the start State. */
	State *start = findEntry( 0 );

	/* If there are any in transitions then the state is not isolated. */
	if ( start->inListHead != 0 || 
			start->inRangeHead != 0 || 
			start->inDefHead != 0 )
	{
		return false;
	}

	/* If there are any entry points other than the start state then it
	 * is not isolated. */
	if ( start->entryIds.length() > 1 )
		return false;

	return true;
}

/* Bring in other's entry points. Assumes others states are going to be
 * copied into this machine. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		copyInEntryPoints( FsmGraph *other )
{
	EntryEl *entryEl = other->entryPoints.data;
	int neel = other->entryPoints.length();
	for ( int i = 0; i < neel; i++, entryEl++ ) {
		/* Insert the item and assert that it succeeded. */
		EntryEl *resEl = entryPoints.insert( entryEl->key, entryEl->value );
		assert( resEl != 0 );
	}
}

template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		setStateNumbers()
{
	int curNum = 0;
	typename StateList::Iter state = stateList;
	for ( ; state.lte(); state++ )
		state->alg.stateNum = curNum++;
}


template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		unsetAllFinStates()
{
	State **st = finStateSet.data;
	int nst = finStateSet.length();
	for ( int i = 0; i < nst; i++, st++ ) {
		State *state = *st;
		state->stateBits &= ~ SB_ISFINAL;
	}
	finStateSet.empty();
}

template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		setFinBits( int finStateBits )
{
	for ( int s = 0; s < finStateSet.length(); s++ )
		finStateSet.data[s]->stateBits |= finStateBits;
}


/* Tests the integrity of the transition lists and the fromStates. */
template < class State, class Transition, class Key, class KeyOps >
		void FsmGraph<State, Transition, Key, KeyOps>::
		verifyIntegrity()
{
	typename StateList::Iter state = stateList;
	for ( ; state.lte(); state++ ) {
		/* Walk the out transitions and assert fromState is correct. */
		FsmOutIter<State, Transition, Key> outIt( state );
		for ( ; ! outIt.end(); outIt++ )
			assert( outIt.trans->fromState == state );

		/* Walk the inlist and assert toState is correct. */
		FsmInIter<State, Transition, Key> inIt( state );
		for ( ; ! inIt.end(); inIt++ )
			assert( inIt.trans->toState == state );
	}
}

#endif /* _RLFSM_FSMBASE_CPP */

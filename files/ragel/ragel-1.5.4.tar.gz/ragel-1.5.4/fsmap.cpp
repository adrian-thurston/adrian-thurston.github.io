/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmap.h"
#include "fsmgraph.cpp"

/* Instantiate the base fsmgraph. */
template struct FsmGraph< StateAp, TransAp, long, FaKeyOps >;

/* The builder and graph dumping need these. */
template struct FsmOutIter< StateAp, TransAp, long >;
template struct FsmUniOutIter< StateAp, TransAp, long, FaKeyOps >;

/* Compares two transitions according to priority and functions. Pointers
 * should not be null. Does not consider to state or from state.  */
int TransAp::compareTransData( TransAp *trans1, TransAp *trans2 )
{
	if ( trans1->priority < trans2->priority )
		return -1;
	else if ( trans1->priority > trans2->priority )
		return 1;
	else {
		int cmpResult = TransFuncTableCompare::
				compare(trans1->transFuncTable, trans2->transFuncTable);
		if ( cmpResult != 0 )
			return cmpResult;
	}
	return 0;
}

/* Compare two transitions according to their relative priority. */
int TransAp::comparePrior( TransAp *trans1, TransAp *trans2 )
{
	if ( trans1->priority < trans2->priority )
		return -1;
	else if ( trans1->priority > trans2->priority )
		return 1;
	else
		return 0;
}

void TransAp::addInTrans( TransAp *srcTrans )
{
	/* Protect against adding in from ourselves. */
	if ( srcTrans == this ) {
		/* Adding in ourselves, need to make a copy of the source. */
		TransFuncTable srcTransTable( srcTrans->transFuncTable );
		setFunctions( srcTransTable );
	}
	else {
		/* Not a copy from oursef, get the functions. */
		setFunctions( srcTrans->transFuncTable );
	}

	/* Copy in the priority. Note that as with addInOutState, this breaks the
	 * idea of adding in a transition. */
	priority = srcTrans->priority;
}

void TransAp::leavingFromState( StateAp *srcState )
{
	/* If there is an out priority, use it. */
	if ( srcState->isOutPriorSet )
		priority = srcState->outPriority;

	/* Get the actions data from the outTransFuncTable. */
	setFunctions( srcState->outTransFuncTable );
}

/* Insert a function into a transition's function table. */
void TransAp::setFunction( int func, int transOrder )
{
	transFuncTable.insertMulti( transOrder, func );
}

/* Set all the functions from a specified TransFuncTable into the transition's
 * function table. */
void TransAp::setFunctions( TransFuncTable &funcTable )
{
	TransFuncEl *tfel = funcTable.data;
	int ntfel = funcTable.length();
	for ( int i = 0; i < ntfel; i++, tfel++ )
		transFuncTable.insertMulti( tfel->key, tfel->value );
}


/* Create a new fsm state. State has not out transitions or in transitions, not
 * out out transition data and not number. */
StateAp::StateAp()
:
	/* No out priority or actions by default. */
	isOutPriorSet(false),
	outPriority(0),
	outTransFuncTable()
{
}

/* Copy everything except actual the transitions. That is left up to the
 * FsmGraph copy constructor. */
StateAp::StateAp(const StateAp &other)
:
	/* Call the base copy constructor. */
	FsmState<StateAp, TransAp, long, FaKeyOps>( other ),

	/* Fsm state data. */
	isOutPriorSet(other.isOutPriorSet),
	outPriority(other.outPriority),
	outTransFuncTable(other.outTransFuncTable)
{
}


/* Compare the out transition data of two states. Compares out priorities and
 * out transitions. */
int StateAp::compareStateData( const StateAp *state1, const StateAp *state2 )
{
	/* If only one out priority is set then differ. */
	if ( state1->isOutPriorSet && !state2->isOutPriorSet )
		return -1;
	else if ( !state1->isOutPriorSet && state2->isOutPriorSet )
		return 1;
	else if ( state1->isOutPriorSet && state2->isOutPriorSet ) {
		/* Both priorities set, compare the priorites. */
		int outPriorCmp = CmpOrd<int>::compare(
				state1->outPriority, state2->outPriority );
		if ( outPriorCmp != 0 )
			return outPriorCmp;
	}

	/* Test outTransFuncTable. */
	int outTransCmp = TransFuncTableCompare::compare(
			state1->outTransFuncTable, state2->outTransFuncTable);
	if ( outTransCmp != 0 )
		return outTransCmp;

	return 0;
}

/* Callback invoked when otherState is added into this state during the
 * merging process. */
void StateAp::addInState( StateAp *srcState )
{
	/* Merge the outTransFuncTable. */
	if ( srcState == this ) {
		/* Duplicate the list to protect against write to source. */
		TransFuncTable srcTransTable( srcState->outTransFuncTable );
		setOutFunctions( srcTransTable );
	}
	else {
		/* Get the out functions. */
		setOutFunctions( srcState->outTransFuncTable );
	}

	/* Copy in the out priority if it is set. This breaks the idea of adding
	 * in another state however. */
	if ( srcState->isOutPriorSet ) {
		isOutPriorSet = true;
		outPriority = srcState->outPriority;
	}
}

/* Callback invoked when a state looses its final state status. This is where
 * properties of final states get unset. At the point of invocation, it is
 * unspecified whether or not isFinState is set. */
void StateAp::relinquishFinal( )
{
	/* Kill the out transitions. Reset the priority. */
	outTransFuncTable.empty();
	isOutPriorSet = false;
	outPriority = 0;
}

/* Insert the contents of funcTable into this state's out functions. */
void StateAp::setOutFunctions( TransFuncTable &funcTable )
{
	TransFuncEl *tfel = funcTable.data;
	int ntfel = funcTable.length();
	for ( int i = 0; i < ntfel; i++, tfel++ )
		outTransFuncTable.insertMulti( tfel->key, tfel->value );
}

/* Init the signedness. */
FsmAp::FsmAp(bool isAlphSigned)
{
	/* Set the key signedness in the key compare inherited by FsmGraph. */
	FaKeyOps::isAlphSigned = isAlphSigned;
}

/* Set the priority of starting transitions. Isolates the start state so it has
 * no other entry points, then sets the priorities of all the transitions out
 * of the start state. If the start state is final, then the outPrior of the
 * start state is also set. The idea is that a machine that accepts the null
 * string can still specify the starting trans prior for when it accepts the
 * null word. */
void FsmAp::startFsmPrior( int prior )
{
	/* Make sure the start state has no other entry points. */
	isolateStartState();

	/* Get the start state. */
	StateAp *startState = findEntry( 0 );

	/* Walk all transitions out of the start state. */
	FsmOutIter<StateAp, TransAp, long> outIt( startState );
	for ( ; ! outIt.end(); outIt++ )
		outIt.trans->priority = prior;

	/* If the new start state is final then set the out priority. This follows
	 * the same convention as setting start funcs in the out funcs of a final
	 * start state. */
	if ( startState->stateBits & SB_ISFINAL ) {
		startState->isOutPriorSet = true;
		startState->outPriority = prior;
	}
}

/* Set the priority of all transitions in a graph. Walks all transition lists
 * and all def transitions. */
void FsmAp::allTransPrior( int prior )
{
	/* Walk the out list of all states. */
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the out list of the state. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end() ; outIt++ ) 
			outIt.trans->priority = prior;

		state = state->next;
	}
}

/* Set the priority of all transitions that go into a final state. Note that if
 * any entry states are final, we will not be setting the priority of any
 * transitions that may go into those states in the future. The graph does not
 * support pending in transitions in the same way pending out transitios are
 * supported. */
void FsmAp::finFsmPrior( int prior )
{
	/* Walk all final states. */
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++) {
		/* Walk all in transitions of the final state. */
		FsmInIter<StateAp, TransAp, long> inIt( *st );
		for ( ; ! inIt.end(); inIt++ )
			inIt.trans->priority = prior;
	}
}

/* Set the priority of any future out transitions that may be made going out of
 * this state machine. */
void FsmAp::leaveFsmPrior( int prior )
{
	/* Walk all final states. */
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = true;
		(*st)->outPriority = prior;
	}
}


/* Set functions to execute on starting transitions. Isolates the start state
 * so it has no other entry points, then adds to the transition functions
 * of all the transitions out of the start state. If the start state is final,
 * then the func is also added to the start state's out func list. The idea is
 * that a machine that accepts the null string can execute a start func when it
 * matches the null word, which can only be done when leaving the start/final
 * state. */
void FsmAp::startFsmFunc( int func, int transOrder )
{
	/* Make sure the start state has no other entry points. */
	isolateStartState();

	/* Get the start state. */
	StateAp *startState = findEntry( 0 );

	/* Walk the start state's transitions, setting functions. */
	FsmOutIter<StateAp, TransAp, long> outIt( startState );
	for ( ; ! outIt.end(); outIt++ ) 
		outIt.trans->setFunction( func, transOrder );

	/* If start state is final then insert on the out func. This means that you
	 * can have start and leaving funcs on a machine that recognizes the null
	 * word. */
	if ( startState->stateBits & SB_ISFINAL )
		startState->outTransFuncTable.insertMulti( transOrder, func );
}

/* Set functions to execute on all transitions. Walks the out lists of all
 * states. */
void FsmAp::allTransFunc( int func, int transOrder )
{
	/* Walk all states. */
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the out list of the state. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt++ )
			outIt.trans->setFunction( func, transOrder );

		state = state->next;
	}
}

/* Specify functions to execute upon entering final states. If the start state
 * is final we can't really specify a function to execute upon entering that
 * final state the first time. So function really means whenever entering a
 * final state from within the same fsm. */
void FsmAp::finFsmFunc( int func, int transOrder )
{
	/* Walk all final states. */
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++) {
		/* Walk the final state's in list. */
		FsmInIter<StateAp, TransAp, long> inIt( *st );
		for ( ; ! inIt.end(); inIt++ )
			inIt.trans->setFunction( func, transOrder );
	}
}

/* Add functions to any future out transitions that may be made going out of
 * this state machine. */
void FsmAp::leaveFsmFunc( int func, int transOrder )
{
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++)
		(*st)->outTransFuncTable.insertMulti( transOrder, func );
}

/* Shift the function ordering of the start transitions to start
 * at fromOrder and increase in units of 1. Useful before staring.
 * Returns the maximum number of order numbers used. */
int FsmAp::shiftStartFuncOrder( int fromOrder )
{
	int maxUsed = 0;

	/* Walk the start state's transitions, shifting function ordering. */
	FsmOutIter<StateAp, TransAp, long> outIt( findEntry(0) );
	for ( ; ! outIt.end(); outIt++ ) {
		TransAp *trans = outIt.trans;

		/* Walk the function data for the transition. */
		TransAp::TransFuncEl *tfel = trans->transFuncTable.data;

		/* Set the keys to increasing values starting at fromOrder */
		int ntfel = trans->transFuncTable.length();
		int curFromOrder = fromOrder;
		for ( int j = 0; j < ntfel; j++, tfel++ )
			tfel->key = curFromOrder++;
	
		/* Keep track of the max number of orders used. */
		if ( curFromOrder - fromOrder > maxUsed )
			maxUsed = curFromOrder - fromOrder;
	}
	
	return maxUsed;
}

/* Clear all functions tables out of the start state. First makes sure that
 * the start state has no other entry points other than its start stateness. */
void FsmAp::clearStartFsmFunc()
{
	/* Make sure the start state has no other entry points. */
	isolateStartState();

	/* Get the start state. */
	StateAp *startState = findEntry( 0 );

	/* Walk the start state's transitions, clearing functions. */
	FsmOutIter<StateAp, TransAp, long> outIt( startState );
	for ( ; ! outIt.end(); outIt++ )
		outIt.trans->transFuncTable.empty();

	/* If start state is final then clear on the out func. Leaving the start state
	 * via an out transition is considered starting the fsm. */
	if ( startState->stateBits & SB_ISFINAL )
		startState->outTransFuncTable.empty();
}

/* Empty all transition functions tables. Does not empty state outFunc tables. */
void FsmAp::clearAllTransFunc()
{
	/* Walk all states. */
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the state's outList. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt++ )
			outIt.trans->transFuncTable.empty();

		state = state->next;
	}
}

/* Empty all transition functions going into a final state. */
void FsmAp::clearFinFsmFunc()
{
	/* Walk all final states. */
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++) {
		/* Walk the final state's in list. */
		FsmInIter<StateAp, TransAp, long> inIt( *st );
		for ( ; ! inIt.end(); inIt++ )
			inIt.trans->transFuncTable.empty();
	}
}

/* Clear pending out functions from the outFunc lists of final states. */
void FsmAp::clearLeaveFsmFunc()
{
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();
	for (int i = 0; i < nst; i++, st++)
		(*st)->outTransFuncTable.empty();
}

/* Clear pending out priorities from final states. */
void FsmAp::clearLeaveFsmPrior( )
{
	StateAp **st = finStateSet.data;
	int nst = finStateSet.length();

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = false;
		(*st)->outPriority = 0;
	}
}

/* Remove all transition data. Remove funcs and outfuncs, zero priorities and
 * remove out priorities. */
void FsmAp::clearAllTransData()
{
	StateAp *state = stateList.head;
	while ( state ) {
		/* Clear out data. */
		state->outTransFuncTable.empty();
		state->isOutPriorSet = false;
		state->outPriority = 0;

		/* Clear transition data from the out transitions. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt++ ) {
			outIt.trans->transFuncTable.empty();
			outIt.trans->priority = 0;
		}

		state = state->next;
	}
}


/* Zeros out the function ordering keys. This may be called before minimization
 * when it is known that no more fsm operations are going to be done.  This
 * will achieve greater reduction as states will not be separated on the basis
 * of function ordering. */
void FsmAp::nullFunctionKeys( )
{
	/* For each state... */
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		/* Walk the transitions for the state. */
		FsmOutIter<StateAp, TransAp, long> outIt( state );
		for ( ; ! outIt.end(); outIt ++ ) {
			/* Walk the function table for the transition. */
			TransAp::TransFuncEl *tfel = outIt.trans->transFuncTable.data;
			int ntfel = outIt.trans->transFuncTable.length();
			for ( int j = 0; j < ntfel; j++, tfel++ )
				tfel->key = 0;
		}

		/* Null the function keys of the out transtions. */
		TransAp::TransFuncEl *tfel = state->outTransFuncTable.data;
		int ntfel = state->outTransFuncTable.length();
		for ( int j = 0; j < ntfel; j++, tfel++ )
			tfel->key = 0;

		state = state->next;
	}
}

/* Walk the list of states and verify that non final states do not have out
 * data, that all stateBits are cleared, and that there are no states with
 * zero foreign in transitions. */
void FsmAp::verifyStates()
{
	StateAp *state = stateList.head;
	while ( state != 0 ) {
		if ( ! (state->stateBits & SB_ISFINAL) ) {
			assert( state->outTransFuncTable.length() == 0 );
			assert( !state->isOutPriorSet );
			assert( state->outPriority == 0 );
		}

		assert( (state->stateBits & (SB_KILLOTHERS | SB_WANTOTHER)) == 0 );
		assert( state->foreignInTrans > 0 );

		state = state->next;
	}
}

/*
 * Operation wrappers to assert each graph is of the same signedness.
 */

/* Wrap concatenation with sign assert. */
void FsmAp::concatOp( FsmAp *other, bool leavingFsm )
{
	/* Assert same signedness and return graph concatenation op. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<StateAp, TransAp, long, FaKeyOps>::concatOp( other, leavingFsm );
}

/* Wrap union with sign assert. */
void FsmAp::unionOp( FsmAp *other )
{
	/* Assert same signedness and return graph union op. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<StateAp, TransAp, long, FaKeyOps>::unionOp( other );
}

/* Wrap intersection with sign assert. */
void FsmAp::intersectOp( FsmAp *other )
{
	/* Assert same signedness and return graph intersection op. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<StateAp, TransAp, long, FaKeyOps>::intersectOp( other );
}

/* Wrap subtraction with sign assert. */
void FsmAp::subtractOp( FsmAp *other )
{
	/* Both this and the other graph should have the same signedness. */
	assert( isAlphSigned == other->isAlphSigned );
	return FsmGraph<StateAp, TransAp, long, FaKeyOps>::subtractOp( other );
}

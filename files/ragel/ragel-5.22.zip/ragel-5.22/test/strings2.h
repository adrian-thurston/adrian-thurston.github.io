#ifndef _STRINGS1_H
#define _STRINGS1_H

struct strs
{
	int cs;
};

#endif

#define VERSION "6.6"
#define PUBDATE "Dec 2009"

/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "ipgotocodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"
#include "bstmap.h"

/* Inits the code and data pointers. There are no code generation 
 * functions to register. */
IpGotoCodeGen::IpGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	GotoCodeGen(fsmName, parseData, machine, out)
{ }

/* Called from GotoCodeGen::STATE_GOTOS just before writing the gotos for each
 * state. */
void IpGotoCodeGen::aboveStateGotos( int st )
{
	bool anyWritten = false;

	/* Emit any transitions that have functions and that go to 
	 * this state. */
	FsmMachTrans *trans = machine->allTrans;
	for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
		if ( trans->toState == st && trans->funcs != FUNC_NO_FUNC ) {
			/* Remember that we wrote a trans so we know to write the
			 * line directive for going back to the output. */
			anyWritten = true;

			/* Write the label for the transition so it can be jumped to. */
			out << "tr" << tr << ":\n";

			/* Get the funcs. */
			int *funcs = machine->allTransFuncs + 
					machine->transFuncIndex[trans->funcs];

			/* The first number is the length. */
			int flen = *funcs++;
			while ( flen-- > 0 ) {
				/* Get the function data. */
				ActionListEl *flel = parseData->actionIndex[*funcs];

				/* Write the preprocessor line info for going into the 
				 * source file. */
				out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

				/* Wrap the block in brakets. */
				out << "\t{" << flel->data << "}\n";
				funcs += 1;
			}

			/* Goto the target state. */
			if ( trans->toState != STATE_ERR_STATE )
				out << "\tgoto st" << trans->toState << ";\n";
			else
				out << "\tgoto err;\n";
		}
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	}
}

/* Emit the goto to take for a given transition. */
std::ostream &IpGotoCodeGen::TRANS_GOTO( FsmMachTrans *trans, int level )
{
	if ( trans->funcs != FUNC_NO_FUNC )
		TABS(level) << "goto tr" << trans - machine->allTrans << ";";
	else {
		/* Get the index of the state we go to. */
		if ( trans->toState != STATE_ERR_STATE )
			TABS(level) << "goto st" << trans->toState << ";";
		else
			TABS(level) << "goto out_err;";
	}
	return out;
}


std::ostream &IpGotoCodeGen::FINISH_CASES()
{
	bool anyWritten = false;

	for ( int st = 0; st < machine->numStates; st++ ) {
		/* Get the machine state. */
		FsmMachState *state = machine->allStates+st;

		if ( state->isFinState ) {
			out << "\tcase " << st << ": ";

			/* If there are out functions, write them. */
			if ( state->outFuncs != FUNC_NO_FUNC ) {
				/* Remember that we wrote a trans so we know to write the
				 * line directive for going back to the output. */
				anyWritten = true;

				out << "\n";
				int *funcs = machine->allTransFuncs + 
						machine->transFuncIndex[state->outFuncs];

				/* The first number is the length. */
				int flen = *funcs++;
				while ( flen-- > 0 ) {
					/* Get the function data. */
					ActionListEl *flel = parseData->actionIndex[*funcs];

					/* Write the preprocessor line info for going into the 
					 * source file. */
					out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

					/* Wrap the block in brakets. */
					out << "\t{" << flel->data << "}\n";
					funcs += 1;
				}
			}
			out << "\tbreak;\n";
		}
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	}
	return out;
}

/* Set up labelNeeded flag for each state. */
void IpGotoCodeGen::setLabelsNeeded()
{
	for ( int st = 0; st < machine->numStates; st++ )
		machine->allStates[st].labelNeeded = false;
	
	FsmMachTrans *trans = machine->allTrans;
	for ( int tr = 0; tr < machine->numTrans; tr++, trans++ ) {
		if ( trans->toState != STATE_ERR_STATE )
			machine->allStates[trans->toState].labelNeeded = true;
	}
}


/* Init base data. */
CIpGotoCodeGen::CIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	IpGotoCodeGen(fsmName, parseData, machine, out)
{ }


/* Emit the prefix for accessing the fsm. In c code the fsm is a struct,
 * and we must derefence the struct. Assume the use of fsm as the pointer
 * name. */
std::ostream &CIpGotoCodeGen::FSM_PREFIX()
{
	out << "fsm->";
	return out;
}

void CIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Init the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the machine. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( fsm->curState >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = fsm->curState;\n"
		"\n"
		"	if ( cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( --len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() << 
		"	}\n";
		EXIT_STATES() << 
		"\n";
	
	out <<
		"out_ok:\n"
		"	fsm->curState = cs;\n"
		"	if ( cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	fsm->curState = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	switch ( fsm->curState ) {\n";
		FINISH_CASES() <<
		"	}\n"
		"	if ( fsm->curState == 0 )\n"
		"		return -1;\n"
		"	else if ( fsm->curState >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";
}

/* Init base data. */
CCIpGotoCodeGen::CCIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	IpGotoCodeGen(fsmName, parseData, machine, out)
{ }


/* Emit the prefix for accessing the fsm. In cpp code the fsm is an object,
 * and no prefix is required. */
std::ostream &CCIpGotoCodeGen::FSM_PREFIX()
{
	return out;
}


void CCIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Init the fsm. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_OFFSET() << ";\n"
		"\n"
		"/* Initialize the machine. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( this->curState >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	/* Prime these to one back to simulate entering the \n"
		"	 * machine on a transition. */ \n"
		"	"; ALPH_TYPE() << " *p = data-1;\n"
		"	int len = dlen+1;\n"
		"	int cs = this->curState;\n"
		"\n"
		"	if ( cs == 0 )\n"
		"		goto out_err;\n"
		"	if ( --len == 0 )\n"
		"		goto out_ok;\n"
		"	switch ( cs ) {\n";
		STATE_GOTOS() <<
		"	}\n";
		EXIT_STATES() << 
		"\n";

	out <<
		"out_ok:\n"
		"	this->curState = cs;\n"
		"	if ( cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	this->curState = 0;\n"
		"	return -1;\n"
		"}\n"
		"\n";
	
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n"
		"	switch( this->curState ) {\n";
		FINISH_CASES() <<
		"	}\n"
		"	if ( this->curState == 0 )\n"
		"		return -1;\n"
		"	else if ( this->curState >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";
}

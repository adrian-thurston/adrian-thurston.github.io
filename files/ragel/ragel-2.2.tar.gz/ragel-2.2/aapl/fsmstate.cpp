/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  Aapl is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 *  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 *  more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Aapl; if not, write to the Free Software Foundation, Inc., 59
 *  Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _RLFSM_FSMSTATE_CPP
#define _RLFSM_FSMSTATE_CPP

#include <string.h>
#include <assert.h>

/* Return and re-entry for the co-routine iterators. This should ALWAYS be
 * used inside of a block. */
#define CO_RETURN(label) \
	itState = label; \
	return; \
	entry##label: backIn = true

/* Return and re-entry for the co-routine iterators. This should ALWAYS be
 * used inside of a block. */
#define CO_RETURN2(label, uState) \
	itState = label; \
	userState = uState; \
	return; \
	entry##label: backIn = true

/* Construct a mark index for a specified number of states. Must new up
 * an array that is states^2 in size. */
template < class State > MarkIndex<State>::
		MarkIndex( int states ) : numStates(states)
{
	/* Total pairs is states^2. Actually only use half of these, but we allocate
	 * them all to make indexing into the array easier. */
	int total = states * states;

	/* New up chars so that individual DListEl constructors are
	 * not called. Zero out the mem manually. */
	array = new bool[total];
	memset( array, 0, sizeof(bool) * total );
}

/* Free the array used to store state pairs. */
template < class State >MarkIndex<State>::~MarkIndex()
{
	delete[] array;
}

/* Mark a pair of states. States are specified by their number. The
 * marked states are moved from the unmarked list to the marked list. */
template < class State > void MarkIndex<State>::
		markPair(int state1, int state2)
{
	int pos = ( state1 >= state2 ) ?
		( state1 * numStates ) + state2 :
		( state2 * numStates ) + state1;

	array[pos] = true;
}

/* Returns true if the pair of states are marked. Returns false otherwise.
 * Ordering of states given does not matter. */
template < class State > bool MarkIndex<State>::
		isPairMarked(int state1, int state2)
{
	int pos = ( state1 >= state2 ) ?
		( state1 * numStates ) + state2 :
		( state2 * numStates ) + state1;

	return array[pos];
}

/*
 * Transition Comparison.
 */

/* Compare target partitions. Either pointer may be null. */
template < class Fsm, class State, class Transition, class Key >
		int FsmGraph<Fsm, State, Transition, Key>::
		comparePartPtr( Transition *trans1, Transition *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. If either are set then both
		 * should be set. The initial partitioning should guarantee this for
		 * us. So this case should never happen. */
		assert( false );
	}
	else if ( trans1 != 0 ) {
		/* Both of transitions are set. */
		return CmpOrd< MinPartition<State>* >::compare( 
				trans1->toState->alg.partition, trans2->toState->alg.partition );
	}
	return 0;
}


/* Compares two transition pointers according to priority and functions.
 * Either pointer may be null. Does not consider to state or from state. */
template < class Fsm, class State, class Transition, class Key >
		int FsmGraph<Fsm, State, Transition, Key>::
		compareDataPtr( Transition *trans1, Transition *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. */
		if ( trans1 != 0 )
			return -1;
		else
			return 1;
	}
	else if ( trans1 != 0 ) {
		/* Both of the transition pointers are set. */
		int compareRes = static_cast<Fsm*>(this)->compareTransData( trans1, trans2 );
		if ( compareRes != 0 )
			return compareRes;
	}

	/* Neither of the transitions are set. */
	return 0;
}

/* Compares two transitions according to target state, priority and functions.
 * Does not consider from state. Either of the pointers may be null. */
template < class Fsm, class State, class Transition, class Key >
		int FsmGraph<Fsm, State, Transition, Key>::
		compareFullPtr( Transition *trans1, Transition *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. */
		if ( trans1 != 0 )
			return -1;
		else
			return 1;
	}
	else if ( trans1 != 0 ) {
		/* Both of the transition pointers are set. Test target state,
		 * priority and funcs. */
		if ( trans1->toState < trans2->toState )
			return -1;
		else if ( trans1->toState > trans2->toState )
			return 1;
		else {
			/* Test transition data. */
			int compareRes = static_cast<Fsm*>(this)->compareTransData( trans1, trans2 );
			if ( compareRes != 0 )
				return compareRes;
		}
	}

	/* Neither of the transition pointers are set. */
	return 0;
}


template < class Fsm, class State, class Transition, class Key >
		bool FsmGraph<Fsm, State, Transition, Key>::
		shouldMarkPtr( MarkIndex<State> &markIndex, Transition *trans1, 
				Transition *trans2 )
{
	if ( (trans1 != 0) ^ (trans2 != 0) ) {
		/* Exactly one of the transitions is set. The initial mark round
		 * should rule out this case. */
		assert( false );
	}
	else if ( trans1 != 0 ) {
		/* Both of the transitions are set. If the target pair is marked, then
		 * the pair we are considering gets marked. */
		return markIndex.isPairMarked( trans1->toState->alg.stateNum, 
				trans2->toState->alg.stateNum );
	}

	/* Neither of the transitiosn are set. */
	return false;
}

/*
 * Fsm Transition List.
 */

/* Find an entry in an fsm trans list. */
template < class Fsm, class Transition, class Key > 
		FsmTransListEl<Transition, Key> * FsmTransList<Fsm, Transition, Key>::
		findSingle( const Key &key, Fsm *keyOps ) const
{
	const TransEl *lower, *upper;
	int dataLen = size();
	if ( dataLen == 0 )
		return 0;

	lower = data;
	upper = data + dataLen - 1;
	while ( true ) {
		/* Not found. */
		if ( upper < lower )
			return 0;

		const TransEl *mid = lower + ((upper-lower)>>1);
		if ( keyOps->lt( key, mid->key ) )
			upper = mid - 1;
		else if ( keyOps->gt( key, mid->key ) )
			lower = mid + 1;
		else {
			/* The key was found, return it. */
			return (TransEl*)mid;
		}
	}
}

/* Given a transition key, find the range the key is in. If the key is in a range, 
 * returns a pointer to the lower end of the range. If the key is not in a range,
 * returns 0. Implemented with a binary search. */
template< class Fsm, class Transition, class Key > 
		FsmTransListEl<Transition, Key> *FsmTransList<Fsm, Transition, Key>::
		findRange( const Key &key, Fsm *keyOps ) const
{
	const TransEl *lower, *upper;
	int dataLen = size();
	if ( dataLen == 0 )
		return 0;

	lower = data;
	upper = data + dataLen - 2;
	while ( true ) {
		/* Not found. */
		if ( upper < lower )
			return 0;

		const TransEl *mid = lower + (((upper-lower)>>1) & ~1);
		if ( keyOps->lt( key, mid[0].key ) )
			upper = mid - 2;
		else if ( keyOps->gt( key, mid[1].key ) )
			lower = mid + 2;
		else {
			/* The key was found in the range mid, return it. */
			return (TransEl*)mid;
		}
	}
}

/* Find a transition range given the lower end of the range. */
template< class Fsm, class Transition, class Key > 
		FsmTransListEl<Transition, Key> *FsmTransList<Fsm, Transition, Key>::
		findLower( const Key &key, Fsm *keyOps ) const
{
	const TransEl *lower, *upper;
	int dataLen = size();
	if ( dataLen == 0 )
		return 0;

	lower = data;
	upper = data + dataLen - 2;
	while ( true ) {
		/* Not found. */
		if ( upper < lower )
			return 0;

		const TransEl *mid = lower + (((upper-lower)>>1) & ~1);
		if ( keyOps->lt( key, mid[0].key ) )
			upper = mid - 2;
		else if ( keyOps->gt( key, mid[0].key ) )
			lower = mid + 2;
		else {
			/* The key was found in the range mid, return it. */
			return (TransEl*)mid;
		}
	}
}

template< class Fsm, class Transition, class Key > 
		FsmTransListEl<Transition, Key> *FsmTransList<Fsm, Transition, Key>::
		insertSingle( const Key &key, Fsm *keyOps )
{
	const TransEl *lower, *upper;
	int dataLen = size();
	if ( dataLen == 0 ) {
		lower = data;
		goto insert;
	}

	lower = data;
	upper = data + dataLen - 1;
	while ( true ) {
		/* Not found, insert location is lower. */
		if ( upper < lower )
			goto insert;

		const TransEl *mid = lower + ((upper-lower)>>1);
		if ( keyOps->lt( key, mid->key ) )
			upper = mid - 1;
		else if ( keyOps->gt( key, mid->key ) )
			lower = mid + 1;
		else {
			/* The key was found, return failure. */
			return 0;
		}
	}
insert:
	/* Get the insert pos. */
	int insertPos = lower - data;

	/* Do the insert. After makeRawSpaceFor, lower pointer is no good. */
	makeRawSpaceFor(insertPos, 1);
	new(data + insertPos) TransEl(key);

	/* Return the new element. */
	return data + insertPos;
}

template< class Fsm, class Transition, class Key > 
		bool FsmTransList<Fsm, Transition, Key>::
		removeSingle( const Key &key, Fsm *keyOps )
{
	TransEl *transEl = findSingle( key, keyOps );
	if ( transEl != 0 ) {
		Vector< TransEl >::remove(transEl - data);
		return true;
	}
	return false;
}

/* Create a new fsm state. State has not out transitions or in transitions,
 * not out out transition data and not number. */
template< class Fsm, class State, class Transition, class Key >
		FsmState<Fsm, State, Transition, Key>::FsmState()
:
	/* No out transitions. */
	outList(),
	outRange(),
	outDefault(0),

	/* No in transitions. */
	inList(),
	inRange(),
	inDefault(),

	/* No entry points. */
	entryIds(),

	/* No transitions in from other states. */
	foreignInTrans(0),

	/* Only used during merging. Normally null. */
	stateDictEl(0),

	/* No state identification bits. */
	stateBits(0)
{
}

/* Copy everything except actual the transitions. That is left up to the
 * FsmGraph copy constructor. */
template< class Fsm, class State, class Transition, class Key >
		FsmState<Fsm, State, Transition, Key>::FsmState(const FsmState &other)
:
	/* Copy the out pointers directly. 
	 * The transitions will be duplicated later. */
	outList(other.outList),
	outRange(other.outRange),
	outDefault(other.outDefault),

	/* All in lists are cleared. They will be filled in when the
	 * individual transitions are duplicated and attached. */
	inList(),
	inRange(),
	inDefault(),

	/* Duplicate the entry id set. This is a set of integers 
	 * and as such needs no fixing. */
	entryIds(other.entryIds),

	/* No transitions in from other states. */
	foreignInTrans(0),

	/* This is only used during merging. Normally null. */
	stateDictEl(0),

	/* Fsm state data. */
	stateBits(other.stateBits)
{
}

/* If there is a state dict element, then delete it. Everything else is left
 * up the FsmGraph destructor. */
template< class Fsm, class State, class Transition, class Key >
		FsmState<Fsm, State, Transition, Key>::~FsmState()
{
	if ( stateDictEl != 0 )
		delete stateDictEl;
}

/* Compare two states using pointers to the states. With the approximate
 * compare the idea is that if the compare finds them the same, they can
 * immediately be merged. */
template< class Fsm, class State, class Transition, class Key >
		int ApproxCompare<Fsm, State, Transition, Key>::
		compare( const State *state1 , const State *state2 )
{
	int compareRes;

	/* Test final state status. */
	if ( (state1->stateBits & SB_ISFINAL) && !(state2->stateBits & SB_ISFINAL) )
		return -1;
	else if ( !(state1->stateBits & SB_ISFINAL) && (state2->stateBits & SB_ISFINAL) )
		return 1;
	
	/* Compare the out transitions. */
	compareRes = keyOps->compareStateData( state1, state2 );
	if ( compareRes )
		return compareRes;

	/* Test default transitions. */
	compareRes = keyOps->compareFullPtr( state1->outDefault, 
			state2->outDefault );
	if ( compareRes != 0 )
		return compareRes;

	/* Use a pair iterator to get the transition pairs. */
	PairIter outPair( state1, state2, keyOps, false );
	while ( ! outPair.end() ) {
		switch ( outPair.userState ) {

		case PairIter::TransInS1:
		case PairIter::RangeInS1:
			compareRes = keyOps->compareFullPtr( 
					outPair.s1Tel->value, outPair.defTrans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::TransInS2:
		case PairIter::RangeInS2:
			compareRes = keyOps->compareFullPtr( 
					outPair.defTrans, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::RangeOverlap:
		case PairIter::TransOverlap:
			compareRes = keyOps->compareFullPtr( 
					outPair.s1Tel->value, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::BreakS1:
		case PairIter::BreakS2:
			break;
		}
		outPair++;
	}

	/* Got through the entire state comparison, deem them equal. */
	return 0;
}

/* Compare class for the sort that does the intial partition of compaction. */
template< class Fsm, class State, class Transition, class Key >
		int InitPartitionCompare<Fsm, State, Transition, Key>::
		compare( const State *state1 , const State *state2 )
{
	int compareRes;

	/* Test final state status. */
	if ( (state1->stateBits & SB_ISFINAL) && !(state2->stateBits & SB_ISFINAL) )
		return -1;
	else if ( !(state1->stateBits & SB_ISFINAL) && (state2->stateBits & SB_ISFINAL) )
		return 1;

	/* Compare the out transitions. */
	compareRes = keyOps->compareStateData( state1, state2 );
	if ( compareRes != 0 )
		return compareRes;

	/* Test default transitions. */
	compareRes = keyOps->compareDataPtr( state1->outDefault, 
			state2->outDefault );
	if ( compareRes != 0 )
		return compareRes;

	/* Use a pair iterator to get the transition pairs. */
	PairIter outPair( state1, state2, keyOps, false );
	while ( ! outPair.end() ) {
		switch ( outPair.userState ) {

		case PairIter::TransInS1:
		case PairIter::RangeInS1:
			compareRes = keyOps->compareDataPtr( 
					outPair.s1Tel->value, outPair.defTrans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::TransInS2:
		case PairIter::RangeInS2:
			compareRes = keyOps->compareDataPtr( 
					outPair.defTrans, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::RangeOverlap:
		case PairIter::TransOverlap:
			compareRes = keyOps->compareDataPtr( 
					outPair.s1Tel->value, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::BreakS1:
		case PairIter::BreakS2:
			break;
		}
		outPair++;
	}

	return 0;
}

/* Compare class for the sort that does the partitioning. */
template< class Fsm, class State, class Transition, class Key >
		int PartitionCompare<Fsm, State, Transition, Key>::
		compare( const State *state1, const State *state2 )
{
	int compareRes;

	/* Test default transitions. */
	compareRes = keyOps->comparePartPtr( state1->outDefault, state2->outDefault );
	if ( compareRes != 0 )
		return compareRes;

	/* Use a pair iterator to get the transition pairs. */
	PairIter outPair( state1, state2, keyOps, false );
	while ( ! outPair.end() ) {
		switch ( outPair.userState ) {

		case PairIter::TransInS1:
		case PairIter::RangeInS1:
			compareRes = keyOps->comparePartPtr( 
					outPair.s1Tel->value, outPair.defTrans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::TransInS2:
		case PairIter::RangeInS2:
			compareRes = keyOps->comparePartPtr( 
					outPair.defTrans, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::RangeOverlap:
		case PairIter::TransOverlap:
			compareRes = keyOps->comparePartPtr( 
					outPair.s1Tel->value, outPair.s2Tel->value );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::BreakS1:
		case PairIter::BreakS2:
			break;
		}
		outPair++;
	}

	return 0;
}

/* Compare class for the sort that does the partitioning. */
template< class Fsm, class State, class Transition, class Key > 
		bool MarkCompare<Fsm, State, Transition, Key>::
		shouldMark( MarkIndex<State> &markIndex, const State *state1, 
			const State *state2 )
{
	/* Test default transitions. */
	if ( keyOps->shouldMarkPtr( markIndex, state1->outDefault, 
			state2->outDefault ) )
		return true;

	/* Use a pair iterator to get the transition pairs. */
	PairIter outPair( state1, state2, keyOps, false );
	while ( ! outPair.end() ) {
		switch ( outPair.userState ) {

		case PairIter::TransInS1:
		case PairIter::RangeInS1:
			if ( keyOps->shouldMarkPtr( markIndex, 
					outPair.s1Tel->value, outPair.defTrans ) )
				return true;
			break;

		case PairIter::TransInS2:
		case PairIter::RangeInS2:
			if ( keyOps->shouldMarkPtr( markIndex,
					outPair.defTrans, outPair.s2Tel->value ) )
				return true;
			break;

		case PairIter::RangeOverlap:
		case PairIter::TransOverlap:
			if ( keyOps->shouldMarkPtr( markIndex,
					outPair.s1Tel->value, outPair.s2Tel->value ) )
				return true;
			break;

		case PairIter::BreakS1:
		case PairIter::BreakS2:
			break;
		}
		outPair++;
	}

	return false;
}


/** Init the iterator by advancing to the first item. */
template< class State, class Transition, class Key >
		FsmOutIter<State, Transition, Key>::FsmOutIter( State *state )
:
	state(state),
	itState(Begin)
{
	findNext();
}

/** Postfix operator. Save result for return then increment. */
template< class State, class Transition, class Key >
		Transition *FsmOutIter<State, Transition, Key>::operator++(int)
{
	Transition *retVal = trans;
	findNext();
	return retVal;
}

/** Prefix operator. Icrement first, then return result. */
template< class State, class Transition, class Key >
		Transition *FsmOutIter<State, Transition, Key>::operator++()
{
	findNext();
	return trans;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case end() returns true. */
template< class State, class Transition, class Key >
		void FsmOutIter<State, Transition, Key>::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:     goto entryBegin;
		case Trans:     goto entryTrans;
		case Range:     goto entryRange;
		case Default:   goto entryDefault;
		case End:       goto entryEnd;
	}

	entryBegin:

	/* Loop over outList transitions. */
	transEl = state->outList.data;
	nTransEl = state->outList.length();
	for ( i = 0; i < nTransEl; i++, transEl++ ) {
		if ( transEl->value != 0 ) {
			/* Save the state of the iterator and return. */
			trans = transEl->value;
			CO_RETURN( Trans );
		}
	}

	/* Loop over outRange transitions. */
	transEl = state->outRange.data;
	nTransEl = state->outRange.length();
	for ( i = 0; i < nTransEl; i+=2, transEl+=2 ) {
		if ( transEl->value != 0 ) {
			/* Save the state of the iterator and return. */
			trans = transEl->value;
			CO_RETURN( Range );
		}
	}

	/* Process default transition. */
	if ( state->outDefault != 0 ) {
		/* Save the state of the iterator and return. */
		trans = state->outDefault;
		CO_RETURN( Default );
	}

	CO_RETURN( End );
}

/** Init the iterator by advancing to the first item. */
template< class Fsm, class State, class Transition, class Key >
		FsmUniOutIter<Fsm, State, Transition, Key>::FsmUniOutIter( 
		State *state, Fsm *keyOps )
:
	state(state),
	itState(Begin),
	keyOps(keyOps)
{
	findNext();
}

/** Postfix operator. Save result for return then increment. */
template< class Fsm, class State, class Transition, class Key >
		Transition *FsmUniOutIter<Fsm, State, Transition, Key>::operator++(int)
{
	Transition *retVal = trans;
	findNext();
	return retVal;
}

/** Prefix operator. Icrement first, then return result. */
template< class Fsm, class State, class Transition, class Key >
		Transition *FsmUniOutIter<Fsm, State, Transition, Key>::operator++()
{
	findNext();
	return trans;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case end() returns true. */
template< class Fsm, class State, class Transition, class Key >
		void FsmUniOutIter<Fsm, State, Transition, Key>::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine based on the iterator state. */
	switch ( itState ) {
		case Begin:        goto entryBegin;
		case SingleLeft:   goto entrySingleLeft;
		case RangeLeft:    goto entryRangeLeft;
		case BothLeft:     goto entryBothLeft;
		case End:          goto entryEnd;
	}

	entryBegin:

	/* Load up the transition element pointers. */
	transEl = state->outList.data;
	endTransEl = transEl + state->outList.length();
	rangeEl = srcRangeEl = state->outRange.data;
	endRangeEl = srcRangeEl + state->outRange.length();

	while ( true ) {
		if ( transEl == endTransEl ) {
			while ( rangeEl != endRangeEl ) {
				lowerKey = rangeEl[0].key;
				upperKey = rangeEl[1].key;
				trans = rangeEl[0].value;
				CO_RETURN( RangeLeft );

				/* Advance over the range. */
				srcRangeEl += 2;
				rangeEl = srcRangeEl;
			}
			break;
		}
		else if ( rangeEl == endRangeEl ) {
			while ( transEl != endTransEl ) {
				lowerKey = upperKey = transEl->key;
				trans = transEl->value;
				CO_RETURN( SingleLeft );

				/* Advance over the transition. */
				transEl += 1;
			}
			break;
		}
		/* Single is entirely below range. */
		else if ( keyOps->lt( transEl->key, rangeEl[0].key ) ) {
			/* Return the single key. */
			lowerKey = upperKey = transEl->key;
			trans = transEl->value;

			/* Advance over the transition. */
			transEl += 1;
		}
		/* Single is entirely above range. */
		else if ( keyOps->lt( rangeEl[1].key, transEl->key ) ) {
			/* Return the range. */
			lowerKey = rangeEl[0].key;
			upperKey = rangeEl[1].key;
			trans = rangeEl[0].value;

			/* Advance over entire range. */
			srcRangeEl += 2;
			rangeEl = srcRangeEl;
		}
		else {
			/* Overlap. Take a copy of the head range cause it 
			 * will be broken. */
			headRange[0] = rangeEl[0];
			headRange[1] = rangeEl[1];
			rangeEl = headRange;

			/* Range sticks out front? */
			if ( keyOps->lt( rangeEl[0].key, transEl->key ) ) {
				lowerKey = rangeEl[0].key;
				upperKey = transEl->key;
				keyOps->dec( upperKey );
				trans = rangeEl[0].value;

				/* Shorten the range. */
				rangeEl[0].key = transEl->key;
			}
			/* Single is first on range. */
			else {
				lowerKey = upperKey = transEl->key;
				trans = transEl->value;

				/* Advance over trans and shorten the range by one. */
				transEl += 1;
				keyOps->inc( rangeEl[0].key );
			}

			/* If the range has been shorted to zero length, skip over it. */
			if ( keyOps->gt( rangeEl[0].key, rangeEl[1].key ) ) {
				/* Advance over the range. */
				srcRangeEl += 2;
				rangeEl = srcRangeEl;
			}
		}

		/* If the trans is not null, then return it. */
		CO_RETURN( BothLeft );
	}
	CO_RETURN( End );
}

/** Init the iterator by advancing to the first item. */
template< class State, class Transition, class Key >
		FsmSingleIter<State, Transition, Key>::FsmSingleIter( State *state )
{
	transEl = state->outList.data;
	endEl = state->outList.data + state->outList.length();
}

/** Init the iterator by advancing to the first item. */
template< class State, class Transition, class Key >
		FsmRangeIter<State, Transition, Key>::FsmRangeIter( State *state )
{
	transEl = state->outRange.data;
	endEl = state->outRange.data + state->outRange.length();
}


/** Init the iterator by advancing to the first item. */
template< class State, class Transition, class Key >
		FsmInIter<State, Transition, Key>::FsmInIter( State *state )
:
	state(state),
	itState(Begin)
{
	findNext();
}

/** Postfix operator. Save result for return then increment. */
template< class State, class Transition, class Key >
		Transition *FsmInIter<State, Transition, Key>::operator++(int)
{
	Transition *retVal = trans;
	findNext();
	return retVal;
}

/** Prefix operator. Icrement first, then return result. */
template< class State, class Transition, class Key >
		Transition *FsmInIter<State, Transition, Key>::operator++()
{
	findNext();
	return trans;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case end() returns true. */
template< class State, class Transition, class Key >
		void FsmInIter<State, Transition, Key>::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:     goto entryBegin;
		case Trans:     goto entryTrans;
		case Range:     goto entryRange;
		case Default:   goto entryDefault;
		case End:       goto entryEnd;
	}

	entryBegin:

	/* Loop over inList transitions. */
	trans = state->inList.head;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Trans );

			/* Next transition. */
		trans = trans->FsmTransInListEl<Transition>::next;
	}

	/* Loop over inRange transitions. */
	trans = state->inRange.head;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Range );

		/* Next transition. */
		trans = trans->FsmTransInListEl<Transition>::next;
	}

	/* Loop over the list of transitions at the default trans. */
	trans = state->inDefault.head;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Default );

		/* Next transition. */
		trans = trans->FsmTransInListEl<Transition>::next;
	}

	/* Done, go into end state. */
	CO_RETURN( End );
}

/** Init the iterator by advancing to the first item. */
template< class Fsm, class State, class Transition, class Key >
		FsmPairIter<Fsm, State, Transition, Key>::
		FsmPairIter( const State *state1, const State *state2, 
			Fsm *keyOps, bool wantBreaks )
:
	state1(state1),
	state2(state2),
	itState(Begin),
	keyOps(keyOps),
	wantBreaks(wantBreaks)
{
	findNext();
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case end() returns true. */
template< class Fsm, class State, class Transition, class Key >
		void FsmPairIter<Fsm, State, Transition, Key>::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Temporary vars used for finding ranges and defaults. */
	TransEl *rangeTel;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:              goto entryBegin;
		case ConsumeS1Trans:     goto entryConsumeS1Trans;
		case ConsumeS2Trans:     goto entryConsumeS2Trans;
		case OnlyInS1Trans:      goto entryOnlyInS1Trans;
		case OnlyInS2Trans:      goto entryOnlyInS2Trans;
		case InBothTrans:        goto entryInBothTrans;
		case ConsumeS1Range:     goto entryConsumeS1Range;
		case ConsumeS2Range:     goto entryConsumeS2Range;
		case OnlyInS1Range:      goto entryOnlyInS1Range;
		case OnlyInS2Range:      goto entryOnlyInS2Range;
		case S1SticksOut:        goto entryS1SticksOut;
		case S1SticksOutBreak:   goto entryS1SticksOutBreak;
		case S2SticksOut:        goto entryS2SticksOut;
		case S2SticksOutBreak:   goto entryS2SticksOutBreak;
		case S1DragsBehind:      goto entryS1DragsBehind;
		case S1DragsBehindBreak: goto entryS1DragsBehindBreak;
		case S2DragsBehind:      goto entryS2DragsBehind;
		case S2DragsBehindBreak: goto entryS2DragsBehindBreak;
		case ExactOverlap:       goto entryExactOverlap;
		case End:                goto entryEnd;
	}

	entryBegin:

	/* Pointers used to walk through out lists concurrently. */
	s1Tel = state1->outList.data;
	s1EndTel = s1Tel + state1->outList.length();
	s2Tel = state2->outList.data;
	s2EndTel = s2Tel + state2->outList.length();

	/* Concurrently scan both out lists. */
	while ( true ) {
		if ( s1Tel == s1EndTel ) {
			/* We are at the end of state1's transitions. Process the rest of
			 * state2's transitions. */
			while ( s2Tel != s2EndTel ) {
				/* Find a transition to serve as the default. If s2Tel->Key is
				 * in a range in state1, use that range (which may be null),
				 * otherwise use state1->default. */
				rangeTel = state1->outRange.findRange( s2Tel->key, keyOps );
				if ( rangeTel != 0 )
					defTrans = rangeTel->value;
				else
					defTrans = state1->outDefault;

				/* Trans is only in s2. */
				CO_RETURN2( ConsumeS2Trans, TransInS2 );

				s2Tel++;
			}
			break;
		}
		else if ( s2Tel == s2EndTel ) {
			/* We are at the end of state2's transitions. Process the rest of
			 * state1's transitions. */
			while ( s1Tel != s1EndTel ) {
				/* Find a transition to serve as the default. If s1Tel->key is
				 * in a range in state2, use that range (which may be null),
				 * otherwise use state2->default. */
				rangeTel = state2->outRange.findRange( s1Tel->key, keyOps );
				if ( rangeTel != 0 )
					defTrans = rangeTel->value;
				else
					defTrans = state2->outDefault;

				/* Trans is only in s1. */
				CO_RETURN2( ConsumeS1Trans, TransInS1 );

				s1Tel++;
			}
			break;
		}
		/* Both state1 and state2 tels are good. */
		else if ( keyOps->lt( s1Tel->key, s2Tel->key ) ) {
			/* A trans exists in state1 on s1Tel->key but not in state2 on
			 * s2Tel->key.  Find a transition from state2 to serve as the
			 * default. If s1Tel->key in a range in state2, use that range
			 * (which may be null), otherwise use state2->default. */
			rangeTel = state2->outRange.findRange( s1Tel->key, keyOps );
			if ( rangeTel != 0 )
				defTrans = rangeTel->value;
			else
				defTrans = state2->outDefault;

			/* Trans is only in s1. */
			CO_RETURN2( OnlyInS1Trans, TransInS1 );

			s1Tel++;
		}
		else if ( keyOps->gt( s1Tel->key, s2Tel->key ) ) {
			/* A trans exists in state2 on s2Tel->key but not in state1 on
			 * s1Tel->key.  Find a transition from state1 to serve as the
			 * default. If s2Tel->key in a range in state1, use that range
			 * (which may be null), otherwise use state1->default. */
			rangeTel = state1->outRange.findRange( s2Tel->key, keyOps );
			if ( rangeTel != 0 )
				defTrans = rangeTel->value;
			else
				defTrans = state1->outDefault;

			/* Trans is only in s2. */
			CO_RETURN2( OnlyInS2Trans, TransInS2 );

			s2Tel++;
		}
		else {
			/* Keys match up. Trans on the same char. */

			/* Trans is in both. */
			CO_RETURN2( InBothTrans, TransOverlap );

			s1Tel++;
			s2Tel++; 
		}
	}


	/* Pointers used to walk through out ranges concurrently. This needs to be
	 * done a little differently than with the out list. Two head pointers are
	 * maintained, one being the head of the out range the other being a
	 * pointer to the virtual head, so we can modify the head range without
	 * changing the out ranges. */
	s1Range = state1->outRange.data;
	s1Tel = s1Range;
	s1EndTel = s1Range + state1->outRange.length();

	/* Pointers for state 2. */
	s2Range = state2->outRange.data;
	s2Tel = s2Range;
	s2EndTel = s2Range + state2->outRange.length();

	/* Concurrently scan both out ranges. */
	while ( true ) {
		if ( s1Range == s1EndTel ) {
			/* We are at the end of state1's ranges. Process the rest of
			 * state2's ranges. */
			while ( s2Range != s2EndTel ) {
				/* Range is only in s2. */
				defTrans = state1->outDefault;
				CO_RETURN2( ConsumeS2Range, RangeInS2 );

				s2Range += 2;
				s2Tel = s2Range;
			}
			break;
		}
		else if ( s2Range == s2EndTel ) {
			/* We are at the end of state2's ranges. Process the rest of
			 * state1's ranges. */
			while ( s1Range != s1EndTel ) {
				/* Range is only in s1. */
				defTrans = state2->outDefault;
				CO_RETURN2( ConsumeS1Range, RangeInS1 );

				s1Range += 2;
				s1Tel = s1Range;
			}
			break;
		}
		/* Both state1's and state2's transition elements are good.
		 * The signiture of no overlap is a back key being in front of a
		 * front key. */
		else if ( keyOps->lt( s1Tel[1].key, s2Tel[0].key ) ) {
			/* A range exists in state1 that does not overlap with state2. */
			defTrans = state2->outDefault;
			CO_RETURN2( OnlyInS1Range, RangeInS1 );

			s1Range += 2;
			s1Tel = s1Range;
		}
		else if ( keyOps->lt( s2Tel[1].key, s1Tel[0].key ) ) {
			/* A range exists in state2 that does not overlap with state1. */
			defTrans = state1->outDefault;
			CO_RETURN2( OnlyInS2Range, RangeInS2 );

			s2Range += 2;
			s2Tel = s2Range;
		}
		/* There is overlap, must mix the ranges in some way. */
		else if ( keyOps->lt( s1Tel[0].key, s2Tel[0].key ) ) {
			/* Range from state1 sticks out front. Must break it into
			 * non-overlaping and overlaping segments. */

			/* First get a copy of the head of range 1. We may be copying from the
			 * copy, this we cannot tell without looking at the pointers. Just
			 * do it anyways. */
			s1HeadTel[0] = s1Tel[0];
			s1HeadTel[1] = s1Tel[1];
			s1Tel = s1HeadTel;

			/* Now do the break. We must save the old end of the range and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s1NextTel[0] = s1Tel[0];
			s1NextTel[1] = s1Tel[1];
			s1Tel[1].key = s2Tel[0].key;
			keyOps->dec( s1Tel[1].key );
			s1NextTel[0].key = s2Tel[0].key;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s1. This gives them a
				 * chance to duplicate s1Tel[0,1].value. */
				CO_RETURN2( S1SticksOutBreak, BreakS1 );
			}

			/* Broken off range is only in s1. */
			defTrans = state2->outDefault;
			CO_RETURN2( S1SticksOut, RangeInS1 );

			/* Advance over the part sticking out front. */
			s1Tel[0] = s1NextTel[0];
			s1Tel[1] = s1NextTel[1];
		}
		else if ( keyOps->lt( s2Tel[0].key, s1Tel[0].key ) ) {
			/* Range from state2 sticks out front. Must break it into
			 * non-overlaping and overlaping segments. */

			/* First get a copy of the head of range 2. We may be copying from the
			 * copy, this we cannot tell without looking at the pointers. Just
			 * do it anyways. */
			s2HeadTel[0] = s2Tel[0];
			s2HeadTel[1] = s2Tel[1];
			s2Tel = s2HeadTel;

			/* Now do the break. We must save the old end of the range and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s2NextTel[0] = s2Tel[0];
			s2NextTel[1] = s2Tel[1];
			s2Tel[1].key = s1Tel[0].key;
			keyOps->dec( s2Tel[1].key );
			s2NextTel[0].key = s1Tel[0].key;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s2. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S2SticksOutBreak, BreakS2 );
			}

			/* Broken off range is only in s2. */
			defTrans = state1->outDefault;
			CO_RETURN2( S2SticksOut, RangeInS2 );

			/* Advance over the part sticking out front. */
			s2Tel[0] = s2NextTel[0];
			s2Tel[1] = s2NextTel[1];
		}
		/* Low ends are even. Are the high ends even? */
		else if ( keyOps->lt( s1Tel[1].key, s2Tel[1].key ) ) {
			/* Range from state2 goes longer than the range from state1. We
			 * must break the range from state2 into an evenly overlaping
			 * segment. */

			/* We are going to break range 2, copy it first. We may be copying
			 * from the copy. We cannot tell without looking at the pointers.
			 * Just do it anyways. */
			s2HeadTel[0] = s2Tel[0];
			s2HeadTel[1] = s2Tel[1];
			s2Tel = s2HeadTel;

			/* Now do the break. We must save the old end of range 2 and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s2NextTel[0] = s2Tel[0];
			s2NextTel[1] = s2Tel[1];
			s2Tel[1].key = s1Tel[1].key;
			s2NextTel[0].key = s1Tel[1].key;
			keyOps->inc( s2NextTel[0].key );

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s2. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S2DragsBehindBreak, BreakS2 );
			}

			/* Breaking s2 produces exact overlap. */
			CO_RETURN2( S2DragsBehind, RangeOverlap );

			/* Advance over the front we just broke off of range 2. */
			s2Tel[0] = s2NextTel[0];
			s2Tel[1] = s2NextTel[1];

			/* Advance over the entire s1Tel. We have consumed it. */
			s1Range += 2;
			s1Tel = s1Range;
		}
		else if ( keyOps->lt( s2Tel[1].key, s1Tel[1].key ) ) {
			/* Range from state1 goes longer than the range from state2. We
			 * must break the range from state1 into an evenly overlaping
			 * segment. */

			/* We are going to break range 1, copy it first. We may be copying
			 * from the copy. We connot tell this without looking at the
			 * pointers. Just do it anyways. */
			s1HeadTel[0] = s1Tel[0];
			s1HeadTel[1] = s1Tel[1];
			s1Tel = s1HeadTel;

			/* Now do the break. We must save the old end of range 1 and the
			 * transition. We will change the range ourselves. The caller may
			 * change the transition. */
			s1NextTel[0] = s1Tel[0];
			s1NextTel[1] = s1Tel[1];
			s1Tel[1].key = s2Tel[1].key;
			s1NextTel[0].key = s2Tel[1].key;
			keyOps->inc( s1NextTel[0].key );

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s1. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S1DragsBehindBreak, BreakS1 );
			}

			/* Breaking s1 produces exact overlap. */
			CO_RETURN2( S1DragsBehind, RangeOverlap );

			/* Advance over the front we just broke off of range 1. */
			s1Tel[0] = s1NextTel[0];
			s1Tel[1] = s1NextTel[1];

			/* Advance over the entire s2Tel. We have consumed it. */
			s2Range += 2;
			s2Tel = s2Range;
		}
		else {
			/* There is an exact overlap. */
			CO_RETURN2( ExactOverlap, RangeOverlap );

			s1Range += 2;
			s1Tel = s1Range;
			s2Range += 2;
			s2Tel = s2Range;
		}
	}

	/* Done, go into end state. */
	CO_RETURN( End );
}


#endif /* _RLFSM_FSMSTATE_CPP */

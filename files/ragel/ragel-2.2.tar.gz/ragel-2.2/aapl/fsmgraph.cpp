/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  Aapl is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 *  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 *  more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Aapl; if not, write to the Free Software Foundation, Inc., 59
 *  Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _RLFSM_FSMGRAPH_CPP
#define _RLFSM_FSMGRAPH_CPP

#include <assert.h>

#include "fsmgraph.h"
#include "mergesort.h"

/* Other graph code files. */
#include "fsmstate.cpp"
#include "fsmbase.cpp"
#include "fsmattach.cpp"
#include "fsmmin.cpp"

/* Make a new state. The new state will be put on the graph's
 * list of state. The new state can be created final or non final. */
template < class Fsm, class State, class Transition, class Key >
		State *FsmGraph<Fsm, State, Transition, Key>::
		addState()
{
	/* Make the new state to return. */
	State *state = new State();

	if ( misfitAccounting ) {
		/* Create the new state on the misfit list. All states are created
		 * with no foreign in transitions. */
		misfitList.append( state );
	}
	else {
		/* Create the new state. */
		stateList.append( state );
	}

	/* Callback for user code. */
	static_cast<Fsm*>(this)->newState( state );
	return state;
}

template < class Fsm, class State, class Transition, class Key >
		Transition *FsmGraph<Fsm, State, Transition, Key>::
		addTrans()
{
	/* Make the transition. */
	Transition *trans = new Transition();

	/* Invoke the callback. */
	static_cast<Fsm*>(this)->newTrans( trans );
	return trans;
}

/**
 * \brief Construct an FSM that is the concatenation of an array of
 * characters.
 *
 * A new machine will be made that has len+1 states with one transition
 * between each state for each integer in str. IsSigned determines if the
 * integers are to be considered as signed or unsigned ints.
 *
 * \returns The new FSM.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		concatFsm( const Key *str, int len )
{
	/* Make the first state and set it as the start state. */
	State *last = addState();
	setEntry( 0, last );

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		State *ns = addState();
		attachNewTrans( last, ns, KeyTypeSingle, str[i], Key() );
		last = ns;
	}

	/* Make the last state the final state. */
	setFinState( last );
}

/**
 * \brief Construct a machine that matches one character.
 *
 * A new machine will be made that has two states with a single transition
 * between the states. IsSigned determines if the integers are to be
 * considered as signed or unsigned ints.
 *
 * \returns The new FSM.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		concatFsm( const Key &chr )
{
	/* Two states first start, second final. */
	State *start = addState();
	setEntry( 0, start );

	State *end = addState();
	setFinState( end );

	/* Attach on the character. */
	attachNewTrans( start, end, KeyTypeSingle, chr, Key() );
}

/**
 * \brief Construct a machine that matches any character in set.
 *
 * A new machine will be made that has two states and len transitions between
 * the them. If set contains any duplicate values then undefined behaviour
 * results. IsSigned determines if the intergers are to be considered as
 * signed or unsigned ints.
 *
 * \returns The new FSM.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		orFsm( const Key *set, int len )
{
	/* Two states first start, second final. */
	State *start = addState();
	setEntry( 0, start );

	State *end = addState();
	setFinState( end );

	/* Attach on all the integers in the given string of ints. */
	for ( int i = 0; i < len; i++ )
		attachNewTrans( start, end, KeyTypeSingle, set[i], Key() );
}

/**
 * \brief Construct a machine that matches the empty word.
 *
 * A new machine will be made with only one state. The new state will be both
 * a start and final state. IsSigned determines if the machine has a signed or
 * unsigned alphabet. Fsm operations must be done on machines with the same
 * alphabet signedness.
 *
 * \returns The new FSM.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		nullFsm( )
{
	/* Give it one state with no transitions making it
	 * the start state and final state. */
	State *startState = addState();
	setEntry( 0, startState );
	setFinState( startState );
}

/**
 * \brief Construct a machine that matches any character.
 *
 * A new machine will be made with two states and a default transition between
 * them. IsSigned determines if the machine has a signed or unsigned alphabet.
 * Fsm operations must be done on machines with the same alphabet signedness.
 *
 * \returns The new FSM.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		dotFsm( )
{
	/* Two states first start, second final. */
	State *start = addState();
	setEntry( 0, start );

	State *end = addState();
	setFinState( end );

	/* Attach on the any char. */
	attachNewTrans( start, end, KeyTypeDefault, Key(), Key() );
}

/**
 * \brief Construct a machine that matches any string of characters.
 *
 * A new machine will be made with a single state that is both start and final
 * and that has default transition back to itself. IsSigned determines if the
 * machine has a signed or unsiged alphabet. Fsm operations must be done on
 * machines with the same signednesss.
 *
 * \returns The new FSM.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		dotStarFsm( )
{
	/* One state which is final and is the start state. */
	State *start = addState();
	setEntry( 0, start );
	setFinState( start );

	/* Attach start to start on default. */
	attachNewTrans( start, start, KeyTypeDefault, Key(), Key() );
}

/**
 * \brief Construct a machine that matches a range of characters.
 *
 * A new machine will be made with two states and a range transition between
 * them. The range will match any characters from low to high inclusive. Low
 * should be less than or equal to high otherwise undefined behaviour results.
 * IsSigned determines if the integers are to be considered as signed or
 * unsigned ints.
 *
 * \returns The new FSM.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		rangeFsm( const Key &low, const Key &high )
{
	/* Two states first start, second final. */
	State *start = addState();
	setEntry( 0, start );

	State *end = addState();
	setFinState( end );

	/* Attach using the range of characters. */
	attachNewTrans( start, end, KeyTypeRange, low, high );
}

/**
 * \brief Kleene star operator.
 *
 * Makes this machine the kleene star of itself. Any transitions made going
 * out of the machine and back into itself will be notified that they are
 * leaving transitions by having the leavingFromState callback invoked.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		starOp( )
{
	/* For the merging process. */
	MergeData md;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of the original start state. */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );

	/* Get a copy of the final state set before creating the new start state.
	 * It may get set final and we don't want the start state to be included in
	 * the final state set. If it is included in the final state set then all
	 * the final states after it get the transitions of the start state doubled
	 * up. That's incorrect.*/
	StateSet finStateSetCopy( finStateSet );

	/* This will be the new start state. It will be set final after the
	 * merging of the final states with the start state is complete. */
	State *newStart = addState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* From here on we need the new start state as start state set. */
	startStateSet.setAs( newStart );

	/* For all the final states, merge with the new start state. */
	State **st = finStateSetCopy.data;
	int nst = finStateSetCopy.length();
	for (int i = 0; i < nst; i++, st++)
		mergeStates( md, *st, startStateSet, true );

	/* Now it is safe to merge the start state with itself (provided it
	 * is set final). */
	if ( newStart->stateBits & SB_ISFINAL )
		mergeStates( md, newStart, startStateSet, true );

	/* Now ensure the new start state is a final state. */
	setFinState( newStart );

	/* Fill in any states that were newed up as combinations of others. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		repeatOp( int times )
{
	/* Must be 1 and up. 0 produces null machine and requires deleting this. */
	assert( times > 0 );

	/* A repeat of one does absolutely nothing. */
	if ( times == 1 )
		return;

	/* Make a machine to make copies from. */
	Fsm *copyFrom = new Fsm( *(static_cast<Fsm*>(this)) );

	/* Concatentate duplicates onto the end up until before the last. */
	for ( int i = 1; i < times-1; i++ ) {
		Fsm *dup = new Fsm( *copyFrom );
		doConcat( dup, 0, false );
	}

	/* Now use the copyFrom on the end. */
	doConcat( copyFrom, 0, false );
}

template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		optionalRepeatOp( int times )
{
	/* Must be 1 and up. 0 produces null machine and requires deleting this. */
	assert( times > 0 );

	/* A repeat of one optional merely allows zero string. */
	if ( times == 1 ) {
		setFinState( findEntry(0) );
		return;
	}

	/* Make a machine to make copies from. */
	Fsm *copyFrom = new Fsm( *(static_cast<Fsm*>(this)) );

	/* The state set used in the from end of the concatentation. Starts with
	 * the initial final state set, then after each concatenation, gets set to
	 * the the final states that come from the the duplicate. */
	StateSet lastFinSet( finStateSet );

	/* Set the initial state to zero to allow zero copies. */
	setFinState( findEntry(0) );

	/* Concatentate duplicates onto the end up until before the last. */
	for ( int i = 1; i < times-1; i++ ) {
		/* Make a duplicate for concating and set the fin bits to graph 2 so we
		 * can pick out it's final states after the optional style concat. */
		Fsm *dup = new Fsm( *copyFrom );
		dup->setFinBits( SB_GRAPH2 );
		doConcat( dup, &lastFinSet, true );

		/* Clear the last final state set and make the new one by taking only
		 * the final states that come from graph 2.*/
		lastFinSet.empty();
		for ( int i = 0; i < finStateSet.length(); i++ ) {
			/* If the state came from graph 2, add it to the last set and clear
			 * the bits. */
			State *fs = finStateSet[i];
			if ( fs->stateBits & SB_GRAPH2 ) {
				lastFinSet.insert( fs );
				fs->stateBits &= ~SB_GRAPH2;
			}
		}
	}

	/* Now use the copyFrom on the end, no bits set, no bits to clear. */
	doConcat( copyFrom, &lastFinSet, true );
}

/* Fsm concatentation worker. Supports treating the concatentation as optional,
 * which essentially leaves the final states of machine one as final. */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		doConcat( Fsm *other, StateSet *fromStates, bool optional )
{
	/* For the merging process. */
	StateSet finStateSetCopy, startStateSet;
	MergeData md;

	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Build a state set consisting of other's start state. */
	startStateSet.insert( other->findEntry(0) );

	/* Unset other's start state before bringing in the entry points. */
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Bring in other's states into our state lists. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* If from states is not set, then get a copy of our final state set before
	 * we clobber it and use it instead. */
	if ( fromStates == 0 ) {
		finStateSetCopy = finStateSet;
		fromStates = &finStateSetCopy;
	}

	/* Unset all of our final states and get the final states from other. */
	if ( !optional )
		unsetAllFinStates();
	finStateSet.insert( other->finStateSet );
	
	/* Since other's lists are empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our former final states with the start state of other. */
	for ( int i = 0; i < fromStates->length(); i++ ) {
		State *state = fromStates->data[i];

		/* Merge the former final state with other's start state. */
		mergeStates( md, state, startStateSet, true );

		/* If the former final state was not reset final then we must clear
		 * the state's out trans data. If it got reset final then it gets to
		 * keep its out trans data. This must be done before fillInStates gets
		 * called to prevent the data from being sourced. */
		if ( !(state->stateBits & SB_ISFINAL) )
			static_cast<Fsm*>(this)->relinquishFinal( state );
	}

	/* Fill in any new states made from merging. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/**
 * \brief Concatenation operator.
 *
 * Concatenates other to the end of this machine. Other is deleted.  Any
 * transitions made leaving this machine and entering into other are notified
 * that they are leaving transitions by having the leavingFromState callback
 * invoked.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		concatOp( Fsm *other )
{
	doConcat( other, 0, false );
}


template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		doOr( Fsm *other )
{
	/* For the merging process. */
	MergeData md;

	/* Build a state set consisting of both start states */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );
	startStateSet.insert( other->findEntry(0) );

	/* Both of the original start states loose their start state status. */
	unsetEntry( 0 );
	other->unsetEntry( 0 );

	/* Bring in the rest of other's entry points. */
	copyInEntryPoints( other );
	other->entryPoints.empty();

	/* Merge the lists. This will move all the states from other
	 * into this. No states will be deleted. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* Move the final set data from other into this. */
	finStateSet.insert(other->finStateSet);
	other->finStateSet.empty();

	/* Since other's list is empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Create a new start state. */
	State *newStart = addState();
	setEntry( 0, newStart );

	/* Merge the start states. */
	mergeStates( md, newStart, startStateSet, false );

	/* Fill in any new states made from merging. */
	fillInStates( md );
}

/**
 * \brief Union operator.
 *
 * Unions other with this machine. Other is deleted.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		unionOp( Fsm *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Call Worker routine. */
	doOr( other );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/**
 * \brief Intersection operator.
 *
 * Intersects other with this machine. Other is deleted.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		intersectOp( Fsm *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits on this and other to want each other. */
	setFinBits( SB_GRAPH1 );
	other->setFinBits( SB_GRAPH2 );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetIncompleteFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}

/**
 * \brief Subtraction operator.
 *
 * Set subtracts other machine from this machine. Other is deleted.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		subtractOp( Fsm *other )
{
	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Set the fin bits of other to be killers. */
	other->setFinBits( SB_GRAPH1 );

	/* Call worker Or routine. */
	doOr( other );

	/* Unset any final states that are no longer to 
	 * be final due to final bits. */
	unsetKilledFinals();

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );

	/* Remove states that have no path to a final state. */
	removeDeadEndStates();
}

template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		epsilonOp( State **fromStates, int nStates, 
				Fsm **others, int nOthers )
{
	/* For the merging process. */
	MergeData md;
	StateSet startStateSet;

	/* Turn on misfit accounting for this graph. */
	setMisfitAccounting( true );

	for ( int i = 0; i < nOthers; i++ ) {
		/* Turn on misfit accounting for other. */
		others[i]->setMisfitAccounting( true );

		/* Build the state set consisting just the other's start states. */
		startStateSet.insert( others[i]->findEntry(0) );

		/* Other loosees start states, which gets glued to the from states. */
		others[i]->unsetEntry( 0 );

		/* Bring in the rest of other's entry points. */
		copyInEntryPoints( others[i] );
		others[i]->entryPoints.empty();

		/* Merge the lists. This will move all the states from other
		 * into this. No states will be deleted. */
		stateList.append( others[i]->stateList );
		misfitList.append( others[i]->misfitList );

		/* Move the final set data from other into this. */
		finStateSet.insert( others[i]->finStateSet );
		others[i]->finStateSet.empty();

		/* Since other's list is empty, we can delete the fsm without
		 * affecting any states. */
		delete others[i];
	}

	/* Merge others start state with each state in the list of from states. */
	for ( int i = 0; i < nStates; i++ )
		mergeStates( md, fromStates[i], startStateSet, false );

	/* Fill in any new states made from merging. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/* Unset any final states that are no longer to be final due to final bits. */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		unsetKilledFinals()
{
	/* Duplicate the final state set before we begin modifying it. */
	StateSet fin( finStateSet );

	for ( int s = 0; s < fin.length(); s++ ) {
		/* Check for killing bit. */
		State *state = fin.data[s];
		if ( state->stateBits & SB_GRAPH1 ) {
			/* One final state is a killer, set to non-final. */
			unsetFinState( state );
		}

		/* Clear all killing bits. Non final states should never have had those
		 * state bits set in the first place. */
		state->stateBits &= ~SB_GRAPH1;
	}
}

/* Unset any final states that are no longer to be final due to final bits. */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		unsetIncompleteFinals()
{
	/* Duplicate the final state set before we begin modifying it. */
	StateSet fin( finStateSet );

	for ( int s = 0; s < fin.length(); s++ ) {
		/* Check for one set but not the other. */
		State *state = fin.data[s];
		if ( state->stateBits & SB_BOTH && 
				(state->stateBits & SB_BOTH) != SB_BOTH )
		{
			/* One state wants the other but it is not there. */
			unsetFinState( state );
		}

		/* Clear wanting bits. Non final states should never have had those
		 * state bits set in the first place. */
		state->stateBits &= ~SB_BOTH;
	}
}

/* Ensure that the start state is free of entry points (aside from the fact
 * that it is the start state). If the start state has entry points then Make a
 * new start state by merging with the old one. Useful before modifying start
 * transitions. If the existing start state has any entry points other than the
 * start state entry then modifying its transitions changes more than the start
 * transitions. So isolate the start state by separating it out such that it
 * only has start stateness as it's entry point. */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		isolateStartState( )
{
	/* For the merging process. */
	MergeData md;

	/* Bail out if the start state is already isolated. */
	if ( isStartStateIsolated() )
		return;

	/* Turn on misfit accounting to possibly catch the old start state. */
	setMisfitAccounting( true );

	/* Build a state set consisting of only the start state. */
	StateSet startStateSet;
	startStateSet.insert( findEntry(0) );

	/* This will be the new start state. The existing start
	 * state is merged with it. */
	State *newStart = addState();
	changeEntry( 0, newStart );

	/* Merge the new start state with the old one to isolate it. */
	mergeStates( md, newStart, startStateSet, false );

	/* Stfil and stateDict will be empty because the merging of the old start
	 * state into the new one will not have any conflicting transitions. */
	assert( md.stateDict.treeSize == 0 );
	assert( md.stfillHead == 0 );

	/* The old start state may be unreachable. Remove the misfits and turn off
	 * misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		mergeStates( MergeData &md, State *destState, StateSet &stateSet, 
				bool leavingFsm )
{
	/* If a merge is to make transitions that leave an fsm then the state set
	 * should have only one element in it. This is to protect against writing
	 * and reading of out trans data as determined by the order of state in
	 * state set. */
	assert( ! ( leavingFsm && stateSet.size() > 1 ));

	State **stp = stateSet.data;
	int nst = stateSet.length();
	for ( int i = 0; i < nst; i++, stp++ ) {
		State *src = *stp;

		/* Get the out transitions. */
		outTransCopy( md, destState, src, leavingFsm );

		/* Get its bits and final state status. */
		destState->stateBits |= ( src->stateBits & ~SB_ISFINAL );
		if ( src->stateBits & SB_ISFINAL )
			setFinState( destState );

		/* Call user routine. */
		static_cast<Fsm*>(this)->addInState( destState, src );
	}
}

template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		fillInStates( MergeData &md )
{
	/* Merge any states that are awaiting merging. This will likey cause
	 * other states to be added to the stfil list. */
	State *state = md.stfillHead;
	while ( state != 0 ) {
		mergeStates( md, state, state->stateDictEl->stateSet, false );
		state = state->alg.next;
	}

	/* Delete the state sets of all states that are on the fill list. */
	state = md.stfillHead;
	while ( state != 0 ) {
		/* Delete and reset the state set. */
		delete state->stateDictEl;
		state->stateDictEl = 0;

		/* Next state in the stfill list. */
		state = state->alg.next;
	}

	/* StateDict will still have it's ptrs/size set but all of it's element
	 * will be deleted so we don't need to clean it up. */
}

/*
 * Callbacks.
 */

/**
 * \brief Compare relative priorities of two transitions.
 *
 * Compare two transitions according to their relative priority. Since the
 * base transition has no priority associated with it, the default is to
 * return equal.
 */
template < class Fsm, class State, class Transition, class Key >
		int FsmGraph<Fsm, State, Transition, Key>::
		comparePrior( Transition *trans1, Transition *trans2 )
{
	return 0;
}

/**
 * \brief Compare transition data of two transitions.
 *
 * Compare two transitions according to the data contained in the transitions.
 * Data means any properties added to user transitions that may differentiate
 * them. Since the base transition has no data, the default is to return
 * equal.
 */
template < class Fsm, class State, class Transition, class Key >
		int FsmGraph<Fsm, State, Transition, Key>::
		compareTransData( Transition *trans1, Transition *trans2 )
{
	return 0;
}

/**
 * \brief Compare state data of two states.
 *
 * Compare two states accroding to the data contained in the states.  Data
 * means any properties added to user states that may differentiate them.
 * Since the base states has no data, the default is to return equal.
 */
template< class Fsm, class State, class Transition, class Key >
		int FsmGraph<Fsm, State, Transition, Key>::
		compareStateData( const State *state1, const State *state2 )
{
	return 0;
}

/**
 * \brief Add in another transition into this transition.
 *
 * Draw in any properties of srcTrans into this transition. AddInTrans is
 * called when a new transitions is made that will be a duplicate of another
 * transition or a combination of several other transitions. AddInTrans will
 * be called for each transition that the new transition is to represent.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		addInTrans( Transition *destTrans, Transition *srcTrans )
{
}

template< class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		newTrans( Transition *trans )
{
}

template< class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		deleteTrans( Transition *trans )
{
}

/**
 * \brief Add in the out transition properties of a state into this transition.
 *
 * Draw in the out transition properties of srcState into this transition.
 * LeavingFromState is called when concatOp or starOp is called with
 * leavingFsm = true and a transition is made that represents leaving machine
 * one and going to machine two in the case of concatOp and leaving a machine
 * to go back into itself in the case of the star operator.
 */
template < class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		leavingFromState( Transition *destTrans, State *srcState )
{
}

/**
 * \brief Notify that otherState is equivalent to this and that it is to be
 * deleted.
 *
 * Callback invoked when two states are made into one by the minimization
 * process. All transitions going into otherState will be redirected into
 * this before other is deleted.
 */
template< class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		fuseInState( State *destState, State *srcState )
{
}

/**
 * \brief Add in another state into this state.
 *
 * Draw in any properties of srcState into this state. AddInState is called
 * when a new state is made that will be a duplicate of another state or a
 * combination of several other states. AddInState will be called for each
 * state that the new state is to represent.
 */
template< class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		addInState( State *destState, State *srcState )
{
}

/**
 * \brief Notify that a state is loosing its final state status.
 *
 * Callback invoked when a state looses its final state status. This is where
 * properties of final states get unset. At the point of invocation, it is
 * unspecified whether or not isFinState is set.
 */
template< class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		relinquishFinal( State *state )
{
}

template< class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		newState( State *state )
{
}

template< class Fsm, class State, class Transition, class Key >
		void FsmGraph<Fsm, State, Transition, Key>::
		deleteState( State *state )
{
}

#endif /* _RLFSM_FSMGRAPH_CPP */

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  Aapl is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 *  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 *  more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with Aapl; if not, write to the Free Software Foundation, Inc., 59
 *  Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _AAPL_AVLIPSET_H
#define _AAPL_AVLIPSET_H

/**
 * \addtogroup avltree 
 * @{
 */

/**
 * \class AvliPset
 * \brief Linked key-only oriented tree for a void* size key.
 *
 * AvliPset is an instantiation of AvliSet with a void* type. It has a small
 * inline interface on top of AvliSet that performs casting of types.
 * AvliPset is useful when a large number of sets are needed but code bloat
 * caused by multiple instantiations of templates in not acceptable.
 *
 * AvliPset stores only keys in element managed by the tree. AvliPset requires
 * that only a Key type be given. A compare class is not needed.  The key type
 * must be castable to a void*.  Items are inserted with just a key value.
 *
 * AvliPset implicitly connects element with linked list pointers, allowing the
 * element to be walked in order using next and previous pointers.
 *
 * AvliPset assumes all elements in the tree are allocated on the heap and are
 * to be managed by the tree. This means that the class destructor will
 * delete the contents of the tree. A deep copy will cause existing elements
 * to be deleted first.
 */

/*@}*/

#include "compare.h"
#include "avliset.h"

typedef AvliSetEl< void* > AvliPsetEl;

/* Common AvlTree Class */
template < class Key > class AvliPset
		: public AvliSet< void* >
{
public:
	typedef AvliSet< void* > BaseTree;

	/* Insert a element into the tree. */
	AvliPsetEl *insert(const Key &key, AvliPsetEl **lastFound = 0 )
		{ return BaseTree::insert( (void*)key, lastFound ); }

	/* Find a element in the tree. Returns the element if 
	 * key exists, false otherwise. */
	AvliPsetEl *find(const Key &key) const
		{ return BaseTree::find( (void*)key ); }

	/* Remove a element in the tree. */
	AvliPsetEl *detach(const Key &key)
		{ return BaseTree::detach( (void*)key ); }

	static Key key( AvliPsetEl *element )
		{ return (Key) element->key; }
};


#endif /* _AAPL_AVLIPSET_H */

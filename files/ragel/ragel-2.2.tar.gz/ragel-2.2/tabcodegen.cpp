/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "tabcodegen.h"
#include "parsetree.h"
#include "fsmmachine.h"

#define SPEC_ANY_FLAT    0x01
#define SPEC_ANY_SINGLE  0x02
#define SPEC_ANY_RANGE   0x04
#define SPEC_ANY_DEF     0x08
#define SPEC_IS_FINAL    0x10
#define SPEC_OUT_FUNC    0x20

/* Integer array line length. */
#define IALL 8

/* "#define CTL_HOLD         0x01\n"
 * "#define CTL_GOTO         0x02\n"
 * "#define CTL_HGOTO        0x04\n" */

/* "#undef CTL_HOLD\n"
 * "#undef CTL_GOTO\n"
 * "#undef CTL_HGOTO\n" */

/* Operations possibly supported in functions.
 * "			int jmp = "; FSM_NAME() << "ExecFuncs( fsm, funcs, p );\n"
 * "			if ( jmp & CTL_HOLD )\n"
 * "				p--, len++;\n"
 * "			else if ( jmp & CTL_GOTO )\n"
 * "				cs = fsm->curState;\n"
 * "			else if ( jmp & CTL_HGOTO ) {\n"
 * "				p--, len++;\n"
 * "				cs = fsm->curState;\n"
 * "			}\n" */

/* Pass init data to base class. */
TabCodeGen::TabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FsmCodeGen(fsmName, parseData, machine, out)
{ }

int TabCodeGen::makeStateSpec( FsmMachState *state )
{
	int retSpec = 0;
	/* Regular single index. */
	if ( state->numIndex > 0 )
		retSpec |= SPEC_ANY_SINGLE;
	/* Range index. */
	if ( state->numRange > 0 )
		retSpec |= SPEC_ANY_RANGE;
	/* Default index. */
	if ( state->dflIndex != TRANS_ERR_TRANS )
		retSpec |= SPEC_ANY_DEF;
	/* Out function? */
	if ( state->outFuncs != FUNC_NO_FUNC )
		retSpec |= SPEC_OUT_FUNC;
	/* Final state? */
	if ( state->isFinState )
		retSpec |= SPEC_IS_FINAL;
	return retSpec;
}

int TabCodeGen::getStateLen( int stateSpec )
{
	/* Basic len of 3. */
	int stateLen = 3;
	if ( stateSpec & SPEC_ANY_FLAT )
		stateLen += 1;
	if ( stateSpec & SPEC_ANY_SINGLE )
		stateLen += 1;
	if ( stateSpec & SPEC_ANY_RANGE )
		stateLen += 1;
	if ( stateSpec & SPEC_OUT_FUNC )
		stateLen += 1;
	return stateLen;
}

int *TabCodeGen::newStatePosArray()
{
	/* Calculate the positions of each state. */
	int *statePos = new int[machine->numStates];
	for ( int sp = 0, s = 0; s < machine->numStates; s++ ) {
		/* Save the position. */
		statePos[s] = sp;

		/* Move over the state. */
		int spec = makeStateSpec( &machine->allStates[s] );
		sp += getStateLen( spec );
	}
	return statePos;
}

std::ostream &TabCodeGen::STATE_OUT_FUNC(FsmMachState *state)
{
	/* This function is only called if there are any out functions, so need
	 * not guard against there being none. */
	out << machine->transFuncIndex[state->outFuncs];
	return out;
}

std::ostream &TabCodeGen::TRANS_FUNC(FsmMachTrans *trans)
{
	/* If there are any out funcs, emit them. Function indicies are indexes
	 * into transFuncIndex and should be dereferenced to get the index
	 * into the array of all transitions. */
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else
		out << "f+" << machine->transFuncIndex[trans->funcs];
	return out;
}

std::ostream &TabCodeGen::FUNC_SWITCH()
{
	/* Walk the list of functions, printing the cases. */
	for ( int fnum = 0; fnum < parseData->numActionIndex; fnum++ ) {
		/* Get the function data. Print the case label.  */
		ActionListEl *flel = parseData->actionIndex[fnum];
		out << "\tcase " << fnum << ":\n";

		/* Write the preprocessor line info for going into the source file. */
		out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

		/* Write the block and close it off. */
		out << "\t{" << flel->data << "} break;\n";
	}

	/* Write the directive for going back into the output file. The line
	 * number is for the next line, so add one. */
	out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	return out;
}

std::ostream &TabCodeGen::STATES()
{
	int curKeyOffset = 0, curIndOffset = 0;
	int totalStateNum = 0;

	/* Initial indent. */
	out << "\t";

	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Get the spec and write it. The len is encoded in the spec. */
		int stateSpec = makeStateSpec( state );
		int stateLen = getStateLen( stateSpec );
		out << ( ( stateLen << 8 ) |  stateSpec ) << ", ";
		if ( ++totalStateNum % IALL == 0 )
			out << "\n\t";

		/* Write the key offset. */
		out << curKeyOffset << ", ";
		if ( ++totalStateNum % IALL == 0 )
			out << "\n\t";

		/* Write the index offset. */
		out << curIndOffset << ", ";
		if ( ++totalStateNum % IALL == 0 )
			out << "\n\t";

		/* Emit length of single index. */
		if ( stateSpec & SPEC_ANY_SINGLE ) {
			out << state->numIndex << ", ";
			if ( ++totalStateNum % IALL == 0 )
				out << "\n\t";
		}

		/* Emit length of range index. */
		if ( stateSpec & SPEC_ANY_RANGE ) {
			out << state->numRange << ", ";
			if ( ++totalStateNum % IALL == 0 )
				out << "\n\t";
		}

		/* If there is an out func, write it. */
		if ( stateSpec & SPEC_OUT_FUNC ) {
			STATE_OUT_FUNC( state ) << ", ";
			if ( ++totalStateNum % IALL == 0 )
				out << "\n\t";
		}

		/* Move the key and index offsets ahead. */
		curKeyOffset += state->numIndex + state->numRange*2;
		curIndOffset += state->numIndex + state->numRange;
		if ( stateSpec & SPEC_ANY_DEF )
			curIndOffset += 1;
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::KEYS()
{
	out << '\t';
	int totalTrans = 0;
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Walk the single list. */
		for ( int j = 0; j < state->numIndex; j++ ) {
			KEY( state->transIndKey[j] ) << ", ";

			/* Put in a line break every 8 */
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}

		/* Walk the range list. Note the 2 times for the keys */
		for ( int j = 0; j < state->numRange*2; j++ ) {
			KEY( state->rangeIndKey[j] ) << ", ";

			/* Put in a line break every 8 */
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::INDICIES()
{
	/* Keep a count of the num of items in the array written. */
	int totalTrans = 0;

	/* Write out initial indentation. */
	out << '\t';
	for ( int i = 0; i < machine->numStates; i++ ) {
		/* Get a pointer to the state. */
		FsmMachState *state = machine->allStates+i;

		/* Get the state spec. */
		int stateSpec = makeStateSpec( state );

		/* Walk the single index list . */
		for ( int j = 0; j < state->numIndex; j++ ) {
			out << state->transIndPtr[j] << ", ";
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}

		/* Walk the range list. */
		for ( int j = 0; j < state->numRange; j++ ) {
			out << state->rangeIndPtr[j] << ", ";
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}

		/* The state's default index goes next. */
		if ( stateSpec & SPEC_ANY_DEF ) {
			out << state->dflIndex << ", ";
			if ( ++totalTrans % IALL == 0 )
				out << "\n\t";
		}
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::INDEX_TYPE()
{
	if ( machine->numTrans <= 256 )
		out << "unsigned char";
	else if ( machine->numTrans <= 256*256 )
		out << "unsigned short";
	else 
		out << "unsigned int";
	return out;
}


std::ostream &TabCodeGen::TRANSITIONS( int *statePos )
{
	/* Keep a count of the num of items in the array written. */
	int totalTransData = 0;

	out << '\t';
	for ( int i = 0; i < machine->numTrans; i++ ) {
		/* Get the transition. */
		FsmMachTrans *trans = &machine->allTrans[i];

		/* Write out the target state. */
		out << "s+" << statePos[trans->toState] << ", ";
		if ( ++totalTransData % IALL == 0 )
			out << "\n\t";

		/* Write the function for the transition. */
		if ( trans->funcs == FUNC_NO_FUNC )
			out << "0, ";
		else
			out << "f+" << machine->transFuncIndex[trans->funcs] << ", ";
		if ( ++totalTransData % IALL == 0 )
			out << "\n\t";
	}

	/* Output one last number so we don't have to figure out when the last
	 * entry is and avoid writing a comma. */
	out << 0;
	return out;
}

std::ostream &TabCodeGen::BSEARCH()
{
	out <<
		"/* Binary search an array of keys looking for a key. */\n"
		"static "; ALPH_TYPE() << " *"; FSM_NAME() << "_bsearch( "; ALPH_TYPE() << 
				" c, "; ALPH_TYPE() << " *keys, int len )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *lower = keys;\n"
		"	"; ALPH_TYPE() << " *mid;\n"
		"	"; ALPH_TYPE() << " *upper = keys + len - 1;\n"
		"	while (1) {\n"
		"		if ( upper < lower )\n"
		"			return 0;\n"
		"\n"
		"		/* Find the midpoint. */\n"
		"		mid = lower + ((upper-lower) >> 1);\n"
		"\n"
		"		if ( c < *mid )\n"
		"			upper = mid - 1;\n"
		"		else if ( c > *mid )\n"
		"			lower = mid + 1;\n"
		"		else\n"
		"			return mid;\n"
		"	}\n"
		"}\n";

	return out;
}

std::ostream &TabCodeGen::RANGE_BSEARCH()
{
	out <<
		"/* Binary search an array of keys looking for a key. */\n"
		"static "; ALPH_TYPE() << " *"; FSM_NAME() << "_range_bsearch( "; ALPH_TYPE() << 
				" c, "; ALPH_TYPE() << " *keys, int len )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *lower = keys;\n"
		"	"; ALPH_TYPE() << " *mid;\n"
		"	"; ALPH_TYPE() << " *upper = keys + len - 2;\n"
		"	while (1) {\n"
		"		if ( upper < lower )\n"
		"			return 0;\n"
		"\n"
		"		/* Find the midpoint. Be sure to settle on the\n"
		"		 * lower end of a range. */\n"
		"		mid = lower + (((upper-lower) >> 1) & ~1);\n"
		"\n"
		"		if ( c < mid[0] )\n"
		"			upper = mid - 2;\n"
		"		else if ( c > mid[1] )\n"
		"			lower = mid + 2;\n"
		"		else {\n"
		"			/* The key was found in the range mid, return it. */\n"
		"			return mid;\n"
		"		}\n"
		"	}\n"
		"}\n";

	return out;
}

std::ostream &TabCodeGen::LOCATE_TRANS()
{
	out <<
		"	/* Get required data. */\n"
		"	specs = *cs++;\n"
		"	keys = k + *cs++;\n"
		"	inds = i + *cs++;\n"
		"\n"
		"	/* Try flat index. */\n"
		"	if ( specs & SPEC_ANY_FLAT ) {\n"
		"		int indsLen = *cs++;\n"
		"		keys += 2;\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try binary search single. */\n"
		"	if ( specs & SPEC_ANY_SINGLE ) {\n"
		"		/* Try to find the key. */\n"
		"		int indsLen = *cs++;\n"
		"		"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
						"_bsearch( *p, keys, indsLen );\n"
		"\n"
		"		if ( match != 0 ) {\n"
		"			trans = t + (inds[match - keys]<<1);\n"
		"			goto match;\n"
		"		}\n"
		"\n"
		"		/* Advance over the keys and indicies. */\n"
		"		keys += indsLen;\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try binary search range. */\n"
		"	if ( specs & SPEC_ANY_RANGE ) {\n"
		"		/* Try to find the key. */\n"
		"		int indsLen = *cs++;\n"
		"		"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
						"_range_bsearch( *p, keys, (indsLen<<1) );\n"
		"\n"
		"		if ( match != 0 ) {\n"
		"			trans = t + (inds[(match - keys)>>1]<<1);\n"
		"			goto match;\n"
		"		}\n"
		"\n"
		"		/* Advance over the keys and indicies. */\n"
		"		keys += (indsLen<<1);\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try the default transition. */\n"
		"	if ( specs & SPEC_ANY_DEF ) {\n"
		"		trans = t + ((*inds)<<1);\n"
		"		goto match;\n"
		"	}\n";

	return out;
}


/* Pass init data to base. */
CTabCodeGen::CTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	TabCodeGen(fsmName, parseData, machine, out)
{ }


/* Generate the header portion. */
void CTabCodeGen::writeOutHeader()
{
	out << 
		"/* Current state and user data. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int *curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Init the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, ";
				ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define f "; FSM_NAME() << "_f\n"
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* If there are any transtion functions then output the array. If there
	 * are none, don't bother emitting an empty array that won't be used. */
	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of transitions. */\n"
		"static int *"; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( *fsm->curState & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"	int *cs = fsm->curState;\n"
		"	int specs, **trans";
		
	if ( anyTransFuncs() )
		out << ", *funcs, nfuncs";

	out <<
		";\n"
		"	"; ALPH_TYPE() << " *keys;\n"
		"	"; INDEX_TYPE() << " *inds;\n"
		"\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out <<
		"again:\n"
		"	if ( cs == s )\n"
		"		goto out_err;\n"
		"\n"
		"	if ( len == 0 )\n"
		"		goto out_ok;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"	/* No match. */\n"
		"	goto out_err;\n"
		"\n"
		"match:\n"
		"	/* Move to the new state. */\n"
		"	cs = *trans++;\n"
		"\n";

	if ( anyTransFuncs() ) {
		out << 
			"	/* Check for functions. */\n"
			"	if ( (funcs=*trans) == 0 )\n"
			"		goto noFuncs;\n"
			"\n";

		/* Only used if there are out funcs. */
		if ( anyOutTransFuncs() )
			out << "execFuncs:\n";

		out <<
			"	nfuncs = *funcs++;\n"
			"	while ( nfuncs-- > 0 ) {\n"
			"		switch ( *funcs++ ) {\n";
			FUNC_SWITCH() <<
			"		}\n"
			"	}\n"
			"\n"
			"noFuncs:\n";
	}

	out <<
		"	p++, len--;\n"
		"	goto again;\n"
		"\n";

	if ( anyOutTransFuncs() ) {
		out <<
			"finishInput:\n"
			"	/* Execute any out funcs for the final state. */\n"
			"	if ( *cs & SPEC_OUT_FUNC ) {\n"
			"		funcs = f+*(cs + (*cs>>8)-1);\n"
			"		len = 1;\n"
			"		goto execFuncs;\n"
			"	}\n"
			"	else if ( cs == s )\n"
			"		goto out_err;\n"
			"\n";
	}

	out <<
		"out_ok:\n"
		"	fsm->curState = cs;\n"
		"	if ( *cs & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	fsm->curState = s;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyOutTransFuncs() ) {
		/* May need to execute code in the action loop. Must use special
		 * params to execute func. */
		out << "	return "; FSM_NAME() << "_execute( fsm, 0, -1 );\n";
	}
	else {
		out << 
			"	if ( fsm->curState == s )\n"
			"		return -1;\n"
			"	else if ( *fsm->curState & SPEC_IS_FINAL )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out << 
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef f\n"
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}

/* Init base class. */
CCTabCodeGen::CCTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out ) 
: 
	TabCodeGen(fsmName, parseData, machine, out) 
{ }

void CCTabCodeGen::writeOutHeader()
{
	out <<
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Initialize the machine for execution. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int *curState;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define f "; FSM_NAME() << "_f\n"
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* If there are any transtion functions then output the array. If there
	 * are none, don't bother emitting an empty array that won't be used. */
	if ( anyTransFuncs() ) {
		out <<
			"/* The array of functions. */\n"
			"static int "; FSM_NAME() << "_f[] = {\n";
			FUNCTIONS() << "\n"
			"};\n"
			"\n";
	}

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of transitions. */\n"
		"static int *"; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->curState = "; FSM_NAME() << "_start;\n";
		INIT_CODE() <<
		"	if ( *this->curState & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"	int *cs = this->curState;\n"
		"	int specs, **trans";

	if ( anyTransFuncs() )
		out << ", *funcs, nfuncs";

	out <<
		";\n"
		"	"; ALPH_TYPE() << " *keys;\n"
		"	"; INDEX_TYPE() << " *inds;\n"
		"\n";
	
	if ( anyOutTransFuncs() ) {
		out << 
			"	if ( dlen < 0 )\n"
			"		goto finishInput;\n"
			"\n";
	}

	out << 
		"again:\n"
		"	if ( cs == s )\n"
		"		goto out_err;\n"
		"\n"
		"	if ( len == 0 )\n"
		"		goto out_ok;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"	/* No match. */\n"
		"	goto out_err;\n"
		"\n"
		"match:\n"
		"	/* Move to the new state. */\n"
		"	cs = *trans++;\n"
		"\n";

	if ( anyTransFuncs() ) {
		out <<
			"	/* Check for functions. */\n"
			"	if ( (funcs=*trans) == 0 )\n"
			"		goto noFuncs;\n"
			"\n";

		if ( anyOutTransFuncs() )
			out << "execFuncs:\n";

		out <<
			"	nfuncs = *funcs++;\n"
			"	while ( nfuncs-- > 0 ) {\n"
			"		switch ( *funcs++ ) {\n";
			FUNC_SWITCH() <<
			"		}\n"
			"	}\n"
			"\n"
			"noFuncs:\n";
	}

	out <<
		"	p++, len--;\n"
		"	goto again;\n"
		"\n";
	
	if ( anyOutTransFuncs() ) {
		out << 
			"finishInput:\n"
			"	/* Execute any out funcs for the final state. */\n"
			"	if ( *cs & SPEC_OUT_FUNC ) {\n"
			"		funcs = f+*(cs + (*cs>>8)-1);\n"
			"		len = 1;\n"
			"		goto execFuncs;\n"
			"	}\n"
			"	else if ( cs == s )\n"
			"		goto out_err;\n"
			"\n";
	}

	out <<
		"out_ok:\n"
		"	this->curState = cs;\n"
		"	if ( *cs & SPEC_IS_FINAL )\n"
		"		return 1;\n"
		"	return 0;\n"
		"out_err:\n"
		"	this->curState = s;\n"
		"	return -1;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";

	if ( anyOutTransFuncs() ) {
		/* May need to execute code in the action loop. Must use special
		 * params to execute func. */
		out << "	return execute( 0, -1 );\n";
	}
	else {
		out << 
			"	if ( this->curState == s )\n"
			"		return -1;\n"
			"	else if ( *this->curState & SPEC_IS_FINAL )\n"
			"		return 1;\n"
			"	return 0;\n";
	}

	out << 
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef f\n"
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}

/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TAG_unknown = 258,
     TAG_ragel = 259,
     TAG_ragel_def = 260,
     TAG_host = 261,
     TAG_state_list = 262,
     TAG_state = 263,
     TAG_trans_list = 264,
     TAG_t = 265,
     TAG_machine = 266,
     TAG_start_state = 267,
     TAG_action_list = 268,
     TAG_action_table_list = 269,
     TAG_action = 270,
     TAG_action_table = 271,
     TAG_alphtype = 272,
     TAG_element = 273,
     TAG_getkey = 274,
     TAG_state_actions = 275,
     TAG_entry_points = 276,
     TAG_sub_action = 277,
     TAG_cond_space_list = 278,
     TAG_cond_space = 279,
     TAG_cond_list = 280,
     TAG_c = 281,
     TAG_text = 282,
     TAG_goto = 283,
     TAG_call = 284,
     TAG_next = 285,
     TAG_goto_expr = 286,
     TAG_call_expr = 287,
     TAG_next_expr = 288,
     TAG_ret = 289,
     TAG_pchar = 290,
     TAG_char = 291,
     TAG_hold = 292,
     TAG_exec = 293,
     TAG_holdte = 294,
     TAG_execte = 295,
     TAG_curs = 296,
     TAG_targs = 297,
     TAG_entry = 298,
     TAG_data = 299,
     TAG_lm_switch = 300,
     TAG_init_act = 301,
     TAG_set_act = 302,
     TAG_set_tokend = 303,
     TAG_get_tokend = 304,
     TAG_init_tokstart = 305,
     TAG_set_tokstart = 306,
     TAG_write = 307,
     TAG_curstate = 308,
     TAG_access = 309,
     TAG_break = 310,
     TAG_option = 311,
     XML_Word = 312,
     XML_Literal = 313
   };
#endif
/* Tokens.  */
#define TAG_unknown 258
#define TAG_ragel 259
#define TAG_ragel_def 260
#define TAG_host 261
#define TAG_state_list 262
#define TAG_state 263
#define TAG_trans_list 264
#define TAG_t 265
#define TAG_machine 266
#define TAG_start_state 267
#define TAG_action_list 268
#define TAG_action_table_list 269
#define TAG_action 270
#define TAG_action_table 271
#define TAG_alphtype 272
#define TAG_element 273
#define TAG_getkey 274
#define TAG_state_actions 275
#define TAG_entry_points 276
#define TAG_sub_action 277
#define TAG_cond_space_list 278
#define TAG_cond_space 279
#define TAG_cond_list 280
#define TAG_c 281
#define TAG_text 282
#define TAG_goto 283
#define TAG_call 284
#define TAG_next 285
#define TAG_goto_expr 286
#define TAG_call_expr 287
#define TAG_next_expr 288
#define TAG_ret 289
#define TAG_pchar 290
#define TAG_char 291
#define TAG_hold 292
#define TAG_exec 293
#define TAG_holdte 294
#define TAG_execte 295
#define TAG_curs 296
#define TAG_targs 297
#define TAG_entry 298
#define TAG_data 299
#define TAG_lm_switch 300
#define TAG_init_act 301
#define TAG_set_act 302
#define TAG_set_tokend 303
#define TAG_get_tokend 304
#define TAG_init_tokstart 305
#define TAG_set_tokstart 306
#define TAG_write 307
#define TAG_curstate 308
#define TAG_access 309
#define TAG_break 310
#define TAG_option 311
#define XML_Word 312
#define XML_Literal 313




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 56 "xmlparse.y"
typedef union YYSTYPE {
	/* General data types. */
	char c;
	char *data;
	int integer;
	AttrList *attrList;

	/* Inline parse tree items. */
	InlineItem *ilitem;
	InlineList *illist;
} YYSTYPE;
/* Line 1447 of yacc.c.  */
#line 166 "xmlpdefs.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif





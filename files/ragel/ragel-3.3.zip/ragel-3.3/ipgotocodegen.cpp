/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "ipgotocodegen.h"
#include "redfsm.h"
#include "parsetree.h"
#include "bstmap.h"

/* Inits the code and data pointers. There are no code generation 
 * functions to register. */
IpGotoCodeGen::IpGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	GotoCodeGen(fsmName, parseData, redFsm, out)
{ }

/* Called from GotoCodeGen::STATE_GOTOS just before writing the gotos for each
 * state. */
void IpGotoCodeGen::aboveStateGotos( RedStateAp *state )
{
	bool anyWritten = false;

	/* Emit any transitions that have actions and that go to 
	 * this state. */
	for ( TransApSet::Iter trans = redFsm->transSet; trans.lte(); trans ++ ) {
		if ( trans->targ == state && trans->action != 0 ) {
			/* Remember that we wrote a trans so we know to write the
			 * line directive for going back to the output. */
			anyWritten = true;

			/* Write the label for the transition so it can be jumped to. */
			out << "tr" << trans->id << ":\n";
			for ( ActionTable::Iter item = trans->action->key; item.lte(); item++ ) {
				/* Get the function data. */
				Action *action = parseData->actionIndex[item->value];

				/* Write the preprocessor line info for going into the 
				 * source file. */
				out << "#line " << action->loc.line << " \""; LDIR_PATH(inputFile) << "\"\n";

				/* Wrap the block in brakets. */
				out << "\t{"; ACTION(action, trans->targ->id, false) << "}\n";
			}

			/* Goto the target state. */
			out << "\tgoto st" << trans->targ->id << ";\n";
		}
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "#line " << outFilter->line + 1 << " \""; LDIR_PATH(outputFile) << "\"\n";
	}
}

/* Emit the goto to take for a given transition. */
std::ostream &IpGotoCodeGen::TRANS_GOTO( RedTransAp *trans, int level )
{
	if ( trans->action != 0 ) {
		/* Go to the transition which will go to the state. */
		TABS(level) << "goto tr" << trans->id << ";";
	}
	else {
		/* Go directly to the target state. */
		TABS(level) << "goto st" << trans->targ->id << ";";
	}
	return out;
}


std::ostream &IpGotoCodeGen::FINISH_CASES()
{
	bool anyWritten = false;

	for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ ) {
		/* Cased needed if there are out actions. */
		if ( st->outAction != 0 ) {
			out << "\tcase " << st->id << ": ";

			/* If there are out functions, write them. */
			/* Remember that we wrote a trans so we know to write the
			 * line directive for going back to the output. */
			anyWritten = true;

			out << "\n";
			for ( ActionTable::Iter item = st->outAction->key; item.lte(); item++ ) {
				/* Get the action item. */
				Action *action = parseData->actionIndex[item->value];
				
				/* Write the preprocessor line info for going into the 
				 * source file. */
				out << "#line " << action->loc.line << " \""; LDIR_PATH(inputFile) << "\"\n";

				/* Wrap the block in brakets. */
				out << "\t{"; ACTION(action, STATE_ERR_STATE, true) << "}\n";
			}
			out << "\tbreak;\n";
		}
	}

	if ( anyWritten ) {
		/* Write the directive for going back into the output file. The line
		 * number is for the next line, so add one. */
		out << "#line " << outFilter->line + 1 << " \""; LDIR_PATH(outputFile) << "\"\n";
	}
	return out;
}

/* Set up labelNeeded flag for each state. */
void IpGotoCodeGen::setLabelsNeeded()
{
	/* Default all labels needed to false. */
	for ( RedStateList::Iter st = redFsm->stateList; st.lte(); st++ )
		st->labelNeeded = false;

	/* Walk all transitions and set only those that have targs. */
	for ( TransApSet::Iter trans = redFsm->transSet; trans.lte(); trans++ ) {
		trans->targ->labelNeeded = true;

		/* Need labels for states that have goto or calls in action code
		 * invoked on characters (ie, not from out action code). */
		if ( trans->action != 0 ) {
			/* Loop the actions. */
			for ( ActionTable::Iter act = trans->action->key; act.lte(); act++ ) {
				/* Get the action. */
				Action *action = parseData->actionIndex[act->value];

				/* Loop it's block items. */
				for ( BlockIter item = action->data; item.lte(); item++ ) {
					if ( item.type == CB_JUMP || item.type == CB_CALL ) {
						/* Get the target. */
						NameInst *name = action->nameTargs[item.i];
						RedEntryMapEl *targ = redFsm->entryMap.find( name->id );

						/* Need a label for this target. */
						targ->value->labelNeeded = true;
					}
				}
			}
		}
	}
}


/* Init base data. */
CIpGotoCodeGen::CIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	IpGotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &CIpGotoCodeGen::GOTO( NameInst *name, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	if ( !inFinish )
		out << "{goto st" << targ->value->id << ";}";
	else
		out << "{fsm->_cs = " << targ->value->id << "; goto out;}";
	return out;
}

std::ostream &CIpGotoCodeGen::CALL( NameInst *name, int targState, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	if ( !inFinish ) {
		out << "{fsm->_st[fsm->_top++] = " << 
				targState << "; goto st" << targ->value->id << ";}";
	}
	else {
		out << "{fsm->_st[fsm->_top++] = " << 
				targState << "; fsm->_cs = " << targ->value->id << 
				"; goto out;}";
	}
	return out;
}

std::ostream &CIpGotoCodeGen::RET( bool inFinish )
{
	if ( !inFinish )
		out << "{_cs = fsm->_st[--fsm->_top]; goto again;}";
	else
		out << "{fsm->_cs = fsm->_st[--fsm->_top]; goto out;}";
	return out;
}
void CIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "\n"
		"{\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n"
		"/* Init the fsm. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n"
		"/* Initialize the machine. */\n"
		"int "; FSM_NAME() << "_init( struct "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() || anyActionRets() )
		out << "	fsm->_top = 0;\n";

	INIT_CODE() <<
		"	if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "_execute( struct "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	"; ALPH_TYPE() << " *_pe = data+dlen;\n"
		"	int _cs = fsm->_cs;\n"
		"\n";
	
	/* Only needed by return statements. */
	if ( anyActionRets() )
		out << "again:\n";

	out <<
		"	if ( ++_p == _pe )\n"
		"		goto out;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS() << 
		"	}\n";
		EXIT_STATES() << 
		"\n";
	
	out <<
		"out:\n"
		"	fsm->_cs = _cs;\n"
		"	if ( _cs == "; ERROR_STATE() << " )\n"
		"		return -1;\n"
		"	else if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";

	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "_finish( struct "; FSM_NAME() << " *fsm )\n"
		"{\n";

	if ( anyOutActionCharRef() ) {
		out << "	"; 
		ALPH_TYPE() << " *_p = 0;\n";
	}

	out <<
		"	switch ( fsm->_cs ) {\n";
		FINISH_CASES() <<
		"	}\n"
		"\n";
	
	if ( anyOutActionControl() )
		out << "	out:\n";

	out <<
		"	if ( fsm->_cs == "; ERROR_STATE() << " )\n"
		"		return -1;\n"
		"	else if ( fsm->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";
}

/* Init base data. */
CCIpGotoCodeGen::CCIpGotoCodeGen( char *fsmName, ParseData *parseData, 
		RedFsmAp *redFsm, std::ostream &out )
:
	IpGotoCodeGen(fsmName, parseData, redFsm, out)
{ }

std::ostream &CCIpGotoCodeGen::GOTO( NameInst *name, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	if ( !inFinish )
		out << "{goto st" << targ->value->id << ";}";
	else
		out << "{this->_cs = " << targ->value->id << "; goto out;}";
	return out;
}

std::ostream &CCIpGotoCodeGen::CALL( NameInst *name, int targState, bool inFinish )
{
	/* Lookup the target. Always guaranteed to return just one target. */
	RedEntryMapEl *targ = redFsm->entryMap.find( name->id );
	if ( !inFinish ) {
		out << "{this->_st[this->_top++] = " << 
				targState << "; goto st" << targ->value->id << ";}";
	}
	else {
		out << "{this->_st[this->_top++] = " << 
				targState << "; this->_cs = " << targ->value->id << 
				"; goto out;}";
	}
	return out;
}

std::ostream &CCIpGotoCodeGen::RET( bool inFinish )
{
	if ( !inFinish )
		out << "{_cs = this->_st[--this->_top]; goto again;}";
	else
		out << "{this->_cs = this->_st[--this->_top]; goto out;}";
	return out;
}

void CCIpGotoCodeGen::writeOutHeader()
{
	out <<
		"/* Only non-static data: current state. */\n"
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* Init the fsm. */\n"
		"	int init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	int execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	int finish( );\n"
		"\n"
		"	int _cs;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCIpGotoCodeGen::writeOutCode()
{
	out <<
		"/* The start state. */\n"
		"static int "; FSM_NAME() << "_start = "; START_STATE_ID() << ";\n"
		"\n"
		"/* Initialize the machine. */\n"
		"int "; FSM_NAME() << "::init( )\n"
		"{\n"
		"	this->_cs = "; FSM_NAME() << "_start;\n";

	/* If there are any calls, then the stack top needs initialization. */
	if ( anyActionCalls() || anyActionRets() )
		out << "	this->_top = 0;\n";

	INIT_CODE() <<
		"	if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n"
		"/* Execute the fsm on some chunk of data. */\n"
		"int "; FSM_NAME() << "::execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *_p = data-1;\n"
		"	"; ALPH_TYPE() << " *_pe = data+dlen;\n"
		"	int _cs = this->_cs;\n"
		"\n";

	/* Only needed by return statements. */
	if ( anyActionRets() )
		out << "again:\n";

	out <<
		"	if ( ++_p == _pe )\n"
		"		goto out;\n"
		"	switch ( _cs ) {\n";
		STATE_GOTOS() <<
		"	}\n";
		EXIT_STATES() << 
		"\n";

	out <<
		"out:\n"
		"	this->_cs = _cs;\n"
		"	if ( _cs == "; ERROR_STATE() << " )\n"
		"		return -1;\n"
		"	else if ( _cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";
	
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"int "; FSM_NAME() << "::finish( )\n"
		"{\n";

	if ( anyOutActionCharRef() ) {
		out << "	"; 
		ALPH_TYPE() << " *_p = 0;\n";
	}

	out <<
		"	switch( this->_cs ) {\n";
		FINISH_CASES() <<
		"	}\n"
		"\n";
	
	if ( anyOutActionControl() )
		out << "	out:\n";

	out <<
		"	if ( this->_cs == "; ERROR_STATE() << " )\n"
		"		return -1;\n"
		"	else if ( this->_cs >= "; FIRST_FINAL_STATE() << " )\n"
		"		return 1;\n"
		"	return 0;\n"
		"}\n"
		"\n";
}

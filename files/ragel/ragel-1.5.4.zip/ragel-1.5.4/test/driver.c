/*
 * A generic driver for C fsms.
 */
#include <stdio.h>
#define BUFSIZE 2048

Fsm fsm;
char buf[BUFSIZE];

int main()
{
	FsmInit( &fsm );
	while ( 1 ) {
		int len = fread( buf, 1, BUFSIZE, stdin );
		FsmExecute( &fsm, buf, len );
		if ( len != BUFSIZE )
			break;
	}
	FsmFinish( &fsm );
	if ( FsmAccept( &fsm ) )
		printf("ACCEPT\n");
	else
		printf("FAIL\n");
	return 0;
}


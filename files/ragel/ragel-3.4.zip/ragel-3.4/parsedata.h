/*
 *  Copyright 2001-2004 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _PARSEDATA_H
#define _PARSEDATA_H

#include "ptreetypes.h"
#include "astring.h"
#include "avlmap.h"
#include "bstmap.h"
#include "astring.h"
#include "vectsimp.h"
#include "dlist.h"
#include "fsmgraph.h"
#include "compare.h"

/* Forwards. */
struct RedFsmAp;
struct FsmCodeGen;
struct NameInst;

#define CB_TEXT	  'T'
#define CB_JUMP	  'J'
#define CB_CALL	  'C'
#define CB_RET    'R'
#define CB_PCHAR  'p'
#define CB_CHAR   'c'
#define CB_HOLD   'H'
#define CB_END    'E'
#define CB_STACK  'S'

/* Types of builtin machines. */
enum BuiltinMachine
{
	BT_Any,
	BT_Ascii,
	BT_Extend,
	BT_Alpha,
	BT_Digit,
	BT_Alnum,
	BT_Lower,
	BT_Upper,
	BT_Cntrl,
	BT_Graph,
	BT_Print,
	BT_Punct,
	BT_Space,
	BT_Xdigit,
	BT_Null,
	BT_Empty
};

/* Location in an input file. */
struct InputLoc
{
	InputLoc( ) 
		: line(0), col(0) { }
	InputLoc( const BISON_YYLTYPE &loc );

	int line;
	int col;
};

/* Element in a generic list of strings. */
struct StringListEl : public DListEl<StringListEl>
{
public:
	StringListEl( const InputLoc &loc, char *data ) 
			: loc(loc), data(data) { }
	~StringListEl() { delete[] data; }

	InputLoc loc;
	char *data;
};

/* List of string elements. Used for actions and data to go into the fsm
 * struct. */
typedef DList<StringListEl> StringList;

/* Nodes in the tree that use this action. */
typedef Vector<FactorWithAug*> ActionRefs;

/* Element in list of actions. Contains the string for the code to exectute. */
struct Action 
:
	public DListEl<Action>,
	public AvlTreeEl<Action>
{
public:
	Action( const InputLoc &loc, char *name, char *data );
	~Action();

	/* Key for action dictionary. */
	char *getKey() const { return name; }

	/* Data collected during parse. */
	InputLoc loc;
	char *name;
	char *data;
	int id;

	/* Places that reference the actions. */
	ActionRefs actionRefs;

	/* Resolved targets for jump, call. */
	NameInst **nameTargs;

	/* For splitting actions by regular and out actions. */
	bool isRegAction;
	bool isOutAction;
	int regActionId;
	int outActionId;
};

/* Iterate through interpreted blocks of data. */
struct BlockIter
{
	/* Initialization. */
	BlockIter( char *bd );
	void operator=( char *bd );
	
	/* Iterator controls. */
	bool lte() const { return type != CB_END; }
	void operator++(int) { loadNext(); i++; }
	void loadNext();

	/* The type, data and num of the item. */
	char type;
	char *data;
	int i;

	char *ptr;
};

/* A list of actions. */
typedef DList<Action> ActionList;
typedef AvlTree<Action, char *, CmpStr> ActionDict;

/* Structure for reverse action mapping. */
struct RevActionMapEl
{
	char *name;
	InputLoc location;
};

/* Store the value and type of a priority augmentation. */
struct PriorityAug
{
	PriorityAug( AugType type, int priorKey, int priorValue ) :
		type(type), priorKey(priorKey), priorValue(priorValue) { }

	AugType type;
	int priorKey;
	int priorValue;
};

/* Structrue represents an action assigned to some FactorWithAug node. The
 * factor with aug will keep an array of these. */
struct ParserAction
{
	ParserAction( AugType type, int localErrKey, Action *action )
		: type(type), localErrKey(localErrKey), action(action) { }

	AugType type;
	int localErrKey;
	Action *action;
};

struct VarDef;
struct Join;
struct Expression;
struct Term;
struct FactorWithAug;
struct FactorWithLabel;
struct FactorWithRep;
struct FactorWithNeg;
struct Factor;
struct Literal;
struct Range;
struct RegExpr;
struct ReItem;
struct ReOrBlock;
struct ReOrItem;

/* Graph dictionary. */
struct GraphDictEl 
:
	public AvlTreeEl<GraphDictEl>,
	public DListEl<GraphDictEl>
{
	GraphDictEl( char *k ) 
		: key(k), value(0), isInstance(false), line(0), col(0) { }
	GraphDictEl( char *k, VarDef *value ) 
		: key(k), value(value), isInstance(false), line(0), col(0) { }

	const char *getKey() { return key; }

	char *key;
	VarDef *value;
	bool isInstance;

	/* Location info of graph definition. Points to variable name of assignment. */
	int line;
	int col;
};

typedef AvlTree<GraphDictEl, char*, CmpStr> GraphDict;
typedef DList<GraphDictEl> GraphList;

/* Priority name dictionary. */
typedef AvlMapEl<char*, int> PriorDictEl;
typedef AvlMap<char*, int, CmpStr> PriorDict;

/* Local error name dictionary. */
typedef AvlMapEl<char*, int> LocalErrDictEl;
typedef AvlMap<char*, int, CmpStr> LocalErrDict;

/* Types of alphabet supported by Ragel. */
enum AlphType
{
	AT_Char,
	AT_UnsignedChar,
	AT_Short,
	AT_UnsignedShort,
	AT_Int,
	AT_UnsignedInt
};


/* Tree of instantiated names. */
typedef BstMapEl<char*, NameInst*> NameMapEl;
typedef BstMap<char*, NameInst*, CmpStr> NameMap;
typedef Vector<NameInst*> NameVect;

/* Node in the tree of instantiated names. */
struct NameInst
{
	NameInst( char *name, int id ) 
		: name(name), id(id), numRefs(0), numUses(0) {}

	char *name;
	int id;
	int numRefs;
	int numUses;

	/* Names underneath us. */
	NameMap children;

	/* Anonymous names underneat us. Used by join operations
	 * to create a local scope. */
	NameVect anonChildren;

	/* During a fsm generation walk, lists the names that are referenced by
	 * epsilon operations in the current scope. After the link is made by the
	 * epsilon reference and the join operation is complete, the label can
	 * have its refcount decremented if there are no more references then the
	 * entry point can be removed from the fsm returned. */
	NameVect referencedNames;
};


/* Class to collect information about the machine during the 
 * parse of input. */
struct ParseData
{
	/* Create a new parse data object. This is done at the beginning of every
	 * fsm specification. */
	ParseData( const String &fileName );
	~ParseData();

	/*
	 * Setting up the graph dict.
	 */

	/* Initialize a graph dict with the basic fsms. */
	void initGraphDict();
	void createBuiltin( char *name, BuiltinMachine builtin );

	/* Make a name id in the current name instantiation scope if it is not
	 * already there. */
	NameInst *addNameInst( char *label );
	NameInst *findNameInst( char *label );
	void makeNameTree( GraphDictEl *dictEl );
	void fillNameIndex( NameInst *from );
	void printNameTree();

	/* Increments the usage count on entry names. Names that are no longer
	 * needed will have their entry points unset. */
	void unsetObsoleteEntries( FsmAp *graph );

	/* Resove name references in action code. */
	void resolveJump( Action *action, char *data, int i );
	void resolveActionNameRefs();

	/* Make an index of pointers to the action blocks. */
	void fillActionIndex();

	/* Set the alphabet type. If type types are not valid returns false. */
	bool setAlphType( String s1, String s2 );
	bool setAlphType( String s1 );

	/* Dumping the name instantiation tree. */
	void printNameInst( NameInst *nameInst, int level );

	/* Make the graph from a graph dict node. Does minimization. */
	FsmAp *makeInstance( GraphDictEl *gdNode );
	FsmAp *makeGraph( GraphDictEl *gdNode );

	/* Dumping and printing. */
	void dumpFsm( GraphDictEl *dictEl );
	void dumpFsm();
	void printFsm();

	/* Generate graphviz code. */
	void generateGraphviz( GraphDictEl *dictEl );
	void generateGraphviz();

	/* Generate and write out the fsm. */
	void generateCode( );
	void doGenerateCode( GraphDictEl *gdNode );
	FsmCodeGen *makeCodeGen( RedFsmAp *machine2 );

	/* Set the lower and upper range from the lower and upper number keys. */
	void setLowerUpperRange( );
	void initKeyOps();

	/*
	 * Querying the parse data
	 */

	/* Is the alphabet a signed type? */
	bool isAlphSigned();
	
	/*
	 * Data collected during the parse.
	 */

	/* Dictionary of graphs. Both instances and non-instances go here. */
	GraphDict graphDict;

	/* The list of instances. */
	GraphList instanceList;

	/* Dictionary of actions. Lets actions be defined and then referenced. */
	ActionDict actionDict;

	/* Dictionary of named priorities. */
	PriorDict priorDict;

	/* Dictionary of named local errors. */
	LocalErrDict localErrDict;

	/* List of actions. Will be pasted into a switch statement. */
	ActionList actionList;
	Action **actionIndex;

	/* List of sections of data to add to the fsm struct. */
	StringList dataList;

	/* The id of the next priority name and label. */
	int nextPriorKey, nextLocalErrKey, nextNameId;
	
	/* The default priority number key for a machine. This is active during
	 * the parse of the rhs of a machine assignment. */
	int curDefPriorKey;

	int curDefLocalErrKey;

	/* If a machine is given this is set. */
	bool machineGiven;

	/* Code sections put in the fsms init routine. */
	StringList initCodeList;

	/* Alphabet type. */
	AlphType alphType;

	/* The alphabet range. */
	String lowerNum, upperNum;
	long lowKey, highKey;
	InputLoc rangeLowLoc, rangeHighLoc;

	/* Key operators. */
	KeyOps keyOps;

	/* The name and location of the fsm. */
	String fsmName;
	InputLoc fsmStartSecLoc;
	InputLoc fsmEndSecLoc;

	/* The name of the file the fsm is from. */
	String fileName;

	/* Number of errors encountered parsing the fsm spec. */
	int errorCount;

	/* Counting the action and priority ordering. */
	int curActionOrd;
	int curPriorOrd;

	/* Root of the name tree. */
	NameInst *rootName;
	NameInst *curNameInst;

	/* Make name ids to name inst pointers. */
	NameInst **nameIndex;
};

void afterOpMinimize( FsmAp *fsm );
long makeFsmKeyHex( char *str, const InputLoc &loc, ParseData *pd );
long makeFsmKeyDec( char *str, const InputLoc &loc, ParseData *pd );
long makeFsmKeyNum( char *str, const InputLoc &loc, ParseData *pd );
long makeFsmKeyChar( char c, ParseData *pd );
void makeFsmKeyArray( long *result, char *data, int len, ParseData *pd );
int makeFsmUniqueKeyArray( long *result, char *data, int len, ParseData *pd );
FsmAp *makeBuiltin( BuiltinMachine builtin, ParseData *pd );


#endif /* _PARSEDATA_H */

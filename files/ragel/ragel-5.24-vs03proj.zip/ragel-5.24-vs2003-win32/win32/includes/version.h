#define VERSION "5.24"
#define PUBDATE "September 2007\n(Built with Microsoft (R) 32-bit C/C++ Optimizing Compiler Version 13.10.6030 for 80x86)"

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_RESIZE_H
#define _AAPL_RESIZE_H

#include <assert.h>

/* This step is expressed in units of T. Changing this requires changes to
 * docs in ResizeLin constructor.  */
#define LIN_DEFAULT_STEP 256

/*
 * Resizing macros giving different resize methods.
 */

/* If needed is greater than existing, give twice needed. */
#define EXPN_UP( existing, needed ) \
		needed > existing ? (needed<<1) : existing
	
/* If needed is less than 1 quarter existing, give twice needed. */
#define EXPN_DOWN( existing, needed ) \
		needed < (existing>>2) ? (needed<<1) : existing

/* If needed is greater than existing, give needed plus step. */
#define LIN_UP( existing, needed ) \
	needed > existing ? (needed+step) : existing

/* If needed is less than existing - 2 * step then give needed plus step. */
#define LIN_DOWN( existing, needed ) \
	needed < (existing-(step<<1)) ? (needed+step) : existing

/* Return existing. */
#define CONST_UP( existing, needed ) existing

/* Return existing. */
#define CONST_DOWN( existing, needed ) existing

/**
 * Resize up and down linearly.
 */
class ResizeLin
{
protected:
	/**
	 * Default constructor intializes resize step to 256.
	 */
	ResizeLin() : step(LIN_DEFAULT_STEP) { }

	/**
	 * If existing space is insufficient for needed space, then allocate needed
	 * plus step (in units of sizeof(T)).
	 */
	inline int upResize( int existing, int needed )
		{ return LIN_UP(existing, needed); }

	/**
	 * If existing space is less than existing - 2 * step, then allocate needed
	 * plus step (in units of sizeof(T)).
	 */
	inline int downResize( int existing, int needed )
		{ return LIN_DOWN(existing, needed); }

public:

	/**
	 * Amount of extra space in units of sizeof(T) added each time a resize
	 * must take place. This may be changed at any time. Keep it >= 0.
	 */
	int step;
};

/**
 * No up and down resizing, allocation stays constant.
 */
class ResizeConst
{
protected:
	/* Assert don't need more than exists. Return existing. */
	static inline int upResize( int existing, int needed )
		{ assert( needed <= existing ); return CONST_UP(existing, needed); }

	/* Return existing. */
	static inline int downResize( int existing, int needed )
		{ return CONST_DOWN(existing, needed); }
};

/**
 * Run time control of what kind of resizing is done.
 */
class ResizeRunTime
{
protected:
	inline ResizeRunTime();

	enum ResizeType {
		Exponential,
		Linear,
		Constant
	};

	inline int upResize( int existing, int needed );
	inline int downResize( int existing, int needed );

public:
	/* Step for linear resizing. */
	int step;

	/* Resizing types. */
	ResizeType upResizeType;
	ResizeType downResizeType;

};

inline ResizeRunTime::ResizeRunTime()
:
	step( LIN_DEFAULT_STEP ),
	upResizeType( Exponential ),
	downResizeType( Linear )
{
}

/* UpResize switches on the resize type. */
inline int ResizeRunTime::upResize( int existing, int needed )
{
	switch ( upResizeType ) {
	case Exponential:
		return EXPN_UP(existing, needed);
	case Linear:
		return LIN_UP(existing, needed);
	case Constant:
		assert( needed <= existing ); 
		return CONST_UP(existing, needed);
	default:
		assert( false );
	}
};

/* DownResize switches on the resize type. */
inline int ResizeRunTime::downResize( int existing, int needed )
{
	switch ( downResizeType ) {
	case Exponential:
		return EXPN_DOWN(existing, needed);
	case Linear:
		return LIN_DOWN(existing, needed);
	case Constant:
		return CONST_DOWN(existing, needed);
	default:
		assert( false );
	}
}

/* Don't need these anymore. */
#undef EXPN_UP
#undef EXPN_DOWN
#undef LIN_UP
#undef LIN_DOWN
#undef CONST_UP
#undef CONST_DOWN

#endif /* _AAPL_RESIZE_H */

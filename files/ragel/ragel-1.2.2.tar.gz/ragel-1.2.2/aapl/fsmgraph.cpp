/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMGRAPH_CC
#define _AAPL_FSMGRAPH_CC

#include <assert.h>

#include "fsmgraph.h"
#include "mergesort.h"
#include "fsmstate.cpp"
#include "fsmbase.cpp"
#include "fsmattach.cpp"

/**
 * Make a new state. The new state will be put on the graph's
 * list of state. The new state can be created final or non final.
 */
template < class State, class TransFunc, class Transition >
		State *FsmGraph<State, TransFunc, Transition>::
		NewState(bool isFinState)
{
	/* Create the new state. */
	StateList::append(new State());

	/* Do we want to create this state as a final state. */
	if (isFinState)
		SetFinState(tail);

	/* Return the new state. */
	return tail;
}

/**
 * Create an fsm that is a concatenation of the characters in the given string.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::ConcatFsm( char *str )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state. */
	State *last = retVal->NewState();
	State *newState;

	/* Attach subsequent states. */
	retVal->startState = last;
	for ( ; *str != 0; str++ ) {
		newState = retVal->NewState();
		retVal->AttachStates( last, newState, KeyTypeSingle, *str, 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->SetFinState(last);

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		ConcatFsm( int *str, int len )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state. */
	State *last = retVal->NewState();
	State *newState;

	/* Attach subsequent states. */
	retVal->startState = last;
	for ( int i = 0; i < len; i++, str++ ) {
		newState = retVal->NewState();
		retVal->AttachStates( last, newState, KeyTypeSingle, *str, 0 );
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->SetFinState(last);

	return retVal;
}



template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		OrFsm( char *set )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	retVal->startState = start;
	for ( ; *set != 0; set++ )
		retVal->AttachStates( start, end, KeyTypeSingle, *set, 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		OrFsm( int *set, int len )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	retVal->startState = start;
	for ( int i = 0; i < len; i++, set++ )
		retVal->AttachStates( start, end, KeyTypeSingle, *set, 0 );

	return retVal;
}

template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::NullFsm()
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Give it one state with no transitions making it
	 * the start state and final state. */
	retVal->startState = retVal->NewState(true);

	/* Return new Graph. */
	return retVal;
}

/**
 * Make a graph with two states and the default transition between them.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::DotFsm()
{
	/* New graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	/* Set the start state and attach. */
	retVal->startState = start;
	retVal->AttachStates( start, end, KeyTypeDefault, 0, 0 );

	return retVal;
}

/**
 * Make a graph with one state (which is final) and a default transition back
 * to itself.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::DotStarFsm()
{
	/* New graph. */
	FsmGraph *retVal = new FsmGraph;

	/* One state which is final and is the start state. */
	State *start = retVal->NewState(true);
	retVal->startState = start;

	/* Attach start to start on default. */
	retVal->AttachStates( start, start, KeyTypeDefault, 0, 0 );

	return retVal;
}

/**
 * Make a graph with one two states and a range of transitions between them.
 */
template < class State, class TransFunc, class Transition >
		FsmGraph<State, TransFunc, Transition>*
		FsmGraph<State, TransFunc, Transition>::
		RangeFsm(int low, int high)
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	/* Attach using the range of characters. */
	retVal->AttachStates( start, end, KeyTypeRange, low, high );
	retVal->startState = start;

	return retVal;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Star(bool leavingFsm)
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);

	/* Build a state set consisting of our start state. */
	StateSet startStateSet;
	startStateSet.set( startState );

	/* For the merging process. */
	MergeData md;

	/* Get a copy of the final state set before creating the new
	 * start state. It may get set final and we don't want the start
	 * state to be included in the final state set. If it is included
	 * in the final state set then all the final states after it get
	 * the transitions of the start state doubled up. That's incorrect.*/
	StateSet finStateSetCopy(finStateSet);

	/* This will be the new start state. It gets set as final and the
	 * existing start state is merged with it. */
	State *newState = NewState(false);
	MergeStates( md, newState, startStateSet, false );
	
	/* Set it as the start state. */
	startState = newState;
	startStateSet.setAs( newState );

	/* For all the final states, merge with the new start state. */
	State **st = finStateSetCopy.table;
	int nst = finStateSetCopy.tableLength;
	for (int i = 0; i < nst; i++, st++) {
		MergeStates( md, *st, startStateSet, leavingFsm );
	}

	/* Now it is safe to merge the start state with itself (provided it
	 * is set final). */
	if ( startState->isFinState )
		MergeStates( md, startState, startStateSet, leavingFsm );

	/* Now ensure the new start state is a final state. */
	SetFinState(startState);

	/* Fill in any states that were newed up as combinations of others. */
	FillInStates( md );

	/* Remove states that have no path into them. */
	RemoveUnreachableStates();

	/* There is nothing in the Star routine to cause states to loose
	 * thier final stateness. So assert the fact that there should be
	 * no non-final states with out functions/priorites. */
	VerifyOutFuncs();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Concat(FsmGraph *other, bool leavingFsm)
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);
	other->SetFinBits(SB_GRAPH2, 0);

	/* Build a state set consisting of other's start state. */
	StateSet startStateSet;
	startStateSet.set( other->startState );

	/* For the merging process. */
	MergeData md;

	/* Get a copy of our final state set. We need to iterate over it
	 * while it may change. */
	StateSet finStateSetCopy(finStateSet);

	/* Unset all of our final states. */
	UnsetAllFinStates();

	/* Merge the lists. Get the final states from other. */
	append( *other );
	finStateSet.set( other->finStateSet );
	
	/* Since other's list is emtpy, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our (former) final states with the start state of other. */
	State **st = finStateSetCopy.table;
	int nst = finStateSetCopy.tableLength;
	for (int i = 0; i < nst; i++, st++)
		MergeStates( md, *st, startStateSet, leavingFsm );

	/* Fill in any new states made from merging. */
	FillInStates( md );

	/* Remove any states that have no path into them. */
	RemoveUnreachableStates();

	/* Strip out functions/priorities from non final states. */
	StripNonFinalStates();
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		DoOr(FsmGraph *other)
{
	/* Build a state set consisting of both start states */
	StateSet startStateSet;
	startStateSet.set( startState );
	startStateSet.set( other->startState );

	/* For the merging process. */
	MergeData md;

	/* Merge the lists. This will move all the states from otherj
	 * into this. No states will be deleted. */
	append( *other );

	/* Move the final set data from other into this. */
	finStateSet.set(other->finStateSet);
	other->finStateSet.empty();

	/* Since other's list is emtpy, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Create a new start state. */
	State *newStartState = NewState();
	startState = newStartState;

	/* Merge the start states. */
	MergeStates( md, newStartState, startStateSet, false );

	/* Fill in any new states made from merging. */
	FillInStates( md );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Or(FsmGraph *other)
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);
	other->SetFinBits(SB_GRAPH2, 0);

	/* Call Worker routine. */
	DoOr( other );

	/* Remove states which have no path into them. */
	RemoveUnreachableStates();

	/* Veryify that there are no out functions on non final states.
	 * This should be true as no states should have their final stateness removed. */
	VerifyOutFuncs();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Intersect(FsmGraph *other)
{
	/* Set the fin bits on this and other to want each other. */
	SetFinBits(SB_GRAPH1, SB_WANTOTHER1);
	other->SetFinBits(SB_GRAPH2, SB_WANTOTHER2);

	/* Unset final states in both. */
	UnsetAllFinStates();
	other->UnsetAllFinStates();

	/* Call worker Or routine. */
	DoOr( other );

	/* Remove states that have no path into them. */
	RemoveUnreachableStates();

	/* Remove states that have no path to a final state. */
	RemoveDeadEndStates();

	/* Strip the out function data from states that are no longer final. */
	StripNonFinalStates();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		Subtract(FsmGraph *other)
{
	/* Set the fin bits of other to be killers. */
	SetFinBits(SB_GRAPH1, 0);
	other->SetFinBits(SB_GRAPH2, SB_KILLOTHERS);

	/* Unset all final states and remove all transition data from other. */
	other->UnsetAllFinStates();
	other->ClearAllTransData();

	/* Call worker Or routine. */
	DoOr( other );

	/* Remove states that have no path into them. */
	RemoveUnreachableStates();

	/* Remove states that have no path to a final state. */
	RemoveDeadEndStates();

	/* Strip the out function data from states that are no longer final. */
	StripNonFinalStates();
}

/**
 * Ensure that the start state is free of entry points (aside from the fact
 * that it is the start state). If the start state has entry points then Make a
 * new start state by merging with the old one. Useful before modifying start
 * transitions. If the existing start state has any entry points other than the
 * start state entry then modifying its transitions changes more than the start
 * transitions. So isolate the start state by separating it out such that it
 * only has start stateness as it's entry point.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::IsolateStartState( )
{
	/* TODO: Need to be able to determine if the start state has any in
	 * transitions.  This cannot be accurately done by checking if inList is
	 * empty because inList may contain null pointers. For now, simply dup the
	 * start state unconditionally. */

	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);

	/* Build a state set consisting of our start state. */
	StateSet startStateSet;
	startStateSet.set( startState );

	/* For the merging process. */
	MergeData md;

	/* This will be the new start state. It the existing start
	 * state is merged with it. */
	State *newState = NewState(false);
	MergeStates( md, newState, startStateSet, false );
	
	/* Set it as the start state. */
	startState = newState;
	startStateSet.setAs( newState );

	/* Stfil and stateDict will be empty because the merging of the old start
	 * state into the new one will not have any conflicting transitions. */
	assert( md.stateDict.nodeCount == 0 );
	assert( md.stfil.listLength == 0 );

	/* The old start state may be unreachable. */
	RemoveUnreachableStates();
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		SetStateNumbers()
{
	int curNum = 0;
	State *state = head;
	while (state != 0) {
		state->num = curNum;
		curNum++;
		state = state->next;
	}
}


template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		UnsetAllFinStates()
{
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ ) {
		(*st)->isFinState = false;
	}
	finStateSet.empty();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		SetFinBits( int allStateBits, int finStateBits )
{
	State *state = head;
	while ( state != 0 ) {
		if ( state->isFinState )
			state->stateBits = allStateBits | finStateBits;
		else
			state->stateBits = allStateBits;

		state = state->next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MergeStates( MergeData &md, State *newState, StateSet &stateSet, 
				bool leavingFsm )
{
	int bits = newState->stateBits | SB_MERGED;
	bool finState = newState->isFinState;

	State **stp = stateSet.table;
	int nst = stateSet.tableLength;
	for ( int i = 0; i < nst; i++, stp++ ) {
		State *src = *stp;

		/* Get the out transitions. */
		OutTransCopy( md, newState, src, leavingFsm );

		/* Get bits and final state status. */
		bits |= src->stateBits;
		if ( src->isFinState )
			finState = true;

		/* Merge the outTransFuncTable. */
		if ( src == newState ) {
			/* Duplicate the list. */
			typename Transition::TransFuncTable
					srcTransTable( src->outTransFuncTable );
			newState->SetOutFunctions( srcTransTable );
		}
		else {
			/* Get the out functions. */
			newState->SetOutFunctions( src->outTransFuncTable );
		}

		if ( src->isOutPriorSet ) {
			newState->isOutPriorSet = true;
			newState->outPriority = src->outPriority;
		}

		/* Call user routine. */
		newState->MergeState( src );
	}

	if ( bits&SB_KILLOTHERS ) {
		/* One final state is a killer, don't set final. */
		finState = false;

		/* Kill the out transitions. Reset the priority. */
		newState->outTransFuncTable.empty();
		newState->isOutPriorSet = false;
		newState->outPriority = 0;
	}

	if ( (bits&SB_WANTOTHER) == SB_WANTOTHER ) {
		/* There are companions in this state, we can make it final. */
		finState = true;
	} else if ( bits&SB_WANTOTHER ) {
		/* One state wants the other but it is not there. */
		finState = false;

		/* Kill the out transitions. Reset the priority. */
		newState->outTransFuncTable.empty();
		newState->isOutPriorSet = false;
		newState->outPriority = 0;
	}

	newState->stateBits = bits;
	if ( finState )
		SetFinState( newState );
	else
		UnsetFinState( newState );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		FillInStates( MergeData &md )
{
	/* Merge any states that are awaiting mergin. This will likey cause
	 * other states to be added to the stfil list. */
	State *state = md.stfil.head;
	while ( state != 0 ) {
		MergeStates( md, state, state->stateDictNode->stateSet, false );
		state = state->next;
	}

	/* For all the states that are on the stfil list. Delete their stateSets
	 * and move them back to the main list. */
	while ( md.stfil.listLength > 0 ) {
		/* Delete and reset the state set. */
		State *state = md.stfil.head;
		delete state->stateDictNode;
		state->stateDictNode = 0;

		/* Move the list from the stfil list to the graph's list. */
		md.stfil.detach( state );
		StateList::append( state );
	}

	/* Stfil will now be empty. We do not need to delete its elements. 
	 * stateDict will still have it's ptrs/size set but all of it's nodes
	 * will be deleted so we don't need to clean it up. */
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		CondenseStable()
{
	/* Set the state numbers. */
	SetStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex markIndex(listLength);

	/* Mark pairs where final stateness, out trans, or trans data differ. */
	InitialMarkRound( markIndex );

	/* While the last round of marking succeeded in marking a state
	 * continue to do another round. */
	int modified = MarkRound( markIndex );
	while (modified)
		modified = MarkRound( markIndex );

	/* Merge pairs that are unmarked. */
	MergeUnmarkedPairs( markIndex );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		CondenseApproximate()
{
	/* While the last condensing round succeeded in
	 * compacting states, continue to try to compact
	 * states. */
	int modified = CondenseRound();
	while (modified)
		modified = CondenseRound();
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		CondenseOptimized1()
{
	/* Set the state numbers. */
	SetStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex markIndex(listLength);

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	State *p = head;
	for ( int i = 0; i < listLength; i++, p = p->next ) {
		State *q = head;
		for ( int j = 0; j < i; j++, q = q->next ) {
			MarkIndex::StatePair *pair = 
					markIndex.GetPair(i, j);
			pair->p = p;
			pair->q = q;

/* The commented out code represents the optimized condensing. It is 
 * commented out for the following reasons:
 *   -It does not always find the optimal condense.
 *   -It requires that stateBits be maintained correctly
 *    and that condensing occur on each op.
 *   -I have not shown it to be a significant improvement
 *    over non optimized
 */

//			int combinedBits = p->stateBits | q->stateBits;
//		
//			/* if either is merged or they are from separate machines. */
//			if ( combinedBits & SB_MERGED ||
//					(combinedBits&SB_GRAPHBOTH) == SB_GRAPHBOTH ) {
				/* If only one is a final state then mark. */
				if ( p->isFinState ^ q->isFinState )
					pair->isMarked = true;
				/* If out Transition data differs then mark. */
				else if ( State::CompareOutTrans( *p, *q ) != 0)
					pair->isMarked = true;
				/* If transition data differs then mark. */
				else if ( ShouldMarkPair(markIndex, p, q, true) )
					pair->isMarked = true;
				
				/* Put the pair on the appropriate list. */
				if ( pair->isMarked )
					markIndex.markedList.append( pair );
				else
					markIndex.unmarkedList.append( pair );
//			}
//			else if ( p->stateBits & SB_NEWINTRANS ||
//						q->stateBits & SB_NEWINTRANS ) {
//				/* Pair is not merged, from the same graph and one of the
//				 * states has had their in trans changed. The pair is marked
//				 * and we must exhaust it because of the in trans change. */
//				pair->isMarked = true;
//				markIndex.markedList.append( pair );
//			}
//			else {
//				/* Pair is not merged, from the same graph neither has had 
//				 * their in trans modified. The pair is marked and could not
//				 * possibly cause other states that are not already marked to 
//				 * be marked. So do not put on exhaust list. */
//				pair->isMarked = true;
//			}
		}
	}

	/* Exhaust all transtions that could could cause other transtions 
	 * to be marked. */
	ExhaustAll( markIndex );

	/* Merge pairs that are unmarked. */
	MergeUnmarkedPairs( markIndex );
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		CondenseOptimized2()
{
	/* Set the state numbers. */
	SetStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex markIndex(listLength);

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	State *p = head;
	for ( int i = 0; i < listLength; i++, p = p->next ) {
		State *q = head;
		for ( int j = 0; j < i; j++, q = q->next ) {
			MarkIndex::StatePair *pair = 
					markIndex.GetPair(i, j);
			pair->p = p;
			pair->q = q;

/* The commented out code represents the optimized condensing. It is 
 * commented out for the following reasons:
 *   -It does not always find the optimal condense.
 *   -It requires that stateBits be maintained correctly
 *    and that condensing occur on each op.
 *   -I have not shown it to be a significant improvement
 *    over non optimized
 */

			int combinedBits = p->stateBits | q->stateBits;
		
			/* if either is merged or they are from separate machines. */
			if ( combinedBits & SB_MERGED ||
					(combinedBits&SB_GRAPHBOTH) == SB_GRAPHBOTH ) {
				/* If only one is a final state then mark. */
				if ( p->isFinState ^ q->isFinState )
					pair->isMarked = true;
				/* If out Transition data differs then mark. */
				else if ( State::CompareOutTrans( *p, *q ) != 0)
					pair->isMarked = true;
				/* If transition data differs then mark. */
				else if ( ShouldMarkPair(markIndex, p, q, true) )
					pair->isMarked = true;
				
				/* Put the pair on the appropriate list. */
				if ( pair->isMarked )
					markIndex.markedList.append( pair );
				else
					markIndex.unmarkedList.append( pair );
			}
			else if ( p->stateBits & SB_NEWINTRANS ||
						q->stateBits & SB_NEWINTRANS ) {
				/* Pair is not merged, from the same graph and one of the
				 * states has had their in trans changed. The pair is marked
				 * and we must exhaust it because of the in trans change. */
				pair->isMarked = true;
				markIndex.markedList.append( pair );
			}
			else {
				/* Pair is not merged, from the same graph neither has had 
				 * their in trans modified. The pair is marked and could not
				 * possibly cause other states that are not already marked to 
				 * be marked. So do not put on exhaust list. */
				pair->isMarked = true;
			}
		}
	}

	/* Exhaust all transtions that could could cause other transtions 
	 * to be marked. */
	ExhaustAll( markIndex );

	/* Merge pairs that are unmarked. */
	MergeUnmarkedPairs( markIndex );
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		CondenseRound()
{
	/* Nothing to do if there are no states. */
	if (listLength == 0)
		return false;

	/* Fill up an array of pointers to the states. */
	State** statePArray = new State*[listLength];
	State *state = head;
	State **dst = statePArray;
	while ( state != 0 ) {
		*dst = state;
		dst += 1;
		state = state->next;
	}

	bool modified = false;

	/* Sort The list. */
	MergeSort<State*,State>::Sort( statePArray, listLength );

	/* Walk the list looking for duplicates next to each other, 
	 * merge in any duplicates. */
	State **pLast = statePArray;
	State **pState = statePArray + 1;
	for ( int i = 1; i < listLength; i++, pState++ ) {
		if ( State::Compare( *pLast, *pState ) == 0 ) {
			/* Last and pState are the same, so set to merge. 
			 * Move forward with pState but not with pLast. If 
			 * any more are identical, we must */
			MergePIntoQ( *pState, *pLast );
			modified = true;
		}
		else {
			/* Last and this are different, do not set to merge
			 * them. Move pLast to the current (it may be way behind
			 * from merging many states) and pState forward one to 
			 * consider the next pair. */
			pLast = pState;
		}
	}
	delete[] statePArray;
	return modified;
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		InitialMarkRound( MarkIndex &markIndex )
{
	State *p = head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = head;
		while ( q != p ) {
			bool mark = false;

			/* If final stateness is not identical then mark. */
			if ( p->isFinState ^ q->isFinState )
				mark = true;
			/* If p and q are both final states and they have different
			 * out transitions then mark. */
			else if (p->isFinState && q->isFinState && 
					State::CompareOutTrans( *p, *q ) != 0)
				mark = true;
			/* If any trans pairs go to a marked state or if the
			 * trans data differs then mark. */
			else if ( ShouldMarkPair(markIndex, p, q, true) )
				mark = true;

			if ( mark )
				markIndex.MarkPair(p->num, q->num);

			q = q->next;
		}
		p = p->next;
	}
}

template < class State, class TransFunc, class Transition >
		bool FsmGraph<State, TransFunc, Transition>::
		MarkRound( MarkIndex &markIndex )
{
	bool pairWasMarked = false;
	State *p = head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = head;
		while ( q != p ) {
			/* Should we mark the pair. */
			if ( !markIndex.IsPairMarked( p->num, q->num ) &&
						ShouldMarkPair(markIndex, p, q, false) ) {
				markIndex.MarkPair(p->num, q->num);
				pairWasMarked = true;
			}
			q = q->next;
		}
		p = p->next;
	}

	return pairWasMarked;
}


/**
 * Calls MarkPairsOnIn on all the pairs in markIndex.markedList. Used by
 * experimental condensing. Not used by stable or approximate condensing.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		ExhaustAll( MarkIndex &markIndex )
{
	MarkIndex::StatePair *pair = markIndex.markedList.head;

	while ( pair != NULL ) {
		MarkPairsOnIn( markIndex, pair->p, pair->q );
		pair = pair->next;
	}
}

/**
 * Remove states that have no path to them from the start state. Recursively
 * traverses the graph marking states that have paths into them. Then removes
 * all states that did not get marked.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		RemoveUnreachableStates()
{
	State *state, *next;

	/* Mark all the states that can be reached
	 * thought the existing transition set. */
	MarkReachableFromHere(startState);

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = head;
	while (state) {
		next = state->next;

		if (state->isMarked)
			state->isMarked = false;
		else
			delete DetachState(state);
		

		state = next;
	}
}

/**
 * Remove states that that do not lead to a final states. Works recursivly traversing
 * the graph in reverse (starting from all final states) and marking seen states. Then
 * removes states that did not get marked.
 */
template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		RemoveDeadEndStates()
{
	State *state, *next;

	/* Start State gets honorary marking. We don't want it to accidentially
	 * go away. */
	startState->isMarked = true;

	/* Mark all states that have paths to the final states. */
	State **st = finStateSet.table;
	int nst = finStateSet.tableLength;
	for ( int i = 0; i < nst; i++, st++ )
		MarkReachableFromHereReverse( *st );

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = head;
	while (state) {
		next = state->next;

		if (state->isMarked)
			state->isMarked = false;
		else
			delete DetachState(state);
		
		state = next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		StripNonFinalStates()
{
	State *state = head;
	while ( state != NULL ) {
		if ( ! state->isFinState ) {
			state->outTransFuncTable.empty();
			state->isOutPriorSet = false;
			state->outPriority = 0;
		}
		state = state->next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		VerifyOutFuncs()
{
	State *state = head;
	while ( state != NULL ) {
		if ( ! state->isFinState ) {
			assert( state->outTransFuncTable.tableLength == 0 );
			assert( !state->isOutPriorSet );
			assert( state->outPriority == 0 );
		}
		state = state->next;
	}
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MergePIntoQ(State *p, State *q)
{
	/* Definition: The primary state of an equivalence class is
	 * the first state encounterd that belongs to the equivalence
	 * class. All equivalence classes have primary state including
	 * equivalence classes with one state in it. */

	/* Merge p into q and delete p. q is always the primary state
	 * of it's equivalence class. We wouldn't have landed on it here
	 * if it were not, because it would have been deleted.
	 *
	 * Proof that q is the primaray state of it's equivalence class:
	 * Assume q is not the primary state of it's equivalence
	 * class, then it would be merged into some state that came
	 * before it and thus p would be equivalent to that state. But
	 * q is the first state that p is equivalent to so we have a 
	 * contradiction. */

	/* Cur is a duplicate. We can merge it with trail. */
	InTransMove(q, p);

	if (p == startState)
		startState = q;

	/* Call user routine. */
	q->FuseState(p);

	delete DetachState(p);
}

template < class State, class TransFunc, class Transition >
		void FsmGraph<State, TransFunc, Transition>::
		MergeUnmarkedPairs( MarkIndex &markIndex )
{
	State *p = head, *nextP, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		nextP = p->next;

		q = head;
		while ( q != p ) {
			/* If one of p or q is a final state then mark. */
			if ( ! markIndex.IsPairMarked(p->num, q->num) ) {
				MergePIntoQ(p, q);
				break;
			}
			q = q->next;
		}
		p = nextP;
	}
}

#endif /* _AAPL_FSMGRAPH_CC */

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_VECTOR_H
#define _AAPL_VECTOR_H

#define VECT_COMPLEX
#include "vectcommon.h"
#undef VECT_COMPLEX

/**
 * The copy constructor copies the contents of the the given vector into this
 * vector. Copy Constructors are in turn called on all the items in the vector.
 */
template<class T, class Resize> Vector<T, Resize>::
		Vector(const Vector<T, Resize> &v)
{
	tableLength = v.tableLength;
	allocLength = v.allocLength;

	if ( allocLength > 0 ) {
		/* Allocate needed space. */
		table = (T*) malloc(sizeof(T) * allocLength);
		if ( table == NULL )
			throw std::bad_alloc();

		/* If there are any items in the src table, copy them in. */
		T *dst = table, *src = v.table;
		for (int pos = 0; pos < tableLength; pos++, dst++, src++ )
			new(dst) T(*src);
	}
	else {
		/* Nothing allocated. */
		table = NULL;
	}

}

/**
 * Calls the destructor on every item in the Vector, frees the memory used and
 * resets the contents to nil.
 */
template<class T, class Resize> void Vector<T, Resize>::
		empty()
{
	if ( table != NULL ) {
		/* Call All destructors. */
		T *pos = table;
		for ( int i = 0; i < tableLength; pos++, i++ )
			pos->~T();

		/* Free the table space. */
		free( table );
		table = NULL;
		tableLength = allocLength = 0;
	}
}

/****************************************
 * Sets the contents of the vector to exactly what the parameters are.
 * If data is NIL, then default constructors are called on every item.
 */
template<class T, class Resize> void Vector<T, Resize>::
		setAs(const T *data, int len)
{
	/* Call All destructors. */
	T *pos = table;
	for ( int i = 0; i < tableLength; pos++, i++ )
		pos->~T();

	/* Adjust the allocated length. */
	if ( len < tableLength )
		downResize( len );
	else if ( len > tableLength )
		upResize( len );

	/* Set the new table length to exactly len. */
	tableLength = len;	
	
	/* Copy data if it was supplied. */
	T *dst = table;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}
}


/**
 * Overwrites with items in data at posion pos. Any items that are overwritten
 * have thier destructors called. If pos is off the end of the buffer then new
 * items are constructed.
 */
template<class T, class Resize> void Vector<T, Resize>::
		replace(int pos, const T *data, int len)
{
	int endPos, i;
	T *item;

	/* If we are given a negative position to replace at then
	 * treat it as a position relative to the length. */
	if ( pos < 0 )
		pos = tableLength + pos;

	/* The end is the one past the last item that we want
	 * to write to. */
	endPos = pos + len;

	/* Make sure we have enough space. */
	if ( endPos > tableLength )
		upResize( endPos );

	/* Delete any objects we need to delete. */
	item = table + pos;
	for ( i = pos; i < tableLength && i < endPos; i++, item++ )
		item->~T();
		
	/* Init any default constructors we need to. */
	item = table + tableLength;
	for ( i = tableLength; i < pos; i++, item++ )
		new(item) T();

	/* Set the new tableLength. */
	tableLength = endPos;
	
	/* Copy data if it was supplied. */
	T *dst = table + pos;
	const T *src = data;
	if ( src == NULL ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}
}


/**
 * Deletes len items at position pos. All items that are deleted have their
 * destructors called.
 */
template<class T, class Resize> void Vector<T, Resize>::
		remove(int pos, int len)
{
	int newLen, lenToSlideOver, endPos;
	T *dst, *item;

	/* If we are given a negative position to remove at then
	 * treat it as a position relative to the length. */
	if ( pos < 0 )
		pos = tableLength + pos;

	/* The first position after the last item deleted. */
	endPos = pos + len;

	/* The New table length. */
	newLen = tableLength - len;

	/* The place in the table we are deleting at. */
	dst = table + pos;

	/* Call Destructors. */
	item = dst;
	for ( int i = 0; i < len; i += 1, item += 1 )
		item->~T();
	
	/* Shift data over if necessary. */
	lenToSlideOver = tableLength - endPos;	
	if ( len > 0 && lenToSlideOver > 0 )
		memmove(dst, dst + len, sizeof(T)*lenToSlideOver);

	/* Shrink the table if necessary. */
	downResize( newLen );

	/* Set the new table length. */
	tableLength = newLen;
}

/**
 * Insert len items into the buffer at position pos. If pos is off the end new
 * items are constructed. No items are destroyed. Any data to the right of pos
 * is shifted over.
 */
template<class T, class Resize> void Vector<T, Resize>::
		insert(int pos, const T *data, int len)
{
	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the length. */
	if ( pos < 0 )
		pos = tableLength + pos;
	
	int newLen = makeRawSpaceFor(pos, len);

	/* Copy data if it was supplied. */
	T *dst = table + pos;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}

	/* Set the new tableLength. */
	tableLength = newLen;
}

/**
 * Makes space for len items, Does not init the items in any way.  If pos is
 * off the end then default constructors are called for any any items that are
 * included in the growth of the vector but not in the subvector specified by
 * pos, len.
 *
 * Returns the new tableLength but does NOT update it, This is up to the
 * caller!
 */
template<class T, class Resize> int Vector<T, Resize>::
		makeRawSpaceFor(int pos, int len)
{
	/* Calculate the new length. */
	int newLen;
	if (pos >= tableLength)
		newLen = pos + len;
	else
		newLen = tableLength + len;

	/* Up resize, we are growing. */
	upResize( newLen );

	/* Init any default constructors we need to. */
	T *item = table + tableLength;
	for ( int i = tableLength; i < pos; i++, item++ )
		new(item) T();

	/* Shift over data at insert spot if needed. */
	if ( len > 0 && pos < tableLength ) {
		memmove(table + pos + len, table + pos,
			sizeof(T)*(tableLength-pos));
	}

	return newLen;
}


#endif /* _AAPL_VECTOR_H */

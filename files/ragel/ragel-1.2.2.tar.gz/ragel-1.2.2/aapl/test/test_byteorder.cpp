/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <assert.h>
#include "byteorder.h"


/* Read / Write to the little endian format and assert correctness. These tests
 * should work on any system. */
int littleEndian()
{
	unsigned char buf[4];
	int num = 0x030677ff, num2;

	EndianLittle::writeInt(buf, num);
	assert( buf[0] == 0xff );
	assert( buf[1] == 0x77 );
	assert( buf[2] == 0x06 );
	assert( buf[3] == 0x03 );

	num2 = EndianLittle::readInt(buf);
	assert( num == num2 );

	return 0;
}

/* Read / Write to the little endian format and assert correctness. These tests
 * should work on any system. */
int bigEndian()
{
	unsigned char buf[4];
	int num = 0x030677ff, num2;

	EndianBig::writeInt(buf, num);
	assert( buf[0] == 0x03 );
	assert( buf[1] == 0x06 );
	assert( buf[2] == 0x77 );
	assert( buf[3] == 0xff );

	num2 = EndianBig::readInt(buf);
	assert( num == num2 );

	return 0;
}

int main()
{
	littleEndian();
	bigEndian();
	return 0;
}

/*
 *  Copyright 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_VECTSIMP_H
#define _AAPL_VECTSIMP_H

#define Vector VectSimp
#include "vectcommon.h"
#undef Vector


/**
 * The copy constructor copies the contents of the the given vector into this
 * vector. Uses memcpy to put data into this vector.
 */
template<class T, class Resize> VectSimp<T, Resize>::
		VectSimp(const VectSimp<T, Resize> &b)
{
	tableLength = b.tableLength;
	allocLength = b.allocLength;

	if ( allocLength > 0 ) {
		/* Alloc the space for the table. */
		table = (T*) malloc(sizeof(T)*allocLength);
		if ( table == NULL )
			throw std::bad_alloc();

		/* Copy the data in. */
		memcpy( table, b.table, sizeof(T)*tableLength );
	}
	else {
		/* Noting is allocated. */
		table = NULL;
	}
}

/**
 * Frees the memory used and resets the contents to nil.
 */
template<class T, class Resize> void VectSimp<T, Resize>::
		empty()
{
	if ( table != NULL ) {
		/* Free the table space. */
		free( table );
		table = NULL;
		tableLength = allocLength = 0;
	}
}

/**
 * Sets the contents of the vector to exactly what the parameters are. If data
 * is NIL, then nothing is copied.
 */
template<class T, class Resize> void VectSimp<T, Resize>::
		setAs(const T *data, int len)
{
	/* Adjust the allocated length. */
	if ( len < tableLength )
		downResize(len);
	else if ( len > tableLength )
		upResize(len);

	/* Set the new table length to exactly len. */
	tableLength = len;
	
	/* If data was supplied, copy it in. */
	if ( data != NULL )
		memcpy( table, data, sizeof(T)*len );
}

/**
 * Overwrites with items in data at posion pos. If pos is off the end of the
 * vector then new items are constructed.
 */
template<class T, class Resize> void VectSimp<T, Resize>::
		replace(int pos, const T *data, int len)
{
	/* If we are given a negative position to replace at then
	 * treat it as a position relative to the length. */
	if ( pos < 0 )
		pos = tableLength + pos;

	/* The end is the one past the last item that we want
	 * to write to. */
	int endPos = pos + len;

	/* Make sure we have enough space. */
	if ( endPos > tableLength )
		upResize( endPos );

	/* Set the new tableLength. */
	tableLength = endPos;
	
	/* If data was supplied, copy it in. */
	if ( data != NULL )
		memcpy( table + pos, data, sizeof(T)*len );
}


/**
 * Deletes len items at position pos. All items that are deleted have their
 * destructors called.
 */
template<class T, class Resize> void VectSimp<T, Resize>::
		remove(int pos, int len)
{
	int newLen, lenToSlideOver, endPos;

	/* If we are given a negative position to remove at then
	 * treat it as a position relative to the length. */
	if ( pos < 0 )
		pos = tableLength + pos;

	/* The first position after the last item deleted. */
	endPos = pos + len;

	/* The New table length. */
	newLen = tableLength - len;

	/* The place in the table we are deleting at. */
	T *dst = table + pos;

	/* Shift data over if necessary. */
	lenToSlideOver = tableLength - endPos;	
	if ( len > 0 && lenToSlideOver > 0 )
		memmove(dst, dst + len, sizeof(T)*lenToSlideOver);

	/* Shrink the table if necessary. */
	downResize( newLen );

	/* Set the new table length. */
	tableLength = newLen;

}

/**
 * Insert len items into the vector at position pos. Any data to the right of
 * pos is shifted over.
 */
template<class T, class Resize> void VectSimp<T, Resize>::
		insert(int pos, const T *data, int len)
{
	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the length. */
	if ( pos < 0 )
		pos = tableLength + pos;
	
	/* Calculate the new length. */
	int newLen;
	if ( pos >= tableLength )
		newLen = pos + len;
	else
		newLen = tableLength + len;

	/* Up resize, we are growing. */
	upResize( newLen );

	/* Shift over data at insert spot if needed. */
	if ( len > 0 && pos < tableLength ) {
		memmove(table + pos + len, table + pos,
			sizeof(T)*(tableLength-pos));
	}

	/* Copy data if it was supplied. */
	if ( data != NULL )
		memcpy( table + pos, data, sizeof(T)*len );

	/* Set the new tableLength. */
	tableLength = newLen;
}


#endif /* _AAPL_VECTSIMP_H */

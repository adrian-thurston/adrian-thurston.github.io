/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "byteorder.h"

#ifdef SBO_RUN_TIME

#include <assert.h>

/* If you allocate 4 bytes, then put a 1 in the lowest byte, 2 in the second lowest byte,
 * 3 in the second highest byte and 4 in highest byte and then cast the value to an unsigned
 * integer you get the following values on their respective architectures. */

#define RESULT_LITTLE_ENDIAN   0x04030201
#define RESULT_BIG_ENDIAN      0x01020304

/* System byte order types. */
enum ByteOrder {
	LittleEndian,
	BigEndian
};

/***
 * This Sytstem byte order class stores the system byte. It is also used to
 * initialize the system byte order before the main functions is entered by
 * means a constructor initializing static data.
 *
 * This class will only exist if byte ordering is specified as a run-time
 * test.
 */
class SystemByteOrder
{
public:
	/* Init the system byte order. */
	SystemByteOrder();

	/* Byte order recorded by the constructor. */
	ByteOrder byteOrder;
};

/* This will work properly on 32 bit systems but not on 16 bit system.
 * Undefined on 64 bit systems. */
SystemByteOrder::SystemByteOrder()
{
	int i = 0;
	unsigned char *dst = (unsigned char*)(&i);

	dst[0] = 0x01;
	dst[1] = 0x02;
	dst[2] = 0x03;
	dst[3] = 0x04;

	switch (i) {
		case RESULT_LITTLE_ENDIAN:
			byteOrder = LittleEndian;
			break;
		case RESULT_BIG_ENDIAN:
			byteOrder = BigEndian;
			break;
		default:
			assert(false);
	}
}


/* Determines byte order in constructor and is made available to following
 * routines. */
static SystemByteOrder systemByteOrder;

#endif /* SBO_RUN_TIME */


#ifdef SBO_RUN_TIME

int EndianLittle::readInt(void *buf)
{
	int retInt;
	unsigned char *dst = (unsigned char*) (&retInt);
	unsigned char *src = (unsigned char*) buf;

	switch (systemByteOrder.byteOrder) {
		case LittleEndian:
			dst[0] = src[0];
			dst[1] = src[1];
			dst[2] = src[2];
			dst[3] = src[3];
			break;

		case BigEndian:
			dst[0] = src[3];
			dst[1] = src[2];
			dst[2] = src[1];
			dst[3] = src[0];
			break;
	}

	return retInt;
}

void EndianLittle::writeInt(void *buf, int i)
{
	unsigned char *dst = (unsigned char*) buf;
	unsigned char *src = (unsigned char*) (&i);

	switch (systemByteOrder.byteOrder) {
		case LittleEndian:
			dst[0] = src[0];
			dst[1] = src[1];
			dst[2] = src[2];
			dst[3] = src[3];
			break;

		case BigEndian:
			dst[0] = src[3];
			dst[1] = src[2];
			dst[2] = src[1];
			dst[3] = src[0];
			break;
	}
}

#elif defined(SBO_LITTLE_ENDIAN)

/* Reading from little endian format on a little endian machine is simple,
 * just treat the pointer to void as a pointer to an int. */
int EndianLittle::readInt(void *buf)
{
	return *((int*) buf);
}

/* Writing to little endian format on a little endian machine is simple, just
 * treat the pointer to void as a pointer to an int. */
void EndianLittle::writeInt(void *buf, int i)
{
	*((int*) buf) = i;
}

#elif defined(SBO_BIG_ENDIAN)

int EndianLittle::readInt(void *buf)
{
	int retInt;
	unsigned char *dst = (unsigned char*) (&retInt);
	unsigned char *src = (unsigned char*) buf;

	dst[0] = src[3];
	dst[1] = src[2];
	dst[2] = src[1];
	dst[3] = src[0];

	return retInt;
}

void EndianLittle::writeInt(void *buf, int i)
{
	unsigned char *dst = (unsigned char*) buf;
	unsigned char *src = (unsigned char*) (&i);

	dst[0] = src[3];
	dst[1] = src[2];
	dst[2] = src[1];
	dst[3] = src[0];
}

#endif

#ifdef SBO_RUN_TIME

int EndianBig::readInt(void *buf)
{
	int retInt;

	switch (systemByteOrder.byteOrder) {
		case LittleEndian: {
			unsigned char *dst = (unsigned char*) (&retInt);
			unsigned char *src = (unsigned char*) buf;

			dst[0] = src[3];
			dst[1] = src[2];
			dst[2] = src[1];
			dst[3] = src[0];
			break;
		}

		case BigEndian:
			retInt = *((int*) buf);
			break;
	}

	return retInt;
}

void EndianBig::writeInt(void *buf, int i)
{
	switch (systemByteOrder.byteOrder) {
		case LittleEndian: {
			unsigned char *dst = (unsigned char*) buf;
			unsigned char *src = (unsigned char*) (&i);

			dst[0] = src[3];
			dst[1] = src[2];
			dst[2] = src[1];
			dst[3] = src[0];
			break;
		}

		case BigEndian: {
			*((int*) buf) = i;
			break;
		}
	}
}

#elif defined(SBO_LITTLE_ENDIAN)

int EndianBig::readInt(void *buf)
{
	int retInt;
	unsigned char *dst = (unsigned char*) (&retInt);
	unsigned char *src = (unsigned char*) buf;

	dst[0] = src[3];
	dst[1] = src[2];
	dst[2] = src[1];
	dst[3] = src[0];

	return retInt;
}

void EndianBig::writeInt(void *buf, int i)
{
	unsigned char *dst = (unsigned char*) buf;
	unsigned char *src = (unsigned char*) (&i);

	dst[0] = src[3];
	dst[1] = src[2];
	dst[2] = src[1];
	dst[3] = src[0];
}

#elif defined(SBO_BIG_ENDIAN)

/* Reading from big endian format on a big endian machine is simple,
 * just treat the pointer to void as a pointer to an int. */
int EndianBig::readInt(void *buf)
{
	return *((int*) buf);
}

/* Writing to big endian format on a big endian machine is simple, just
 * treat the pointer to void as a pointer to an int. */
void EndianBig::writeInt(void *buf, int i)
{
	*((int*) buf) = i;
}

#endif

/*
 *  Copyright 2001-2003 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "ragel.h"
#include "ftabcodegen.h"
#include "fsmmachine.h"
#include "parsetree.h"

/* Integer array line length. */
#define IALL 8

/* Transition array line length. */
#define TALL 4

/* Init base data. */
FTabCodeGen::FTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	TabCodeGen(fsmName, parseData, machine, out)
{ }

/* Write out the out-func for a state. */
std::ostream &FTabCodeGen::STATE_OUT_FUNC(FsmMachState *state)
{
	/* This function is only called if there are any out functions, so need
	 * not guard against there being none. */
	out << state->outFuncs+1;
	return out;
}

/* Write out the function for a transition. */
std::ostream &FTabCodeGen::TRANS_FUNC(FsmMachTrans *trans)
{
	if ( trans->funcs == FUNC_NO_FUNC )
		out << "0";
	else
		out << trans->funcs+1;
	return out;
}

/* Write out the function switch. This switch is keyed on the values
 * of the func index. */
std::ostream &FTabCodeGen::FUNC_SWITCH()
{
	/* Loop over all func indicies. */
	int *transFuncs = machine->allTransFuncs;
	for ( int i = 0; i < machine->numTransFuncIndex; i++ ) {
		/* 	We are at the start of a glob, write the case. */
		out << "\tcase " << i+1 << ":\n";
		
		/* Loop over the function list to the start of the next glob. */
		int *funcs = transFuncs + machine->transFuncIndex[i];

		/* First is the length. */
		int numFuncs = *funcs++;
		while ( numFuncs-- > 0 ) {
			/* Get the function data. */
			FuncListEl *flel = parseData->funcIndex[*funcs];

			/* Write the preprocessor line info for going into the 
			 * source file. */
			out << "# " << flel->loc.line << " \"" << inputFile << "\"\n";

			/* Wrap the block in brakets. */
			out << "\t{" << flel->data << "}\n";
			funcs += 1;
		}
		out << "\tbreak;\n";
	}

	/* Write the directive for going back into the output file. The line
	 * number is for the next line, so add one. */
	out << "# " << outFilter->line + 1 << " \"" << outputFile << "\"\n";
	return out;
}

std::ostream &FTabCodeGen::TRANSITIONS( int *statePos )
{
	/* Initial indentation. */
	out << '\t';
	FsmMachTrans *trans = machine->allTrans;
	for ( int i = 0; i < machine->numTrans; i++, trans++ ) {
		if ( trans->toState == STATE_ERR_STATE )
			out << "{0, ";
		else
			out << "{s+" << statePos[trans->toState] << ", ";

		/* Write the function for the state. Close transition. */
		if ( trans->funcs == FUNC_NO_FUNC )
			out << "0";
		else
			out << trans->funcs+1;
		out << "}";

		/* If not on the last transition, output a command 
		 * and possibly a line break. */
		if ( i < machine->numTrans-1 ) {
			out << ", ";

			/* Put in a break every 4, but only if not the last. */
			if ( i % TALL == TALL-1 )
				out << "\n\t";
		}
	}
	return out;
}

std::ostream &FTabCodeGen::LOCATE_TRANS()
{
	out <<
		"	/* Get required data. */\n"
		"	specs = *cs++;\n"
		"	keys = k + *cs++;\n"
		"	inds = i + *cs++;\n"
		"\n"
		"	/* Try flat index. */\n"
		"	if ( specs & SPEC_ANY_FLAT ) {\n"
		"		int indsLen = *cs++;\n"
		"		keys += 2;\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try binary search single. */\n"
		"	if ( specs & SPEC_ANY_SINGLE ) {\n"
		"		/* Try to find the key. */\n"
		"		int indsLen = *cs++;\n"
		"		"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
					"BSearch( *p, keys, indsLen );\n"
		"\n"
		"		if ( match != 0 ) {\n"
		"			trans = t + inds[match - keys];\n"
		"			goto match;\n"
		"		}\n"
		"\n"
		"		/* Advance over the keys and indicies. */\n"
		"		keys += indsLen;\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try binary search range. */\n"
		"	if ( specs & SPEC_ANY_RANGE ) {\n"
		"		/* Try to find the key. */\n"
		"		int indsLen = *cs++;\n"
		"		"; ALPH_TYPE() << " *match = "; FSM_NAME() << 
					"RangeBSearch( *p, keys, (indsLen<<1) );\n"
		"\n"
		"		if ( match != 0 ) {\n"
		"			trans = t + inds[(match - keys)>>1];\n"
		"			goto match;\n"
		"		}\n"
		"\n"
		"		/* Advance over the keys and indicies. */\n"
		"		keys += (indsLen<<1);\n"
		"		inds += indsLen;\n"
		"	}\n"
		"\n"
		"	/* Try the default transition. */\n"
		"	if ( specs & SPEC_ANY_DEF ) {\n"
		"		trans = t + *inds;\n"
		"		goto match;\n"
		"	}\n";

	return out;
}



/* Init base class. */
CFTabCodeGen::CFTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FTabCodeGen(fsmName, parseData, machine, out)
{ }

void CFTabCodeGen::writeOutHeader()
{
	out <<
		"/* Forward dec state for the transition structure. */\n"
		"struct "; FSM_NAME() << "StateStruct;\n"
		"\n"
		"/* A single transition. */\n"
		"struct "; FSM_NAME() << "TransStruct\n"
		"{\n"
		"	int *toState;\n"
		"	int funcs;\n"
		"};\n"
		"typedef struct "; FSM_NAME() << "TransStruct "; FSM_NAME() << "Trans;\n"
		"\n"
		"/* Only non-static data: current state. */\n"
		"struct "; FSM_NAME() << "Struct\n"
		"{\n"
		"	int *curState;\n"
		"	int accept;\n";
		STRUCT_DATA() <<
		"};\n"
		"typedef struct "; FSM_NAME() << "Struct "; FSM_NAME() << ";\n"
		"\n"
		"/* Init the fsm. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Execute some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() << 
				" *data, int dlen );\n"
		"\n"
		"/* Indicate to the fsm tha there is no more data. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm );\n"
		"\n"
		"/* Did the machine accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm );\n"
		"\n";
}

void CFTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"void "; FSM_NAME() << "Init( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	fsm->curState = "; FSM_NAME() << "_start;\n"
		"	fsm->accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n";

	/* Accept routine. */
	out <<
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "Accept( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	return fsm->accept;\n"
		"}\n"
		"\n";

	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "Execute( "; FSM_NAME() << " *fsm, "; ALPH_TYPE() <<
				" *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"	int *cs = fsm->curState;\n"
		"	int specs";

	if ( anyTransFuncs() ) 
		out << ", funcs";

	out <<
		";\n"
		"	"; ALPH_TYPE() << " *keys;\n"
		"	"; INDEX_TYPE() << " *inds;\n"
		"	"; FSM_NAME() << "Trans *trans;\n"
		"\n"
		"	if ( data == 0 )\n"
		"		goto finishInput;\n"
		"\n"
		"again:\n"
		"	if ( cs == 0 || len == 0 )\n"
		"		goto out;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"	/* No match. */\n"
		"	cs = 0;\n"
		"	goto out;\n"
		"\n"
		"match:\n"
		"	/* Move to the new state. */\n"
		"	cs = trans->toState;\n"
		"\n";

	if ( anyTransFuncs() ) {
		out << 
			"	/* Check for functions. */\n"
			"	if ( (funcs=trans->funcs) == 0 )\n"
			"		goto noFuncs;\n"
			"\n"
			"execFuncs:\n"
			"	switch ( funcs ) {\n";
			FUNC_SWITCH() <<
			"	}\n"
			"\n"
			"noFuncs:\n";
	}

	out <<
		"	p++, len--;\n"
		"	goto again;\n"
		"\n"
		"finishInput:\n"
		"	if ( cs != 0 && *cs & SPEC_IS_FINAL ) {\n"
		"		/* The machine accepts. */\n"
		"		fsm->accept = 1;\n";

	/* If there are any functions, then jump to the func execution. */
	if ( anyTransFuncs() ) {
		out <<
			"		/* If finishing in a final state then execute the\n"
			"		 * out functions for it. (if any). */\n"
			"		if ( *cs & SPEC_OUT_FUNC ) {\n"
			"			funcs = *(cs + (*cs>>8)-1);\n"
			"			len = 1;\n"
			"			goto execFuncs;\n"
			"		}\n";
	}

	out << 
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		fsm->curState = 0;\n"
		"	}\n"
		"\n"
		"out:\n"
		"	fsm->curState = cs;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "Finish( "; FSM_NAME() << " *fsm )\n"
		"{\n"
		"	"; FSM_NAME() << "Execute( fsm, 0, 0 );\n"
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}


/* Init base data. */
CCFTabCodeGen::CCFTabCodeGen( char *fsmName, ParseData *parseData, 
		FsmMachine *machine, std::ostream &out )
:
	FTabCodeGen(fsmName, parseData, machine, out) 
{ }

void CCFTabCodeGen::writeOutHeader()
{
	out <<
		"class "; FSM_NAME() << "\n"
		"{\n"
		"public:\n"
		"	/* A single transition. */\n"
		"	struct Trans\n"
		"	{\n"
		"		int *toState;\n"
		"		int funcs;\n"
		"	};\n"
		"\n"
		"	/* Constructor. */\n"
		"	"; FSM_NAME() << "();\n"
		"\n"
		"	void Init( );\n"
		"\n"
		"	/* Execute some chunk of data. */\n"
		"	void Execute( "; ALPH_TYPE() << " *data, int dlen );\n"
		"\n"
		"	/* Indicate to the fsm tha there is no more data. */\n"
		"	void Finish( );\n"
		"\n"
		"	/* Did the machine accept? */\n"
		"	int Accept( );\n"
		"\n"
		"	int *curState;\n"
		"	int accept;\n";
		STRUCT_DATA() <<
		"};\n"
		"\n";
}

void CCFTabCodeGen::writeOutCode()
{
	/* Need the state positions. */
	int *statePos = newStatePosArray();
	
	/* State machine data. */
	out << 
		"#define s "; FSM_NAME() << "_s\n"
		"#define k "; FSM_NAME() << "_k\n"
		"#define i "; FSM_NAME() << "_i\n"
		"#define t "; FSM_NAME() << "_t\n"
		"\n"
		"#define SPEC_ANY_FLAT    0x01\n"
		"#define SPEC_ANY_SINGLE  0x02\n"
		"#define SPEC_ANY_RANGE   0x04\n"
		"#define SPEC_ANY_DEF     0x08\n"
		"#define SPEC_IS_FINAL    0x10\n"
		"#define SPEC_OUT_FUNC    0x20\n"
		"\n";

	/* Write the array of keys. */
	out <<
		"/* The array of keys of transitions. */\n"
		"static "; ALPH_TYPE() << " "; FSM_NAME() << "_k[] = {\n";
		KEYS() << "\n"
		"};\n"
		"\n";

	/* Write the array of indicies. */
	out << 
		"/* The array of indicies into the transition array. */\n"
		"static "; INDEX_TYPE() << " "; FSM_NAME() << "_i[] = {\n";
		INDICIES() << "\n"
		"};\n"
		"\n";

	/* Write the array of states. */
	out <<
		"/* The aray of states. */\n"
		"static int "; FSM_NAME() << "_s[] = {\n";
		STATES() << "\n"
		"};\n"
		"\n"
		"/* The array of trainsitions. */\n"
		"static "; FSM_NAME() << "::Trans "; FSM_NAME() << "_t[] = {\n";
		TRANSITIONS( statePos ) << "\n"
		"};\n"
		"\n"
		"/* The start state. */\n"
		"static int *"; FSM_NAME() << "_start = s+" 
				<< statePos[machine->startState] << ";\n"
		"\n";

	/* Constructor. */
	out <<
		"/* Make sure the machine is initted. */\n";
		FSM_NAME() << "::"; FSM_NAME() << "()\n"
		"{\n"
		"	Init();\n"
		"}\n"
		"\n";

	/* Init routine. */
	out << 
		"/* Init the fsm to a runnable state. */\n"
		"void "; FSM_NAME() << "::Init( )\n"
		"{\n"
		"	this->curState = "; FSM_NAME() << "_start;\n"
		"	this->accept = 0;\n";
		INIT_CODE() <<
		"}\n"
		"\n";

	/* Accept routine. */
	out <<
		"/* Did the fsm accept? */\n"
		"int "; FSM_NAME() << "::Accept( )\n"
		"{\n"
		"	return this->accept;\n"
		"}\n"
		"\n";


	/* The binary search. */
	BSEARCH() << "\n";

	/* The binary search for a range. */
	RANGE_BSEARCH() << "\n";

	/* Execution function. */
	out << 
		"/* Execute the fsm on some chunk of data. */\n"
		"void "; FSM_NAME() << "::Execute( "; ALPH_TYPE() << " *data, int dlen )\n"
		"{\n"
		"	"; ALPH_TYPE() << " *p = data;\n"
		"	int len = dlen;\n"
		"	int *cs = this->curState;\n"
		"	int specs";
	
	if ( anyTransFuncs() ) 
		out << ", funcs";

	out <<
		";\n"
		"	"; ALPH_TYPE() << " *keys;\n"
		"	"; INDEX_TYPE() << " *inds;\n"
		"	"; FSM_NAME() << "::Trans *trans;\n"
		"\n"
		"	if ( data == 0 )\n"
		"		goto finishInput;\n"
		"\n"
		"again:\n"
		"	if ( cs == 0 || len == 0 )\n"
		"		goto out;\n"
		"\n";
		LOCATE_TRANS() <<
		"\n"
		"	/* No match. */\n"
		"	cs = 0;\n"
		"	goto out;\n"
		"\n"
		"match:\n"
		"	/* Move to the new state. */\n"
		"	cs = trans->toState;\n"
		"\n";

	if ( anyTransFuncs() ) {
		out << 
			"	/* Check for functions. */\n"
			"	if ( (funcs=trans->funcs) == 0 )\n"
			"		goto noFuncs;\n"
			"\n"
			"execFuncs:\n"
			"	switch ( funcs ) {\n";
			FUNC_SWITCH() <<
			"	}\n"
			"\n"
			"noFuncs:\n";
	}

	out <<
		"	p++, len--;\n"
		"	goto again;\n"
		"\n"
		"finishInput:\n"
		"	if ( cs != 0 && *cs & SPEC_IS_FINAL ) {\n"
		"		/* The machine accepts. */\n"
		"		this->accept = 1;\n";

	/* If there are any functions, then jump to the func execution. */
	if ( anyTransFuncs() ) {
		out << 
			"		/* If finishing in a final state then execute the\n"
			"		 * out functions for it. (if any). */\n"
			"		if ( *cs & SPEC_OUT_FUNC ) {\n"
			"			funcs = *(cs + (*cs>>8)-1);\n"
			"			len = 1;\n"
			"			goto execFuncs;\n"
			"		}\n";
	}

	out <<
		"	}\n"
		"	else {\n"
		"		/* If we are not in a final state then this\n"
		"		 * is an error. Move to the error state. */\n"
		"		this->curState = 0;\n"
		"	}\n"
		"out:\n"
		"	this->curState = cs;\n"
		"}\n"
		"\n";

	/* Finish routine. */
	out <<
		"/* Indicate to the fsm that the input is done. Does cleanup tasks. */\n"
		"void "; FSM_NAME() << "::Finish( )\n"
		"{\n"
		"	Execute( 0, 0 );\n"
		"}\n"
		"\n";

	/* Cleanup after ourselves. */
	out <<
		"#undef s\n"
		"#undef k\n"
		"#undef i\n"
		"#undef t\n"
		"#undef SPEC_ANY_FLAT\n"
		"#undef SPEC_ANY_SINGLE\n"
		"#undef SPEC_ANY_RANGE\n"
		"#undef SPEC_ANY_DEF\n"
		"#undef SPEC_IS_FINAL\n"
		"#undef SPEC_OUT_FUNC\n"
		"\n";

	/* Finished with this. */
	delete[] statePos;
}

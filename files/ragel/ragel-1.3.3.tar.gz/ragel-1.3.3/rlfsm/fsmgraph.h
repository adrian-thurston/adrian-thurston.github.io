/*
 *  Copyright 2001, 2002 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Reglang FSM.
 *
 *  Reglang FSM is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Reglang FSM is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Reglang FSM; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _RLFSM_FSMGRAPH_H
#define _RLFSM_FSMGRAPH_H

#include <assert.h>
#include "vector.h"
#include "bstset.h"
#include "compare.h"
#include "avltree.h"
#include "dlist.h"
#include "bstmap.h"

/* Flags that control merging. */
#define SB_KILLOTHERS 0x01
#define SB_WANTOTHER1 0x02
#define SB_WANTOTHER2 0x04
#define SB_WANTOTHER  0x06

struct FsmMachState;

/* Differnt types of keys that transitions can be attached on. */
enum FsmKeyType {
	KeyTypeSingle,
	KeyTypeRange,
	KeyTypeDefault
};

/* This is the marked index for a state pair. Used in minimization. It keeps
 * track of whether or not the state pair is marked. */
template <class State> struct MarkIndex
{
	MarkIndex(int states);
	~MarkIndex();

	void markPair(int state1, int state2);
	bool isPairMarked(int state1, int state2);

private:
	int numStates;
	bool *array;
};

/* Compare of a whole Func table element (key & value). */
struct TransFuncElCmp
{
	static int compare( const BstMapEl<int, int> &func1, 
			const BstMapEl<int, int> &func2 )
	{
		int compareRes = CmpOrd<int>::compare( func1.key, func2.key );
		if ( compareRes != 0 )
			return compareRes;
		return CmpOrd<int>::compare( func1.value, func2.value );
	}
};

/* A single transition for an fsm. */
template < class State, class Transition > struct FsmTrans
{
	FsmTrans( ) : fromState(0), toState(0), priority(0) {}

	Transition *next, *prev;
	State *fromState;
	State *toState;
	int lowerKey;

	/* Transistion Func Element and the table. */
	typedef BstMapEl< int, int > TransFuncEl;
	typedef BstMap< int, int, CmpOrd<int> > TransFuncTable;

	/* Compare of a TransFuncTable. */
	typedef CmpTable< TransFuncEl, TransFuncElCmp > TransFuncTableCompare;

	/* Plain Func list that imposes no ordering. */
	typedef Vector<int> TransFuncList;

	/* Comparison for TransFuncList. */
	typedef CmpTable< int, CmpOrd<int> > TransFuncListCompare;

	/* The function table and priority for the transition. */
	TransFuncTable transFuncTable;
	int priority;

	/* Compare function tables. */
	static inline int compareFuncs( const TransFuncTable &funcs1,
			const TransFuncTable &funcs2 );

	/* Compare priority and function table of transitions. */
	static inline int compareTransDataOBS( FsmTrans *trans1, FsmTrans *trans2 );

	/* Compare priority and function table of transitions. Either of the
	 * pointers may be null. */
	static inline int compareDataPtr( FsmTrans *trans1, FsmTrans *trans2 );

	/* Compare target, priority and function table of transitions. Either
	 * pointer may be null. */
	static inline int compareFullPtr( FsmTrans *trans1, FsmTrans *trans2 );

	/* Compare target partitions. Either pointer may be null. */
	static inline int comparePartPtr( FsmTrans *trans1, FsmTrans *trans2 );

	/* Check marked status of target states. Either pointer may be null. */
	static inline bool shouldMarkPtr( MarkIndex<State> &markIndex, 
			FsmTrans *trans1, FsmTrans *trans2 );

	/* Set functions on the transition. */
	void setFunction( int func, int transOrder );
	void setFunctions( TransFuncTable &funcTable );

	/*
	 * User callbacks
	 */
	void addInTrans( Transition *srcTrans );
	void addInOutState( State *srcState );
	static inline int comparePrior( FsmTrans *trans1, FsmTrans *trans2 );
};


/* A node in a state dict. */
template<class State> struct FsmSDNode :
		public AvlNode< FsmSDNode<State> >,
		public CmpTable< State*, CmpOrd<State*> >
{
	typedef BstSet< State*, CmpOrd<State*> > StateSet;

	FsmSDNode(const StateSet &stateSet) : stateSet(stateSet) { }

	const StateSet &getKey() { return stateSet; }
	StateSet stateSet;
	State *targState;
};

/* Data needed for a merge operation. */
template < class State > struct FsmMergeData
{
	FsmMergeData() 
		: stfillHead(0), stfillTail(0) { }

	typedef BstSet< State*, CmpOrd<State*> > StateSet;
	typedef AvlTree<FsmSDNode<State>, StateSet> StateDict;
	typedef DList<State> StateList;

	StateDict stateDict;

	State *stfillHead;
	State *stfillTail;

	void fillListAppend( State *state );
};

/* Extend binary search map with functions useful for ranges. */
template < class Transition > struct FsmTransList :
		BstMap< int, Transition*, CmpOrd<int> >
{
	typedef BstMapEl< int, Transition* > TransEl;

	/* Given a transition key, find the range the key is in. */
	TransEl *findRange( int onChar ) const;
	TransEl *findLower( int onChar ) const;
};

template < class State > struct MinPartition 
		: public DListEl< MinPartition<State> >
{
	MinPartition() : active(false) { }

	DList<State> list;
	bool active;
};


/* A single state for an fsm. */
template < class State, class Transition > 
		struct FsmState : public DListEl<State>
{
	FsmState();
	FsmState(const FsmState &other);
	~FsmState();

	/* Transition lists element and the table. */
	typedef FsmTransList<Transition> TransListType;
	typedef BstMapEl< int, Transition* > TransEl;

	/* Transistion func element and the table. */
	typedef BstMapEl< int, int > TransFuncEl;
	typedef BstMap< int, int, CmpOrd<int> > TransFuncTable;

	/* Set of entry ids that go into this state. */
	typedef BstSet< int, CmpOrd<int> > EntryIdEl;
	typedef BstSet< int, CmpOrd<int> > EntryIdSet;

	/* Out transition lists and the pointer for the default out trans. */
	TransListType outList;
	TransListType outRange;
	Transition *outDefault;

	/* Pointers for the lists of in transitions. */
	Transition *inListHead, *inRangeHead, *inDefHead;

	/* What entry points in this state? */
	EntryIdSet entryIds;

	/* Identification for printing. */
	int num;

	/* Number of in transitions from states other than ourselves. */
	int foreignInTrans, foreignOutTrans;

	/* Temporary data for various algorithms. */
	union {
		/* When duplicating the fsm we need to map each 
		 * state to the new state representing it. */
		State *stateMap;

		/* When building the runnable machine, this maps graph states to
		 * machine states representing it. */
		FsmMachState *machState;

		/* When minimizing machines, this maps the group the state is in. */
		MinPartition<State> *partition;

		/* When merging states (state machine operations) this next pointer is
		 * used for the list of states that need to be filled in. */
		State *next;
	} alg;

	/* Is the state a final state? */
	bool isFinState;

	/* Is the state Marked during the MarkReachableFromHere process. */
	bool isMarked;

	/* Is the out priority set? If so then it can be transfered to out
	 * transistions. Otherwise ignore it. */
	bool isOutPriorSet;

	/* Bits controlling the behaviour of the state during collapsing to dfa. */
	int stateBits;

	/* Transition data to add to any transition leaving an fsm via this state. */
	int outPriority;
	TransFuncTable outTransFuncTable;

	/* StateSet, FsmSDNode */
	typedef BstSet< State*, CmpOrd<State*> > StateSet;
	typedef AvlTree<FsmSDNode<State>, StateSet> StateDict;

	/* A pointer to a dict node that contains the set of states
	 * this state represents. */
	FsmSDNode<State> *stateDictNode;

	/*
	 * Callbacks.
	 */
	void fuseInState( State *otherState );
	void addInState( State *otherState );
	void relinquishFinal( );

	static int compareOutTrans( const FsmState &state1, 
			const FsmState &state2 );
	void setOutFunctions( TransFuncTable &funcTable );
};

/* Iterator for a state's out transitions.  Objects being iterated over come
 * from 3 sources: out transitions, out ranges and the default transitions.
 * Pointers in those segments may be null. */
template < class State, class Transition > struct FsmOutIterator
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IteratorState {
		Begin,
		Trans,
		Range,
		Default,
		End
	};

	FsmOutIterator( State *state );

	/* Query iterator. */
	bool atEnd();
	Transition *operator++(int);
	Transition *operator++();

	/* Transistion list element. */
	typedef BstMapEl< int, Transition* > TransEl;

	/* The trans pointer available outside this class. */
	Transition *trans;

	/* Loop variables. */
	TransEl *transEl;
	int nTransEl, i;

	/* Iterator state. */
	State *state;
	IteratorState itState;

private:
	void findNext();
};

/* Iterator for a state's in transitions. This iterator does not adhere to
 * Aapl's standard iterator interface due to the exceptional requirements.
 * Objects being iterated over come from 3 sources: in transitions, in
 * ranges and the default transitions. These points are lists of transitions. */
template < class State, class Transition > struct FsmInIterator
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IteratorState {
		Begin,
		Trans,
		Range,
		Default,
		End
	};

	FsmInIterator( State *state );

	/* Query iterator. */
	bool atEnd();
	Transition *operator++(int);
	Transition *operator++();

	/* Transistion list element. */
	typedef BstMapEl< int, Transition* > TransEl;

	/* The trans pointer available outside this class. */
	Transition *trans;

	/* Iterator state. */
	State *state;
	IteratorState itState;

private:
	void findNext();
};

template < class State, class Transition > struct FsmPairIterator
{
	/** Encodes the different states that an fsm iterator can be in. */
	enum IteratorState {
		Begin,
		ConsumeS1Trans, ConsumeS2Trans,
		OnlyInS1Trans,  OnlyInS2Trans,
		InBothTrans,
		ConsumeS1Range, ConsumeS2Range,
		OnlyInS1Range,  OnlyInS2Range,
		S1SticksOut,    S1SticksOutBreak,
		S2SticksOut,    S2SticksOutBreak,
		S1DragsBehind,  S1DragsBehindBreak,
		S2DragsBehind,  S2DragsBehindBreak,
		ExactOverlap,   End
	};

	/** Encodes the different states that are meaningful to the user. */
	enum UserState {
		TransInS1,  TransInS2,
		TransOverlap,
		RangeInS1,  RangeInS2,
		RangeOverlap,
		BreakS1,    BreakS2
	};

	FsmPairIterator( const State *state1, const State *state2, bool wantBreaks );

	/* Query iterator. */
	bool atEnd();
	void operator++(int) { findNext(); }
	void operator++()    { findNext(); }

	typedef BstMapEl< int, Transition* > TransEl;

	/* Iterator state. */
	const State *state1;
	const State *state2;
	IteratorState itState;
	UserState userState;


	TransEl *s1Tel, *s1EndTel;
	TransEl *s2Tel, *s2EndTel;
	TransEl *s1Range, *s2Range;
	int savedKey;
	Transition *savedTrans;
	TransEl s1HeadTel[2], s2HeadTel[2];
	TransEl s1NextTel[2], s2NextTel[2];
	Transition *defTrans;

	bool wantBreaks;

private:
	void findNext();
};

/* Compare class for the Approximate minimization. */
template < class State, class Transition > class ApproxCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;

public:
	static int compare( const State *pState1, const State *pState2 );
};

/* Compare class for the initial partitioning of a partition minimization. */
template < class State, class Transition > class InitPartitionCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;
public:
	static int compare( const State *pState1, const State *pState2 );
};

/* Compare class for the regular partitioning of a partition minimization. */
template < class State, class Transition > class PartitionCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;
public:
	static int compare( const State *pState1, const State *pState2 );
};

/* Compare class for a minimization that marks pairs. Provides the shouldMark
 * routine. */
template < class State, class Transition > class MarkCompare
{
	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;
public:
	static bool shouldMark( MarkIndex<State> &markIndex, const State *pState1, 
			const State *pState2 );
};

/* Contains all the fsm operators, nfa to dfa conversion and minimization
 * algorithms. */
template < class State, class Transition > struct FsmGraph
{
public:
	/* Constructor/Destructor. */
	FsmGraph() 
		: misfitAccounting(false) {}
	FsmGraph(const FsmGraph &graph);
	~FsmGraph();

	/* Transistion Func Element and the table. */
	typedef BstMapEl< int, int > TransFuncEl;
	typedef BstMap< int, int, CmpOrd<int> > TransFuncTable;
	
	/**
	 * StateSet, StateDict
	 */
	typedef BstSet< State*, CmpOrd<State*> > StateSet;
	typedef AvlTree< FsmSDNode<State>, StateSet > StateDict;

	/* The list of states. */
	typedef DListEl< State > ListEl;
	typedef DList< State > StateList;

	/* List of transtions out of a state. */
	typedef FsmTransList<Transition> TransListType;
	typedef BstMapEl<int, Transition*> TransEl;
	typedef Vector< BstMapEl<int, Transition*> > TransListVect;

	/* Entry point map used for keeping track of entry points in a machine. */
	typedef BstMapEl< int, State* > EntryEl;
	typedef BstMap< int, State*, CmpOrd<int> > EntryMap;

	/* Data required on a merge. */
	typedef FsmMergeData<State> MergeData;

	/* Iterator Type */
	typedef FsmPairIterator<State, Transition> PairIterator;

	/* The list of states. */
	DList<State> stateList;
	DList<State> misfitList;

	/* The map of entry points. */
	EntryMap entryPoints;

	/* The set of final states. */
	StateSet finStateSet;

	/* Misfit Accounting. Are misfits put on a separate list. */
	bool misfitAccounting;
	void setMisfitAccounting( bool val ) 
		{ misfitAccounting = val; }

	/* Set and Unset a state as final. */
	void setFinState( State *state );
	void unsetFinState( State *state );

	/* Set and unset a state as an entry point. */
	void setEntry( int id, State *state );
	void unsetEntry( int id );
	void changeEntry( int id, State *state );
	State *findEntry( int id ) const;

	/* Determine if there are any entry points into a start state other than
	 * the start state. */
	bool isStartStateIsolated();

	/* Make a new start state that has no entry points. Will not change the
	 * identity of the fsm. */
	void isolateStartState( );

	/*
	 * Transition functions and priorities.
	 */

	/* Set priorities on transtions. */
	void startFsmPrior( int prior );
	void allTransPrior( int prior );
	void finFsmPrior( int prior );
	void leaveFsmPrior( int prior );

	/* Set functions to execute. */
	void startFsmFunc( int func, int transOrder );
	void allTransFunc( int func, int transOrder );
	void finFsmFunc( int func, int transOrder );
	void leaveFsmFunc( int func, int transOrder );

	/* Shift the function ordering of the start transitions to start
	 * at fromOrder and increase in units of 1. Useful before staring. */
	int shiftStartFuncOrder( int fromOrder );

	/* Clear functions from transitions. */
	void clearStartFsmFunc();
	void clearAllTransFunc();
	void clearFinFsmFunc();
	void clearLeaveFsmFunc();

	/* Clear the leave fsm priority settings from the fsm. */
	void clearLeaveFsmPrior();

	/* Remove all transition data. Remove funcs and outfuncs, zero priorities
	 * and remove out priorities. */
	void clearAllTransData();

	/* Zero out all the function keys. */
	void nullFunctionKeys();

	/*
	 * Basic attaching and detaching.
	 */

	/* Common to attaching/detaching list and default. */
	void attachTrans(State *from, State *to, Transition *&head, Transition *trans);
	void detachTrans(State *from, State *to, Transition *&head, Transition *trans);

	/* Attach/Detach for out/in lists or for default transition. */
	Transition *attachStates( State *from, State *to, FsmKeyType keyType, 
			int onChar1, int onChar2 );
	void attachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, int onChar );
	void detachStates( State *from, State *to, Transition *trans, 
			FsmKeyType keyType, int onChar );

	/* When a range is split the lower key changes, this fixes it. */
	void changeRangeLowerKey( Transition *trans, int oldKey, int newKey );

	/* Detach a state from the graph. */
	void detachState( State *state );

	/*
	 * NFA to DFA conversion routines.
	 */

	/* Duplicate a transition that will dropin to a free spot. */
	Transition *dupTrans( State *from, FsmKeyType keyType, int onChar,
			Transition *srcTrans, bool leavingFsm );

	/* In crossing, src trans overwrites the existing one because it has a
	 * higher priority. */
	Transition *overwriteTrans( MergeData &md, State *from, FsmKeyType keyType, 
			int onChar, Transition *destTrans, Transition *srcTrans, bool leavingFsm );

	/* In crossing, src trans and dest trans are merged. */
	Transition *fsmAttachStates( MergeData &md, State *from, FsmKeyType keyType,
			int onChar, Transition *destTrans, Transition *srcTrans, bool leavingFsm );

	/* Cross a src transition with one that is already occupying a spot. */
	Transition *crossTransitions( MergeData &md, State *from, FsmKeyType keyType, 
			int onChar, Transition *destTrans, Transition *srcTrans,
			bool leavingFsm );

	/* Common to copying transition lists and ranges. */
	Transition *keyInDestEl( MergeData &md, State *dest, State *src, TransEl *destTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm );
	Transition *keyInSrcEl( MergeData &md, State *dest, State *src, TransEl *srcTel, 
			FsmKeyType keyType, Transition *defTrans, bool leavingFsm );
	Transition *keyInBothEl( MergeData &md, State *dest, State *src, TransEl *destTel,
			TransEl *srcTel, FsmKeyType keyType, bool leavingFsm );

	/* Copy the default transition. */
	void copyDefTrans( MergeData &md, State *dest, State *src, bool leavingFsm );

	/* Copy the out transitions from src to dest. */
	void outTransCopy( MergeData &md, State *dest, State *src, bool leavingFsm );

	/* Merge a set of states into newState. */
	void mergeStates( MergeData &md, State *newState, StateSet &stateSet, 
			bool leavingFsm );

	/* Make all states that are combinations of other states and that
	 * have not yet had their out transitions filled in. This will 
	 * empty out stateDict and stFil. */
	void fillInStates( MergeData &md );

	/*
	 * Various.
	 */

	/* New up a state and add it to the graph. */
	State *newState();

	/* Build basic fsms. */
	static FsmGraph *concatFsm( char *str, int len );
	static FsmGraph *concatFsm( int *str, int len );
	static FsmGraph *concatFsm( int chr );
	static FsmGraph *orFsm( char *set, int len );
	static FsmGraph *orFsm( int *set, int len );
	static FsmGraph *nullFsm( );
	static FsmGraph *dotFsm();
	static FsmGraph *dotStarFsm();
	static FsmGraph *rangeFsm( int low, int high );

	/* Fsm Operators. */
	void starOp( bool leavingFsm );
	void concatOp( FsmGraph *other, bool leavingFsm );
	void orOp( FsmGraph *other );
	void intersectOp( FsmGraph *other );
	void subtractOp( FsmGraph *other );

	/* Underlying worker behind Or, Intersect and Subtract. */
	void doOr(FsmGraph *other);

	/* Unset any final states that are no longer to be final 
	 * due to final bits. */
	void unsetIncompleteFinals();

	/* Bring in other's entry points. Assumes others states are going to be
	 * copied into this machine. */
	void copyInEntryPoints( FsmGraph *other );

	/* Set State numbers starting at 0. */
	void setStateNumbers();

	/* Unset all final states. */
	void unsetAllFinStates();

	/* Set the bits of final states and clear the bits of non final states. */
	void setFinBits( int finStateBits );

	/* Assert that there are no out funcs/priorities on non final states. */
	void verifyStates();

	/* Run a sanity check on the machine. */
	void verifyIntegrity();

	/*
	 * Path pruning
	 */

	/* Mark all states reachable from state. */
	void markReachableFromHereReverse( State *state );

	/* Mark all states reachable from state. */
	void markReachableFromHere( State *state );

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void removeDeadEndStates();

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void removeUnreachableStates();

	/* Remove states that are on the misfit list. */
	void removeMisfits();

	/*
	 * FSM Minimization
	 */

	/* Minimization by partitioning. */
	void minimizePartition1();
	void minimizePartition2();

	/* Minimize the final state Machine. The result is the minimal fsm. Slow
	 * but stable, correct minimization. Uses n^2 space (lookout) and average
	 * n^2 time. Worst case n^3 time, but a that is a very rare case. */
	void minimizeStable();

	/* Minimize the final state machine. Does not find the minimal fsm, but a
	 * pretty good approximation. Does not use any extra space. Average n^2
	 * time. Worst case n^3 time, but a that is a very rare case. */
	void minimizeApproximate();

	/* This is the worker for the minimize approximate solution. It merges
	 * states that have identical out transitions. */
	bool minimizeRound( );

	/* Given an intial partioning of states, split partitions that have out trans
	 * to differing partitions. */
	int partitionRound( State **statePtrs, MinPartition<State> *parts, int numParts );

	/* Split partitions that have a transition to a previously split partition, until
	 * there are no more partitions to split. */
	int splitCandidates( State **statePtrs, MinPartition<State> *parts, int numParts );

	/* Fuse together states in the same partition. */
	void fusePartitions( MinPartition<State> *parts, int numParts );

	/* Mark pairs where out final stateness differs, out trans data differs,
	 * trans pairs go to a marked pair or trans data differs. Should get 
	 * alot of pairs. */
	void initialMarkRound( MarkIndex<State> &markIndex );

	/* One marking round on all state pairs. Considers if trans pairs go
	 * to a marked state only. Returns whether or not a pair was marked. */
	bool markRound( MarkIndex<State> &markIndex );

	/* Move the in trans into src into dest. */
	void inTransMove(State *dest, State *src);
	
	/* Make state src and dest the same state. */
	void fuseEquivStates(State *dest, State *src);

	/* Find any states that didn't get marked by the marking algorithm and
	 * merge them into the primary states of their equivalence class. */
	void fuseUnmarkedPairs( MarkIndex<State> &markIndex );
};

#endif /* _RLFSM_FSMGRAPH_H */

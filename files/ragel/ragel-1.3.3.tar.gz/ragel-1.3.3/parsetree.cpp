/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "parsetree.h"
#include "rl.h"

int curFuncOrdering = 0;

/* Initialize the graph dict with builtin types. */
void InitGraphDict( GraphDict *graphDict )
{
	/* All characters. */
	Fsm *any = Fsm::dotFsm();
	graphDict->insert( "any", new ExpressionNode(any) );

	/* Ascii extended characters. Once integer alphabets are fully supported
	 * this should change to the range 0-255 so that it does not span large
	 * alphabets. */
	Fsm *extend = Fsm::dotFsm();
	graphDict->insert( "extend", new ExpressionNode(extend) );

	/* Ascii characters 0 to 127. */
	Fsm *ascii = Fsm::rangeFsm( 0, 127 );
	graphDict->insert( "ascii", new ExpressionNode(ascii) );

	/* Alpha [A-Za-z]. */
	Fsm *alpha = Fsm::rangeFsm( 'A', 'Z' );
	alpha->orOp( Fsm::rangeFsm( 'a', 'z' ) );
	alpha->minimizePartition2();
	graphDict->insert( "alpha", new ExpressionNode(alpha) );

	/* Digits [0-9]. */
	Fsm *digit = Fsm::rangeFsm( '0', '9' );
	graphDict->insert( "digit", new ExpressionNode(digit) );

	/* Alpha numerics [0-9A-Za-z]. */
	Fsm *alnum = Fsm::rangeFsm( '0', '9' );
	alnum->orOp( Fsm::rangeFsm( 'A', 'Z' ) );
	alnum->orOp( Fsm::rangeFsm( 'a', 'z' ) );
	alnum->minimizePartition2();
	graphDict->insert( "alnum", new ExpressionNode(alnum) );

	/* Lower case characters. */
	Fsm *lower = Fsm::rangeFsm( 'a', 'z' );
	graphDict->insert( "lower", new ExpressionNode(lower) );

	/* Upper case characters. */
	Fsm *upper = Fsm::rangeFsm( 'A', 'Z' );
	graphDict->insert( "upper", new ExpressionNode(upper) );

	/* Control characters. */
	Fsm *cntrl = Fsm::rangeFsm( 0, 31 );
	cntrl->orOp( Fsm::concatFsm( 127 ) );
	cntrl->minimizePartition2();
	graphDict->insert( "cntrl", new ExpressionNode(cntrl) );

	/* Graphical ascii characters [!-~]. */
	Fsm *graph = Fsm::rangeFsm( '!', '~' );
	graphDict->insert( "graph", new ExpressionNode(graph) );

	/* Printable characters. Same as graph except includes space. */
	Fsm *print = Fsm::rangeFsm( ' ', '~' );
	graphDict->insert( "print", new ExpressionNode(print) );

	/* Punctuation. */
	Fsm *punct = Fsm::rangeFsm( '!', '/' );
	punct->orOp( Fsm::rangeFsm( ':', '@' ) );
	punct->orOp( Fsm::rangeFsm( '[', '`' ) );
	punct->orOp( Fsm::rangeFsm( '{', '~' ) );
	punct->minimizePartition2();
	graphDict->insert( "punct", new ExpressionNode(punct) );

	/* Whitespace: [\t\v\f\n\r ]. */
	Fsm *space = Fsm::rangeFsm( '\t', '\r' );
	space->orOp( Fsm::concatFsm( ' ' ) );
	space->minimizePartition2();
	graphDict->insert( "space", new ExpressionNode(space) );

	/* Hex digits [0-9A-Fa-f]. */
	Fsm *xdigit = Fsm::rangeFsm('0', '9');
	xdigit->orOp( Fsm::rangeFsm('A', 'F') );
	xdigit->orOp( Fsm::rangeFsm('a', 'f') );
	xdigit->minimizePartition2();
	graphDict->insert( "xdigit", new ExpressionNode(xdigit) );
}

/* Perform minimization after an operation according 
 * to the command line args. */
void afterOpMinimize( Fsm *fsm )
{
	/* Switch on the prefered minimization algorithm. */
	if ( minimizeEveryOp ) {
		if ( minimizeLevel != MinimizeNone ) {
			/* First clean up the graph. Fsm operations may leave these lying
			 * around.  There should be no dead end states however. The
			 * subtract intersection operators are the only places where they
			 * may be created and those operators clean them up. */
			fsm->removeUnreachableStates();
		}

		switch ( minimizeLevel ) {
			case MinimizeNone:
				break;
			case MinimizeApprox:
				fsm->minimizeApproximate();
				break;
			case MinimizePartition1:
				fsm->minimizePartition1();
				break;
			case MinimizePartition2:
				fsm->minimizePartition2();
				break;
			case MinimizeStable:
				fsm->minimizeStable();
				break;
		}
	}
}

ParseData::ParseData()
		: nextFuncNum(0), machineGiven(false)
{
	/* Initialize the dictionary of graphs.
	 * This is our symbol table. */
	InitGraphDict( &graphDict );
}

ParseData::~ParseData()
{
	/* Delete all the nodes in the function list. Will cause all the
	 * string data that represents the functions to be deallocated. */
	funcList.empty();
	dataList.empty();
	initCodeList.empty();
}

ExpressionNode::~ExpressionNode()
{
	switch ( type ) {
		case Or: case Intersect: case Subtract:
			delete expression;
			delete term;
			break;
		case Term:
			delete term;
			break;
		case Builtin:
			delete builtin;
			break;
	}
}

Fsm *ExpressionNode::Walk()
{
	Fsm *rtnVal = 0;
	switch ( type ) {
		case Or: {
			/* Evaluate the expression. */
			rtnVal = expression->Walk();
			/* Evaluate the term. */
			Fsm *rhs = term->Walk();
			/* Perform union. */
			rtnVal->orOp( rhs );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case Intersect: {
			/* Evaluate the expression. */
			rtnVal = expression->Walk();
			/* Evaluate the term. */
			Fsm *rhs = term->Walk();
			/* Perform intersection. */
			rtnVal->intersectOp( rhs );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case Subtract: {
			/* Evaluate the expression. */
			rtnVal = expression->Walk();
			/* Evaluate the term. */
			Fsm *rhs = term->Walk();
			/* Perform subtraction. */
			rtnVal->subtractOp( rhs );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case Term: {
			/* Return result of the term. */
			rtnVal = term->Walk();
			break;
		}
		case Builtin: {
			/* Duplicate the builtin. */
			rtnVal = new Fsm( *builtin );
			break;
		}
	}

	return rtnVal;
}

TermNode::~TermNode()
{
	switch ( type ) {
		case Concat:
			delete term;
			delete factorWithAug;
			break;
		case FactorWithAug:
			delete factorWithAug;
			break;
	}
}

Fsm *TermNode::Walk()
{
	Fsm *rtnVal = 0;
	switch ( type ) {
		case Concat: {
			/* Evaluate the Term. */
			rtnVal = term->Walk();
			/* Evaluate the FactorWithRep. */
			Fsm *rhs = factorWithAug->Walk();
			/* Perform concatenation. */
			rtnVal->concatOp( rhs, leavingFsm );
			/* Minimization. */
			afterOpMinimize( rtnVal );
			break;
		}
		case FactorWithAug: {
			rtnVal = factorWithAug->Walk();
			break;
		}
	}
	return rtnVal;
}

FactorWithAugNode::~FactorWithAugNode()
{
	delete factorWithRep;

	/* Walk the vector of parser funcs, deleting function names. */
}

Fsm *FactorWithAugNode::Walk()
{
	/* First walk the list of functions, assigning the
	 * starting function ordering. */
	ParserFunc *func = funcs.table;
	int i, nFuncs = funcs.tableLength;
	for ( i = 0; i < nFuncs; i++, func++ ) {
		if ( func->type == start )
			func->ordering = curFuncOrdering++;
	}

	/* Evaluate the factor with repetition. */
	Fsm *rtnVal = factorWithRep->Walk();

	/* Now compute the remaining function call orderings. */
	func = funcs.table;
	nFuncs = funcs.tableLength;
	for ( i = 0; i < nFuncs; i++, func++ ) {
		if ( func->type != start )
			func->ordering = curFuncOrdering++;
	}

	/* Assign functions. */
	func = funcs.table;
	nFuncs = funcs.tableLength;
	for ( i = 0; i < nFuncs; i++, func++ )  {
		if ( func->func == FUNC_NUM_CLEAR ) {
			switch ( func->type ) {
			case start:
				rtnVal->clearStartFsmFunc( );
				/* FIXME: I'm not sure if this is required, think about it. */
				afterOpMinimize( rtnVal );
				break;
			case all:
				rtnVal->clearAllTransFunc( );
				break;
			case fin:
				rtnVal->clearFinFsmFunc( );
				break;
			case leave:
				rtnVal->clearLeaveFsmFunc( );
				break;
			case clearLeave:
				assert(false);
			}
		}
		else {
			switch ( func->type ) {
			case start:
				rtnVal->startFsmFunc( func->func, func->ordering );
				/* Start fsm funcs are a special case that may require
				 * minimization afterwards. */
				afterOpMinimize( rtnVal );
				break;
			case all:
				rtnVal->allTransFunc( func->func, func->ordering );
				break;
			case fin:
				rtnVal->finFsmFunc( func->func, func->ordering );
				break;
			case leave:
				rtnVal->leaveFsmFunc( func->func, func->ordering );
				break;
			case clearLeave:
				assert(false);
			}
		}
	}

	/* Assign priorities. */
	PriorityAug *aug = priorityAugs.table;
	int nAugs = priorityAugs.tableLength;
	for ( i = 0; i < nAugs; i++, aug++ ) {
		switch ( aug->type ) {
			case start:
				rtnVal->startFsmPrior( aug->value );
				/* Start fsm priorities are a special case that may require
				 * minimization afterwards. */
				afterOpMinimize( rtnVal );
				break;
			case all:
				rtnVal->allTransPrior( aug->value );
				break;
			case fin:
				rtnVal->finFsmPrior( aug->value );
				break;
			case leave:
				rtnVal->leaveFsmPrior( aug->value );
				break;
			case clearLeave:
				rtnVal->clearLeaveFsmPrior();
				break;
		}
	}
	
	return rtnVal;
}

FactorWithRepNode::~FactorWithRepNode()
{
	switch ( type ) {
		case Star: case Optional: case Plus: case Negate:
			delete factorWithRep;
			break;
		case Factor:
			delete factor;
			break;
	}
}

Fsm *FactorWithRepNode::Walk()
{
	Fsm *rtnVal = 0;
	switch ( type ) {
		case Star: {
			/* Evaluate the FactorWithRep. */
			rtnVal = factorWithRep->Walk();
			/* Perform the kleen star. */
			if ( leavingFsm ) {
				curFuncOrdering +=
						rtnVal->shiftStartFuncOrder( curFuncOrdering );
			}
			rtnVal->starOp(leavingFsm);
			/* Minimization. */
			afterOpMinimize(rtnVal);
			break;
		}
		case Optional: {
			/* Evaluate the FactorWithRep. */
			rtnVal = factorWithRep->Walk();
			/* Perform the question operator. */
			rtnVal->orOp( Fsm::nullFsm() );
			/* Minimization. */
			afterOpMinimize(rtnVal);
			break;
		}
		case Plus: {
			/* Evaluate the FactorWithRep. */
			rtnVal = factorWithRep->Walk();
			/* Perform the plus operator. */
			Fsm *dup = new Fsm(*rtnVal);
			if ( leavingFsm ) {
				curFuncOrdering +=
						dup->shiftStartFuncOrder( curFuncOrdering );
			}
			dup->starOp(leavingFsm);
			/* Intermediate minimization. */
			afterOpMinimize(dup);
			rtnVal->concatOp(dup, leavingFsm);
			/* Minimization. */
			afterOpMinimize(rtnVal);
			break;
		}
		case Negate: {
			/* Evaluate the FactorWithRep. */
			Fsm *toNegate = factorWithRep->Walk();
			/* Negation is subtract from dot-star. */
			rtnVal = Fsm::dotStarFsm();
			rtnVal->subtractOp( toNegate );
			/* Minimization. */
			afterOpMinimize(rtnVal);
			break;
		}
		case Factor: {
			/* Evaluate the Factor. Pass it up. */
			rtnVal = factor->Walk();
			break;
		}
	}
	return rtnVal;
}

FactorNode::~FactorNode()
{
	switch ( type ) {
		case LiteralFsm:
			delete fsm;
			break;
		case LookupExpression:
			break;
		case Expression:
			delete expression;
			break;
		case Range:
			break;
	}
}

Fsm *FactorNode::Walk()
{
	Fsm *rtnVal = 0;
	switch ( type ) {
		case LiteralFsm:
			rtnVal = new Fsm(*fsm);
			break;
		case LookupExpression:
		case Expression:
			rtnVal = expression->Walk();
			break;
		case Range: {
			if ( upper < lower )
				rtnVal = Fsm::nullFsm();
			else
				rtnVal = Fsm::rangeFsm( lower, upper );
			
			break;
		}
	}
	return rtnVal;
}


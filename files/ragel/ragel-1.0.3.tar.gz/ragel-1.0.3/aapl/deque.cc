/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <string.h>
#include "deque.h"

/*******************************************************************************
 *                                Deque
 */
Deque::Deque(int chunkLength)
{
	ChunkLength = chunkLength;
	EndPos = FrontPos = DequeLength = 0;
	SpareChunk = 0;
}

Deque::~Deque()
{
	if ( SpareChunk )
		delete SpareChunk;
	SpareChunk = 0;
}

void Deque::Empty()
{
	/* if there is no spare chunk then try to keep one. */
	if ( SpareChunk == 0 && ListLength > 0 )
		SpareChunk = DequehunkList::DetachFront();

	DequehunkList::DeleteElements();
	EndPos = FrontPos = DequeLength = 0;
}

Dequehunk *Deque::NewChunk()
{
	Dequehunk *newChunk;

	if ( SpareChunk == 0 )
		newChunk = new Dequehunk( ChunkLength );
	else
	{
		newChunk = SpareChunk;
		SpareChunk = 0;
	}

	return newChunk;
}

void Deque::SpareAChunk( Dequehunk *chunk )
{
	if ( SpareChunk == 0 )
		SpareChunk = chunk;
	else
		delete chunk;
}

int Deque::SizeLeftChunk()
{
	int retVal;
	switch ( ListLength ) {
	case 0:
		retVal = 0;
		break;

	case 1:
		retVal = EndPos - FrontPos;
		break;

	default:
		retVal = ChunkLength - FrontPos;
		break;
	}
	return retVal;
}

int Deque::SizeRightChunk()
{
	int retVal;
	switch ( ListLength ) {
	case 0:
		retVal = 0;
		break;

	case 1:
		retVal = EndPos - FrontPos;
		break;

	default:
		retVal = EndPos;
		break;
	}
	return retVal;
}

byte *Deque::PtrLeftChunk()
{
	if ( ListLength == 0 )
		return 0;
	else
		return Head->Data + FrontPos;
}

byte *Deque::PtrRightChunk()
{
	if ( ListLength == 0 )
		return 0;
	else
		return Tail->Data;
}

void Deque::AppendLeft(void *data, int len)
{
	int lenAvail;

	/* Ensure we are trying to append something. */
	if ( len <= 0 || data == 0)
		return;

	/* We will never fail on this function (assuming we can
	 * allocate space for another chunk). */
	DequeLength += len;

	/* The source data. */
	byte *src = (byte*) data + len;

	/* What can we fit in the end chunk? */
	if ( ListLength == 0 )
	{
		lenAvail = 0;

		/* EndPos and FrontPos are currently Undefined. Set
		 * them here. */
		FrontPos = EndPos = ChunkLength;
	}
	else
		lenAvail = FrontPos;
	
	if (len <= lenAvail)
	{
		/* We can fit the rest of the source into the 
		 * current chunk. */
		memcpy(Head->Data + FrontPos - len, src - len, len);
		FrontPos -= len;
	}
	else
	{
		/* We need to stuff the source into more than one chunk.
		 * Max out the current chunk. */
		if (lenAvail > 0)
		{
			/* Fill the cur chunk. */
			memcpy( Head->Data, src - lenAvail, lenAvail );
			src -= lenAvail;
			len -= lenAvail;
		}
		
		/* Create a new chunk. */
		AddFront( NewChunk() );

		/* While we need all the space in this chunk and more. */
		while (len > ChunkLength)
		{
			/* Fill the cur chunk. */
			memcpy( Head->Data, src - ChunkLength, ChunkLength );
			src -= ChunkLength;
			len -= ChunkLength;
	
			/* Create a new chunk. */
			AddFront( NewChunk() );
		}

		/* We won't overflow this chunk. */
		memcpy(Head->Data + ChunkLength - len, src - len, len);
		FrontPos = ChunkLength - len;
	}

	return;
}

void Deque::AppendRight(void *data, int len)
{
	int lenAvail;

	/* Ensure we are trying to append something. */
	if ( len <= 0 || data == 0)
		return;

	/* We will never fail on this function (assuming we can
	 * allocate space for another chunk). */
	DequeLength += len;

	/* The source data. */
	byte *src = (byte*) data;

	/* What can we fit in the end chunk? */
	if ( ListLength == 0 )
	{
		lenAvail = 0;

		/* EndPos and FrontPos are currently Undefined. Set
		 * them here. */
		FrontPos = EndPos = 0;
	}
	else
		lenAvail = ChunkLength - EndPos;
	
	if (len <= lenAvail)
	{
		/* We can fit the rest of the source into the 
		 * current chunk. */
		memcpy(Tail->Data + EndPos, src, len);
		EndPos += len;
	}
	else
	{
		/* We need to stuff the source into more than one chunk.
		 * Max out the current chunk. */
		if (lenAvail > 0)
		{
			/* Fill the cur chunk. */
			memcpy(Tail->Data + EndPos, src, lenAvail);
			len -= lenAvail;
			src += lenAvail;
		}
		
		/* Create a new chunk. */
		AddEnd( NewChunk() );

		/* While we need all the space in this chunk and more. */
		while (len > ChunkLength)
		{
			/* Fill the cur chunk. */
			memcpy(Tail->Data, src, ChunkLength);
			len -= ChunkLength;
			src += ChunkLength;
	
			/* Create a new chunk. */
			AddEnd( NewChunk() );
		}

		/* We won't overflow this chunk. */
		memcpy(Tail->Data, src, len);
		EndPos = len;
	}

	return;
}

int Deque::PeekLeft(void *buffer, int len)
{
	Dequehunk *chunk;
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	byte *dst;          /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > DequeLength)
		len = DequeLength;

	/* Ensure we are trying to peek something. */
	if (len <= 0)
		return 0;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the first chunk.
	 * We assert that this value is always >= 1. */
	if ( ListLength == 1 )
		len_in_chunk = EndPos - FrontPos;
	else
		len_in_chunk = ChunkLength - FrontPos;

	/* If we only need data from the first chunk get it and return. */
	if (len <= len_in_chunk)
		memcpy(buffer, Head->Data + FrontPos, len);
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		chunk = Head;
		dst = (byte*) buffer;
		
		/* Copy what we can get from the first chunk. */
		memcpy(dst, chunk->Data + FrontPos, len_in_chunk);
		chunk = chunk->Next;
		dst += len_in_chunk;
		len -= len_in_chunk;

		/* While we want all the data and more from the head chunk. */
		while (len > ChunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst, chunk->Data, ChunkLength);
			chunk = chunk->Next;
			dst += ChunkLength;
			len -= ChunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst, chunk->Data, len);
	}

	return retVal;
}

int Deque::PeekRight(void *buffer, int len)
{
	Dequehunk *chunk;
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	byte *dst;          /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > DequeLength)
		len = DequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the last chunk.
	 * We assert that this value is always >= 1. */
	if ( ListLength == 1 )
		len_in_chunk = EndPos - FrontPos;
	else
		len_in_chunk = EndPos;

	/* If we only need data from the last chunk get it and return. */
	if (len <= len_in_chunk)
		memcpy(buffer, Tail->Data + EndPos - len, len);
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		chunk = Tail;
		dst = (byte*) buffer + len;
		
		/* Copy what we can get from the last chunk and toast it. */
		memcpy(dst - len_in_chunk, chunk->Data, len_in_chunk);
		chunk = chunk->Prev;
		dst -= len_in_chunk;
		len -= len_in_chunk;
		
		/* While we want all the data and more from the head chunk. */
		while (len > ChunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst - ChunkLength, chunk->Data, ChunkLength);
			chunk = chunk->Prev;
			dst -= ChunkLength;
			len -= ChunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst - len, chunk->Data + ChunkLength - len, len);
	}

	return retVal;
}


int Deque::KillLeft(int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */

	/* Restrict the len to the length of the fifo. */
	if (len > DequeLength)
		len = DequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	DequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the first chunk.
	 * We assert that this value is always >= 1. */
	if ( ListLength == 1 )
		len_in_chunk = EndPos - FrontPos;
	else
		len_in_chunk = ChunkLength - FrontPos;

	/* If we only need data from the first chunk get it and return. */
	if (len <= len_in_chunk)
		FrontPos += len;
	else 
	{
		/* We need to traverse at least two chunks.
		 */

		/* Kill what we can get from the first chunk and toast it. */
		len -= len_in_chunk;
		SpareAChunk( DetachElement(Head) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > ChunkLength )
		{
			/* Get the whole chunk. */
			len -= ChunkLength;
			SpareAChunk( DetachElement(Head) );
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		FrontPos = len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( DequeLength == 0 )
		SpareAChunk( DetachElement(Head) );
	/* If the fifo len not zero and there is no data in
	 * the front chunk then move to the next chunk. */
	else if ( FrontPos == ChunkLength )
	{
		SpareAChunk( DetachElement(Head) );
		FrontPos = 0;
	}

	return retVal;
}

int Deque::KillRight(int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */

	/* Restrict the len to the length of the fifo. */
	if (len > DequeLength)
		len = DequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	DequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the last chunk.
	 * We assert that this value is always >= 1. */
	if ( ListLength == 1 )
		len_in_chunk = EndPos - FrontPos;
	else
		len_in_chunk = EndPos;

	/* If we only need data from the last chunk get it and return. */
	if (len <= len_in_chunk)
		EndPos -= len;
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		
		/* Copy what we can get from the last chunk and toast it. */
		len -= len_in_chunk;
		SpareAChunk( DetachElement(Tail) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > ChunkLength )
		{
			/* Get the whole chunk. */
			len -= ChunkLength;
			SpareAChunk( DetachElement(Tail) );
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		EndPos = ChunkLength - len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( DequeLength == 0 )
		SpareAChunk( DetachElement(Tail) );
	/* If the fifo len not zero and there is no data in
	 * the end chunk then move to the previous chunk. */
	else if ( EndPos == 0 )
	{
		SpareAChunk( DetachElement(Tail) );
		EndPos = ChunkLength;
	}

	return retVal;
}

int Deque::RemoveLeft(void *buffer, int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	byte *dst;          /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > DequeLength)
		len = DequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	DequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the first chunk.
	 * We assert that this value is always >= 1. */
	if ( ListLength == 1 )
		len_in_chunk = EndPos - FrontPos;
	else
		len_in_chunk = ChunkLength - FrontPos;

	/* If we only need data from the first chunk get it and return. */
	if (len <= len_in_chunk)
	{
		memcpy(buffer, Head->Data + FrontPos, len);
		FrontPos += len;
	}
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		dst = (byte*) buffer;
		
		/* Copy what we can get from the first chunk and toast it. */
		memcpy(dst, Head->Data + FrontPos, len_in_chunk);
		dst += len_in_chunk;
		len -= len_in_chunk;
		SpareAChunk( DetachElement(Head) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > ChunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst, Head->Data, ChunkLength);
			SpareAChunk( DetachElement(Head) );
			dst += ChunkLength;
			len -= ChunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst, Head->Data, len);
		FrontPos = len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( DequeLength == 0 )
		SpareAChunk( DetachElement(Head) );
	/* If the fifo len not zero and there is no data in
	 * the front chunk then move to the next chunk. */
	else if ( FrontPos == ChunkLength )
	{
		SpareAChunk( DetachElement(Head) );
		FrontPos = 0;
	}

	return retVal;
}

int Deque::RemoveRight(void *buffer, int len)
{
	int retVal;         /* The number of bytes to return. */
	int len_in_chunk;   /* The num of bytes left in a chunk. */
	byte *dst;          /* Ptr to the dest. */

	/* Restrict the len to the length of the fifo. */
	if (len > DequeLength)
		len = DequeLength;

	/* Ensure we are trying to remove something. */
	if (len <= 0)
		return 0;

	/* Decrement the fifo Length. */
	DequeLength -= len;

	/* Return how many bytes were copied. */
	retVal = len;

	/* The number of bytes available in the last chunk.
	 * We assert that this value is always >= 1. */
	if ( ListLength == 1 )
		len_in_chunk = EndPos - FrontPos;
	else
		len_in_chunk = EndPos;

	/* If we only need data from the last chunk get it and return. */
	if (len <= len_in_chunk)
	{
		memcpy(buffer, Tail->Data + EndPos - len, len);
		EndPos -= len;
	}
	else 
	{
		/* We need to traverse at least two chunks.
		 */
		dst = (byte*) buffer + len;
		
		/* Copy what we can get from the last chunk and toast it. */
		memcpy(dst - len_in_chunk, Tail->Data, len_in_chunk);
		dst -= len_in_chunk;
		len -= len_in_chunk;
		SpareAChunk( DetachElement(Tail) );
		
		/* While we want all the data and more from the head chunk. */
		while (len > ChunkLength )
		{
			/* Get the whole chunk. */
			memcpy(dst - ChunkLength, Tail->Data, ChunkLength);
			SpareAChunk( DetachElement(Tail) );
			dst -= ChunkLength;
			len -= ChunkLength;
		}

		/* Copy what we need from the last chunk that
		 * has data in it then toast it. */
		memcpy(dst - len, Tail->Data + ChunkLength - len, len);
		EndPos = ChunkLength - len;
	}

	/* If the fifo len is now zero then the only chunk has its
	 * endpos and frontpos on top of each other somewhere in the middle.
	 * Reseet the markers and spare the chunk.
	 */
	if ( DequeLength == 0 )
		SpareAChunk( DetachElement(Tail) );
	/* If the fifo len not zero and there is no data in
	 * the end chunk then move to the previous chunk. */
	else if ( EndPos == 0 )
	{
		SpareAChunk( DetachElement(Tail) );
		EndPos = ChunkLength;
	}

	return retVal;
}

void Deque::FeedTo(Data *datac)
{
	Dequehunk *chunk;

	if (DequeLength == 0)
		return;
	
	if (ListLength == 1)
		datac->Receive(Head->Data + FrontPos, DequeLength);
	else
	{
		datac->Receive(Head->Data + FrontPos, ChunkLength - FrontPos);

		chunk = Head->Next;
		while ( chunk->Next != 0)
		{
			/* While cur is not the last element in the chunk list. */
			datac->Receive(chunk->Data, ChunkLength);
			chunk = chunk->Next;
		}
	
		datac->Receive(chunk->Data, EndPos);
	}

	datac->StopReceiving();
}

void Deque::DumpTo(Data *datac)
{
	if (DequeLength == 0)
		return;
	
	if (ListLength == 1) {
		datac->Receive(Head->Data + FrontPos, DequeLength);
		KillLeft(DequeLength);
	}
	else
	{
		datac->Receive(Head->Data + FrontPos, ChunkLength - FrontPos);
		SpareAChunk(DetachElement(Head));

		while ( Head->Next != 0)
		{
			/* While cur is not the last element in the chunk list. */
			datac->Receive(Head->Data, ChunkLength);
			SpareAChunk(DetachElement(Head));
		}
	
		datac->Receive(Head->Data, EndPos);
		SpareAChunk(DetachElement(Head));
		Empty();
	}

	datac->StopReceiving();
}
void Deque::Walk()
{
	Dequehunk *chunk = Head;
	while( chunk != 0 )
		chunk = chunk->Next;
}

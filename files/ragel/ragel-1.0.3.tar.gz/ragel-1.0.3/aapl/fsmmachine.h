/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMMACH_H
#define _AAPL_FSMMACH_H

#include "assert.h"
#include "vector.h"

#define MAX_UINT (~((unsigned int)0))
#define MAX_INT ((int)(MAX_UINT>>1))
#define MIN_INT ((int)((MAX_UINT>>1)+1))

#define TRANS_NO_FUNCS ((TransitionFunc*)-1)
#define ERR_TRANS_INDEX 0

template <class TransitionFunc> struct FsmMachState;

/***********************************************************************
 * class FsmMachTrans
 */
template <class TransitionFunc> struct FsmMachTrans
{
	/* State the transition goes to. */
	FsmMachState<TransitionFunc> *toState;

	/* Functions on this transition. */
	TransitionFunc *funcs;

	struct FsmMachTransCompare
	{
		static int Compare(const FsmMachTrans<TransitionFunc> &t1,
				const FsmMachTrans<TransitionFunc> &t2)
		{
			if ( t1.toState < t2.toState )
				return -1;
			else if ( t1.toState > t2.toState )
				return 1;
			else {
				if ( t1.funcs < t2.funcs )
					return -1;
				else if ( t1.funcs > t2.funcs )
					return 1;
				else
					return 0;
			}
		}
	};
};


/***********************************************************************
 * class FsmMachState
 */
template <class TransitionFunc> struct FsmMachState
{
	FsmMachState() { };
	~FsmMachState()
	{
		if (transIndex)
			delete[] transIndex;
	}

	/* Index into the transitions for this state. */
	FsmMachTrans<TransitionFunc> **transIndex;
	FsmMachTrans<TransitionFunc> *errIndex;
	int numIndex;

	/* low and high index values. */
	int lowIndex;
	int highIndex;

	/* Out functions for this state. */
	TransitionFunc *outFuncs;

	/* Is the state final. */
	bool isFinState;
};

/***********************************************************************
 * class FsmMachine
 */
template <class TransitionFunc> class FsmMachine
{
public:

	FsmMachine() :
			startState(0),
			allStates(0), numStates(0),
			allTrans(0), numTrans(0),
			allTransFuncs(0),
			numTransFuncs(0),
			gblLowIndex(MAX_INT), gblHighIndex(MIN_INT) {}

	~FsmMachine()
	{
		if ( allStates != 0 )
			delete[] allStates;
		if ( allTrans != 0 )
			delete[] allTrans;
		if ( allTransFuncs )
			delete[] allTransFuncs;
	}

	/* Start state. */
	FsmMachState<TransitionFunc> *startState;

	/* Giant array of all states. */
	FsmMachState<TransitionFunc> *allStates;
	int numStates;

	/* Giant array of all transitions. */
	FsmMachTrans<TransitionFunc> *allTrans;
	int numTrans;

	/* Giant array of all transition functions. */
	TransitionFunc *allTransFuncs;
	int numTransFuncs;

	int gblLowIndex;
	int gblHighIndex;

	/* Counts the number of transition indicies across all states. */
	int NumIndicies();
};


/* Count the number of transition indicies across all state. */
template <class TransitionFunc> int FsmMachine<TransitionFunc>::NumIndicies()
{
	int sum = 0;
	FsmMachState<TransitionFunc> *state = allStates;
	for ( int i = 0; i < numStates; i++, state++ )
		sum += state->numIndex;
	return sum;
}

#endif /* _AAPL_FSMMACH_H */

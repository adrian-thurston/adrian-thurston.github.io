/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMGRAPH_H
#define _AAPL_FSMGRAPH_H

#include "fsmmachine.h"
#include "vector.h"
#include "vectorset.h"
#include "compare.h"
#include "avltree.h"
#include "assert.h"
#include "doublelist.h"
#include "bstable.h"

/* Flags that control merging. */
#define SB_KILLOTHERS 0x01
#define SB_WANTOTHER1 0x02
#define SB_WANTOTHER2 0x04
#define SB_WANTOTHER  0x06
#define SB_GRAPH1     0x08
#define SB_GRAPH2     0x10
#define SB_GRAPHBOTH  0x18
#define SB_MERGED     0x20
#define SB_NEWINTRANS 0x40

/*************************************************************
 * FsmGraphListEl
 *
 * This is the list element base for the the state list.
 * Disambiguating the list element data members allows fsm states
 * to be list elements of other types.
 */
template <class State> struct FsmGraphListEl :
		public DoubleListEl<State>
{ };

/*************************************************************
 * MarkIndexTmpl
 *
 * This is the marked index for a state pair. Used in condensing.
 * It keeps track of whether or not the state pair is marked.
 */
template <class State> struct MarkIndexTmpl
{
	struct StatePair : public DoubleListEl<StatePair>
	{
		bool isMarked;
		State *p, *q;
	};

	MarkIndexTmpl(int states);
	~MarkIndexTmpl();
	void MarkPair(int state1, int state2);
	bool IsPairMarked(int state1, int state2);
	StatePair *GetPair(int state1, int state2);

	DoubleList<StatePair> markedList, unmarkedList;

private:
	int numStates;
	StatePair *array;
};

#if 0
/*************************************************************
 * TransFuncKeyCompare
 */
struct TransFuncKeyCompare
{
	static int Compare( const TransitionFuncKey &key1, const TransitionFuncKey &key2 )
	{
		if ( key1.transClass < key2.transClass )
			return -1;
		else if ( key1.transClass > key2.transClass )
			return 1;
		else {
			if ( key1.transOrder < key2.transOrder )
				return -1;
			else if ( key1.transOrder > key2.transOrder )
				return 1;
			else
				return 0;
		}
	}
};
#endif

/*************************************************************
 * FsmTransition
 *
 * A single transition for a fsm.
 */
template < class State,
			class Transition,
			class TransitionFunc,
			class TransitionFuncCompare > struct FsmTransition
{
	FsmTransition( ) : fromState(0), toState(0), priority(0) {}

	Transition *Next, *Prev;
	State *fromState;
	State *toState;

	/* Transistion Func Element and the table. */
	typedef BSElement< int, TransitionFunc > TransitionFuncEl;
	typedef BSTable< int, TransitionFunc, OrdinalCompare<int> > TransitionFuncTable;

	/* Compare of a whole Func table element (key & value). */
	struct TransFuncElCompare
	{
		static int Compare( const TransitionFuncEl &func1, const TransitionFuncEl &func2 )
		{
			int res = OrdinalCompare<int>::Compare( func1.Key, func2.Key );
			if ( res != 0 )
				return res;
			else
				return TransitionFuncCompare::Compare( func1.Value, func2.Value );
		}
	};

	/* Compare of a TransFuncTable. */
	typedef TableCompare<TransitionFuncEl, TransFuncElCompare> TransFuncTableCompare;
	
	/* Plain Func list that imposes no ordering. */
	typedef Vector<TransitionFunc> TransitionFuncList;

	/* Make a func list from a func table. Simly copies the value data over. */
	static void FuncTableToFuncList( TransitionFuncList &funcList,
			TransitionFuncTable &funcTable);

	/* Comparison for TransFuncList. */
	typedef TableCompare<TransitionFunc, TransitionFuncCompare> TransFuncListCompare;

	/* The function table and priority for the transition. */
	TransitionFuncTable transFuncTable;
	int priority;

	/* Compare for transitions. */
	static inline int Compare( const FsmTransition &trans1, const FsmTransition &trans2 );
	static inline int CompareFuncs( const TransitionFuncTable &funcs1,
			const TransitionFuncTable &funcs2 );

	/* Set functions on the transition. */
	void SetFunction( TransitionFunc func, int transOrder );
	void SetFunctions( TransitionFuncTable &funcTable );

	/* For the user. */
	void MergeTransition( FsmTransition *otherTrans ) { }
};

/**************************************************
 * StateDictNode
 */
template<class State> struct StateDictNode :
		public AvlNode< StateDictNode<State> >,
		public TableCompare< State*, OrdinalCompare<State*> >
{
	typedef VectorSet< State*, OrdinalCompare<State*> > StateSet;

	StateDictNode(const StateSet &key) : Key(key) { }
	StateDictNode(const StateSet &key, const State*&) : Key(key) { }

	StateSet Key;
	State *targState;
};


/****************************************
 * template FsmState
 */
template < class State, 
			class TransitionFunc,
			class Transition > struct FsmState
		: public FsmGraphListEl<State>
{
	FsmState();
	FsmState(FsmState &other);
	~FsmState();

	typedef BSTable< int, Transition*, OrdinalCompare<int> > TransListType;
	typedef BSElement< int, Transition* > TransEl;

	/* Transistion Func Element and the table. */
	typedef BSElement< int, TransitionFunc > TransitionFuncEl;
	typedef BSTable< int, TransitionFunc, OrdinalCompare<int> > TransitionFuncTable;

	TransListType OutList;
	TransListType InList;

	int Num;

	/* When duplicating the fsm we need a map of state to new state. */
	State *stateMap;

	/* Is the state a final state. */
	bool IsFinState;

	/* Is the state Marked during the MarkReachableFromHere process. */
	bool IsMarked;

	/* Bits controlling the behaviour of the state during collapsing to dfa. */
	int StateBits;

	/* Transition data to add to any transition leaving a fsm via this state. */
	int outPriority;
	bool isOutPriorSet;
	TransitionFuncTable outTransFuncTable;

	/****************************************
	 * StateSet, StateDictNode
	 */
	typedef VectorSet< State*, OrdinalCompare<State*> > StateSet;
	typedef AvlTree<StateDictNode<State>, StateSet, State*> StateDict;

	/* A pointer to a dict node that contains the set of states
	 * this state represents. */
	StateDictNode<State> *stateDictNode;

	/* User routines. */
	void FuseState( State *otherState ) { }
	void MergeState( State *otherState ) { }

	/* Pointer to state comparison. Used by condens round. */
	typedef State* PState;
	static int Compare( const PState s1, const PState s2 );

	static int CompareOutTrans( const FsmState &state1, const FsmState &state2 );
	void SetOutFunctions( TransitionFuncTable &funcTable );
};

/****************************************
 * template FsmGraph
 */
template < class State, class TransitionFunc, class Transition >
		struct FsmGraph : public DoubleList< State, FsmGraphListEl<State> >
{
public:
	/* Constructor/Destructor. */
	FsmGraph() {}
	FsmGraph(FsmGraph &graph);
	~FsmGraph();

	/* Transistion Func Element and the table. */
	typedef BSElement< int, TransitionFunc > TransitionFuncEl;
	typedef BSTable< int, TransitionFunc, OrdinalCompare<int> > TransitionFuncTable;

	/****************************************
	 * StateSet, StateDict
	 */
	typedef VectorSet< State*, OrdinalCompare<State*> > StateSet;
	typedef AvlTree<StateDictNode<State>, StateSet, State*> StateDict;

	/* The list of states. */
	typedef FsmGraphListEl<State> ListEl;
	typedef DoubleList< State, ListEl > BaseListType;
	typedef BSTable< int, Transition*, OrdinalCompare<int> > TransListType;
	typedef BSElement< int, Transition* > TransEl;

	/* A list of states that need filling in. */
	typedef DoubleList< State, ListEl > StateFillInList;

	/* Mark index for condenseing. */
	typedef MarkIndexTmpl< State > MarkIndex;

	/* Start state and final state list. */
	State *StartState;
	StateSet FinStateSet;

	/* Attach/Detach states. */
	Transition *AttachStates(State *from, State *to, int onChar);
	void AttachStates(State *from, State *to, Transition *trans, int onChar);
	void DetachStates(State *from, State *to, Transition *trans, int onChar);

	/* Detach a state from the graph. */
	State *DetachState( State *state );

	/* Set and Unset a state as final. */
	void SetFinState(State *state);
	void UnsetFinState(State *state);

	/* Adjust priority on all transitions. */
	void AllTransPrior( int prior );

	/* Adjust priority on entering final states. */
	void FinFsmPrior( int prior );

	/* Adjust priority on leaving the fsm. */
	void LeaveFsmPrior( int prior );

	/* Clear the leave fsm priority settings from the fsm. */
	void ClearLeaveFsmPrior();

	/* Adjust priority on starting the fsm. */
	void BaseStartFsmPrior( int prior );
	void StartFsmPrior( int prior );

	/* Set function to execute on all transitions. */
	void AllTransFunc( TransitionFunc func, int transOrder );

	/* Set function to execute on entering final states. */
	void FinFsmFunc( TransitionFunc func, int transOrder );

	/* Set function to execute on leaving the fsm. */
	void LeaveFsmFunc( TransitionFunc func, int transOrder );

	/* Set function to execute on starting the fsm. */
	void BaseStartFsmFunc( TransitionFunc func, int transOrder );
	void StartFsmFunc( TransitionFunc func, int transOrder );

	/* Shift the function ordering of the start transitions to start
	 * at fromOrder and increase in units of 1. Useful before staring.
	 * Returns the ordering number of order numbers used. */
	int ShiftStartFuncOrder( int fromOrder );

	/* Remove all transition functions from the machine. */
	void StripAllTransData();

	/* Function clearing routines. */
	void ClearAllTransFunc();
	void ClearFinFsmFunc();
	void ClearLeaveFsmFunc();
	void ClearStartFsmFunc();

	/* Attach States using Fsm methods. */
	void FsmAttachStates( StateDict &stateDict, StateFillInList &stfil,
			State *from, State *to, int onChar,
			Transition *srcTrans, bool leavingFsm, bool ignorePriorities );

	/* Copy the in trans from src to dest. */
	void OutTransCopy(StateDict &stateDict, StateFillInList &stfil,
			State *dest, TransListType &srcList, bool leavingFsm, 
			bool ignorePriorities);
	void OutTransCopy(StateDict &stateDict, StateFillInList &stfil,
			State *dest, State *src, bool leavingFsm, bool ignorePriorities);

	/* Move the in trans into src into dest. */
	void InTransMove(State *dest, State *src);

	/* Mark state pairs that go into this pair. */
	void MarkPairsOnIn( MarkIndex &markIndex, State *r, State *s );

	/* Decide if the pair should be marked. Considers whether or not pairs of 
	 * transitions go to marked states. Does not consider transition data. */
	bool ShouldMarkPair(MarkIndex &markIndex, State *r, State *s);

	/* Decide if the pair should be marked. Considers whether or not pairs of 
	 * transitions go to marked states and if the transition data differs. */
	bool ShouldMarkPairTransData(MarkIndex &markIndex, State *r, State *s);

	/* Mark all states reachable from state. */
	void MarkReachableFromHereReverse( State *state );

	/* Mark all states reachable from state. */
	void MarkReachableFromHere( State *state );

	/* Mark all states reachable from state. */
	void UnmarkReachableFromHere( State *state );

	/* A map between list of functions and pointers to the list. Used
	 * Creating the final fsm. Allows to reuse duplicate function lists
	 * and greately compress the fsm. */
	typedef BSTable<typename Transition::TransitionFuncList, int,
			typename Transition::TransFuncListCompare> FuncListMap;

	/* Elements in the function list map. */
	typedef BSElement<typename Transition::TransitionFuncList, int> FuncListMapEl;

	/* A map between transitions and lists of characters that go on those
	 * transitions. Used in condensing the outlist of a state. */
	typedef BSTable<FsmMachTrans<TransitionFunc>, int,
			FsmMachTrans<TransitionFunc>::FsmMachTransCompare> TransMap;

	/* Elements in the transition map. */
	typedef BSElement<FsmMachTrans<TransitionFunc>, int> TransMapEl;

	/* Build a runnable, compressed machine from this graph. */
	void BuildFsmMachine( FsmMachine<TransitionFunc> &machine );

	/* Make the states for a new machine. */
	void InitMachineStates( FsmMachine<TransitionFunc> &newMachine );

	/* Make a machine state from a graph state. */
	void MakeMachineState( FuncListMap &funcListMap, int &curFuncOffest,
			TransMap &transMap, int &curTransOffset, 
			FsmMachState<TransitionFunc> *machState, State *state );

	/* Run a sanity check on the machine. */
	void VerifyIntegrity();

	/* New up a state and add it to the graph. */
	State *NewState(bool isFinState = false);

	/* Build basic fsms. */
	static FsmGraph *ConcatFsm( char *set );
	static FsmGraph *ConcatFsm( int *set, int len );
	/* The oring routines reqire that the characters in
	 * set be uniq otherwise they will assertion fail. */
	static FsmGraph *OrFsm( char *set );
	static FsmGraph *OrFsm( int *set, int len );
	static FsmGraph *NullFsm( );

	/* Fsm Operators. */
	void Star(bool leavingFsm);
	void Concat(FsmGraph *other, bool leavingFsm);
	void Or(FsmGraph *other);
	void Intersect(FsmGraph *other);
	void Subtract(FsmGraph *other);

	/* Underlying worker behind Or, Intersect and Subtract. */
	void DoOr(FsmGraph *other);

	/* Set State numbers starting at 0. */
	void SetStateNumbers();

	/* Unset all final states. */
	void UnsetAllFinStates();

	/* Set the priority of all transitions into final states. */
	void SetFinBits( int allStateBits, int finStateBits );

	/* Merge a set of states into newState. */
	void MergeStates( StateDict &stateDict, StateFillInList &stfil,
			State *newState, StateSet &stateSet,
			bool leavingFsm, bool ignorePriorities );

	/* Make all states that are combinations of other states and that
	 * have not yet had their out transitions filled in. This
	 * will empty out stateDict and stFil. */
	void FillInStates( StateDict &stateDict, StateFillInList &stfil );

	/* Zero out all the function keys. This is useful just before
	 * condensing and building a machine. If the function keys are all identical
	 * then states will not be separated because of the specified ordering.
	 * After this call, no operations can be done on the fsm. */
	void NullFunctionKeys();

	/*** Condensing ***/

	/* Condense the final state Machine. The result is the most condense fsm possible.
	 * Slow but stable, correct condensing. Uses n^2 space (lookout) and average
	 * n^2 time. Worst case n^3 time, but a that is a very rare case. */
	void CondenseStable();

	/* Condense the final state machine. Does not find the most condense fsm possible.
	 * But a pretty good approximation. Does not use any extra space. Average
	 * n^2 time. Worst case n^3 time, but a that is a very rare case. */
	void CondenseApproximate();


	/* Condense the final state Machine. The result is the most condense
	 * fsm possible. Considers all state pairs and is thus O(n^2)
	 * Warning: Unverified, maybe buggy, maybe incorrect. */
	void CondenseOptimized1();

	/* Condense the final state Machine. The result is the most condense
	 * fsm possible. Does not consider all state pairs. If this is called
	 * it must be called after every fsm operation that can created states.
	 * (or,and,star,intersect,subtract,startprior,startfunc). Is at worst
	 * O( n^2 / 4 ) when operating on two machines of equal size. And at
	 * best O(n) when operating on one small machine and one large machine.
	 * Warning: Unverified, maybe buggy, maybe incorrect. */
	void CondenseOptimized2();

	/* This is the worker for the condense approximate solution. It merges
	 * states that have identical out transitions. */
	bool CondenseRound( );

	/* Mark pairs where out final stateness differs, out trans data differs,
	 * trans pairs go to a marked pair or trans data differs. Should get 
	 * alot of pairs. */
	void InitialMarkRound( MarkIndex &markIndex );

	/* One marking round on all state pairs. Considers if trans pairs go
	 * to a marked state only. Returns whether or not a pair was marked.  */
	bool MarkRound( MarkIndex &markIndex );

	/* Mark pairs that have in trans to pairs that can cause marking. */
	void ExhaustAll( MarkIndex &markIndex );

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void RemoveDeadEndStates();

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void RemoveObliviousStates();

	/* Mark and Unmark all states. */
	void MarkAllStates();
	void UnmarkAllStates();

	/* Remove all out funcs and out priorites on non final states. */
	void StripNonFinalStates();

	/* Assert that there are no out funcs/priorities on non final states. */
	void VerifyOutFuncs();
	
	/* Merge state p into state q. */
	void MergePIntoQ(State *p, State *q);

	/* Find any states that didn't get marked by the marking algorithm and merge
	 * them into the primary states of their equivalence class. */
	void MergeUnmarkedPairs( MarkIndex &markIndex );
};

#endif /* _AAPL_FSMGRAPH_H */

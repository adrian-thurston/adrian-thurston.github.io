/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_TABLE_H
#define _AAPL_TABLE_H

#include <new>
#include <stddef.h>
#include "assert.h"

template<class T> class BaseTable
{
public:
	/* Default Constructor. */
	BaseTable() 
		: Table(0), TableLength(0), AllocatedLength(0) { }

	T *Table;
	int TableLength;
	int AllocatedLength;
};

template<class T> class ExpnTable : public BaseTable<T>
{
public: 
	void UpResizeToFit(int len);
	void DownResizeToFit();
};

template<class T> void ExpnTable<T>::UpResizeToFit(int len)
{
	/* If the Table is not big enough to fit len then upsize it. */
	if ( len > AllocatedLength )
	{
		/* Double the size n requested. */
		AllocatedLength = len * 2;
		if (Table) {
			/* Create the new table and copy the contents. */
			T *newTable = (T*) new char[sizeof(T)*AllocatedLength];
			ASSERT( newTable != 0 );
			memcpy(newTable, Table, sizeof(T)*TableLength);

			/* Delete the old table and make the new table the cur table. */
			delete[] (char*) Table;
			Table = newTable;
		}
		else {
			/* Create the table. */
			Table = (T*) new char[sizeof(T)*AllocatedLength];
			ASSERT( Table != 0 );
		}
	}
}

template<class T> void ExpnTable<T>::DownResizeToFit()
{
	/* Down resize if we are using less than a quarter
	 * of the space allocated. */
	if ( TableLength < AllocatedLength / 4 ) {
		if ( TableLength == 0 ) {
			/* Empty the Table. */
			AllocatedLength = 0;
			delete[] (char*) Table;
			Table = 0;
		}
		else {
			/* The new allocated length is twice that wanted. */
			AllocatedLength = TableLength * 2;

			/* Create a new table. */
			T *newTable = (T*) new char[sizeof(T)*AllocatedLength];
			ASSERT( newTable != 0 );
			memcpy(newTable, Table, sizeof(T)*TableLength);

			/* Delete the old table and make the new table the cur table. */
			delete[] (char*) Table;
			Table = newTable;
		}
	}
}

template<class T> class LinearTable : public BaseTable<T>
{
public: 
	void UpResizeToFit(int len);
	void DownResizeToFit();
};

template<class T> void LinearTable<T>::UpResizeToFit(int len)
{
	if (Table) {
		/* The new allocated length. */
		AllocatedLength = len;

		/* Create the new table and copy the contents. */
		T *newTable = (T*) new char[sizeof(T)*AllocatedLength];
		ASSERT( newTable != 0 );
		memcpy(newTable, Table, sizeof(T)*TableLength);

		/* Delete the old table and make the new table the cur table. */
		delete[] (char*) Table;
		Table = newTable;
	}
	else {
		/* The new allocated length. */
		AllocatedLength = len;

		/* Create the table. */
		Table = (T*) new char[sizeof(T)*AllocatedLength];
		ASSERT( Table != 0 );
	}
}

template<class T> void LinearTable<T>::DownResizeToFit()
{
	if ( TableLength == 0 ) {
		/* The new allocated length. */
		AllocatedLength = 0;
		/* Just delete the Table. */
		delete[] (char*) Table;
		Table = 0;
	}
	else {
		/* The new allocated length. */
		AllocatedLength = TableLength;

		/* Create the new table and copy the contents. */
		T *newTable = (T*) new char[sizeof(T)*AllocatedLength];
		ASSERT( newTable != 0 );
		memcpy(newTable, Table, sizeof(T)*TableLength);
		
		/* Delete the old table and make the new table the cur table. */
		delete[] (char*) Table;
		Table = newTable;
	}
}

template<class T, int FixedSize> class ConstTable : public BaseTable<T>
{
public: 
	void UpResizeToFit(int len);
	void DownResizeToFit() {};
};

template<class T, int FixedSize> void ConstTable<T, FixedSize>::UpResizeToFit(int len) 
{
	ASSERT( len <= FixedSize );
	if ( Table == 0 ) {
		Table = (T*) new char [sizeof(T) * FixedSize];
		ASSERT( Table != 0 );
		AllocatedLength = FixedSize;
	}
}

#endif /* _AAPL_TABLE_H */


/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include "file.h"

#define BUFSIZE 1024

/*******************************************************************************
 * InFile
 */

InFile::InFile(FILE *file)
{
 	File = file;
	LineNum = 1;
}


void InFile::Close()
{
	fclose(File);
	File = 0;
	LineNum = 0;
}

void InFile::FeedTo(Data *datac)
{
	int len;
	char buf[BUFSIZE];

	while ( (len = fread(buf, 1, BUFSIZE, File)) == BUFSIZE )
		datac->Receive(buf, BUFSIZE);

	if ( len != 0 )
		datac->Receive(buf, len);

	datac->StopReceiving();
}

#define fgetsBUFSIZE 10
bool InFile::FeedNLinesTo(Data *datac, uint lines)
{
	char buf[fgetsBUFSIZE];
	int len;
	bool bytesSent = false;

	while ( (lines > 0) && (fgets(buf, fgetsBUFSIZE, File) != NULL) )
	{
		bytesSent = true;

		len = strlen(buf);
		datac->Receive(buf, len);

		if ( buf[len-1] == '\n' )
			lines--;
	}

	LineNum++;

	datac->StopReceiving();

	return bytesSent;
}


/*******************************************************************************
 * OutFile
 */

void OutFile::Close()
{
	fclose(File);
	File = 0;
}

void OutFile::Receive(void* data, uint len)
{
	fwrite( data, 1, len, File);
}

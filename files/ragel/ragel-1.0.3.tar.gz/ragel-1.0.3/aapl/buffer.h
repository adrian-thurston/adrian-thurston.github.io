/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_BUFFER_H
#define _AAPL_BUFFER_H

#include "table.h"

/****************************************
 * template Buffer
 */
template <
			class T,
			class TableT = ExpnTable<T>
		> class Buffer : public TableT
{
public:
	/* Default Constructor. */
	Buffer() {}

	/* Copy Constructor. */
	Buffer(const Buffer &v)
		{ Append( b ); }

	/* Destructor Empties the Buffer. */
	~Buffer()
		{ delete[] (char*) Table; }

	void Empty()
		{ TableLength = 0; }

	/* Appending routines. */
	void Append(const T &val);
	void Append(const T *val, int len);
	void Append(const Buffer &b);
};

/****************************************
 * void Buffer<T, Table>::Append(const T &data)
 */
template<class T, class TableT> void Buffer<T, TableT>::
		Append(const T &src)
{
	/* Make sure we have enough space. */
	UpResizeToFit(TableLength + 1);

	/* Copy data. */
	Table[TableLength] = src;

	/* Increment table size. */
	TableLength += 1;
}

/****************************************
 * void Buffer<T, Table>::Append(const T *data, int len)
 */
template<class T, class TableT> void Buffer<T, TableT>::
		Append(const T *src, int len)
{
	/* Make sure we have enough space. */
	UpResizeToFit(TableLength + len);

	/* Copy data. */
	memcopy(Table + TableLength, src, sizeof(T)*len);

	/* Update table size. */
	TableLength += len;
}
/****************************************
 * void Buffer<T, Table>::Append(const Buffer &b)
 */
template<class T, class TableT> void Buffer<T, TableT>::
		Append(const Buffer &b)
{
	/* Make sure we have enough space. */
	UpResizeToFit(TableLength + b.TableLength);

	/* Copy data. */
	memcopy(Table + TableLength, b.Table, sizeof(T)*b.TableLength);

	/* Update table size. */
	TableLength += len;
}

/****************************************
 * void Buffer<T, Table>::Empty()
 */
template<class T, class TableT> void Vector<T, TableT>::
			Empty()
{
	if (Table) {
		/* Free the table memory. */
		delete[] (char*) Table;
		Table = 0;
		TableLength = AllocatedLength = 0;
	}
}

#endif /* _AAPL_BUFFER_H */

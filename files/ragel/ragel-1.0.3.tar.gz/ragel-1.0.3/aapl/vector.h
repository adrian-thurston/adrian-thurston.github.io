/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_VECTOR_H
#define _AAPL_VECTOR_H

#include "table.h"

/****************************************
 * template Vector
 */
template <
			class T,
			class TableT = ExpnTable<T>
		> class Vector : public TableT
{
public:
	/* Default Constructor. */
	Vector() {}

	/* Copy Constructor. */
	Vector(const Vector &v);

	/* Init Vector with size elements. */
	Vector( int size ) { SetAs( 0, size ); }

	/* Destructor Empties the Vector. */
	~Vector() { Empty(); }

	/* Reset the contents of the Vector to 0. */
	void Empty();

	/* Insertion routines. */
 	int MakeRawSpaceFor(int pos, int len);
	void Insert(int pos, const T &val)   { Insert(pos, &val, 1); }
	/* Causes ambiguaties when T is int type. */
	/* void Insert(int pos, int len)     { Insert(pos, 0, len); } */
	void Insert(int pos, const T *val, int len);
	void Insert(int pos, const Vector &v);

	/* Deletion routines. */
	void Delete(int pos)              { Delete(pos, 1); }
	void Delete(int pos, int len);

	/* Overwriting routines. */
	void Overwrite(int pos, const T &val)   { Overwrite(pos, &val, 1); }
	/* void Overwrite(int pos, int len)  { Overwrite(pos, 0, len); } */
	void Overwrite(int pos, const T *val, int len);
	void Overwrite(int pos, const Vector &v);

	/* Routines for setting the contents. */
	void SetAs(const T &val)                { SetAs(&val, 1); }
	/* void SetAs(int len)               { SetAs(0, len); } */
	void SetAs(const T *val, int len);
	void SetAs(const Vector &v);

	/* Appending routines. */
	void Append(const T &val)               { Overwrite(TableLength, &val, 1); }
	/* void Append(int len)              { Overwrite(TableLength, 0, len); } */
	void Append(const T *val, int len)      { Overwrite(TableLength, val, len); }
	void Append(const Vector &v)          
			{ ASSERT(&v != this); Overwrite(TableLength, v.Table, v.TableLength); }

};

/****************************************
 * Vector<T, Table>::Vector(Vector &v)
 *
 * The copy constructor copies the contents of the the given
 * vector into this vector. Copy Constructors are in turn called on
 * all the items in the vector.
 */
template<class T, class TableT> Vector<T, TableT>::
			Vector(const Vector<T,TableT> &v)
{
	TableLength = v.TableLength;
	AllocatedLength = v.AllocatedLength;
	if ( AllocatedLength > 0 )
	{
		Table = (T*) new char[sizeof(T) * AllocatedLength];
		T *dst = Table, *src = v.Table;
		for (int pos = 0; pos < TableLength;
				pos += 1, dst += 1, src += 1 )
			new(dst) T(*src);
	}
	else
		Table = 0;
}

/****************************************
 * void Vector<T, Table>::Empty()
 *
 * Calls the destructor on every item in the Vector, frees the
 * memory used and resets the contents to nil.
 */
template<class T, class TableT> void Vector<T, TableT>::
			Empty()
{
	if (Table) {
		/* Call All destructors. */
		T *pos = Table;
		for ( int i = 0; i < TableLength; pos++, i++ )
			pos->~T();

		/* Free the table space. */
		delete[] (char*) Table;
		Table = 0;
		TableLength = AllocatedLength = 0;
	}
}

/****************************************
 * void Vector<T, Table>::SetAs(T *data, int len)
 *
 * Sets the contents of the vector to the contents of another vector.
 * that the ther vector does not equal this.
 */
template<class T, class TableT> void Vector<T, TableT>::
		SetAs(const Vector<T, TableT> &v)
{
	ASSERT( &v != this );
	SetAs(v.Table, v.TableLength);
}

/****************************************
 * void Vector<T, Table>::SetAs(T *data, int len)
 *
 * Sets the contents of the vector to exactly what the parameters are.
 * If data is NIL, then default constructors are called on every item.
 */
template<class T, class TableT> void Vector<T, TableT>::
			SetAs(const T *data, int len)
{
	/* Call All destructors. */
	T *pos = Table;
	for ( int i = 0; i < TableLength; pos++, i++ )
		pos->~T();

	/* We are shrinking the buffer. */
	if ( len < TableLength ) {
		TableLength = len;	
		DownResizeToFit();
	}
	/* We are growing the buffer. */
	else if ( len > TableLength ) {
		UpResizeToFit(len);
		TableLength = len;
	}
	
	/* Copy data if it was supplied. */
	T *dst = Table;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}
}

/****************************************
 * void Vector<T, Table>::Overwrite(int pos, const Vector &v)
 *
 * Overwrite a vector with another vector. Requires that the source
 * vector does not = this.
 */
template<class T, class TableT> void Vector<T, TableT>::
		Overwrite(int pos, const Vector<T, TableT> &v)
{
	ASSERT(&v != this);
	Overwrite( pos, v.Table, v.TableLength );
}

/****************************************
 * void Vector<T, Table>::Overwrite(int pos, T *data, int len)
 *
 * Overwrites with items in data at posion pos. Any items that are overwritten
 * have thier destructors called. If pos is off the end of the buffer then
 * new items are constructed.
 */
template<class T, class TableT> void Vector<T, TableT>::
		Overwrite(int pos, const T *data, int len)
{
	int endPos, i;
	T *item;

	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the right end of
	 * the vector. */
	if (pos < 0)
		pos = TableLength + pos;

	/* The end is the one past the last item that we want
	 * to write to. */
	endPos = pos + len;

	/* Make sure we have enough space. */
	if ( endPos > TableLength )
		UpResizeToFit(endPos);

	/* Delete any objects we need to delete. */
	item = Table + pos;
	for ( i = pos; i < TableLength && i < endPos; i += 1, item += 1 )
		item->~T();
		
	/* Init any default constructors we need to. */
	item = Table + TableLength;
	for ( i = TableLength; i < pos; i += 1, item += 1 )
		new(item) T();

	/* Set the new TableLength. */
	TableLength = endPos;
	
	/* Copy data if it was supplied. */
	T *dst = Table + pos;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}
}


/****************************************
 * void Vector<T, Table>::Delete(int pos, int len)
 *
 * Deletes len items at position pos. All items that are deleted have their
 * destructors called.
 */
template<class T, class TableT> void Vector<T, TableT>::
		Delete(int pos, int len)
{
	int newLen, lenToSlideOver, endPos;
	T *dst, *item;

	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the right end of
	 * the vector. */
	if (pos < 0)
		pos = TableLength + pos;

	/* The first position after the last item deleted. */
	endPos = pos + len;

	/* The New table length. */
	newLen = TableLength - len;

	/* The place in the table we are deleting at. */
	dst = Table + pos;

	/* Call Destructors. */
	item = dst;
	for ( int i = 0; i < len; i += 1, item += 1 )
		item->~T();
	
	/* Shift data over if necessary. */
	lenToSlideOver = TableLength - endPos;	
	if ( len > 0 && lenToSlideOver > 0 )
		memmove(dst, dst + len, sizeof(T)*lenToSlideOver);

	/* Set the new table length. */
	TableLength = newLen;

	/* Shrink the table if necessary. */
	DownResizeToFit( );
}

/****************************************
 * void Vector<T, Table>::Insert(int pos, const Vector &v)
 *
 * Insert another vector into this vector at pos pos.
 * Requires that we don't try to insert a vector into itself.
 */
template<class T, class TableT> void Vector<T, TableT>::
	Insert(int pos, const Vector<T, TableT> &v)
{
	ASSERT(&v != this);
	Insert(pos, v.Table, v.TableLength);
}

/****************************************
 * void Vector<T, Table>::Insert(int pos, T *data, int len)
 *
 * Insert len items into the buffer at position pos. If pos is off the end
 * new items are constructed. No items are destroyed. Any Data to the
 * right of pos is shifted over.
 */
template<class T, class TableT> void Vector<T, TableT>::
		Insert(int pos, const T *data, int len)
{
	/* If we are given a negative position to insert at then
	 * treat it as a position relative to the right end of
	 * the vector. */
	if (pos < 0)
		pos = TableLength + pos;
	
	int newLen = MakeRawSpaceFor(pos, len);

	/* Copy data if it was supplied. */
	T *dst = Table + pos;
	const T *src = data;
	if ( src == 0 ) {
		/* If no data was supplied, call default constructors. */
		for ( int i = 0; i < len; i++, dst++ )
			new(dst) T();
	}
	else {
		/* If data was supplied, call copy constructors. */
		for ( int i = 0; i < len; i++, dst++, src++ )
			new(dst) T(*src);
	}

	/* Set the new TableLength. */
	TableLength = newLen;
}

/****************************************
 * int Vector<T, Table>::MakeRawSpaceFor(int pos, int len)
 *
 * Makes space for len items, Does not init the items in any way.
 * If pos is off the end then default constructors are called for
 * any any items that are included in the growth of the vector but
 * not in the subvector specified by pos, len.
 *
 * Returns the new TableLength but does NOT update it, This is
 * up to the caller!
 */
template<class T, class TableT> int Vector<T, TableT>::
		MakeRawSpaceFor(int pos, int len)
{
	/* Ensure there is space in the buffer. */
	int newLen;
	if (pos >= TableLength)
		newLen = pos + len;
	else
		newLen = TableLength + len;
	UpResizeToFit( newLen );

	/* Init any default constructors we need to. */
	T *item = Table + TableLength;
	for ( int i = TableLength; i < pos; i += 1, item += 1 )
		new(item) T();

	/* Shift Over Data at insert spot if needed. */
	if ( len > 0 && pos < TableLength ) {
		memmove(Table + pos + len, Table + pos,
			sizeof(T)*(TableLength-pos));
	}

	return newLen;
}
	


#endif /* _AAPL_VECTOR_H */

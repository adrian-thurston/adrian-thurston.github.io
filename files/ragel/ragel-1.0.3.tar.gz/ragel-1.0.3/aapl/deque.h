/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_DEQUE_H
#define _AAPL_DEQUE_H

#include "support.h"
#include "doublelist.h"

/*******************************************************************************
 *                                 Dequehunk
 */
struct Dequehunk : public DoubleListEl<Dequehunk>
{
	Dequehunk(int len)
		{ Data = new byte[len]; }

	~Dequehunk()
		{ delete[] Data; }

	byte *Data;
};

typedef DoubleList<Dequehunk> DequehunkList;

/*****************************************************************************
 *                                Deque
 */
class Deque : public Data, public DequehunkList
{
public:
	Deque(int chunkLength = 1024);
	~Deque();
	
	void Empty();
	
	/* Appends data to one end of the deque. */
	void AppendRight(void *data, int len);
	void AppendRight(char *data)
		{ AppendRight(data, strlen(data)); }
	void AppendLeft(void *data, int len);
	void AppendLeft(char *data)
		{ AppendLeft(data, strlen(data)); }

	int RemoveLeft(void *buffer, int len);
	int RemoveRight(void *buffer, int len);

	int RemoveLeft(int n);
	int RemoveRight(int n);

	/* Copies len bytes from the front of the fifo. Does
	 * not remove and data. Returns the amount of data copied. */
	int PeekLeft(void *buffer, int len);
	int PeekRight(void *buffer, int len);

	int KillLeft(int len);
	int KillRight(int len);

	int SizeLeftChunk();
	int SizeRightChunk();
	byte *PtrLeftChunk();
	byte *PtrRightChunk();

	/* Feed and Receive. */
	void FeedTo( Data * );
	void DumpTo( Data * );
	void Receive(void *data, uint len)
		{ AppendRight( data, (int) len ); }

	Dequehunk *NewChunk();
	void SpareAChunk( Dequehunk * chunk );


	int DequeLength;      /* Length of the data in the deque. */
	int ChunkLength;      /* The size of allocated chunks. */
	int FrontPos, EndPos; /* Markers to the front and end of data. */

	Dequehunk *SpareChunk;
	void Walk();
};

#if 0
class Marker
{
public:
	Marker(int i, EditChunk::DirToGrow dir, Marker *on_top_of);
	~Marker();

	void NewLeftChunk();
	void NewRightChunk();

	void InsertRight(byte *data, int len);
	void InsertLeft(byte *data, int len);

	void MoveLeft(int len);

	void DumpAllLeft();
	void DumpAllRight();

	void DumpLeft(int len);
	void DumpRight(int len);
	void InsertChunkRight(EditChunk *chunk);
	void InsertShortDataRight(byte *data, int len);
	void InsertChunkLeft(EditChunk *chunk);
	void InsertShortDataLeft(byte *data, int len);

	void SpareLeft(EditChunk *chunk);
	void SpareRight(EditChunk *chunk);

	DoubleList<EditChunk> chunkList;
	EditChunk *spareChunk;
	int filePos, id, Length;
	Marker *Next, *Prev, *onTopOf;
	unsigned int IsSentinal :1;
};
#endif

#endif /* _AAPL_DEQUE_H */


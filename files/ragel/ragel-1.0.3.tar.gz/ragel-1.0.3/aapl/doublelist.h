/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_DOUBLE_LIST_H
#define _AAPL_DOUBLE_LIST_H

#if defined( AAPL_NOBASEREF )
#	define BASEREF(name) name
#else
#	define BASEREF(name) BaseElement::name
#endif

/*****************************************************************
 * DoubleListEl
 */
template<class Element> struct DoubleListEl
{
	Element *Prev;
	Element *Next;
};


/*****************************************************************
 * DoubleList
 */
template < class Element, class BaseElement = Element >
		class DoubleList
{
public:
	DoubleList(const DoubleList &other);
	DoubleList() : Head(0), Tail(0), ListLength(0) {}

	void AddFront(Element *new_el)
		{AddBefore(Head, new_el);}
	void AddEnd(Element *new_el)
		{AddAfter(Tail, new_el);}

	void AddFront( DoubleList &dl )
		{AddBefore(Head, dl);}
	void AddEnd( DoubleList &dl )
		{AddAfter(Tail, dl);}

	Element *DetachFront()
		{return DetachElement(Head);}
	Element *DetachEnd()
		{return DetachElement(Tail);}

	void DeleteElements();
	void EmptyList();
	
	void AddAfter(Element *prev_el, Element *new_el);
	void AddBefore(Element *next_el, Element *new_el);

	void AddAfter(Element *prev_el, DoubleList &dl);
	void AddBefore(Element *next_el, DoubleList &dl);

	Element *DetachElement(Element *el);

	Element *Head, *Tail;
	int ListLength;
};

/*******************************************************************
 * Copy Constructor
 *
 * Copy the data from another list. New up each item.
 */
template<class Element, class BaseElement>
		DoubleList<Element, BaseElement>::
		DoubleList(const DoubleList<Element, BaseElement> &other) :
		Head(0), Tail(0), ListLength(0)
{
	Element *el = other.Head;
	while( el != 0 ) {
		AddEnd( new Element(*el) );
		el = el->BASEREF(Next);
	}
}

/*******************************************************************
 * DoubleList::AddAfter
 *
 * Insert an element after a given element already in the list.
 */
template<class Element, class BaseElement>
		void DoubleList<Element, BaseElement>::
		AddAfter(Element *prev_el, Element *new_el)
{
	/* Set the previous pointer of new_el to prev_el. We do
	 * this regardless of the state of the list. */
	new_el->BASEREF(Prev) = prev_el; 

	/* Set forward pointers. */
	if (prev_el == 0) {
		/* There was no prev_el, we are inserting at the head. */
		new_el->BASEREF(Next) = Head;
		Head = new_el;
	} 
	else {
		/* There was a prev_el, we can access previous next. */
		new_el->BASEREF(Next) = prev_el->BASEREF(Next);
		prev_el->BASEREF(Next) = new_el;
	} 

	/* Set reverse pointers. */
	if (new_el->BASEREF(Next) == 0) {
		/* There is no next element. Set the Tail pointer. */
		Tail = new_el;
	}
	else {
		/* There is a next element. Set it's prev pointer. */
		new_el->BASEREF(Next)->BASEREF(Prev) = new_el;
	}

	/* Update list length. */
	ListLength++;
}

/*******************************************************************
 * DoubleList::AddBefore
 *
 * Insert an element before a given element already in the list.
 */
template<class Element, class BaseElement>
		void DoubleList<Element, BaseElement>::
		AddBefore(Element *next_el, Element *new_el)
{
	/* Set the next pointer of the new element to next_el. We do
	 * this regardless of the state of the list. */
	new_el->BASEREF(Next) = next_el; 

	/* Set reverse pointers. */
	if (next_el == 0) {
		/* There is no next elememnt. We are inserting at the tail. */
		new_el->BASEREF(Prev) = Tail;
		Tail = new_el;
	} 
	else {
		/* There is a next element and we can access next's previous. */
		new_el->BASEREF(Prev) = next_el->BASEREF(Prev);
		next_el->BASEREF(Prev) = new_el;
	} 

	/* Set forward pointers. */
	if (new_el->BASEREF(Prev) == 0) {
		/* There is no previous element. Set the head pointer.*/
		Head = new_el;
	}
	else {
		/* There is a previous element, set it's next pointer to new_el. */
		new_el->BASEREF(Prev)->BASEREF(Next) = new_el;
	}

	/* Update list length. */
	ListLength++;
}

/*******************************************************************
 * DoubleList::AddAfter
 *
 * Insert an entire list after another element already in the list.
 * Result is other list is emptied out.
 */
template<class Element, class BaseElement>
		void DoubleList<Element, BaseElement>::
		AddAfter( Element *prev_el, DoubleList<Element,BaseElement> &dl )
{
	/* Do not bother if dl has no elements. */
	if ( dl.ListLength == 0 )
		return;

	/* Set the previous pointer of dl.Head to prev_el. We do
	 * this regardless of the state of the list. */
	dl.Head->BASEREF(Prev) = prev_el; 

	/* Set forward pointers. */
	if (prev_el == 0) {
		/* There was no prev_el, we are inserting at the head. */
		dl.Tail->BASEREF(Next) = Head;
		Head = dl.Head;
	} 
	else {
		/* There was a prev_el, we can access previous next. */
		dl.Tail->BASEREF(Next) = prev_el->BASEREF(Next);
		prev_el->BASEREF(Next) = dl.Head;
	} 

	/* Set reverse pointers. */
	if (dl.Tail->BASEREF(Next) == 0) {
		/* There is no next element. Set the Tail pointer. */
		Tail = dl.Tail;
	}
	else {
		/* There is a next element. Set it's prev pointer. */
		dl.Tail->BASEREF(Next)->BASEREF(Prev) = dl.Tail;
	}

	/* Update the list length. */
	ListLength += dl.ListLength;

	/* Empty out dl. */
	dl.Head = dl.Tail = 0;
	dl.ListLength = 0;
}

/*******************************************************************
 * DoubleList::AddBefore
 *
 * Insert an entire list before another element already in the list.
 * Result is other list is emptied out.
 */
template<class Element, class BaseElement>
		void DoubleList<Element, BaseElement>::
		AddBefore( Element *next_el, DoubleList<Element,BaseElement> &dl )
{
	/* Do not bother if dl has no elements. */
	if ( dl.ListLength == 0 )
		return;

	/* Set the next pointer of dl.Tail to next_el. We do
	 * this regardless of the state of the list. */
	dl.Tail->BASEREF(Next) = next_el; 

	/* Set reverse pointers. */
	if (next_el == 0) {
		/* There is no next elememnt. We are inserting at the tail. */
		dl.Head->BASEREF(Prev) = Tail;
		Tail = dl.Tail;
	} 
	else {
		/* There is a next element and we can access next's previous. */
		dl.Head->BASEREF(Prev) = next_el->BASEREF(Prev);
		next_el->BASEREF(Prev) = dl.Tail;
	} 

	/* Set forward pointers. */
	if (dl.Head->BASEREF(Prev) == 0) {
		/* There is no previous element. Set the head pointer.*/
		Head = dl.Head;
	}
	else {
		/* There is a previous element, set it's next pointer to new_el. */
		dl.Head->BASEREF(Prev)->BASEREF(Next) = dl.Head;
	}

	/* Update list length. */
	ListLength += dl.ListLength;

	/* Empty out dl. */
	dl.Head = dl.Tail = 0;
	dl.ListLength = 0;
}


/*******************************************************************
 * DoubleList::DetachElement
 *
 * Detaches an element from the list. Does not free any memory.
 */
template<class Element, class BaseElement>
		Element *DoubleList<Element, BaseElement>::DetachElement(Element *el)
{
	/* Set forward pointers to skip over el. */
	if (el->BASEREF(Prev) == 0) 
		Head = el->BASEREF(Next); 
	else {
		el->BASEREF(Prev)->BASEREF(Next) =
				el->BASEREF(Next); 
	}

	/* Set reverse pointers to skip over el. */
	if (el->BASEREF(Next) == 0) 
		Tail = el->BASEREF(Prev); 
	else {
		el->BASEREF(Next)->BASEREF(Prev) =
				el->BASEREF(Prev); 
	}

	/* Update List length and return element we detached. */
	ListLength--;
	return el;
}

/*******************************************************************
 * DoubleList::DeleteElements
 *
 * Frees all the memory used by a list.
 */
template<class Element, class BaseElement>
		void DoubleList<Element, BaseElement>::DeleteElements()
{
	Element *nextToGo = 0, *cur = Head;
	
	while (cur != 0)
	{
		nextToGo = cur->BASEREF(Next);
		delete cur;
		cur = nextToGo;
	}
	Head = Tail = 0;
	ListLength = 0;
}

/*******************************************************************
 * DoubleList::EmptyList
 *
 * Abandon all elements in the list.
 */
template<class Element, class BaseElement>
		void DoubleList<Element, BaseElement>::EmptyList()
{
	Head = Tail = 0;
	ListLength = 0;
}

/* Finished with this. */
#undef BASEREF


#endif /* _AAPL_DOUBLE_LIST_H */


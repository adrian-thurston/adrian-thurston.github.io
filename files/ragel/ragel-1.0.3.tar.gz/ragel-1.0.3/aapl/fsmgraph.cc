/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMGRAPH_CC
#define _AAPL_FSMGRAPH_CC

#include "fsmgraph.h"
#include "mergesort.h"

#include "fsmbase.cc"


#if defined( AAPL_NOBASEREF )
#	define BASEREF(name) name
#else
#	define BASEREF(name) ListEl::name
#endif


/*************************************************************
 * FsmTransition::Compare
 */
template < class State, class Transition,
		class TransitionFunc, class TransitionFuncCompare >
		int FsmTransition<State, Transition, TransitionFunc, TransitionFuncCompare>::
		Compare( const FsmTransition &trans1, const FsmTransition &trans2 )
{
	if ( trans1.priority < trans2.priority )
		return -1;
	else if ( trans1.priority > trans2.priority )
		return 1;
	else
	{
		int cmpResult = TransFuncTableCompare::
				Compare(trans1.transFuncTable, trans2.transFuncTable);
		if ( cmpResult != 0 )
			return cmpResult;
	}
	return 0;
}

/*************************************************************
 * FsmTransition::Compare
 */
template < class State, class Transition,
		class TransitionFunc, class TransitionFuncCompare >
		int FsmTransition<State, Transition, TransitionFunc, TransitionFuncCompare>::
		CompareFuncs ( const TransitionFuncTable &funcs1, const TransitionFuncTable &funcs2 )
{
	return TransFuncTableCompare::Compare( funcs1, funcs2 );
}

/*************************************************************
 * FsmTransition::SetFunction
 */
template < class State, class Transition,
		class TransitionFunc, class TransitionFuncCompare >
		void FsmTransition<State, Transition, TransitionFunc, TransitionFuncCompare>::
		SetFunction( TransitionFunc func, int transOrder )
{
	transFuncTable.InsertMulti( transOrder, func );
}

/*************************************************************
 * FsmTransition::SetFunctions
 */
template < class State, class Transition,
		class TransitionFunc, class TransitionFuncCompare >
		void FsmTransition<State, Transition, TransitionFunc, TransitionFuncCompare>::
		SetFunctions( TransitionFuncTable &funcTable )
{
	TransitionFuncEl *tfel = funcTable.Table;
	int ntfel = funcTable.TableLength;
	for ( int i = 0; i < ntfel; i++, tfel++ )
		transFuncTable.InsertMulti( tfel->Key, tfel->Value );
}

/*************************************************************
 * FsmTransition::FuncTableToFuncList
 */
template < class State, class Transition,
		class TransitionFunc, class TransitionFuncCompare >
		void FsmTransition<State, Transition, TransitionFunc, TransitionFuncCompare>::
		FuncTableToFuncList( TransitionFuncList &funcList, TransitionFuncTable &funcTable )
{
	TransitionFuncEl *tfel = funcTable.Table;
	int ntfel = funcTable.TableLength;
	for ( int i = 0; i < ntfel; i++, tfel++ )
		funcList.Append( tfel->Value );
}

/*************************************************************
 * FsmGraph::NewState
 */
template < class State, class TransitionFunc, class Transition >
		State *FsmGraph<State, TransitionFunc, Transition>::
		NewState(bool isFinState)
{
	/* Create the new state. */
	BaseListType::AddEnd(new State());

	/* Do we want to create this state as a final state. */
	if (isFinState)
		SetFinState(Tail);

	/* Return the new state. */
	return Tail;
}

/*************************************************************
 * FsmGraph::ConcatFsm
 */
template < class State, class TransitionFunc, class Transition >
		FsmGraph<State, TransitionFunc, Transition>*
		FsmGraph<State, TransitionFunc, Transition>::
		ConcatFsm( char *set )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state. */
	State *last = retVal->NewState();
	State *newState;

	/* Attach subsequent states. */
	retVal->StartState = last;
	for ( ; *set != 0; set++ ) {
		newState = retVal->NewState();
		retVal->AttachStates(last, newState, *set);
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->SetFinState(last);

	return retVal;
}

template < class State, class TransitionFunc, class Transition >
		FsmGraph<State, TransitionFunc, Transition>*
		FsmGraph<State, TransitionFunc, Transition>::
		ConcatFsm( int *set, int len )
{
	/* New Graph */
	FsmGraph *retVal = new FsmGraph;

	/* Make the first state. */
	State *last = retVal->NewState();
	State *newState;

	/* Attach subsequent states. */
	retVal->StartState = last;
	for ( int i = 0; i < len; i++, set++ ) {
		newState = retVal->NewState();
		retVal->AttachStates(last, newState, *set);
		last = newState;
	}

	/* Make the last state the final state. */
	retVal->SetFinState(last);

	return retVal;
}



template < class State, class TransitionFunc, class Transition >
		FsmGraph<State, TransitionFunc, Transition>*
		FsmGraph<State, TransitionFunc, Transition>::
		OrFsm( char *set )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	retVal->StartState = start;
	for ( ; *set != 0; set++ )
		retVal->AttachStates(start, end, *set);

	return retVal;
}

template < class State, class TransitionFunc, class Transition >
		FsmGraph<State, TransitionFunc, Transition>*
		FsmGraph<State, TransitionFunc, Transition>::
		OrFsm( int *set, int len )
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Two states first start, second final. */
	State *start = retVal->NewState();
	State *end = retVal->NewState(true);

	retVal->StartState = start;
	for ( int i = 0; i < len; i++, set++ )
		retVal->AttachStates( start, end, *set );

	return retVal;
}

template < class State, class TransitionFunc, class Transition >
		FsmGraph<State, TransitionFunc, Transition>*
		FsmGraph<State, TransitionFunc, Transition>::
		NullFsm()
{
	/* New Graph. */
	FsmGraph *retVal = new FsmGraph;

	/* Give it one state with no transitions making it
	 * the start state and final state. */
	retVal->StartState = retVal->NewState(true);

	/* Return new Graph. */
	return retVal;
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		Star(bool leavingFsm)
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);

	/* Build a state set consisting of our start state. */
	StateSet startStateSet;
	startStateSet.Set( StartState );

	/* For the merging process. */
	StateFillInList stfil;
	StateDict stateDict;

	/* Get a copy of the final state set before creating the new
	 * start state. It may get set final and we don't want the start
	 * state to be included in the final state set. If it is included
	 * in the final state set then all the final states after it get
	 * the transitions of the start state doubled up. That's incorrect.*/
	StateSet finStateSetCopy(FinStateSet);

	/* This will be the new start state. It gets set as final and the
	 * existing start state is merged with it. */
	State *newState = NewState(false);
	MergeStates( stateDict, stfil, newState, startStateSet, false, false );
	
	/* Set it as the start state. */
	StartState = newState;
	startStateSet.SetAs( newState );

	/* For all the final states, merge with the new start state. */
	State **st = finStateSetCopy.Table;
	int nst = finStateSetCopy.TableLength;
	for (int i = 0; i < nst; i++, st++)
		MergeStates( stateDict, stfil, *st, startStateSet, leavingFsm, false );

	/* Now it is safe to merge the start state with itself (provided it
	 * is set final). */
	if ( StartState->IsFinState )
		MergeStates( stateDict, stfil, StartState, startStateSet, leavingFsm, false );

	/* Now ensure the new start state is a final state. */
	SetFinState(StartState);

	/* Fill in any states that were newed up as combinations of others. */
	FillInStates( stateDict, stfil );

	/* Remove states that have no path into them. */
	RemoveObliviousStates();

	/* There is nothing in the Star routine to cause states to loose
	 * thier final stateness. So ASSERT the fact that there should be
	 * no non-final states with out functions/priorites. */
	VerifyOutFuncs();
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		Concat(FsmGraph *other, bool leavingFsm)
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);
	other->SetFinBits(SB_GRAPH2, 0);

	/* Build a state set consisting of other's start state. */
	StateSet startStateSet;
	startStateSet.Set( other->StartState );

	/* For the merging process. */
	StateFillInList stfil;
	StateDict stateDict;

	/* Get a copy of our final state set. We need to iterate over it
	 * while it may change. */
	StateSet finStateSetCopy(FinStateSet);

	/* Unset all of our final states. */
	UnsetAllFinStates();

	/* Merge the lists. Get the final states from other. */
	AddEnd( *other );
	FinStateSet.Set( other->FinStateSet );
	
	/* Since other's list is emtpy, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our (former) final states with the start state of other. */
	State **st = finStateSetCopy.Table;
	int nst = finStateSetCopy.TableLength;
	for (int i = 0; i < nst; i++, st++)
		MergeStates( stateDict, stfil, *st, startStateSet, leavingFsm, false );

	/* Fill in any new states made from merging. */
	FillInStates( stateDict, stfil );

	/* Remove any states that have no path into them. */
	RemoveObliviousStates();

	/* Strip out functions/priorities from non final states. */
	StripNonFinalStates();
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		DoOr(FsmGraph *other)
{
	/* Build a state set consisting of both start states */
	StateSet startStateSet;
	startStateSet.Set( StartState );
	startStateSet.Set( other->StartState );

	/* For the merging process. */
	StateFillInList stfil;
	StateDict stateDict;

	/* Merge the lists. This will move all the states from otherj
	 * into this. No states will be deleted. */
	AddEnd( *other );

	/* Move the final set data from other into this. */
	FinStateSet.Set(other->FinStateSet);
	other->FinStateSet.Empty();

	/* Since other's list is emtpy, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Create a new start state. */
	State *newStartState = NewState();
	StartState = newStartState;

	/* Merge the start states. */
	MergeStates( stateDict, stfil, newStartState, startStateSet, false, false );

	/* Fill in any new states made from merging. */
	FillInStates( stateDict, stfil );
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		Or(FsmGraph *other)
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);
	other->SetFinBits(SB_GRAPH2, 0);

	/* Call Worker routine. */
	DoOr( other );

	/* Remove states which have no path into them. */
	RemoveObliviousStates();

	/* Veryify that there are no out functions on non final states.
	 * This should be true as no states should have their final stateness removed. */
	VerifyOutFuncs();
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		Intersect(FsmGraph *other)
{
	/* Set the fin bits on this and other to want each other. */
	SetFinBits(SB_GRAPH1, SB_WANTOTHER1);
	other->SetFinBits(SB_GRAPH2, SB_WANTOTHER2);

	/* Unset final states in both. */
	UnsetAllFinStates();
	other->UnsetAllFinStates();

	/* Call worker Or routine. */
	DoOr( other );

	/* Remove states that have no path into them. */
	RemoveObliviousStates();

	/* Remove states that have no path to a final state. */
	RemoveDeadEndStates();

	/* Strip the out function data from states that are no longer final. */
	StripNonFinalStates();
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		Subtract(FsmGraph *other)
{
	/* Set the fin bits of other to be killers. */
	SetFinBits(SB_GRAPH1, 0);
	other->SetFinBits(SB_GRAPH2, SB_KILLOTHERS);

	/* Unset all final states and remove all transition data from other. */
	other->UnsetAllFinStates();
	other->StripAllTransData();

	/* Call worker Or routine. */
	DoOr( other );

	/* Remove states that have no path into them. */
	RemoveObliviousStates();

	/* Remove states that have no path to a final state. */
	RemoveDeadEndStates();

	/* Strip the out function data from states that are no longer final. */
	StripNonFinalStates();
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		StartFsmPrior( int prior )
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);

	/* Build a state set consisting of our start state. */
	StateSet startStateSet;
	startStateSet.Set( StartState );

	/* For the merging process. */
	StateFillInList stfil;
	StateDict stateDict;

	/* This will be the new start state. It the existing start
	 * state is merged with it. */
	State *newState = NewState(false);
	MergeStates( stateDict, stfil, newState, startStateSet, false, false );
	
	/* Set it as the start state. */
	StartState = newState;
	startStateSet.SetAs( newState );

	/* stfil and stateDict Should be empty as we the merging of the old
	 * start state into the new one will not have any conflicting transitions. */
	ASSERT( stateDict.NodeCount == 0 );
	ASSERT( stfil.ListLength == 0 );

	/* If the new start state is final then add the to out priority.
	 * not really sure if this is what is desired.  */
	if ( StartState->IsFinState ) {
		StartState->isOutPriorSet = true;
		StartState->outPriority = prior;
	}

	/* Now call the underlying worker that will actually set the priority. */
	BaseStartFsmPrior( prior );

	/* Old start state may be oblivious. */
	RemoveObliviousStates();

	/* There is nothing in the StartFsmPrior routine to cause states to loose
	 * thier final stateness. So ASSERT the fact that there should be
	 * no non-final states with out functions/priorites. */
	VerifyOutFuncs();
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		StartFsmFunc( TransitionFunc func, int transOrder )
{
	/* Reset the final bits for the optimized condensing2 */
	SetFinBits(SB_GRAPH1, 0);

	/* Build a state set consisting of our start state. */
	StateSet startStateSet;
	startStateSet.Set( StartState );

	/* For the merging process. */
	StateFillInList stfil;
	StateDict stateDict;

	/* This will be the new start state. It the existing start
	 * state is merged with it. */
	State *newState = NewState(false);
	MergeStates( stateDict, stfil, newState, startStateSet, false, false );
	
	/* Set it as the start state. */
	StartState = newState;
	startStateSet.SetAs( newState );

	/* stfil and stateDict Should be empty as we the merging of the old
	 * start state into the new one will not have any conflicting transitions. */
	ASSERT( stateDict.NodeCount == 0 );
	ASSERT( stfil.ListLength == 0 );

	/* If the new start state is final then insert on the out func. This
	 * means that your can have start and leaving funcs on a machine
	 * that is recognising the null word. */
	if ( StartState->IsFinState )
		StartState->outTransFuncTable.InsertMulti( transOrder, func );

	/* Now call the underlying worker that will actually set the funcs. */
	BaseStartFsmFunc( func, transOrder );

	/* Old start state may be oblivious. */
	RemoveObliviousStates();

	/* There is nothing in the StartFsmPrior routine to cause states to loose
	 * thier final stateness. So ASSERT the fact that there should be
	 * no non-final states with out functions/priorites. */
	VerifyOutFuncs();
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		SetStateNumbers()
{
	int curNum = 0;
	State *state = Head;
	while (state != 0) {
		state->Num = curNum;
		curNum++;
		state = state->BASEREF(Next);
	}
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		UnsetAllFinStates()
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;
	for ( int i = 0; i < nst; i++, st++ ) {
		(*st)->IsFinState = false;
	}
	FinStateSet.Empty();
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		SetFinBits( int allStateBits, int finStateBits )
{
	State *state = Head;
	while ( state != 0 ) {
		if ( state->IsFinState )
			state->StateBits = allStateBits | finStateBits;
		else
			state->StateBits = allStateBits;

		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MergeStates( StateDict &stateDict, StateFillInList &stfil,
				State *newState, StateSet &stateSet,
				bool leavingFsm, bool ignorePriorities )
{
	int bits = newState->StateBits | SB_MERGED;
	bool finState = newState->IsFinState;

	State **stp = stateSet.Table;
	int nst = stateSet.TableLength;
	for ( int i = 0; i < nst; i++, stp++ ) {
		State *src = *stp;

		/* Get the out transitions. */
		OutTransCopy(stateDict, stfil, newState, src, leavingFsm, false);

		/* Get bits and final state status. */
		bits |= src->StateBits;
		if ( src->IsFinState )
			finState = true;

		/* Merge the outTransFuncTable. */
		if ( src == newState ) {
			/* Duplicate the list. */
			typename Transition::TransitionFuncTable
					srcTransTable( src->outTransFuncTable );
			newState->SetOutFunctions( srcTransTable );
		}
		else {
			/* Get the out functions. */
			newState->SetOutFunctions( src->outTransFuncTable );
		}

		if ( src->isOutPriorSet ) {
			newState->isOutPriorSet = true;
			newState->outPriority = src->outPriority;
		}

		/* Call user routine. */
		newState->MergeState( src );
	}

	if ( bits&SB_KILLOTHERS ) {
		/* One final state is a killer, don't set final. */
		finState = false;

		/* Kill the out transitions. Reset the priority. */
		newState->outTransFuncTable.Empty();
		newState->isOutPriorSet = false;
		newState->outPriority = 0;
	}

	if ( (bits&SB_WANTOTHER) == SB_WANTOTHER ) {
		/* There are companions in this state, we can make it final. */
		finState = true;
	} else if ( bits&SB_WANTOTHER ) {
		/* One state wants the other but it is not there. */
		finState = false;

		/* Kill the out transitions. Reset the priority. */
		newState->outTransFuncTable.Empty();
		newState->isOutPriorSet = false;
		newState->outPriority = 0;
	}

	newState->StateBits = bits;
	if ( finState )
		SetFinState( newState );
	else
		UnsetFinState( newState );
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		FillInStates( StateDict &stateDict, StateFillInList &stfil )
{
	/* Merge any states that are awaiting mergin. This will likey cause
	 * other states to be added to the stfil list. */
	State *state = stfil.Head;
	while ( state != 0 ) {
		MergeStates( stateDict, stfil, state, state->stateDictNode->Key, false, false );
		state = state->BASEREF(Next);
	}

	/* For all the states that are on the stfil list. Delete their stateSets
	 * and move them back to the main list. */
	while ( stfil.ListLength > 0 ) {
		/* Delete and reset the state set. */
		State *state = stfil.Head;
		delete state->stateDictNode;
		state->stateDictNode = 0;

		/* Move the list from the stfil list to the graph's list. */
		stfil.DetachElement( state );
		BaseListType::AddEnd( state );
	}

	/* Stfil will now be empty. We do not need to delete its elements. 
	 * stateDict will still have it's ptrs/size set but all of it's nodes
	 * will be deleted so we don't need to clean it up. */
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		CondenseStable()
{
	/* Set the state numbers. */
	SetStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex markIndex(ListLength);

	/* Mark pairs where final stateness, out trans, or trans data differ. */
	InitialMarkRound( markIndex );

	/* While the last round of marking succeeded in marking a state
	 * continue to do another round. */
	int modified = MarkRound( markIndex );
	while (modified)
		modified = MarkRound( markIndex );

	/* Merge pairs that are unmarked. */
	MergeUnmarkedPairs( markIndex );
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		CondenseApproximate()
{
	/* While the last condensing round succeeded in
	 * compacting states, continue to try to compact
	 * states. */
	int modified = CondenseRound();
	while (modified)
		modified = CondenseRound();
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		CondenseOptimized1()
{
	/* Set the state numbers. */
	SetStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex markIndex(ListLength);

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	State *p = Head;
	for ( int i = 0; i < ListLength; i++, p = p->BASEREF(Next) ) {
		State *q = Head;
		for ( int j = 0; j < i; j++, q = q->BASEREF(Next) ) {
			MarkIndex::StatePair *pair = 
					markIndex.GetPair(i, j);
			pair->p = p;
			pair->q = q;

/* The commented out code represents the optimized condensing. It is 
 * commented out for the following reasons:
 *   -It does not always find the optimal condense.
 *   -It requires that StateBits be maintained correctly
 *    and that condensing occur on each op.
 *   -I have not shown it to be a significant improvement
 *    over non optimized
 */

//			int combinedBits = p->StateBits | q->StateBits;
//		
//			/* if either is merged or they are from separate machines. */
//			if ( combinedBits & SB_MERGED ||
//					(combinedBits&SB_GRAPHBOTH) == SB_GRAPHBOTH ) {
				/* If only one is a final state then mark. */
				if ( p->IsFinState ^ q->IsFinState )
					pair->isMarked = true;
				/* If out Transition data differs then mark. */
				else if ( State::CompareOutTrans( *p, *q ) != 0)
					pair->isMarked = true;
				/* If transition data differs then mark. */
				else if ( ShouldMarkPairTransData(markIndex, p, q) )
					pair->isMarked = true;
				
				/* Put the pair on the appropriate list. */
				if ( pair->isMarked )
					markIndex.markedList.AddEnd( pair );
				else
					markIndex.unmarkedList.AddEnd( pair );
//			}
//			else if ( p->StateBits & SB_NEWINTRANS ||
//						q->StateBits & SB_NEWINTRANS ) {
//				/* Pair is not merged, from the same graph and one of the
//				 * states has had their in trans changed. The pair is marked
//				 * and we must exhaust it because of the in trans change. */
//				pair->isMarked = true;
//				markIndex.markedList.AddEnd( pair );
//			}
//			else {
//				/* Pair is not merged, from the same graph neither has had 
//				 * their in trans modified. The pair is marked and could not
//				 * possibly cause other states that are not already marked to 
//				 * be marked. So do not put on exhaust list. */
//				pair->isMarked = true;
//			}
		}
	}

	/* Exhaust all transtions that could could cause 
	 * other transtions to be marked. */
	ExhaustAll( markIndex );

	/* Merge pairs that are unmarked. */
	MergeUnmarkedPairs( markIndex );
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		CondenseOptimized2()
{
	/* Set the state numbers. */
	SetStateNumbers();

	/* This keeps track of which pairs have been marked. */
	MarkIndex markIndex(ListLength);

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	State *p = Head;
	for ( int i = 0; i < ListLength; i++, p = p->BASEREF(Next) ) {
		State *q = Head;
		for ( int j = 0; j < i; j++, q = q->BASEREF(Next) ) {
			MarkIndex::StatePair *pair = 
					markIndex.GetPair(i, j);
			pair->p = p;
			pair->q = q;

/* The commented out code represents the optimized condensing. It is 
 * commented out for the following reasons:
 *   -It does not always find the optimal condense.
 *   -It requires that StateBits be maintained correctly
 *    and that condensing occur on each op.
 *   -I have not shown it to be a significant improvement
 *    over non optimized
 */

			int combinedBits = p->StateBits | q->StateBits;
		
			/* if either is merged or they are from separate machines. */
			if ( combinedBits & SB_MERGED ||
					(combinedBits&SB_GRAPHBOTH) == SB_GRAPHBOTH ) {
				/* If only one is a final state then mark. */
				if ( p->IsFinState ^ q->IsFinState )
					pair->isMarked = true;
				/* If out Transition data differs then mark. */
				else if ( State::CompareOutTrans( *p, *q ) != 0)
					pair->isMarked = true;
				/* If transition data differs then mark. */
				else if ( ShouldMarkPairTransData(markIndex, p, q) )
					pair->isMarked = true;
				
				/* Put the pair on the appropriate list. */
				if ( pair->isMarked )
					markIndex.markedList.AddEnd( pair );
				else
					markIndex.unmarkedList.AddEnd( pair );
			}
			else if ( p->StateBits & SB_NEWINTRANS ||
						q->StateBits & SB_NEWINTRANS ) {
				/* Pair is not merged, from the same graph and one of the
				 * states has had their in trans changed. The pair is marked
				 * and we must exhaust it because of the in trans change. */
				pair->isMarked = true;
				markIndex.markedList.AddEnd( pair );
			}
			else {
				/* Pair is not merged, from the same graph neither has had 
				 * their in trans modified. The pair is marked and could not
				 * possibly cause other states that are not already marked to 
				 * be marked. So do not put on exhaust list. */
				pair->isMarked = true;
			}
		}
	}

	/* Exhaust all transtions that could could cause 
	 * other transtions to be marked. */
	ExhaustAll( markIndex );

	/* Merge pairs that are unmarked. */
	MergeUnmarkedPairs( markIndex );
}

template < class State, class TransitionFunc, class Transition >
		bool FsmGraph<State, TransitionFunc, Transition>::
		CondenseRound()
{
	/* Nothing to do if there are no states. */
	if (ListLength == 0)
		return false;

	/* Fill up an array of pointers to the states. */
	State** statePArray = new State*[ListLength];
	State *state = Head;
	State **dst = statePArray;
	while ( state != 0 ) {
		*dst = state;
		dst += 1;
		state = state->BASEREF(Next);
	}

	bool modified = false;

	/* Sort The list. */
	MergeSort<State*,State>::Sort( statePArray, ListLength );

	/* Walk the list looking for duplicates next to each other, merge in any duplicates. */
	State **pLast = statePArray;
	State **pState = statePArray + 1;
	for ( int i = 1; i < ListLength; i++, pState++ ) {
		if ( State::Compare( *pLast, *pState ) == 0 ) {
			/* Last and pState are the same, so set to merge. Move forward with pState
			 * but not with pLast. If any more are identical, we must */
			MergePIntoQ( *pState, *pLast );
			modified = true;
		}
		else {
			/* Last and this are different, do not set to merge
			 * them. Move pLast to the current (it may be way behind
			 * from merging many states) and pState forward one to consider
			 * the next pair. */
			pLast = pState;
		}
	}
	delete[] statePArray;
	return modified;
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		InitialMarkRound( MarkIndex &markIndex )
{
	State *p = Head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = Head;
		while ( q != p ) {
			bool mark = false;

			/* If final stateness is not identical then mark. */
			if ( p->IsFinState ^ q->IsFinState )
				mark = true;
			/* If p and q are both final states and they have different
			 * out transitions then mark. */
			else if (p->IsFinState && q->IsFinState && 
					State::CompareOutTrans( *p, *q ) != 0)
				mark = true;
			/* If any trans pairs go to a marked state or if the
			 * trans data differs then mark. */
			else if ( ShouldMarkPairTransData(markIndex, p, q) )
				mark = true;

			if ( mark )
				markIndex.MarkPair(p->Num, q->Num);

			q = q->BASEREF(Next);
		}
		p = p->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		bool FsmGraph<State, TransitionFunc, Transition>::
		MarkRound( MarkIndex &markIndex )
{
	bool pairWasMarked = false;
	State *p = Head, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		q = Head;
		while ( q != p ) {
			/* Should we mark the pair. */
			if ( !markIndex.IsPairMarked( p->Num, q->Num ) &&
						ShouldMarkPair(markIndex, p, q) ) {
				markIndex.MarkPair(p->Num, q->Num);
				pairWasMarked = true;
			}
			q = q->BASEREF(Next);
		}
		p = p->BASEREF(Next);
	}

	return pairWasMarked;
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		ExhaustAll( MarkIndex &markIndex )
{
	MarkIndex::StatePair *pair = markIndex.markedList.Head;

	while ( pair != NULL ) {
		MarkPairsOnIn( markIndex, pair->p, pair->q );
		pair = pair->Next;
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		RemoveDeadEndStates()
{
	State *state, *next;

	/* Start State gets honorary marking. We don't want it to accidentially
	 * go away. */
	StartState->IsMarked = true;

	/* Mark all states that have paths to the final states. */
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;
	for ( int i = 0; i < nst; i++, st++ )
		MarkReachableFromHereReverse( *st );

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = Head;
	while (state) {
		next = state->BASEREF(Next);

		if (state->IsMarked)
			state->IsMarked = false;
		else
			delete DetachState(state);
		
		state = next;
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		RemoveObliviousStates()
{
	State *state, *next;

	/* Mark all the states that can be reached
	 * thought the existing transition set. */
	MarkReachableFromHere(StartState);

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	state = Head;
	while (state) {
		next = state->BASEREF(Next);

		if (state->IsMarked)
			state->IsMarked = false;
		else
			delete DetachState(state);
		

		state = next;
	}
}
	/* Mark and Unmark all states. */
template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MarkAllStates()
{
	State *state = Head;
	while ( state != NULL ) {
		state->IsMarked = true;
		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		UnmarkAllStates()
{
	State *state = Head;
	while ( state != NULL ) {
		state->IsMarked = false;
		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		StripNonFinalStates()
{
	State *state = Head;
	while ( state != NULL ) {
		if ( ! state->IsFinState ) {
			state->outTransFuncTable.Empty();
			state->isOutPriorSet = false;
			state->outPriority = 0;
		}
		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		VerifyOutFuncs()
{
	State *state = Head;
	while ( state != NULL ) {
		if ( ! state->IsFinState ) {
			ASSERT( state->outTransFuncTable.TableLength == 0 );
			ASSERT( !state->isOutPriorSet );
			ASSERT( state->outPriority == 0 );
		}
		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MergePIntoQ(State *p, State *q)
{
	/* Definition: The primary state of an equivalence class is
	 * the first state encounterd that belongs to the equivalence
	 * class. All equivalence classes have primary state including
	 * equivalence classes with one state in it. */

	/* Merge p into q and delete p. q is always the primary state
	 * of it's equivalence class. We wouldn't have landed on it here
	 * if it were not, because it would have been deleted.
	 *
	 * Proof that q is the primaray state of it's equivalence class:
	 * Assume q is not the primary state of it's equivalence
	 * class, then it would be merged into some state that came
	 * before it and thus p would be equivalent to that state. But
	 * q is the first state that p is equivalent to so we have a 
	 * contradiction. */

	/* Cur is a duplicate. We can merge it with trail. */
	InTransMove(q, p);

	if (p == StartState)
		StartState = q;

	/* Call user routine. */
	q->FuseState(p);

	delete DetachState(p);
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MergeUnmarkedPairs( MarkIndex &markIndex )
{
	State *p = Head, *nextP, *q;

	/* Walk all unordered pairs of (p, q) where p != q.
	 * The second depth of the walk stops before reaching p. This
	 * gives us all unordered pairs of states (p, q) where p != q. */
	while ( p != 0 ) {
		nextP = p->BASEREF(Next);

		q = Head;
		while ( q != p ) {
			/* If one of p or q is a final state then mark. */
			if ( ! markIndex.IsPairMarked(p->Num, q->Num) ) {

				MergePIntoQ(p, q);
				break;
			}
			q = q->BASEREF(Next);
		}
		p = nextP;
	}
}

/* This is no longer needed. */
#undef BASEREF

#endif /* _AAPL_FSMGRAPH_CC */

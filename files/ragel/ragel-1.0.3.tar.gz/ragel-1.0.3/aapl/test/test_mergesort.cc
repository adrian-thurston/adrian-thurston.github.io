/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <vector>
#include "vector.h"
#include "mergesort.h"
#include "compare.h"

void testMergeSort1()
{
	Vector<int> v;
	srandom( time(0) );
	int numItems = ( random() % 100 );
	for ( int i = 0; i < numItems; i++ )
		v.Append(random() % 100);

	MergeSort< int, OrdinalCompare<int> >::Sort( v.Table, v.TableLength );
	int *tel = v.Table;
	int tlen = v.TableLength;
	for ( int i = 0; i < tlen; i++, tel++ )
		cout << *tel << endl;
}

int main() {
	testMergeSort1();
	return 0;
}


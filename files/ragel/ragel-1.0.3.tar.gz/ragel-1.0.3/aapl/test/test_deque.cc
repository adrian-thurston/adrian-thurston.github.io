/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "deque.h"
#include "file.h"
#include <time.h>
#include <stdlib.h>

InFile inp;
OutFile out;
OutFile errout;

char *ReverseChars(char *buf, int len)
{
	int charsToSwitch = len / 2;
	char tmp, *front = buf, *end = buf + len - 1;

	while ( charsToSwitch-- )
	{
		tmp = *front;
		*front = *end;
		*end = tmp;

		front++;
		end--;
	}

	return buf;
}

void testDeque()
{
	char buf[200];
	int nbytes_wanted;
	int nbytes;
	Deque dq( 5 );

	srandom(time(0));

	while (1)
	{
		/* Read in some random amount. */
		nbytes_wanted = ( random() % 20) + 1;

		nbytes = fread(buf, 1, nbytes_wanted, stdin);

		if (nbytes == 0)
			break;
		else if ( nbytes != nbytes_wanted)
		{
			dq.AppendRight( buf, nbytes );
			break;
		}

		dq.AppendRight( buf, nbytes );

		/* Write out some random amount. */
		nbytes = dq.RemoveLeft(buf, ( random() % 20 ));
		if (nbytes > 0)
			fwrite(buf, 1, nbytes, stdout);
	}

	/* Write out the rest. */
	nbytes = dq.RemoveLeft(buf, ( random() % 20 ) + 1);
	while ( nbytes > 0 )
	{
		fwrite(buf, 1, nbytes, stdout);

		nbytes = dq.RemoveLeft(buf, ( random() % 20 ) + 1);
	}
}

void testDequeRev()
{
	char buf[200];
	int nbytes_wanted;
	int nbytes;
	Deque dq( 5 );

	srandom(time(0));

	while (1)
	{
		/* Read in some random amount. */
		nbytes_wanted = ( random() % 20) + 1;

		nbytes = fread(buf, 1, nbytes_wanted, stdin);

		if (nbytes == 0)
			break;
		else if ( nbytes != nbytes_wanted)
		{
			ReverseChars( buf, nbytes );
			dq.AppendLeft( buf, nbytes );
			break;
		}

		ReverseChars( buf, nbytes );
		dq.AppendLeft( buf, nbytes );

		/* Write out some random amount. */
		nbytes = dq.RemoveRight(buf, ( random() % 20 ));
		if (nbytes > 0)
		{
			ReverseChars( buf, nbytes );
			fwrite(buf, 1, nbytes, stdout);
		}
	}

	/* Write out the rest. */
	nbytes = dq.RemoveRight(buf, ( random() % 20 ) + 1);
	while ( nbytes > 0 )
	{
		ReverseChars( buf, nbytes );
		fwrite(buf, 1, nbytes, stdout);

		nbytes = dq.RemoveRight(buf, ( random() % 20 ) + 1);
	}
}

void testDeque2()
{
	char buf[200];
	int nbytes_wanted;
	int nbytes;
	Deque dq( 5 );

	srandom(time(0));

	while (1)
	{
		/* Read in some random amount. */
		nbytes_wanted = ( random() % 20) + 1;

		nbytes = fread(buf, 1, nbytes_wanted, stdin);

		if (nbytes == 0)
			break;
		else if ( nbytes != nbytes_wanted)
		{
			dq.AppendRight( buf, nbytes );
			break;
		}

		dq.AppendRight( buf, nbytes );

		/* Write out some random amount. */
		nbytes = dq.PeekLeft(buf, ( random() % 20 ));
		if (nbytes > 0)
		{
			fwrite(buf, 1, nbytes, stdout);
			dq.KillLeft( nbytes );
		}
	}

	/* Write out the rest. */
	nbytes = dq.PeekLeft(buf, ( random() % 20 ) + 1);
	while ( nbytes > 0 )
	{
		fwrite(buf, 1, nbytes, stdout);
		dq.KillLeft( nbytes );

		nbytes = dq.PeekLeft(buf, ( random() % 20 ) + 1);
	}
}

void testDequeRev2()
{
	char buf[200];
	int nbytes_wanted;
	int nbytes;
	Deque dq( 5 );

	srandom(time(0));

	while (1)
	{
		/* Read in some random amount. */
		nbytes_wanted = ( random() % 20) + 1;

		nbytes = fread(buf, 1, nbytes_wanted, stdin);

		if (nbytes == 0)
			break;
		else if ( nbytes != nbytes_wanted)
		{
			ReverseChars( buf, nbytes );
			dq.AppendLeft( buf, nbytes );
			break;
		}

		ReverseChars( buf, nbytes );
		dq.AppendLeft( buf, nbytes );

		/* Write out some random amount. */
		nbytes = dq.PeekRight(buf, ( random() % 20 ));
		if (nbytes > 0)
		{
			ReverseChars( buf, nbytes );
			fwrite(buf, 1, nbytes, stdout);
			dq.KillRight( nbytes );
		}
	}

	/* Write out the rest. */
	nbytes = dq.PeekRight(buf, ( random() % 20 ) + 1);
	while ( nbytes > 0 )
	{
		ReverseChars( buf, nbytes );
		fwrite(buf, 1, nbytes, stdout);
		dq.KillRight( nbytes );

		nbytes = dq.PeekRight(buf, ( random() % 20 ) + 1);
	}
}

void testDeque3()
{
	char buf[200];
	int nbytes_wanted;
	int nbytes;
	Deque dq( 5 );

	srandom(time(0));

	while (1)
	{
		/* Read in some random amount. */
		nbytes_wanted = ( random() % 20) + 1;

		nbytes = fread(buf, 1, nbytes_wanted, stdin);

		if (nbytes == 0)
			break;
		else if ( nbytes != nbytes_wanted)
		{
			dq.AppendRight( buf, nbytes );
			break;
		}

		dq.AppendRight( buf, nbytes );

		/* Write out some random amount. */
		nbytes = dq.PeekLeft(buf, dq.SizeLeftChunk());
		if (nbytes > 0)
		{
			fwrite(buf, 1, nbytes, stdout);
			dq.KillLeft( nbytes );
		}
	}

	/* Write out the rest. */
	nbytes = dq.PeekLeft(buf, dq.SizeLeftChunk());
	while ( nbytes > 0 )
	{
		fwrite(buf, 1, nbytes, stdout);
		dq.KillLeft( nbytes );

		nbytes = dq.PeekLeft(buf, dq.SizeLeftChunk());
	}
}

void testDequeRev3()
{
	char buf[200];
	int nbytes_wanted;
	int nbytes;
	Deque dq( 5 );

	srandom(time(0));

	while (1)
	{
		/* Read in some random amount. */
		nbytes_wanted = ( random() % 20) + 1;

		nbytes = fread(buf, 1, nbytes_wanted, stdin);

		if (nbytes == 0)
			break;
		else if ( nbytes != nbytes_wanted)
		{
			ReverseChars( buf, nbytes );
			dq.AppendLeft( buf, nbytes );
			break;
		}

		ReverseChars( buf, nbytes );
		dq.AppendLeft( buf, nbytes );

		/* Write out some random amount. */
		nbytes = dq.PeekRight(buf, dq.SizeRightChunk());
		if (nbytes > 0)
		{
			ReverseChars( buf, nbytes );
			fwrite(buf, 1, nbytes, stdout);
			dq.KillRight( nbytes );
		}
	}

	/* Write out the rest. */
	nbytes = dq.PeekRight(buf, dq.SizeRightChunk());
	while ( nbytes > 0 )
	{
		ReverseChars( buf, nbytes );
		fwrite(buf, 1, nbytes, stdout);
		dq.KillRight( nbytes );

		nbytes = dq.PeekRight(buf, dq.SizeRightChunk());
	}
}



int main() {
	testDeque();
	return 0;
}

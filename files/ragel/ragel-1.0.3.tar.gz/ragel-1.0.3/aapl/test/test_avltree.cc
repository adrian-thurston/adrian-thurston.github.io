/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <sys/time.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "avltree.h"


template < class Node > struct MyAvlNode1 :
		public AvlNode< Node >,
		public OrdinalCompare<int>
{
	MyAvlNode1( ) { }
	MyAvlNode1( const int &key ) : Key( key ) {}

	int Key;
};

template < class Node > struct MyAvlNode2 :
		public AvlNode< Node >,
		public OrdinalCompare<int>
{
	MyAvlNode2( ) { }
	MyAvlNode2( const int &key ) : Key( key ) {}

	int Key;
};

struct MyAvlNode : public MyAvlNode1<MyAvlNode>, public MyAvlNode2<MyAvlNode>
{
	MyAvlNode( const int &key ) : 
			MyAvlNode1<MyAvlNode>( key ), MyAvlNode2<MyAvlNode>( key ) { }

	MyAvlNode( const int &key, const int& ) : 
			MyAvlNode1<MyAvlNode>( key ), MyAvlNode2<MyAvlNode>( key ) { }

	int thedata;
};

template class AvlTree< MyAvlNode, int, int, MyAvlNode1<MyAvlNode> >;

#define INITIAL_ENTRIES 60000

#define VERIFY_PERIOD 1000
#define ACTION_CHANGE_PERIOD 100000

#define INCREMENT_VARIATION 10
#define OUTBUFSIZE 100

int NewIndex(int increment, int oldIndex)
{
	if ( increment == 0 )
		return random() % INITIAL_ENTRIES;
	else
		return (oldIndex + increment) % INITIAL_ENTRIES;
}

void StatsHeader();
void PrintStats(int curRound, int increment, int action, int index, int nodeCount);

void testAvlTree()
{
	srandom( time(0) );

	typedef AvlNodeValue< int, int, OrdinalCompare<int> > TreeNode;
	AvlTree< TreeNode, int, int > tree;

	int increment = 0;
	int index = 0;
	int action = 1;

	StatsHeader();

	for ( int curRound = 0; true; curRound++ ) {
		if ( action&0x1 ) {
			/* Insert One. */
			index = NewIndex( increment, index );
			PrintStats( curRound, increment, action, index, tree.NodeCount );
			tree.Insert( index );
		}

		if ( action&0x2 ) {
			/* Delete one. */
			index = NewIndex( increment, index );
			PrintStats( curRound, increment, action, index, tree.NodeCount );
			AvlNodeValue< int, int, OrdinalCompare<int> > *node = tree.DetachNode( index );
			if ( node != 0 )
				delete node;
		}

		if ( curRound % VERIFY_PERIOD == 0 )
			tree.VerifyIntegrity();

		if ( curRound % ACTION_CHANGE_PERIOD == 0 ) {
			increment = random() % 2;
			if ( increment > 0 )
				increment = random() % INCREMENT_VARIATION;

			action = (random()%3) + 1;
		}
	}	
}

void ExpandTab(char *buf, char *dstBuf)
{
	int pos = 10;
	char *src = buf;
	char *dst = dstBuf;

	while ( *src != 0 ) {
		if ( *src == '\t' ) {
			*dst++ = ' ';
			while ( dst - dstBuf < pos )
				*dst++ = ' ';
			pos += 8;
		}
		else
			*dst++ = *src;
		src++;
	}
	*dst = 0;
}

void StatsHeader()
{
	char buf[OUTBUFSIZE];
	ExpandTab("round\tinc\tins\trem\tindex\tnodes\n", buf);
	fputs(buf, stdout);
}

void PrintStats(int curRound, int increment, int action, int index, int nodeCount)
{
	/* Print stats. */
	char buf1[OUTBUFSIZE];
	char buf2[OUTBUFSIZE];
	memset( buf1, '\b', OUTBUFSIZE );
	fwrite( buf1, 1, OUTBUFSIZE, stdout );
	sprintf(buf1, "%i\t%i\t%s\t%s\t%i\t%i\t", curRound, increment,
			action&0x1 ? "yes" : "no", action&0x2 ? "yes" : "no", index, nodeCount );
	ExpandTab(buf1, buf2);
	fputs(buf2, stdout);
	fflush(stdout);
}



int main() {
	testAvlTree();
	return 0;
}

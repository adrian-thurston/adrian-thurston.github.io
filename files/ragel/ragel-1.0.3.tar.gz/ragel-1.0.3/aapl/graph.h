/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_GRAPH_H
#define _AAPL_GRAPH_H

#include "doublelist.h"
#include "bstable.h"
#include "mergesort.h"
#include "assert.h"


template < class State,
			class Key,
			class Transition > struct GraphState 
		: public DoubleListEl<State>
{
	GraphState() : stateMap(0), Num(0) {}

	/****************************************
	 * TransitionKey
	 *
	 * This is they key that identifies a transition. Transitions
	 * are keyed on the character that they act on and the state
	 * they go to.
	 */
	struct TransitionKey
	{
		TransitionKey() : onChar(0), toState(0) {}
		TransitionKey(const Key &onChar, State *toState) :
				onChar(onChar), toState(toState) { }

		/* Character the trans is on. */
		Key onChar;

		/* State the trans goes to. */
		State *toState;
	};


	/****************************************
	 * TransitionKeyCompare
	 *
	 * Compare TransitionKeys. onChars are first order and State are second
	 * order. This ensures that transitions that are on the same character
	 * always end up next to each other in the TransitionList. When it
	 * comes time to find non-deterministic transitions, our life becomes
	 * much easier.
	 */
	struct TransitionKeyCompare
	{
		static inline int Compare(const TransitionKey &key1,
				const TransitionKey &key2)
		{
			if ( key1.onChar < key2.onChar )
				return -1;
			else if ( key1.onChar > key2.onChar )
				return 1;
			else
			{
				if ( key1.toState < key2.toState )
					return -1;
				else if ( key1.toState > key2.toState )
					return 1;
				else
					return 0;
			}
		}
	};

	/****************************************
	 * TransitionEl
	 *
	 * This structure is the element in the transition list.
	 * It contains the Key(TransitionKey) and the Value(Transition).
	 */
	typedef BSElement<TransitionKey, Transition*> TransitionEl;

	/****************************************
	 * TransitionElCompare
	 */
	struct TransitionElCompare
	{
		static inline int Compare(const TransitionEl &el1,
				const TransitionEl &el2)
			{ return TransitionKeyCompare::Compare(el1.Key, el2.Key); }
	};

	/****************************************
	 * TransitionList
	 *
	 * This structure is the list of transions. Every state maintains
	 * two of these: InList and OutList.
	 */
	typedef BSTable<TransitionKey, Transition*, TransitionKeyCompare>
		TransitionList;

	/* TransitionLists. */
	TransitionList InList, OutList;

	/* When duplicating the fsm we need a map of state to new state. */
	State *stateMap;

	/* The number of the state, for printing. */
	int Num;
};

/****************************************
 * template Graph
 */
template < class State,
			class Key,
			class Transition > struct Graph
		: public DoubleList< State >
{
public:
	typename State::TransitionEl *LastTransElFrom, *LastTransElTo;

	Graph() : DoubleList<State>(), LastTransElFrom(0), LastTransElTo(0) {}
	Graph(Graph &graph);
	~Graph();

	void SetStateNumbers();

	Transition *GetLastTrans() { return LastTransElFrom->Value; }
	void SetLastTrans(Transition *trans) {
		LastTransElFrom->Value = trans;
		LastTransElTo->Value = trans;
	}

	bool AttachStates(State *from, State *to, Key onChar);
	Transition *AttachStatesWithTrans(State *from, State *to, Key onChar);
	Transition *DetachStates(State *from, State *to, Key onChar);

	void AddToGraph(State *state)
		{ DoubleList<State>::AddEnd( state ); }
	State *DetachState(State *state);

	State *DetachInTrans(State *state);
	State *DetachOutTrans(State *state);

	void DumpTransitions( FILE *file, typename State::TransitionList *list );
	void Dump( FILE *file );
};

#endif /* _AAPL_GRAPH_H */

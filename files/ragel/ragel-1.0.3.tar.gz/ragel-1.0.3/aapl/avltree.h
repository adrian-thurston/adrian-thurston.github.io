/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_AVLTREE_H
#define _AAPL_AVLTREE_H

#include "compare.h"

#if defined( AAPL_NOBASEREF )
#	define BASEREF(name) name
#else
#	define BASEREF(name) BaseNode::name
#endif


/**********************************************************
 * AVLNode
 */
template<class Node> struct AvlNode
{
	/* FIXME: This constructor should now be able to disappear
	 * as insert guarantees these values on insert. */
	AvlNode() :
		Left(0), Right(0), Parent(0),
		Height(1) { }

	/* Tree pointers, height. For avl management. */
	Node *Left, *Right, *Parent;
	int Height;
};

/**********************************************************
 * AvlNodeValue
 *
 * This is an avl node that is not intended to be subclassed.
 * Instead it is used as the node itself.
 */
template<class KeyT, class ValueT, class Compare> struct AvlNodeValue :
		public AvlNode< AvlNodeValue<KeyT, ValueT, Compare> >,
		public Compare
{
	AvlNodeValue() { }
	AvlNodeValue(const KeyT &key) : Key(key) { }
	AvlNodeValue(const KeyT &key, const ValueT &value) : Key(key), Value(value) { }

	KeyT Key;
	ValueT Value;
};

/**********************************************************
 * AVLTree
 */
template < class Node, class KeyT, class ValueT, class BaseNode = Node > class AvlTree
{
public:
	AvlTree() :
		Head(0),
		NodeCount(0) { }

	/* Insert a node into the tree. Returns true if insert
	 * succeeded. False otherwise. */
	Node *Insert(Node *node, Node **lastFound = NULL);
	Node *Insert(const KeyT &key, Node **lastFound = NULL);
	Node *Insert(const KeyT &key, const ValueT &val, Node **lastFound = NULL );

	/* Find a node in the tree. Returns the node if 
	 * key exists, false otherwise. */
	Node *Find(const KeyT &key, Node **lastFound = NULL);

	/* Remove a node in the tree. */
	Node *DetachNode(const KeyT &key);
	Node *DetachNode(Node *node);

	/* Free all memory used by tree. */
	void DeleteNodes();

	/* Abandon all nodes in the tree. Does not delete nodes. */
	void EmptyTree();

	Node *Head;
	int NodeCount;

	/* For debugging/testing. Verify the tree properties. */
	void VerifyIntegrity()
		{VerifyIntegrity(Head, 0);}

private:

	/* For debugging/testing. Verify the tree properties. */
	void VerifyIntegrity(Node *node, Node *parent);

	/* Recursively delete nodes in the tree. */
	void DeleteChildrenOf(Node *n);

	/* Rebalance the tree beginning at the leaf whose 
	 * grandparent is unbalanced. */
	Node *Rebalance(Node *start);

	/* Move up the tree from a given node, recalculating the heights. */
	void RecalculateHeights(Node *start);

	/* Move up the tree and find the first node whose 
	 * grand-parent is unbalanced. */
	Node *FindFirstUnbalancedGP(Node *start);

	/* Move up the tree and find the first node which is unbalanced. */
	Node *FindFirstUnbalancedNode(Node *start);

	/* Replace a node in the tree with another node not in the tree. */
	void ReplaceNode(Node *node, Node *replacement);

	/* Remove a node from the tree and put another (normally a child of node)
	 * in its place. */
	void RemoveNode(Node *node, Node *filler);
};

/****************************************************************************
 * AVLTree::Insert()
 *
 * Insert a node in the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		Insert( Node *node, Node **lastFound )
{
	int keyRelation;
	Node *curNode = Head, *parentNode = 0;
	enum { left, right } direction = left;

	while (true)
	{
		if ( curNode == 0 )
		{
			/* We are at an external node and did not find the
			 * key we were looking for.  */
			NodeCount++;

			/* Set node's parent. */
			node->BASEREF(Parent) = parentNode;

			/* New node always starts as a leaf with height 1. */
			node->BASEREF(Left) = 0;
			node->BASEREF(Right) = 0;
			node->BASEREF(Height) = 1;

			/* Are we inserting the head? */
			if ( parentNode ) {
				if (direction == left)
					parentNode->BASEREF(Left) = node;
				else
					parentNode->BASEREF(Right) = node;
			}
			else
				Head = node;

			/* Recalculate the heights. */
			RecalculateHeights(parentNode);

			/* Find the first unbalance. */
			Node *ub = FindFirstUnbalancedGP(node);

			/* Rebalance. */
			if ( ub != 0 )
			{
				/* We assert that after this single rotation the tree is now
				 * properly balanced. */
				Rebalance(ub);
			}

			if ( lastFound != NULL )
				*lastFound = node;
			return node;
		}

		keyRelation = BaseNode::Compare(node->BASEREF(Key), curNode->BASEREF(Key));

		/* Do we go left? */
		if ( keyRelation < 0 )
		{
			direction = left;
			parentNode = curNode;
			curNode = curNode->BASEREF(Left);
		}
		/* Do we go right? */
		else if ( keyRelation > 0 )
		{
			direction = right;
			parentNode = curNode;
			curNode = curNode->BASEREF(Right);
		}
		/* We have hit the target. */
		else
		{
			if ( lastFound != NULL )
				*lastFound = curNode;
			return 0;
		}
	}
}

/****************************************************************************
 * AVLTree::Insert()
 *
 * Insert a node in the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		Insert( const KeyT &key, const ValueT &val, Node **lastFound )
{
	int keyRelation;
	Node *curNode = Head, *parentNode = 0;
	enum { left, right } direction = left;

	while (true)
	{
		if ( curNode == 0 )
		{
			/* We are at an external node and did not find the
			 * key we were looking for.  */
			NodeCount++;

			/* Create the new node. */
			Node *node = new Node( key, val );

			/* Set node's parent. */
			node->BASEREF(Parent) = parentNode;

			/* New node always starts as a leaf with height 1. */
			node->BASEREF(Left) = 0;
			node->BASEREF(Right) = 0;
			node->BASEREF(Height) = 1;

			/* Are we inserting the head? */
			if ( parentNode ) {
				if (direction == left)
					parentNode->BASEREF(Left) = node;
				else
					parentNode->BASEREF(Right) = node;
			}
			else
				Head = node;

			/* Recalculate the heights. */
			RecalculateHeights(parentNode);

			/* Find the first unbalance. */
			Node *ub = FindFirstUnbalancedGP(node);

			/* Rebalance. */
			if ( ub != 0 )
			{
				/* We assert that after this single rotation the tree is now
				 * properly balanced. */
				Rebalance(ub);
			}

			if ( lastFound != NULL )
				*lastFound = node;
			return node;
		}

		keyRelation = BaseNode::Compare(key, curNode->BASEREF(Key));

		/* Do we go left? */
		if ( keyRelation < 0 )
		{
			direction = left;
			parentNode = curNode;
			curNode = curNode->BASEREF(Left);
		}
		/* Do we go right? */
		else if ( keyRelation > 0 )
		{
			direction = right;
			parentNode = curNode;
			curNode = curNode->BASEREF(Right);
		}
		/* We have hit the target. */
		else
		{
			if ( lastFound != NULL )
				*lastFound = curNode;
			return 0;
		}
	}
}


/****************************************************************************
 * AVLTree::Insert()
 *
 * Insert a node in the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		Insert( const KeyT &key, Node **lastFound )
{
	int keyRelation;
	Node *curNode = Head, *parentNode = 0;
	enum { left, right } direction = left;

	while (true)
	{
		if ( curNode == 0 )
		{
			/* We are at an external node and did not find the
			 * key we were looking for.  */
			NodeCount++;

			/* Create the new node. */
			Node *node = new Node( key );

			/* Set node's parent. */
			node->BASEREF(Parent) = parentNode;
			
			/* New node always starts as a leaf with height 1. */
			node->BASEREF(Left) = 0;
			node->BASEREF(Right) = 0;
			node->BASEREF(Height) = 1;

			/* Are we inserting the head? */
			if ( parentNode ) {
				if (direction == left)
					parentNode->BASEREF(Left) = node;
				else
					parentNode->BASEREF(Right) = node;
			}
			else
				Head = node;

			/* Recalculate the heights. */
			RecalculateHeights(parentNode);

			/* Find the first unbalance. */
			Node *ub = FindFirstUnbalancedGP(node);

			/* Rebalance. */
			if ( ub != 0 )
			{
				/* We assert that after this single rotation the tree is now
				 * properly balanced. */
				Rebalance(ub);
			}

			if ( lastFound != NULL )
				*lastFound = node;
			return node;
		}

		keyRelation = BaseNode::Compare(key, curNode->BASEREF(Key));

		/* Do we go left? */
		if ( keyRelation < 0 )
		{
			direction = left;
			parentNode = curNode;
			curNode = curNode->BASEREF(Left);
		}
		/* Do we go right? */
		else if ( keyRelation > 0 )
		{
			direction = right;
			parentNode = curNode;
			curNode = curNode->BASEREF(Right);
		}
		/* We have hit the target. */
		else
		{
			if ( lastFound != NULL )
				*lastFound = curNode;
			return 0;
		}
	}
}


/****************************************************************************
 * AVLTree::Find()
 *
 * Find a node in the tree given a key.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		Find(const KeyT &key, Node **lastFound)
{
	Node *curNode = Head;
	int keyRelation;

	while (curNode) {
		keyRelation = BaseNode::Compare(key, curNode->BASEREF(Key));

		/* Do we go left? */
		if ( keyRelation < 0 )
			curNode = curNode->BASEREF(Left);
		/* Do we go right? */
		else if ( keyRelation > 0 )
			curNode = curNode->BASEREF(Right);
		/* We have hit the target. */
		else {
			if ( lastFound != NULL )
				*lastFound = curNode;
			return curNode;
		}
	}
	if ( lastFound != NULL )
		*lastFound = 0;
	return 0;
}


/******************************************************
 * AvlTree::DetachNode
 *
 * Free all the memory used by the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		DetachNode(const KeyT &key)
{
	Node *node = Find( key );
	if ( node ) {
		DetachNode(node);
	}

	return node;
}

/******************************************************
 * AvlTree::DetachNode
 *
 * Free all the memory used by the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		DetachNode(Node *node)
{
	Node *replacement, *fixfrom;
	int lheight, rheight;

	/* Update NodeCount. */
	NodeCount--;

	/* Find a replacement node. */
	if (node->BASEREF(Right))
	{
		/* Find the leftmost node of the right subtree. */
		replacement = node->BASEREF(Right);
		while (replacement->BASEREF(Left))
			replacement = replacement->BASEREF(Left);

		/* If replacing the node the with
		 * its child then we need to start fixing at the replacement.
		 * otherwise we start replacing at the parent of the replacement.
		 */
		if (replacement->BASEREF(Parent) == node)
			fixfrom = replacement;
		else
			fixfrom = replacement->BASEREF(Parent);

		RemoveNode(replacement, replacement->BASEREF(Right));
		ReplaceNode(node, replacement);
	}
	else if (node->BASEREF(Left))
	{
		/* Find the rightmost node of the left subtree. */
		replacement = node->BASEREF(Left);
		while (replacement->BASEREF(Right))
			replacement = replacement->BASEREF(Right);

		/* If replacing the node the with
		 * its child then we need to start fixing at the replacement.
		 * otherwise we start replacing at the parent of the replacement.
		 */
		if (replacement->BASEREF(Parent) == node)
			fixfrom = replacement;
		else
			fixfrom = replacement->BASEREF(Parent);

		RemoveNode(replacement, replacement->BASEREF(Left));
		ReplaceNode(node, replacement);
	}
	else
	{
		/* We need to start fixing at the parent of the node. */
		fixfrom = node->BASEREF(Parent);

		/* The node we are deleting is a leaf node. */
		RemoveNode(node, 0);
	}

	/* If fixfrom is null it means we just deleted
	 * the head of the tree. */
	if ( fixfrom == 0 )
		return node;

	/* Fix the heights. after the deletion. */
	RecalculateHeights(fixfrom);

	/* Fix every unbalanced node going up in the tree. */
	Node *ub = FindFirstUnbalancedNode(fixfrom);
	while ( ub )
	{
		/* Find the node to rebalance by moving down from the first unbalanced
		 * node 2 levels in the direction of the greatest heights. On the
		 * second move down, the heights may be equal ( but not on the first ).
		 * In which case go in the direction of the first move. */
		lheight = ub->BASEREF(Left) ? ub->BASEREF(Left)->BASEREF(Height) : 0;
		rheight = ub->BASEREF(Right) ? ub->BASEREF(Right)->BASEREF(Height) : 0;
		ASSERT( lheight != rheight );
		if (rheight > lheight)
		{
			ub = ub->BASEREF(Right);
			lheight = ub->BASEREF(Left) ? ub->BASEREF(Left)->BASEREF(Height) : 0;
			rheight = ub->BASEREF(Right) ? ub->BASEREF(Right)->BASEREF(Height) : 0;
			if (rheight > lheight)
				ub = ub->BASEREF(Right);
			else if (rheight < lheight)
				ub = ub->BASEREF(Left);
			else
				ub = ub->BASEREF(Right);
		}
		else
		{
			ub = ub->BASEREF(Left);
			lheight = ub->BASEREF(Left) ? ub->BASEREF(Left)->BASEREF(Height) : 0;
			rheight = ub->BASEREF(Right) ? ub->BASEREF(Right)->BASEREF(Height) : 0;
			if (rheight > lheight)
				ub = ub->BASEREF(Right);
			else if (rheight < lheight)
				ub = ub->BASEREF(Left);
			else
				ub = ub->BASEREF(Left);
		}


		/* Rebalance returns the grandparant of the subtree formed
		 * by the nodes that were rebalanced.
		 * We must continue upward from there rebalancing. */
		fixfrom = Rebalance(ub);

		/* Find the next unbalaced node. */
		ub = FindFirstUnbalancedNode(fixfrom);
	}

	return node;
}

/******************************************************
 * AvlTree::DeleteNodes
 *
 * Free all the memory used by the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		void AvlTree<Node, KeyT, ValueT, BaseNode>::
		DeleteNodes()
{
	if ( Head ) {
		DeleteChildrenOf(Head);
		delete Head;
		Head = 0;
		NodeCount = 0;
	}
}

/******************************************************
 * AvlTree::EmptyTree
 *
 * Abandon all nodes in the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		void AvlTree<Node, KeyT, ValueT, BaseNode>::
		EmptyTree()
{
	Head = 0;
	NodeCount = 0;
}

/******************************************************
 * AvlTree::DeleteChildrenOf
 *
 * Recursively delete all the children of a node.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		void AvlTree<Node, KeyT, ValueT, BaseNode>::
		DeleteChildrenOf( Node *node )
{
	/* Recurse left. */
	if (node->BASEREF(Left)) {
		DeleteChildrenOf(node->BASEREF(Left));

		/* Delete left node. */
		delete node->BASEREF(Left);
		node->BASEREF(Left) = 0;
	}

	/* Recurse right. */
	if (node->BASEREF(Right)) {
		DeleteChildrenOf(node->BASEREF(Right));

		/* Delete right node. */
		delete node->BASEREF(Right);
		node->BASEREF(Left) = 0;
	}
}

/********************************************************************
 * AvlTree::Rebalance
 *
 * Rebalance from a node whose gradparent is unbalanced. Only
 * call on a node that has a grandparent.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		Rebalance(Node *n)
{
	int lheight, rheight;
	Node *a, *b, *c;
	Node *t1, *t2, *t3, *t4;

	Node *p = n->BASEREF(Parent);      /* Parent (Non-NUL). L*/
	Node *gp = p->BASEREF(Parent);     /* Grand-parent (Non-NULL). */
	Node *ggp = gp->BASEREF(Parent);   /* Great grand-parent (may be NULL). */

	if (gp->BASEREF(Right) == p)
	{
		/*  gp
		 *   \
		 *    p
		 */
		if (p->BASEREF(Right) == n)
		{
			/*  gp
			 *   \
			 *    p
			 *     \
			 *      n
			 */
			a = gp;
			b = p;
			c = n;
			t1 = gp->BASEREF(Left);
			t2 = p->BASEREF(Left);
			t3 = n->BASEREF(Left);
			t4 = n->BASEREF(Right);
		}
		else
		{
			/*  gp
			 *     \
			 *       p
			 *      /
			 *     n
			 */
			a = gp;
			b = n;
			c = p;
			t1 = gp->BASEREF(Left);
			t2 = n->BASEREF(Left);
			t3 = n->BASEREF(Right);
			t4 = p->BASEREF(Right);
		}
	}
	else
	{
		/*    gp
		 *   /
		 *  p
		 */
		if (p->BASEREF(Right) == n)
		{
			/*      gp
			 *    /
			 *  p
			 *   \
			 *    n
			 */
			a = p;
			b = n;
			c = gp;
			t1 = p->BASEREF(Left);
			t2 = n->BASEREF(Left);
			t3 = n->BASEREF(Right);
			t4 = gp->BASEREF(Right);
		}
		else
		{
			/*      gp
			 *     /
			 *    p
			 *   /
			 *  n
			 */
			a = n;
			b = p;
			c = gp;
			t1 = n->BASEREF(Left);
			t2 = n->BASEREF(Right);
			t3 = p->BASEREF(Right);
			t4 = gp->BASEREF(Right);
		}
	}

	/* Perform rotation.
	 */

	/* Tie b to the great grandparent. */
	if ( ggp == 0 )
		Head = b;
	else if ( ggp->BASEREF(Left) == gp )
		ggp->BASEREF(Left) = b;
	else
		ggp->BASEREF(Right) = b;
	b->BASEREF(Parent) = ggp;

	/* Tie a as a leftchild of b. */
	b->BASEREF(Left) = a;
	a->BASEREF(Parent) = b;

	/* Tie c as a rightchild of b. */
	b->BASEREF(Right) = c;
	c->BASEREF(Parent) = b;

	/* Tie t1 as a leftchild of a. */
	a->BASEREF(Left) = t1;
	if ( t1 != 0 ) t1->BASEREF(Parent) = a;

	/* Tie t2 as a rightchild of a. */
	a->BASEREF(Right) = t2;
	if ( t2 != 0 ) t2->BASEREF(Parent) = a;

	/* Tie t3 as a leftchild of c. */
	c->BASEREF(Left) = t3;
	if ( t3 != 0 ) t3->BASEREF(Parent) = c;

	/* Tie t4 as a rightchild of c. */
	c->BASEREF(Right) = t4;
	if ( t4 != 0 ) t4->BASEREF(Parent) = c;

	/* The heights are all recalculated manualy and the great
	 * grand-parent is passed to RecalculateHeights() to ensure
	 * the heights are correct up the tree.
	 *
	 * Note that RecalculateHeights() cuts out when it comes across
	 * a height that hasn't changed.
	 */

	/* Fix height of a. */
	lheight = a->BASEREF(Left) ? a->BASEREF(Left)->BASEREF(Height) : 0;
	rheight = a->BASEREF(Right) ? a->BASEREF(Right)->BASEREF(Height) : 0;
	a->BASEREF(Height) = (lheight > rheight ? lheight : rheight) + 1;

	/* Fix height of c. */
	lheight = c->BASEREF(Left) ? c->BASEREF(Left)->BASEREF(Height) : 0;
	rheight = c->BASEREF(Right) ? c->BASEREF(Right)->BASEREF(Height) : 0;
	c->BASEREF(Height) = (lheight > rheight ? lheight : rheight) + 1;

	/* Fix height of b. */
	lheight = a->BASEREF(Height);
	rheight = c->BASEREF(Height);
	b->BASEREF(Height) = (lheight > rheight ? lheight : rheight) + 1;

	/* Fix height of b's parents. */
	RecalculateHeights(ggp);
	return ggp;
}

/********************************************************************
 * AvlTree::RecalculateHeights
 *
 * Recalculates the heights of all the ancestors of node.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		void AvlTree<Node, KeyT, ValueT, BaseNode>::
		RecalculateHeights(Node *node)
{
	int lheight, rheight, new_height;
	while ( node != 0 )
	{
		lheight = node->BASEREF(Left) ? node->BASEREF(Left)->BASEREF(Height) : 0;
		rheight = node->BASEREF(Right) ? node->BASEREF(Right)->BASEREF(Height) : 0;

		new_height = (lheight > rheight ? lheight : rheight) + 1;

		/* If there is no chage in the height, then there will be no
		 * change in any of the ancestor's height. We can stop going up.
		 * If there was a change, continue upward. */
		if (new_height == node->BASEREF(Height))
			return;
		else
			node->BASEREF(Height) = new_height;

		node = node->BASEREF(Parent);
	}
}

/********************************************************************
 * AvlTree::FindFirstUnbalancedGP
 *
 * Finds the first node whose grandparent is unbalanced.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		FindFirstUnbalancedGP(Node *node)
{
	int lheight, rheight, balanceProp;
	Node *gp;

	if ( node == 0 || node->BASEREF(Parent) == 0 ||
			node->BASEREF(Parent)->BASEREF(Parent) == 0 )
		return 0;
	
	/* Don't do anything if we we have no grandparent. */
	gp = node->BASEREF(Parent)->BASEREF(Parent);
	while ( gp != 0 )
	{
		lheight = gp->BASEREF(Left) ? gp->BASEREF(Left)->BASEREF(Height) : 0;
		rheight = gp->BASEREF(Right) ? gp->BASEREF(Right)->BASEREF(Height) : 0;
		balanceProp = lheight - rheight;

		if ( balanceProp < -1 || balanceProp > 1 )
			return node;

		node = node->BASEREF(Parent);
		gp = gp->BASEREF(Parent);
	}
	return 0;
}


/********************************************************************
 * AvlTree::FindFirstUnbalancedGP
 *
 * Finds the first node that is unbalanced.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		Node *AvlTree<Node, KeyT, ValueT, BaseNode>::
		FindFirstUnbalancedNode(Node *node)
{
	if ( node == 0 )
		return 0;
	
	while ( node != 0 )
	{
		int lheight = node->BASEREF(Left) ? node->BASEREF(Left)->BASEREF(Height) : 0;
		int rheight = node->BASEREF(Right) ? node->BASEREF(Right)->BASEREF(Height) : 0;
		int balanceProp = lheight - rheight;

		if ( balanceProp < -1 || balanceProp > 1 )
			return node;

		node = node->BASEREF(Parent);
	}
	return 0;
}

/********************************************************************
 * AvlTree::ReplaceNode
 *
 * Replace a node in the tree with another node not in the tree.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		void AvlTree<Node, KeyT, ValueT, BaseNode>::
		ReplaceNode(Node *node, Node *replacement)
{
	Node *parent = node->BASEREF(Parent),
		*left = node->BASEREF(Left),
		*right = node->BASEREF(Right);

	replacement->BASEREF(Left) = left;
	if (left)
		left->BASEREF(Parent) = replacement;
	replacement->BASEREF(Right) = right;
	if (right)
		right->BASEREF(Parent) = replacement;

	replacement->BASEREF(Parent) = parent;
	if (parent)
	{
		if (parent->BASEREF(Left) == node)
			parent->BASEREF(Left) = replacement;
		else
			parent->BASEREF(Right) = replacement;
	}
	else
		Head = replacement;

	replacement->BASEREF(Height) = node->BASEREF(Height);
}

/********************************************************************
 * AvlTree::RemoveNode
 *
 * Removes a node from a tree and puts filler in it's place.
 * Filler should be null or a child of node.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		void AvlTree<Node, KeyT, ValueT, BaseNode>::
		RemoveNode(Node *node, Node *filler)
{
	Node *parent = node->BASEREF(Parent);

	if (parent)
	{
		if (parent->BASEREF(Left) == node)
			parent->BASEREF(Left) = filler;
		else
			parent->BASEREF(Right) = filler;
	}
	else
		Head = filler;
	
	if (filler)
		filler->BASEREF(Parent) = parent;

	return;
}

/********************************************************************
 * AvlTree::VerifyIntegrity
 *
 * Verify the balance property of the avl tree
 * Verify binary tree propery as well as parent/child pointers are correct.
 */
template <class Node, class KeyT, class ValueT, class BaseNode >
		void AvlTree<Node, KeyT, ValueT, BaseNode>::
		VerifyIntegrity(Node *node, Node *parent)
{
	int lheight, rheight, balanceProp;
	if ( node == 0 )
		return;

	lheight = node->BASEREF(Left) ? node->BASEREF(Left)->BASEREF(Height) : 0;
	rheight = node->BASEREF(Right) ? node->BASEREF(Right)->BASEREF(Height) : 0;

	balanceProp = lheight - rheight;

	ASSERT( -1 <= balanceProp && balanceProp <= 1 );
	ASSERT( node->BASEREF(Parent) == parent);

	if ( node->BASEREF(Left) ) {
		ASSERT( BaseNode::Compare( node->BASEREF(Key), 
				node->BASEREF(Left)->BASEREF(Key) ) > 0 );
	}

	if ( node->BASEREF(Right) ) {
		ASSERT( BaseNode::Compare( node->BASEREF(Key),
				node->BASEREF(Right)->BASEREF(Key) ) < 0 );
	}

	VerifyIntegrity(node->BASEREF(Left), node);
	VerifyIntegrity(node->BASEREF(Right), node);
	return;
}

/* Finished with this. */
#undef BASEREF

#endif /* _AAPL_AVLTREE_H */

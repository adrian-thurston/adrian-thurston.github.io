/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_VECTORSET_H
#define _AAPL_VECTORSET_H

#include "compare.h"
#include "vector.h"

template
		<
			class KeyT,
			class Compare,
			class TableT = ExpnTable<KeyT>
		>
		class VectorSet
				: public Vector<KeyT, TableT>
{
public:
	typedef Vector<KeyT, TableT> BaseType;

	/* Set items in the vector set. */
	void Set(const VectorSet<KeyT, Compare, TableT> &otherSet);
	bool Set(const KeyT &val, KeyT **lastFound = NULL);

	/* Unset an item in the vector set. */
	bool UnSet(const KeyT &val);

	/* Find and is set. */
	bool IsSet(const KeyT &val);
	KeyT *Find(const KeyT &val, KeyT **lastFound = NULL);
};

template< class KeyT,
			class Compare,
			class TableT >
KeyT *VectorSet<KeyT, Compare, TableT>::
		Find(const KeyT &val, KeyT **lastFound)
{
	KeyT *lower, *mid, *upper;
	int keyRelation;

	if (! Table) {
		if ( lastFound != NULL )
			*lastFound = 0;
		return 0;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1) {
		if ( upper < lower ) {
			if ( lastFound != NULL )
				*lastFound = 0;
			return 0;
		}

		mid = lower + ( (upper-lower) / 2);
		
		keyRelation = Compare::Compare( val, *mid );
		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* if ( keyRelation == 0 ) */ {
			if ( lastFound != NULL )
				*lastFound = mid;
			return mid;
		}
	}
}


template< class KeyT,
			class Compare,
			class TableT >
bool VectorSet<KeyT, Compare, TableT>::IsSet(const KeyT &val)
{
	KeyT *pos = Find(val);
	return pos != 0;
}

template< class KeyT,
			class Compare,
			class TableT >
bool VectorSet<KeyT, Compare, TableT>::UnSet(const KeyT &val)
{
	KeyT *pos = Find(val);
	if (pos != 0) {
		BaseType::Delete(pos - Table);
		return true;
	}
	return false;
}

template< class KeyT,
			class Compare,
			class TableT >
bool VectorSet<KeyT, Compare, TableT>::Set(const KeyT &val, KeyT **lastFound)
{
	KeyT *lower, *mid, *upper;
	int keyRelation, insertPos;

	if (! Table) {
		/* Table is empty. Do the insert. */
		lower = Table;
		goto Insert;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1)
	{
		if ( upper < lower ) {
			/* Did not find the key in the table. Do the insert. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		
		keyRelation = Compare::Compare( val, *mid );
		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* if ( keyRelation == 0 ) */ {
			if ( lastFound != NULL )
				*lastFound = mid;
			return false;
		}
	}

Insert:
    /* Get the insert pos. */
    insertPos = lower - Table;

    /* Do the insert. */
    BaseType::Insert(insertPos, val);

	/* Set lastFound. */
	if ( lastFound != NULL )
		*lastFound = Table + insertPos;
    
    return true; 
}

template< class KeyT,
			class Compare,
			class TableT >
void VectorSet<KeyT, Compare, TableT>::
		Set(const VectorSet<KeyT, Compare, TableT> &otherSet)
{
	KeyT *otherItem = otherSet.Table;
	int otherLen = otherSet.TableLength;
	for (int i = 0; i < otherLen; i++, otherItem++)
		Set(*otherItem);
}

#endif /* _AAPL_VECTORSET_H */

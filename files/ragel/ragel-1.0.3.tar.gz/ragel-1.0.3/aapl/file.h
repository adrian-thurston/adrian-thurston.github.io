/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FILE_H
#define _AAPL_FILE_H

#include <stdio.h>
#include "support.h"

class InFile : public Data
{
public:
	InFile(FILE *file = stdin);

  void AssignFile(FILE *file)    {LineNum = 1; File = file;}
	void Close();
	bool IsOpen()                  {return (File != 0);}

	void OpenForReading(char *filename) 
		{LineNum = 1; File = fopen(filename, "rt");}

	void FeedTo(Data *datac);
	bool FeedNLinesTo(Data *datac, uint lines);

	uint GetLineNum()             {return LineNum;}

protected:
	uint LineNum;
	FILE *File;
};


class OutFile : public Data
{
public:
	OutFile(FILE *file = stdout)  {File = file;} 

  void AssignFile(FILE *file)    {File = file;}
	void Close();
	bool IsOpen()                  {return (File != 0);}


	void OpenForWriting(char *filename) 
		{File = fopen(filename, "wt");}

	void Receive(void* data, uint len);
protected:
	FILE *File;
};


#endif /* _AAPL_FILE_H */

/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_BSTABLE_H
#define _AAPL_BSTABLE_H

#include "vector.h"
#include "compare.h"

#define KEY_DISPLAY_SIZE 20
template<class KeyT, class ValueT> struct BSElement
{
	BSElement() {}
	BSElement(const KeyT &key) : Key(key), Value() {}
	BSElement(const KeyT &key, const ValueT &val) : Key(key), Value(val) {}
	KeyT Key;
	ValueT Value;
};

template
		<
			class KeyT,
			class ValueT,
			class Compare,
			class TableT = ExpnTable< BSElement<KeyT,ValueT> >
		>
		class BSTable : public Vector< BSElement<KeyT,ValueT>, TableT >
{
public:
	typedef BSElement<KeyT, ValueT> ElementType;
	typedef Vector<ElementType, TableT> BaseType;

	BSTable() { }
	BSTable( const BSTable &t );

	ElementType *Insert(const KeyT &key, ElementType **lastFound = NULL);
	ElementType *Insert(const KeyT &key, const ValueT &val, ElementType **lastFound = NULL);

	ElementType *InsertMulti(const KeyT &key, ElementType **lastFound = NULL);
	ElementType *InsertMulti(const KeyT &key, const ValueT &val, ElementType **lastFound = NULL);

	ElementType *Find(const KeyT &key, ElementType **lastFound = NULL);
	bool FindMulti( const KeyT &key, ElementType *&lower, ElementType *&upper );

	int Remove(const KeyT &key);
	int RemoveMulti(const KeyT &key);
	int RemoveItem( ElementType *item );
};

template< class KeyT, class ValueT,
			class Compare,
			class TableT>
BSTable<KeyT, ValueT, Compare, TableT>::
	BSTable(const BSTable<KeyT,ValueT,Compare,TableT> &t) : BaseType( t )
{ }

template< class KeyT, class ValueT,
			class Compare,
			class TableT>
int BSTable<KeyT, ValueT, Compare, TableT>::RemoveMulti(const KeyT &key)
{
	ElementType *low, *high;
	if ( FindMulti(key, low, high) )
	{
		int num = high - low + 1;
		BaseType::Delete(low - Table, high - low + 1);
		return num;
	}
	else
		return 0;
}


template< class KeyT, class ValueT,
			class Compare,
			class TableT>
int BSTable<KeyT, ValueT, Compare, TableT>::Remove(const KeyT &key)
{
	ElementType *el = Find(key);
	if (el)
	{
		BaseType::Delete(el - Table);
		return true;
	}
	else
		return false;
}

template<class KeyT, class ValueT,
			class Compare,
			class TableT>
bool BSTable<KeyT, ValueT, Compare, TableT>::FindMulti(const KeyT &key,
	ElementType *&low, ElementType *&high )
{
	ElementType *lower, *mid, *upper;
	int keyRelation;

	if (! Table)
	{
		return false;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array. */
			return false;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->Key);

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			ElementType *lowEnd = Table - 1;
			ElementType *highEnd = Table + TableLength;

			lower = mid - 1;
			while ( lower != lowEnd && Compare::Compare(key, lower->Key) == 0 )
				lower--;

			upper = mid + 1;
			while ( upper != highEnd && Compare::Compare(key, upper->Key) == 0 )
				upper++;
			
			low = lower + 1;
			high = upper - 1;
			return true;
		}
	}
}

template<class KeyT, class ValueT,
			class Compare,
			class TableT>
BSElement<KeyT, ValueT> *BSTable<KeyT, ValueT, Compare, TableT>::
		Find( const KeyT &key, ElementType **lastFound )
{
	ElementType *lower, *mid, *upper;
	int keyRelation;

	if (! Table)
	{
		if ( lastFound != NULL )
			*lastFound = 0;
		return 0;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array. */
			if ( lastFound != NULL )
				*lastFound = 0;
			return 0;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->Key);

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != NULL )
				*lastFound = mid;
			return mid;
		}
	}
}

template< class KeyT, class ValueT,
			class Compare,
			class TableT>
int BSTable<KeyT, ValueT, Compare, TableT>::RemoveItem( ElementType *item )
{
	if (item != NULL)
	{
		BaseType::Delete(item - Table);
		return true;
	}
	else
		return false;
}

template< class KeyT, class ValueT,
			class Compare,
			class TableT>
BSTable<KeyT, ValueT, Compare, TableT>::
		ElementType *BSTable<KeyT, ValueT, Compare, TableT>::
		InsertMulti(const KeyT &key, const ValueT &val, ElementType **lastFound)
{
	ElementType *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (TableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = Table;
		goto Insert;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->Key);

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			lower = mid;
			goto Insert;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - Table;

	/* Do the insert. */
	TableLength = MakeRawSpaceFor(insertPos, 1);
	new(Table + insertPos) ElementType(key, val);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = Table + insertPos;
	return Table + insertPos;
}

template< class KeyT, class ValueT,
			class Compare,
			class TableT>
BSTable<KeyT, ValueT, Compare, TableT>::
		ElementType *BSTable<KeyT, ValueT, Compare, TableT>::
		InsertMulti(const KeyT &key, ElementType **lastFound)
{
	ElementType *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (TableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = Table;
		goto Insert;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->Key);

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			lower = mid;
			goto Insert;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - Table;

	/* Do the insert. */
	TableLength = MakeRawSpaceFor(insertPos, 1);
	new(Table + insertPos) ElementType(key);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = Table + insertPos;
	return Table + insertPos;
}


template< class KeyT, class ValueT,
			class Compare,
			class TableT>
BSTable<KeyT, ValueT, Compare, TableT>::
		ElementType *BSTable<KeyT, ValueT, Compare, TableT>::
		Insert(const KeyT &key, const ValueT &val, ElementType **lastFound)
{
	ElementType *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (TableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = Table;
		goto Insert;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->Key);

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != NULL )
				*lastFound = mid;
			return 0;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - Table;

	/* Do the insert. */
	TableLength = MakeRawSpaceFor(insertPos, 1);
	new(Table + insertPos) ElementType(key, val);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = Table + insertPos;
	return Table + insertPos;
}


template< class KeyT, class ValueT,
			class Compare,
			class TableT>
BSTable<KeyT, ValueT, Compare, TableT>::
		ElementType *BSTable<KeyT, ValueT, Compare, TableT>::
		Insert(const KeyT &key, ElementType **lastFound)
{
	ElementType *lower, *mid, *upper;
	int keyRelation, insertPos;


	if (TableLength == 0)
	{
		/* If the table is empty then go
		 * straight to insert. */
		lower = Table;
		goto Insert;
	}

	lower = Table;
	upper = Table + TableLength - 1;
	while (1)
	{
		if ( upper < lower )
		{
			/* Did not find the fd in the array.
			 * Place to insert at is lower. */
			goto Insert;
		}

		mid = lower + ( (upper-lower) / 2);
		keyRelation = Compare::Compare(key, mid->Key);

		if ( keyRelation < 0 )
			upper = mid - 1;
		else if ( keyRelation > 0 )
			lower = mid + 1;
		else /* keyRelation == 0 */
		{
			if ( lastFound != NULL )
				*lastFound = mid;
			return 0;
		}
	}

Insert:
	/* Get the insert pos. */
	insertPos = lower - Table;

	/* Do the insert. */
	TableLength = MakeRawSpaceFor(insertPos, 1);
	new(Table + insertPos) ElementType(key);

	/* Set lastFound */
	if ( lastFound != NULL )
		*lastFound = Table + insertPos;
	return Table + insertPos;
}

#endif /* _AAPL_BSTABLE_H */

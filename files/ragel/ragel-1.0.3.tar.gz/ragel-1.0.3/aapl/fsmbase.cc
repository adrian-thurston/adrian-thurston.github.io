/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_FSMBASE_CC
#define _AAPL_FSMBASE_CC

#include <string.h>

#if defined( AAPL_NOBASEREF )
#	define BASEREF(name) name
#else
#	define BASEREF(name) ListEl::name
#endif


/****************************************
 * MarkIndexTmpl Constructor
 */
template < class State > MarkIndexTmpl<State>::
		MarkIndexTmpl( int states ) : numStates(states)
{
	/* Total pairs is states^2. Actually only use half of these. */
	int total = states * states;

	/* New up chars so that individual DoubleListEl constructors are
	 * not called. Zero out the mem manually. */
	array = (StatePair*) new char[sizeof(StatePair) * total];
	memset( array, 0, sizeof(StatePair) * total );
}

/****************************************
 * MarkIndexTmpl Destructor
 */
template < class State >MarkIndexTmpl<State>::~MarkIndexTmpl()
{
	delete[] (char*) array;
}

/****************************************
 * MarkIndexTmpl::MarkPair
 */
template < class State > void MarkIndexTmpl<State>::
		MarkPair(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	ASSERT( ! array[pos].isMarked );
	array[pos].isMarked = true;
	markedList.AddEnd( unmarkedList.DetachElement( &array[pos] ) );
}

/****************************************
 * MarkIndexTmpl::IsPairMarked
 */
template < class State > bool MarkIndexTmpl<State>::
		IsPairMarked(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	return array[pos].isMarked;
}

/****************************************
 * MarkIndexTmpl::GetPair
 */
template < class State > MarkIndexTmpl<State>::StatePair *MarkIndexTmpl<State>::
		GetPair(int state1, int state2)
{
	int pos;
	if ( state1 >= state2 )
		pos = ( state1 * numStates ) + state2;
	else
		pos = ( state2 * numStates ) + state1;

	return array + pos;
}


/****************************************
 * FsmState Constructor
 */
template< class State, class TransitionFunc, class Transition >
		FsmState<State, TransitionFunc, Transition>::FsmState() :
		OutList(), InList(),
		outTransFuncTable()
{
	/* General State data. */
	Num = 0;
	stateMap = 0;

	/* No out priority by default. */
	isOutPriorSet = false;
	outPriority = 0;

	/* Fsm State data. */
	IsFinState = false;
	IsMarked = false;
	StateBits = 0;
	stateDictNode = 0;
}

/****************************************
 * FsmState Copy Constructor 
 */
template< class State, class TransitionFunc, class Transition >
		FsmState<State, TransitionFunc, Transition>::
		FsmState(FsmState &other) :
		OutList(other.OutList), InList(other.InList),
		outTransFuncTable(other.outTransFuncTable)
		
{
	/* This Copy Constructor relies on the FsmGraph copy constructor. */

	/* General State data. */
	Num = other.Num;
	stateMap = 0;

	/* Get the out priority stuff. */
	isOutPriorSet = other.isOutPriorSet;
	outPriority = other.outPriority;

	/* Fsm State data. */
	IsFinState = other.IsFinState;
	IsMarked = other.IsMarked;
	StateBits = other.StateBits;
	stateDictNode = other.stateDictNode;

	/* Zero out the in transition list. */
	TransEl *tel = InList.Table;
	int ntel = InList.TableLength;
	for ( int i = 0; i < ntel; i++, tel++ )
		tel->Value = 0;
}

/****************************************
 * FsmState Destructor
 */
template< class State, class TransitionFunc, class Transition >
		FsmState<State, TransitionFunc, Transition>::
		~FsmState()
{
	if ( stateDictNode != 0 )
		delete stateDictNode;
}

/**************************************************************************
 * FsmState::CompareOutTrans
 */
template< class State, class TransitionFunc, class Transition >
		int FsmState<State, TransitionFunc, Transition>::
		CompareOutTrans( const FsmState &state1, const FsmState &state2 )
{
	/* If only one out priority is set then differ. */
	if ( state1.isOutPriorSet && !state2.isOutPriorSet )
		return -1;
	else if ( !state1.isOutPriorSet && state2.isOutPriorSet )
		return 1;
	else if ( state1.isOutPriorSet && state2.isOutPriorSet ) {
		/* Both priorities set, compare the priorites. */
		int outPriorCmp = OrdinalCompare<int>::Compare(
				state1.outPriority, state2.outPriority );
		if ( outPriorCmp != 0 )
			return outPriorCmp;
	}

	/* Test outTransFuncTable. */
	int outTransCmp = Transition::CompareFuncs(
			state1.outTransFuncTable, state2.outTransFuncTable);
	if ( outTransCmp != 0 )
		return outTransCmp;

	return 0;
}

/**************************************************************************
 * FsmState::Compare
 *
 * Compare two pointers to states (actually compares the states they point to).
 * Compare States according to:
 *  Final state status
 *  OutTransitions
 *  Length of lists.
 *    Do any onChar values differ
 *    Do any of the targeted states differ.
 *    Do any of the transitions differ.
 */
template< class State, class TransitionFunc, class Transition >
		int FsmState<State, TransitionFunc, Transition>::
		Compare( const PState state1 , const PState state2 )
{
	/* Test final state status. */
	if ( state1->IsFinState != state2->IsFinState ) {
		if (state1->IsFinState)
			return -1;
		else
			return 1;
	}
	
	/* Compare the out transitions. */
	int outTransCmp = CompareOutTrans( *state1, *state2 );
	if ( outTransCmp )
		return outTransCmp;

	/* Test transition table length. */
	if ( state1->OutList.TableLength != state2->OutList.TableLength ) {
		if ( state1->OutList.TableLength < state2->OutList.TableLength )
			return -1;
		else
			return 1;
	}

	/* Walk the lists, testing onChars, targets, and transitions. */
	TransEl *el1 = state1->OutList.Table;
	TransEl *el2 = state2->OutList.Table;
	int nel = state1->OutList.TableLength;
	for ( int i = 0; i < nel; i++, el1++, el2++ ) {
		/* Test onChar. */
		if ( el1->Key != el2->Key ) {
			if ( el1->Key < el2->Key )
				return -1;
			else
				return 1;
		}

		/* Get transitions. */
		Transition *trans1 = el1->Value;
		Transition *trans2 = el2->Value;

		/* Test targets. */
		if ( trans1->toState != trans2->toState ) {
			if ( trans1->toState < trans2->toState )
				return -1;
			else
				return 1;
		}

		/* Test transitions. */
		int funcCmp = Transition::Compare( *trans1, *trans2 );
		if ( funcCmp != 0 )
			return funcCmp;
	}

	/* Got through the entire state comparison, deem them equal. */
	return 0;
}

template< class State, class TransitionFunc, class Transition >
		void FsmState<State, TransitionFunc, Transition>::
		SetOutFunctions( TransitionFuncTable &funcTable )
{
	TransitionFuncEl *tfel = funcTable.Table;
	int ntfel = funcTable.TableLength;
	for ( int i = 0; i < ntfel; i++, tfel++ )
		outTransFuncTable.InsertMulti( tfel->Key, tfel->Value );
}

/****************************************
 * FsmGraph Copy Constructor
 */
template < class State, class TransitionFunc, class Transition >
		FsmGraph<State, TransitionFunc, Transition>::
		FsmGraph(FsmGraph &graph) :
		StartState(0), FinStateSet()
{
	/* Create the states and record their map in the original state. */
	State *origState = graph.Head;
	while ( origState != 0 ) {
		/* Make the new state. */
		State *newState = new State(*origState);

		/* Add the state to the  */
		BaseListType::AddEnd( newState );

		/* Set the mapsTo item of the old state. */
		origState->stateMap = newState;

		/* Next state. */
		origState = origState->BASEREF(Next);
	}
	
	/* Derefernce all the state maps. */
	State *state = Head;
	while ( state != 0 ) {
		/* Walk the list of out transitions setting and attch transitions
		 * to their corresponding new states. */
		TransEl *tel = state->OutList.Table;
		int ntel = state->OutList.TableLength;
		for (int i = 0; i < ntel; i++, tel++ ) {
			/* Get the trans and the to state. */
			Transition *trans = tel->Value;
			State *to = trans->toState->stateMap;

			/* Make a copy of the transition. */
			trans = new Transition(*trans);
			tel->Value = trans;

			/* This is to simulate a real attaching. */
			trans->fromState = 0;
			trans->toState = 0;
			AttachStates( state, to, trans, tel->Key );
		}
		state = state->BASEREF(Next);
	}

	/* Fix the start state. */
	StartState = graph.StartState->stateMap;
	
	/* Build the final state set. */
	State **st = graph.FinStateSet.Table;
	int nst = graph.FinStateSet.TableLength;
	for ( int i = 0; i < nst; i++, st++ )
		FinStateSet.Set((*st)->stateMap);
}

/****************************************
 * FsmGraph Destructor
 */
template < class State, class TransitionFunc, class Transition >
		FsmGraph<State, TransitionFunc, Transition>::
		~FsmGraph()
{
	/* Delete all the transitions. */
	State *state = Head;
	while ( state != NULL ) {
		TransEl *tel = state->OutList.Table;
		int ntel = state->OutList.TableLength;
		for ( int i = 0; i < ntel; i++, tel++ )
			delete tel->Value;
		state = state->BASEREF(Next);
	}

	/* Delete all the states. */
	BaseListType::DeleteElements();
}

template < class State, class TransitionFunc, class Transition >
		Transition *FsmGraph<State, TransitionFunc, Transition>::
		AttachStates( State *from, State *to, int onChar )
{
	/* Make the transition if it is not there. */
	typename State::TransEl *lastFound;
	if ( from->OutList.Insert( onChar, &lastFound ) )
		lastFound->Value = new Transition();

	/* Get the transition. Maybe we just made one, maybe it was already there. 
	 * If it was already there we will fail on an assert in AttachStates. */
	Transition *trans = lastFound->Value;

	AttachStates( from, to, trans, onChar );
	return trans;
};


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		AttachStates( State *from, State *to, Transition *trans, int onChar )
{
	/* Get the transition and ensure it is unused. */
	ASSERT( trans->toState == NULL );
	ASSERT( trans->fromState == NULL );

	/* Create a new in trans pointer if it is not there. */
	TransEl *lastFound;
	to->InList.Insert( onChar, 0, &lastFound );

	/* Get the pointer on the in transition side. */
	Transition *&inTransPtr = lastFound->Value;

	/* Set the data of the transtion. */
	trans->fromState = from;
	trans->toState = to;

	trans->Next = inTransPtr;
	trans->Prev = 0;

	/* If in trans list is not empty, set the head->Prev to trans. */
	if ( inTransPtr )
		inTransPtr->Prev = trans;

	/* Now insert ourselves at the front of the list. */
	inTransPtr = trans;
};

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		DetachStates(State *from, State *to, Transition *trans, int onChar)
{
	/* Ensure they are hooked up. */
	ASSERT( trans->toState == to );

	/* Get a reference to the head pointer of the inList list for onChar. */
	TransEl *tel = to->InList.Find( onChar );
	ASSERT( tel != NULL );
	Transition *&inTransPtr = tel->Value;

	/* Detach in the inTransList. */
	if (trans->Prev == 0) 
		inTransPtr = trans->Next; 
	else
		trans->Prev->Next = trans->Next; 

	if (trans->Next != 0) 
		trans->Next->Prev = trans->Prev; 
	
	trans->fromState = 0;
	trans->toState = 0;
}

template < class State, class TransitionFunc, class Transition >
		State *FsmGraph<State, TransitionFunc, Transition>::
		DetachState( State *state )
{
	/* Detach the in Transitions. */
	TransEl *tel = state->InList.Table;
	int i, ntel = state->InList.TableLength;
	for ( i = 0; i < ntel; i++, tel++ ) {
		while ( tel->Value ) {
			/* Get pointers to the trans and the stae. */
			Transition *trans = tel->Value;
			State *fromState = trans->fromState;
			/* Detach. */
			DetachStates( fromState, state, trans, tel->Key );
			/* Delete the allocation of the transition in from->OutList. */
			fromState->OutList.Remove( tel->Key );
			delete trans;
		}
	}

	/* Detach the out transitions. */
	tel = state->OutList.Table;
	ntel = state->OutList.TableLength;
	for ( i = 0; i < ntel; i++, tel++ ) {
		DetachStates( state, tel->Value->toState, tel->Value, tel->Key );
		delete tel->Value;
	}

	/* Delete all of the out transition elements. */
	state->OutList.Empty();

	/* Unset final stateness before detaching from graph. */
	if ( state->IsFinState )
		FinStateSet.UnSet( state );

	DetachElement( state );
	return state;
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		SetFinState(State *state)
{
	/* Is it already a fin state. */
	if (state->IsFinState)
		return;
	
	state->IsFinState = true;
	FinStateSet.Set( state );
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		UnsetFinState(State *state)
{
	/* Is it already a fin state. */
	if (! state->IsFinState)
		return;

	state->IsFinState = false;
	FinStateSet.UnSet( state );
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		AllTransPrior( int prior )
{
	State *state = Head;
	while ( state != NULL ) {
		TransEl *tel = state->OutList.Table;
		int ntel = state->OutList.TableLength;
		for (int i = 0; i < ntel; i++, tel++)
			tel->Value->priority = prior;

		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		FinFsmPrior( int prior )
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;

	for (int i = 0; i < nst; i++, st++) {
		State *targ = *st;
		TransEl *tel = targ->InList.Table;
		int ntel = targ->InList.TableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->Value;
			while ( trans != 0 ) {
				trans->priority = prior;
				trans = trans->Next;
			}
		}
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		LeaveFsmPrior( int prior )
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = true;
		(*st)->outPriority = prior;
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		ClearLeaveFsmPrior( )
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;

	for (int i = 0; i < nst; i++, st++) {
		(*st)->isOutPriorSet = false;
		(*st)->outPriority = 0;
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		BaseStartFsmPrior( int prior )
{
	State *state = StartState;
	TransEl *tel = state->OutList.Table;
	int ntel = state->OutList.TableLength;
	for (int i = 0; i < ntel; i++, tel++)
		tel->Value->priority = prior;

	state = state->BASEREF(Next);
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		AllTransFunc( TransitionFunc func, int transOrder )
{
	State *state = Head;
	while ( state != NULL ) {
		TransEl *tel = state->OutList.Table;
		int ntel = state->OutList.TableLength;
		for (int i = 0; i < ntel; i++, tel++)
			tel->Value->SetFunction( func, transOrder );

		state = state->BASEREF(Next);
	}
}

/*******************************************************************
 * NullFunctionKeys
 *
 * Zeros out the function ordering keys. This may be called before condensing
 * when it is known that no more fsm operations are going to be done.
 * This will achieve greater condensing as states will not be separated
 * the the basis of function ordering.
 */
template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		NullFunctionKeys( )
{
	State *state = Head;
	while ( state != NULL ) {
		/* Walk the transitions for the state. */
		TransEl *tel = state->OutList.Table;
		int ntel = state->OutList.TableLength;
		for ( int i = 0; i < ntel; i++, tel++ ) {
			/* Walk the function table for the transition. */
			typename Transition::TransitionFuncEl *tfel =
					tel->Value->transFuncTable.Table;
			int ntfel = tel->Value->transFuncTable.TableLength;
			for ( int j = 0; j < ntfel; j++, tfel++ )
				tfel->Key = 0;
		}
		state = state->BASEREF(Next);
	}
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		FinFsmFunc( TransitionFunc func, int transOrder )
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;

	for (int i = 0; i < nst; i++, st++) {
		State *targ = *st;
		/* FIXME: if the start state is final then it gets a fin func. */
		TransEl *tel = targ->InList.Table;
		int ntel = targ->InList.TableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->Value;
			while ( trans != 0 ) {
				trans->SetFunction( func, transOrder );
				trans = trans->Next;
			}
		}
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		LeaveFsmFunc( TransitionFunc func, int transOrder )
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;
	for (int i = 0; i < nst; i++, st++) {
		(*st)->outTransFuncTable.InsertMulti( transOrder, func );
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		BaseStartFsmFunc( TransitionFunc func, int transOrder )
{
	State *state = StartState;
	TransEl *tel = state->OutList.Table;
	int ntel = state->OutList.TableLength;
	for (int i = 0; i < ntel; i++, tel++)
		tel->Value->SetFunction( func, transOrder );

	state = state->BASEREF(Next);
}

template < class State, class TransitionFunc, class Transition >
		int FsmGraph<State, TransitionFunc, Transition>::
		ShiftStartFuncOrder( int fromOrder )
{
	int maxUsed = 0;
	/* Walk the transition list of the start state. */
	TransEl *tel = StartState->OutList.Table;
	int ntel = StartState->OutList.TableLength;
	for ( int i = 0; i < ntel; i++, tel++ ) {
		/* Walk the function table for the transition. */
		typename Transition::TransitionFuncEl *tfel =
				tel->Value->transFuncTable.Table;

		/* Set the keys to increasing values starting at fromOrder */
		int ntfel = tel->Value->transFuncTable.TableLength;
		int curFromOrder = fromOrder;
		for ( int j = 0; j < ntfel; j++, tfel++ )
			tfel->Key = curFromOrder++;
	
		/* Keep track of the max number of orders used so 
		 * we can return the max. */
		if ( curFromOrder - fromOrder > maxUsed )
			maxUsed = curFromOrder - fromOrder;
	}
	return maxUsed;
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::StripAllTransData()
{
	State *state = Head;
	while ( state ) {
		state->outTransFuncTable.Empty();
		state->isOutPriorSet = false;
		state->outPriority = 0;

		TransEl *tel = state->OutList.Table;
		int ntel = state->OutList.TableLength;
		for (int i = 0; i < ntel; i++, tel++) {
			tel->Value->transFuncTable.Empty();
			tel->Value->priority = 0;
		}

		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		ClearAllTransFunc()
{
	State *state = Head;
	while ( state != NULL ) {
		TransEl *tel = state->OutList.Table;
		int ntel = state->OutList.TableLength;
		for (int i = 0; i < ntel; i++, tel++)
			tel->Value->transFuncTable.Empty();

		state = state->BASEREF(Next);
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		ClearFinFsmFunc()
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;

	for (int i = 0; i < nst; i++, st++) {
		State *targ = *st;
		/* FIXME: if the start state is final then it gets a fin func. */
		TransEl *tel = targ->InList.Table;
		int ntel = targ->InList.TableLength;
		for (int j = 0; j < ntel; j++, tel++) {
			Transition *trans = tel->Value;
			while ( trans != 0 ) {
				trans->transFuncTable.Empty();
				trans = trans->Next;
			}
		}
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		ClearLeaveFsmFunc()
{
	State **st = FinStateSet.Table;
	int nst = FinStateSet.TableLength;
	for (int i = 0; i < nst; i++, st++) {
		(*st)->outTransFuncTable.Empty();
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		ClearStartFsmFunc()
{
	/* FIXME: Implement. */
}

/****************************************************************************
 * FsmAttachStates
 *
 * Attach states according to the rules of an fsm. Requires that srcTrans is
 * not a transition in State from.
 */
template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		FsmAttachStates( StateDict &stateDict, StateFillInList &stfil,
			State *from, State *to, 
			int onChar, Transition *srcTrans, bool leavingFsm, bool ignorePriorities )
{
	int newTransPrior = srcTrans->priority;
	if ( leavingFsm && from->isOutPriorSet )
		newTransPrior = from->outPriority;

	/* Possibly make a new transition. */
	TransEl *lastFound;
	if ( from->OutList.Insert( onChar, &lastFound ) ) {
		/* Make a new transition. */
		lastFound->Value = new Transition();
		Transition *trans = lastFound->Value;

		/* We can attach the transition, one does not exist. */
		AttachStates( from, to, trans, onChar );
		
		/* Flag the targ as getting a new in transition. */
		to->StateBits |= SB_NEWINTRANS;

		/* Copy the transition data from the source transition. */
		trans->priority = newTransPrior;
		trans->transFuncTable.SetAs( srcTrans->transFuncTable );

		/* Call user routine for merging transitions. */
		trans->MergeTransition(srcTrans);

		/* Now that the transition has been properly set up, we can add any out
		 * transition data if necessary. */
		if ( leavingFsm ) {
			/* Get the data from the outTransFuncTable. */
			trans->SetFunctions( from->outTransFuncTable );
		}
	}
	else {
		/* There is a trans already. Get it. */
		Transition *trans = lastFound->Value;

		if ( trans->priority > newTransPrior ) {
			/* The existing trans has a higher priority. We do nothing. No new transition
			 * is made. Nothing is done. */
		}
		else if ( trans->priority < newTransPrior ) {
			/* Toast the existing transition. */
			DetachStates( from, trans->toState, trans, onChar );

			/* Delete the existing transition, it is being replaced and 
			 * make a brand new one to replace it. This is for completeness 
			 * of concept. */
			delete trans;
			lastFound->Value = trans = new Transition();

			/* We can attach the transition, one does not exist. */
			AttachStates( from, to, trans, onChar );

			/* Flag the targ as getting a new in transition. */
			to->StateBits |= SB_NEWINTRANS;

			/* Copy the transition data from the source transition. */
			trans->priority = newTransPrior;
			trans->transFuncTable.SetAs( srcTrans->transFuncTable );

			/* Trans is a merge with srcTrans. */
			trans->MergeTransition(srcTrans);

			/* Now that the transition has been properly set up, we can add any out
			 * transition data if necessary. */
			if ( leavingFsm ) {
				/* Get the data from the outTransFuncTable. */
				trans->SetFunctions( from->outTransFuncTable );
			}
		}
		else {
			/* The priorities are equal. We must merge the transitions.
			 * Does the existing trans go to the trans we are to attach to?
			 * ie, are we to simply double up the transition? */
			State *existingState = trans->toState;
		
			if ( existingState == to ) {
				/* Copy the transition data from the source transition. */
				if ( trans == srcTrans ) {
					typename Transition::TransitionFuncTable
								srcTable( srcTrans->transFuncTable );
					trans->SetFunctions( srcTable );
				}
				else
					trans->SetFunctions( srcTrans->transFuncTable );

				/* Call user routine for merging transitions. */
				trans->MergeTransition(srcTrans);
			}
			else {
				/* The trans is not a double up. trans cannot be the same as srcTrans
				 * Set up the state set. */
				StateSet stateSet;
				/* We go to all the states the existing trans goes to, plus... */
				if ( existingState->stateDictNode == NULL )
					stateSet.Set( existingState );
				else
					stateSet.Set( existingState->stateDictNode->Key );
				/* ... all the states that we have been told to go to. */
				if ( to->stateDictNode == NULL )
					stateSet.Set( to );
				else
					stateSet.Set( to->stateDictNode->Key );

				/* Look for the state. If it is not there already, make it. */
				StateDictNode<State> *lastFound;
				if ( stateDict.Insert( stateSet, &lastFound ) ) {
					/* Make a new State, but it doesn't get added to the list. 
					 * Instead, add it to the stfil list. This means that we
					 * need to fill in it's transitions sometime in the future.
					 * We don't do that now (ie, do not recurse). */
					State *newState = new State();

					/* Link up the dict node and the state. */
					lastFound->targState = newState;
					newState->stateDictNode = lastFound;

					/* Add to the stfil list. */
					stfil.AddEnd( newState );
				}

				/* Get the state insertted/deleted. */
				State *targ = lastFound->targState;

				/* Detach the state from existing state. */
				DetachStates( from, existingState, trans, onChar );

				/* Reattach to the new target. */
				AttachStates( from, targ, trans, onChar );

				/* Flag the targ as getting a new in transition. */
				targ->StateBits |= SB_NEWINTRANS;

				/* Copy the transition data from the source transition. */
				trans->SetFunctions( srcTrans->transFuncTable );

				/* Call user routine for merging transitions. */
				trans->MergeTransition(srcTrans);
			}

			/* Now that the transition has been properly set up, we can add any out
			 * transition data if necessary. */
			if ( leavingFsm ) {
				/* Get the data from the outTransFuncTable. */
				trans->SetFunctions( from->outTransFuncTable );
			}
		}
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		OutTransCopy( StateDict &stateDict, StateFillInList &stfil, 
				State *dest, State *src, bool leavingFsm, bool ignorePriorities )
{
	/* If src == dest we will be modifying a out trans list we are reading
	 * from. Make a copy first. */
	if ( src == dest ) {
		TransListType listCopy(src->OutList);
		OutTransCopy(stateDict, stfil, dest, listCopy, leavingFsm, ignorePriorities );
	}
	else
		OutTransCopy(stateDict, stfil, dest, src->OutList, leavingFsm, ignorePriorities );
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		OutTransCopy( StateDict &stateDict, StateFillInList &stfil, 
				State *dest, TransListType &srcList, bool leavingFsm, bool ignorePriorities )
{
	/* Iterate over the trans, copying them. */
	TransEl *tel = srcList.Table;
	int ntel = srcList.TableLength;
	for (int i = 0; i < ntel; i++, tel++) {
		Transition *trans = tel->Value;
		FsmAttachStates( stateDict, stfil, dest, trans->toState, tel->Key,
				trans, leavingFsm, ignorePriorities );
	}
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		InTransMove(State *dest, State *src)
{
	/* Do not try to move in trans to and from the same state. */
	ASSERT( dest != src );

	TransEl *tel = src->InList.Table;
	int ntel = src->InList.TableLength;
	for ( int i = 0; i < ntel; i++, tel++ ) {
		while ( tel->Value != NULL ) {
			Transition *trans = tel->Value;
			State *fromState = trans->fromState;
			DetachStates( fromState, src, trans, tel->Key );
			AttachStates( fromState, dest, trans, tel->Key );
		}
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MarkPairsOnIn( MarkIndex &markIndex, State *r, State *s )
{
	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->InList.Table;
	TransEl *rEndTransEl = rTransEl + r->InList.TableLength;
	TransEl *sTransEl = s->InList.Table;
	TransEl *sEndTransEl = sTransEl + s->InList.TableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( rTransEl != rEndTransEl && sTransEl != sEndTransEl ) {
		/* Both rPos and sPos are good. Get the characters of the
		 * transitions. */
		rItem = rTransEl->Key;
		sItem = sTransEl->Key;
		if ( rItem < sItem ) {
			/* transitions don't match up. Move ahead in rTransEl. */
			rTransEl++;
		}
		else if ( sItem < rItem ) {
			/* Transitions don't match up. Move ahead in sTransEl. */
			sTransEl++;
		}
		else {
			/* This will stop us from unneccessary looping if r has lots of trans on
			 * this char and s has none. */
			if ( rTransEl->Value != NULL && sTransEl->Value != NULL ) {
				/* Loop over r's transitions on this char. */
				Transition *rTrans = rTransEl->Value;
				while ( rTrans != NULL ) {
					State *p = rTrans->fromState;

					/* Loop over s's transitions on this char. */
					Transition *sTrans = sTransEl->Value;
					while ( sTrans != NULL ) {
						State *q = sTrans->fromState;

						/* If the states are different and not already marked. Then mark. */
						if ( p != q && ! markIndex.IsPairMarked(p->Num, q->Num) )
							markIndex.MarkPair(p->Num, q->Num);
				
						sTrans = sTrans->Next;
					}
					rTrans = rTrans->Next;
				}
			}
			rTransEl++;
			sTransEl++; 
		}
	}
}

template < class State, class TransitionFunc, class Transition >
		bool FsmGraph<State, TransitionFunc, Transition>::
		ShouldMarkPair(MarkIndex &markIndex, State *r, State *s)
{
	bool shouldMarkPair = false;

	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->OutList.Table;
	TransEl *rEndTransEl = rTransEl + r->OutList.TableLength;
	TransEl *sTransEl = s->OutList.Table;
	TransEl *sEndTransEl = sTransEl + s->OutList.TableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( !shouldMarkPair ) {
		/* Are we at the end of r's transitions? */
		if ( rTransEl == rEndTransEl ) {
			/* We are at the end of r's transitions. If we are not at the
			 * end of s's transitions as well then mark. */
			if  ( sTransEl != sEndTransEl )
				shouldMarkPair = true;
			break;
		}
		/* Are we at the end of s's transitions? */
		else if ( sTransEl == sEndTransEl ) {
			/* We are not at the end of r's but at the end of
			 * s's transitions. */
			shouldMarkPair = true;
		}
		else {
			/* Both rPos and sPos are good. Get the characters of the
			 * transitions. */
			rItem = rTransEl->Key;
			sItem = sTransEl->Key;
			if ( rItem < sItem ) {
				/* Transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else if ( sItem < rItem ) {
				/* Transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else {
				if ( markIndex.IsPairMarked( rTransEl->Value->toState->Num,
							sTransEl->Value->toState->Num ) )
					shouldMarkPair = true;

				rTransEl++;
				sTransEl++; 
			}
		}
	}
	return shouldMarkPair;
}

template < class State, class TransitionFunc, class Transition >
		bool FsmGraph<State, TransitionFunc, Transition>::
		ShouldMarkPairTransData(MarkIndex &markIndex, State *r, State *s)
{
	bool shouldMarkPair = false;

	/* Pointers used to walk through r's and s's transition lists. */
	TransEl *rTransEl = r->OutList.Table;
	TransEl *rEndTransEl = rTransEl + r->OutList.TableLength;
	TransEl *sTransEl = s->OutList.Table;
	TransEl *sEndTransEl = sTransEl + s->OutList.TableLength;

	/* The onChar of the transition. */
	int rItem, sItem;

	while ( !shouldMarkPair ) {
		/* Are we at the end of r's transitions? */
		if ( rTransEl == rEndTransEl ) {
			/* We are at the end of r's transitions. If we are not at the
			 * end of s's transitions as well then mark. */
			if ( sTransEl != sEndTransEl )
				shouldMarkPair = true;
			break;
		}
		/* Are we at the end of s's transitions? */
		else if ( sTransEl == sEndTransEl ) {
			/* We are not at the end of r's but at the end of
			 * s's transitions. */
			shouldMarkPair = true;
		}
		else {
			/* Both rPos and sPos are good. Get the characters of the
			 * transitions. */
			rItem = rTransEl->Key;
			sItem = sTransEl->Key;
			if ( rItem < sItem ) {
				/* transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else if ( sItem < rItem ) {
				/* Transitions don't match up. Mark. */
				shouldMarkPair = true;
			}
			else {
				if ( markIndex.IsPairMarked( rTransEl->Value->toState->Num,
							sTransEl->Value->toState->Num ) )
					shouldMarkPair = true;
				else if ( Transition::Compare(*(rTransEl->Value), *(sTransEl->Value)) != 0 )
					shouldMarkPair = true;

				rTransEl++;
				sTransEl++; 
			}
		}
	}
	return shouldMarkPair;
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MarkReachableFromHereReverse( State *state )
{
	/* Base case: return; */
	if (state->IsMarked) return;
	
	/* Set this state as marked. */
	state->IsMarked = true;

	/* Recurse on all items in outlist. */
	TransEl *tel = state->InList.Table;
	int ntel = state->InList.TableLength;
	for (int i = 0; i < ntel; i++, tel++) {
		Transition *trans = tel->Value;
		while ( trans ) {
			MarkReachableFromHereReverse( trans->fromState );
			trans = trans->Next;
		}
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MarkReachableFromHere( State *state )
{
	/* Base case: return; */
	if (state->IsMarked) return;
	
	/* Set this state as marked. */
	state->IsMarked = true;

	/* Recurse on all items in outlist. */
	TransEl *tel = state->OutList.Table;
	int ntel = state->OutList.TableLength;
	for (int i = 0; i < ntel; i++, tel++)
		MarkReachableFromHere( tel->Value->toState );
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		UnmarkReachableFromHere( State *state )
{
	/* Base case: return; */
	if (!state->IsMarked) return;
	
	/* Set this state as marked. */
	state->IsMarked = false;

	/* Recurse on all items in outlist. */
	TransEl *tel = state->OutList.Table;
	int ntel = state->OutList.TableLength;
	for (int i = 0; i < ntel; i++, tel++)
		UnmarkReachableFromHere( tel->Value->toState );
}

/*************************************************************************
 * BuildFsmMachine
 *
 * Construct a compact runnable machine from this graph. Machine is put in
 * the machine object passed in.
 */
template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		BuildFsmMachine( FsmMachine<TransitionFunc> &machine )
{
	/* Make the machine states. */
	InitMachineStates( machine );

	/* The transition map and the running offset. */
	TransMap transMap;
	int curTransOffset = 0;

	/* Make the global error transition. The rest of the fsm building code works on
	 * the assumption that the error trans is index 0. */
	FsmMachTrans<TransitionFunc> errTrans;
	errTrans.toState = 0;
	errTrans.funcs = TRANS_NO_FUNCS;
	transMap.Insert( errTrans, curTransOffset );
	curTransOffset++;

	/* The Function map and the running offset. */
	FuncListMap funcListMap;
	int curFuncOffset = 0;

	State *state = Head;
	while ( state != 0 ) {

		/* Get the fsm state. */
		FsmMachState<TransitionFunc> *machState =
				(FsmMachState<TransitionFunc>*) state->stateMap;

		/* Use the base class to make the machine state. This call will modify
		 * funcListMap, curFuncOffset, and transMap. */
		MakeMachineState( funcListMap, curFuncOffset, transMap, curTransOffset,
				machState, state );

		/* Add the functions in the outFuncs for this state to the funcs map. */
		machState->outFuncs = TRANS_NO_FUNCS;
		int tlen = state->outTransFuncTable.TableLength;
		if ( tlen != 0 ) {
			/* Make a new trans func list from the trans func table (we don't
			 * care about the ordering numbers on the transitions so we make 
			 * a list without the ordering). */
			typename Transition::TransitionFuncList transFuncList;
			Transition::FuncTableToFuncList( transFuncList, state->outTransFuncTable );

			/* If not in the function list map then insert. */
			FuncListMapEl *lastFound;
			if ( funcListMap.Insert( transFuncList, curFuncOffset, &lastFound ) )
					curFuncOffset += ( tlen + 1 );

			/* Get the offset as what was found/inserted in the map. */
			machState->outFuncs = (TransitionFunc*) lastFound->Value;
		}

		state = state->BASEREF(Next);
	}

	/* Save the items in the transMap to trans */
	FsmMachTrans<TransitionFunc> *trans = 0;
	if ( transMap.TableLength > 0 ) {
		/* New up the Transition Table. */
		trans = new FsmMachTrans<TransitionFunc>[curTransOffset];

		/* Walk the transMap and copy to the transitions. The location of the
		 * transition must be the offsets in the Value field because that is
		 * what the index array uses. */
		TransMapEl *tmel = transMap.Table;
		int tmlen = transMap.TableLength;
		for ( int i = 0; i < tmlen; i++, tmel++ )
			trans[tmel->Value] = tmel->Key;
	}

	/* Set the transitions pointer and the number of transitions. */
	machine.allTrans = trans;
	machine.numTrans = curTransOffset;

	/* Walk all transIndex arrays and replace the indicies with ptrs. */
	int i;
	FsmMachState<TransitionFunc> *st = machine.allStates;
	for ( i = 0; i < machine.numStates; i++, st++ ) {
		/* Replace the index for the error transition. */
		int index = (int) st->errIndex;
		st->errIndex = trans + index;

		/* Replace the index for array of indicies. */
		FsmMachTrans<TransitionFunc> **pIndex = st->transIndex;
		for ( int j = 0; j < st->numIndex; j++, pIndex++ ) {
			index = (int) *pIndex;
			*pIndex = trans + index;
		}
	}

	/* If there are any function lists in the function map then we need to copy
	 * them to the new machine. */
	TransitionFunc *transFuncs = 0;
	if ( curFuncOffset != 0 ) {
		/* There was space used. New up the funclist array and then fill it in. */
		transFuncs = new TransitionFunc[curFuncOffset];

		/* For each funclist in the funclist map, copy the list over. */
		FuncListMapEl *flel = funcListMap.Table;
		int nflel = funcListMap.TableLength;
		for ( int i = 0; i < nflel; i++, flel++ ) {
			/* Get a ref to the trans func list and it's offset. */
			typename Transition::TransitionFuncList *tfl = &flel->Key;
			int offset = flel->Value;

			/* Copy the transFuncs at the offset Maybe trans funcs should be
			 * vector and vector. Overwrite should be used. This will do for now. But
			 * then again we require that it is nullable and if we need constructors we like
			 * can't assign 0 to it. Though c++ could do if if you had to. Overkill? */
			memcpy(transFuncs + offset, tfl->Table,
					tfl->TableLength * sizeof(TransitionFunc));

			/* TransitionFunc must be set to something we can nullify in order to
			 * signal the end of a transition function list. */
			transFuncs[offset + tfl->TableLength] = 0;
		}
	}

	/* Set the transition funcs ptr and the number of trans funcs. */
	machine.allTransFuncs = transFuncs;
	machine.numTransFuncs = curFuncOffset;

	/* Walk all transitions and replace the function indicies with ptrs. */
	FsmMachTrans<TransitionFunc> *curTrans = machine.allTrans;
	for ( i = 0; i < machine.numTrans; i++, curTrans++ ) {
		if ( curTrans->funcs != TRANS_NO_FUNCS ) {
			int index = (int) curTrans->funcs;
			curTrans->funcs = transFuncs + index;
		}
		else
			curTrans->funcs = 0;
	}

	/* Walk all states and replace the out function indicies with ptrs. */
	st = machine.allStates;
	for ( i = 0; i < machine.numStates; i++, st++ ) {
		if ( st->outFuncs != TRANS_NO_FUNCS ) {
			int index = (int) st->outFuncs;
			st->outFuncs = transFuncs + index;
		}
		else
			st->outFuncs = 0;
	}
}

/* Creates machine states and assignes each state to a its corresponding
 * state in the fsm graph from which it will be built.
 * Also takes the opprotunity to compute gblLowIndex and gblHighIndex.
 */
template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		InitMachineStates( FsmMachine<TransitionFunc> &newMachine )
{
	/* Make the array of states. */
	int numStates = ListLength;
	FsmMachState<TransitionFunc> *machStates = 
		new FsmMachState<TransitionFunc>[numStates];

	/* Make all the states first and set the mapto values. */
	State *state = Head;
	FsmMachState<TransitionFunc> *curState = machStates;
	for ( int i = 0; i < numStates; i++, curState++ ) {
		/* Init the state. */
		curState->transIndex = 0;
		curState->errIndex = ERR_TRANS_INDEX;
		curState->numIndex = 0;
		curState->lowIndex = MAX_INT;
		curState->highIndex = MIN_INT;
		curState->outFuncs = TRANS_NO_FUNCS;

		/* If the original state is a final state, set the new state final. */
		curState->isFinState = state->IsFinState;

		/* Compute gblLowIndex and gblHighIndex. */
		if ( state->OutList.TableLength > 0 ) {
			int lowKey = state->OutList.Table[0].Key;
			if ( lowKey < newMachine.gblLowIndex )
				newMachine.gblLowIndex = lowKey;

			int highKey = state->OutList.Table[
					state->OutList.TableLength-1].Key + 1;
			if ( highKey > newMachine.gblHighIndex )
				newMachine.gblHighIndex = highKey;
		}

		/* Set the mapto value and go to next state. */
		state->stateMap = (State*) (machStates + i);
		state = state->BASEREF(Next);
	}

	/* Get the start state. */
	newMachine.numStates = numStates;
	newMachine.allStates = machStates;
	newMachine.startState = (FsmMachState<TransitionFunc>*) StartState->stateMap;
}


template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		MakeMachineState( FuncListMap &funcListMap, int &curFuncOffset,
				TransMap &transMap, int &curTransOffset,
				FsmMachState<TransitionFunc> *machState, State *state )
{
	TransEl *tel = state->OutList.Table;
	int ntel = state->OutList.TableLength;

	int lowIndex = MAX_INT;
	int highIndex = MIN_INT;
	int len = 0;

	if ( ntel > 0 ) {
		lowIndex = tel[0].Key;
		/* highIndex is defined to be one past the last valid transition
		 * so high - low == len */
		highIndex = tel[ntel-1].Key + 1;
		len = highIndex - lowIndex;
	}

	if ( len > 0 ) {
		machState->lowIndex = lowIndex;
		machState->highIndex = highIndex;
		machState->transIndex = new FsmMachTrans<TransitionFunc>*[len];
		machState->numIndex = len;
	}

	/* For each transition add the functions to the global function map and
	 * add then transition to the transition map for this state. */
	for ( int i = 0, curIndex = lowIndex; i < ntel; i++, tel++, curIndex++ ) {
		/* While the current index is less than the the next transition to
		 * to add, fill in with an error transition. */
		while ( curIndex < tel->Key ) {
			/* Set the index for this character to the error trans. */
			machState->transIndex[curIndex - lowIndex] = ERR_TRANS_INDEX;
			curIndex++;
		}

		/* Get the state */
		Transition *trans = tel->Value;
		FsmMachState<TransitionFunc> *state =
				(FsmMachState<TransitionFunc>*) trans->toState->stateMap;

		/* Init func offset to no function. */
		int newFuncOffset = -1;

		/* If there are any functions then add them to the map if they
		 * are not already there. */
		int tlen = trans->transFuncTable.TableLength;
		if ( tlen != 0 ) {
			/* Make a new trans func list from the trans func table (we don't care
			 * about the ordering numbers on the transitions so we make a list 
			 * without the ordering). */
			typename Transition::TransitionFuncList transFuncList;
			Transition::FuncTableToFuncList( transFuncList, trans->transFuncTable );

			/* If not in the function list map then insert. */
			FuncListMapEl *lastFound;
			if ( funcListMap.Insert( transFuncList, curFuncOffset, &lastFound ) )
				curFuncOffset += ( tlen + 1 );

			/* Get the offset as what was found/inserted in the map. */
			newFuncOffset = lastFound->Value;
		}
			
		/* We now have the transition for looking up in the transMap. */
		FsmMachTrans<TransitionFunc> machineTrans;
		machineTrans.toState = state;
		machineTrans.funcs = (TransitionFunc*) newFuncOffset;

		/* If not in the transition map, insert it. */
		TransMapEl *lastFound;
		if ( transMap.Insert( machineTrans, curTransOffset, &lastFound ) )
			curTransOffset++;

		/* Get the offset as what was found/inserted in the map. */
		int newTransOffset = lastFound->Value;
			
		/* Set the index for this character. */
		machState->transIndex[curIndex - lowIndex] = 
				(FsmMachTrans<TransitionFunc>*) newTransOffset;
	}
}

template < class State, class TransitionFunc, class Transition >
		void FsmGraph<State, TransitionFunc, Transition>::
		VerifyIntegrity()
{
	State *state = Head;
	while ( state != NULL ) {
		TransEl *tel = state->OutList.Table;
		int i, ntel = state->OutList.TableLength;
	 	for ( i = 0; i < ntel; i++, tel++ ) {
			/* Assert the fromState is correct. */
			ASSERT( tel->Value->fromState == state );
		}

		tel = state->InList.Table;
		ntel = state->InList.TableLength;
		for ( i = 0; i < ntel; i++, tel++ ) {
			Transition *last = 0;
			Transition *trans = tel->Value;
			while ( trans != 0 ) {
				/* Assert the toState is correct. */
				ASSERT( trans->toState == state );
				/* Assert the prev ptr is correct. */
				ASSERT( trans->Prev == last );

				last = trans;
				trans = trans->Next;
			}
		}
		state = state->BASEREF(Next);
	}
}

/* This is no longer needed. */
#undef BASEREF

#endif /* _AAPL_FSMBASE_CC */

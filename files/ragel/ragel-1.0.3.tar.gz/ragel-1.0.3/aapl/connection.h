/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Aapl.
 *
 *  Aapl is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Aapl is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Aapl; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _AAPL_CONNECTIONS_H
#define _AAPL_CONNECTIONS_H

#ifdef _WIN
#	include <winsock.h>
#else
#	include <netinet/in.h>
#	include <sys/un.h>
#endif

#include "deque.h"
#include "doublelist.h"

class Selector;
class Connection;

struct FdListEl
{
	Connection *Next, *Prev;
};

struct Message
{
	int Id;
	int Length;
};

template<class Element> struct ReadFdListElTmpl : public DoubleListEl<Element> {};
template<class Element> struct WriteFdListElTmpl : public DoubleListEl<Element> {};
template<class Element> struct ConnListElTmpl : public DoubleListEl<Element> {};

class Connection :
		public ReadFdListElTmpl<Connection>, 
		public WriteFdListElTmpl<Connection>, 
		public ConnListElTmpl<Connection>
{
	friend Selector;
protected:
	void SuccessfullOpen();
	virtual void ConnectionClosed() {};

	virtual int ServiceRead() { UnRegisterRead(); return -1; }
	virtual int ServiceWrite() { UnRegisterWrite(); return -1; }

	int readFd;
	int writeFd;
	unsigned int readRegistered :1;
	unsigned int writeRegistered :1;
	unsigned int connectionOpen :1;
	unsigned int deleteOnClose :1;

	Selector &sel;

public:
	Connection(Selector &sel);
	virtual ~Connection() { Close(); }
		
	void Close();
	int IsOpen() { return connectionOpen; }

	void RegisterRead();
	void RegisterWrite();
	void UnRegisterRead();
	void UnRegisterWrite();

};

typedef ReadFdListElTmpl<Connection> ReadFdListEl;
typedef WriteFdListElTmpl<Connection> WriteFdListEl;
typedef ConnListElTmpl<Connection> ConnListEl;

typedef DoubleList< Connection, ReadFdListEl > ReadFdList;
typedef DoubleList< Connection, WriteFdListEl > WriteFdList;
typedef DoubleList< Connection, ConnListEl > ConnList;


class Listener : public Connection
{
protected:
	int ServiceRead();
	virtual void CreateConnection(int sock);
public:
	Listener(Selector &sel) : Connection(sel) {}
};

class FNSListener : public Listener
{
	void ConnectionClosed();
	sockaddr_un sockName;

public:
	FNSListener(Selector &sel) : Listener(sel) {}
	int Open(char *filename);
};

class INSListener : public Listener
{
	void ConnectionClosed();
	sockaddr_in sockName;

public:
	INSListener(Selector &sel) : Listener(sel) {}
	int Open(unsigned short int port);
};


class ReaderWriter : public Connection
{
protected:
	void ConnectionClosed();
	virtual int ReadReady(byte *data, int len) {return -1;}
	void Eof();
	unsigned int closeOnEmptyWriteDq :1;


	int ServiceRead();
	int ServiceWrite();

public:
	ReaderWriter(Selector &sel) :
		Connection(sel),
		closeOnEmptyWriteDq(false) {}

	int Open(int rfd, int wfd);
	int Open(char *host, unsigned short int port);

	void WriteData(byte *data, int len);
	Deque writeDq;
};

class ReaderWriterPipe : public ReaderWriter
{
protected:
	void ConnectionClosed();

	int ReadReady(byte *data, int len);
	ReaderWriter &otherRW;
public:
	ReaderWriterPipe(Selector &sel, ReaderWriter &otherRW) :
		ReaderWriter(sel), otherRW(otherRW) {}
};
class Messenger : public Connection
{
public:
	Messenger(Selector &sel);

	void ConnectionClosed();

	int Open(int rfd, int wfd);
	int Open(char *host, unsigned short int port);

	void SendMessageHeader(int msgid, int msglen);
	
	int GetBasicMessage();
	int ScanBasicMessage(char *msg, int *i1, int *i2);

	virtual int ProcessMessage() {return -1;};
	
	int ServiceRead();
	int ServiceWrite();

	Deque writeDq;
	Deque readDq;
	enum { Empty, MessageStarted } state;
	Message msg;
};

#endif /* _AAPL_CONNECTIONS_H */

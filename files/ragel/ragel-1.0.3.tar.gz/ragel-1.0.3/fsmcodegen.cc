/*
 *  Copyright 2001 Adrian Thurston <adriant@ragel.ca>
 */

/*  This file is part of Ragel.
 *
 *  Ragel is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Ragel is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmcodegen.h"
#include "rl.h"

FsmCodeGen::FsmCodeGen( char *fsmName, FsmMachine<int> *machine, 
		ParseData *parseData ) : header(0), code(0),
		fsmName(fsmName), machine(machine),
		parseData(parseData)
{
	RegisterSection( "FSMNAME", common_FSMNAME );
	RegisterSection( "STRUCT_DATA", common_STRUCT_DATA );
	RegisterSection( "PRE_FUNC_LIST", common_PRE_FUNC_LIST );
	RegisterSection( "POST_FUNC_LIST", common_POST_FUNC_LIST );
	RegisterSection( "INIT_CODE", common_INIT_CODE );
	RegisterSection( "ANY_FUNCS", common_ANY_FUNCS );
	RegisterSection( "ANY_INDICIES", common_ANY_INDICIES );
}

/* Given a func index get the string version of the func that will
 * go to the output. */
char *FsmCodeGen::GetCodeBuiltin(int index)
{
	if ( 1 > index || index > parseData->funcList.ListLength )
		return 0;

	/* Walk the list of functions, to find the given index. */
	StringListEl *flel = parseData->funcList.Head;
	for ( int fnum = 1; fnum < index; fnum++ )
		flel = flel->Next;
	return flel->data;
}


/* Write out the code section. Use the header class member which will
 * be set by whatever super class is used. */
void FsmCodeGen::WriteOutHeader( ostream &out )
{
	WriteOutScan( out, header );
}

/* Write out the code section. Use the header class member which will
 * be set by whatever super class is used. */
void FsmCodeGen::WriteOutCode( ostream &out )
{
	WriteOutScan( out, code );
}

/* Associate a section name with a function call for handling 
 * the section name. */
void FsmCodeGen::RegisterSection( char *secName, SectionType call )
{
	/* Insert into the dict, ignoring whether or not if failed.
	 * We always overwrite existing entries so that super classes
	 * can override handlers that are set up by base classes. */
	BSElement< char*, SectionType > *lastFound;
	sectionDict.Insert( secName, call, &lastFound );
	lastFound->Value = call;
}

void common_FSMNAME( FsmCodeGen *codeGen, ostream &out )
{
	out << codeGen->fsmName;
}

void common_STRUCT_DATA( FsmCodeGen *codeGen, ostream &out )
{
	/* Walk the list of data, printing the cases. */
	StringListEl *del = codeGen->parseData->dataList.Head;
	while ( del != NULL ) {
		out << del->data;
		del = del->Next;
	}
}

void common_PRE_FUNC_LIST( FsmCodeGen *codeGen, ostream &out )
{
	/* Walk the list of pre funcs, printing the sections. */
	StringListEl *del = codeGen->parseData->preFuncList.Head;
	while ( del != NULL ) {
		out.form( "{ %s }\n", del->data );
		del = del->Next;
	}
}

void common_INIT_CODE( FsmCodeGen *codeGen, ostream &out )
{
	/* Walk the list of pre funcs, printing the sections. */
	StringListEl *del = codeGen->parseData->initCodeList.Head;
	while ( del != NULL ) {
		out.form( "{ %s }\n", del->data );
		del = del->Next;
	}
}

void common_POST_FUNC_LIST( FsmCodeGen *codeGen, ostream &out )
{
	/* Walk the list of post funcs, printing the sections. */
	StringListEl *del = codeGen->parseData->postFuncList.Head;
	while ( del != NULL ) {
		out.form( "{ %s }\n", del->data );
		del = del->Next;
	}
}

void common_ANY_FUNCS( FsmCodeGen *codeGen, ostream &out )
{
	if ( codeGen->machine->numTransFuncs > 0 )
		out << "1";
	else
		out << "0";
}

void common_ANY_INDICIES( FsmCodeGen *codeGen, ostream &out )
{
	bool indiciesFound = false;
	FsmMachState<int> *pSt = codeGen->machine->allStates;
	for ( int st = 0; st < codeGen->machine->numStates; st++, pSt++ ) {
		if ( pSt->numIndex > 0 ) {
			indiciesFound = true;
			break;
		}
	}
	if ( indiciesFound )
		out << "1";
	else
		out << "0";
}

void FsmCodeGen::SelectSection( ostream &out, char *sname )
{
	BSElement<char*, SectionType> *res = sectionDict.Find( sname );
	if ( res == 0 )
		out << "\n<<internal ragel error: section " << sname << " not found>>\n";
	else
		res->Value( this, out );
}

void FsmCodeGen::WriteOutScan( ostream &out, char *data )
{
	char *sectionStart = 0;
	char *cur = data;
	enum { inData, inSection } state = inData;

	while ( *cur != 0 ) {
		if ( state == inData ) {
			if ( *cur == '@' ) {
				sectionStart = cur + 1;
				state = inSection;
			}
			else
				out << *cur;
		}
		else if ( *cur == '@' ) {
			/* We got to the end of a section name. */
			*cur = 0;
			SelectSection( out, sectionStart );
			*cur = '@';
			state = inData;
		}
		cur++;
	}
}

char FsmCodeGen::outputHeader[] = 
"/*
 * Automatically generated by " PROGNAME ". Do not edit.
 */
";

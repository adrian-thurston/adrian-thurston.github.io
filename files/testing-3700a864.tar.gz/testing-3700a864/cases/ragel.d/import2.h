

#define A 49

#define B "2"

#define C '3'

int D = 52;

const char *E = "5";

char F = '6';

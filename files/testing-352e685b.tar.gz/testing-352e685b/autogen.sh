#!/bin/bash
#

set -xe

cd public
./autogen.sh
cd ..


rm -f configure
cp configure.in configure
chmod +x-w configure


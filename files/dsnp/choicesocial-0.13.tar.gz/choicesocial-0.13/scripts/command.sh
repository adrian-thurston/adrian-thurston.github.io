#!/bin/sh
#

prefix=@prefix@
php $prefix/share/choicesocial/web/command.php "$@"

<?php
	$CONVERT = "convert ";
	$SCHEMA_VERSION = 3;
	$WITH_DSNPD = "/opt/dsnpd";
	$WWW_USER = "www-data";
?>

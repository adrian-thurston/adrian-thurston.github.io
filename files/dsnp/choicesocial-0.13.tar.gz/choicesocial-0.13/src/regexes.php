<?php

define( 'REGEX_USER', '/^.+$/' );
define( 'REGEX_ID',   '/^.+$/' );
define( 'REGEX_DATE', '/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/' );
define( 'REGEX_TIME', '/^[0-9]{2}:[0-9]{2}:[0-9]{2}$/' );

?>

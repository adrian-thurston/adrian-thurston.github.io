<?
class PublicIndexController extends Controller
{
	var $vars = array();

	var $function = array(
		'index' => array()
	);

	function index()
	{
	}
}
?>

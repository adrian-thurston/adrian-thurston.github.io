<?php

$ERROR[1]  = 'A friend claim already exists.';
$ERROR[2]  = 'A friend request already exists.';
$ERROR[3]  = 'Could not fetch public key.';
$ERROR[4]  = 'Could not fetch the relid that was requested.';
$ERROR[5]  = 'Failed to decrypt and verify the message.';
$ERROR[6]  = 'Failed to encrypt and sign the message.';
$ERROR[7]  = 'The decrypted message was the wrong size';
$ERROR[8]  = 'Could not fetch the response relid.';
$ERROR[9]  = 'The relid that was returned did not match the original we chose.';
$ERROR[10] = 'Failed to fetch the friend-login token.';
$ERROR[11] = 'Not a friend.';
$ERROR[12] = 'No friend-login token found.';
$ERROR[13] = 'There was a databse error.';

?>

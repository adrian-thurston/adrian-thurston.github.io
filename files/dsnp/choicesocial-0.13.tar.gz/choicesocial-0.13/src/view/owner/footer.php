	</div>

	<div id="footer">
	<table><tr>
		<td id="footer_left"><div class="footer_content">
		</div></td>

		<td id="footer_middle"><div class="footer_content">
		<h1>
			<a href="http://www.complang.org/dsnp/">DSNP Content-Manager One</a>
		</h1>
		</div></td>

		<td id="footer_right"><div class="footer_content">
		</div></td>
	</tr><table>
	</div>
</body>
</html>


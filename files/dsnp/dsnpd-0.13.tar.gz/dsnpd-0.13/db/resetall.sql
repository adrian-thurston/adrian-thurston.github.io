use dsnpn;
source /opt/dsnpd/share/dsnpd/dsnpn.sql;
use dsnpk;
source /opt/dsnpd/share/dsnpd/dsnpk.sql;
use dsnpd;
source /opt/dsnpd/share/dsnpd/dsnpd.sql;

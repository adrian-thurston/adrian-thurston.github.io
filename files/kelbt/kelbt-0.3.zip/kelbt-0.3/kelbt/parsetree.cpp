/*
 *  Copyright 2001-2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <iomanip>
#include <errno.h>
#include <limits.h>
#include <stdlib.h>

/* Parsing. */
#include "kelbt.h"
#include "parsedata.h"

using namespace std;

/* Parse tree traversal. */
FsmAp *LangEl::walk( ParseData *pd )
{
	FsmAp *retVal = 0;
	switch ( type ) {
	case NonTerm: {
		retVal = new FsmAp();
		retVal->concatFsm( id );
		break;
	}
	case Term: {
		retVal = new FsmAp();
		retVal->concatFsm( id );
		break;
	}
	case Unknown: {
		assert( false );
	}}

	return retVal;
}

FsmAp *ProdElList::walk( ParseData *pd )
{
	FsmAp *rtnVal = new FsmAp();
	rtnVal->lambdaFsm();
	for ( Iter prodEl = first(); prodEl.lte(); prodEl++ ) {
		FsmAp *itemFsm = prodEl->walk( pd );
		rtnVal->concatOp( itemFsm );
		pd->prodLength += 1;
	}
	return rtnVal;
}

/* Clean up after a factor node. */
Factor::~Factor()
{
	switch ( type ) {
		case LiteralType:
			delete literal;
			break;
		case ReferenceType:
			break;
	}
}

/* Evaluate a factor node. */
FsmAp *Factor::walk( ParseData *pd )
{
	FsmAp *rtnVal = 0;
	switch ( type ) {
	case LiteralType:
		rtnVal = literal->walk( pd );
		break;
	case ReferenceType:
		rtnVal = langEl->walk( pd );
		break;
	}

	if ( isReferenced ) {
		long storeNum = referenceNum;
		for ( TransList::Iter trans = rtnVal->startState->outList; trans.lte(); trans++ )
			trans->storeSet.insert( storeNum );
	}

	if ( commit ) {
		cout << "COMMIT: inserting commit of length: " << pd->prodLength << endl;
		rtnVal->setCommit( pd->prodLength );
	}

	return rtnVal;
}

/* Evaluate a literal object. */
FsmAp *Literal::walk( ParseData *pd )
{
	/* Make the array of keys in int format. */
	long *arr = new long[strlen(str)];

	/* Copy from a char star type. */
	char *src = str;
	int len = strlen(str);
	for ( int i = 0; i < len; i++ )
		arr[i] = src[i];

	/* Make the new machine. */
	FsmAp *rtnVal = new FsmAp();
	rtnVal->concatFsm( arr, strlen(str) );
	delete[] arr;

	return rtnVal;
}


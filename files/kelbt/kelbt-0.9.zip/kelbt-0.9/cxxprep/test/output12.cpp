
class [cn C] { };
namespace [nn ns] {}
template <{class T}> class [cn CT] {};

int $[di main]({int $[di argc], char $<*>[di argv][[]]})
{
C:~
	int $[di i] = int(1);
id:~
ns:~
case "hello":~
	int $[di i] = int(1);
case 1 + 2:~
	int $[di i] = int(1);
case a[[b]]:~
	int $[di i] = int(1);
}

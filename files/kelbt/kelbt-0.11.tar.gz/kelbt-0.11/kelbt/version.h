#define VERSION "0.11"
#define PUBDATE "February 2007"

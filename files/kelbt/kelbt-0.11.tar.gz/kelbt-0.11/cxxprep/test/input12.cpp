
class C { };
namespace ns {}
template <class T> class CT {};

int main(int argc, char *argv[])
{
C:
	int i = int(1);
id:
ns:
case "hello":
	int i = int(1);
case 1 + 2:
	int i = int(1);
case a[b]:
	int i = int(1);
}

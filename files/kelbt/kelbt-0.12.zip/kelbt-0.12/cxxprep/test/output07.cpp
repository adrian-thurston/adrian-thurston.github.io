
class [cn C]{};
void $[di main]({int $[di argc], char $<*>[di argv][[]]})
{
	// sdflkj

	i*2.3 /**/ / f / /**/ 2.2;
	(new [cn C]<*><*><*>) * 2.2;
	(new [cn C]<*><*><*>)*2.2;
}


class C;
int main()
{
    C( (hello || 1), 2 );
}

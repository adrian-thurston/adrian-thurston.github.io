#line 1 "klscan.rl"
/*
 *  Copyright 2006 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <fstream>
#include <string.h>

#include "kelbt.h"
#include "klparse.h"

using std::ifstream;
using std::istream;
using std::ostream;
using std::cout;
using std::cerr;
using std::endl;

void do_scan( char *fileName, istream &input, ParserDict &parserDict, int include_depth );

#line 208 "klscan.rl"



#line 44 "klscan.cpp"
static const int klscan_start = 28;

static const int klscan_first_final = 28;

static const int klscan_error = -1;

#line 211 "klscan.rl"

void do_scan( char *fileName, istream &input, ParserDict &parserDict, int include_depth )
{
	int bufsize = 8;
	char *buf = new char[bufsize];
	const char last_char = 0;
	char *tokstart, *tokend;
	int cs, act, have = 0;
	int curly_count = 0;
	char *inline_start = 0;
	char *litstart = 0, *litend = 0;
	char *identstart = 0, *identend = 0;
	ParserDictEl *pdEl = 0;
	Parser *parser = 0;
	bool execute = true;

	
#line 69 "klscan.cpp"
	{
	cs = klscan_start;
	tokstart = 0;
	tokend = 0;
	act = 0;
	}
#line 228 "klscan.rl"

	while ( execute ) {
		char *p = buf + have;
		int space = bufsize - have;

		if ( space == 0 ) {
			/* We filled up the buffer trying to scan a token. Grow it. */
			bufsize = bufsize * 2;
			char *newbuf = new char[bufsize];
			//cout << "FULL BUFFER, NEW SIZE: " << bufsize << endl;

			/* Recompute p and space. */
			p = newbuf + have;
			space = bufsize - have;

			/* Patch up pointers possibly in use. */
			if ( tokstart != 0 )
				tokstart = newbuf + ( tokstart - buf );
			if ( inline_start != 0 )
				inline_start = newbuf + ( inline_start - buf );
			tokend = newbuf + ( tokend - buf );
			litstart = newbuf + ( litstart - buf );
			litend = newbuf + ( litend - buf );
			identstart = newbuf + ( identstart - buf );
			identend = newbuf + ( identend - buf );

			/* Copy the new buffer in. */
			memcpy( newbuf, buf, have );
			delete[] buf;
			buf = newbuf;
		}

		input.read( p, space );
		int len = input.gcount();

		/* If we see eof then append the EOF char. */
	 	if ( len == 0 ) {
			p[0] = last_char, len = 1;
			execute = false;
		}

		char *pe = p + len;
		
#line 120 "klscan.cpp"
	{
	if ( p == pe )
		goto _out;
	switch ( cs )
	{
tr1:
#line 191 "klscan.rl"
	{tokend = p+1;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}}
	goto st28;
tr5:
#line 191 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st28;
tr7:
#line 191 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st28;
tr9:
#line 191 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st28;
tr11:
#line 191 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st28;
tr15:
#line 191 "klscan.rl"
	{tokend = p+1;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}}
	goto st28;
tr16:
#line 204 "klscan.rl"
	{tokend = p+1;}
	goto st28;
tr22:
#line 191 "klscan.rl"
	{tokend = p+1;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}}
	goto st28;
tr23:
#line 191 "klscan.rl"
	{{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st28;
tr24:
#line 202 "klscan.rl"
	{tokend = p+1;{ {goto st46;} }}
	goto st28;
st28:
#line 1 "klscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out28;
case 28:
#line 1 "klscan.rl"
	{tokstart = p;}
#line 198 "klscan.cpp"
	switch( (*p) ) {
		case 0: goto tr16;
		case 32: goto st29;
		case 34: goto tr17;
		case 37: goto tr18;
		case 39: goto tr19;
		case 47: goto tr20;
		case 95: goto st35;
	}
	if ( (*p) < 48 ) {
		if ( 9 <= (*p) && (*p) <= 10 )
			goto st29;
	} else if ( (*p) > 57 ) {
		if ( (*p) > 90 ) {
			if ( 97 <= (*p) && (*p) <= 122 )
				goto st35;
		} else if ( (*p) >= 65 )
			goto st35;
	} else
		goto st34;
	goto tr15;
st29:
	if ( ++p == pe )
		goto _out29;
case 29:
	if ( (*p) == 32 )
		goto st29;
	if ( 9 <= (*p) && (*p) <= 10 )
		goto st29;
	goto tr9;
tr17:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st30;
st30:
	if ( ++p == pe )
		goto _out30;
case 30:
#line 237 "klscan.cpp"
	switch( (*p) ) {
		case 34: goto tr1;
		case 92: goto st1;
	}
	goto st0;
st0:
	if ( ++p == pe )
		goto _out0;
case 0:
	switch( (*p) ) {
		case 34: goto tr1;
		case 92: goto st1;
	}
	goto st0;
st1:
	if ( ++p == pe )
		goto _out1;
case 1:
	goto st0;
tr18:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st31;
st31:
	if ( ++p == pe )
		goto _out31;
case 31:
#line 265 "klscan.cpp"
	if ( (*p) == 37 )
		goto st2;
	goto tr11;
st2:
	if ( ++p == pe )
		goto _out2;
case 2:
	if ( (*p) == 123 )
		goto tr24;
	goto tr23;
tr19:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st32;
st32:
	if ( ++p == pe )
		goto _out32;
case 32:
#line 284 "klscan.cpp"
	switch( (*p) ) {
		case 39: goto tr1;
		case 92: goto st4;
	}
	goto st3;
st3:
	if ( ++p == pe )
		goto _out3;
case 3:
	switch( (*p) ) {
		case 39: goto tr1;
		case 92: goto st4;
	}
	goto st3;
st4:
	if ( ++p == pe )
		goto _out4;
case 4:
	goto st3;
tr20:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st33;
st33:
	if ( ++p == pe )
		goto _out33;
case 33:
#line 312 "klscan.cpp"
	switch( (*p) ) {
		case 42: goto st5;
		case 47: goto st7;
	}
	goto tr11;
st5:
	if ( ++p == pe )
		goto _out5;
case 5:
	if ( (*p) == 42 )
		goto st6;
	goto st5;
st6:
	if ( ++p == pe )
		goto _out6;
case 6:
	switch( (*p) ) {
		case 42: goto st6;
		case 47: goto tr22;
	}
	goto st5;
st7:
	if ( ++p == pe )
		goto _out7;
case 7:
	if ( (*p) == 10 )
		goto tr22;
	goto st7;
st34:
	if ( ++p == pe )
		goto _out34;
case 34:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st34;
	goto tr7;
st35:
	if ( ++p == pe )
		goto _out35;
case 35:
	if ( (*p) == 95 )
		goto st35;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st35;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st35;
	} else
		goto st35;
	goto tr5;
tr26:
#line 59 "klscan.rl"
	{tokend = p+1;}
	goto st36;
tr30:
#line 56 "klscan.rl"
	{tokend = p;p--;}
	goto st36;
tr32:
#line 57 "klscan.rl"
	{tokend = p;p--;}
	goto st36;
tr34:
#line 60 "klscan.rl"
	{tokend = p;p--;}
	goto st36;
tr36:
#line 73 "klscan.rl"
	{tokend = p;{
			if ( inline_start < tokstart )
				parser->token( TK_Inline, inline_start, tokstart );
			parser->token( TK_Reference, tokstart, tokend );
			inline_start = tokend;
		}p--;}
	goto st36;
tr38:
#line 80 "klscan.rl"
	{tokend = p;p--;}
	goto st36;
tr41:
#line 73 "klscan.rl"
	{tokend = p+1;{
			if ( inline_start < tokstart )
				parser->token( TK_Inline, inline_start, tokstart );
			parser->token( TK_Reference, tokstart, tokend );
			inline_start = tokend;
		}}
	goto st36;
tr42:
#line 80 "klscan.rl"
	{tokend = p+1;}
	goto st36;
tr48:
#line 62 "klscan.rl"
	{tokend = p+1;{ curly_count += 1; }}
	goto st36;
tr49:
#line 64 "klscan.rl"
	{tokend = p+1;{ 
			if ( --curly_count == 0 ) {
				/* Send the entire block and free the inline_start pointer. */
				parser->token( TK_Inline, inline_start, tokend );
				inline_start = 0;
				{goto st46;}
			}
		}}
	goto st36;
tr51:
#line 58 "klscan.rl"
	{tokend = p+1;}
	goto st36;
st36:
#line 1 "klscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out36;
case 36:
#line 1 "klscan.rl"
	{tokstart = p;}
#line 432 "klscan.cpp"
	switch( (*p) ) {
		case 32: goto st37;
		case 34: goto tr43;
		case 36: goto st39;
		case 39: goto tr45;
		case 47: goto tr46;
		case 64: goto st44;
		case 95: goto st45;
		case 123: goto tr48;
		case 125: goto tr49;
	}
	if ( (*p) < 48 ) {
		if ( 9 <= (*p) && (*p) <= 10 )
			goto st37;
	} else if ( (*p) > 57 ) {
		if ( (*p) > 90 ) {
			if ( 97 <= (*p) && (*p) <= 122 )
				goto st45;
		} else if ( (*p) >= 65 )
			goto st45;
	} else
		goto st43;
	goto tr42;
st37:
	if ( ++p == pe )
		goto _out37;
case 37:
	if ( (*p) == 32 )
		goto st37;
	if ( 9 <= (*p) && (*p) <= 10 )
		goto st37;
	goto tr34;
tr43:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st38;
st38:
	if ( ++p == pe )
		goto _out38;
case 38:
#line 473 "klscan.cpp"
	switch( (*p) ) {
		case 34: goto tr26;
		case 92: goto st9;
	}
	goto st8;
st8:
	if ( ++p == pe )
		goto _out8;
case 8:
	switch( (*p) ) {
		case 34: goto tr26;
		case 92: goto st9;
	}
	goto st8;
st9:
	if ( ++p == pe )
		goto _out9;
case 9:
	goto st8;
st39:
	if ( ++p == pe )
		goto _out39;
case 39:
	if ( (*p) == 36 )
		goto tr41;
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st40;
	goto tr38;
st40:
	if ( ++p == pe )
		goto _out40;
case 40:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st40;
	goto tr36;
tr45:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st41;
st41:
	if ( ++p == pe )
		goto _out41;
case 41:
#line 517 "klscan.cpp"
	switch( (*p) ) {
		case 39: goto tr26;
		case 92: goto st11;
	}
	goto st10;
st10:
	if ( ++p == pe )
		goto _out10;
case 10:
	switch( (*p) ) {
		case 39: goto tr26;
		case 92: goto st11;
	}
	goto st10;
st11:
	if ( ++p == pe )
		goto _out11;
case 11:
	goto st10;
tr46:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st42;
st42:
	if ( ++p == pe )
		goto _out42;
case 42:
#line 545 "klscan.cpp"
	switch( (*p) ) {
		case 42: goto st12;
		case 47: goto st14;
	}
	goto tr38;
st12:
	if ( ++p == pe )
		goto _out12;
case 12:
	if ( (*p) == 42 )
		goto st13;
	goto st12;
st13:
	if ( ++p == pe )
		goto _out13;
case 13:
	switch( (*p) ) {
		case 42: goto st13;
		case 47: goto tr51;
	}
	goto st12;
st14:
	if ( ++p == pe )
		goto _out14;
case 14:
	if ( (*p) == 10 )
		goto tr51;
	goto st14;
st43:
	if ( ++p == pe )
		goto _out43;
case 43:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st43;
	goto tr32;
st44:
	if ( ++p == pe )
		goto _out44;
case 44:
	if ( (*p) == 64 )
		goto tr41;
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st40;
	goto tr38;
st45:
	if ( ++p == pe )
		goto _out45;
case 45:
	if ( (*p) == 95 )
		goto st45;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st45;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st45;
	} else
		goto st45;
	goto tr30;
tr53:
#line 188 "klscan.rl"
	{tokend = p;{ parser->token( *tokstart, 0, 0 ); }p--;}
	goto st46;
tr56:
#line 169 "klscan.rl"
	{tokend = p+1;}
	goto st46;
tr57:
#line 167 "klscan.rl"
	{tokend = p;{ parser->token( TK_Word, tokstart, tokend ); }p--;}
	goto st46;
tr66:
#line 151 "klscan.rl"
	{ identend = p; }
#line 84 "klscan.rl"
	{tokend = p+1;{
		//cout << "PARSER STATEMENT" << endl;

		char *data = identstart;
		int length = identend - identstart;
		char *parserName = new char[length+1];
		memcpy( parserName, data, length );
		parserName[length] = 0;

		pdEl = parserDict.find( parserName );
		if ( pdEl != 0 ) {
			//cout << "USING EXISTING PARSER" << endl;
			delete[] parserName;
		}
		else {
			//cout << "CREATING NEW PARSER" << endl;
			pdEl = new ParserDictEl;
			pdEl->name = parserName;
			pdEl->parser = new Parser( fileName, parserName );
			pdEl->parser->init();
			parserDict.insert( pdEl );
		}

		parser = pdEl->parser;
		parser->startSection();
	}}
	goto st46;
tr103:
#line 180 "klscan.rl"
	{tokend = p;p--;}
	goto st46;
tr106:
#line 1 "klscan.rl"
	{	switch( act ) {
	case 10:
	{ parser->token( KW_Commit, 0, 0 ); }
	break;
	case 11:
	{ parser->token( KW_Try, 0, 0 ); }
	break;
	case 12:
	{ parser->token( KW_Undo, 0, 0 ); }
	break;
	case 13:
	{ parser->token( KW_Final, 0, 0 ); }
	break;
	case 14:
	{ parser->token( KW_Translate, 0, 0 ); }
	break;
	case 15:
	{ parser->token( KW_Token, 0, 0 ); }
	break;
	case 16:
	{ parser->token( KW_NonTerm, 0, 0 ); }
	break;
	case 17:
	{ parser->token( KW_Uses, 0, 0 ); }
	break;
	case 18:
	{ parser->token( KW_Type, 0, 0 ); }
	break;
	case 19:
	{ parser->token( KW_Interface, 0, 0 ); }
	break;
	case 22:
	{ parser->token( TK_Word, tokstart, tokend ); }
	break;
	default: break;
	}
	{p = ((tokend))-1;}}
	goto st46;
tr107:
#line 188 "klscan.rl"
	{tokend = p+1;{ parser->token( *tokstart, 0, 0 ); }}
	goto st46;
tr117:
#line 182 "klscan.rl"
	{tokend = p+1;{ 
			inline_start = tokstart;
			curly_count = 1; 
			{goto st36;}
		}}
	goto st46;
tr124:
#line 167 "klscan.rl"
	{{ parser->token( TK_Word, tokstart, tokend ); }{p = ((tokend))-1;}}
	goto st46;
tr127:
#line 84 "klscan.rl"
	{tokend = p+1;{
		//cout << "PARSER STATEMENT" << endl;

		char *data = identstart;
		int length = identend - identstart;
		char *parserName = new char[length+1];
		memcpy( parserName, data, length );
		parserName[length] = 0;

		pdEl = parserDict.find( parserName );
		if ( pdEl != 0 ) {
			//cout << "USING EXISTING PARSER" << endl;
			delete[] parserName;
		}
		else {
			//cout << "CREATING NEW PARSER" << endl;
			pdEl = new ParserDictEl;
			pdEl->name = parserName;
			pdEl->parser = new Parser( fileName, parserName );
			pdEl->parser->init();
			parserDict.insert( pdEl );
		}

		parser = pdEl->parser;
		parser->startSection();
	}}
	goto st46;
tr129:
#line 112 "klscan.rl"
	{tokend = p+1;{
		char *data = litstart + 1;
		int length = litend - litstart - 1;
		char *includeFileName = new char[length+1];
		memcpy( includeFileName, data, length );
		includeFileName[length] = 0;

		//cout << "HIT INCLUDE " << includeFileName << endl;

		/* Open the input file for reading. */
		ifstream *inFile = new ifstream( includeFileName );
		istream *inStream = inFile;
		if ( ! inFile->is_open() )
			error() << "include: could not open " << includeFileName << " for reading" << endl;

		do_scan( includeFileName, *inStream, parserDict, include_depth+1 );

		delete[] includeFileName;
		delete inFile;
	}}
	goto st46;
tr131:
#line 188 "klscan.rl"
	{{ parser->token( *tokstart, 0, 0 ); }{p = ((tokend))-1;}}
	goto st46;
tr132:
#line 168 "klscan.rl"
	{tokend = p+1;{ parser->token( TK_Literal, tokstart+1, tokend-1 ); }}
	goto st46;
tr133:
#line 171 "klscan.rl"
	{tokend = p+1;{ 
			/* In order to generate anything we must be in the top level file
			 * and the current spec must be active and there must not have been
			 * any parse errors. */
			if ( include_depth == 0 ) 
				parser->endSection();
			{goto st28;}
		}}
	goto st46;
st46:
#line 1 "klscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out46;
case 46:
#line 1 "klscan.rl"
	{tokstart = p;}
#line 787 "klscan.cpp"
	switch( (*p) ) {
		case 32: goto st47;
		case 35: goto tr108;
		case 39: goto tr109;
		case 95: goto tr61;
		case 99: goto st51;
		case 102: goto st56;
		case 105: goto st60;
		case 110: goto st73;
		case 112: goto st79;
		case 116: goto st86;
		case 117: goto st99;
		case 123: goto tr117;
		case 125: goto tr118;
	}
	if ( (*p) < 65 ) {
		if ( 9 <= (*p) && (*p) <= 10 )
			goto st47;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr107;
st47:
	if ( ++p == pe )
		goto _out47;
case 47:
	if ( (*p) == 32 )
		goto st47;
	if ( 9 <= (*p) && (*p) <= 10 )
		goto st47;
	goto tr103;
tr108:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st48;
st48:
	if ( ++p == pe )
		goto _out48;
case 48:
#line 829 "klscan.cpp"
	if ( (*p) == 10 )
		goto tr56;
	goto st15;
st15:
	if ( ++p == pe )
		goto _out15;
case 15:
	if ( (*p) == 10 )
		goto tr56;
	goto st15;
tr109:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st49;
st49:
	if ( ++p == pe )
		goto _out49;
case 49:
#line 848 "klscan.cpp"
	switch( (*p) ) {
		case 39: goto tr53;
		case 92: goto st17;
	}
	goto st16;
st16:
	if ( ++p == pe )
		goto _out16;
case 16:
	if ( (*p) == 39 )
		goto tr132;
	goto tr131;
st17:
	if ( ++p == pe )
		goto _out17;
case 17:
	goto st16;
tr61:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 167 "klscan.rl"
	{act = 22;}
	goto st50;
tr69:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 136 "klscan.rl"
	{act = 11;}
	goto st50;
tr94:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 135 "klscan.rl"
	{act = 10;}
	goto st50;
tr95:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 142 "klscan.rl"
	{act = 17;}
	goto st50;
tr96:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 137 "klscan.rl"
	{act = 12;}
	goto st50;
tr97:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 140 "klscan.rl"
	{act = 15;}
	goto st50;
tr98:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 141 "klscan.rl"
	{act = 16;}
	goto st50;
tr99:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 138 "klscan.rl"
	{act = 13;}
	goto st50;
tr100:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 139 "klscan.rl"
	{act = 14;}
	goto st50;
tr101:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 143 "klscan.rl"
	{act = 18;}
	goto st50;
tr102:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 144 "klscan.rl"
	{act = 19;}
	goto st50;
st50:
	if ( ++p == pe )
		goto _out50;
case 50:
#line 936 "klscan.cpp"
	if ( (*p) == 95 )
		goto tr61;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr106;
st51:
	if ( ++p == pe )
		goto _out51;
case 51:
	switch( (*p) ) {
		case 95: goto tr61;
		case 111: goto st52;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st52:
	if ( ++p == pe )
		goto _out52;
case 52:
	switch( (*p) ) {
		case 95: goto tr61;
		case 109: goto st53;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st53:
	if ( ++p == pe )
		goto _out53;
case 53:
	switch( (*p) ) {
		case 95: goto tr61;
		case 109: goto st54;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st54:
	if ( ++p == pe )
		goto _out54;
case 54:
	switch( (*p) ) {
		case 95: goto tr61;
		case 105: goto st55;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st55:
	if ( ++p == pe )
		goto _out55;
case 55:
	switch( (*p) ) {
		case 95: goto tr61;
		case 116: goto tr94;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st56:
	if ( ++p == pe )
		goto _out56;
case 56:
	switch( (*p) ) {
		case 95: goto tr61;
		case 105: goto st57;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st57:
	if ( ++p == pe )
		goto _out57;
case 57:
	switch( (*p) ) {
		case 95: goto tr61;
		case 110: goto st58;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st58:
	if ( ++p == pe )
		goto _out58;
case 58:
	switch( (*p) ) {
		case 95: goto tr61;
		case 97: goto st59;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st59:
	if ( ++p == pe )
		goto _out59;
case 59:
	switch( (*p) ) {
		case 95: goto tr61;
		case 108: goto tr99;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st60:
	if ( ++p == pe )
		goto _out60;
case 60:
	switch( (*p) ) {
		case 95: goto tr61;
		case 110: goto st61;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st61:
	if ( ++p == pe )
		goto _out61;
case 61:
	switch( (*p) ) {
		case 95: goto tr61;
		case 99: goto st62;
		case 116: goto st67;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st62:
	if ( ++p == pe )
		goto _out62;
case 62:
	switch( (*p) ) {
		case 95: goto tr61;
		case 108: goto st63;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st63:
	if ( ++p == pe )
		goto _out63;
case 63:
	switch( (*p) ) {
		case 95: goto tr61;
		case 117: goto st64;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st64:
	if ( ++p == pe )
		goto _out64;
case 64:
	switch( (*p) ) {
		case 95: goto tr61;
		case 100: goto st65;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st65:
	if ( ++p == pe )
		goto _out65;
case 65:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto tr75;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
tr75:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st66;
st66:
	if ( ++p == pe )
		goto _out66;
case 66:
#line 1212 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st18;
		case 32: goto st18;
		case 34: goto tr59;
		case 39: goto tr60;
		case 95: goto tr61;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st18:
	if ( ++p == pe )
		goto _out18;
case 18:
	switch( (*p) ) {
		case 9: goto st18;
		case 32: goto st18;
		case 34: goto tr59;
		case 39: goto tr60;
	}
	goto tr124;
tr59:
#line 158 "klscan.rl"
	{ litstart = p; }
	goto st19;
st19:
	if ( ++p == pe )
		goto _out19;
case 19:
#line 1248 "klscan.cpp"
	switch( (*p) ) {
		case 34: goto tr120;
		case 92: goto st21;
	}
	goto st19;
tr120:
#line 159 "klscan.rl"
	{ litend = p; }
	goto st20;
st20:
	if ( ++p == pe )
		goto _out20;
case 20:
#line 1262 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st20;
		case 32: goto st20;
		case 59: goto tr129;
	}
	goto tr124;
st21:
	if ( ++p == pe )
		goto _out21;
case 21:
	goto st19;
tr60:
#line 158 "klscan.rl"
	{ litstart = p; }
	goto st22;
st22:
	if ( ++p == pe )
		goto _out22;
case 22:
#line 1282 "klscan.cpp"
	switch( (*p) ) {
		case 39: goto tr120;
		case 92: goto st23;
	}
	goto st22;
st23:
	if ( ++p == pe )
		goto _out23;
case 23:
	goto st22;
st67:
	if ( ++p == pe )
		goto _out67;
case 67:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto st68;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st68:
	if ( ++p == pe )
		goto _out68;
case 68:
	switch( (*p) ) {
		case 95: goto tr61;
		case 114: goto st69;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st69:
	if ( ++p == pe )
		goto _out69;
case 69:
	switch( (*p) ) {
		case 95: goto tr61;
		case 102: goto st70;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st70:
	if ( ++p == pe )
		goto _out70;
case 70:
	switch( (*p) ) {
		case 95: goto tr61;
		case 97: goto st71;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st71:
	if ( ++p == pe )
		goto _out71;
case 71:
	switch( (*p) ) {
		case 95: goto tr61;
		case 99: goto st72;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st72:
	if ( ++p == pe )
		goto _out72;
case 72:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto tr102;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st73:
	if ( ++p == pe )
		goto _out73;
case 73:
	switch( (*p) ) {
		case 95: goto tr61;
		case 111: goto st74;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st74:
	if ( ++p == pe )
		goto _out74;
case 74:
	switch( (*p) ) {
		case 95: goto tr61;
		case 110: goto st75;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st75:
	if ( ++p == pe )
		goto _out75;
case 75:
	switch( (*p) ) {
		case 95: goto tr61;
		case 116: goto st76;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st76:
	if ( ++p == pe )
		goto _out76;
case 76:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto st77;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st77:
	if ( ++p == pe )
		goto _out77;
case 77:
	switch( (*p) ) {
		case 95: goto tr61;
		case 114: goto st78;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st78:
	if ( ++p == pe )
		goto _out78;
case 78:
	switch( (*p) ) {
		case 95: goto tr61;
		case 109: goto tr98;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st79:
	if ( ++p == pe )
		goto _out79;
case 79:
	switch( (*p) ) {
		case 95: goto tr61;
		case 97: goto st80;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st80:
	if ( ++p == pe )
		goto _out80;
case 80:
	switch( (*p) ) {
		case 95: goto tr61;
		case 114: goto st81;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st81:
	if ( ++p == pe )
		goto _out81;
case 81:
	switch( (*p) ) {
		case 95: goto tr61;
		case 115: goto st82;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st82:
	if ( ++p == pe )
		goto _out82;
case 82:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto st83;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st83:
	if ( ++p == pe )
		goto _out83;
case 83:
	switch( (*p) ) {
		case 95: goto tr61;
		case 114: goto tr90;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
tr90:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st84;
st84:
	if ( ++p == pe )
		goto _out84;
case 84:
#line 1590 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st24;
		case 32: goto st24;
		case 95: goto tr63;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr63;
	} else
		goto tr63;
	goto tr57;
st24:
	if ( ++p == pe )
		goto _out24;
case 24:
	switch( (*p) ) {
		case 9: goto st24;
		case 32: goto st24;
		case 95: goto tr125;
	}
	if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr125;
	} else if ( (*p) >= 65 )
		goto tr125;
	goto tr124;
tr125:
#line 150 "klscan.rl"
	{ identstart = p; }
	goto st25;
st25:
	if ( ++p == pe )
		goto _out25;
case 25:
#line 1628 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto tr64;
		case 32: goto tr64;
		case 59: goto tr66;
		case 95: goto st25;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st25;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st25;
	} else
		goto st25;
	goto tr124;
tr64:
#line 151 "klscan.rl"
	{ identend = p; }
	goto st26;
st26:
	if ( ++p == pe )
		goto _out26;
case 26:
#line 1652 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st26;
		case 32: goto st26;
		case 59: goto tr127;
	}
	goto tr124;
tr65:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st85;
tr63:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 150 "klscan.rl"
	{ identstart = p; }
	goto st85;
st85:
	if ( ++p == pe )
		goto _out85;
case 85:
#line 1673 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto tr64;
		case 32: goto tr64;
		case 59: goto tr66;
		case 95: goto tr65;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr65;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr65;
	} else
		goto tr65;
	goto tr57;
st86:
	if ( ++p == pe )
		goto _out86;
case 86:
	switch( (*p) ) {
		case 95: goto tr61;
		case 111: goto st87;
		case 114: goto st90;
		case 121: goto st97;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st87:
	if ( ++p == pe )
		goto _out87;
case 87:
	switch( (*p) ) {
		case 95: goto tr61;
		case 107: goto st88;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st88:
	if ( ++p == pe )
		goto _out88;
case 88:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto st89;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st89:
	if ( ++p == pe )
		goto _out89;
case 89:
	switch( (*p) ) {
		case 95: goto tr61;
		case 110: goto tr97;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st90:
	if ( ++p == pe )
		goto _out90;
case 90:
	switch( (*p) ) {
		case 95: goto tr61;
		case 97: goto st91;
		case 121: goto tr69;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st91:
	if ( ++p == pe )
		goto _out91;
case 91:
	switch( (*p) ) {
		case 95: goto tr61;
		case 110: goto st92;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st92:
	if ( ++p == pe )
		goto _out92;
case 92:
	switch( (*p) ) {
		case 95: goto tr61;
		case 115: goto st93;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st93:
	if ( ++p == pe )
		goto _out93;
case 93:
	switch( (*p) ) {
		case 95: goto tr61;
		case 108: goto st94;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st94:
	if ( ++p == pe )
		goto _out94;
case 94:
	switch( (*p) ) {
		case 95: goto tr61;
		case 97: goto st95;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st95:
	if ( ++p == pe )
		goto _out95;
case 95:
	switch( (*p) ) {
		case 95: goto tr61;
		case 116: goto st96;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st96:
	if ( ++p == pe )
		goto _out96;
case 96:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto tr100;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st97:
	if ( ++p == pe )
		goto _out97;
case 97:
	switch( (*p) ) {
		case 95: goto tr61;
		case 112: goto st98;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st98:
	if ( ++p == pe )
		goto _out98;
case 98:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto tr101;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st99:
	if ( ++p == pe )
		goto _out99;
case 99:
	switch( (*p) ) {
		case 95: goto tr61;
		case 110: goto st100;
		case 115: goto st102;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st100:
	if ( ++p == pe )
		goto _out100;
case 100:
	switch( (*p) ) {
		case 95: goto tr61;
		case 100: goto st101;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st101:
	if ( ++p == pe )
		goto _out101;
case 101:
	switch( (*p) ) {
		case 95: goto tr61;
		case 111: goto tr96;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st102:
	if ( ++p == pe )
		goto _out102;
case 102:
	switch( (*p) ) {
		case 95: goto tr61;
		case 101: goto st103;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
st103:
	if ( ++p == pe )
		goto _out103;
case 103:
	switch( (*p) ) {
		case 95: goto tr61;
		case 115: goto tr95;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr61;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr61;
	} else
		goto tr61;
	goto tr57;
tr118:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st104;
st104:
	if ( ++p == pe )
		goto _out104;
case 104:
#line 2007 "klscan.cpp"
	if ( (*p) == 37 )
		goto st27;
	goto tr53;
st27:
	if ( ++p == pe )
		goto _out27;
case 27:
	if ( (*p) == 37 )
		goto tr133;
	goto tr131;
	}
	_out28: cs = 28; goto _out; 
	_out29: cs = 29; goto _out; 
	_out30: cs = 30; goto _out; 
	_out0: cs = 0; goto _out; 
	_out1: cs = 1; goto _out; 
	_out31: cs = 31; goto _out; 
	_out2: cs = 2; goto _out; 
	_out32: cs = 32; goto _out; 
	_out3: cs = 3; goto _out; 
	_out4: cs = 4; goto _out; 
	_out33: cs = 33; goto _out; 
	_out5: cs = 5; goto _out; 
	_out6: cs = 6; goto _out; 
	_out7: cs = 7; goto _out; 
	_out34: cs = 34; goto _out; 
	_out35: cs = 35; goto _out; 
	_out36: cs = 36; goto _out; 
	_out37: cs = 37; goto _out; 
	_out38: cs = 38; goto _out; 
	_out8: cs = 8; goto _out; 
	_out9: cs = 9; goto _out; 
	_out39: cs = 39; goto _out; 
	_out40: cs = 40; goto _out; 
	_out41: cs = 41; goto _out; 
	_out10: cs = 10; goto _out; 
	_out11: cs = 11; goto _out; 
	_out42: cs = 42; goto _out; 
	_out12: cs = 12; goto _out; 
	_out13: cs = 13; goto _out; 
	_out14: cs = 14; goto _out; 
	_out43: cs = 43; goto _out; 
	_out44: cs = 44; goto _out; 
	_out45: cs = 45; goto _out; 
	_out46: cs = 46; goto _out; 
	_out47: cs = 47; goto _out; 
	_out48: cs = 48; goto _out; 
	_out15: cs = 15; goto _out; 
	_out49: cs = 49; goto _out; 
	_out16: cs = 16; goto _out; 
	_out17: cs = 17; goto _out; 
	_out50: cs = 50; goto _out; 
	_out51: cs = 51; goto _out; 
	_out52: cs = 52; goto _out; 
	_out53: cs = 53; goto _out; 
	_out54: cs = 54; goto _out; 
	_out55: cs = 55; goto _out; 
	_out56: cs = 56; goto _out; 
	_out57: cs = 57; goto _out; 
	_out58: cs = 58; goto _out; 
	_out59: cs = 59; goto _out; 
	_out60: cs = 60; goto _out; 
	_out61: cs = 61; goto _out; 
	_out62: cs = 62; goto _out; 
	_out63: cs = 63; goto _out; 
	_out64: cs = 64; goto _out; 
	_out65: cs = 65; goto _out; 
	_out66: cs = 66; goto _out; 
	_out18: cs = 18; goto _out; 
	_out19: cs = 19; goto _out; 
	_out20: cs = 20; goto _out; 
	_out21: cs = 21; goto _out; 
	_out22: cs = 22; goto _out; 
	_out23: cs = 23; goto _out; 
	_out67: cs = 67; goto _out; 
	_out68: cs = 68; goto _out; 
	_out69: cs = 69; goto _out; 
	_out70: cs = 70; goto _out; 
	_out71: cs = 71; goto _out; 
	_out72: cs = 72; goto _out; 
	_out73: cs = 73; goto _out; 
	_out74: cs = 74; goto _out; 
	_out75: cs = 75; goto _out; 
	_out76: cs = 76; goto _out; 
	_out77: cs = 77; goto _out; 
	_out78: cs = 78; goto _out; 
	_out79: cs = 79; goto _out; 
	_out80: cs = 80; goto _out; 
	_out81: cs = 81; goto _out; 
	_out82: cs = 82; goto _out; 
	_out83: cs = 83; goto _out; 
	_out84: cs = 84; goto _out; 
	_out24: cs = 24; goto _out; 
	_out25: cs = 25; goto _out; 
	_out26: cs = 26; goto _out; 
	_out85: cs = 85; goto _out; 
	_out86: cs = 86; goto _out; 
	_out87: cs = 87; goto _out; 
	_out88: cs = 88; goto _out; 
	_out89: cs = 89; goto _out; 
	_out90: cs = 90; goto _out; 
	_out91: cs = 91; goto _out; 
	_out92: cs = 92; goto _out; 
	_out93: cs = 93; goto _out; 
	_out94: cs = 94; goto _out; 
	_out95: cs = 95; goto _out; 
	_out96: cs = 96; goto _out; 
	_out97: cs = 97; goto _out; 
	_out98: cs = 98; goto _out; 
	_out99: cs = 99; goto _out; 
	_out100: cs = 100; goto _out; 
	_out101: cs = 101; goto _out; 
	_out102: cs = 102; goto _out; 
	_out103: cs = 103; goto _out; 
	_out104: cs = 104; goto _out; 
	_out27: cs = 27; goto _out; 

	_out: {}
	}
#line 271 "klscan.rl"

		/* Check if we failed. */
		if ( cs == klscan_error ) {
			/* Machine failed before finding a token. */
			cout << "PARSE ERROR" << endl;
			exit(1);
		}

		/* Decide if we need to preserve anything. */
		char *preserve = tokstart;
		if ( inline_start != 0 && ( preserve == 0 || inline_start < preserve ) )
			preserve = inline_start;

		/* Now set up the prefix. */
		if ( preserve == 0 )
			have = 0;
		else {
			/* There is data that needs to be shifted over. */
			have = pe - preserve;
			memmove( buf, preserve, have );
			unsigned int shiftback = preserve - buf;
			if ( tokstart != 0 )
				tokstart -= shiftback;
			if ( inline_start != 0 )
				inline_start -= shiftback;

			tokend -= shiftback;
			litstart -= shiftback;
			litend -= shiftback;
			identstart -= shiftback;
			identend -= shiftback;

			preserve = buf;
		}
	}

	delete[] buf;
}

void scan( char *fileName, istream &input )
{
	ParserDict parserDict;
	do_scan( fileName, input, parserDict, 0 );
}

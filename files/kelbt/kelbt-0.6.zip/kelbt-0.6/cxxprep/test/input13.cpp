
class C { };
namespace ns {}
template <class T> class CT {};

class string{};

int main(int argc, char *argv[])
{
	for ( int (*i)(int K) = 1 ; i < 2 ; i(33)++) {

	}
}

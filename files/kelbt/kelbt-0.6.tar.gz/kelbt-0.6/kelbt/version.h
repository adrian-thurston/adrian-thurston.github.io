#define VERSION "0.6"
#define PUBDATE "December 2006"

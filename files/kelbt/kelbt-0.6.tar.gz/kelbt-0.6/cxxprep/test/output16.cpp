
typedef int $[di T1];
[cn T1] $[di i];

class [cn C] {
	typedef int $[di T2];
	[cn T2] $[di foo];

	int $[di f]({})
	{
		typedef int $[di T3];
		[cn T3] $[di foo];
	}
};

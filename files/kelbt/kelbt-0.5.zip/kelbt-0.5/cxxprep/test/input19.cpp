


class G;
class H {};

template <class T> class I;
template <class T> class J {};

template <class> class I<int> {

};

template <class> void foo();
template <class> void bar()
{
}

int main()
{
	foo<int>(hi);
	bar<int, (i<1), 1>(hi);
	kar < new int*[22];
}

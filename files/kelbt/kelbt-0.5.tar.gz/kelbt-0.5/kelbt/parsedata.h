/*
 *  Copyright 2001-2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _PARSEDATA_H
#define _PARSEDATA_H

#include <iostream>
#include <limits.h>
#include "avlmap.h"
#include "bstmap.h"
#include "dlist.h"
#include "fsmgraph.h"
#include "compare.h"
#include "vector.h"
#include "dlistmel.h"

using std::ostream;


/* Forwards. */
struct RedFsmAp;
struct FsmCodeGen;
struct LangEl;

/* The minimum chars are the absolute value of the real minimum because the
 * sign is stored separately in integers read in so they are compared in the
 * positive. Each is casted to an unsigned because the data part of the number
 * is in unsigned int size. 
 */
#define RL_CHAR_MIN    ((long)((char)CHAR_MIN))
#define RL_CHAR_MAX    ((long)((char)CHAR_MAX))
#define RL_UCHAR_MIN   ((unsigned long)((unsigned char)0))
#define RL_UCHAR_MAX   ((unsigned long)((unsigned char)UCHAR_MAX))
#define RL_SHORT_MIN   ((long)((short)SHRT_MIN))
#define RL_SHORT_MAX   ((long)((short)SHRT_MAX))
#define RL_USHORT_MIN  ((unsigned long)((unsigned short)0))
#define RL_USHORT_MAX  ((unsigned long)((unsigned short)USHRT_MAX))
#define RL_INT_MIN     ((long)((int)INT_MIN))
#define RL_INT_MAX     ((long)((int)INT_MAX))
#define RL_UINT_MIN    ((unsigned long)((unsigned int)0))
#define RL_UINT_MAX    ((unsigned long)((unsigned int)UINT_MAX))
#define RL_LONG_MIN    ((long)LONG_MIN)
#define RL_LONG_MAX    ((long)LONG_MAX)
#define RL_ULONG_MIN   ((unsigned long)0)
#define RL_ULONG_MAX   ((unsigned long)LONG_MAX)

#define SHIFT_CODE 0x1
#define REDUCE_CODE 0x2
#define SHIFT_REDUCE_CODE 0x3

inline long makeReduceCode( long reduction, bool isShiftReduce )
{
	return ( isShiftReduce ? SHIFT_REDUCE_CODE : REDUCE_CODE ) | 
		( reduction << 2 );
}

/* Types of builtin machines. */
enum BuiltinMachine
{
	BT_Any,
	BT_Ascii,
	BT_Extend,
	BT_Alpha,
	BT_Digit,
	BT_Alnum,
	BT_Lower,
	BT_Upper,
	BT_Cntrl,
	BT_Graph,
	BT_Print,
	BT_Punct,
	BT_Space,
	BT_Xdigit,
	BT_Lambda,
	BT_Empty
};

/* Location in an input file. */
struct InputLoc
{
	InputLoc( ) 
		: line(0), col(0) { }
	InputLoc( int line, int col ) 
		: line(line), col(col) { }
	InputLoc( const BISON_YYLTYPE &loc );

	int line;
	int col;
};

/*
 * Inline code tree
 */
struct InlineItem
{
	enum Type 
	{
		Text, 
		Reference
	};

	InlineItem( const InputLoc &loc, char *data, Type type ) : 
		loc(loc), data(data), type(type) { }

	InlineItem( const InputLoc &loc, Type type ) : 
		loc(loc), data(0), type(type) { }
	
	InputLoc loc;
	char *data;
	Type type;

	InlineItem *prev, *next;
};

typedef DList<InlineItem> InlineList;

/* Element in a list of strings used for storing inline code blocks. */
struct InlineBlock
{
	InlineBlock( const InputLoc &loc, InlineList *inlineList ) 
			: loc(loc), inlineList(inlineList) { }

	InputLoc loc;
	InlineList *inlineList;

	InlineBlock *prev, *next;
};

/* List of inline code blocks. */
typedef DList<InlineBlock> InlineBlockList;

/* Element in list of actions. Contains the string for the code to exectute. */
struct Action 
:
	public DListEl<Action>,
	public AvlTreeEl<Action>
{
public:
	Action( const InputLoc &loc, char *name, InlineList *inlineList );

	/* Key for action dictionary. */
	char *getKey() const { return name; }

	/* Data collected during parse. */
	InputLoc loc;
	char *name;
	InlineList *inlineList;
	int actionId;

	/* Number of references in the final machine. */
	bool numRefs() 
		{ return numTransRefs + numToStateRefs + numFromStateRefs + numEofRefs; }
	int numTransRefs;
	int numToStateRefs;
	int numFromStateRefs;
	int numEofRefs;
};

/* A list of actions. */
typedef DList<Action> ActionList;
typedef AvlTree<Action, char *, CmpStr> ActionDict;

/* Structure for reverse action mapping. */
struct RevActionMapEl
{
	char *name;
	InputLoc location;
};

struct Factor;
struct ProdElList;
struct Factor;
struct Literal;
struct Definition;

struct DefListEl { Definition *prev, *next; };
struct LelDefListEl { Definition *prev, *next; };
typedef Vector< LangEl* > LangElVect;
typedef Vector< Factor* > FactorVect;
typedef BstMap< long, long, CmpOrd<long> > RhsRefMap;
typedef BstMapEl< long, long > RhsRefMapEl;

struct TypeDef
{
	TypeDef( char *data, InlineBlock *typeBlock ) 
		: data(data), typeBlock(typeBlock) {}

	char *data;
	InlineBlock *typeBlock;
};

typedef BstMap< char*, TypeDef*, CmpStr > TypeDefMap;
typedef BstMapEl< char*, TypeDef* > TypeDefMapEl;

/* Graph dictionary. */
struct Definition 
:
	public DefListEl, public LelDefListEl
{
	enum Type { Production };

	Definition( const InputLoc &loc, LangEl *prodName, ProdElList *prodElList, 
			bool prodCommit, InlineBlock *redBlock, InlineBlock *undoBlock, 
			InlineBlock *finalBlock, int prodId, Type type ) : 
		loc(loc), prodName(prodName), prodElList(prodElList), prodCommit(prodCommit),
		redBlock(redBlock), undoBlock(undoBlock), finalBlock(finalBlock), 
		prodId(prodId), type(type), fsm(0), fsmLength(0), fssFsmLengths(0), 
		data(0), fssProdIdLow(0), uniqueEmptyLeader(0), isLeftRec(false) {}

	InputLoc loc;
	LangEl *prodName;
	ProdElList *prodElList;
	bool prodCommit;
	InlineBlock *redBlock;
	InlineBlock *undoBlock;
	InlineBlock *finalBlock;
	int prodId;
	Type type;

	FsmAp *fsm;
	FsmAp *storeFsm;
	int fsmLength;
	int *fssFsmLengths;
	char *data;
	int fssProdIdLow;
	LangElVect rhsLelVect;
	FactorVect rhsFactorVect;
	RhsRefMap rhsRefMap;
	LongSet reducesTo;

	LangEl *uniqueEmptyLeader;

	ProdIdSet nonTermFirstSet;
	AlphSet firstSet;
	bool isLeftRec;
};

struct CmpDefById
{
	static int compare( Definition *d1, Definition *d2 )
	{
		if ( d1->prodId < d2->prodId )
			return -1;
		else if ( d1->prodId > d2->prodId )
			return 1;
		else
			return 0;
	}
};


/* Map dotItems to productions. */
typedef BstMap< int, Definition*, CmpOrd<int> > DotItemIndex;
typedef BstMapEl< int, Definition*> DotItemIndexEl;

/* Symbol Map. */
typedef AvlMap< char*, LangEl*, CmpStr > SymbolMap;
typedef AvlMapEl< char*, LangEl* > SymbolMapEl;

/* A vector of production vectors. Each non terminal can have many productions. */
typedef DListMel<Definition, DefListEl> DefList;
typedef DListMel<Definition, LelDefListEl> LelDefList;

/* A set of machines made during a closure round. */
typedef Vector< FsmAp* > Machines;

/* Types of alphabet supported by Kelbt. */
enum AlphType
{
	AT_Char,
	AT_UnsignedChar,
	AT_Short,
	AT_UnsignedShort,
	AT_Int,
	AT_UnsignedInt
};

/* List of language elements. */
typedef DList<LangEl> LelList;

/* Class to collect information about the machine during the 
 * parse of input. */
struct ParseData
{
	/* Create a new parse data object. This is done at the beginning of every
	 * fsm specification. */
	ParseData( char *fileName, char *fsmName, const InputLoc &sectionLoc );
	~ParseData();

	void wrapUserStartSymbol();
	void makeTokens();
	void makeDefinitionNames();
	void noUndefindLangEls();
	void makeLangElIds();

	/* Parser generation. */
	void advanceReductions();
	void sortActions();
	void linkExpansions();
	void lalr1FollowEpsilonOp();

	void transferCommits( TransAp *trans, StateAp *state, long prodId );

	void lalr1AddFollow2( TransAp *trans, FollowToAdd &followKeys );
	void lalr1AddFollow1( StateAp *state );

	void lalr1AddFollow2( TransAp *trans, long followKey );
	void lalr1AddFollow1( TransAp *trans );

	void lalr1AddFollowSets();

	void lr0BringInItem( StateAp *dest, StateAp *prodState, 
			TransAp *expandFrom, Definition *prod );
	void lr0InvokeClosure( StateAp *state );
	void lr0CloseAllStates();

	void lalr1GenerateParser();


	void reduceActions();

	bool makeNonTermFirstSetProd( Definition *prod, StateAp *state );
	void makeNonTermFirstSets();

	bool makeFirstSetProd( Definition *prod, StateAp *state );
	void makeFirstSets();

	StateAp *followProd( StateAp *tabState, StateAp *prodState );
	void findFollow( AlphSet &result, StateAp *overTab, 
			StateAp *overSrc, Definition *parentDef );
	void computeActOrds();
	void computeActOrdsDef( StateAp *tabState, TransAp *tabTrans, TransAp *srcTrans,
			Definition *parentDef, Definition *definition, long &time );
	void computeActOrdsState( StateAp *tabState, 
			StateAp *srcState, Definition *parentDef, long &time );
	void analyzeMachine();
	void resolveReferences( Definition *prod );
	void makeProdFsms();

	void makeGraph();

	/* Generate and write out the fsm. */
	void generateHeader( int endLine );
	void generateCode( bool sawInterface, int endLine );
	void generateGraphviz();

	/*
	 * Querying the parse data
	 */

	/*
	 * Code Generation.
	 */

	void writeFinalBlocks( ostream &out );
	void writeReduceBlocks( ostream &out );
	void writeUndoBlocks( ostream &out );
	void writeTokenDefs( ostream &out );
	void writeTokenIds( ostream &out );
	void writeLangEls( ostream &out );
	void writeHeader( ostream &out );
	void writeParser( ostream &out );
	void writeTables( ostream &out );

	void writeRefThis( ostream &out, Definition *prod, bool user );
	void writeRefNumberFixed( ostream &out, Definition *prod, int rhsPos, 
			int offset, bool user );
	void writeRefNumberStored( ostream &out, Definition *prod, int rhsPos, 
			int offset, bool user );
	void writeReference( ostream &out, Definition *prod, char *data );
	void writeInlinList( ostream &out, Definition *prod, InlineList *inlineList );
	void writeFirstLocate( ostream &out, Definition *prod );
	void writeRhsLocate( ostream &out, Definition *prod );

	std::ostream &UARRAY_TYPE( unsigned long long maxVal );
	std::ostream &SARRAY_TYPE( signed long long maxVal );

	void startCodeGen();
	void endCodeGen( int endLine );

	/* 
	 * Graphviz Generation
	 */
	void writeTransList( ostream &out, StateAp *state );
	void writeDotFile( ostream &out, FsmAp *graph );
	void writeDotFile( );
	
	/*
	 * Data collected during the parse.
	 */

	/* Dictionary of graphs. Both instances and non-instances go here. */
	SymbolMap symbolMap;
    LelList langEls;

	/* The list of instances. */
	DefList regList;
	DefList prodList;

	/* Dumping. */
	DotItemIndex dotItemIndex;

	/* Dictionary of actions. Lets actions be defined and then referenced. */
	ActionDict actionDict;

	/* List of actions. Will be pasted into a switch statement. */
	ActionList actionList;

	/* The id of the next priority name and label. */
//	int nextNameId;
	
	/* Code sections put in the fsms init routine. */
	InlineBlockList initCodeList;

	/* Alphabet type. */
	AlphType alphType;

	/* Element type and get key expression. */
	InlineList *elementType;
	InlineList *getKeyExpr;

	/* The alphabet range. */
	char *lowerNum, *upperNum;
	InputLoc rangeLowLoc, rangeHighLoc;

	/* The name of the file the fsm is from, and the spec name. */
	char *fileName;
	char *fsmName;
	InputLoc sectionLoc;

	/* Number of errors encountered parsing the fsm spec. */
	int errorCount;

	/* Counting the action and priority ordering. */
	int curActionOrd;
	int curPriorOrd;

	/* Counter for assigning ids to longest match items. */
	int nextLongestMatchId;

	/* The code generator, subclasses exist for output style/language. */
	FsmCodeGen *codeGen;

	LangEl *startLangEl;
	LangEl *eofLangEl;
	LangEl *errorLangEl;
	LangEl *userStartLangEl;
	Definition *startDef;

	int nextSymbolId;
	int firstNonTermId;

	LangEl **langElIndex;
	FsmAp *graph;
	StateAp *actionDestState;
	DefSetSet prodSetSet;
	ActionSet actionSet;


	/* Collected machine information. */
	unsigned long long maxState;
	unsigned long long maxAction;
	unsigned long long maxLelId;
	unsigned long long maxOffset;
	unsigned long long maxIndex;
	unsigned long long maxProdLen;

	bool bAnyTokens;
	bool bAnyDefinitions;

	InlineBlock *elementBlock;
	InlineBlock *tokenBlock;
	InlineBlock *preReduceBlock;
	InlineBlock *postReduceBlock;
	InlineBlock *translateBlock;
	InlineBlock *undoTransBlock;
	InlineBlock *tokenFinalBlock;

	Definition **fssProdIdIndex;
	AlphSet literalSet;
	TypeDefMap typeDefMap;

	bool didTokens;
	bool someProdNeedsRhsLocate;

	/* This is something of a hack to determine the location of a commit point
	 * within a production. This mechanism only works with basic linear
	 * grammars. It won't work with inclusion of regular language components. */
	int prodLength;
};

/* Data used by the parser specific to the current file. Supports the include
 * system, since a new parser is executed for each included file. */
struct InputData
{
	InputData( char *fileName, char *includeSpec, char *includeTo ) :
		pd(0), sectionName(0), defaultParseData(0), 
		first_line(1), first_column(1), 
		last_line(1), last_column(0), 
		fileName(fileName), includeSpec(includeSpec), 
		includeTo(includeTo), active(true), 
		lookedUpSection(false) {}

	/* The parse data. For each fsm spec, the parser collects things that it parses
	 * in data structures in here. */
	ParseData *pd;

	/* The the source of the end of the section location varies, sometimes it's
	 * the last token in the only statement or it is the closing '}' */
	InputLoc sectionEndLoc;

	char *sectionName;
	ParseData *defaultParseData;

	typedef Vector<char *> StructStack;
	StructStack structStack;

	int first_line;
	int first_column;
	int last_line;
	int last_column;

	char *fileName;

	/* If this is an included file, this contains the specification to search
	 * for. IncludeTo will contain the spec name that does the includng. */
	char *includeSpec;
	char *includeTo;

	bool active;
	bool lookedUpSection;

	bool sawInterface;
	bool sawStart;

	InputLoc sectionLoc;
};

/* A language element class. Can be a nonTerm or a term. */
struct LangEl : public DListEl<LangEl>
{
	enum Type { Unknown, Term, NonTerm };

	LangEl( char *data, Type type );
	~LangEl();

	/* Parse tree traversal. */
	FsmAp *walk( ParseData *pd );

	char *data;
	Type type;
	long id;
	bool isUserTerm;
	bool isContext;
	TypeDef *typeDef;
	char *displayString;
	int numAppearances;
	bool commit;

	/* Return a string that describes what the lang el is.
	 *   literal-term, term, regular, non-term */
	const char *typeString();

	/* Productions from the language element if it is a non-terminal. */
	LelDefList defList;
};

LangEl *getLangEl( ParseData *pd, char *data, LangEl::Type defType );

struct Factor
{
	/* Language elements a factor node can be. */
	enum Type {
		LiteralType, 
		ReferenceType
	}; 

	/* Construct with a literal fsm. */
	Factor( bool commit, Literal *literal ) :
		commit(commit), literal(literal), type(LiteralType), 
		isReferenced(false), referenceNum(-1), 
		referenceProd(0) { }

	/* Construct with a reference to a var def. */
	Factor( const InputLoc &loc, bool commit, LangEl *langEl ) :
		loc(loc), commit(commit), langEl(langEl), type(ReferenceType), 
		isReferenced(false), referenceNum(-1), 
		referenceProd(0) {}

	/* Cleanup. */
	~Factor();

	/* Tree traversal. */
	FsmAp *walk( ParseData *pd );

	InputLoc loc;
	bool commit;
	Literal *literal;
	LangEl *langEl;
	int lower, upper;
	Type type;
	bool isReferenced;
	int referenceNum;
	Definition *referenceProd;

	Factor *prev, *next;
};

struct ProdElList : public DList<Factor>
{
	FsmAp *walk( ParseData *pd );
};

/* Some literal machine. Can be a number or literal string. */
struct Literal
{
	Literal( const InputLoc &loc, char *str )
		: loc(loc), str(str) { }

	long makeRangeEndPoint( ParseData *pd );
	FsmAp *walk( ParseData *pd );
	
	InputLoc loc;
	char *str;
};


#include "klpdefs.h"

#endif /* _PARSEDATA_H */

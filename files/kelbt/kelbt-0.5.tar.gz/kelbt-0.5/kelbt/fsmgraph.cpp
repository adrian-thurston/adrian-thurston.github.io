/*
 *  Copyright 2001, 2002, 2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <assert.h>
#include <iostream>

using std::cerr;
using std::endl;

#include "fsmgraph.h"
#include "mergesort.h"


/* Callback invoked when another trans (or possibly this) is added into this
 * transition during the merging process.  Draw in any properties of srcTrans
 * into this transition. AddInTrans is called when a new transitions is made
 * that will be a duplicate of another transition or a combination of several
 * other transitions. AddInTrans will be called for each transition that the
 * new transition is to represent. */
void FsmAp::addInTrans( TransAp *destTrans, TransAp *srcTrans )
{
	/* Protect against adding in from ourselves. */
	if ( srcTrans != destTrans ) {
		/* Add in the reductions, or in the shift. */
		destTrans->isShift = destTrans->isShift || srcTrans->isShift;
		destTrans->reductions.insert( srcTrans->reductions );
		destTrans->storeSet.insert( srcTrans->storeSet );
		destTrans->commits.insert( srcTrans->commits );
	}
}

void FsmAp::addInState( StateAp *destState, StateAp *srcState )
{
	/* Draw in any properties of srcState into destState. */
	if ( srcState != destState ) {
		/* Get the epsilons, context, out priorities. */
		destState->pendingCommits.insert( srcState->pendingCommits );
		if ( srcState->pendingCommits.length() > 0 )
			cerr << "THERE ARE PENDING COMMITS DRAWN IN" << endl;

		/* Parser generation data. */
		destState->dotSet.insert( srcState->dotSet );

		if ( srcState->onClosureQueue && !destState->onClosureQueue ) {
			stateClosureQueue.append( destState );
			destState->onClosureQueue = true;
		}
		if ( srcState->followMarked && !destState->followMarked ) {
			followMarkedList.append( destState );
			destState->followMarked = true;
		}
	}
}

/* Make a new state. The new state will be put on the graph's
 * list of state. The new state can be created final or non final. */
StateAp *FsmAp::addState()
{
	/* Make the new state to return. */
	StateAp *state = new StateAp();

	if ( misfitAccounting ) {
		/* Create the new state on the misfit list. All states are created
		 * with no foreign in transitions. */
		misfitList.append( state );
	}
	else {
		/* Create the new state. */
		stateList.append( state );
	}

	return state;
}

/* Construct an FSM that is the concatenation of an array of characters. A new
 * machine will be made that has len+1 states with one transition between each
 * state for each integer in str. IsSigned determines if the integers are to
 * be considered as signed or unsigned ints. */
void FsmAp::concatFsm( long *str, int len )
{
	/* Make the first state and set it as the start state. */
	StateAp *last = addState();
	setStartState( last );

	/* Attach subsequent states. */
	for ( int i = 0; i < len; i++ ) {
		StateAp *newState = addState();
		attachNewTrans( last, newState, str[i], str[i] );
		last = newState;
	}

	/* Make the last state the final state. */
	setFinState( last );
}

/* Construct a machine that matches the empty string.  A new machine will be
 * made with only one state. The new state will be both a start and final
 * state. IsSigned determines if the machine has a signed or unsigned
 * alphabet. Fsm operations must be done on machines with the same alphabet
 * signedness. */
void FsmAp::lambdaFsm( )
{
	/* Give it one state with no transitions making it
	 * the start state and final state. */
	setStartState( addState() );
	setFinState( startState );
}


/* Fsm concatentation worker. Supports treating the concatentation as optional,
 * which essentially leaves the final states of machine one as final. */
void FsmAp::doConcat( FsmAp *other, StateSet *fromStates, bool optional )
{
	/* For the merging process. */
	StateSet finStateSetCopy, startStateSet;
	MergeData md;

	/* Turn on misfit accounting for both graphs. */
	setMisfitAccounting( true );
	other->setMisfitAccounting( true );

	/* Get the other's start state. */
	StateAp *otherStartState = other->startState;

	/* Unset other's start state before bringing in the entry points. */
	other->unsetStartState();

	/* Bring in other's states into our state lists. */
	stateList.append( other->stateList );
	misfitList.append( other->misfitList );

	/* If from states is not set, then get a copy of our final state set before
	 * we clobber it and use it instead. */
	if ( fromStates == 0 ) {
		finStateSetCopy = finStateSet;
		fromStates = &finStateSetCopy;
	}

	/* Unset all of our final states and get the final states from other. */
	if ( !optional )
		unsetAllFinStates();
	finStateSet.insert( other->finStateSet );
	
	/* Since other's lists are empty, we can delete the fsm without
	 * affecting any states. */
	delete other;

	/* Merge our former final states with the start state of other. */
	for ( int i = 0; i < fromStates->length(); i++ ) {
		StateAp *state = fromStates->data[i];

		/* Merge the former final state with other's start state. */
		mergeStates( md, state, otherStartState, true );
	}

	/* Fill in any new states made from merging. */
	fillInStates( md );

	/* Remove the misfits and turn off misfit accounting. */
	removeMisfits();
	setMisfitAccounting( false );
}

/* Concatenates other to the end of this machine. Other is deleted. */
void FsmAp::concatOp( FsmAp *other )
{
	/* Assert same signedness and return graph concatenation op. */
	doConcat( other, 0, false );
}

/* Follow from to the final state of srcFsm. */
StateAp *FsmAp::followFsm( StateAp *from, FsmAp *srcFsm )
{
	StateAp *followSrc = srcFsm->startState;

	while ( ! followSrc->isFinState() ) {
		assert( followSrc->transMap.length() == 1 );
		TransAp *followTrans = followSrc->transMap[0].value;

		TransAp *inTrans = from->findTrans( followTrans->lowKey );
		assert( inTrans != 0 );

		from = inTrans->toState;
		followSrc = followTrans->toState;
	}

	return from;
}

void FsmAp::mergeStates( MergeData &md, StateAp *destState, 
		StateAp *srcState, bool leaving )
{
	/* Get the out transitions. */
	outTransCopy( md, destState, srcState, leaving );

	/* Get its bits and final state status. */
	destState->stateBits |= ( srcState->stateBits & ~SB_ISFINAL );
	if ( srcState->stateBits & SB_ISFINAL )
		setFinState( destState );

	addInState( destState, srcState );
}

void FsmAp::mergeStates( MergeData &md, StateAp *destState, 
		StateAp **srcStates, int numSrc )
{
	for ( int s = 0; s < numSrc; s++ )
		mergeStates( md, destState, srcStates[s], false );
}

void FsmAp::fillInStates( MergeData &md )
{
	/* Merge any states that are awaiting merging. This will likey cause
	 * other states to be added to the stfil list. */
	StateAp *state = md.stfillHead;
	while ( state != 0 ) {
		StateSet *stateSet = &state->stateDictEl->stateSet;
		mergeStates( md, state, stateSet->data, stateSet->length() );
		state = state->alg_next;
	}

	/* Delete the state sets of all states that are on the fill list. */
	state = md.stfillHead;
	while ( state != 0 ) {
		/* Delete and reset the state set. */
		delete state->stateDictEl;
		state->stateDictEl = 0;

		/* Next state in the stfill list. */
		state = state->alg_next;
	}

	/* StateDict will still have it's ptrs/size set but all of it's element
	 * will be deleted so we don't need to clean it up. */
}

int FsmAp::fsmLength( )
{
	int length = 0;
	StateAp *state = startState;
	while ( ! state->isFinState() ) {
		length += 1;
		state = state->transMap[0].value->toState;
	}
	return length;
}

int FsmAp::fsmLength2( int storeNum )
{
	int length = 0;
	StateAp *state = startState;
	TransAp *trans = state->transMap[0].value;
	while ( trans->storeSet.find( storeNum ) == 0 ) {
		length += 1;
		state = trans->toState;
		trans = state->transMap[0].value;
	}
	return length;
}

void FsmAp::removeStore( StateAp *from, int storeNum, int rhsPos )
{
	if ( rhsPos == 0 ) {
		for ( TransMap::Iter trans = from->transMap; trans.lte(); trans++ )
			trans->value->storeSet.remove( storeNum );
	}
	else {
		int newRhsPos = rhsPos-1;
		for ( TransMap::Iter trans = from->transMap; trans.lte(); trans++ )
			removeStore( trans->value->toState, storeNum, newRhsPos );
	}
}

void FsmAp::removeStore( int storeNum, int rhsPos )
{
	removeStore( startState, storeNum, rhsPos );
}

void FsmAp::setCommit( int length )
{
	/* Recurse on everything ranges. */
	for ( TransMap::Iter trans = startState->transMap; trans.lte(); trans++ ) {
		if ( trans->value->toState != 0 )
			trans->value->commits.insert( length );
	}
}

/* Remove states that have no path to them from the start state. Recursively
 * traverses the graph marking states that have paths into them. Then removes
 * all states that did not get marked. */
void FsmAp::removeUnreachableStates()
{
	/* Misfit accounting should be off and there should be no states on the
	 * misfit list. */
	assert( !misfitAccounting && misfitList.length() == 0 );

	/* Mark all the states that can be reached 
	 * through the existing set of entry points. */
	markReachableFromHere( startState );

	/* Delete all states that are not marked
	 * and unmark the ones that are marked. */
	StateAp *state = stateList.head;
	while ( state ) {
		StateAp *next = state->next;

		if ( state->stateBits & SB_ISMARKED )
			state->stateBits &= ~ SB_ISMARKED;
		else {
			detachState( state );
			stateList.detach( state );
			delete state;
		}

		state = next;
	}
}

/* Remove states on the misfit list. To work properly misfit accounting should
 * be on when this is called. The detaching of a state will likely cause
 * another misfit to be collected and it can then be removed. */
void FsmAp::removeMisfits()
{
	while ( misfitList.length() > 0 ) {
		/* Get the first state. */
		StateAp *state = misfitList.head;

		/* Detach and delete. */
		detachState( state );

		/* The state was previously on the misfit list and detaching can only
		 * remove in transitions so the state must still be on the misfit
		 * list. */
		misfitList.detach( state );
		delete state;
	}
}


#define VERSION "0.7"
#define PUBDATE "December 2006"

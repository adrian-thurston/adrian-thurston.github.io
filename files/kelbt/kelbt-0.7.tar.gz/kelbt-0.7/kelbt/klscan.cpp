#line 1 "klscan.rl"
/*
 *  Copyright 2006 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <fstream>
#include <string.h>

#include "kelbt.h"
#include "klparse.h"

using std::ifstream;
using std::istream;
using std::ostream;
using std::cout;
using std::cerr;
using std::endl;


#line 39 "klscan.cpp"
static const int section_parser_start = 5;

static const int section_parser_first_final = 5;

static const int section_parser_error = 1;

#line 39 "klscan.rl"


struct Scanner
{
	Scanner( char *fileName, istream &input, 
			ParserDict &parserDict, int include_depth ) : 
		fileName(fileName), input(input), 
		parserDict(parserDict), include_depth(include_depth),
		parser(0), curline(1)
	{
		
#line 58 "klscan.cpp"
	{
	cs = section_parser_start;
	}
#line 50 "klscan.rl"
	}
	
	void do_scan();
	void try_token( int tokid, char *start, char *end );

	/* Open an error message with the file name and line. */
	ostream &error()
	{
		/* Keep the error count. */
		gblErrorCount += 1;
	
		cerr << fileName << ":" << curline << ": ";
		return cerr;
	}

	char *fileName;
	istream &input;
	ParserDict &parserDict;
	int include_depth;
	Parser *parser;
	int curline;

	/* For section parser. */
	int cs;
	char *captured;
};

void Scanner::try_token( int tokid, char *start, char *end )
{
	char *tokdata = 0;
	int *p = &tokid, *pe = &tokid + 1;

	if ( start != 0 ) {
		int len = end-start;
		tokdata = new char[len+1];
		memcpy( tokdata, start, len );
		tokdata[len] = 0;
	}


#line 103 "klscan.cpp"
	{
	if ( p == pe )
		goto _out;
	switch ( cs )
	{
tr0:
#line 139 "klscan.rl"
	{
		if ( parser == 0 )
			error() << "no section name and no previously named section" << endl;
		else {
			int result = parser->token( tokid, tokdata );
			if ( result < 0 )
				error() << "parse error on or near this line" << endl;
		}
	}
	goto st5;
tr6:
#line 99 "klscan.rl"
	{
		//cout << "PARSER STATEMENT" << endl;

		char *parserName = captured;
		ParserDictEl *pdEl = parserDict.find( parserName );
		if ( pdEl != 0 ) {
			//cout << "USING EXISTING PARSER" << endl;
			delete[] parserName;
		}
		else {
			//cout << "CREATING NEW PARSER" << endl;
			pdEl = new ParserDictEl;
			pdEl->name = parserName;
			pdEl->parser = new Parser( fileName, parserName );
			pdEl->parser->init();
			parserDict.insert( pdEl );
		}

		parser = pdEl->parser;
		parser->startSection();
	}
	goto st5;
tr7:
#line 122 "klscan.rl"
	{
		char *includeFileName = captured;

		//cout << "INCLUDE STATEMENT " << includeFileName << endl;

		/* Open the input file for reading. */
		ifstream *inFile = new ifstream( includeFileName );
		istream *inStream = inFile;
		if ( ! inFile->is_open() )
			error() << "include: could not open " << includeFileName << " for reading" << endl;

		Scanner subScanner( includeFileName, *inStream, parserDict, include_depth+1 );
		subScanner.do_scan();

		delete inFile;
	}
	goto st5;
st5:
	if ( ++p == pe )
		goto _out5;
case 5:
#line 168 "klscan.cpp"
	switch( (*p) ) {
		case 128: goto st0;
		case 129: goto st3;
	}
	goto tr0;
st0:
	if ( ++p == pe )
		goto _out0;
case 0:
	if ( (*p) == 130 )
		goto tr5;
	goto st1;
st1:
	goto _out1;
tr5:
#line 149 "klscan.rl"
	{ captured = tokdata; }
	goto st2;
st2:
	if ( ++p == pe )
		goto _out2;
case 2:
#line 191 "klscan.cpp"
	if ( (*p) == 59 )
		goto tr6;
	goto st1;
st3:
	if ( ++p == pe )
		goto _out3;
case 3:
	if ( (*p) == 131 )
		goto tr3;
	goto st1;
tr3:
#line 150 "klscan.rl"
	{ captured = tokdata; }
	goto st4;
st4:
	if ( ++p == pe )
		goto _out4;
case 4:
#line 210 "klscan.cpp"
	if ( (*p) == 59 )
		goto tr7;
	goto st1;
	}
	_out5: cs = 5; goto _out; 
	_out0: cs = 0; goto _out; 
	_out1: cs = 1; goto _out; 
	_out2: cs = 2; goto _out; 
	_out3: cs = 3; goto _out; 
	_out4: cs = 4; goto _out; 

	_out: {}
	}
#line 164 "klscan.rl"

}

#line 277 "klscan.rl"



#line 232 "klscan.cpp"
static const int klscan_start = 21;

static const int klscan_first_final = 21;

static const int klscan_error = -1;

#line 280 "klscan.rl"

void Scanner::do_scan()
{
	int bufsize = 8;
	char *buf = new char[bufsize];
	const char last_char = 0;
	char *tokstart, *tokend;
	int cs, act, have = 0;
	int curly_count = 0;
	char *inline_start = 0;
	char *litstart = 0, *litend = 0;
	char *identstart = 0, *identend = 0;
	bool execute = true;

	
#line 255 "klscan.cpp"
	{
	cs = klscan_start;
	tokstart = 0;
	tokend = 0;
	act = 0;
	}
#line 295 "klscan.rl"

	while ( execute ) {
		char *p = buf + have;
		int space = bufsize - have;

		if ( space == 0 ) {
			/* We filled up the buffer trying to scan a token. Grow it. */
			bufsize = bufsize * 2;
			char *newbuf = new char[bufsize];
			//cout << "FULL BUFFER, NEW SIZE: " << bufsize << endl;

			/* Recompute p and space. */
			p = newbuf + have;
			space = bufsize - have;

			/* Patch up pointers possibly in use. */
			if ( tokstart != 0 )
				tokstart = newbuf + ( tokstart - buf );
			if ( inline_start != 0 )
				inline_start = newbuf + ( inline_start - buf );
			tokend = newbuf + ( tokend - buf );
			litstart = newbuf + ( litstart - buf );
			litend = newbuf + ( litend - buf );
			identstart = newbuf + ( identstart - buf );
			identend = newbuf + ( identend - buf );

			/* Copy the new buffer in. */
			memcpy( newbuf, buf, have );
			delete[] buf;
			buf = newbuf;
		}

		input.read( p, space );
		int len = input.gcount();

		/* If we see eof then append the EOF char. */
	 	if ( len == 0 ) {
			p[0] = last_char, len = 1;
			execute = false;
		}

		char *pe = p + len;
		
#line 306 "klscan.cpp"
	{
	if ( p == pe )
		goto _out;
	switch ( cs )
	{
tr1:
#line 260 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st21;
tr2:
#line 260 "klscan.rl"
	{tokend = p+1;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}}
	goto st21;
tr6:
#line 260 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st21;
tr8:
#line 260 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st21;
tr10:
#line 260 "klscan.rl"
	{tokend = p;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}p--;}
	goto st21;
tr16:
#line 260 "klscan.rl"
	{tokend = p+1;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}}
	goto st21;
tr17:
#line 273 "klscan.rl"
	{tokend = p+1;}
	goto st21;
tr24:
#line 260 "klscan.rl"
	{tokend = p+1;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}}
	goto st21;
tr25:
#line 260 "klscan.rl"
	{{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}{p = ((tokend))-1;}}
	goto st21;
tr26:
#line 174 "klscan.rl"
	{ curline++; }
#line 260 "klscan.rl"
	{tokend = p+1;{
		if ( !generateGraphviz && gblErrorCount == 0 && include_depth == 0 )
			outStream->write( tokstart, tokend-tokstart );
	}}
	goto st21;
tr27:
#line 271 "klscan.rl"
	{tokend = p+1;{ {goto st39;} }}
	goto st21;
st21:
#line 1 "klscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out21;
case 21:
#line 1 "klscan.rl"
	{tokstart = p;}
#line 393 "klscan.cpp"
	switch( (*p) ) {
		case 0: goto tr17;
		case 9: goto st22;
		case 10: goto tr12;
		case 13: goto st22;
		case 32: goto st22;
		case 34: goto tr18;
		case 37: goto tr19;
		case 39: goto tr20;
		case 47: goto tr21;
		case 95: goto st28;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st27;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st28;
	} else
		goto st28;
	goto tr16;
tr12:
#line 174 "klscan.rl"
	{ curline++; }
	goto st22;
st22:
	if ( ++p == pe )
		goto _out22;
case 22:
#line 423 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st22;
		case 10: goto tr12;
		case 13: goto st22;
		case 32: goto st22;
	}
	goto tr10;
tr18:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st23;
st23:
	if ( ++p == pe )
		goto _out23;
case 23:
#line 439 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr1;
		case 13: goto tr1;
		case 34: goto tr2;
		case 92: goto st1;
	}
	goto st0;
st0:
	if ( ++p == pe )
		goto _out0;
case 0:
	switch( (*p) ) {
		case 10: goto tr25;
		case 13: goto tr25;
		case 34: goto tr2;
		case 92: goto st1;
	}
	goto st0;
st1:
	if ( ++p == pe )
		goto _out1;
case 1:
	goto st0;
tr19:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st24;
st24:
	if ( ++p == pe )
		goto _out24;
case 24:
#line 471 "klscan.cpp"
	if ( (*p) == 37 )
		goto st2;
	goto tr1;
st2:
	if ( ++p == pe )
		goto _out2;
case 2:
	if ( (*p) == 123 )
		goto tr27;
	goto tr25;
tr20:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st25;
st25:
	if ( ++p == pe )
		goto _out25;
case 25:
#line 490 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr1;
		case 13: goto tr1;
		case 39: goto tr2;
		case 92: goto st4;
	}
	goto st3;
st3:
	if ( ++p == pe )
		goto _out3;
case 3:
	switch( (*p) ) {
		case 10: goto tr25;
		case 13: goto tr25;
		case 39: goto tr2;
		case 92: goto st4;
	}
	goto st3;
st4:
	if ( ++p == pe )
		goto _out4;
case 4:
	goto st3;
tr21:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st26;
st26:
	if ( ++p == pe )
		goto _out26;
case 26:
#line 522 "klscan.cpp"
	switch( (*p) ) {
		case 42: goto st5;
		case 47: goto st7;
	}
	goto tr1;
tr22:
#line 174 "klscan.rl"
	{ curline++; }
	goto st5;
st5:
	if ( ++p == pe )
		goto _out5;
case 5:
#line 536 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr22;
		case 42: goto st6;
	}
	goto st5;
st6:
	if ( ++p == pe )
		goto _out6;
case 6:
	switch( (*p) ) {
		case 10: goto tr22;
		case 42: goto st6;
		case 47: goto tr24;
	}
	goto st5;
st7:
	if ( ++p == pe )
		goto _out7;
case 7:
	if ( (*p) == 10 )
		goto tr26;
	goto st7;
st27:
	if ( ++p == pe )
		goto _out27;
case 27:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st27;
	goto tr8;
st28:
	if ( ++p == pe )
		goto _out28;
case 28:
	if ( (*p) == 95 )
		goto st28;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st28;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st28;
	} else
		goto st28;
	goto tr6;
tr29:
#line 214 "klscan.rl"
	{tokend = p;p--;}
	goto st29;
tr30:
#line 193 "klscan.rl"
	{tokend = p+1;}
	goto st29;
tr34:
#line 190 "klscan.rl"
	{tokend = p;p--;}
	goto st29;
tr36:
#line 191 "klscan.rl"
	{tokend = p;p--;}
	goto st29;
tr38:
#line 194 "klscan.rl"
	{tokend = p;p--;}
	goto st29;
tr41:
#line 207 "klscan.rl"
	{tokend = p;{
			if ( inline_start < tokstart )
				try_token( TK_Inline, inline_start, tokstart );
			try_token( TK_Reference, tokstart, tokend );
			inline_start = tokend;
		}p--;}
	goto st29;
tr45:
#line 207 "klscan.rl"
	{tokend = p+1;{
			if ( inline_start < tokstart )
				try_token( TK_Inline, inline_start, tokstart );
			try_token( TK_Reference, tokstart, tokend );
			inline_start = tokend;
		}}
	goto st29;
tr46:
#line 214 "klscan.rl"
	{tokend = p+1;}
	goto st29;
tr52:
#line 196 "klscan.rl"
	{tokend = p+1;{ curly_count += 1; }}
	goto st29;
tr53:
#line 198 "klscan.rl"
	{tokend = p+1;{ 
			if ( --curly_count == 0 ) {
				/* Send the entire block and free the inline_start pointer. */
				try_token( TK_Inline, inline_start, tokend );
				inline_start = 0;
				{goto st39;}
			}
		}}
	goto st29;
tr56:
#line 192 "klscan.rl"
	{tokend = p+1;}
	goto st29;
tr57:
#line 214 "klscan.rl"
	{{p = ((tokend))-1;}}
	goto st29;
tr58:
#line 174 "klscan.rl"
	{ curline++; }
#line 192 "klscan.rl"
	{tokend = p+1;}
	goto st29;
st29:
#line 1 "klscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out29;
case 29:
#line 1 "klscan.rl"
	{tokstart = p;}
#line 660 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st30;
		case 10: goto tr40;
		case 13: goto st30;
		case 32: goto st30;
		case 34: goto tr47;
		case 36: goto st32;
		case 39: goto tr49;
		case 47: goto tr50;
		case 64: goto st37;
		case 95: goto st38;
		case 123: goto tr52;
		case 125: goto tr53;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st36;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st38;
	} else
		goto st38;
	goto tr46;
tr40:
#line 174 "klscan.rl"
	{ curline++; }
	goto st30;
st30:
	if ( ++p == pe )
		goto _out30;
case 30:
#line 692 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st30;
		case 10: goto tr40;
		case 13: goto st30;
		case 32: goto st30;
	}
	goto tr38;
tr47:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st31;
st31:
	if ( ++p == pe )
		goto _out31;
case 31:
#line 708 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr29;
		case 13: goto tr29;
		case 34: goto tr30;
		case 92: goto st9;
	}
	goto st8;
st8:
	if ( ++p == pe )
		goto _out8;
case 8:
	switch( (*p) ) {
		case 10: goto tr57;
		case 13: goto tr57;
		case 34: goto tr30;
		case 92: goto st9;
	}
	goto st8;
st9:
	if ( ++p == pe )
		goto _out9;
case 9:
	goto st8;
st32:
	if ( ++p == pe )
		goto _out32;
case 32:
	if ( (*p) == 36 )
		goto tr45;
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st33;
	goto tr29;
st33:
	if ( ++p == pe )
		goto _out33;
case 33:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st33;
	goto tr41;
tr49:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st34;
st34:
	if ( ++p == pe )
		goto _out34;
case 34:
#line 756 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr29;
		case 13: goto tr29;
		case 39: goto tr30;
		case 92: goto st11;
	}
	goto st10;
st10:
	if ( ++p == pe )
		goto _out10;
case 10:
	switch( (*p) ) {
		case 10: goto tr57;
		case 13: goto tr57;
		case 39: goto tr30;
		case 92: goto st11;
	}
	goto st10;
st11:
	if ( ++p == pe )
		goto _out11;
case 11:
	goto st10;
tr50:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st35;
st35:
	if ( ++p == pe )
		goto _out35;
case 35:
#line 788 "klscan.cpp"
	switch( (*p) ) {
		case 42: goto st12;
		case 47: goto st14;
	}
	goto tr29;
tr54:
#line 174 "klscan.rl"
	{ curline++; }
	goto st12;
st12:
	if ( ++p == pe )
		goto _out12;
case 12:
#line 802 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr54;
		case 42: goto st13;
	}
	goto st12;
st13:
	if ( ++p == pe )
		goto _out13;
case 13:
	switch( (*p) ) {
		case 10: goto tr54;
		case 42: goto st13;
		case 47: goto tr56;
	}
	goto st12;
st14:
	if ( ++p == pe )
		goto _out14;
case 14:
	if ( (*p) == 10 )
		goto tr58;
	goto st14;
st36:
	if ( ++p == pe )
		goto _out36;
case 36:
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st36;
	goto tr36;
st37:
	if ( ++p == pe )
		goto _out37;
case 37:
	if ( (*p) == 64 )
		goto tr45;
	if ( 48 <= (*p) && (*p) <= 57 )
		goto st33;
	goto tr29;
st38:
	if ( ++p == pe )
		goto _out38;
case 38:
	if ( (*p) == 95 )
		goto st38;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto st38;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto st38;
	} else
		goto st38;
	goto tr34;
tr60:
#line 257 "klscan.rl"
	{tokend = p;{ try_token( *tokstart, 0, 0 ); }p--;}
	goto st39;
tr63:
#line 237 "klscan.rl"
	{tokend = p+1;{ try_token( TK_String, tokstart+1, tokend-1 ); }}
	goto st39;
tr66:
#line 174 "klscan.rl"
	{ curline++; }
#line 238 "klscan.rl"
	{tokend = p+1;}
	goto st39;
tr67:
#line 235 "klscan.rl"
	{tokend = p;{ try_token( TK_Word, tokstart, tokend ); }p--;}
	goto st39;
tr105:
#line 249 "klscan.rl"
	{tokend = p;p--;}
	goto st39;
tr109:
#line 1 "klscan.rl"
	{	switch( act ) {
	case 10:
	{ try_token( KW_Commit, 0, 0 ); }
	break;
	case 11:
	{ try_token( KW_Try, 0, 0 ); }
	break;
	case 12:
	{ try_token( KW_Undo, 0, 0 ); }
	break;
	case 13:
	{ try_token( KW_Final, 0, 0 ); }
	break;
	case 14:
	{ try_token( KW_Translate, 0, 0 ); }
	break;
	case 15:
	{ try_token( KW_Token, 0, 0 ); }
	break;
	case 16:
	{ try_token( KW_NonTerm, 0, 0 ); }
	break;
	case 17:
	{ try_token( KW_Uses, 0, 0 ); }
	break;
	case 18:
	{ try_token( KW_Type, 0, 0 ); }
	break;
	case 19:
	{ try_token( KW_Interface, 0, 0 ); }
	break;
	case 20:
	{ try_token( KW_Parser, 0, 0 ); }
	break;
	case 21:
	{ try_token( KW_Include, 0, 0 ); }
	break;
	case 22:
	{ try_token( TK_Word, tokstart, tokend ); }
	break;
	default: break;
	}
	{p = ((tokend))-1;}}
	goto st39;
tr110:
#line 257 "klscan.rl"
	{tokend = p+1;{ try_token( *tokstart, 0, 0 ); }}
	goto st39;
tr121:
#line 251 "klscan.rl"
	{tokend = p+1;{ 
			inline_start = tokstart;
			curly_count = 1; 
			{goto st29;}
		}}
	goto st39;
tr123:
#line 257 "klscan.rl"
	{{ try_token( *tokstart, 0, 0 ); }{p = ((tokend))-1;}}
	goto st39;
tr124:
#line 236 "klscan.rl"
	{tokend = p+1;{ try_token( TK_Literal, tokstart+1, tokend-1 ); }}
	goto st39;
tr125:
#line 240 "klscan.rl"
	{tokend = p+1;{ 
			/* In order to generate anything we must be in the top level file
			 * and the current spec must be active and there must not have been
			 * any parse errors. */
			if ( include_depth == 0 && parser != 0 ) 
				parser->endSection();
			{goto st21;}
		}}
	goto st39;
st39:
#line 1 "klscan.rl"
	{tokstart = 0;}
	if ( ++p == pe )
		goto _out39;
case 39:
#line 1 "klscan.rl"
	{tokstart = p;}
#line 963 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st40;
		case 10: goto tr107;
		case 13: goto st40;
		case 32: goto st40;
		case 34: goto tr111;
		case 35: goto tr112;
		case 39: goto tr113;
		case 95: goto tr68;
		case 99: goto st45;
		case 102: goto st50;
		case 105: goto st54;
		case 110: goto st66;
		case 112: goto st72;
		case 116: goto st77;
		case 117: goto st90;
		case 123: goto tr121;
		case 125: goto tr122;
	}
	if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else if ( (*p) >= 65 )
		goto tr68;
	goto tr110;
tr107:
#line 174 "klscan.rl"
	{ curline++; }
	goto st40;
st40:
	if ( ++p == pe )
		goto _out40;
case 40:
#line 997 "klscan.cpp"
	switch( (*p) ) {
		case 9: goto st40;
		case 10: goto tr107;
		case 13: goto st40;
		case 32: goto st40;
	}
	goto tr105;
tr111:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st41;
st41:
	if ( ++p == pe )
		goto _out41;
case 41:
#line 1013 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr60;
		case 13: goto tr60;
		case 34: goto tr63;
		case 92: goto st16;
	}
	goto st15;
st15:
	if ( ++p == pe )
		goto _out15;
case 15:
	switch( (*p) ) {
		case 10: goto tr123;
		case 13: goto tr123;
		case 34: goto tr63;
		case 92: goto st16;
	}
	goto st15;
st16:
	if ( ++p == pe )
		goto _out16;
case 16:
	goto st15;
tr112:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st42;
st42:
	if ( ++p == pe )
		goto _out42;
case 42:
#line 1045 "klscan.cpp"
	if ( (*p) == 10 )
		goto tr66;
	goto st17;
st17:
	if ( ++p == pe )
		goto _out17;
case 17:
	if ( (*p) == 10 )
		goto tr66;
	goto st17;
tr113:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st43;
st43:
	if ( ++p == pe )
		goto _out43;
case 43:
#line 1064 "klscan.cpp"
	switch( (*p) ) {
		case 10: goto tr60;
		case 13: goto tr60;
		case 39: goto tr60;
		case 92: goto st19;
	}
	goto st18;
st18:
	if ( ++p == pe )
		goto _out18;
case 18:
	if ( (*p) == 39 )
		goto tr124;
	goto tr123;
st19:
	if ( ++p == pe )
		goto _out19;
case 19:
	goto st18;
tr68:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 235 "klscan.rl"
	{act = 22;}
	goto st44;
tr71:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 220 "klscan.rl"
	{act = 11;}
	goto st44;
tr94:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 219 "klscan.rl"
	{act = 10;}
	goto st44;
tr95:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 226 "klscan.rl"
	{act = 17;}
	goto st44;
tr96:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 229 "klscan.rl"
	{act = 20;}
	goto st44;
tr97:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 221 "klscan.rl"
	{act = 12;}
	goto st44;
tr98:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 224 "klscan.rl"
	{act = 15;}
	goto st44;
tr99:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 225 "klscan.rl"
	{act = 16;}
	goto st44;
tr100:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 222 "klscan.rl"
	{act = 13;}
	goto st44;
tr101:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 223 "klscan.rl"
	{act = 14;}
	goto st44;
tr102:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 227 "klscan.rl"
	{act = 18;}
	goto st44;
tr103:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 228 "klscan.rl"
	{act = 19;}
	goto st44;
tr104:
#line 1 "klscan.rl"
	{tokend = p+1;}
#line 230 "klscan.rl"
	{act = 21;}
	goto st44;
st44:
	if ( ++p == pe )
		goto _out44;
case 44:
#line 1166 "klscan.cpp"
	if ( (*p) == 95 )
		goto tr68;
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr109;
st45:
	if ( ++p == pe )
		goto _out45;
case 45:
	switch( (*p) ) {
		case 95: goto tr68;
		case 111: goto st46;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st46:
	if ( ++p == pe )
		goto _out46;
case 46:
	switch( (*p) ) {
		case 95: goto tr68;
		case 109: goto st47;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st47:
	if ( ++p == pe )
		goto _out47;
case 47:
	switch( (*p) ) {
		case 95: goto tr68;
		case 109: goto st48;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st48:
	if ( ++p == pe )
		goto _out48;
case 48:
	switch( (*p) ) {
		case 95: goto tr68;
		case 105: goto st49;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st49:
	if ( ++p == pe )
		goto _out49;
case 49:
	switch( (*p) ) {
		case 95: goto tr68;
		case 116: goto tr94;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st50:
	if ( ++p == pe )
		goto _out50;
case 50:
	switch( (*p) ) {
		case 95: goto tr68;
		case 105: goto st51;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st51:
	if ( ++p == pe )
		goto _out51;
case 51:
	switch( (*p) ) {
		case 95: goto tr68;
		case 110: goto st52;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st52:
	if ( ++p == pe )
		goto _out52;
case 52:
	switch( (*p) ) {
		case 95: goto tr68;
		case 97: goto st53;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st53:
	if ( ++p == pe )
		goto _out53;
case 53:
	switch( (*p) ) {
		case 95: goto tr68;
		case 108: goto tr100;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st54:
	if ( ++p == pe )
		goto _out54;
case 54:
	switch( (*p) ) {
		case 95: goto tr68;
		case 110: goto st55;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st55:
	if ( ++p == pe )
		goto _out55;
case 55:
	switch( (*p) ) {
		case 95: goto tr68;
		case 99: goto st56;
		case 116: goto st60;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st56:
	if ( ++p == pe )
		goto _out56;
case 56:
	switch( (*p) ) {
		case 95: goto tr68;
		case 108: goto st57;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st57:
	if ( ++p == pe )
		goto _out57;
case 57:
	switch( (*p) ) {
		case 95: goto tr68;
		case 117: goto st58;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st58:
	if ( ++p == pe )
		goto _out58;
case 58:
	switch( (*p) ) {
		case 95: goto tr68;
		case 100: goto st59;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st59:
	if ( ++p == pe )
		goto _out59;
case 59:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto tr104;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st60:
	if ( ++p == pe )
		goto _out60;
case 60:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto st61;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st61:
	if ( ++p == pe )
		goto _out61;
case 61:
	switch( (*p) ) {
		case 95: goto tr68;
		case 114: goto st62;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st62:
	if ( ++p == pe )
		goto _out62;
case 62:
	switch( (*p) ) {
		case 95: goto tr68;
		case 102: goto st63;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st63:
	if ( ++p == pe )
		goto _out63;
case 63:
	switch( (*p) ) {
		case 95: goto tr68;
		case 97: goto st64;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st64:
	if ( ++p == pe )
		goto _out64;
case 64:
	switch( (*p) ) {
		case 95: goto tr68;
		case 99: goto st65;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st65:
	if ( ++p == pe )
		goto _out65;
case 65:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto tr103;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st66:
	if ( ++p == pe )
		goto _out66;
case 66:
	switch( (*p) ) {
		case 95: goto tr68;
		case 111: goto st67;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st67:
	if ( ++p == pe )
		goto _out67;
case 67:
	switch( (*p) ) {
		case 95: goto tr68;
		case 110: goto st68;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st68:
	if ( ++p == pe )
		goto _out68;
case 68:
	switch( (*p) ) {
		case 95: goto tr68;
		case 116: goto st69;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st69:
	if ( ++p == pe )
		goto _out69;
case 69:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto st70;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st70:
	if ( ++p == pe )
		goto _out70;
case 70:
	switch( (*p) ) {
		case 95: goto tr68;
		case 114: goto st71;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st71:
	if ( ++p == pe )
		goto _out71;
case 71:
	switch( (*p) ) {
		case 95: goto tr68;
		case 109: goto tr99;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st72:
	if ( ++p == pe )
		goto _out72;
case 72:
	switch( (*p) ) {
		case 95: goto tr68;
		case 97: goto st73;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st73:
	if ( ++p == pe )
		goto _out73;
case 73:
	switch( (*p) ) {
		case 95: goto tr68;
		case 114: goto st74;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st74:
	if ( ++p == pe )
		goto _out74;
case 74:
	switch( (*p) ) {
		case 95: goto tr68;
		case 115: goto st75;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st75:
	if ( ++p == pe )
		goto _out75;
case 75:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto st76;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st76:
	if ( ++p == pe )
		goto _out76;
case 76:
	switch( (*p) ) {
		case 95: goto tr68;
		case 114: goto tr96;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st77:
	if ( ++p == pe )
		goto _out77;
case 77:
	switch( (*p) ) {
		case 95: goto tr68;
		case 111: goto st78;
		case 114: goto st81;
		case 121: goto st88;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st78:
	if ( ++p == pe )
		goto _out78;
case 78:
	switch( (*p) ) {
		case 95: goto tr68;
		case 107: goto st79;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st79:
	if ( ++p == pe )
		goto _out79;
case 79:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto st80;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st80:
	if ( ++p == pe )
		goto _out80;
case 80:
	switch( (*p) ) {
		case 95: goto tr68;
		case 110: goto tr98;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st81:
	if ( ++p == pe )
		goto _out81;
case 81:
	switch( (*p) ) {
		case 95: goto tr68;
		case 97: goto st82;
		case 121: goto tr71;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st82:
	if ( ++p == pe )
		goto _out82;
case 82:
	switch( (*p) ) {
		case 95: goto tr68;
		case 110: goto st83;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st83:
	if ( ++p == pe )
		goto _out83;
case 83:
	switch( (*p) ) {
		case 95: goto tr68;
		case 115: goto st84;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st84:
	if ( ++p == pe )
		goto _out84;
case 84:
	switch( (*p) ) {
		case 95: goto tr68;
		case 108: goto st85;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st85:
	if ( ++p == pe )
		goto _out85;
case 85:
	switch( (*p) ) {
		case 95: goto tr68;
		case 97: goto st86;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 98 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st86:
	if ( ++p == pe )
		goto _out86;
case 86:
	switch( (*p) ) {
		case 95: goto tr68;
		case 116: goto st87;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st87:
	if ( ++p == pe )
		goto _out87;
case 87:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto tr101;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st88:
	if ( ++p == pe )
		goto _out88;
case 88:
	switch( (*p) ) {
		case 95: goto tr68;
		case 112: goto st89;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st89:
	if ( ++p == pe )
		goto _out89;
case 89:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto tr102;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st90:
	if ( ++p == pe )
		goto _out90;
case 90:
	switch( (*p) ) {
		case 95: goto tr68;
		case 110: goto st91;
		case 115: goto st93;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st91:
	if ( ++p == pe )
		goto _out91;
case 91:
	switch( (*p) ) {
		case 95: goto tr68;
		case 100: goto st92;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st92:
	if ( ++p == pe )
		goto _out92;
case 92:
	switch( (*p) ) {
		case 95: goto tr68;
		case 111: goto tr97;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st93:
	if ( ++p == pe )
		goto _out93;
case 93:
	switch( (*p) ) {
		case 95: goto tr68;
		case 101: goto st94;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
st94:
	if ( ++p == pe )
		goto _out94;
case 94:
	switch( (*p) ) {
		case 95: goto tr68;
		case 115: goto tr95;
	}
	if ( (*p) < 65 ) {
		if ( 48 <= (*p) && (*p) <= 57 )
			goto tr68;
	} else if ( (*p) > 90 ) {
		if ( 97 <= (*p) && (*p) <= 122 )
			goto tr68;
	} else
		goto tr68;
	goto tr67;
tr122:
#line 1 "klscan.rl"
	{tokend = p+1;}
	goto st95;
st95:
	if ( ++p == pe )
		goto _out95;
case 95:
#line 2041 "klscan.cpp"
	if ( (*p) == 37 )
		goto st20;
	goto tr60;
st20:
	if ( ++p == pe )
		goto _out20;
case 20:
	if ( (*p) == 37 )
		goto tr125;
	goto tr123;
	}
	_out21: cs = 21; goto _out; 
	_out22: cs = 22; goto _out; 
	_out23: cs = 23; goto _out; 
	_out0: cs = 0; goto _out; 
	_out1: cs = 1; goto _out; 
	_out24: cs = 24; goto _out; 
	_out2: cs = 2; goto _out; 
	_out25: cs = 25; goto _out; 
	_out3: cs = 3; goto _out; 
	_out4: cs = 4; goto _out; 
	_out26: cs = 26; goto _out; 
	_out5: cs = 5; goto _out; 
	_out6: cs = 6; goto _out; 
	_out7: cs = 7; goto _out; 
	_out27: cs = 27; goto _out; 
	_out28: cs = 28; goto _out; 
	_out29: cs = 29; goto _out; 
	_out30: cs = 30; goto _out; 
	_out31: cs = 31; goto _out; 
	_out8: cs = 8; goto _out; 
	_out9: cs = 9; goto _out; 
	_out32: cs = 32; goto _out; 
	_out33: cs = 33; goto _out; 
	_out34: cs = 34; goto _out; 
	_out10: cs = 10; goto _out; 
	_out11: cs = 11; goto _out; 
	_out35: cs = 35; goto _out; 
	_out12: cs = 12; goto _out; 
	_out13: cs = 13; goto _out; 
	_out14: cs = 14; goto _out; 
	_out36: cs = 36; goto _out; 
	_out37: cs = 37; goto _out; 
	_out38: cs = 38; goto _out; 
	_out39: cs = 39; goto _out; 
	_out40: cs = 40; goto _out; 
	_out41: cs = 41; goto _out; 
	_out15: cs = 15; goto _out; 
	_out16: cs = 16; goto _out; 
	_out42: cs = 42; goto _out; 
	_out17: cs = 17; goto _out; 
	_out43: cs = 43; goto _out; 
	_out18: cs = 18; goto _out; 
	_out19: cs = 19; goto _out; 
	_out44: cs = 44; goto _out; 
	_out45: cs = 45; goto _out; 
	_out46: cs = 46; goto _out; 
	_out47: cs = 47; goto _out; 
	_out48: cs = 48; goto _out; 
	_out49: cs = 49; goto _out; 
	_out50: cs = 50; goto _out; 
	_out51: cs = 51; goto _out; 
	_out52: cs = 52; goto _out; 
	_out53: cs = 53; goto _out; 
	_out54: cs = 54; goto _out; 
	_out55: cs = 55; goto _out; 
	_out56: cs = 56; goto _out; 
	_out57: cs = 57; goto _out; 
	_out58: cs = 58; goto _out; 
	_out59: cs = 59; goto _out; 
	_out60: cs = 60; goto _out; 
	_out61: cs = 61; goto _out; 
	_out62: cs = 62; goto _out; 
	_out63: cs = 63; goto _out; 
	_out64: cs = 64; goto _out; 
	_out65: cs = 65; goto _out; 
	_out66: cs = 66; goto _out; 
	_out67: cs = 67; goto _out; 
	_out68: cs = 68; goto _out; 
	_out69: cs = 69; goto _out; 
	_out70: cs = 70; goto _out; 
	_out71: cs = 71; goto _out; 
	_out72: cs = 72; goto _out; 
	_out73: cs = 73; goto _out; 
	_out74: cs = 74; goto _out; 
	_out75: cs = 75; goto _out; 
	_out76: cs = 76; goto _out; 
	_out77: cs = 77; goto _out; 
	_out78: cs = 78; goto _out; 
	_out79: cs = 79; goto _out; 
	_out80: cs = 80; goto _out; 
	_out81: cs = 81; goto _out; 
	_out82: cs = 82; goto _out; 
	_out83: cs = 83; goto _out; 
	_out84: cs = 84; goto _out; 
	_out85: cs = 85; goto _out; 
	_out86: cs = 86; goto _out; 
	_out87: cs = 87; goto _out; 
	_out88: cs = 88; goto _out; 
	_out89: cs = 89; goto _out; 
	_out90: cs = 90; goto _out; 
	_out91: cs = 91; goto _out; 
	_out92: cs = 92; goto _out; 
	_out93: cs = 93; goto _out; 
	_out94: cs = 94; goto _out; 
	_out95: cs = 95; goto _out; 
	_out20: cs = 20; goto _out; 

	_out: {}
	}
#line 338 "klscan.rl"

		/* Check if we failed. */
		if ( cs == klscan_error ) {
			/* Machine failed before finding a token. */
			cout << "PARSE ERROR" << endl;
			exit(1);
		}

		/* Decide if we need to preserve anything. */
		char *preserve = tokstart;
		if ( inline_start != 0 && ( preserve == 0 || inline_start < preserve ) )
			preserve = inline_start;

		/* Now set up the prefix. */
		if ( preserve == 0 )
			have = 0;
		else {
			/* There is data that needs to be shifted over. */
			have = pe - preserve;
			memmove( buf, preserve, have );
			unsigned int shiftback = preserve - buf;
			if ( tokstart != 0 )
				tokstart -= shiftback;
			if ( inline_start != 0 )
				inline_start -= shiftback;

			tokend -= shiftback;
			litstart -= shiftback;
			litend -= shiftback;
			identstart -= shiftback;
			identend -= shiftback;

			preserve = buf;
		}
	}

	delete[] buf;
}

void scan( char *fileName, istream &input )
{
	ParserDict parserDict;
	Scanner scanner( fileName, input, parserDict, 0 );
	scanner.do_scan();
}

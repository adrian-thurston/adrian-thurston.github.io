/*
 *  Copyright 2002-2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "fsmgraph.h"

/* If there is a state dict element, then delete it. Everything else is left
 * up to the FsmGraph destructor. */
StateAp::~StateAp()
{
	if ( stateDictEl != 0 )
		delete stateDictEl;
}

/* Compares two transitions according to priority and functions. Pointers
 * should not be null. Does not consider to state or from state.  Compare two
 * transitions according to the data contained in the transitions.  Data means
 * any properties added to user transitions that may differentiate them. Since
 * the base transition has no data, the default is to return equal. */
int FsmAp::compareTransData( TransAp *trans1, TransAp *trans2 )
{
	/* Compare shift status. */
	int cmpRes = CmpOrd<bool>::compare( trans1->isShift, 
			trans2->isShift );
	if ( cmpRes != 0 )
		return cmpRes;

	/* There should be no reduction data. */
	assert( trans1->reductions.length() == 0 );
	assert( trans2->reductions.length() == 0 );
	
	/* Compare prod set data. */
	cmpRes = CmpDefSet::compare( trans1->pushSet, trans2->pushSet );
	if ( cmpRes != 0 )
		return cmpRes;

	/* Compare commit points. */
	cmpRes = CmpIntSet::compare( trans1->commits, trans2->commits );
	if ( cmpRes != 0 )
		return cmpRes;

	/* Compare store set data. */
	return CmpStoreSet::compare( trans1->storeSet, trans2->storeSet );
}

/* Callback invoked when another trans (or possibly this) is added into this
 * transition during the merging process.  Draw in any properties of srcTrans
 * into this transition. AddInTrans is called when a new transitions is made
 * that will be a duplicate of another transition or a combination of several
 * other transitions. AddInTrans will be called for each transition that the
 * new transition is to represent. */
void FsmAp::addInTrans( TransAp *destTrans, TransAp *srcTrans )
{
	/* Protect against adding in from ourselves. */
	if ( srcTrans != destTrans ) {
		/* Add in the reductions, or in the shift. */
		destTrans->isShift = destTrans->isShift || srcTrans->isShift;
		destTrans->reductions.insert( srcTrans->reductions );
		destTrans->pushSet.insert( srcTrans->pushSet );
		destTrans->storeSet.insert( srcTrans->storeSet );
		destTrans->commits.insert( srcTrans->commits );
	}
}

void FsmAp::addInState( StateAp *destState, StateAp *srcState )
{
	/* Draw in any properties of srcState into destState. */
	if ( srcState == destState ) {
		/* Duplicate the list to protect against write to source. The
		 * priorities and context sets are not copied in because that would
		 * have no effect. */
		destState->epsilonTrans.append( EpsilonTrans( srcState->epsilonTrans ) );
	}
	else {
		/* Get the epsilons, context, out priorities. */
		destState->epsilonTrans.append( srcState->epsilonTrans );
		destState->contextSet.insert( srcState->contextSet );
		destState->pendingCommits.insert( srcState->pendingCommits );

		/* Parser generation data. */
		destState->dotSet.insert( srcState->dotSet );

		if ( srcState->onClosureQueue && !destState->onClosureQueue ) {
			stateClosureQueue.append( destState );
			destState->onClosureQueue = true;
		}
		if ( srcState->followMarked && !destState->followMarked ) {
			followMarkedList.append( destState );
			destState->followMarked = true;
		}
	}
}

/* Compare the properties of states that are embedded by users. Compares out
 * priorities, out transitions, to, from, out, error and eof action tables. */
int FsmAp::compareStateData( const StateAp *state1, const StateAp *state2 )
{
	/* We always want start states isolated therefore we always compare agains
	 * start state status. */
	if ( !(state1->stateBits & SB_ISSTART) && (state2->stateBits & SB_ISSTART) )
		return -1;
	else if ( (state1->stateBits & SB_ISSTART) && !(state2->stateBits & SB_ISSTART) )
		return 1;

	return 0;
}

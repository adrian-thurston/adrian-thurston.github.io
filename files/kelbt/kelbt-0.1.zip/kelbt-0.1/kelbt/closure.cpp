/*
 *  Copyright 2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "kelbt.h"
#include "parsedata.h"

#include "vector.h"
#include <assert.h>
#include <string.h>
#include <iostream>

using std::endl;
using std::cerr;

bool ParseData::lr0ClosureRound( StateAp *state, Machines &prodAdditions )
{
	bool modified = false;

	/* Loop over the transitions out of the state, looking for nonterminals
	 * whose productions we can add to the state. */
	for ( TransList::Iter linkSrc = state->outList; linkSrc.lte(); linkSrc++ ) {
		/* Get the langEl. */
		for ( long key = linkSrc->lowKey; key <= linkSrc->highKey; key++ ) {
			LangEl *langEl = langElIndex[key];

			/* If the item is a non-term, try to expand it. */
			if ( langEl != 0 && langEl->type == LangEl::NonTerm ) {
				/* Make graphs for all of the productions that the non
				 * terminal goes to that are not already in the state's dotSet. */
				int prodsExpanded = 0;
				for ( LelDefList::Iter prod = langEl->defList; prod.lte(); prod++ ) {
					/* Make dot item for beginning the production. In lr0,
					 * follow set item always is 0. */
					assert( prod->fsm->startState->dotSet.length() == 1 );
					int dotNum = prod->fsm->startState->dotSet[0];

					/* Only add if item is not in set already. */
					if ( ! state->dotSet.find( dotNum ) ) {
						modified = true;
						prodsExpanded += 1;

						/* Set the production dot in the state's dot set. This
						 * will get added in again when the epsilon trans is
						 * drawn, but that's okay. We need it now, can't wait. */
						state->dotSet.insert( dotNum );

						/* Add to the graph the production and get a
						 * pointer to its start state. */
						FsmAp *newGraph = new FsmAp( *prod->fsm );

						if ( linkSrc->commits.length() > 0 ) {
							//cerr << "SETTING COMMIT ON CLOSURE ROUND" << endl;
							for ( IntSet::Iter len = linkSrc->commits; len.lte(); len++ )
								newGraph->setCommit( *len );

							if ( newGraph->startState->isFinState() ) {
								//cerr << "SETTING COMMIT IN PENDING LOOKAHEAD" << endl;
								for ( IntSet::Iter len = linkSrc->commits; 
										len.lte(); len++ )
								{
									newGraph->startState->pendingCommits.
										insert( ProdIdPair( prod->prodId, *len ) );
								}
							}
						}

						/* Set the prodStart in a state set that later we
						 * may use for merging. */
						prodAdditions.append( newGraph );
					}
				}

				if ( prodsExpanded > 0 ) {
					assert( prodsExpanded == langEl->defList.length() );
					linkSrc->commits.empty();
				}
			}
		}
	}

	return modified;
}

void ParseData::lr0InvokeClosure( StateAp *state )
{
	/* State should not already be closed. */
	assert( !state->inClosedMap );

	/* Keep a count of the total number of epsilon additions to the state. */
	int additionCount = 0;

	while ( true ) {
		/* This is the state set of production start states that will be merged
		 * into state upon the closure action. */
		Machines additions;

		/* Do a closure round, break if no modifications. */
		bool modified = lr0ClosureRound( state, additions );
		if ( !modified )
			break;

		/* Keep track of the total number of machines added in. */
		additionCount += additions.length();

		/* Clear the final states from the additions. */
		for ( int e = 0; e < additions.length(); e++ )
			additions[e]->unsetAllFinStates();

		/* Draw the additions into state. */
		graph->epsilonOp( &state, 1, additions.data, additions.length() );
	}

	/* Try and insert into the closed dict. */
	DotSetMapEl *lastFound;
	if ( graph->closedMap.insert( state, &lastFound ) ) {
		/* Insertion into closed dict succeeded. There is no state with the
		 * same dot set. The state is now closed. It is guaranteed a spot in
		 * the closed dict and it will never go away (states never deleted
		 * during closure). */
		graph->stateClosedList.append( state );
		state->inClosedMap = true;

		/* Add all of the states in the out transitions to the closure queue.
		 * This will give us a depth first search of the graph. */
		for ( TransList::Iter trans = state->outList; trans.lte(); trans++ ) {
			/* Get the state the transEl goes to. */
			StateAp *targ = trans->toState;

			/* If the state on this tranisition has not already been slated
			 * for closure, then add it to the queue. */
			if ( targ != 0 && !targ->onClosureQueue && ! targ->inClosedMap ) {
				graph->stateClosureQueue.append( targ );
				targ->onClosureQueue = true;
			}
		}
	}
	else {
		/* Insertion into closed dict failed. There is an existing state
		 * with the same dot set. Get the existing state. */
		graph->setMisfitAccounting( true );
		graph->inTransMove( lastFound, state );
		graph->removeMisfits();
		graph->setMisfitAccounting( false );
	}
}


/* Invoke cloure on the graph. We use a queue here to achieve a breadth
 * first search of the tree we build. Note, there are back edges in this
 * tree. They are the edges made when upon closure, a dot set exists
 * already. */
void ParseData::lr0CloseAllStates()
{
	/* While there are items on the closure queue. */
	while ( graph->stateClosureQueue.length() > 0 ) {
		/* Pop the first item off. */
		StateAp *state = graph->stateClosureQueue.detachFirst();
		state->onClosureQueue = false;

		/* Invoke closure upon the state. */
		lr0InvokeClosure( state );
	}
}

void ParseData::lalr1AddFollow2( TransAp *trans, FollowToAdd &followKeys )
{
	for ( ExpandToSet::Iter ets = trans->expandTo; ets.lte(); ets++ ) {
		int fssProdId = ets->fssProdId;
		StateAp *expandTo = ets->state;

		for ( FollowToAdd::Iter fkey = followKeys; fkey.lte(); fkey++ ) {
			/* Set up the follow transition. */
			TransAp *followTrans = new TransAp;
			followTrans->lowKey = *fkey;
			followTrans->highKey = *fkey;
			followTrans->isShift = false;
			followTrans->reductions.insert( fssProdId );

			Definition *prod = fssProdIdIndex[fssProdId];
			ProdIdPairSet &pendingCommits = expandTo->pendingCommits;
			for ( ProdIdPairSet::Iter pi = pendingCommits; pi.lte(); pi++ ) {
				if ( pi->onReduce == prod->prodId ) {
					followTrans->commits.insert( pi->length );
				}
			}

			/* Either link the expand To state to the actinon dest state
			 * with a new transition or add in the transition data to an
			 * existing transition. */
			bool modified = graph->transOverlay( expandTo, followTrans, actionDestState );

			/* If the expand to state has had its out list modified then
			 * queue the state for closure. */
			if ( modified && !expandTo->onClosureQueue ) {
				graph->stateClosureQueue.append( expandTo );
				expandTo->onClosureQueue = true;
			}
		}
	}
}

void ParseData::lalr1AddFollow1( StateAp *state )
{
	/* Finding non-terminals into the state. */
	for ( InIter in = state; in.lte(); in++ ) {
		for ( long key = in.trans->lowKey; key <= in.trans->highKey; key++ ) {
			LangEl *langEl = langElIndex[key];
			if ( langEl != 0 && langEl->type == LangEl::NonTerm ) {
				/* Finding the following transitions. */
				FollowToAdd followKeys;
				for ( OutIter fout = state; fout.lte(); fout++ ) {
					for ( int fkey = fout.trans->lowKey; fkey <= 
							fout.trans->highKey; fkey++ )
					{
						LangEl *flel = langElIndex[fkey];
						if ( flel == 0 || flel->type == LangEl::Term )
							followKeys.insert( fkey );
					}
				}

				if ( followKeys.length() > 0 )
					lalr1AddFollow2( in.trans, followKeys );
			}
		}
	}
}

/* Add follow sets to an LR(0) graph to make it LALR(1). */
void ParseData::lalr1AddFollowSets( )
{
	/* Make the state that all reduction actions go to. Since a reduction pops
	 * states of the stack and sets the new target state, this state is
	 * actually never reached. Just here to link the trans to. */
	actionDestState = graph->addState();
	graph->setFinState( actionDestState );

	/* Get the entry into the graph and traverse over start. */
	StateSet startFollowTo = graph->followFsm( graph->startState, startDef->fsm, 0 );
	assert( startFollowTo.length() == 1 );
	StateAp *overStart = startFollowTo[0];

	/* Add _eof after the initial _start. */
	TransAp *eofTrans = graph->attachNewTrans( overStart, actionDestState, 
			eofLangEl->id, eofLangEl->id );
	eofTrans->isShift = true;

	/* Need to pass over every state initially. */
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		state->onClosureQueue = true;
		graph->stateClosureQueue.append( state );
	}

	/* While the closure queue has items, pop them off and add follow
	 * characters. */
	while ( graph->stateClosureQueue.length() > 0 ) {
		/* Pop the first item off and add Follow for it . */
		StateAp *state = graph->stateClosureQueue.detachFirst();
		state->onClosureQueue = false;
		lalr1AddFollow1( state );
	}
}

void ParseData::linkExpansions()
{
	graph->setStateNumbers();
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		/* Find transitions out on non terminals. */
		for ( TransList::Iter trans = state->outList; trans.lte(); trans++ ) {
			for ( long key = trans->lowKey; key <= trans->highKey; key++ ) {
				LangEl *langEl = langElIndex[key];
				if ( langEl != 0 && langEl->type == LangEl::NonTerm ) {
					/* For each production that the non terminal expand to ... */
					for ( LelDefList::Iter prod = langEl->defList; prod.lte(); prod++ ) {
						/* For each final state in the production (each final
						 * state has it's own production id. */
						for ( StateSet::Iter fin = prod->fsm->finStateSet; fin.lte(); fin++ ) {
							/* Follow the production and add to the trans's expand to set. */
							int fssProdId = prod->fssProdIdLow + fin.pos();
							(*fin)->fssProdId = fssProdId;
							StateSet followRes = graph->followFsm( state, prod->fsm, *fin );
							for ( StateSet::Iter fto = followRes; fto.lte(); fto++ ) {
								//LangEl *lel = langElIndex[key];
								//cerr << state->stateNum << ", "; 
								//if ( lel != 0 )
								//	cerr << lel->data;
								//else
								//	cerr << (char)key;
								//cerr << " -> " << (*fto)->stateNum << " on " <<
								//		prod->data << " (fss = " << fin.pos() << ")" << endl;
								trans->expandTo.insert( ExpandToEl( (*fto), fssProdId ) );
							}
						}
					}
				}
			}
		}
	}
}

/* Generate a LALR(1) graph. */
void ParseData::lalr1GenerateParser()
{
	/* Make the intial graph. */
	graph = new FsmAp( *startDef->fsm );
	graph->unsetAllFinStates();

	/* Queue the start state for closure. */
	StateAp *start = graph->startState;
	start->onClosureQueue = true;
	graph->stateClosureQueue.append( start );

	/* Run the lr0 closure. */
	lr0CloseAllStates();
	graph->removeUnreachableStates();

	/* Link production expansions to the place they expand to. */
	linkExpansions();

	/* Walk the graph adding follow sets to the LR(0) graph. */
	lalr1AddFollowSets();
}

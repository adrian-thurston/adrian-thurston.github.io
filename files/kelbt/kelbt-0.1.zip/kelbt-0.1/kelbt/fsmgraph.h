/*
 *  Copyright 2001-2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#ifndef _FSMGRAPH_H
#define _FSMGRAPH_H

#include <assert.h>
#include "vector.h"
#include "bstset.h"
#include "compare.h"
#include "avltree.h"
#include "dlist.h"
#include "bstmap.h"
#include "sbstmap.h"
#include "sbstset.h"
#include "sbsttable.h"
#include "avlset.h"
#include "dlistmel.h"
#include "avltree.h"

/* Flags for states. */
#define SB_GRAPH1     0x01
#define SB_GRAPH2     0x02
#define SB_BOTH       0x03
#define SB_ISFINAL    0x04
#define SB_ISMARKED   0x08
#define SB_ISSTART    0x10

/* Flags for transitions. */
#define TB_ISMARKED   0x01

struct TransAp;
struct StateAp;
struct FsmAp;
struct Action;
struct LongestMatchPart;
struct Definition;

typedef Vector<long> ActDataList;

struct ActionData
{
	ActionData( int targ, ActDataList &actions, long pushSet, 
			long storeSet, int commitLen )
		: targ(targ), pushSet(pushSet), storeSet(storeSet), 
		commitLen(commitLen), id(0), actions(actions) { }

	int targ;
	long pushSet;
	long storeSet;
	int commitLen;
	int id;

	ActDataList actions;
};


struct CmpActionData
{
	static int compare( const ActionData &ap1, const ActionData &ap2 )
	{
		if ( ap1.targ < ap2.targ )
			return -1;
		else if ( ap1.targ > ap2.targ )
			return 1;
		else if ( ap1.pushSet < ap2.pushSet )
			return -1;
		else if ( ap1.pushSet > ap2.pushSet )
			return 1;
		else if ( ap1.storeSet < ap2.storeSet )
			return -1;
		else if ( ap1.storeSet > ap2.storeSet )
			return 1;
		else if ( ap1.commitLen < ap2.commitLen )
			return -1;
		else if ( ap1.commitLen > ap2.commitLen )
			return 1;
		else if ( ap1.id < ap2.id )
			return -1;
		else if ( ap1.id > ap2.id )
			return 1;

		return CmpTable< long, CmpOrd<long> >::
			compare( ap1.actions, ap2.actions );
	}
};

typedef AvlSet<ActionData, CmpActionData> ActionSet;
typedef AvlSetEl<ActionData> ActionSetEl;

/* State list element for unambiguous access to list element. */
struct FsmListEl { StateAp *prev, *next; };

/* List pointers for the closure queue. Goes into state. */
struct ClosureQueueListEl { StateAp *prev, *next; };
struct FollowMarkedListEl { StateAp *prev, *next; };

/* This is the marked index for a state pair. Used in minimization. It keeps
 * track of whether or not the state pair is marked. */
struct MarkIndex
{
	MarkIndex(int states);
	~MarkIndex();

	void markPair(int state1, int state2);
	bool isPairMarked(int state1, int state2);

private:
	int numStates;
	bool *array;
};

/* Plain action list that imposes no ordering. */
typedef Vector<int> TransFuncList;

/* Comparison for TransFuncList. */
typedef CmpTable< int, CmpOrd<int> > TransFuncListCompare;

/* Queue of states, transitions to be closed. */
typedef DListMel< StateAp, ClosureQueueListEl > StateClosureQueue;
typedef DListMel< StateAp, FollowMarkedListEl > FollowMarkedList;

typedef BstSet< Definition*, CmpOrd<Definition*> > DefSet;
typedef CmpTable< Definition*, CmpOrd<Definition*> > CmpDefSet;
typedef BstSet< DefSet, CmpDefSet > DefSetSet;

typedef Vector< Definition* > DefVect;

typedef BstSet< long, CmpOrd<long> > AlphSet;
typedef BstSet< long, CmpOrd<long> > StoreSet;
typedef CmpTable< long, CmpOrd<long> > CmpStoreSet;
typedef BstSet< StoreSet, CmpStoreSet > StoreSetSet;

struct ExpandToEl
{
	ExpandToEl( StateAp *state, int fssProdId )
		: state(state), fssProdId(fssProdId) { }

	StateAp *state;
	int fssProdId;
};

struct CmpExpandToEl
{
	static inline int compare( const ExpandToEl &etel1, const ExpandToEl &etel2 )
	{ 
		if ( etel1.state < etel2.state )
			return -1;
		else if ( etel1.state > etel2.state )
			return 1;
		else if ( etel1.fssProdId < etel2.fssProdId )
			return -1;
		else if ( etel1.fssProdId > etel2.fssProdId )
			return 1;
		else
			return 0;
	}
};

typedef BstSet<ExpandToEl, CmpExpandToEl> ExpandToSet;
typedef BstSet< int, CmpOrd<int> > IntSet;
typedef CmpTable< int, CmpOrd<int> > CmpIntSet;

typedef IntSet ProdIdSet;
typedef CmpIntSet CmpProdIdSet;

/* Set of states, list of states. */
typedef BstSet<StateAp*> StateSet;
typedef Vector<StateAp*> StateVect;
typedef DList<StateAp> StateList;

typedef IntSet FollowToAdd;
typedef IntSet ReductionSet;

struct ProdIdPair
{
	ProdIdPair( int onReduce, int length )
		: onReduce(onReduce), length(length) {}

	int onReduce;
	int length;
};

struct CmpProdIdPair
{
	static inline int compare( const ProdIdPair &pair1, const ProdIdPair &pair2 )
	{ 
		if ( pair1.onReduce < pair2.onReduce )
			return -1;
		else if ( pair1.onReduce > pair2.onReduce )
			return 1;
		else if ( pair1.length < pair2.length )
			return -1;
		else if ( pair1.length > pair2.length )
			return 1;
		else
			return 0;
	}
};

typedef BstSet< ProdIdPair, CmpProdIdPair > ProdIdPairSet;

/* Transition class that implements actions and priorities. */
struct TransAp 
{
	TransAp() : 
		fromState(0), 
		toState(0), 
		isShift(false), 
		isShiftReduce(false), 
		redPushSet(0),
		redStoreSet(0),
		transBits(0)
	{ }

	TransAp( const TransAp &other ) :
		lowKey(other.lowKey),
		highKey(other.highKey),
		fromState(0), toState(0),
		isShift(other.isShift),
		isShiftReduce(other.isShiftReduce),
		reductions(other.reductions),
		pushSet(other.pushSet),
		redPushSet(0),
		storeSet(other.storeSet),
		redStoreSet(0),
		commits(other.commits),
		transBits(other.transBits)
	{ }

	long lowKey, highKey;
	StateAp *fromState;
	StateAp *toState;

	/* Pointers for outlist. */
	TransAp *prev, *next;

	/* Pointers for in-list. */
	TransAp *ilprev, *ilnext;

	/* Parse Table construction data. */
	bool isShift, isShiftReduce;
	ReductionSet reductions;
	ActDataList actions;
	ActDataList actOrds;

	ExpandToSet expandTo;

	DefSet pushSet;
	int redPushSet;
	ActionSetEl *actionSetEl;

	StoreSet storeSet;
	int redStoreSet;

	IntSet commits;
	IntSet afterShiftCommits;

	int transBits;
};

/* In transition list. Like DList except only has head pointers, which is all
 * that is required. Insertion and deletion is handled by the graph. This
 * class provides the iterator of a single list. */
struct TransInList
{
	TransInList() : head(0) { }

	TransAp *head;

	struct Iter
	{
		/* Default construct. */
		Iter() : ptr(0) { }

		/* Construct, assign from a list. */
		Iter( const TransInList &il )  : ptr(il.head) { }
		Iter &operator=( const TransInList &dl ) { ptr = dl.head; return *this; }

		/* At the end */
		bool lte() const    { return ptr != 0; }
		bool end() const    { return ptr == 0; }

		/* At the first, last element. */
		bool first() const { return ptr && ptr->ilprev == 0; }
		bool last() const  { return ptr && ptr->ilnext == 0; }

		/* Cast, dereference, arrow ops. */
		operator TransAp*() const   { return ptr; }
		TransAp &operator *() const { return *ptr; }
		TransAp *operator->() const { return ptr; }

		/* Increment, decrement. */
		inline void operator++(int)   { ptr = ptr->ilnext; }
		inline void operator--(int)   { ptr = ptr->ilprev; }

		/* The iterator is simply a pointer. */
		TransAp *ptr;
	};
};

typedef DList<TransAp> TransList;

/* A element in a state dict. */
struct StateDictEl 
:
	public AvlTreeEl<StateDictEl>
{
	StateDictEl(const StateSet &stateSet) 
		: stateSet(stateSet) { }

	const StateSet &getKey() { return stateSet; }
	StateSet stateSet;
	StateAp *targState;
};

/* Dictionary mapping a set of states to a target state. */
typedef AvlTree< StateDictEl, StateSet, CmpTable<StateAp*> > StateDict;

/* Data needed for a merge operation. */
struct MergeData
{
	MergeData() 
		: stfillHead(0), stfillTail(0) { }

	StateDict stateDict;

	StateAp *stfillHead;
	StateAp *stfillTail;

	void fillListAppend( StateAp *state );
};

/* Vector based set of key items. */
typedef BstSet< long, CmpOrd<long> > KeySet;

struct MinPartition 
{
	MinPartition() : active(false) { }

	StateList list;
	bool active;

	MinPartition *prev, *next;
};

/* Epsilon transition stored in a state. Specifies the target */
typedef Vector<int> EpsilonTrans;

/* List of states that are to be drawn into this. */
struct EptVectEl
{
	EptVectEl( StateAp *targ, bool leaving ) 
		: targ(targ), leaving(leaving) { }

	StateAp *targ;
	bool leaving;
};
typedef Vector<EptVectEl> EptVect;

/* Set of entry ids that go into this state. */
typedef BstSet<int> EntryIdSet;

/* Set of context ids. */
typedef BstSet<int> ContextSet;

/* What items does a particular state encompass. */
typedef BstSet< int, CmpOrd<int> > DotSet;
typedef CmpTable< int, CmpOrd<int> > CmpDotSet;

/* Map of dot sets to states. */
typedef AvlTree< StateAp, DotSet, CmpDotSet > DotSetMap;
typedef StateAp DotSetMapEl;

/* State class that implements actions and priorities. */
struct StateAp 
: 
	public ClosureQueueListEl,
	public FollowMarkedListEl,
	public AvlTreeEl< StateAp >
{
	StateAp();
	StateAp(const StateAp &other);
	~StateAp();

	/* Is the state final? */
	bool isFinState() { return stateBits & SB_ISFINAL; }

	/* Out transition list and the pointer for the default out trans. */
	TransList outList;

	TransAp *findTrans( long key ) 
	{
		for ( TransList::Iter tr = outList; tr.lte(); tr++ ) {
			if ( tr->lowKey == key )
				return tr;
		}
		return 0;
	}

	/* In transition list. */
	TransInList inRange;

	/* Entry points into the state. */
	EntryIdSet entryIds;

	/* Epsilon transitions. */
	EpsilonTrans epsilonTrans;

	/* Context set in the state. */
	ContextSet contextSet;

	ProdIdPairSet pendingCommits;

	/* Number of in transitions from states other than ourselves. */
	int foreignInTrans;

	/* Temporary data for various algorithms. */
	union {
		/* When duplicating the fsm we need to map each 
		 * state to the new state representing it. */
		StateAp *stateMap;

		/* When minimizing machines by partitioning, this maps to the group
		 * the state is in. */
		MinPartition *partition;

		/* When merging states (state machine operations) this next pointer is
		 * used for the list of states that need to be filled in. */
		StateAp *next;
	} alg;

	/* Identification for printing and stable minimization. */
	int stateNum;

	/* Data used in epsilon operation, maybe fit into alg? */
	StateAp *isolatedShadow;
	int owningGraph;

	/* A pointer to a dict element that contains the set of states this state
	 * represents. This cannot go into alg, because alg.next is used during
	 * the merging process. */
	StateDictEl *stateDictEl;

	/* When drawing epsilon transitions, holds the list of states to merge
	 * with. */
	EptVect *eptVect;

	/* Bits controlling the behaviour of the state during collapsing to dfa. */
	int stateBits;
	long traversalLevel;

	/* State list elements. */
	StateAp *next, *prev;

	/* For dotset map. */
	DotSet &getKey() { return dotSet; }

	/* Closure management. */
	DotSet dotSet;
	DotSet dotSet2;
	bool onClosureQueue;
	bool inClosedMap;
	bool followMarked;
	bool onStateList;
	long fssProdId;
};

/* Iterator for a state's out transitions. Objects being iterated over come
 * from two sources: out ranges and the default transition. Skips key pairs
 * that have no transition and therefore take away from the default. */
struct OutIter
{
	/* Encodes the different states that an fsm iterator can be in. */
	enum IterState {
		Begin,
		Range,
		End
	};

	OutIter();
	OutIter( StateAp *state );
	OutIter( StateList::Iter iter );
	void operator =( StateAp *state );
	void operator =( StateList::Iter iter );

	/* Query iterator. */
	bool lte() { return itState != End; }
	bool end() { return itState == End; }
	TransAp *operator++(int);
	TransAp *operator++();

	/* Iterator state data. */
	TransAp *trans;
	StateAp *state;
	IterState itState;

private:
	void findNext();
};

/* Iterator for a state's in transitions. This iterator does not adhere to
 * Kelbt's standard iterator interface due to the exceptional requirements.
 * Objects being iterated over come from 3 sources: in transitions, in
 * ranges and the default transitions. These points are lists of transitions. */
struct InIter
{
	/* Encodes the different states that an fsm iterator can be in. */
	enum IterState {
		Begin,
		Range,
		End
	};

	InIter( StateAp *state );
	InIter( StateList::Iter iter );

	/* Query iterator. */
	bool lte() { return itState != End; }
	bool end() { return itState == End; }
	TransAp *operator++(int);
	TransAp *operator++();

	/* The trans pointer available outside this class. */
	TransAp *trans;

	/* Iterator state. */
	StateAp *state;
	IterState itState;

private:
	void findNext();
};

struct NextTrans
{
	long lowKey, highKey;
	TransAp *trans;
	TransAp *next;

	void load() {
		if ( trans != 0 ) {
			next = trans->next;
			lowKey = trans->lowKey;
			highKey = trans->highKey;
		}
	}

	void set( TransAp *t ) {
		trans = t;
		load();
	}

	void increment() {
		trans = next;
		load();
	}
};

struct PairIter
{
	/* Encodes the different states that an fsm iterator can be in. */
	enum IterState {
		Begin,
		ConsumeS1Range, ConsumeS2Range,
		OnlyInS1Range,  OnlyInS2Range,
		S1SticksOut,    S1SticksOutBreak,
		S2SticksOut,    S2SticksOutBreak,
		S1DragsBehind,  S1DragsBehindBreak,
		S2DragsBehind,  S2DragsBehindBreak,
		ExactOverlap,   End
	};

	/* Encodes the different states that are meaningful to the of the
	 * iterator. */
	enum UserState {
		RangeInS1, RangeInS2,
		RangeOverlap,
		BreakS1, BreakS2
	};

	PairIter( const TransList &list1, const TransList &head2, bool wantBreaks );
	
	/* Query iterator. */
	bool lte() { return itState != End; }
	bool end() { return itState == End; }
	void operator++(int) { findNext(); }
	void operator++()    { findNext(); }

	/* Iterator state. */
	const TransList &list1;
	const TransList &list2;
	IterState itState;
	UserState userState;

	NextTrans s1Tel, s2Tel;
	long bottomLow, bottomHigh;
	TransAp *bottomTrans;

	bool wantBreaks;

private:
	void findNext();
};

/* Compare lists of epsilon transitions. Entries are name ids of targets. */
typedef CmpTable< int, CmpOrd<int> > CmpEpsilonTrans;

/* Compare sets of context values. */
typedef CmpTable< int, CmpOrd<int> > CmpContextSets;

/* Compare class for the initial partitioning of a partition minimization. */
class InitPartitionCompare
{
public:
	InitPartitionCompare() { }
	int compare( const StateAp *pState1, const StateAp *pState2 );
};

/* Compare class for the regular partitioning of a partition minimization. */
class PartitionCompare
{
public:
	PartitionCompare() { }
	int compare( const StateAp *pState1, const StateAp *pState2 );
};

/* List of partitions. */
typedef DList< MinPartition > PartitionList;

/* Entry point map used for keeping track of entry points in a machine. */
typedef BstSet< int > EntryIdSet;
typedef BstMapEl< int, StateAp* > EntryMapEl;
typedef BstMap< int, StateAp* > EntryMap;
typedef Vector<EntryMapEl> EntryMapBase;

/* Graph class that implements actions and priorities. */
struct FsmAp 
{
	/* Constructors/Destructors. */
	FsmAp();
	FsmAp( const FsmAp &graph );
	~FsmAp();

	/* The list of states. */
	StateList stateList;
	StateList misfitList;

	/* The map of entry points. */
	EntryMap entryPoints;

	/* The start state. */
	StateAp *startState;

	/* The set of final states. */
	StateSet finStateSet;

	/* Misfit Accounting. Are misfits put on a separate list. */
	bool misfitAccounting;

	/* Closure queues and maps. */
	DotSetMap closedMap;
	StateClosureQueue stateClosureQueue;
	StateClosureQueue stateClosedList;
	FollowMarkedList followMarkedList;

	/* Misfit Accounting. Are misfits put on a separate list. */
	void setMisfitAccounting( bool val ) 
		{ misfitAccounting = val; }

	void setStartState( StateAp *state );
	void unsetStartState( );
	
	/* Set and unset a state as an entry point. */
	void setEntry( int id, StateAp *state );
	void changeEntry( int id, StateAp *to, StateAp *from );
	void unsetEntry( int id, StateAp *state );
	void unsetEntry( int id );
	void unsetAllEntryPoints();

	/* Epsilon transitions. */
	void epsilonTrans( int id );
	void shadowReadWriteStates( MergeData &md );

	/*
	 * Basic attaching and detaching.
	 */

	/* Common to attaching/detaching list and default. */
	void attachToInList( StateAp *from, StateAp *to, TransAp *&head, TransAp *trans );
	void detachFromInList( StateAp *from, StateAp *to, TransAp *&head, TransAp *trans );

	/* Attach with a new transition. */
	TransAp *attachNewTrans( StateAp *from, StateAp *to, long onChar1, long onChar2 );

	/* Attach with an existing transition that already in an out list. */
	void attachTrans( StateAp *from, StateAp *to, TransAp *trans );
	
	/* Detach a transition from a target state. */
	void detachTrans( StateAp *from, StateAp *to, TransAp *trans );

	/* Detach a state from the graph. */
	void detachState( StateAp *state );

	/*
	 * NFA to DFA conversion routines.
	 */

	/* Duplicate a transition that will dropin to a free spot. */
	TransAp *dupTrans( StateAp *from, TransAp *srcTrans, bool leavingFsm );

	/* In crossing, src trans overwrites the existing one because it has a
	 * higher priority. */
	TransAp *overwriteTrans( MergeData &md, StateAp *from,
			TransAp *destTrans, TransAp *srcTrans, bool leavingFsm );

	/* In crossing, two transitions both go to real states. */
	TransAp *fsmAttachStates( MergeData &md, StateAp *from,
			TransAp *destTrans, TransAp *srcTrans, bool leavingFsm );

	/* Two transitions are to be crossed, handle the possibility of either
	 * going to the error state. */
	TransAp *mergeTrans( MergeData &md, StateAp *from,
			TransAp *destTrans, TransAp *srcTrans, bool leavingFsm );

	/* Cross a src transition with one that is already occupying a spot. */
	TransAp *crossTransitions( MergeData &md, StateAp *from,
			TransAp *destTrans, TransAp *srcTrans, bool leavingFsm );

	/* Common to copying transition lists and ranges. */
	TransAp *keyInDestEl( MergeData &md, StateAp *dest, StateAp *src, 
			NextTrans *destTel, bool leavingFsm );
	TransAp *keyInSrcEl( MergeData &md, StateAp *dest, StateAp *src, 
			NextTrans *srcTel, bool leavingFsm );

	void outTransCopy( MergeData &md, StateAp *dest, StateAp *src, bool leavingFsm );

	/* Merging states into a destination state. */
	void mergeStates( MergeData &md, StateAp *destState, 
			StateAp *srcState, bool leavingFsm );

	/* Merge a set of states into newState. */
	void mergeStates( MergeData &md, StateAp *destState, 
			StateAp **srcStates, int numSrc );

	/* Make all states that are combinations of other states and that
	 * have not yet had their out transitions filled in. This will 
	 * empty out stateDict and stFil. */
	void fillInStates( MergeData &md );

	/*
	 * Transition Comparison.
	 */

	/* Compare transition data. Either of the pointers may be null. */
	static inline int compareDataPtr( TransAp *trans1, TransAp *trans2 );

	/* Compare target partitions. Either pointer may be null. */
	static inline int comparePartPtr( TransAp *trans1, TransAp *trans2 );

	/*
	 * Callbacks.
	 */

	/* Compare priority and function table of transitions. */
	static int compareTransData( TransAp *trans1, TransAp *trans2 );

	/* Add in the properties of srcTrans into this. */
	void addInTrans( TransAp *destTrans, TransAp *srcTrans );
	void addInState( StateAp *destState, StateAp *srcState );

	/* Compare states on data stored in the states. */
	static int compareStateData( const StateAp *state1, const StateAp *state2 );

	/*
	 * Allocation.
	 */

	/* New up a state and add it to the graph. */
	StateAp *addState();

	/*
	 * Building basic machines
	 */

	void concatFsm( long c );
	void concatFsm( long *str, int len );
	void orFsm( long *set, int len );
	void dotFsm( );
	void dotStarFsm( );
	void rangeFsm( long low, long high );
	void emptyFsm( );
	void lambdaFsm( );

	/*
	 * Fsm operators.
	 */

	void starOp( );
	void repeatOp( int times );
	void optionalRepeatOp( int times );
	void concatOp( FsmAp *other );
	void unionOp( FsmAp *other );
	void intersectOp( FsmAp *other );
	void subtractOp( FsmAp *other );
	void epsilonOp( StateAp **fromStates, int nStates, 
			FsmAp **others, int numOthers );
	void deterministicEntry();

	bool transOverlay( StateAp *from, TransAp *trans, StateAp *defaultTo );

	/* If src targ is give, we follow from to srcTarg in srcFsm, otherwise we
	 * follow from to all the final states of srcFsm. */
	void followFsm( StateSet &followTo, StateAp *followIn, 
			StateAp *followSrc, StateAp *srcTarg );
	StateSet followFsm( StateAp *from, FsmAp *srcFsm, StateAp *srcTarg );

	void setCommit( int prodId );

	/*
	 * Operator workers
	 */

	/* Determine if there are any entry points into a start state other than
	 * the start state. */
	bool isStartStateIsolated();

	/* Make a new start state that has no entry points. Will not change the
	 * identity of the fsm. */
	void isolateStartState();

	/* Workers for resolving epsilon transitions. */
	bool inEptVect( EptVect *eptVect, StateAp *targ );
	void epsilonFillEptVectFrom( StateAp *root, StateAp *from, bool parentLeaving );
	void resolveEpsilonTrans( MergeData &md );

	/* Workers for concatenation and union. */
	void doConcat( FsmAp *other, StateSet *fromStates, bool optional );
	void doOr( FsmAp *other );

	/*
	 * Final states
	 */

	/* Set and Unset a state as final. */
	void setFinState( StateAp *state );
	void unsetFinState( StateAp *state );
	void unsetAllFinStates( );

	/* Unset any final states that are no longer to be final 
	 * due to final bits. */
	void unsetIncompleteFinals();
	void unsetKilledFinals();

	/* Bring in other's entry points. Assumes others states are going to be
	 * copied into this machine. */
	void copyInEntryPoints( FsmAp *other );

	/* Set State numbers starting at 0. */
	void setStateNumbers();

	/* Set the bits of final states and clear the bits of non final states. */
	void setFinBits( int finStateBits );

	/*
	 * Self-consistency checks.
	 */

	/* Run a sanity check on the machine. */
	void verifyIntegrity();

	/* Verify that there are no unreachable states, or dead end states. */
	void verifyReachability();
	void verifyNoDeadEndStates();

	/*
	 * Path pruning
	 */

	/* Mark all states reachable from state. */
	void markReachableFromHereReverse( StateAp *state );

	/* Mark all states reachable from state. */
	void markReachableFromHere( StateAp *state );
	void markReachableFromHereStopFinal( StateAp *state );

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void removeDeadEndStates();

	/* Removes states that cannot be reached by any path in the fsm and are
	 * thus wasted silicon. */
	void removeUnreachableStates();

	/* Remove error actions from states on which the error transition will
	 * never be taken. */
	bool outListCovers( StateAp *state );

	/* Remove states that are on the misfit list. */
	void removeMisfits();


	/*
	 * FSM Minimization
	 */

	/* Minimization by partitioning. */
	void minimizePartition2();

	/* Given an intial partioning of states, split partitions that have out trans
	 * to differing partitions. */
	int partitionRound( StateAp **statePtrs, MinPartition *parts, int numParts );

	/* Split partitions that have a transition to a previously split partition, until
	 * there are no more partitions to split. */
	int splitCandidates( StateAp **statePtrs, MinPartition *parts, int numParts );

	/* Fuse together states in the same partition. */
	void fusePartitions( MinPartition *parts, int numParts );

	/* Move the in trans into src into dest. */
	void inTransMove(StateAp *dest, StateAp *src);
	
	/* Make state src and dest the same state. */
	void fuseEquivStates(StateAp *dest, StateAp *src);

	/*
	 * Other
	 */
	int someLength( StateAp *from, int curLen, StateAp *targState );
	bool isVariableLength( StateAp *from, int &lastLen, int curLen, StateAp *targState );
	int fsmLength( StateAp *targState );

	int someLength2( TransAp *over, StateAp *from, int curLen, int storeNum );
	bool isVariableLength2( StateAp *from, int &lastLen, int curLen, int storeNum );
	int fsmLength2( int storeNum );

	bool alwaysStoreAt( StateAp *from, int storeNum, int rhsPos );
	bool alwaysStoreAt( int storeNum, int rhsPos );

	void removeStore( StateAp *from, int storeNum, int rhsPos );
	void removeStore( int storeNum, int rhsPos );

	void depthFirstOrdering( StateAp *state );
	void depthFirstOrdering();
};


#endif /* _FSMGRAPH_H */

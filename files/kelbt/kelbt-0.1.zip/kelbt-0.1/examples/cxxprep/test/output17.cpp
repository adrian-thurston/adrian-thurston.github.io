

int $[di f]({ ... });
int $[di f]({ int $[di a] ... });
int $[di f]({ int $[di a], ... });

int $[di f]( int(1) );

class [cn C];

[cn C] $[di c](hello + 1);


class [cn D] 
{
	void $(|(|<*>[di d]|)|)({int $[di i] = 0, [cn C] <&>});
};

template <{class}> class [cn F];

int $[di main]({}) 
{
	void $(|<*>[di d]|)({int $[di i] = 0, [cn C] <&>});
}

template<{ template <{class T = [cn F]<| (1+2) |>}> class, class}> class [cn G];



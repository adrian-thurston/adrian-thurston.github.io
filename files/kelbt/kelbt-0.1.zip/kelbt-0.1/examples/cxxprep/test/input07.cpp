
class C{};
void main(int argc, char *argv[])
{
	// sdflkj

	i*2.3 /**/ / f / /**/ 2.2;
	(new C***) * 2.2;
	(new C***)*2.2;
}


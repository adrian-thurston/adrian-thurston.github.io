#define VERSION "0.10"
#define PUBDATE "January 2007"

#define VERSION "0.9"
#define PUBDATE "January 2007"

/*
 *  Copyright 2001, 2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <string.h>
#include <assert.h>
#include "fsmgraph.h"
#include "kelbt.h"
#include "parsedata.h"

#include <iostream>
using namespace std;

/* Insert a transition into an inlist. The head must be supplied. */
void FsmAp::attachToInList( StateAp *from, StateAp *to, 
		TransAp *&head, TransAp *trans )
{
	trans->ilnext = head;
	trans->ilprev = 0;

	/* If in trans list is not empty, set the head->prev to trans. */
	if ( head != 0 )
		head->ilprev = trans;

	/* Now insert ourselves at the front of the list. */
	head = trans;

	/* Keep track of foreign transitions for from and to. */
	if ( from != to ) {
		if ( misfitAccounting ) {
			/* If the number of foreign in transitions is about to go up to 1 then
			 * move it from the misfit list to the main list. */
			if ( to->foreignInTrans == 0 )
				stateList.append( misfitList.detach( to ) );
		}
		
		to->foreignInTrans += 1;
	}
};

/* Detach a transition from an inlist. The head of the inlist must be supplied. */
void FsmAp::detachFromInList( StateAp *from, StateAp *to, 
		TransAp *&head, TransAp *trans )
{
	/* Detach in the inTransList. */
	if ( trans->ilprev == 0 ) 
		head = trans->ilnext; 
	else
		trans->ilprev->ilnext = trans->ilnext; 

	if ( trans->ilnext != 0 )
		trans->ilnext->ilprev = trans->ilprev; 
	
	/* Keep track of foreign transitions for from and to. */
	if ( from != to ) {
		to->foreignInTrans -= 1;
		
		if ( misfitAccounting ) {
			/* If the number of foreign in transitions goes down to 0 then move it
			 * from the main list to the misfit list. */
			if ( to->foreignInTrans == 0 )
				misfitList.append( stateList.detach( to ) );
		}
	}
}

/* Attach states on the default transition, range list or on out/in list key.
 * Type of attaching and is controlled by keyType. First makes a new
 * transition. If there is already a transition out from fromState on the
 * default, then will assertion fail. */
TransAp *FsmAp::attachNewTrans( StateAp *from, StateAp *to, long lowKey, long )
{
	/* Make the new transition. */
	TransAp *retVal = new TransAp();

	/* The transition is now attached. Remember the parties involved. */
	retVal->fromState = from;
	retVal->toState = to;

	/* Make the entry in the out list for the transitions. */
	from->transMap.append( TransMapEl( lowKey, retVal ) );

	/* Set the the keys of the new trans. */
	retVal->lowKey = lowKey;

	/* Attach using inRange as the head pointer. */
	attachToInList( from, to, to->inRange.head, retVal );

	return retVal;
}

/* Attach for range lists or for the default transition. Type of attaching is
 * controlled by the keyType parameter. This attach should be used when a
 * transition already is allocated and must be attached to a target state.
 * Does not handle adding the transition into the out list. */
void FsmAp::attachTrans( StateAp *from, StateAp *to, TransAp *trans )
{
	assert( trans->fromState == 0 && trans->toState == 0 );
	trans->fromState = from;
	trans->toState = to;

	/* Attach using the inRange pointer as the head pointer. */
	attachToInList( from, to, to->inRange.head, trans );
}

/* Detach for out/in lists or for default transition. The type of detaching is
 * controlled by the keyType parameter. */
void FsmAp::detachTrans( StateAp *from, StateAp *to, TransAp *trans )
{
	assert( trans->fromState == from && trans->toState == to );
	trans->fromState = 0;
	trans->toState = 0;

	/* Detach using to's inRange pointer as the head. */
	detachFromInList( from, to, to->inRange.head, trans );
}


/* Detach a state from the graph. Detaches and deletes transitions in and out
 * of the state. Empties inList and outList. Removes the state from the final
 * state set. A detached state becomes useless and should be deleted. */
void FsmAp::detachState( StateAp *state )
{
	/* Detach the in transitions from the inRange list of transitions. */
	while ( state->inRange.head != 0 ) {
		/* Get pointers to the trans and the state. */
		TransAp *trans = state->inRange.head;
		StateAp *fromState = trans->fromState;

		/* Detach the transitions from the source state. */
		detachTrans( fromState, state, trans );

		/* Ok to delete the transition. */
		fromState->transMap.remove( trans->lowKey );
		delete trans;
	}

	/* Detach out range transitions. */
	for ( TransMap::Iter trans = state->transMap; trans.lte(); trans++ ) {
		detachTrans( state, trans->value->toState, trans->value );
		delete trans->value;
	}

	/* Delete all of the out range pointers. */
	state->transMap.empty();

	/* Unset final stateness before detaching from graph. */
	if ( state->stateBits & SB_ISFINAL )
		finStateSet.remove( state );
}


/* Duplicate a transition. Makes a new transition that is attached to the same
 * dest as srcTrans. The new transition has functions and priority taken from
 * srcTrans. If leavingFsm is set, then outPrior and outFuncs are taken from
 * the from state. Used for merging a transition in to a free spot. The trans
 * can just be dropped in. It does not conflict with an existing trans and need
 * not be crossed. Returns the new transition. */
TransAp *FsmAp::dupTrans( StateAp *from, TransAp *srcTrans, bool leavingFsm )
{
	/* Make a new transition. */
	TransAp *newTrans = new TransAp();

	/* We can attach the transition, one does not exist. */
	attachTrans( from, srcTrans->toState, newTrans );
		
	/* Call the user callback to add in the original source transition. */
	addInTrans( newTrans, srcTrans );

	return newTrans;
}

/* In crossing, src trans and dest trans both go to existing states. Make one
 * state from the sets of states that src and dest trans go to. */
TransAp *FsmAp::fsmAttachStates( MergeData &md, StateAp *from,
			TransAp *destTrans, TransAp *srcTrans, bool leavingFsm )
{
	/* The priorities are equal. We must merge the transitions. Does the
	 * existing trans go to the state we are to attach to? ie, are we to
	 * simply double up the transition? */
	StateAp *toState = srcTrans->toState;
	StateAp *existingState = destTrans->toState;

	if ( existingState == toState ) {
		/* The transition is a double up to the same state.  Copy the src
		 * trans into itself. We don't need to merge in the from out trans
		 * data, that was done already. */
		addInTrans( destTrans, srcTrans );
	}
	else {
		/* The trans is not a double up. Dest trans cannot be the same as src
		 * trans. Set up the state set. */
		StateSet stateSet;

		/* We go to all the states the existing trans goes to, plus... */
		if ( existingState->stateDictEl == 0 )
			stateSet.insert( existingState );
		else
			stateSet.insert( existingState->stateDictEl->stateSet );

		/* ... all the states that we have been told to go to. */
		if ( toState->stateDictEl == 0 )
			stateSet.insert( toState );
		else
			stateSet.insert( toState->stateDictEl->stateSet );

		/* Detach the state from existing state. */
		detachTrans( from, existingState, destTrans );

		/* Look for the state. If it is not there already, make it. */
		StateDictEl *lastFound;
		if ( md.stateDict.insert( stateSet, &lastFound ) ) {
			/* Make a new state representing the combination of states in
			 * stateSet. It gets added to the fill list.  This means that we
			 * need to fill in it's transitions sometime in the future.  We
			 * don't do that now (ie, do not recurse). */
			StateAp *combinState = addState();

			/* Link up the dict element and the state. */
			lastFound->targState = combinState;
			combinState->stateDictEl = lastFound;

			/* Add to the fill list. */
			md.fillListAppend( combinState );
		}

		/* Get the state insertted/deleted. */
		StateAp *targ = lastFound->targState;

		/* Re-attach to the new target. */
		attachTrans( from, targ, destTrans );

		/* Add in src trans to the existing transition that we redirected to
		 * the new state. We don't need to merge in the from out trans data,
		 * that was done already. */
		addInTrans( destTrans, srcTrans );
	}

	return destTrans;
}

/* Copy the transitions in srcList to the outlist of dest. If srcList comes from
 * a final state and out transitions should be copied in then leavingFsm can be
 * set true. SrcList should not be the outList of dest, otherwise you would
 * be copying the contents of srcList into itself as it's iterated: bad news. */
void FsmAp::outTransCopy( MergeData &md, StateAp *dest, StateAp *src, bool leavingFsm )
{
	for ( TransMap::Iter srcTel = src->transMap; srcTel.lte(); srcTel++ ) {
		TransMapEl *destTel = dest->transMap.find( srcTel->key );

		if ( destTel == 0 ) {
			/* Src range may get crossed with dest's default transition. */
			TransAp *newTrans = dupTrans( dest, srcTel->value, leavingFsm );

			/* Set up the transition's keys and append to the dest list. */
			newTrans->lowKey = srcTel->key;
			dest->transMap.insert( newTrans->lowKey, newTrans );

			if ( langElIndex != 0 && dest == stateClosureHead ) {
				long key = newTrans->lowKey;
				LangEl *langEl = langElIndex[key];

				/* If the item is a non-term, queue it for closure. */
				if ( langEl != 0 && langEl->type == LangEl::NonTerm )
					transClosureQueue.append( newTrans );
			}
		}
		else {
			/* Exact overlap, cross them. */
			fsmAttachStates( md, dest, destTel->value, srcTel->value, leavingFsm );
		}
	}
}

/* This assumes that trans has it's data and keys set up. It should not be
 * attached to any state ( toState and fromState == 0 ). */
bool FsmAp::transOverlay( StateAp *from, TransAp *trans, StateAp *defaultTo )
{
	bool modified = false;
	TransMapEl *transEl = from->transMap.find( trans->lowKey );
	if ( transEl != 0 ) {
		addInTrans( transEl->value, trans );
		delete trans;
	}
	else {
		attachTrans( from, defaultTo, trans );
		from->transMap.insert( trans->lowKey, trans );
		modified = true;
	}
	return modified;
}


/* Move all the transitions that go into src so that they go into dest.  */
void FsmAp::inTransMove( StateAp *dest, StateAp *src )
{
	/* Do not try to move in trans to and from the same state. */
	assert( dest != src );

	/* If src is the start state, dest becomes the start state. */
	if ( src == startState ) {
		unsetStartState();
		setStartState( dest );
	}

	/* Move the transitions in inRange. */
	while ( src->inRange.head != 0 ) {
		/* Get trans and from state. */
		TransAp *trans = src->inRange.head;
		StateAp *fromState = trans->fromState;

		/* Detach from src, reattach to dest. */
		detachTrans( fromState, src, trans );
		attachTrans( fromState, dest, trans );
	}
}

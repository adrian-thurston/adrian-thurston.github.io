
class [cn C] { };
namespace [nn ns] {}
template <{class T}> class [cn CT] {};

class [cn string]{};

int $[di main]({int $[di argc], char $<*>[di argv][[]]})
{
	for ( int $(|<*>[di i]|)({int $[di K]}) = 1 ; i < 2 ; i(33)++) {

	}
}

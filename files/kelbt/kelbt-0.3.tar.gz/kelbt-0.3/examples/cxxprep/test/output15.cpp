
class [cn C];

class [cn C]::[cn D];

class [cn C]
{
	[cn D] $[di foo]({});
};

int $[di main]({}) 
{
	class [cn D];
	[cn C] $<*>[di c]({int $[di i]});
	[cn D] $<*>[di d]({});
	int $[di i] = foo->[cn C]::poo( a[[22]][[233]]++ - ~11 || a ? c.hi(1-1):|33);
}

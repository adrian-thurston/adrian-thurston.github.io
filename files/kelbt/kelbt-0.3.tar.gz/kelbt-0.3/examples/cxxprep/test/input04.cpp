
void main(int argc, char *argv[])
{
	int i = --helloNed(1.1, i, i++);
	+ ++foobar++();
}


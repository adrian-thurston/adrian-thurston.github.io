

template <class T> class C 
{
};

class C<int>;

class C<int>
{
};

void f( int (*f)[2](int) );

class D
{
	D *foo;
};
struct E
{
	class D {
		void e(E i);
		D(int i);
		D(D i);
		D(D D);
		~D();
		virtual ~D();
//		template <class> class C;
		class C<int *> {
			E::alsdfj;			
		};
		class D {};

		class F {
			E::D::F::F(int i, const F *k);
		};
	};


	void length() const {}
};


class Base
{
public:
	virtual void foo();
};

class SubClass 
{

};

int main()
{
	foo = E::D(bar);
	bar = foo(88.8);
}

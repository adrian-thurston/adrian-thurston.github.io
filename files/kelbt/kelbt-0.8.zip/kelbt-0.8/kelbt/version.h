#define VERSION "0.8"
#define PUBDATE "January 2007"

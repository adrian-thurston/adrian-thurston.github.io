#define VERSION "0.12"
#define PUBDATE "May 2007"

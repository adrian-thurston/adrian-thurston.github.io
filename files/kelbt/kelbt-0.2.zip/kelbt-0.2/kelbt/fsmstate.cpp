/*
 *  Copyright 2002, 2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <string.h>
#include <assert.h>
#include "fsmgraph.h"

#include <iostream>
using namespace std;

/* Return and re-entry for the co-routine iterators. This should ALWAYS be
 * used inside of a block. */
#define CO_RETURN(label) \
	itState = label; \
	return; \
	entry##label: backIn = true

/* Return and re-entry for the co-routine iterators. This should ALWAYS be
 * used inside of a block. */
#define CO_RETURN2(label, uState) \
	itState = label; \
	userState = uState; \
	return; \
	entry##label: backIn = true

/* Create a new fsm state. State has not out transitions or in transitions, not
 * out out transition data and not number. */
StateAp::StateAp()
:
	/* No out transitions. */
	outList(),

	/* No in transitions. */
	inRange(),

	/* No entry points, or epsilon trans. */
	entryIds(),
	epsilonTrans(),
	contextSet(),
	pendingCommits(),

	/* No transitions in from other states. */
	foreignInTrans(0),

	/* Only used during merging. Normally null. */
	stateDictEl(0),
	eptVect(0),

	/* No state identification bits. */
	stateBits(0),

	onClosureQueue(false),
	inClosedMap(false),
	followMarked(false),

	fssProdId(0)
{
}

/* Copy everything except actual the transitions. That is left up to the
 * FsmAp copy constructor. */
StateAp::StateAp(const StateAp &other)
:
	/* All lists are cleared. They will be filled in when the
	 * individual transitions are duplicated and attached. */
	outList(),
	inRange(),

	/* Duplicate the entry id set, epsilon transitions and context sets. These
	 * are sets of integers and as such need no fixing. */
	entryIds(other.entryIds),
	epsilonTrans(other.epsilonTrans),
	contextSet(other.contextSet),
	pendingCommits(other.pendingCommits),

	/* No transitions in from other states. */
	foreignInTrans(0),

	/* This is only used during merging. Normally null. */
	stateDictEl(0),
	eptVect(0),

	/* Fsm state data. */
	stateBits(other.stateBits),

	dotSet(other.dotSet),
	onClosureQueue(false),
	inClosedMap(false),
	followMarked(false),

	fssProdId(0)
{
	/* Duplicate all the transitions. */
	for ( TransList::Iter trans = other.outList; trans.lte(); trans++ ) {
		/* Dupicate and store the orginal target in the transition. This will
		 * be corrected once all the states have been created. */
		TransAp *newTrans = new TransAp(*trans);
		newTrans->toState = trans->toState;
		outList.append( newTrans );
	}
}

/* Compare class for the sort that does the intial partition of compaction. */
int InitPartitionCompare::compare( const StateAp *state1 , const StateAp *state2 )
{
	int compareRes;

	/* Test final state status. */
	if ( (state1->stateBits & SB_ISFINAL) && !(state2->stateBits & SB_ISFINAL) )
		return -1;
	else if ( !(state1->stateBits & SB_ISFINAL) && (state2->stateBits & SB_ISFINAL) )
		return 1;

	/* Test epsilon transition sets. */
	compareRes = CmpEpsilonTrans::compare( state1->epsilonTrans, 
			state2->epsilonTrans );
	if ( compareRes != 0 )
		return compareRes;

	/* Test context sets. */
	compareRes = CmpContextSets::compare( state1->contextSet, 
			state2->contextSet );
	if ( compareRes != 0 )
		return compareRes;

	/* Compare the out transitions. */
	compareRes = FsmAp::compareStateData( state1, state2 );
	if ( compareRes != 0 )
		return compareRes;
	
	assert( state1->pendingCommits.length() == 0 );
	assert( state2->pendingCommits.length() == 0 );

	/* Use a pair iterator to get the transition pairs. */
	PairIter outPair( state1->outList, state2->outList, false );
	while ( ! outPair.end() ) {
		switch ( outPair.userState ) {

		case PairIter::RangeInS1:
			compareRes = FsmAp::compareDataPtr( outPair.s1Tel.trans, 0 );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::RangeInS2:
			compareRes = FsmAp::compareDataPtr( 0, outPair.s2Tel.trans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::RangeOverlap:
			compareRes = FsmAp::compareDataPtr( 
					outPair.s1Tel.trans, outPair.s2Tel.trans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::BreakS1:
		case PairIter::BreakS2:
			break;
		}
		outPair++;
	}

	return 0;
}

/* Compare class for the sort that does the partitioning. */
int PartitionCompare::compare( const StateAp *state1, const StateAp *state2 )
{
	int compareRes;

	/* Use a pair iterator to get the transition pairs. */
	PairIter outPair( state1->outList, state2->outList, false );
	while ( ! outPair.end() ) {
		switch ( outPair.userState ) {

		case PairIter::RangeInS1:
			compareRes = FsmAp::comparePartPtr( outPair.s1Tel.trans, 0 );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::RangeInS2:
			compareRes = FsmAp::comparePartPtr( 0, outPair.s2Tel.trans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::RangeOverlap:
			compareRes = FsmAp::comparePartPtr( 
					outPair.s1Tel.trans, outPair.s2Tel.trans );
			if ( compareRes != 0 )
				return compareRes;
			break;

		case PairIter::BreakS1:
		case PairIter::BreakS2:
			break;
		}
		outPair++;
	}

	return 0;
}

OutIter::OutIter()
:
	state(0),
	itState(Begin)
{}

/* Init the iterator by advancing to the first item. */
OutIter::OutIter( StateAp *state )
:
	state(state),
	itState(Begin)
{
	findNext();
}

/* Init the iterator by advancing to the first item. */
OutIter::OutIter( StateList::Iter iter )
:
	state(iter),
	itState(Begin)
{
	findNext();
}

/* Init the iterator by advancing to the first item. */
void OutIter::operator=( StateAp *state )
{
	this->state = state;
	itState = Begin;
	findNext();
}

/* Init the iterator by advancing to the first item. */
void OutIter::operator=( StateList::Iter iter )
{
	this->state = iter;
	itState = Begin;
	findNext();
}

/* Postfix operator. Save result for return then increment. */
TransAp *OutIter::operator++(int)
{
	TransAp *retVal = trans;
	findNext();
	return retVal;
}

/* Prefix operator. Icrement first, then return result. */
TransAp *OutIter::operator++()
{
	findNext();
	return trans;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case end() returns true. */
void OutIter::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:     goto entryBegin;
		case Range:     goto entryRange;
		case End:       goto entryEnd;
	}

	entryBegin:

	/* Loop over out list transitions. */
	trans = state->outList.head;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Range );
		trans = trans->next;
	}

	CO_RETURN( End );
}

/* Init the iterator by advancing to the first item. */
InIter::InIter( StateAp *state )
:
	state(state),
	itState(Begin)
{
	findNext();
}

/* Init the iterator by advancing to the first item. */
InIter::InIter( StateList::Iter iter )
:
	state(iter),
	itState(Begin)
{
	findNext();
}

/* Postfix operator. Save result for return then increment. */
TransAp *InIter::operator++(int)
{
	TransAp *retVal = trans;
	findNext();
	return retVal;
}

/* Prefix operator. Icrement first, then return result. */
TransAp *InIter::operator++()
{
	findNext();
	return trans;
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case end() returns true. */
void InIter::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:     goto entryBegin;
		case Range:     goto entryRange;
		case End:       goto entryEnd;
	}

	entryBegin:

	/* Loop over inRange transitions. */
	trans = state->inRange.head;
	while ( trans != 0 ) {
		/* Save the state of the iterator and return. */
		CO_RETURN( Range );

		/* Next transition. */
		trans = trans->ilnext;
	}

	/* Done, go into end state. */
	CO_RETURN( End );
}

/* Init the iterator by advancing to the first item. */
PairIter::PairIter( const TransList &list1, const TransList &list2, bool wantBreaks )
:
	list1(list1),
	list2(list2),
	itState(Begin),
	wantBreaks(wantBreaks)
{
	findNext();
}

/* Advance to the next transition. When returns, trans points to the next
 * transition, unless there are no more, in which case end() returns true. */
void PairIter::findNext()
{
	/* This variable is used in dummy statements that follow the entry
	 * goto labels. The compiler needs some statement to follow the label. */
	bool backIn;

	/* Jump into the iterator routine base on the iterator state. */
	switch ( itState ) {
		case Begin:              goto entryBegin;
		case ConsumeS1Range:     goto entryConsumeS1Range;
		case ConsumeS2Range:     goto entryConsumeS2Range;
		case OnlyInS1Range:      goto entryOnlyInS1Range;
		case OnlyInS2Range:      goto entryOnlyInS2Range;
		case S1SticksOut:        goto entryS1SticksOut;
		case S1SticksOutBreak:   goto entryS1SticksOutBreak;
		case S2SticksOut:        goto entryS2SticksOut;
		case S2SticksOutBreak:   goto entryS2SticksOutBreak;
		case S1DragsBehind:      goto entryS1DragsBehind;
		case S1DragsBehindBreak: goto entryS1DragsBehindBreak;
		case S2DragsBehind:      goto entryS2DragsBehind;
		case S2DragsBehindBreak: goto entryS2DragsBehindBreak;
		case ExactOverlap:       goto entryExactOverlap;
		case End:                goto entryEnd;
	}

entryBegin:
	/* Set up the next structs at the head of the transition lists. */
	s1Tel.set( list1.head );
	s2Tel.set( list2.head );

	/* Concurrently scan both out ranges. */
	while ( true ) {
		if ( s1Tel.trans == 0 ) {
			/* We are at the end of state1's ranges. Process the rest of
			 * state2's ranges. */
			while ( s2Tel.trans != 0 ) {
				/* Range is only in s2. */
				CO_RETURN2( ConsumeS2Range, RangeInS2 );
				s2Tel.increment();
			}
			break;
		}
		else if ( s2Tel.trans == 0 ) {
			/* We are at the end of state2's ranges. Process the rest of
			 * state1's ranges. */
			while ( s1Tel.trans != 0 ) {
				/* Range is only in s1. */
				CO_RETURN2( ConsumeS1Range, RangeInS1 );
				s1Tel.increment();
			}
			break;
		}
		/* Both state1's and state2's transition elements are good.
		 * The signiture of no overlap is a back key being in front of a
		 * front key. */
		else if ( s1Tel.highKey < s2Tel.lowKey ) {
			/* A range exists in state1 that does not overlap with state2. */
			CO_RETURN2( OnlyInS1Range, RangeInS1 );
			s1Tel.increment();
		}
		else if ( s2Tel.highKey < s1Tel.lowKey ) {
			/* A range exists in state2 that does not overlap with state1. */
			CO_RETURN2( OnlyInS2Range, RangeInS2 );
			s2Tel.increment();
		}
		/* There is overlap, must mix the ranges in some way. */
		else if ( s1Tel.lowKey < s2Tel.lowKey ) {
			/* Range from state1 sticks out front. Must break it into
			 * non-overlaping and overlaping segments. */
			bottomLow = s2Tel.lowKey;
			bottomHigh = s1Tel.highKey;
			s1Tel.highKey = s2Tel.lowKey;
			s1Tel.highKey -= 1;
			bottomTrans = s1Tel.trans;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s1. This gives them a
				 * chance to duplicate s1Tel[0,1].value. */
				CO_RETURN2( S1SticksOutBreak, BreakS1 );
			}

			/* Broken off range is only in s1. */
			CO_RETURN2( S1SticksOut, RangeInS1 );

			/* Advance over the part sticking out front. */
			s1Tel.lowKey = bottomLow;
			s1Tel.highKey = bottomHigh;
			s1Tel.trans = bottomTrans;
		}
		else if ( s2Tel.lowKey < s1Tel.lowKey ) {
			/* Range from state2 sticks out front. Must break it into
			 * non-overlaping and overlaping segments. */
			bottomLow = s1Tel.lowKey;
			bottomHigh = s2Tel.highKey;
			s2Tel.highKey = s1Tel.lowKey;
			s2Tel.highKey -= 1;
			bottomTrans = s2Tel.trans;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s2. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S2SticksOutBreak, BreakS2 );
			}

			/* Broken off range is only in s2. */
			CO_RETURN2( S2SticksOut, RangeInS2 );

			/* Advance over the part sticking out front. */
			s2Tel.lowKey = bottomLow;
			s2Tel.highKey = bottomHigh;
			s2Tel.trans = bottomTrans;
		}
		/* Low ends are even. Are the high ends even? */
		else if ( s1Tel.highKey < s2Tel.highKey ) {
			/* Range from state2 goes longer than the range from state1. We
			 * must break the range from state2 into an evenly overlaping
			 * segment. */
			bottomLow = s1Tel.highKey;
			bottomLow += 1;
			bottomHigh = s2Tel.highKey;
			s2Tel.highKey = s1Tel.highKey;
			bottomTrans = s2Tel.trans;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s2. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S2DragsBehindBreak, BreakS2 );
			}

			/* Breaking s2 produces exact overlap. */
			CO_RETURN2( S2DragsBehind, RangeOverlap );

			/* Advance over the front we just broke off of range 2. */
			s2Tel.lowKey = bottomLow;
			s2Tel.highKey = bottomHigh;
			s2Tel.trans = bottomTrans;

			/* Advance over the entire s1Tel. We have consumed it. */
			s1Tel.increment();
		}
		else if ( s2Tel.highKey < s1Tel.highKey ) {
			/* Range from state1 goes longer than the range from state2. We
			 * must break the range from state1 into an evenly overlaping
			 * segment. */
			bottomLow = s2Tel.highKey;
			bottomLow += 1;
			bottomHigh = s1Tel.highKey;
			s1Tel.highKey = s2Tel.highKey;
			bottomTrans = s1Tel.trans;

			if ( wantBreaks ) {
				/* Notify the caller that we are breaking s1. This gives them a
				 * chance to duplicate s2Tel[0,1].value. */
				CO_RETURN2( S1DragsBehindBreak, BreakS1 );
			}

			/* Breaking s1 produces exact overlap. */
			CO_RETURN2( S1DragsBehind, RangeOverlap );

			/* Advance over the front we just broke off of range 1. */
			s1Tel.lowKey = bottomLow;
			s1Tel.highKey = bottomHigh;
			s1Tel.trans = bottomTrans;

			/* Advance over the entire s2Tel. We have consumed it. */
			s2Tel.increment();
		}
		else {
			/* There is an exact overlap. */
			CO_RETURN2( ExactOverlap, RangeOverlap );

			s1Tel.increment();
			s2Tel.increment();
		}
	}

	/* Done, go into end state. */
	CO_RETURN( End );
}

/*
 * Transition Comparison.
 */

/* Compare target partitions. Either pointer may be null. */
int FsmAp::comparePartPtr( TransAp *trans1, TransAp *trans2 )
{
	if ( trans1 != 0 ) {
		/* If trans1 is set then so should trans2. The initial partitioning
		 * guarantees this for us. */
		if ( trans1->toState == 0 && trans2->toState != 0 )
			return -1;
		else if ( trans1->toState != 0 && trans2->toState == 0 )
			return 1;
		else if ( trans1->toState != 0 ) {
			/* Both of targets are set. */
			return CmpOrd< MinPartition* >::compare( 
				trans1->toState->alg.partition, trans2->toState->alg.partition );
		}
	}
	return 0;
}


/* Compares two transition pointers according to priority and functions.
 * Either pointer may be null. Does not consider to state or from state. */
int FsmAp::compareDataPtr( TransAp *trans1, TransAp *trans2 )
{
	if ( trans1 == 0 && trans2 != 0 )
		return -1;
	else if ( trans1 != 0 && trans2 == 0 )
		return 1;
	else if ( trans1 != 0 ) {
		/* Both of the transition pointers are set. */
		int compareRes = compareTransData( trans1, trans2 );
		if ( compareRes != 0 )
			return compareRes;
	}
	return 0;
}

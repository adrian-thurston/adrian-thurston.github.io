

class [cn C] {
};

template <{class T}> class [cn D] {
};

typedef int $[di I];
typedef int $(|(|<*>[di T]|)|)({int, char (|<*>|)({int})});

class [cn C];

[cn C] $[di c];

[cn I] $[di i];
[cn T] $[di t];


namespace [nn NS] {
	using [cn C];
	using [cn D];
	using [cn T];
};

[nn NS]::[cn T] $[di i] = unsigned int(77) + [nn NS]::[cn T](44) - [nn NS]::[cn D]<|1|>(a + b < c);

void $[di f] ({}) {
	class [cn G];
}

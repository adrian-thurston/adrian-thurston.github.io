/*
 *  Copyright 2001-2005 Adrian Thurston <thurston@cs.queensu.ca>
 */

/*  This file is part of Kelbt.
 *
 *  Kelbt is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  Kelbt is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with Kelbt; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <iostream>
#include <iomanip>
#include <errno.h>
#include <stdlib.h>

/* Parsing. */
#include "kelbt.h"
#include "parsedata.h"

/* Dumping the fsm. */
#include "mergesort.h"

using namespace std;

char startDefName[] = "start";

InputLoc::InputLoc( const BISON_YYLTYPE &loc )
:
	line(loc.first_line), 
	col(loc.first_column)
{
}

Action::Action( const InputLoc &loc, char *name, InlineList *inlineList )
:
	loc(loc),
	name(name),
	inlineList(inlineList), 
	actionId(0),
	numTransRefs(0),
	numToStateRefs(0),
	numFromStateRefs(0),
	numEofRefs(0)
{
}

/* Count the transitions in the fsm by walking the state list. */
int countTransitions( FsmAp *fsm )
{
	int numTrans = 0;
	StateAp *state = fsm->stateList.head;
	while ( state != 0 ) {
		numTrans += state->outList.length();
		state = state->next;
	}
	return numTrans;
}

LangEl::LangEl( char *data, Type type )
:
	type(type),
	id(-1),
	isUserTerm(false),
	isContext(false),
	typeDef(0),
	displayString(0),
	numAppearances(0),
	commit(false)
{
	/* If there is a data, take a copy. */
	this->data = strdup(data);
}
 
/* Return a string that describes what the lang el is.
 *   literal-term, term, regular, non-term */
const char *LangEl::typeString()
{
	switch ( type ) {
	case Term:    return "term";
	case NonTerm: return "non-term";
	default: return 0;
	}
}


/*
 * ParseData
 */

/* Initialize the structure that will collect info during the parse of a
 * machine. */
ParseData::ParseData( char *fileName, char *fsmName, const InputLoc &sectionLoc )
:	
	/* 0 is reserved for global error actions. */
	alphType(AT_Char),
	elementType(0),
	getKeyExpr(0),
	lowerNum(0),
	upperNum(0),
	fileName(fileName),
	fsmName(fsmName),
	sectionLoc(sectionLoc),
	errorCount(0),
	curActionOrd(0),
	curPriorOrd(0),
	codeGen(0),
	startLangEl(0),
	eofLangEl(0),
	errorLangEl(0),
	userStartLangEl(0),
	startDef(0),
	nextSymbolId(0), 
	firstNonTermId(0),
	bAnyTokens(false),
	bAnyDefinitions(false),
	structBlock(0),
	elementBlock(0),
	tokenBlock(0),
	preReduceBlock(0),
	postReduceBlock(0),
	translateBlock(0),
	undoTransBlock(0),
	fssProdIdIndex(0),
	didTokens(false),
	someProdNeedsRhsLocate(false)
{}

/* Clean up the data collected during a parse. */
ParseData::~ParseData()
{
	/* Delete all the nodes in the action list. Will cause all the
	 * string data that represents the actions to be deallocated. */
	actionList.empty();
	initCodeList.empty();
}


LangEl *getLangEl( ParseData *pd, char *data, LangEl::Type defType )
{
    /* If the id is already in the dict, it will be placed in last found. If
     * it is not there then it will be inserted and last found will be set to it. */
    SymbolMapEl *inDict = pd->symbolMap.find( data );
    if ( inDict == 0 ) {
        /* Language element not there. Make the new lang el and insert.. */
        LangEl *langEl = new LangEl( data, defType );
        inDict = pd->symbolMap.insert( langEl->data, langEl );
        pd->langEls.append( langEl );
    }
    return inDict->value;
}

ProdElList *makeProdElList( char *name, LangEl *langEl )
{
	ProdElList *prodElList = new ProdElList();
	prodElList->append( new Factor( InputLoc(), false, langEl ) );
	return prodElList;
}

void ParseData::makeDefinitionNames()
{
	for ( LelList::Iter lel = langEls; lel.lte(); lel++ ) {
		int prodNum = 1;
		for ( LelDefList::Iter def = lel->defList; def.lte(); def++ ) {
			def->data = new char[strlen(lel->data) + 30];
			sprintf( def->data, "%s-%i", lel->data, prodNum++ );
		}
	}
}

/* Make sure there there are no language elements whose type is unkonwn. This
 * can happen when an id is used on the rhs of a definition but is not defined
 * as anything. */
void ParseData::noUndefindLangEls()
{
	for ( LelList::Iter lel = langEls; lel.lte(); lel++ ) {
		if ( lel->type == LangEl::Unknown )
			error() << "'" << lel->data << "' was not defined as anything" << endl;
	}
}

void ParseData::makeTokens( )
{
	if ( didTokens )
		return;

	/* Make an EOF language element. */
	eofLangEl = new LangEl( strdup("_eof"), LangEl::Term );
	langEls.append( eofLangEl );
	SymbolMapEl *eofMapEl = symbolMap.insert( eofLangEl->data, eofLangEl );
	assert( eofMapEl != 0 );

	nextSymbolId = 128;

	/* First pass assigns to the user terminals. */
	for ( LelList::Iter lel = langEls; lel.lte(); lel++ ) {
		/* Must be a term, and not any of the special reserved terminals.
		 * Remember if the non terminal is a user non terminal. */
		if ( lel->type == LangEl::Term && lel != eofLangEl && lel != errorLangEl ) {
			lel->isUserTerm = true;
			lel->id = nextSymbolId++;
		}
	}

	/* Next assign to the eof token, which we always create. */
	eofLangEl->id = nextSymbolId++;

	didTokens = true;
}

void ParseData::makeLangElIds()
{
	/* First pass assigns to the user terminals. */
	for ( LelList::Iter lel = langEls; lel.lte(); lel++ ) {
		if ( lel->id < 0 ) {
			/* Must be a term, and not any of the special reserved terminals.
			 * Remember if the non terminal is a user non terminal. */
			if ( lel->type == LangEl::Term && lel != eofLangEl && lel != errorLangEl ) {
				lel->isUserTerm = true;
				lel->id = nextSymbolId++;
			}
		}
	}

	/* Possibly assign to the error language element. */
	if ( errorLangEl != 0 )
		errorLangEl->id = nextSymbolId++;

	/* Save this for for the code generation. */
	firstNonTermId = nextSymbolId;

	/* A third and final pass assigns to everything else. */
	for ( LelList::Iter lel = langEls; lel.lte(); lel++ ) {
		/* Anything else not yet assigned gets assigned now. */
		if ( lel->id < 0 )
			lel->id = nextSymbolId++;
	}
}

void ParseData::resolveReferences( Definition *prod )
{
	if ( prod->redBlock != 0 ) {
		for ( InlineList::Iter ili = *prod->redBlock->inlineList; ili.lte(); ili++ ) {
			if ( ili->type == InlineItem::Reference ) {
				if ( ili->data[1] != '$' && ili->data[1] != '@' ) {
					int refPos = atoi( ili->data+1 ) - 1;
					assert( refPos >= 0 && refPos < prod->rhsFactorVect.length() );
					prod->rhsFactorVect[refPos]->isReferenced = true;
					prod->rhsFactorVect[refPos]->referenceProd = prod;
					prod->rhsFactorVect[refPos]->referenceNum = refPos;
				}
			}
		}
	}
}

/* Set up dot sets, shift info, and prod sets. */
void ParseData::makeProdFsms()
{
	/* There are two items in the index for each production (high and low). */
	int indexLen = prodList.length() * 2;
	dotItemIndex.setAsNew( indexLen );
	int dsiLow = 0, indexPos = 0;
	int fssProdIdLow = 0;

	/* Build FSMs for all production language elements. */
	for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
		/* Resolve reduction references. */
		resolveReferences( prod );

		/* Build the graph from a walk of the parse tree. */
		prodLength = 0;
		prod->fsm = prod->prodElList->walk( this );
	}

	makeNonTermFirstSets();

	/* Build FSMs for all production language elements. */
	for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
		if ( addUniqueEmptyProductions ) {
			if ( !prod->isLeftRec && prod->uniqueEmptyLeader != 0 ) {
				FsmAp *emptyLeader = prod->uniqueEmptyLeader->walk( this );
				emptyLeader->concatOp( prod->fsm );
				prod->fsm = emptyLeader;
			}
		}

		/* Find the positions of the right hand sides. */
		for ( RhsRefMap::Iter ref = prod->rhsRefMap; ref.lte(); ref++ ) {
			int storeNum = ref->key;
			int rhsPos = prod->fsm->fsmLength2( storeNum );
			if ( rhsPos >= 0 && ! prod->fsm->alwaysStoreAt( storeNum, rhsPos ) )
				rhsPos = -1;

			ref->value = rhsPos;
			if ( rhsPos < 0 ) {
				prod->needRhsLocate = true;
				someProdNeedsRhsLocate = true;
			}
			else {
				/* The ref is always at the same spot, don't save the state,
				 * we will access the position by offset. */
				prod->fsm->removeStore( storeNum, rhsPos );
			}
		}

		/* We always isolate the start state before minimization. There is
		 * need to check if it is necessary. If the start state has
		 * transitions in then there is going to be some kind of infinite loop
		 * requiring us to pre-reduce the production. Therefore isolation is
		 * right. If there are no transitions into the start state then
		 * isolation does not cost us any new states and there is no harm
		 * done. We use stateBits to force isolation through the minimization.
		 * */
		prod->fsm->isolateStartState();

		/* Make a minimal fsm. First remove unreachable states, then minimize.
		 * There should be no dead end states. The subtract and intersection
		 * operators are the only places where they may be created and those
		 * operators clean them up. */
		prod->fsm->removeUnreachableStates();
		prod->fsm->startState->stateBits |= SB_ISSTART;
		prod->fsm->minimizePartition2();
		prod->fsm->startState->stateBits &= ~SB_ISSTART;

		/* Compute the machine's length. */
		prod->fsmLength = prod->fsm->fsmLength( 0 );

		/* Find the final-state-specific lengths. */
		prod->fssFsmLengths = new int[prod->fsm->finStateSet.length()];
		for ( StateSet::Iter fin = prod->fsm->finStateSet; fin.lte(); fin++ ) {
			int length = prod->fsm->fsmLength( *fin );
			prod->fssFsmLengths[fin.pos()] = length;
			if ( length < 0 )
				prod->needFirstLocate = true;
		}

		if ( prod->needFirstLocate ) {
			for ( TransList::Iter trans = prod->fsm->startState->outList; 
					trans.lte(); trans++ )
				trans->pushSet.insert( prod );
		}

		/* Productions have a unique production id for each final state.
		 * This lets us use a production length specific to each final state.
		 * Start states are always isolated therefore if the start state is
		 * final then reductions from it will always have a fixed production
		 * length. This is a simple method for determining the length
		 * of zero-length derivations when reducing. */
		prod->fssProdIdLow = fssProdIdLow;
		fssProdIdLow += prod->fsm->finStateSet.length();

		/* Number of dot items needed for the production is elements + 1
		 * because the dot can be before the first and after the last element. */
		int numForProd = prod->fsm->stateList.length() + 1;

		/* Set up the low and high values in the index for this production. */
		dotItemIndex.data[indexPos].key = dsiLow;
		dotItemIndex.data[indexPos].value = prod;
		dotItemIndex.data[indexPos+1].key = dsiLow + numForProd - 1;
		dotItemIndex.data[indexPos+1].value = prod;

		int dsi = dsiLow;
		for ( StateList::Iter state = prod->fsm->stateList; state.lte(); state++, dsi++ ) {
			/* All transitions are shifts. */
			for ( OutIter out = state; out.lte(); out++ )
				out.trans->isShift = true;

			state->dotSet.insert( dsi );
		}

		/* Move over the production. */
		dsiLow += numForProd;
		indexPos += 2;

		if ( prod->prodCommit ) {
			for ( StateSet::Iter fin = prod->fsm->finStateSet; fin.lte(); fin++ ) {
				int length = prod->fssFsmLengths[fin.pos()];
				//cerr << "PENDING COMMIT IN FINAL STATE of " << prod->prodId <<
				//		" with len: " << length << endl;
				(*fin)->pendingCommits.insert( ProdIdPair( prod->prodId, length ) );
			}
		}
	}

	/* Make the final state specific prod id to prod id mapping. */
	fssProdIdIndex = new Definition*[fssProdIdLow];
	for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
		for ( int p = 0; p < prod->fsm->finStateSet.length(); p++ )
			fssProdIdIndex[prod->fssProdIdLow+p] = prod;
	}
}


void ParseData::computeActOrdsDef( StateAp *tabState, TransAp *tabTrans, 
		Definition *definition, long level, long &time )
{
	ExpandToSet expandTo;
	computeActOrdsState( expandTo, tabState, definition->fsm->startState, level, time );

	for ( ExpandToSet::Iter ets = expandTo; ets.lte(); ets++ ) {
		int fssProdId = ets->fssProdId;
		StateAp *expandTo = ets->state;

		/* Find the reduce item. */
		long redCode = makeReduceCode( fssProdId, false );
		for ( TransList::Iter tabTrans = expandTo->outList; tabTrans.lte(); tabTrans++ ) {
			for ( ActDataList::Iter adl = tabTrans->actions; adl.lte(); adl++ ) {
				if ( *adl == redCode && tabTrans->actOrds[adl.pos()] == 0 ) {
					//cerr << "setting reduction(" << redCode << "): state = " 
					//		<< expandTo->stateNum 
					//		<< ", trans = " << tabTrans->lowKey 
					//		<< ", time = " << time << endl;
					tabTrans->actOrds[adl.pos()] = time++;
				}
			}
		}
	}
}

void ParseData::computeActOrdsState( ExpandToSet &expandTo, StateAp *tabState, 
	StateAp *srcState, long level, long &time )
{
	assert( srcState->dotSet.length() == 1 );
	if ( tabState->dotSet2.find( srcState->dotSet[0] ) )
		return;
	tabState->dotSet2.insert( srcState->dotSet[0] );

	/* We manage our own expand to sets here even though they are set up in
	 * the LR tables already so that we only visit the expand to destinates
	 * once (the above dotSet guard will stop us from multiple visits).
	 *
	 * It may be sufficient just to rely on the test which determines if the
	 * action has a timestamp already. */
	if ( srcState->isFinState() )
		expandTo.insert( ExpandToEl( tabState, srcState->fssProdId ) );

	/* Traverse the src state's transitions. */
	for ( TransList::Iter srcTrans = srcState->outList; srcTrans.lte(); srcTrans++ ) {
		/* Find the equivalent state in the parser. */
		TransAp *tabTrans = tabState->findTrans( srcTrans->lowKey );


		/* Recurse into the transition if it is a non-terminal. */
		LangEl *langEl = langElIndex[srcTrans->lowKey];
		if ( langEl != 0 ) {
			for ( LelDefList::Iter expDef = langEl->defList; expDef.lte(); expDef++ )
				computeActOrdsDef( tabState, tabTrans, expDef, level+1, time );
		}

		/* Find the shift item. */
		ActDataList::Iter adl = tabTrans->actions;
		for ( ; adl.lte(); adl++ ) {
			if ( *adl == SHIFT_CODE )
				break;
		}

		/* If the time of the shift is not already set, set it. */
		if ( tabTrans->actOrds[adl.pos()] == 0 ) {
			//cerr << "setting shift: state = " << tabState->stateNum 
			//		<< ", trans = " << tabTrans->lowKey
			//		<< ", time = " << time << endl;
			tabTrans->actOrds[adl.pos()] = time++;
		}


		computeActOrdsState( expandTo, tabTrans->toState, srcTrans->toState, level+1, time );
	}
}

void ParseData::computeActOrds()
{
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		state->traversalLevel = 0;
		assert( (state->stateBits & SB_ISMARKED) == 0 );

		/* Traverse the src state's transitions. */
		long last = 0;
		for ( TransList::Iter trans = state->outList; trans.lte(); trans++ ) {
			assert( (trans->transBits & SB_ISMARKED) == 0 );
			assert( trans->lowKey == trans->highKey );
			if ( ! trans.first() )
				assert( last < trans->lowKey );
			last = trans->highKey;
		}
	}

	/* Compute the action orderings, record the max value. */
	long level = 1, time = 1;
	ExpandToSet expandTo;
	StateAp *startState = startDef->fsm->startState;
	computeActOrdsState( expandTo, graph->startState, startState, level, time );

	/* Walk over the start lang el and set the time for shift of
	 * the eof action that completes the parse. This could use some cleanup,
	 * in particular a find routine. */
	TransAp *overStart = graph->startState->findTrans( userStartLangEl->id );
	TransAp *eofTrans = overStart->toState->findTrans( eofLangEl->id );
	eofTrans->actOrds[0] = time++;
}

void ParseData::advanceReductions()
{
	/* Use the closure queue to process the states since we have misfit
	 * accounting on and will be modifying the state list. */
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ )
		graph->stateClosureQueue.append( state );

	graph->setMisfitAccounting( true );

	/* Loop all states. */
	for ( StateClosureQueue::Iter state = graph->stateClosureQueue; state.lte(); state++ ) {
		bool outHasShift = false;
		ProdIdSet outReds;
		IntSet outCommits;
		for ( OutIter out(state); out.lte(); out++ ) {
			/* Get the transition from the trans el. */
			if ( out.trans->isShift )
				outHasShift = true;
			outReds.insert( out.trans->reductions );
			outCommits.insert( out.trans->commits );
		}

		bool inHasShift = false;
		ProdIdSet inReds;
		for ( InIter in(state); in.lte(); in++ ) {
			/* Get the transition from the trans el. */
			if ( in.trans->isShift )
				inHasShift = true;
			inReds.insert( in.trans->reductions );
		}

		if ( !outHasShift && outReds.length() == 1 && 
				inHasShift && inReds.length() == 0 )
		{
			//cerr << "moving reduction to shift" << endl;

			/* Move the reduction to all in transitions. */
			for ( InIter in(state); in.lte(); in++ ) {
				assert( in.trans->actions.length() == 1 );
				assert( in.trans->actions[0] == SHIFT_CODE );
				in.trans->actions[0] = makeReduceCode( outReds[0], true );
				in.trans->afterShiftCommits.insert( outCommits );
			}

			/* 
			 * Remove all transitions out of the state.
			 */

			/* Detach out range transitions. */
			for ( TransList::Iter trans = state->outList; trans.lte(); ) {
				TransList::Iter next = trans.next();
				graph->detachTrans( state, trans->toState, trans );
				delete trans;
				trans = next;
			}
			state->outList.abandon();

			/* Redirect all the in transitions to the actionDestState. */
			graph->inTransMove( actionDestState, state );
		}
	}

	graph->removeMisfits();
	graph->setMisfitAccounting( false );
}

void ParseData::sortActions()
{
	/* Sort the actions. */
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		assert( CmpDotSet::compare( state->dotSet, state->dotSet2 ) == 0 );
		for ( TransList::Iter trans = state->outList; trans.lte(); trans++ ) {
			/* Check every action has an ordering. */
			for ( ActDataList::Iter adl = trans->actOrds; adl.lte(); adl++ ) {
				if ( *adl == 0 ) {
					error() << "ACTION ORDERING for " << 
						trans->actions[adl.pos()] << " is unset, state: " << 
						state->stateNum << ", trans: ";

					LangEl *lel = langElIndex[trans->lowKey];
					if ( lel == 0 )
						cerr << (char)trans->lowKey << endl;
					else
						cerr << lel->data << endl;
				}
			}

			/* Sort by the action ords. */
			ActDataList actionsDup( trans->actions );
			ActDataList actOrdsDup( trans->actOrds );
			trans->actions.empty();
			trans->actOrds.empty();
			while ( actOrdsDup.length() > 0 ) {
				int min = 0;
				for ( int i = 1; i < actOrdsDup.length(); i++ ) {
					if ( actOrdsDup[i] < actOrdsDup[min] )
						min = i;
				}
				trans->actions.append( actionsDup[min] );
				trans->actOrds.append( actOrdsDup[min] );
				actionsDup.remove(min);
				actOrdsDup.remove(min);
			}

			if ( branchPointInfo && trans->actions.length() > 1 ) {
				cerr << "info: branch point"
						<< " state: " << state->stateNum
						<< " trans: ";
				LangEl *lel = langElIndex[trans->lowKey];
				if ( lel == 0 )
					cerr << (char)trans->lowKey << endl;
				else
					cerr << lel->data << endl;

				for ( ActDataList::Iter act = trans->actions; act.lte(); act++ ) {
					switch ( *act & 0x3 ) {
					case 1: 
						cerr << "    shift" << endl;
						break;
					case 2: 
						cerr << "    reduce " << 
								fssProdIdIndex[(*act >> 2)]->data << endl;
						break;
					case 3:
						cerr << "    shift-reduce" << endl;
						break;
					}
				}
			}

			/* Verify that shifts of nonterminals don't have any branch
			 * points or commits. */
			if ( trans->lowKey >= firstNonTermId ) {
				if ( trans->actions.length() != 1 || 
					(trans->actions[0] & 0x3) != 1 )
				{
					error() << "TRANS ON NONTERMINAL is something "
						"other than a shift" << endl;
				}
				if ( trans->commits.length() > 0 )
					error() << "TRANS ON NONTERMINAL is has a commit" << endl;
			}

			/* TODO: Shift-reduces are optimizations. Verify that
			 * shift-reduces exist only if they don't entail a conflict. */
		}
	}
}

void ParseData::reduceActions()
{
	/* Reduce the actions. */
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		for ( TransList::Iter trans = state->outList; trans.lte(); trans++ ) {
			ActionSetEl *inSet;

			int commitLen = trans->commits.length() > 0 ?
				trans->commits[trans->commits.length()-1] : 0;

			if ( trans->afterShiftCommits.length() > 0 ) {
				int afterShiftCommit = trans->afterShiftCommits[
					trans->afterShiftCommits.length()-1];

				if ( commitLen > 0 && commitLen+1 > afterShiftCommit )
					commitLen = ( commitLen + 1 );
				else
					commitLen = afterShiftCommit;
			}
			else {
				commitLen = commitLen * -1;
			}
			
//			if ( commitLen != 0 ) {
//				cerr << "FINAL ACTION COMMIT LEN: " << commitLen << endl;
//			}

			actionSet.insert( ActionData( trans->toState->stateNum, 
					trans->actions, trans->redPushSet, trans->redStoreSet,
					commitLen ), &inSet );
			trans->actionSetEl = inSet;
		}
	}
}

void ParseData::analyzeMachine()
{
	maxState = graph->stateList.length() - 1;
	maxLelId = nextSymbolId - 1;
	maxOffset = graph->stateList.length() * maxLelId;

	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		for ( TransList::Iter trans = state->outList; trans.lte(); trans++ ) {
			if ( trans->isShift )
				trans->actions.append( SHIFT_CODE );
			for ( ReductionSet::Iter red = trans->reductions; red.lte(); red++ )
				trans->actions.append( makeReduceCode( *red, false ) );
			trans->actOrds.appendDup( 0, trans->actions.length() );
		}
	}

	computeActOrds();
	sortActions();
	advanceReductions();
	graph->setStateNumbers();
	reduceActions();

	/* Set the action ids. */
	int actionSetId = 0;
	for ( ActionSet::Iter asi = actionSet; asi.lte(); asi++ )
		asi->key.id = actionSetId++;
	
	/* Get the max index. */
	maxIndex = actionSetId - 1;

	/* Compute the max prod length. */
	maxProdLen = 0;
	for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
		if ( prod->fsmLength >= 0 && (unsigned)prod->fsmLength > maxProdLen )
			maxProdLen = prod->fsmLength;
	}
}

void ParseData::reduceSets()
{
	/* Create the prod set set from transitions and state. */
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		for ( OutIter out = state; out.lte(); out++ )
			prodSetSet.insert( out.trans->pushSet );
	}
	assert( prodSetSet.data[0].length() == 0 );

	/* Store the id of the reduced prod set set. */
	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		for ( OutIter out = state; out.lte(); out++ ) {
			DefSet *pushSet = prodSetSet.find( out.trans->pushSet );
			out.trans->redPushSet = pushSet - prodSetSet.data;
		}
	}

	for ( StateList::Iter state = graph->stateList; state.lte(); state++ ) {
		for ( OutIter out = state; out.lte(); out++ ) {
			for ( DefSet::Iter dsi = out.trans->pushSet; dsi.lte(); dsi++ )
				(*dsi)->reducesTo.insert( out.trans->redPushSet );
		}
	}

	//for ( DefList::Iter prod = prodList; prod.lte(); prod++ )
	//	cerr << prod->data << " " << prod->prodId << endl;
}

void ParseData::wrapUserStartSymbol()
{
	SymbolMapEl *startMapEl = symbolMap.find( startDefName );
	if ( startMapEl == 0 ) {
		/* No recovery action, fsm is skipped. */
		error(sectionLoc) << "start non-terminal not defined in \"" 
			<< fsmName << "\"" << endl;
		return;
	}
	userStartLangEl = startMapEl->value;

	/* Make a language element that will go to the start symbol only. This will
	 * guarantee a start symbol with only one production. A name with an underscore 
	 * at the beginning will never clash with any user name. */
	startLangEl = new LangEl( strdup("_start"), LangEl::NonTerm );
	langEls.append( startLangEl );
	startMapEl = symbolMap.insert( startLangEl->data, startLangEl );
	assert( startMapEl != 0 );

	/* Make a single production for the start element. */
	ProdElList *startProdElList = makeProdElList( startLangEl->data, userStartLangEl );
	startDef = new Definition( InputLoc(), startLangEl, 
			startProdElList, false, 0, 0, 0,
			prodList.length(), Definition::Production );

	prodList.append( startDef );
	startLangEl->defList.append( startDef );
}

bool ParseData::followDownProd( Definition *prod, StateAp *state )
{
	bool modified = false;
	for ( TransList::Iter trans = state->outList; trans.lte(); trans++ ) {
		if ( trans->lowKey >= firstNonTermId ) {
			int *inserted = prod->nonTermFirstSet.insert( trans->lowKey );
			if ( inserted != 0 )
				modified = true;

			bool hasEpsilon = false;
			LangEl *lel = langElIndex[trans->lowKey];
			for ( LelDefList::Iter ldef = lel->defList; ldef.lte(); ldef++ ) {
				for ( ProdIdSet::Iter pid = ldef->nonTermFirstSet; 
						pid.lte(); pid++ )
				{
					if ( *pid == -1 )
						hasEpsilon = true;
					else {
						int *inserted = prod->nonTermFirstSet.insert( *pid );
						if ( inserted != 0 )
							modified = true;
					}
				}
			}

			if ( hasEpsilon ) {
				if ( trans->toState->isFinState() ) {
					int *inserted = prod->nonTermFirstSet.insert( -1 );
					if ( inserted != 0 )
						modified = true;
				}

				bool lmod = followDownProd( prod, trans->toState );
				if ( lmod )
					modified = true;
			}
		}
	}
	return modified;
}

void ParseData::makeNonTermFirstSets()
{
//	cerr << "MAKING NONTERM FIRST SETS" << endl;
	bool modified = true;
	while ( modified ) {
		modified = false;
		for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
			if ( prod->fsm->startState->isFinState() ) {
				int *inserted = prod->nonTermFirstSet.insert( -1 );
				if ( inserted != 0 )
					modified = true;
			}

			bool lmod = followDownProd( prod, prod->fsm->startState );
			if ( lmod )
				modified = true;
		}
	}

	for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
//		cerr << prod->data << ": ";
//		for ( ProdIdSet::Iter pid = prod->nonTermFirstSet; pid.lte(); pid++ )
//		{
//			if ( *pid < 0 )
//				cerr << " <EPSILON>";
//			else {
//				LangEl *lel = langElIndex[*pid];
//				cerr << " " << lel->data;
//			}
//		}
//		cerr << endl;

		if ( prod->nonTermFirstSet.find( prod->prodName->id ) ) {
//			cerr << "PROD IS LEFT REC: " << prod->data << endl;
			prod->isLeftRec = true;
		}
	}
}

void ParseData::makeGraph()
{
	makeTokens();

	if ( addUniqueEmptyProductions ) {
		int limit = prodList.length();
		for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
			if ( prod->prodId == limit )
				break;

			/* Get a language element. */
			char name[20];
			sprintf(name, "U%li", prodList.length());
			LangEl *prodName = getLangEl( this, name, LangEl::NonTerm );
			Definition *newDef = new Definition( InputLoc(), prodName, 
					0 /* FIXME new VarDef( name, 0 )*/, 
					false, 0, 0, 0, prodList.length(), Definition::Production );
			prodName->defList.append( newDef );
			prodList.append( newDef );

			prod->uniqueEmptyLeader = prodName;
		}
	}

	wrapUserStartSymbol();
	if ( gblErrorCount > 0 ) 
		return;

	makeLangElIds();
	makeDefinitionNames();
	noUndefindLangEls();

	/* Put the language elements in an index by language element id. */
	langElIndex = new LangEl*[nextSymbolId+1];
	memset( langElIndex, 0, sizeof(LangEl*)*(nextSymbolId+1) );
	for ( LelList::Iter lel = langEls; lel.lte(); lel++ )
		langElIndex[lel->id] = lel;
	
	/* Fill Reference Vectors. */
	for ( DefList::Iter prod = prodList; prod.lte(); prod++ ) {
		if ( prod->redBlock != 0 ) {
			for ( InlineList::Iter ili = *prod->redBlock->inlineList; ili.lte(); ili++ ) {
				if ( ili->type == InlineItem::Reference ) {
					if ( ili->data[1] != '$' && ili->data[1] != '@' ) {
						int pos = atoi(ili->data+1)-1;
						prod->rhsRefMap.insert( pos, 0, 0 );
					}
				}
			}
		}
	}
	
	//for ( DefList::Iter prod = prodList; prod.lte(); prod++ )
	//	cerr << prod->prodId << " " << prod->data << endl;

	makeProdFsms();

	lalr1GenerateParser();
	graph->setStateNumbers();
	reduceSets();
	analyzeMachine();

	cerr << "NUMBER OF STATES: " << graph->stateList.length() << endl;
}

void ParseData::generateHeader( int endLine )
{
	makeTokens( );
	startCodeGen();

	/* Write the header elements. */
	ostream &out = *outStream;
	writeTokenDefs( out );
	writeHeader( out );

	endCodeGen( endLine );
}

void ParseData::generateCode( bool sawInterface, int endLine )
{
	makeGraph();
	if ( gblErrorCount > 0 ) 
		return;

	/* Write the output. */
	startCodeGen();

	/* Write the code elements. */
	ostream &out = *outStream;
	writeTokenIds( out );
	writeLangEls( out );
	writeParser( out );
	writeTables( out );

	endCodeGen( endLine );
}

void ParseData::generateGraphviz( )
{
	makeGraph();
	if ( gblErrorCount > 0 ) 
		return;
	writeDotFile();
}

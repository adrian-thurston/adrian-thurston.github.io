ragel c-example.rl && gcc c-example.c
ragel -J java-example.rl -o JavaSample.java && javac JavaSample.java
# to clean: 
#   rm *.class *.java *.c *.out
